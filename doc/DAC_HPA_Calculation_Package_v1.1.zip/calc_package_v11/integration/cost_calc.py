import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""VE cost basis (ve/brief_ve_integration.md step 2; owner decisions O-1...O-4 / DZ-7...DZ-10).

Reads bom_merged.csv (built by build_package.py from the VE stream BOMs) and writes cost_report.md.
JLCPCB parts at exact 5-board quantity + JLCPCB attrition (parts-stream ORDER_PLAN rule), owner-fitted lines
excluded from the JLCPCB parts, joints, part types, X-ray and THT fees; both assembly classes with the
handling-fee rule; global sourcing only for the lines still global-sourced; owner purchase and gate samples;
PCB without epoxy via fill. Report only - no cost gate.
"""
import csv, math, re

OUT = _PKG_ROOT + '/integration'
N = 5
RATE = 31.73          # NTD per USD [ASSUMP: spot 25 Sep 2026, as in the previous passes; parts used 32.5 for the tax threshold]
PREV = dict(per_board=82.02, order=1072.87, order_ntd=34042, parts_buy=640.32, fees=271.90, gs=82.65, pcb=53.00, ship=25.00)
PREV_V09 = 758.82   # v0.9 document set (VE pass + parts clean-up, 25 Sep 16:06)
V09 = dict(parts_buy=248.20, fees=277.00, gs=24.02, pcb=23.00, ship=25.00, owner=161.60)   # its cost elements (cost_report of 16:06)
PREV_V10 = 856.14   # v1.0 set (R9 final, cost_report of 25 Sep 20:08)
V10 = dict(parts_buy=317.37, fees=299.62, gs=29.54, pcb=23.00, ship=25.00, owner=161.60)   # its cost elements (v1.0 cost_report section 1)
V10_BOARD = dict(fitted=78.51, placed=55.76, owner=22.75, order_ntd=27165, per_board=171.23)   # v1.0 cost_report section 1

# owner-fitted lines (layout_package.md 13a, DZ-10): DNP at JLCPCB, owner buys 5 x qty
OWNER = {'D102', 'R509', 'K601-K604', 'J701'}
# LCSC order multiples known from the stream VE sections (analog V1/V3, digital VE 1)
MULT = {'RT0603BRD071K3L': 60, 'RT0603BRD07680RL': 60, 'ERA-3AEB202V': 50, 'RT0603BRD07698RL': 40, 'SN74LVC3G34DCUR': 10}
# still global-sourced after VE: stock text says so, plus the 0.1 % values with no LCSC listing (parts ORDER_PLAN)
GLOBAL_EXTRA = ['RT0402BRD07953KL', 'RT0402BRD07330KL', 'RT0402BRD071ML']   # no LCSC listing (parts 11:33); 237 k C852654 is at LCSC
LCSC_FIRST = ['PMEG2010AEH', 'RT0603BRD07698RL', 'RT0603BRD07205KL', 'TLV1704AIPWR']   # LCSC primary, global only as fallback

rows = list(csv.DictReader(open(f'{OUT}/bom_merged.csv', encoding='utf-8')))
comp = [r for r in rows if r['fit'].startswith('Yes') and r['mpn'] not in ('JLCPCB',) and not r['mpn'].lower().startswith('pcb pad')
        and r['refs'] not in ('PCB', 'MH, FID')]
for r in comp:
    if r['refs'] in OWNER:
        assert 'owner' in (r['note'] + r['stock_or_sourcing']).lower(), r['refs']


def is_passive(r):
    return re.match(r'^(R|C|FB)', r['refs']) is not None


def attrition(r, need):
    """ORDER_PLAN rule (parts VE model): exact need + JLCPCB attrition, estimated 5 % min 2 for passives, +1 per other line [ASSUMP]."""
    return max(2, math.ceil(0.05 * need)) if is_passive(r) else 1


def is_global(r):
    t = r['stock_or_sourcing'].lower()
    if any(k in r['mpn'] for k in LCSC_FIRST):
        return False
    return any(k in r['mpn'] for k in GLOBAL_EXTRA) or 'global sourcing' in t and ('out of stock' in t or 'not stocked' in t or t.startswith('jlcpcb global') or 'lcsc out' in t or 'not at lcsc' in t or 'treat as jlcpcb global' in t or r['jlcpcb_class'].strip().lower().startswith('global sourcing'))


placed, owner = [], []
for r in comp:
    q = int(r['qty_per_board']); need = q * N; up = float(r['unit_price_usd'] or 0)
    d = dict(refs=r['refs'], mpn=r['mpn'], q=q, need=need, up=up, smt=int(r['smt_pins_per_part']), tht=int(r['tht_pins_per_part']),
             leadless=r['leadless'].startswith('Yes'), cls=r['jlcpcb_class'], stream=r['stream'])
    if r['refs'] in OWNER:
        owner.append(d); continue
    buy = need + attrition(r, need)
    m = next((v for k, v in MULT.items() if k in r['mpn']), None)
    if m:
        buy = max(buy, m)
    d.update(buy=buy, glob=is_global(r), basic=('basic' in r['jlcpcb_class'].lower() and 'extended' not in r['jlcpcb_class'].lower()))
    placed.append(d)

parts_buy = sum(l['buy'] * l['up'] for l in placed)
parts_need = sum(l['need'] * l['up'] for l in placed)
per_board_placed = sum(l['q'] * l['up'] for l in placed)
per_board_owner = sum(l['q'] * l['up'] for l in owner)
glob_buy = sum(l['buy'] * l['up'] for l in placed if l['glob'])

# ---- assembly fees, JLCPCB fee table of 8 Sep 2026 (parts VE model constants)
smt_joints = sum(l['q'] * l['smt'] for l in placed)
tht_joints = sum(l['q'] * l['tht'] for l in placed)          # R11 (SE-1 / SE-2): J101 shell stakes (and any plated slot pads counted as THT): no fee priced
tht_desc = ', '.join(f"{l['refs']} {l['q'] * l['tht']}" for l in placed if l['tht']) or 'none'
types = {l['mpn'] for l in placed}
basic_types = {l['mpn'] for l in placed if l['basic']}
ext_types = types - basic_types
leadless_pcs = sum(l['q'] for l in placed if l['leadless']) * N


def xray_rate(n):
    for lim, p in [(10, 1.64), (50, 0.82), (200, 0.49), (500, 0.33), (1000, 0.25), (3000, 0.16), (99999, 0.082)]:
        if n <= lim:
            return p


xray = leadless_pcs * xray_rate(leadless_pcs)
joints_fee = smt_joints * N * 0.0016
econ = [('Setup', 8.18), ('Stencil', 1.53), (f'SMT joints {smt_joints} x {N} x $0.0016', joints_fee),
        ('Manual/THT joints (none priced: J701 owner-fitted; J101 S1–S4 / J702 pads 1/2 by confirmed reflow or the owner fallback)', 0.0), ('Hand-soldering labour', 0.0),
        (f'Extended part types {len(ext_types)} x $3.07 (Basic {len(basic_types)} free)', len(ext_types) * 3.07),
        (f'X-ray {leadless_pcs} leadless parts x ${xray_rate(leadless_pcs):.2f}', xray), ('Confirm parts placement', 0.45)]
econ_total = sum(v for _, v in econ)
std = [('Setup', 25.56), ('Stencil', 8.21), (f'SMT joints {smt_joints} x {N} x $0.0016', joints_fee),
       ('Manual/THT joints (none priced)', 0.0), ('Hand-soldering labour (no through-hole-only part in the JLCPCB order; a JLCPCB hand-solder step for J101 S1–S4 / J702 pads 1/2 would be priced from their quote)', 0.0),
       (f'All part types {len(types)} x $1.53 (feeder loading)', len(types) * 1.53),
       (f'X-ray {leadless_pcs} leadless parts x ${xray_rate(leadless_pcs):.2f}', xray), ('Confirm parts placement', 0.45),
       ('Fixture (2 for 1-29 boards)', 16.42), (f'Packing $0.50 + $0.00003 x {10 * 9 * N} cm2 (100 x 90 mm panels)', 0.50 + 0.00003 * 10 * 9 * N)]
std_base = sum(v for _, v in std)
topup = max(0.0, econ_total + 14.93 - std_base)
std_total = std_base + topup

# ---- global sourcing (lines still global-sourced)
gs = [('Price difference of global-sourced parts (+10 % of their value) [ASSUMP]', 0.10 * glob_buy),
      ('Commodity inspection, USB4105 connector ($20 per kind of connector)', 20.0 if any('USB4105' in l['mpn'] and l['glob'] for l in placed) else 0.0),
      ('Customs duty on relays (TLP3545A now owner-bought -> none)', 0.0),
      ('Shipping of global-sourced parts to JLCPCB', 0.0)]
gs_total = sum(v for _, v in gs)

# ---- owner purchase: two orders (parts layout_package.md 13a, 25 Sep 11:32) - owner-fitted parts + gate samples
LAYOUT = _PKG_ROOT + '/parts/layout_package.md'
ORD = {'DigiKey': [], 'LCSC': []}
for ln in open(LAYOUT, encoding='utf-8'):
    c = [x.strip() for x in ln.strip().strip('|').split('|')]
    if len(c) >= 6 and c[0] in ORD and not c[0].startswith('**'):
        ORD[c[0]].append(dict(part=c[1], qty=int(c[2]), unit=float(c[3]), usd=float(c[4]), role=c[5]))
TOT = {}
for ln in open(LAYOUT, encoding='utf-8'):
    c = [x.strip().strip('*') for x in ln.strip().strip('|').split('|')]
    if len(c) >= 5 and c[0] in ORD and c[1] == 'parts total':
        TOT[c[0]] = float(c[4])
dk_parts = TOT.get('DigiKey', sum(x['usd'] for x in ORD['DigiKey']))   # parts' stated order totals (unrounded line values)
lc_parts = TOT.get('LCSC', sum(x['usd'] for x in ORD['LCSC']))
dk_ship, dk_tax = 0.0, 0.05 * dk_parts            # DigiKey TW free delivery >= US$ 50; customs value > NT$ 2,000 -> 5 % business tax
lc_ship, lc_tax = 10.0, 0.0                       # LCSC economy courier ~US$ 10 [ASSUMP]; customs value <= NT$ 2,000 -> no tax
dk_total = dk_parts + dk_ship + dk_tax
lc_total = lc_parts + lc_ship + lc_tax
own_total = dk_total + lc_total
own_parts = dk_parts + lc_parts
own_ship = dk_ship + lc_ship
own_tax = dk_tax + lc_tax
# R9: order totals follow parts' tables (layout_package.md 13a)

# ---- PCB and shipping [ASSUMP, not quoted]
pcb = [('4-layer FR-4 1.6 mm JLC04161H-7628, 5 panels 100 x 90 mm (board 100 x 80 mm + 2 x 5 mm rails, E-19) - same JLCPCB <= 100 x 100 mm price tier as 80 x 70 mm [ASSUMP]', 8.0), ('ENIG (kept; HASL rejected)', 15.0),
       ('90 ohm impedance control on the standard stack-up', 0.0),
       ('Exposed-pad thermal vias unfilled and tented (VE: epoxy fill and cap dropped, was US$ 30.00 [ASSUMP])', 0.0),
       ('V-cut rails panel, fiducials/tooling by JLCPCB', 0.0)]
pcb_total = sum(v for _, v in pcb)
ship = 25.0

jlc_total_std = parts_buy + std_total + gs_total + pcb_total + ship
jlc_total_econ = parts_buy + econ_total + gs_total + pcb_total + ship
order_std = jlc_total_std + own_total
order_econ = jlc_total_econ + own_total


def usd(x):
    return f'{x:,.2f}'


def ntd(x):
    return f'{x * RATE:,.0f}'


md = []
A = md.append
A('# Cost report — v1.1 set (R10), VE cost basis (26 Sep 2026)')
A('')
A('**Estimate: every total in this report is an estimate until the supplier orders and the JLCPCB quote exist** — '
  'part prices and stock are those of the day, JLCPCB attrition, PCB price and shipping are assumed, and no order has been placed. '
  'The R10 sourcing data (prices, stock, JLCPCB class) come from web-page copies read by parts on 26 Sep 2026 and are to be re-checked in the JLCPCB BOM tool at order.')
A('')
A('Integration, generated by `integration/cost_calc.py` (VE basis) from `bom_merged.csv` (VE stream BOMs). **Report only — no cost gate.** '
  f'Basis: owner decisions O-1…O-4 (decisions_r8c DZ-7…DZ-10): exact 5-board quantity + JLCPCB attrition (no spares), owner-fitted parts '
  f'(D102, R509, K601–K604, J701) bought and hand-soldered by the owner in two orders (DigiKey + LCSC) that also carry the gate samples, **Standard PCBA** (Economic for information), epoxy via fill dropped. '
  f'Currency {RATE} NTD/USD [ASSUMP]. The previous basis (final pass) is kept as `_work/cost_report_final_pass.md.bak`.')
A('')
A('## 1. Summary')
A('')
A('| Item | USD | NTD | Basis |')
A('|---|---:|---:|---|')
A(f'| JLCPCB-placed parts per board (stream unit prices) | {usd(per_board_placed)} | {ntd(per_board_placed)} | {len(placed)} lines, {sum(l["q"] for l in placed)} parts [CALC] |')
A(f'| Owner-fitted parts per board (distributor prices) | {usd(per_board_owner)} | {ntd(per_board_owner)} | {len(owner)} lines, {sum(l["q"] for l in owner)} parts |')
A(f'| **All fitted parts per board** | **{usd(per_board_placed + per_board_owner)}** | **{ntd(per_board_placed + per_board_owner)}** | v1.0 set US$ {V10_BOARD["fitted"]:.2f} (JLCPCB-placed {V10_BOARD["placed"]:.2f} + owner {V10_BOARD["owner"]:.2f}) |')
A(f'| JLCPCB parts for 5 boards, exact need + attrition | {usd(parts_buy)} | {ntd(parts_buy)} | exact need US$ {usd(parts_need)} + attrition [ASSUMP rule, section 2] |')
A(f'| JLCPCB Standard PCBA fees (basis) | {usd(std_total)} | {ntd(std_total)} | section 3 (incl. handling-fee top-up {usd(topup)}) |')
A(f'| (information) JLCPCB Economic PCBA fees | {usd(econ_total)} | {ntd(econ_total)} | section 3 — not used: U202 at the Economic pitch limit, J101/J702 reflow |')
A(f'| Global-sourcing extras | {usd(gs_total)} | {ntd(gs_total)} | section 4 |')
A(f'| PCB, 5 panels (no epoxy via fill) | {usd(pcb_total)} | {ntd(pcb_total)} | section 6 [ASSUMP — not quoted] |')
A(f'| Shipping JLCPCB → Taiwan | {usd(ship)} | {ntd(ship)} | [ASSUMP] |')
A(f'| **JLCPCB order (Standard)** | **{usd(jlc_total_std)}** | **{ntd(jlc_total_std)}** | |')
A(f'| Owner purchase: two orders (DigiKey + LCSC), owner-fitted parts **and gate samples**, incl. shipping and tax | {usd(own_total)} | {ntd(own_total)} | section 5 (DigiKey {usd(dk_total)} + LCSC {usd(lc_total)}) |')
A(f'| **Total per 5-board order (JLCPCB Standard + owner)** | **{usd(order_std)}** | **{ntd(order_std)}** | estimate until the supplier orders and the JLCPCB quote exist; v1.0 set US$ {usd(PREV_V10)} = NTD {V10_BOARD["order_ntd"]:,} ({order_std - PREV_V10:+.2f}) |')
A(f'| **Equivalent per assembled board (total / 5)** | **{usd(order_std / N)}** | **{ntd(order_std / N)}** | v1.0 set US$ {V10_BOARD["per_board"]:.2f} |')
A(f'| (information) Total with Economic PCBA | {usd(order_econ)} | {ntd(order_econ)} | −{usd(order_std - order_econ)} vs Standard |')
A(f'| Per assembled board: JLCPCB {usd(jlc_total_std / N)} + owner {usd(own_total / N)} | {usd(order_std / N)} | {ntd(order_std / N)} | order total / 5 |')
A('')
A(f'### Change vs the v1.0 set (US$ {PREV_V10:.2f} → {usd(order_std)}, {order_std - PREV_V10:+.2f})')
A('')
A('| Cost element | v1.0 set (USD) | v1.1 set R10 (USD) | Change (USD) | Main cause |')
A('|---|---:|---:|---:|---|')
_v11 = dict(parts_buy=parts_buy, fees=std_total, gs=gs_total, pcb=pcb_total, ship=ship, owner=own_total)
_cause = dict(parts_buy='history-robust protection: per-leg OR stages (U611/U612 TLV1704) and LPW stages (8 x TLV3402IDGKR at US$ 1.3642, 1 M / 910 k / 360 k / 88.7 k resistors, 3.3 nF 0603 and 100 nF 1206 C0G), R951, onsemi MMBT3904LT1G for Q623-Q627, the TLV1704 line priced at the 30+ tier (US$ 1.5567); the leg-window RC stage (115 k, 2.2 uF, 0.1 % 121 k / 115 k / 10.0 k) removed',
              fees='more Extended part types (TLV3402IDGKR, 910 k, 88.7 k, 360 k, FH 0603 / 1206 C0G, MMBT3904LT1G) minus the retired 115 k type — Standard base and the handling-fee top-up',
              gs='the retired 0.1 % 121 k / 115 k global lines; the new C0G lines are LCSC-stocked (no global sourcing)',
              pcb='unchanged: 100 × 80 mm (panel 100 × 90 mm), same price tier [ASSUMP]',
              ship='—', owner='unchanged (no owner-fitted change in R10)')
_names = dict(parts_buy='JLCPCB parts', fees='Assembly fees (Standard)', gs='Global-sourcing extras', pcb='PCB', ship='Shipping', owner='Owner purchase (two orders)')
for _k in ('parts_buy', 'fees', 'gs', 'pcb', 'ship', 'owner'):
    A(f'| {_names[_k]} | {usd(V10[_k])} | {usd(_v11[_k])} | {_v11[_k] - V10[_k]:+.2f} | {_cause[_k]} |')
A(f'| **Total** | {usd(PREV_V10)} | {usd(order_std)} | {order_std - PREV_V10:+.2f} | (the v1.0 elements are rounded to the cent) |')
A('')
A(f'Earlier record: the v0.9 set was US$ {PREV_V09:.2f}; the v1.0 set US$ {PREV_V10:.2f} ({PREV_V10 - PREV_V09:+.2f}).')
A('')
A('### VE-round comparison: where the saving comes from (5-board order, R8 final pass US$ 1,072.87 → current set)')
A('')
A('| Cost element | Final pass (USD) | VE (USD) | Change (USD) | Main cause |')
A('|---|---:|---:|---:|---|')
chg = [('JLCPCB parts (incl. spares / attrition)', PREV['parts_buy'], parts_buy, 'O-1 no spares; LCSC substitutes (leg resistors, C442/C443, R641/R642, U208, R668/R669, D610); owner-fitted lines moved out'),
       ('Assembly fees (Standard)', PREV['fees'], std_total, f'placed types 100 (final pass 109) and no priced THT / hand-soldering fee lower the Standard base to {usd(std_base)}, but the handling-fee rule lifts Standard to Economic + 14.93 (top-up {usd(topup)})'),
       ('Global-sourcing extras', PREV['gs'], gs_total, 'TLP3545A duty gone (owner-bought); leg resistors, T495D, PATT, R509/R510/D102 no longer global'),
       ('PCB', PREV['pcb'], pcb_total, 'epoxy fill and cap of the EP vias dropped (tented)'),
       ('Shipping', PREV['ship'], ship, '—'),
       ('Owner purchase (two orders, incl. gate samples, shipping, tax)', 0.0, own_total, 'owner-fitted K601–K604, J701, D102, R509 at distributor prices + the G-1…G-4 gate samples (the final pass had no owner purchase and no priced samples)'),
       ('**Total**', PREV['order'], order_std, '')]
for name, a, b, c in chg:
    A(f'| {name} | {usd(a)} | {usd(b)} | {usd(b - a)} | {c} |')
A('')
A(f'Saving vs the final pass: **US$ {usd(PREV["order"] - order_std)} per order = NTD {ntd(PREV["order"] - order_std)}** '
  f'({100 * (PREV["order"] - order_std) / PREV["order"]:.1f} %); per assembled board US$ {usd((PREV["order"] - order_std) / N)}. '
  f'Fitted-parts cost per board: US$ {PREV["per_board"]:.2f} → {usd(per_board_placed + per_board_owner)}.')
A('')
A('## 2. JLCPCB parts for 5 boards (placed lines only; owner-fitted lines excluded)')
A('')
A('Rule (parts ORDER_PLAN, O-1): buy = 5 × per board + JLCPCB attrition; attrition estimated as 5 % (min 2) for passives and +1 per other line [ASSUMP — JLCPCB sets the real figure in the quote]; known LCSC order multiples applied (1.30 k/680 Ω leg resistors 60, 2.00 k 50, 698 Ω 40, SN74LVC3G34 10). TLV1704AIPWR is costed from LCSC stock at the 30+ tier (US$ 1.5567) — **condition: ≥ 31 in LCSC stock at order time** (6 per board since R10: U603, U606, U609–U612; 30 + attrition), otherwise JLCPCB global sourcing (+10 %). **TLV3402IDGKR (C140314, 8 per board, U613–U620): JLCPCB shows 152 available against 40 + attrition — buy now into the JLCPCB part library.**')
A('')
A('| Refs | MPN | /board | Need | Buy | Unit USD | USD | Sourcing |')
A('|---|---|---:|---:|---:|---:|---:|---|')
for l in sorted(placed, key=lambda x: -x['buy'] * x['up']):
    A(f'| {l["refs"]} | {l["mpn"]} | {l["q"]} | {l["need"]} | {l["buy"]} | {l["up"]:.4g} | {usd(l["buy"] * l["up"])} | {"global sourcing" if l["glob"] else "JLCPCB/LCSC"} |')
A(f'| **Total** | | | | | | **{usd(parts_buy)}** | |')
A('')
A('## 3. Assembly fees (JLCPCB fee table of 8 Sep 2026; parts VE model constants)')
A('')
A(f'Placed part types {len(types)} (Basic {len(basic_types)}, Extended/unverified {len(ext_types)} — class as recorded in the stream BOMs; "preferred Extended" status not checked, it could only lower the Economic figure). SMT joints {smt_joints} per board; plated through-hole joints in the JLCPCB order {tht_joints} per board ({tht_desc}): no fee priced — reflowed only if JLCPCB confirms the process in writing (G-6), otherwise hand-soldered by the owner from the bottom side at no cost; a JLCPCB hand-solder step, if quoted, is added from their quote [ASSUMP]; leadless (X-ray) parts {leadless_pcs // N} per board.')
A('')
A('| Fee item | Economic (USD) | Standard (USD) |')
A('|---|---:|---:|')
emap = dict(econ); smap = dict(std)
keys = []
for k, _ in econ + std:
    if k not in keys:
        keys.append(k)
for k in keys:
    A(f'| {k} | {usd(emap[k]) if k in emap else "—"} | {usd(smap[k]) if k in smap else "—"} |')
A(f'| Subtotal | {usd(econ_total)} | {usd(std_base)} |')
A(f'| Handling fee (Standard must be ≥ Economic + 14.93) | — | {usd(topup)} |')
A(f'| **Total** | **{usd(econ_total)}** | **{usd(std_total)}** |')
A('')
A(f'**Class decision (DZ-8):** Standard is the basis. Economic would save {usd(std_total - econ_total)} per order but U202 AGRV2KQ32 (QFN-32, 0.40 mm) sits at the Economic minimum pitch with no solder-paste inspection and cannot be owner-fitted; J101 USB4105 (255 °C −0/+5, 5 s) and J702 PJ-332A-6A (rating not verified) do not fit the fixed 255 ± 5 °C Economic reflow.')
A('')
A('## 4. Global-sourcing extras (lines still global-sourced)')
A('')
A('Lines: ' + ', '.join(f'{l["refs"]} ({l["mpn"]})' for l in placed if l['glob']) + f' — value bought US$ {usd(glob_buy)}.')
A('')
A('| Item | USD | Basis |')
A('|---|---:|---|')
for k, v in gs:
    A(f'| {k} | {usd(v)} | [JLCPCB global-sourcing terms; ASSUMP where marked] |')
A(f'| **Total** | **{usd(gs_total)}** | |')
A('')
A('## 5. Owner purchase — two orders (owner-fitted parts + gate samples; parts `layout_package.md` §13a)')
A('')
A('The owner-fitted parts (D102, R509, K601–K604, J701; DNP at JLCPCB) double as their own gate samples — the G-2/G-3/G-4 checks are non-destructive and are done before fitting — so they are not bought twice. Every other gate sample (two per part type named in G-1…G-4, LCSC minimum quantities where they apply) goes on the order that stocks it.')
A('')
A('| Order | Part | Qty | Unit USD | USD | Role |')
A('|---|---|---:|---:|---:|---|')
for o in ('DigiKey', 'LCSC'):
    for x in ORD[o]:
        A(f'| {o} | {x["part"]} | {x["qty"]} | {x["unit"]:.4g} | {usd(x["usd"])} | {x["role"]} |')
A(f'| **DigiKey** | parts | | | **{usd(dk_parts)}** | shipping {usd(dk_ship)} (free delivery to Taiwan above US$ 50); 5 % business tax {usd(dk_tax)} (customs value above NT$ 2,000; ITA tariff 0 % [ASSUMP]) → **{usd(dk_total)}** |')
A(f'| **LCSC** | parts | | | **{usd(lc_parts)}** | shipping ≈ {usd(lc_ship)} [ASSUMP: economy courier, rate shown only at checkout]; customs value under NT$ 2,000 → no tax → **{usd(lc_total)}** |')
A(f'| **Owner total** | | | | **{usd(own_total)}** | parts {usd(own_parts)} + shipping {usd(own_ship)} + tax {usd(own_tax)} = NTD {ntd(own_total)} |')
A('')
A('Fitting order of the owner-fitted parts: D102/R509 → K601–K604 → J701 (bring-up (i)). If power adopts an LCSC USB-C connector for J101, its G-1 samples move to the LCSC order and the USB4105 line drops out.')
A('')
A('## 6. PCB and shipping [ASSUMP — not quoted]')
A('')
A('| Item | USD |')
A('|---|---:|')
for k, v in pcb:
    A(f'| {k} | {usd(v)} |')
A(f'| **PCB total** | **{usd(pcb_total)}** |')
A(f'| Shipping JLCPCB → Taiwan (courier) | {usd(ship)} |')
A('')
A('## 7. Not verified (plainly)')
A('')
A('The totals as a whole: an estimate until the supplier orders (DigiKey, LCSC) and the JLCPCB quote exist; the figures above are then replaced by the quoted and invoiced amounts.')
A('')
A('JLCPCB per-part attrition (estimated); the real via-fill and ENIG adders (quote-only); which Extended parts are "preferred Extended"; whether Economic accepts global-sourced parts; Taiwan tariff lines (0 % assumed); the LCSC shipping to Taiwan (≈ US$ 10 assumed; the order stays under NT$ 2,000 only if shipping ≤ ≈ US$ 16); 1-piece prices of some gate samples (LCSC minimum quantities assumed 1–5 pcs where not marked); TLV1704 LCSC stock at order time; and, for every part, the prices, stock figures and JLCPCB classes of the day, which come from web-page copies of 26 Sep 2026 (the R10 parts included: C643–C646 FH 0603 C190576 and R934 360 k C45956 are verified Extended by parts from the part pages, MSL 1, Economic + Standard) - re-check them in the JLCPCB BOM tool at order.')
open(f'{OUT}/cost_report.md', 'w', encoding='utf-8').write('\n'.join(md) + '\n')
print(f'placed lines {len(placed)} types {len(types)} (basic {len(basic_types)}, ext {len(ext_types)}); owner lines {len(owner)}; smt {smt_joints}; leadless/board {leadless_pcs // N}')
print(f'per board placed {per_board_placed:.2f} owner {per_board_owner:.2f} all {per_board_placed + per_board_owner:.2f}')
print(f'parts buy {parts_buy:.2f} (need {parts_need:.2f}); fees std {std_total:.2f} (base {std_base:.2f} + topup {topup:.2f}) econ {econ_total:.2f}; gs {gs_total:.2f} (glob buy {glob_buy:.2f}); pcb {pcb_total:.2f}; ship {ship:.2f}')
print(f'JLCPCB std {jlc_total_std:.2f} (NTD {jlc_total_std * RATE:.0f}); owner {own_total:.2f} = DigiKey {dk_total:.2f} + LCSC {lc_total:.2f} (NTD {own_total * RATE:.0f}); ORDER std {order_std:.2f} = NTD {order_std * RATE:.0f}; econ {order_econ:.2f}; per board JLCPCB {jlc_total_std / N:.2f} owner {own_total / N:.2f} total {order_std / N:.2f} (NTD {order_std / N * RATE:.0f})')
print(f'saving vs final pass {PREV["order"] - order_std:.2f} USD; change vs the v1.0 set (US$ {PREV_V10}) {order_std - PREV_V10:+.2f} USD')
