import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""Merge the stream BOM rows and netlists and run consistency (ERC-like) checks."""
import csv, re, os, sys, collections, json
BASE=_PKG_ROOT + ''
STREAMS=sys.argv[1:] or ['power','protection','analog','digital']
IFACE=set("""VBUS 5V_SYS GND 3V3M 3V3D 1V3 3V3A 5V_ANA 5V_ANA_F VPOS VNEG USB_DP USB_DN CC1 CC2 CC1_ADC CC2_ADC VBUS_SENSE
AUD_EN AVCC_EN ANA_EN ILIM_HI ANA_SENSE N2_AVCC_EN_G RELAY_EN DAC_RESETB LED_G LED_R RAILS_OK_N ANA_FAULT_N DC_PERMIT_N CPLD_IRQ
DAC_LOCK LRCLK_FB PROG DC_SENSE_LP DC_SENSE_LN DC_SENSE_RP DC_SENSE_RN V3A_MON LINK_SCK LINK_MOSI LINK_MISO LINK_FRAME I2C_SCL I2C_SDA
SWDIO SWCLK NRST BOOT0 USART_TX USART_RX CPLD_JTMS CPLD_JTCK CPLD_NRST MCLK MCLK_EN FAM_CLK OSC48_EN OSC44_EN BCLK LRCLK SDATA
DACL DACLB DACR DACRB VREF AVCC_L AVCC_R VCCA DVCC LEG_LP LEG_LN LEG_RP LEG_RN JACK_LP JACK_RP JACK_LN JACK_RN""".split())
def expand(refs):
    out=[]
    for tok in re.split(r'\s*,\s*',refs.strip()):
        m=re.match(r'^([A-Z]+)(\d+)\s*[–\-]\s*([A-Z]*)(\d+)$',tok)
        if m:
            p,a,_,b=m.groups(); w=len(m.group(2))
            out+= ['%s%d'%(p,i) for i in range(int(a),int(b)+1)]
        elif tok: out.append(tok)
    return out
def load(path):
    if not os.path.exists(path): return None
    with open(path,newline='',encoding='utf-8-sig') as f: return list(csv.DictReader(f))
issues=collections.defaultdict(list); bom={}; BOM_ROWS=[]; nets=collections.defaultdict(list); pins=collections.defaultdict(dict)
for s in STREAMS:
    b=load(f'{BASE}/{s}/bom_rows.csv'); n=load(f'{BASE}/{s}/netlist.csv')
    if b is None: issues['missing'].append(f'{s}: bom_rows.csv missing'); b=[]
    if n is None: issues['missing'].append(f'{s}: netlist.csv missing'); n=[]
    for r in b:
        BOM_ROWS.append((s, r))
        for d in expand(r.get('refs','')):
            if d in bom: issues['dup_refdes'].append(f'{d}: {bom[d]["stream"]} and {s}')
            bom[d]=dict(stream=s,row=r)
    for r in n:
        d=r.get('refdes','').strip(); p=r.get('pin','').strip(); net=r.get('net','').strip()
        if not d or not p: issues['bad_row'].append(f'{s}: {r}'); continue
        if p in pins[d] and pins[d][p][0]!=net: issues['pin_two_nets'].append(f'{d}.{p}: {pins[d][p][0]} ({pins[d][p][1]}) vs {net} ({s})')
        pins[d][p]=(net,s,r.get('pin_name',''))
        nets[net].append((d,p,s))
# checks
for d,v in bom.items():
    fit=v['row'].get('fit','Yes'); np_=v['row'].get('smt_pins_per_part','') or '0'; th=v['row'].get('tht_pins_per_part','') or '0'
    try: exp=int(float(np_))+int(float(th))
    except: exp=None
    got=len(pins.get(d,{}))
    if exp and got==0 and fit.lower().startswith(('yes','dnf')): issues['no_netlist'].append(f'{d} ({v["stream"]}, fit {fit})')
    elif exp and got and got!=exp: issues['pin_count'].append(f'{d}: BOM {exp} pins, netlist {got}')
for d in pins:
    if d not in bom: issues['netlist_not_in_bom'].append(f'{d} ({",".join(sorted({x[1] for x in pins[d].values()}))})')
for net,conns in nets.items():
    if net.upper() in ('NC',''): continue
    if len(conns)<2: issues['single_pin_net'].append(f'{net}: {conns}')
    streams={c[2] for c in conns}
    if net in IFACE and len(conns)<2: issues['iface_unconnected'].append(net)
    if net not in IFACE and len(streams)>1 and not re.match(r'^N\d_',net): issues['cross_stream_non_iface'].append(f'{net}: {sorted(streams)}')
for i in IFACE:
    if i not in nets: issues['iface_absent'].append(i)
norm=collections.defaultdict(set)
for net in nets: norm[re.sub(r'[^A-Z0-9]','',net.upper())].add(net)
for k,v in norm.items():
    if len(v)>1: issues['near_duplicate_net_names'].append(sorted(v))

# ---- E-1 (R9): the BOM value must decode from the MPN (UNI-ROYAL 0402WGF/0603WAF/0805W8F, YAGEO RT/RC/RP, SAE 1RC,
#      KOA RN73/RS73 resistor codes; Samsung CL and FH capacitor codes)
_SZ = r'(?:0201|0402|0603|0805|1206|1210)'
def decode_mpn(mpn):
    """Return (value, unit, family) decoded from the MPN, None if the MPN is outside the covered families,
    or (None, None, family) if the family is recognised but the code cannot be decoded."""
    m = mpn.upper().replace('(FENGHUA)', '')
    if 'UNI-ROYAL' in m or re.search(r'\b' + _SZ + r'W[A-Z0-9]F\d', m) or re.search(r'\bTC0[1-9](?:05|10|15|25|50)[BCDF]\d', m):
        x = re.search(_SZ + r'W[A-Z0-9]F(\d{3})([0-6JKLM])', m) or re.search(r'TC0[1-9](?:05|10|15|25|50)[BCDF](\d{3})([0-6JKLM])T', m)   # R9: TC0225 thin film (R924 alt. TC0225B3322TCC)
        if not x: return (None, None, 'UNI-ROYAL')
        mult = {'J': 0.1, 'K': 0.01, 'L': 0.001, 'M': 0.0001}.get(x.group(2))
        return (int(x.group(1)) * (mult if mult is not None else 10 ** int(x.group(2))), 'ohm', 'UNI-ROYAL')
    if 'YAGEO' in m and re.search(r'\bR[TCP]' + _SZ, m):
        x = re.search(r'\bR[TCP]' + _SZ + r'[A-Z]{1,3}-?07(\d*)([RKM])(\d*)L\b', m)
        if not x: return (None, None, 'YAGEO')
        num = float((x.group(1) or '0') + '.' + (x.group(3) or '0'))
        return (num * {'R': 1, 'K': 1e3, 'M': 1e6}[x.group(2)], 'ohm', 'YAGEO')
    if 'SAE' in m and re.search(r'\b1RC' + _SZ, m):
        x = re.search(r'\b1RC' + _SZ + r'[A-Z](\d{3})([0-6JK])\b', m)
        if not x: return (None, None, 'SAE')
        mult = {'J': 0.1, 'K': 0.01}.get(x.group(2))
        return (int(x.group(1)) * (mult if mult is not None else 10 ** int(x.group(2))), 'ohm', 'SAE')
    if 'KOA' in m and re.search(r'\bR[NS]73', m):
        x = re.search(r'\bR[NS]73[A-Z]?\d[A-Z]TT[A-Z]?(\d{3})(\d)[A-Z]', m)
        if not x: return (None, None, 'KOA')
        return (int(x.group(1)) * 10 ** int(x.group(2)), 'ohm', 'KOA')
    if 'SAMSUNG' in m and re.search(r'\bCL\d\d[A-Z]', m):
        x = re.search(r'\bCL\d\d[A-Z](\d[0-9R]\d|\d\d[0-9R])', m)
        if not x: return (None, None, 'Samsung CL')
        c = x.group(1)
        pf = float(c.replace('R', '.')) if 'R' in c else int(c[:2]) * 10 ** int(c[2])
        return (pf * 1e-12, 'F', 'Samsung CL')
    if re.search(r'\bFH\b|FENGHUA', m):
        x = re.search(r'\b' + _SZ + r'(?:CG|NPO|NP0|B|X|N|F)?(\d[0-9R]\d|\d\d[0-9R])[BCDFGJKMZ]\d{3}N', m)
        if not x: return (None, None, 'FH')
        c = x.group(1)
        pf = float(c.replace('R', '.')) if 'R' in c else int(c[:2]) * 10 ** int(c[2])
        return (pf * 1e-12, 'F', 'FH')
    return None

def parse_value(v):
    """BOM value field -> (value, unit) or None ('100 kOhm', '4.7 k', '33 R', '0 Ohm', '4.7 uF', '82 pF', '1.00 MOhm')."""
    x = re.match(r'^\s*([0-9]*\.?[0-9]+)\s*([pnuµmkKM]?)\s*(ohm|Ω|R|F)?\b', v.strip(), re.I)
    if not x: return None
    num, pre, unit = float(x.group(1)), x.group(2), (x.group(3) or '')
    if unit.upper() == 'F' or (pre in ('p', 'n', 'u', 'µ') and unit == ''):
        return (num * {'p': 1e-12, 'n': 1e-9, 'u': 1e-6, 'µ': 1e-6, 'm': 1e-3, '': 1}[pre], 'F')
    return (num * {'': 1, 'k': 1e3, 'K': 1e3, 'M': 1e6, 'm': 1e-3}[pre], 'ohm')

VALUE_CHECK = dict(decoded=0, families=collections.Counter())
for s_, r in BOM_ROWS:
    mpn, val, fit = r.get('mpn', ''), r.get('value', ''), r.get('fit', 'Yes')
    dm = decode_mpn(mpn)
    if dm is None: continue
    dv, du, fam = dm
    placeholder = 'XXX' in mpn.upper() or val.strip().upper().startswith('DNF')
    if dv is None:
        if not placeholder: issues['value_mpn_undecoded'].append(f"{r.get('refs')} ({s_}): MPN '{mpn}' ({fam}) not decodable")
        continue
    pv = parse_value(val)
    if pv is None:
        if not placeholder: issues['value_mpn_mismatch'].append(f"{r.get('refs')} ({s_}): value '{val}' not parseable vs MPN {mpn} = {dv:g} {du}")
        continue
    VALUE_CHECK['decoded'] += 1; VALUE_CHECK['families'][fam] += 1
    ok = (pv[1] == du) and ((dv == 0 and pv[0] == 0) or (dv != 0 and abs(pv[0] - dv) / dv <= 0.005))
    if not ok:
        issues['value_mpn_mismatch'].append(f"{r.get('refs')} ({s_}): value '{val}' but MPN {mpn} decodes to {dv:g} {du}")
summary=dict(parts=len(bom),netlisted_parts=len(pins),nets=len(nets),pins=sum(len(v) for v in pins.values()),issues={k:len(v) for k,v in issues.items()},value_decode=dict(lines=VALUE_CHECK['decoded'],families=dict(VALUE_CHECK['families'])))
json.dump(dict(summary=summary,issues=issues),open(f'{BASE}/integration/check_result.json','w'),indent=1,ensure_ascii=False)
print(json.dumps(summary,indent=1))
for k,v in issues.items():
    print('==',k,len(v))
    for x in v[:25]: print('   ',x)
