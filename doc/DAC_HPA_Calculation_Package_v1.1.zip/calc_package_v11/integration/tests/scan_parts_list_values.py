"""Apply the E-1 decoder to the Parts List workbook (read-only) to locate stale Value cells."""
import re, collections, os, sys, openpyxl
src = open(os.path.join(os.path.dirname(__file__), '..', 'check_design.py')).read()
ns = {'re': re, 'collections': collections}
exec(src[src.index('_SZ = r'):src.index('VALUE_CHECK = dict(')], ns)
path = sys.argv[1]
wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
n = bad = 0
for ws in wb.worksheets:
    hdr = None
    for row in ws.iter_rows(values_only=True):
        cells = [str(c) if c is not None else '' for c in row]
        low = [c.lower() for c in cells]
        if hdr is None:
            if any('value' == c.strip() for c in low) and any('mpn' in c or 'part number' in c for c in low):
                hdr = {k: i for i, k in enumerate(low)}
                iv = next(i for i, c in enumerate(low) if c.strip() == 'value')
                im = next(i for i, c in enumerate(low) if 'mpn' in c or 'part number' in c)
                idg = next((i for i, c in enumerate(low) if 'designator' in c or c.strip() in ('refs', 'ref')), 0)
            continue
        if len(cells) <= max(iv, im): continue
        d = ns['decode_mpn'](cells[im]); p = ns['parse_value'](cells[iv])
        if not d or d[0] is None or not p: continue
        n += 1
        if not (p[1] == d[1] and ((d[0] == 0 and p[0] == 0) or (d[0] and abs(p[0] - d[0]) / d[0] <= 0.005))):
            bad += 1
            print(f'{ws.title}: {cells[idg]} value "{cells[iv]}" vs MPN {cells[im]} = {d[0]:g} {d[1]}')
    hdr = None
print(f'{os.path.basename(path)}: {n} decodable rows, {bad} mismatches')
