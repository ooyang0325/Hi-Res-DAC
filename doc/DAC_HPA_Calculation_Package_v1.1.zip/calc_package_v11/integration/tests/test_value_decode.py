"""Self-test of the E-1 value-decode check in check_design.py (integration, R9)."""
import re, collections, sys, os
src = open(os.path.join(os.path.dirname(__file__), '..', 'check_design.py')).read()
block = src[src.index('_SZ = r'):src.index('VALUE_CHECK = dict(')]
ns = {'re': re, 'collections': collections}
exec(block, ns)
dec, pv = ns['decode_mpn'], ns['parse_value']
cases = [('UNI-ROYAL 0402WGF1003TCE', '86.6 kOhm', False), ('UNI-ROYAL 0402WGF4703TCE', '300 kOhm', False),
         ('UNI-ROYAL 0402WGF1003TCE', '68.1 kOhm', False), ('UNI-ROYAL 0402WGF4702TCE', '30.1 kOhm', False),
         ('UNI-ROYAL 0402WGF1003TCE', '100 kOhm', True), ('UNI-ROYAL 0603WAF470KT5E', '4.7 Ohm', True),
         ('UNI-ROYAL 0603WAF100JT5E', '10 Ohm', True), ('UNI-ROYAL 0402WGF330JTCE', '33 R', True),
         ('UNI-ROYAL 0402WGF0000TCE', '0 R', True), ('UNI-ROYAL 0402WGF2205TCE', '22 MOhm', True),
         ('UNI-ROYAL 0805W8F220KT5E', '2.2 ohm', True), ('YAGEO RT0603BRD071K3L', '1.30 kOhm', True),
         ('YAGEO RT0402BRD0724R9L', '24.9 Ohm', True), ('YAGEO RT0402BRD071ML', '1.00 MOhm', True),
         ('YAGEO RC0402FR-0722ML', '22 MOhm', True), ('YAGEO RP0402BRD076K8L (RT0402BRD076K8L alt.)', '6.8 kOhm', True),
         ('YAGEO RT0603BRD07680RL', '680 ohm', True), ('SAE 1RC0402F2204', '2.2 MOhm', True), ('SAE 1RC0402F4704', '4.7 MOhm', True),
         ('KOA RN73R1JTTD4811B25', '4.81 kOhm', True), ('KOA RN73R1JTTD4811B25', '4.75 kOhm', False),
         ('Samsung CL05C101JB5NNNC', '100 pF', True), ('Samsung CL21A475KAQNNNE', '4.7 uF', True),
         ('Samsung CL10C100JB8NNNC', '10 pF', True), ('Samsung CL05B103KB5NNNC', '100 nF', False),
         ('FH 0402B472K500NT', '4.7 nF', True), ('FH (Fenghua) 0402CG820J500NT', '82 pF', True), ('FH 0402CG330J500NT', '3.3 pF', False),
         ('UNI-ROYAL TC0225B3322TCC', '33.2 kOhm', True), ('UNI-ROYAL TC0225B3322TCC', '187 kOhm', False)]
bad = 0
for mpn, val, expect in cases:
    d = dec(mpn); p = pv(val)
    ok = d is not None and d[0] is not None and p is not None and p[1] == d[1] and ((d[0] == 0 and p[0] == 0) or (d[0] and abs(p[0] - d[0]) / d[0] <= 0.005))
    flag = 'OK ' if ok == expect else 'ERR'
    bad += ok != expect
    print(f'{flag} {mpn:45s} value {val:10s} decoded {d[0] if d else None!s:>10} {d[1] if d else ""} -> {"match" if ok else "MISMATCH"}')
print('self-test', 'PASS' if not bad else f'FAIL ({bad})')
sys.exit(1 if bad else 0)
