"""E-15 (R9) / F-2 (R10) evidence register: requirement or limit -> value -> class (derived from the recorded inputs) -> evidence -> qualification test.

R10 F-2: the class is no longer typed in; every row records its inputs (INPUTS below) and derive() gives the class by the rule
"G only if every input is a datasheet limit or a G result; any assumption, typical value or reconstructed model -> E; anything
resting on a measurement -> Q". Q rows are open qualification obligations (open until the measurement record exists).
Options: --out PATH (trial output; default evidence_register.csv), --strict (final rebuild: no pending stream list, no conflict,
no traceability text contradicting a class). The R9 texts below are kept for the requirement/qualification-test columns and as
the v1.0 class ('class_v1.0').

Class: G = every input a datasheet limit, a construction fact or a G row (worst-case calculation); E = at least one assumption,
typical value or reconstructed/typical-curve model (named in 'capped_by'); Q = the claim rests on a measurement: an open
qualification obligation until the measurement record exists (no board exists yet, so none has passed).
Output columns (R10): id, requirement_or_limit, value, class, capped_by, inputs, evidence, qualification_test,
qualification_status, class_v1.0, class_source. (The R9 columns assumption_flag / r9_status are replaced by capped_by /
inputs / qualification_status / class_source.) Input: traceability.csv (same folder). Output: evidence_register.csv.
"""
import csv, os

HERE = os.path.dirname(os.path.abspath(__file__))
# id: (class, assumption flag ('' = none), qualification test, r9 status)
C = {
    'R-01': ('G', '', 'bit-perfect capture at all 8 rates (bring-up i-11)', 'final'),
    'R-02': ('E', 'host driver behaviour (not provable by calculation)', 'enumeration + playback on Windows/macOS/Linux/Android', 'final'),
    'R-03': ('G', 'minor: board skew 2.22 ns [ASSUMP] vs 14.0 ns margin', 'scope setup/hold at 384 kHz', 'final'),
    'R-04': ('Q', 'X201 duty 45-55 % equals the ESS limit (zero margin)', 'duty/edges at U301 XI (TP711); fallback R203 0 ohm / NDK part', 'final'),
    'R-05': ('E', 'typical-only DAC/op-amp THD data', 'THD+N 1 kHz 0 dBFS 300 ohm, LEG vs JACK', 'provisional (E-3 new taps: analog to confirm THD)'),
    'R-06': ('E', 'typical DAC DR (127 dB-A) and noise densities', 'DR measurement (A-weighted)', 'final'),
    'R-07': ('G', '', 'production calibration to 1.55 Vrms +-0.05 dB', 'final'),
    'R-08': ('G', '', 'check the default trim register on first boot', 'final'),
    'R-09': ('G', 'at VBUS 4.40 V: LM27762 R_NEG typical only (L-3)', 'power at 32 ohm, VBUS 4.60 and 4.40 V (i-12)', 'final'),
    'R-10': ('G', 'at VBUS 4.40 V: LM27762 R_NEG typical only (L-3)', 'power at 60 ohm balanced, VBUS 4.60 and 4.40 V (i-12)', 'final'),
    'R-11': ('G', '', 'power at 120 ohm balanced', 'final'),
    'R-12': ('G', '', 'power at 300 ohm balanced', 'final'),
    'R-13': ('G', 'thin (+0.97 mA IOS); linear interpolation of the power table', 'Default 32 ohm power at the measured U503 limit (i-4)', 'provisional (E-6)'),
    'R-14': ('E', 'integration estimate: round-2 peaks + round-3 quiescent', 'Default power at 60/120/300 ohm', 'provisional (E-6)'),
    'R-15': ('E', 'TLP3545A RON x1.35 at 60 C and contact resistances assumed', 'output impedance at 25/60 C (O12)', 'final'),
    'R-16': ('G', '', 'frequency response 20 Hz-20 kHz', 'final'),
    'R-17': ('E', 'layout return-path target 2 mOhm (not yet routed)', 'crosstalk 3.5 mm 32 ohm / 4.4 mm 300 ohm', 'provisional (E-13 placement)'),
    'R-18': ('G', '', 'channel balance after trim', 'final'),
    'R-19': ('E', 'DAC pair mismatch 3 % / null 1 mV assumed (ESS publishes none); 0-50 C via 25 C screen is conditional (R9-B4/D3)', '100 % DC screen at 25 C + temperature qualification of the prototype lot (E-4)', 'provisional (E-4)'),
    'R-20': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 2 V DC on each leg -> removal time (i-9)', 'provisional (E-2/E-3)'),
    'R-21': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 1 V DC on each leg -> removal time (i-9)', 'provisional (E-2/E-3)'),
    'R-22': ('G', 'tOFF x2 (L-2); OPA1622 current bound', 'rail-stuck injection test (i-9)', 'provisional (E-3)'),
    'R-23': ('E', '22 % DAC pin mismatch for the CM content; tOFF x2 (L-2)', 'CM-window stuck I/V test (i-9)', 'provisional (E-3: L-11 detector)'),
    'R-24': ('G', 'MCU pin leakage 1 uA [ASSUMP] in the error budget', 'tier boundary tests (i-10)', 'final'),
    'R-25': ('G', '', '-', 'final'),
    'R-26': ('G', 'capacitor ageing -5 % assumed in the aged range', 'FS 20 Hz square / sine at the leg -> no trip', 'provisional (E-3 new detector must not false-trip)'),
    'R-27': ('G', '', 'OD-1 content tests (i-17...i-20)', 'final'),
    'R-28': ('G', 'DAC filter delay <= 1 ms [ASSUMP]; tOFF x2 (L-2)', 'flat digital DC tests (i-19)', 'final'),
    'R-29': ('E', 'TLV3402 delay 3 x typical; 74AUP1G17 thresholds scaled from 3.0 V; Kyocera edge 4.5 ns', 'boot self-test (b)/(c) on every board', 'provisional (E-11 R665 330 ohm, E-3)'),
    'R-30': ('E', 'COFF <= 1 nF (640 pF typ x1.5), 22 % DAC pin mismatch, LP5907 current limit <= 0.75 A - all unpublished', 'pop at 300/600 ohm, 5 boards, 0/50 C (O10)', 'provisional (E-9 power-down order, E-3 taps)'),
    'R-31': ('E', 'hold-up model: reservoir >= 176 uF, PMEG VF tempco, LP5907 reverse behaviour, MCU reset thresholds', 'hot-unplug scope at music level (i-13, M11)', 'provisional (E-8)'),
    'R-32': ('E', 'MCU 80 mA planning value (L-1)', 'S1 current on every board (production test)', 'final'),
    'R-33': ('E', 'MCU/CPLD/DVDD planning values (L-1); 9.2 mA to 500 mA', 'S3 current at the U503 limit on every board', 'provisional (E-6)'),
    'R-34': ('G', '', 'Type-C source classes 0.5/1.5/3 A (i-2)', 'final'),
    'R-35': ('G', '', 'USB-IF attach inrush (M1)', 'final'),
    'R-36': ('E', 'MCU Stop 1.9 mA [PH] (L-1); BAT54 leakage estimate ~12 uA vs 10 uA budget; +3.5 uA margin', 'suspend current vs time, legacy cable (M5)', 'provisional (E-5)'),
    'R-37': ('E', 'RthJA values and +10 C local rise assumed; U202 40 mA', '30 min overload / 50 C ambient IR scan', 'final'),
    'R-38': ('G', 'THIN / DATA-GAP rows listed in the stress table', 'stress items per the bring-up plan', 'provisional (parts: rows for the R9 parts)'),
    'R-39': ('G', '', 'impedance coupon / TDR; placement feasibility', 'provisional (E-13)'),
    'R-40': ('G', 'LED VF tempco -2.2 mV/K and hFE at 0 C assumed', 'LED current per string at 0/25/50 C, 4.30 V (i-8)', 'final'),
    'R-41': ('E', 'tOFF 2 x 25 C max (L-2); permit re-close depends on node-H discharge depth (R9-B1)', 'switch timing at 0/50 C; short trip pulses with RELAY_EN held high', 'provisional (E-2)'),
    'R-42': ('G', 'wording: U303 regulates into R530 for ~90 us after AUD_EN falls (R9-A4)', 'discharge scope (M4)', 'provisional (A4 wording)'),
    'R-43': ('E', 'MCU reset thresholds 1.8/2.3 V, LP5907 reverse behaviour (both variants modelled)', 'hard-unplug scope (M11)', 'final'),
    'R-44': ('E', 'MCU reset thresholds; PA1 leakage 1 uA; brown-out margin ~0.17 V at the 4.40 V corner (R9-A8)', 'brown-out ISR timing at a hard unplug (M11)', 'provisional (E-5 may change the VBUS divider)'),
    'R-45': ('E', 'planning values (L-1)', 'S5 current', 'final'),
    'R-46': ('E', 'LM27762 R_NEG typical only (L-3)', 'R_NEG at VIN 4.2 V / 150 mA (O9, M2)', 'final'),
    'R-47': ('Q', 'maker drawings image-only', 'gates G-1/G-2 (two samples each)', 'final (gate, open until measured)'),
    'R-48': ('G', '', 'check_design.py incl. the E-1 value-decode check', 'provisional (E-1: Parts List Value cells to be corrected by parts)'),
    'R-49': ('G', 'gate timing uses TLV3402 delay 3 x typical', 'boot self-test (d); slow 3V3A ramp threshold test', 'final'),
    'R-50': ('G', '', 'link BER test 1e10 bits', 'final'),
    'R-51': ('G', '', '-', 'final'),
    'R-52': ('E', 'cable model 0.25-1.5 uH / 0.05-0.4 ohm assumed', '5V_SYS hard short with D102 fitted (i-9)', 'final'),
    'R-53': ('E', 'documented limitation L-8', 'unplug scope OUT-IN of U302/U503 (D104/D105)', 'final'),
    'R-54': ('G', '', 'ANA_SENSE trip at 1.279 V / 1587 counts', 'final'),
    'R-55': ('E', 'NOT met as stated: node-H recovery 6.1-34.8 ms after a shallow discharge (R9-B1)', 'short comparator pulses with RELAY_EN held high -> switch stays open', 'provisional (E-2)'),
    'R-56': ('G', 'MCU pin leakage 1 uA; offset 9.23/18.45 mV', 'pre-close check with a known DC', 'provisional (E-4 offset)'),
    'R-57': ('G', '', 'boot self-test on every board', 'provisional (E-2/E-3/E-10 add self-test items)'),
    'R-58': ('G', '', 'rate/family change with the switch open', 'provisional (E-10 GPIO2 = lock only, E-12 CPLD reset)'),
    'R-59': ('E', 'OPA2210 600 ohm swing row at 25 C only; PMEG VF from 25 C max + typical tempco', 'I/V swing at calibrated full scale; fallback R501 232 k', 'provisional (E-8)'),
    'R-60': ('-', 'documented limitations', '-', 'provisional (E-3 may remove L-11)'),
    'R-61': ('E', 'limitation L-11 (undetectable DAC-core hang)', 'none possible (fault not inducible)', 'provisional (E-3: hardware large-DC persistence detector)'),
    'R-62': ('G', '', 'unpowered-MCU injection check at attach', 'final'),
    'R-63': ('E', 'ESS VOL ohmic extrapolation from 100 uA', 'SDA VOL at the DAC with 10 k pull-ups', 'final'),
    'R-64': ('Q', 'limitation L-9', 'leg-to-leg short survival test, 30 min', 'final'),
    'R-65': ('G', 'limitation L-10 (out-of-spec source)', '-', 'final'),
    'R-66': ('E', 'I2S2 slave at 22.6/24.6 MHz BCLK not published', 'bit-exact capture at 352.8/384 kHz (i-15)', 'final'),
    'R-67': ('E', 'MCU boot <= 10 ms assumed', 'D+ pull-up time after VBUS valid', 'final'),
    'R-68': ('E', 'attrition, PCB and shipping prices assumed (report only)', 'JLCPCB quote', 'provisional (R9 parts changes)'),
    'R-69': ('-', 'process', 'bring-up checklist', 'final'),
    'R-70': ('G', '', '-', 'final'),
    'R-71': ('E', 'ESS internal lock-loss latency not published', 'DAC_LOCK self-test; forced lock loss', 'provisional (E-10 GPIO2 = lock only)'),
}
# explicit assumption-based bounds (R9-B3 and the summary) not captured as a single requirement row
EXTRA = [
    ('A-01', 'TLP3545A tON/tOFF over 0-60 C', '10 ms / 1.0 ms design (2 x 25 C maxima)', 'E', 'Toshiba DS 25 C maxima; x2 [ASSUMP] (L-2)', 'yes: temperature curves typical only', 'tON/tOFF at 0/50 C (L-2)', 'final'),
    ('A-02', 'TLP3545A RON at 60 C', '0.081 ohm (60 mOhm x 1.35)', 'E', 'DS 25 C max; x1.35 [ASSUMP]', 'yes', 'RON at 60 C (O12)', 'final'),
    ('A-03', 'TLP3545A COFF bound', '<= 1 nF (640 pF typ x 1.5)', 'E', 'DS typical only', 'yes', 'pop test (O10)', 'final'),
    ('A-04', 'TLV3402 propagation delay', '<= 0.9 ms (3 x typical)', 'E', 'TI DS typical 55-300 us, no maximum', 'yes (R9-B3)', 'boot self-test (d) timing', 'final'),
    ('A-05', 'PMEG2010AEH VF at 10-30 mA, 0-50 C', '<= 0.30 V', 'E', '25 C maxima + typical tempco (parts R3.7)', 'yes (R9-B3)', 'VF at 0/50 C (O13)', 'provisional (E-8)'),
    ('A-06', 'BAT54 leakage at 50 C (D103-D105, D413/D414) in the suspend budget', '10 uA budget vs ~12 uA estimate', 'E', 'maker 25 C data only; estimate exceeds the allowance by ~2 uA against a +3.5 uA S6 margin', 'yes (R9-B3/D2)', 'suspend current at 50 C (M5)', 'provisional (E-5)'),
    ('A-07', 'MCU Stop current', '1.9 mA planning value (0.11 mA typ)', 'E', 'WCH publishes typical only (L-1)', 'yes', 'suspend current on the first board (R9-C3)', 'provisional (E-5)'),
    ('A-08', 'MCU / CPLD / DVDD running currents', '80 / 40 / 60 mA planning values', 'E', 'vendor-unpublished (L-1)', 'yes', 'per-rail currents in every state (production)', 'provisional (E-6)'),
    ('A-09', 'VCCA current at 80 MHz', '2.9 mA', 'E', 'ESS 0.8 mA at 22 MHz scaled [ASSUMP]', 'yes', 'VCCA current (O11)', 'final'),
    ('A-10', 'DAC pin-pair mismatch and null offset', '3 % (offset) / 22 % (CM, pop) / 1 mV', 'E', 'ESS publishes no matching', 'yes (R9-B4/D3)', '25 C screen + temperature qualification (E-4)', 'provisional (E-4)'),
    ('A-11', 'LM27762 R_NEG, UVLO, PGOOD, start-up current', 'R_NEG 2.5 ohm typ; UVLO 2.4/2.6 V typ', 'E', 'TI DS typical only', 'yes', 'R_NEG and start into the Default limit (M2, M9)', 'final'),
    ('A-12', 'LP5907 current limit / reverse behaviour / rise time', '<= 0.75 A assumed; both reverse variants modelled', 'E', 'TI DS 500 mA typ, no minimum rise time', 'yes', '3V3A rise and hot-unplug scope', 'final'),
    ('A-13', 'OPA2210 output swing at the I/V load', '(V+) - 0.6 V at 600 ohm, 25 C only', 'E', 'TI DS 600 ohm row at 25 C', 'yes', 'swing at calibrated full scale, 0/50 C', 'provisional (E-8)'),
    ('A-14', 'X201 duty cycle vs ESS', '45-55 % = the ESS limit', 'Q', 'Kyocera DS vs ESS DS (zero margin)', 'yes (zero margin)', 'duty at XI; fallback R203 0 ohm', 'final'),
    ('A-15', 'MCLK-alive tap margin (74AUP1G17 behind R665)', 'not provable with 4.5 ns edges (R9-A9)', 'E', 'VT+/VT- at 3.0 V scaled; CI/CPD unpublished', 'yes', 'boot self-test (b) on every board', 'provisional (E-11 R665 330 ohm)'),
    ('A-16', 'CH32V307 reset thresholds, PA1 leakage, pin injection', '1.8/2.3 V, 1 uA', 'E', 'WCH DS incomplete', 'yes', 'brown-out ISR vs reset at unplug (M11)', 'final'),
    ('A-17', 'C442/C443 reverse bias during LM27762 start/off (open item 6)', 'clamped by D413/D414 (not yet computed)', 'E', 'calculation pending (R9-A5)', 'yes', 'VPOS/VNEG at start (O15)', 'provisional (E-8)'),
    ('A-18', 'Filter capacitor ageing (C601-C604, C608-C611)', '-5 % ageing term', 'E', 'X5R ageing assumed', 'yes', 'FS 20 Hz square no-trip at 0/50 C', 'final'),
    ('A-19', 'VBUS cable model for the hard-short kick', '0.25-1.5 uH, 0.05-0.4 ohm', 'E', 'assumed cable range', 'yes', 'hard-short test at U102 IN', 'final'),
    ('A-20', 'Thermal model', 'RthJA values, +10 C local rise', 'E', 'assumed board conditions', 'yes', '50 C ambient IR scan', 'final'),
    ('A-21', 'Node-H minimum off-time after any trip', 'NOT guaranteed: 6.1-34.8 ms after a shallow discharge (R9-B1) vs the 53 ms claim', 'E', 'p05 recovery computed from a full discharge only', 'yes (claim open)', 'short trip pulses with RELAY_EN held high', 'provisional (E-2)'),
    ('A-22', 'Brown-out threshold margin at the VBUS 4.40 V corner', '~0.17 V effective (R9-A8)', 'G', 'power c09 band 3.756-4.244 V vs 5V_SYS min 4.311 V', 'thin', 'VBUS_SENSE trip at 4.40 V', 'provisional (thin-margin table, E-14)'),
    ('A-23', 'Hardware-window 20 Hz false-trip margin (aged corner)', '6.2 %', 'G', 'protection p11 (ageing -5 % assumed)', 'thin', 'FS 20 Hz square at the leg', 'provisional (thin-margin table, E-14; E-3)'),
    ('A-24', 'Default USB total vs 500 mA', '490.80 mA (9.2 mA)', 'E', 'power c17 with L-1 planning values', 'yes (L-1)', 'S3 current on every board', 'provisional (E-6)'),
    ('A-25', 'ESS lock-loss latency (OD-2 interrupt)', 'not published', 'E', 'ESS DS silent', 'yes', 'forced lock loss (i-22)', 'provisional (E-10)'),
    ('A-26', 'I2S2 slave capture at 22.6/24.6 MHz', 'not published', 'E', 'WCH text silent (digital R3.6)', 'yes', 'bit-exact capture at 352.8/384 kHz (i-15)', 'final'),
]

def norm_flag(cls, note, basis=''):
    """'yes: ...' = the guarantee rests on the named assumption (class E, or Q pending measurement);
    'thin: ...' / 'minor: ...' = G rows with a small or covered assumption; 'no' = none."""
    note = (note or '').strip()
    if cls in ('E', 'Q'):
        return 'yes: ' + (note or basis or 'see evidence')
    if cls == '-':
        return 'n/a' + (f': {note}' if note else '')
    if not note:
        return 'no'
    if note.startswith('thin'):
        return note
    if note.startswith('minor: '):
        note = note[7:]
    return 'minor: ' + note + ' (worst-case margin covers it)'


# ---- R9 final (streams reported 25 Sep 2026 ~18:00): overrides for the rows touched by E-1...E-21
R9 = {
    'R-05': ('E', 'typical-only DAC/op-amp THD data; E-3 taps confirmed without effect (analog R9)', 'THD+N 1 kHz 0 dBFS 300 ohm, LEG vs JACK', 'final (R9)'),
    'R-13': ('G', '', 'Default 32 ohm power at the measured U503 limit (i-4)', 'final (R9 E-18: R509 4.75 k; IOS min 180.05 mA vs need 178.82 mA, G +1.23 mA)'),
    'R-14': ('G', '', 'Default power at 60/120/300 ohm', 'final (R9: need 178.82 mA G covers every Default target)'),
    'R-17': ('E', 'layout return-path target 2 mOhm (routing pending)', 'crosstalk 3.5 mm 32 ohm / 4.4 mm 300 ohm', 'final (R9: placement 100 x 80 mm)'),
    'R-19': ('G', 'DAC matching/drift not published: those terms are Q per board', 'per-board offset test at 0-5 / 25 / 50 C (E-4 procedure, all 5 boards)', 'final (R9 E-4: G 5.61 / 11.21 mV; E 7.73 / 15.47 mV)'),
    'R-20': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 2 V DC on each leg -> removal time (i-9)', 'final (R9)'),
    'R-21': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 1 V DC on each leg -> removal time (i-9)', 'final (R9)'),
    'R-22': ('G', 'tOFF x2 (L-2)', 'rail-stuck injection test (i-9)', 'final (R9)'),
    'R-23': ('E', 'E-3 timer leakage <= 1 uA per node (NPN ICBO hot, C_T, PCB) assumed for the 32 ohm worst case; 22 % DAC pin mismatch for the CM content; tOFF x2 (L-2)', 'E-3 DC injection tests (1.70 V no trip; 2.10 V trip 19.5-23.2 ms + <= 2 ms); timer T_P at 50 C', 'final (R9 check E-22/E-24: 27.5 / 14.5 mJ worst)'),
    'R-26': ('G', 'capacitor ageing -5 % assumed; E-3 T_P from C_T +-2 % PPS film (leakage only slows the timer)', 'FS 20 Hz sine 60 s no trip; FS square 21.0 Hz trips, 26 Hz no trip', 'final (R9 check: sine 5.8 %, squares <= 21.5 / 25.6 Hz)'),
    'R-29': ('G', 'TLV3402 delay 3 x typical (3V3A path only)', 'boot self-test (b)/(c); MCLK-alive with R665 330 ohm', 'final (R9 E-11)'),
    'R-30': ('E', 'COFF <= 1 nF, 22 % DAC pin mismatch, LP5907 current limit - unpublished; E-9 order and E-3 taps checked (<= 1.09 mV)', 'pop at 300/600 ohm, 5 boards, 0/50 C (O10)', 'final (R9)'),
    'R-31': ('E', 'hold-up model assumptions (reservoir >= 176 uF, PMEG tempco, MCU reset thresholds)', 'hot-unplug scope at music level (i-13, M11)', 'final (R9 E-8 closed; c14 re-run)'),
    'R-33': ('E', 'MCU/CPLD/DVDD planning values (L-1); S3 493.45 mA', 'production test per board: S3 <= 480 mA, S1 <= 90 mA (E-17); fallback firmware ceiling (E-21)', 'final (R9 E-17/E-18/E-21)'),
    'R-36': ('E', 'MCU Stop 1.9 mA planning value (L-1); Q507 hot leakage estimated (EN >= 3.18 V at VBUS 4.40 V, 50 C)', 'suspend current on the first board (R9-C3), then every board', 'final (R9 E-16: S6 +224 uA; suspend level <= 8.75 ms)'),
    'R-38': ('G', 'THIN / DATA-GAP rows listed in the stress table (165 current rows, FAIL 0)', 'stress items per the bring-up plan', 'final (R9 stress run)'),
    'R-39': ('G', '', 'impedance coupon / TDR; placement at 100 x 80 mm', 'final (R9 E-19)'),
    'R-41': ('G', 'tOFF 2 x 25 C max (L-2)', 'switch timing at 0/50 C; short trip pulses with RELAY_EN held high', 'final (R9 E-2)'),
    'R-42': ('G', '', 'discharge scope (M4)', 'final (R9 A4 wording)'),
    'R-44': ('E', 'PA1 leakage 1 uA dominates the band; PVD threshold >= 2.9 V assumed (L-12)', 'brown-out ISR timing at a hard unplug and at a slow sag (M11)', 'final (R9)'),
    'R-48': ('G', '', 'check_design.py incl. the value-from-MPN check (116 lines, 0 mismatches)', 'final (R9 E-1)'),
    'R-55': ('G', '', 'short comparator pulses with RELAY_EN held high -> switch stays open, PB0 low', 'final (R9 E-2)'),
    'R-56': ('G', 'MCU pin leakage 1 uA; offset 7.73 / 15.47 mV with DAC terms', 'pre-close check with a known DC', 'final (R9)'),
    'R-57': ('G', '', 'boot self-test on every board (2.84 s; PB0 low after each self-test trip)', 'final (R9)'),
    'R-58': ('G', '', 'rate/family change with the switch open (<= 972 ms)', 'final (R9 E-10/E-12)'),
    'R-59': ('E', 'OPA2210 600 ohm swing row at 25 C only; PMEG VF from 25 C max + typical tempco', 'I/V swing at calibrated full scale; fallback R501 232 k', 'final (R9 E-8)'),
    'R-60': ('-', 'documented limitations', '-', 'final (R9: L-11 closed; L-12, L-13 added)'),
    'R-61': ('E', 'E-3 timer leakage <= 1 uA per node assumed (NPN ICBO, C_T, PCB)', 'E-3 DC injection tests; frozen-code tests; timer T_P at 50 C', 'final (R9 check E-22/E-24: L-11 closed, 27.5 / 14.5 mJ)'),
    'R-68': ('E', 'attrition, PCB (100 x 80 mm, same price tier) and shipping prices assumed (report only)', 'JLCPCB quote', 'final (R9 cost)'),
    'R-71': ('E', 'ESS internal lock-loss latency not published', 'DAC_LOCK self-test; forced lock loss', 'final (R9 E-10)'),
    'R-72': ('G', 'latent single fault: Q622 D-S short (covered by the production test)', 'comparator-path trips >= 1 ms with RELAY_EN held high; production test: latch cleared + RELAY_EN high -> every photorelay open, LED current < 10 uA', 'final (R9 check E-23/E-26)'),
    'R-73': ('E', 'USB <= 500 mA rests on the planning values (L-1)', 'production test S3 <= 480 mA, S1 <= 90 mA; firmware ceiling fallback', 'final (R9 E-17/E-18/E-21)'),
}
C.update(R9)
C['R-74'] = ('new (R10)', '', 'DC injection just above and below the floor at bring-up; the p21 history states on the first boards', 'final (R10)')
EXTRA_R9 = {
    'A-05': ('A-05', 'PMEG2010AEH VF at 10-30 mA, 0-50 C', '<= 0.30 V', 'E', '25 C maxima + typical tempco (parts R3.7)', 'yes (R9-B3)', 'VF at 0/50 C (O13)', 'final (R9)'),
    'A-06': ('A-06', 'BAT54 leakage in the suspend budget', 'D103 deleted, D104/D105 unbiased in Stop (E-16) -> 0 in the S6 budget', 'G', 'power c22 (TPS70933 on VBUS, U102 off in Stop)', '', 'suspend current (first board)', 'final (R9 E-16: resolved)'),
    'A-07': ('A-07', 'MCU Stop current', '1.9 mA planning value (0.11 mA typ); S6 margin +224 uA', 'E', 'WCH publishes typical only (L-1)', 'yes', 'suspend current on the first board (R9-C3)', 'final (R9 E-16)'),
    'A-08': ('A-08', 'MCU / CPLD / DVDD running currents', '80 / 40 / 60 mA planning values', 'E', 'vendor-unpublished (L-1)', 'yes', 'production test S3 <= 480 mA, S1 <= 90 mA (E-17)', 'final (R9 E-17)'),
    'A-10': ('A-10', 'DAC pin-pair mismatch and null offset', '3 % (offset) / 22 % (CM, pop) / 1 mV', 'Q', 'ESS publishes no matching (E-4 split)', 'yes (R9-B4/D3)', 'per-board offset test at 0-5 / 25 / 50 C', 'final (R9 E-4)'),
    'A-13': ('A-13', 'OPA2210 output swing at the I/V load', '(V+) - 0.6 V at 600 ohm, 25 C only', 'E', 'TI DS 600 ohm row at 25 C', 'yes', 'swing at calibrated full scale, 0/50 C', 'final (R9)'),
    'A-15': ('A-15', 'MCLK-alive tap margin (74AUP1G17 behind R665 330 ohm)', '+141 mV to VT+max at 2.4 pF (Kyocera 4.5 ns edge)', 'G', 'protection p19 E-11 (VT at 3.0 V scaled)', 'minor: VT+/VT- scaled from 3.0 V', 'boot self-test (b)', 'final (R9 E-11)'),
    'A-17': ('A-17', 'C442/C443 reverse bias (open item 6)', '<= 0.469 V at 0 C (limit 1.00 V); 0.386 V at 50 C (limit 0.71 V)', 'E', 'power/analog E-8: BAT54 maxima, -1 mV/K and the MnO2 reverse-limit rule assumed', 'yes', 'VPOS/VNEG at start (O15)', 'final (R9 E-8: closed)'),
    'A-21': ('A-21', 'Minimum off-time after any trip', 'independent of the node-H discharge depth (E-2 re-arm latch)', 'G', 'protection p18/p19', '', 'short-trip test with RELAY_EN held high', 'final (R9 E-2: resolved)'),
    'A-22': ('A-22', 'Brown-out threshold margin at the VBUS 4.40 V corner', '+67...+114 mV (band 3.704-4.236 V, final loads, TPS70933 range, U502 current no longer through U102; power c21 R10)', 'E', 'PA1 leakage 1 uA [ASSUMP] dominates the band', 'yes', 'VBUS_SENSE trip at 4.40 V', 'final (R9: thin margin, L-12 PVD backup)'),
    'A-23': ('A-23', 'Hardware-window 20 Hz false-trip margin (aged corner)', '6.2 % (E-3 detector: 5.8 %)', 'G', 'protection p11/p18 (ageing -5 % assumed)', 'thin', 'FS 20 Hz square/sine at the leg', 'final (R9 check)'),
    'A-24': ('A-24', 'Default USB total vs 500 mA', '493.46 mA (+6.54 mA) on the planning values; 497.96 mA (+2.04 mA) with the NDK X201 second source (E-27; power F-1 final)', 'E', 'power c17/c21 with L-1 planning values', 'yes (L-1)', 'production test S3 <= 480 mA per board', 'final (R9 E-17/E-27)'),
    'A-25': ('A-25', 'ESS lock-loss latency (OD-2 interrupt)', 'not published', 'E', 'ESS DS silent', 'yes', 'forced lock loss (i-22)', 'final (R9 E-10)'),
}
EXTRA = [EXTRA_R9.get(e[0], e) for e in EXTRA] + [
    ('A-27', 'TPS70933 3V3M range (E-16)', '3.207-3.343 V (1 % + line + load) [DS]; dropout <= 650 mV at 50 mA', 'G', 'TI TPS709 DS; power c22', '', '3V3M at 5V_SYS/VBUS corners', 'final (R9)'),
    ('A-28', 'Q507 MMBT3904 off-state leakage at 50 C (U102 EN held high while running)', '<= 0.57 uA hot (from the 25 C maxima ICEX 50 nA / ICBO 100 nA) -> EN >= 3.18 V at VBUS 4.40 V and 50 C (+1.28 V to the 1.9 V threshold)', 'E', 'JSCJ MMBT3904 25 C maxima; hot leakage estimated [ASSUMP] (parts stress row, power c22)', 'yes', 'U102 EN level at 50 C', 'final (R9 check)'),
    ('A-29', 'ECH-U1H224GX9 reflow (C631-C634, 2416, L-13)', 'ECHU series rating 260 C max, <= 95 s above 220 C (not yet confirmed for the 2416 size) vs JLCPCB 45-90 s above melting', 'Q', 'Panasonic ECHU series data vs JLCPCB profile', 'yes (confirmation for the 2416 size)', 'JLCPCB profile confirmation for the 2416 size (order remark), else owner-fit (1.5 mm iron clearance kept)', 'final (R9 check)'),
    ('A-30', 'X201 load with the MCLK-alive tap (E-11)', '<= 14.2 pF vs 15 pF (layout rule XI <= 10 mm, R665 at the XI pin)', 'G', 'digital/protection R9 (XI 10 pF ESS max, tap 2.4 pF bound)', 'thin', 'MCLK edges/duty at XI', 'final (R9)'),
    ('A-31', 'E-3 detector content boundary', 'sines >= 20 Hz never trip (5.8 %); squares mute <= 21.5 Hz, may up to 25.6 Hz', 'G', 'protection p18 R9 check (C_T 220 nF +-2 %, R_T 110 k, divider 0.1 %)', 'minor: T_P 19.5-23.2 ms includes the <= 1 uA leakage bound (A-33, E)', 'E-3 sine/square tests', 'final (R9 check E-24)'),
    ('A-33', 'E-3 timer node leakage bound (per node)', '<= 1 uA total (NPN ICBO at temperature, C_T insulation, PCB surface)', 'E', 'protection R9 check design basis (no hot maxima published for all terms)', 'yes (R9-CHK-03)', 'timer T_P and trip at 50 C on the first boards', 'final (R9 check E-24)'),
    ('A-34', 'E-2 latent single fault (Q622 drain-source short)', 'bypasses the latch; H path and Q616 still act', 'Q', 'protection R9 check E-23', 'yes (not detectable at boot)', 'production test: latch cleared + RELAY_EN high -> every photorelay open, LED current < 10 uA', 'final (R9 check E-23)'),
    ('A-32', 'PVD brown-out backup threshold on 3V3M (L-12)', '>= 2.9 V highest PVD level', 'E', 'WCH PVD level tolerance not published [ASSUMP]', 'yes', 'slow VBUS sag test', 'final (R9)'),
]

# ======================================================================================================================
# R10 F-2 (decisions_r10.md): evidence classes propagate through dependent calculations.
#   Every row records its inputs; the class follows from them (derive() below), it is never typed in by hand.
#   Input kinds:  DS     datasheet limit (min / max)                                              -> G
#                 CON    construction fact: netlist/BOM value with its datasheet tolerance, exact
#                        arithmetic, logic by construction, a design parameter (e.g. a test limit)  -> G
#                 R-xx / A-xx   another register row                                             -> that row's class
#                 ASSUMP assumption, planning value, estimate, assumed bound or scaling            -> E
#                 TYP    typical value (no published limit)                                      -> E
#                 MODEL  reconstructed or typical-curve model                                    -> E
#                 MEAS   the claim rests on a measurement (production / first-board / gate test
#                        named as the acceptance evidence, zero-margin item)                     -> Q
#                 PROC   process / documentation, no technical claim                             -> '-' (ignored if
#                        the row has technical inputs)
#                 SCOPE  precondition, not an input (e.g. 'calibrated unit'): no class effect; allowed only with a stated
#                        margin that shows no measured value is relied on (otherwise reference the Q row instead)
#   A row is G only if every input is G; any E input makes it E; any Q input makes it Q (Q > E > G).
#   A planned confirmation test of a G or E row is not an input: it stays in qualification_test and changes nothing.
#   Q rows are open qualification obligations: open until the measurement record exists. No board exists yet, so
#   none has passed.
# ======================================================================================================================
import re, sys
from collections import Counter

OWNER = {}
for _s, _ids in {
        'power': 'R-13 R-14 R-32 R-33 R-34 R-35 R-36 R-37 R-42 R-43 R-44 R-45 R-46 R-51 R-52 R-53 R-54 R-65 R-67 R-73 '
                 'A-06 A-07 A-08 A-11 A-12 A-17 A-19 A-20 A-22 A-24 A-27 A-28 A-32 A-41 A-42',
        'analog': 'R-05 R-06 R-07 R-08 R-09 R-10 R-11 R-12 R-15 R-16 R-17 R-18 R-19 R-30 R-31 R-59 R-64 '
                  'A-02 A-03 A-05 A-09 A-10 A-13 A-35 A-36 A-37 A-38',
        'protection': 'R-20 R-21 R-22 R-23 R-24 R-25 R-26 R-27 R-28 R-29 R-40 R-41 R-49 R-55 R-56 R-57 R-61 R-62 R-72 R-74 '
                      'A-01 A-04 A-15 A-18 A-21 A-23 A-30 A-31 A-33 A-34 A-39 A-43 A-44 A-45 A-46',
        'digital': 'R-01 R-02 R-03 R-04 R-50 R-58 R-63 R-66 R-71 A-14 A-16 A-25 A-26 A-40',
        'parts': 'R-38 R-39 R-47 R-69 R-70 A-29',
        'integration': 'R-48 R-60 R-68'}.items():
    for _i in _ids.split():
        OWNER[_i] = _s

# ---- integration walk (R10, 26 Sep 2026): inputs of every row as recorded in the register, the traceability row and the
#      stream sources; superseded by a stream list where one is applied (STREAM_R10 below).
INPUTS = {
    'R-01': ['CON: exact integer divider ratios FAM_CLK -> BCLK/LRCLK for all 8 rates (digital clock_timing 1, Fraction arithmetic)',
             'DS: X202/X203 49.152 / 45.1584 MHz family oscillators'],
    'R-02': ['CON: async feedback from the LRCLK counter; feedback-table assertions; FIFO 512 frames (digital usb_feedback)',
             'ASSUMP: host UAC2 driver behaviour (not provable by calculation)',
             'MEAS: enumeration + playback on Windows/macOS/Linux/Android is the acceptance evidence'],
    'R-03': ['DS: ESS tDS >= 4.1 ns / tDH >= 2 ns; CPLD output-delay maxima', 'CON: 33 ohm series, <= 25 mm matched routing rule',
             'ASSUMP: board skew 2.22 ns (layout not routed yet)'],
    'R-04': ['DS: ESS MCLK >= 192 x FSR, period / high / low limits', 'A-14: X201 duty 45-55 % = the ESS limit (zero margin)'],
    'R-05': ['TYP: ES9018K2M / OPA2210 / OPA1622 THD+N typical only', 'CON: switch distortion bound <= -164 dB (analog r2_switch)'],
    'R-06': ['TYP: ESS DR 127 dB(A) typical; op-amp noise densities typical'],
    'R-07': ['DS: Rf 0.1 % + TCR, 3V3A +-2 %, ESS Rs 806 ohm +-11 % (DS note)', 'CON: master trim -2.90...-0.56 dB, per-channel trim +-0.05 dB',
             'TYP: ESS output model 0.924 x AVCC p-p ([DS-typ] in analog_budget) sets the untrimmed range 1.653-2.165 Vrms',
             'MEAS: the calibrated level exists only through the per-board calibration record (production calibration; F-5)'],
    'R-08': ['TYP: ESS output model 0.924 x AVCC p-p ([DS-typ]) -> uncalibrated 0.985-1.290 Vrms per leg',
             'CON: pre-calibration default -4.5 dB (trim word 0x4C3EA838)'],
    'R-09': ['DS: High IOS min 395.4 mA (R510 3.74 k with R509 4.75 k) vs peak need 320.1 mA; OPA1622 swing/current maxima',
             'A-11: rails 3.789 / -3.661 V hold only while the LM27762 regulates: R_NEG typical only (L-3; 4.40 V corner measured)'],
    'R-10': ['DS: High IOS min 395.4 mA vs the 60 ohm balanced need; OPA1622 swing/current maxima',
             'A-11: LM27762 regulation headroom rests on the typical R_NEG (L-3; 4.40 V corner measured)'],
    'R-11': ['DS: OPA1622 swing/current maxima; rails in regulation (analog r2_power)'],
    'R-12': ['DS: |V-| min 3.661 V >= 3.625 V needed (analog r2_power R2.3)'],
    'R-13': ['DS: U503 Default IOS min 180.05 mA (R509 4.75 k 0.1 %)', 'A-35: Default 5V_ANA need 178.82 mA'],
    'R-14': ['DS: U503 Default IOS min 180.05 mA', 'A-35: Default need 178.82 mA (set by the 32 ohm target; 60/120/300 ohm need less)'],
    'R-15': ['DS: TLP3545A RON 60 mOhm max at 25 C', 'A-02: RON x1.35 at 60 C', 'ASSUMP: J701/J702 contact resistance 50 mOhm per contact and 0 ohm links 50 mOhm each; the maker drawings give no contact-resistance maximum, so the owner kept this assumption (27 Sep 2026); these terms stay E until the bring-up output-impedance measurement'],
    'R-16': ['CON: I/V pole 278 kHz, T pole 198 kHz, lead pole 8 MHz from the R/C values and tolerances (analog section 12)'],
    'R-17': ['ASSUMP: layout return-path target 2 mOhm (routing pending)', 'CON: balanced <= 0.3 pF rule; switch-to-switch -166 dB'],
    'R-18': ['DS: Rf 0.1 % pair; TLP3545A RON mismatch <= 0.081 ohm', 'CON: per-channel trim +-0.05 dB',
             'MEAS: untrimmed L/R balance is not specified by ESS; the balance exists only through the per-board calibration record'],
    'R-19': ['DS: resistor tolerance + TCR, OPA1622/OPA2210 offset maxima, 3V3A tolerance -> 5.61 / 11.21 mV',
             'A-10: DAC pair mismatch 3 % / null 1 mV assumed (ESS publishes none) -> 7.73 / 15.47 mV; closed only by the per-board test'],
    'R-20': ['DS: TLV1704 thresholds and VOS, 0.1 % dividers, filter R/C tolerances (protection p03/p11)', 'A-01: switch tOFF 1.0 ms design',
             'ASSUMP: fault starts with the leg filters at rest (zero-state sweep; R10-A1 history, F-1 re-analysis pending)'],
    'R-21': ['DS: TLV1704 thresholds and VOS, 0.1 % dividers, filter R/C tolerances (protection p03/p11)', 'A-01: switch tOFF 1.0 ms design',
             'ASSUMP: fault starts with the leg filters at rest (zero-state sweep; R10-A1 history, F-1 re-analysis pending)'],
    'R-22': ['DS: TLV1704 thresholds, 0.1 % dividers (protection p03)', 'A-01: switch tOFF 1.0 ms design',
             'ASSUMP: zero filter history and no partner-leg content (R10 facts 2/3; F-1 pending); pcommon rail bound 4.014 V (R10-A3)'],
    'R-23': ['A-33: E-3 timer leakage <= 1 uA per node (32 ohm worst case)', 'ASSUMP: 22 % DAC pin mismatch for the CM content (ESS publishes none)',
             'R-07: CM content at the calibrated level 2.228 V per leg (analog propagation note)',
             'A-01: switch tOFF 1.0 ms design',
             'ASSUMP: zero filter history (R10-A1 counterexample 31.2-32.4 mJ > 30 mJ; F-1 pending)'],
    'R-24': ['DS: ADC2 and divider limits (protection p06/p09/p10)', 'A-16: MCU pin leakage 1 uA in the error budget',
             'ASSUMP: history robustness of the DC-sense filters not yet shown (F-1 c)'],
    'R-25': ['R-24: tier thresholds 0.176 / 0.192 V worst case', 'CON: 0.192 V^2 / 16 ohm = 2.31 mW'],
    'R-26': ['A-18: filter capacitor ageing -5 %', 'A-31: E-3 content boundary (T_P incl. the leakage bound)',
             'DS: C_T +-2 % PPS film, 0.1 % dividers',
             'R-07: FS sine at the calibrated level 2.228 V per leg; with the G-bounded 3V3A drift 18.67 ms vs T_P min 19.5 ms (analog)',
             'A-40: firmware gain ceiling (F-5)'],
    'R-27': ['CON: OD-1 rules P1-P4, digital thresholds and counts (exact arithmetic, protection p15/p16)'],
    'R-28': ['CON: OD-1 guard removal <= 23.6 ms', 'ASSUMP: DAC filter delay <= 1 ms', 'A-01: switch tOFF 1.0 ms design'],
    'R-29': ['A-04: TLV3402 delay 3 x typical (3V3A path)', 'A-15: MCLK-alive tap margin', 'R-61: frozen DC removed <= 25.2 ms by E-3'],
    'R-30': ['A-03: COFF <= 1 nF (640 pF typ x1.5)', 'ASSUMP: 22 % DAC pin mismatch (ESS publishes none)',
             'A-12: LP5907 current limit (unpublished)'],
    'R-31': ['MODEL: hold-up model (analog unplug_model_r3, power c14: reservoir >= 176 uF)', 'A-05: PMEG VF 0-50 C',
             'A-12: LP5907 reverse behaviour', 'A-16: MCU reset thresholds'],
    'R-32': ['A-08: MCU 80 mA planning value (L-1)', 'MEAS: S1 <= 90 mA production test on every board (E-17) is the acceptance evidence'],
    'R-33': ['A-24: S3 493.45 mA on the planning values (L-1)', 'DS: U503 Default IOS max 222.6 mA',
             'MEAS: S3 <= 480 mA production test on every board (E-17) is the acceptance evidence'],
    'R-34': ['CON: CC ADC thresholds 0.20 / 0.66 / 1.23 V (divider tolerances)', 'DS: U102 IOS min 870 mA (R108 100 k)',
             'A-08: S4 760.76 mA rests on the MCU/CPLD/DVDD planning values (L-1)'],
    'R-35': ['DS: C102 2.2 uF tolerance, U102 soft start, TPS70933 current limit (power c22)', 'CON: USB-IF CU #45 region method',
             'ASSUMP: U502 start <= 1 ms in the region timing (power c22)'],
    'R-36': ['A-07: MCU Stop 1.9 mA planning value (L-1)', 'A-28: Q507 hot leakage estimate',
             'CON: firmware suspend sequence <= 8.75 ms (digital firmware_sequences 19)'],
    'R-37': ['A-20: thermal model (RthJA values, +10 C local rise)', 'ASSUMP: U202 40 mA'],
    'R-38': ['DS: part ratings (parts stress_table.csv R10f: 312 rows / 178 current, OK 145, AVAIL 14, FAIL 0; every F-1 part covered, onsemi Q623-Q627 rows OK)',
             'ASSUMP: DATA-GAP (4) and THIN (15) rows rest on missing or assumed data; the E-3 reset level is E via A-46',
             'TYP: analog stress rows with TYP inputs (OPA2210 ISC 65 mA typ, FB301/FB302 VCCA current; analog)'],
    'R-39': ['DS: JLCPCB JLC04161H-7628 stack-up', 'MODEL: field-solver Zdiff 90.0 ohm on the nominal stack-up (parts usb_diffpair_impedance)',
             'ASSUMP: placement fill ~60 % (59.6 %) at 100 x 80 mm is an estimate (parts placement_density R10: Z4 52 %, Z7 59.0 %)'],
    'R-40': ['A-27: 3V3M minimum 3.207 V -> RELAY_EN >= 2.81 V', 'DS: R641/R642 24.9 ohm 0.1 %',
             'ASSUMP: LED VF tempco -2.2 mV/K and hFE at 0 C'],
    'R-41': ['A-01: switch tOFF 1.0 ms design', 'CON: re-close only after a fresh RELAY_EN edge with H recovered (latch logic)'],
    'R-42': ['DS: U303 accuracy -> 1V3 1.2716-1.3248 V', 'CON: U303 EN tied to 3V3D; U605B gates AUD_EN on 3V3A good',
             'A-12: DVDD - DVCC <= +5 mV in the unplug corners of the power c14 model (LP5907 reverse behaviour, both variants)'],
    'R-43': ['A-16: MCU reset thresholds 1.8/2.3 V', 'A-12: LP5907 reverse behaviour (both variants modelled)'],
    'R-44': ['A-16: PA1 leakage 1 uA dominates the band', 'A-32: PVD threshold >= 2.9 V (L-12)', 'A-22: brown-out margin at the 4.40 V corner'],
    'R-45': ['A-08: planning values (L-1)', 'ASSUMP: DAC in reset 88.38 mA (analog E value, F-1)'],
    'R-46': ['A-11: LM27762 R_NEG typical only (L-3)'],
    'R-47': ['MEAS: connector pin maps (maker drawings image-only): gates G-1/G-2, two samples each'],
    'R-48': ['CON: check_design.py + build_package.py cross-check (exact), value-from-MPN decode of every fitted line'],
    'R-49': ['A-27: TPS70933 3V3M range', 'DS: TLV3402 thresholds and hysteresis', 'A-04: TLV3402 delay 3 x typical (gate timing)'],
    'R-50': ['DS: SN74LVC3G34 Ioff <= +-2 uA; MCU SPI and U208 delay limits', 'ASSUMP: skew bound 2.7 ns (layout not routed yet)',
             'ASSUMP: R305 part: Q207 / RESETB leakage assumed (released >= 3.151 V vs VIH 2.03 V, 1.1 V margin; analog)'],
    'R-51': ['CON: EN+/EN- tied to VIN (5V_ANA_F) by construction; RAIL_EN, R506, R507 deleted'],
    'R-52': ['A-19: cable model 0.25-1.5 uH / 0.05-0.4 ohm', 'DS: D102 SMDJ12A clamp; C102 2.2 uF (1.1-2.42 uF effective)'],
    'R-53': ['DS: BAT54 VF maxima (D104/D105 OUT->IN)', 'A-12: input-collapse corners of the power c14 model', 'PROC: limitation L-8 (target 0.3 V not met)'],
    'R-54': ['DS: R535/R536 100 k / 47 k tolerances; ADC accuracy', 'CON: fault < 4.0 V = 1.279 V (1587 counts)'],
    'R-55': ['CON: E-2 latch logic: RELAY_EN static high can never re-arm; clear dominates', 'DS: U606 ch4 HREF 2.88-3.11 V (VPOS x 330/430)'],
    'R-56': ['A-16: MCU pin leakage 1 uA', 'DS: ADC and divider error budget (protection R3.17)',
             'ASSUMP: offset estimate 7.73 / 15.47 mV with the assumed DAC terms -> a healthy board reads <= 64.0 / 77.2 mV (analog)',
             'CON: per-board offset acceptance limit (design parameter) -> margins 4.2 / 9.2 mV'],
    'R-57': ['CON: boot self-test windows derived from the detector timings; R10 F-1: a\' deleted, (f) LPW +-0.30 FS pass 45-100 ms, (g) OR with PC15 high +-0.25 FS pass 18-32 ms (digital F-1a..c; protection list pending)',
             'ASSUMP: new window timings rest on protection\'s F-1 detector estimates (to be confirmed by the protection list)',
             'A-33: E-3 timer leakage (window e)', 'A-04: TLV3402 delay 3 x typical (window d)'],
    'R-58': ['CON: firmware lists D/E timings and ENGINE_RST (digital firmware_sequences 4/17)'],
    'R-59': ['A-13: OPA2210 600 ohm swing row at 25 C only', 'A-05: PMEG VF from the 25 C max + typical tempco'],
    'R-60': ['PROC: documented limitations L-1...L-13'],
    'R-61': ['A-33: E-3 timer leakage <= 1 uA per node', 'ASSUMP: zero filter history (R10-A1; F-1 pending)'],
    'R-62': ['DS: CH32V307 IINJ(PIN) +-5 mA, sum +-25 mA [DS Tab 4-1]', 'CON: R242-R246 330 ohm 1 %'],
    'R-63': ['ASSUMP: ESS VOL ohmic extrapolation from 100 uA'],
    'R-64': ['MEAS: leg-to-leg short survival test, 30 min (L-9; outside the one-amplifier continuous-short rating)'],
    'R-65': ['DS: U102 clamp 5.25-5.55 V; LP5907/LM27762 ROC and abs max; USBLC6 VRM', 'PROC: limitation L-10 (out-of-spec source)'],
    'R-66': ['A-26: I2S2 slave capture at 22.6/24.6 MHz BCLK', 'ASSUMP: 15 CPU cycles per frame (CPU <= 13.3 %)'],
    'R-67': ['ASSUMP: MCU boot <= 10 ms', 'DS: R109 470 k + C104 EN delay'],
    'R-68': ['ASSUMP: attrition, PCB and shipping prices; stock and prices of the day (web-page copies of 26 Sep 2026, to be re-checked in the JLCPCB BOM tool); no supplier order or JLCPCB quote yet: an estimate until they exist'],
    'R-69': ['PROC: owner-fitting order (parts layout_package 13a)'],
    'R-70': ['DS: JLCPCB process limits (Economic vs Standard) and part data', 'CON: Standard PCBA kept'],
    'R-71': ['A-25: ESS lock-loss latency not published', 'CON: OD-2 check timings (10 ms status poll)'],
    'R-72': ['CON: E-2 latch logic (clear dominates; power-up cleared; re-arm only by a fresh RELAY_EN edge after H > HREF)',
             'DS: 74LVC1G74 and U606 thresholds',
             'ASSUMP: clear-path and switch timing are timing estimates, not a transistor-level transient of every failure (R10-A4)'],
    'R-73': ['A-35: Default need 178.82 mA vs IOS min 180.05 mA', 'A-24: USB <= 500 mA on the planning values',
             'MEAS: S3 <= 480 mA / S1 <= 90 mA production test on every board (E-17)'],
    'A-01': ['DS: TLP3545A tON/tOFF maxima at 25 C', 'TYP: temperature curves typical only', 'ASSUMP: x2 design factor (L-2)'],
    'A-02': ['DS: TLP3545A RON 60 mOhm max at 25 C', 'ASSUMP: x1.35 at 60 C'],
    'A-03': ['TYP: TLP3545A COFF 640 pF', 'ASSUMP: x1.5 bound'],
    'A-04': ['TYP: TLV3402 delay 55-300 us, no maximum published', 'ASSUMP: x3 bound'],
    'A-05': ['DS: PMEG2010AEH VF maxima at 25 C', 'TYP: VF tempco'],
    'A-06': ['CON: D103 deleted; D104/D105 unbiased in Stop (U102 off) -> 0 in the S6 budget (power c22)'],
    'A-07': ['TYP: WCH Stop current 0.11 mA typical only', 'ASSUMP: 1.9 mA planning value (L-1)'],
    'A-08': ['ASSUMP: 80 / 40 / 60 mA planning values (vendor-unpublished, L-1)'],
    'A-09': ['TYP: ESS 0.8 mA at 22 MHz', 'ASSUMP: scaled to 80 MHz'],
    'A-10': ['ASSUMP: DAC pair offset mismatch 3 % and null 1 mV (ESS publishes no matching)',
             'MEAS: per-board offset test at 0-5 / 25 / 50 C (E-4 procedure, all 5 boards) replaces the assumption'],
    'A-11': ['TYP: LM27762 R_NEG 2.5 ohm, UVLO 2.4/2.6 V, PGOOD and start-up current typical only'],
    'A-12': ['TYP: LP5907 current limit 500 mA typical; no minimum rise time', 'ASSUMP: <= 0.75 A; both reverse variants modelled'],
    'A-13': ['DS: OPA2210 600 ohm swing row at 25 C', 'ASSUMP: the 25 C row applies over 0-50 C'],
    'A-14': ['DS: X201 duty 45-55 % vs ESS 45-55 % (zero margin)', 'MEAS: duty at U301 XI (TP711) decides; fallback R203 0 ohm / NDK part'],
    'A-15': ['DS: 74AUP1G17 VT+/VT- at 3.0 V', 'ASSUMP: VT scaled to the operating supply; CI/CPD unpublished (2.4 pF bound)'],
    'A-16': ['TYP: CH32V307 reset thresholds 1.8/2.3 V and PA1 leakage 1 uA (WCH DS incomplete)'],
    'A-17': ['DS: BAT54 VF maxima', 'ASSUMP: -1 mV/K tempco and the MnO2 reverse-limit rule'],
    'A-18': ['ASSUMP: X5R ageing -5 %'],
    'A-19': ['ASSUMP: cable 0.25-1.5 uH, 0.05-0.4 ohm'],
    'A-20': ['ASSUMP: RthJA values and +10 C local rise'],
    'A-21': ['CON: E-2 re-arm latch logic (clear dominates; independent of the node-H discharge depth)'],
    'A-22': ['A-16: PA1 leakage 1 uA dominates the band', 'DS: power c09 divider band'],
    'A-23': ['A-18: capacitor ageing -5 %', 'DS: filter R/C tolerances (protection p11)', 'R-07: FS 20 Hz content at the calibrated level (analog)'],
    'A-24': ['A-08: planning values (L-1)', 'DS: U503 Default IOS max 222.6 mA', 'CON: NDK X201 second source +4.5 mA (E-27)'],
    'A-25': ['ASSUMP: ESS lock-loss latency not published'],
    'A-26': ['ASSUMP: I2S2 slave at 22.6/24.6 MHz BCLK not published (WCH text silent)',
             'MEAS: bit-exact capture at 352.8/384 kHz (i-15) decides (R-5 condition)'],
    'A-27': ['DS: TPS70933 1 % + line + load; dropout <= 650 mV at 50 mA'],
    'A-28': ['DS: MMBT3904 ICEX 50 nA / ICBO 100 nA at 25 C', 'ASSUMP: hot leakage scaled to 50 C'],
    'A-29': ['DS: ECHU series reflow 260 C max, <= 95 s above 220 C (not confirmed for the 2416 size)',
             'MEAS: JLCPCB profile confirmation for the 2416 size (order remark), else owner-fit'],
    'A-30': ['DS: ESS XI 10 pF max', 'ASSUMP: tap 2.4 pF bound (74AUP1G17 CI unpublished) and XI trace <= 10 mm (layout not routed)'],
    'A-31': ['DS: C_T 220 nF +-2 % PPS, R_T 110 k 0.1 %, V_T divider 0.1 %', 'A-33: timer leakage bound <= 1 uA',
             'R-07: boundary guaranteed only at or below the calibrated FS (2.228 V per leg); uncalibrated boards run at the -4.5 dB default (F-5)',
             'A-40: firmware gain ceiling and the -4.5 dB default without a valid calibration record (F-5)'],
    'A-32': ['TYP: WCH PVD level tolerance not published', 'ASSUMP: >= 2.9 V highest PVD level'],
    'A-33': ['ASSUMP: <= 1 uA per timer node (NPN ICBO hot, C_T insulation, PCB surface; no hot maxima for all terms)'],
    'A-34': ['MEAS: production test: latch cleared + RELAY_EN high -> every photorelay open, LED current < 10 uA (Q622 short not detectable at boot)'],
    'A-35': ['DS: quiescent maxima of the I+ / I- loads (OPA1622, OPA2210, ES9018K2M, comparators, leakage bounds)',
             'CON: 32 ohm Default peak current from the target power; ANA_SENSE and block-6 maxima (protection R9 check)',
             'TYP: LM27762 IQ 1.00 mA (390 uA typ, no maximum published) - also inside the 73.51 mA quiescent (r2_power)',
             'ASSUMP: charge-pump input-current factor 1.03 on I- (estimated) - also inside the 73.51 mA quiescent'],
    'A-36': ['MODEL: OPA1622 macro-model calibrated to typical datasheet curves (4 variants; analog calibrate_opa1622)',
             'A-02: switch RON up to 0.081 ohm at 60 C', 'ASSUMP: 5-15 nH wiring, 0-1 nF + cable load family (37 cases)'],
    'A-37': ['MODEL: OPA1622 typical-curve macro-model (4 variants)', 'A-03: COFF 0.1-1 nF bound'],
    'A-38': ['MODEL: reconstructed OPA2210 open-loop gain and output-impedance shapes (1,080 corners; analog stability_iv)'],
    'A-39': ['MEAS: E-2 latch qualification tests: shallow and short trips with RELAY_EN held high, power-up state, single-fault injection (R10-A4, F-4)'],
    'A-46': ['ASSUMP: E-3 timer reset level VCE(sat) <= 0.20 V at IC ~35 uA: the datasheet row of the fitted onsemi MMBT3904LT1G (C81464; <= 0.2 V at 10 mA / 1 mA) extended to 35 uA at forced beta ~3.5 (Ebers-Moll <= ~0.11 V needs the unpublished beta_R)',
             'CON: sensitivity with 0.30 V (the 50 mA / 5 mA row): T_P min 18.84 ms, 20 Hz margins 3.1 / 2.4 / 0.9 %, FS squares may mute up to 26.5 Hz (p21)'],
    'A-40': ['CON: record validation (magic, version/length, CRC-32, 96-bit UID, range) -> gain state G; the ESS resets reg 17-20 at every RESETB and G.M is re-written',
             'CON: gain ceiling: master trim reg 20..17 <= the calibrated value, reg 15/16 attenuation only, UAC2 volume maximum 0 dB; pre-close and OD-2 poll A compare reg 15-20 with G.M',
             'ASSUMP: record page in the non-zero-wait flash area; CRC unit STM32F1-compatible; flash endurance >= 1k; ESS trim rounding <= 2^-24; no ESS output before relock after a reset',
             'TYP: the default range 0.983-1.293 Vrms per leg rests on the ESS TYP full scale (analog r10_fixes F-5)'],
}

# ---- new rows (R10): (id, requirement / limit, value, evidence, qualification test)
NEW_R10 = [
    ('A-35', 'Default 5V_ANA need (sets R-13 / R-14 / R-73)', '178.96 mA (analog need_for 178.9230 with the F-1 leg taps and block 6 2.738 / 2.566 mA + ANA_SENSE 0.0378 = 178.961) '
     'vs U503 IOS min 180.0507 mA: +1.09 mA (+1.0899), E; used up at LM27762 IQ 2.09 mA (5.4 x TYP) or CP 1.038; block 6 budgeted at the conservative bound <= 2.738 / 2.566 mA (the protection 06:43 loads +0.078 / +0.086 mA); the design 2.714 / 2.542 mA lies inside it, and the need is computed on the bound'
     '; a new load on VPOS/VNEG adds ~I+ + 1.03 x I- (decisions_r10 fact 9)',
     'analog r9_fixes E-6 ("G, except LM27762 IQ 1.0 mA (no max) and CP 1.03 = E"); power c17', 'Default 32 ohm power at the measured U503 limit (i-4)'),
    ('A-36', 'Leg stability with the output switch closed (0-1 nF + cable)', 'PM >= 51.3 deg, GM >= 7.7 dB (2 nF stress 47.0 deg); bead alternate 51.8 deg / 7.7 dB',
     'analog stability_switch (37 load cases x 4 OPA1622 models)', 'step / square response into 0-1 nF + cable at bring-up (O1); fallback Clead 4.7-22 pF, Ct 1.5-2.2 nF'),
    ('A-37', 'Leg stability with the output switch open (COFF 0.1-1 nF)', 'PM >= 59.9 deg, GM >= 10.1 dB (57.7 deg at COFF 1.5 nF)',
     'analog stability_switch', 'step response with the switch open (O1)'),
    ('A-38', 'I/V stage stability (released case, with the CM-summing load)', 'PM >= 67.5 deg, GM >= 5.6 dB (1,080 corners); the 66.8 deg section of stability_iv.txt is the rejected 10 ohm-Rser variant',
     'analog stability_iv (1,080 corners)', 'I/V step response and ringing at bring-up (O1)'),
    ('A-41', 'High-mode USB total (S4) vs the U102 current limit (split from R-34, power R10)', 'S4 760.77 mA (NDK X201 765.27 mA) vs U102 IOS min 870 mA (R108 100 k): +109 mA (+105 mA NDK) on the planning values (power F-1 final)',
     'power c17 / c20 (R10)', 'S4 current on the first board; production S1/S3 tests'),
    ('A-42', 'ANA_SENSE supply-fault threshold band: no false fault (power R10, c21 addendum)',
     'Default 4.00 V (1587 counts): band 3.704-4.236 V, margin +71 mV at VBUS 4.40 V; High (ILIM_HI = 1) 3.90 V = 1.247 V (1548 counts): band 3.608-4.133 V, '
     'margin +124 mV at the High peak need, +108 mV with the J101 contact drop; a short still reads ~0 V (power 06:43)',
     'power c21 R10 addendum; digital firmware_sequences 3 and adc_settings 3', 'ANA_SENSE trip level in Default and High at VBUS 4.40 V (bring-up)'),
    ('A-40', 'F-5 calibration rule: detector content boundaries only at or below the calibrated full-scale level',
     'A_FS = 1.55 Vrms +0.15 dB per leg (+0.10 dB acceptance + 0.05 dB instrument); no valid record -> -4.5 dB default 0x4C3EA838 (0.983-1.293 Vrms per leg), '
     'red double-flash + log; the firmware never sets a gain above the calibrated level',
     'digital firmware_sequences 20 (R10 F-5, flash record at 0x08077000, UID-bound, CRC-32); analog r10_fixes F-5',
     'production P-1...P-7 incl. the erased-record test; reg 15-20 read-back at every pre-close'),
    ('A-39', 'E-2 re-arm latch qualification (R10-A4 / F-4)', 'a trip that pulls N6_H below HREF clears ARM within <= 0.346 ms (released) / 0.383 ms (fallback) after the comparator switches; '
     'a disturbance that never reaches HREF neither clears the latch nor opens the switch; the tests are open obligations',
     'protection p21 timing estimate (not a transistor-level transient)', 'trips of 1 / 3 / 10 ms with RELAY_EN held high; an H dip above HREF; a hung MCU; power-up with RELAY_EN high; R692 open / U608 unpowered; Q622 D-S short production test'),
    ('A-46', 'E-3 timer reset level at low current (independent check 26 Sep 08:09; protection 08:20 / 08:46 / 08:48: [ASSUMP], no DS or construction bound at 35-40 uA)', 'VCE(sat) <= 0.20 V at IC ~35 uA used for T_P min 19.50 ms: the 10 mA / 1 mA datasheet row of the fitted onsemi MMBT3904LT1G (Q623-Q627, C81464, adopted 08:48) extended; '
     'with 0.30 V: T_P min 18.84 ms, 20 Hz margins 3.1 / 2.4 / 0.9 %, FS squares may mute up to 26.5 Hz',
     'protection p21 (labelled [ASSUMP A-46] in code and output; A-31 / R-26 inputs)', 'timer reset level of Q623-Q626 at bring-up (expect < 0.1 V); E-3 timer T_P at 0 / 50 C'),
    ('A-43', 'F-1 comparator timing and LPW node leakage (assumption)', 'TLV1704 tpd <= 5 us (10 x typ); LPW timer-node leakage <= 0.1 uA',
     'protection p21 design basis (no maxima published)', 'LPW timer T_P2 and OR / LPW trip timing at 0 / 50 C on the first boards'),
    ('A-44', 'LPW / OR detectors and the new content boundary (adopted by default)', 'OR V_OR +1.764...1.964 / -1.762...-1.959 V; LPW V_LL +0.279...0.322 / -0.283...-0.324 V, T_P2 51.3-68.5 ms, reset <= 9.6 ms; '
     'content boundary stated on the timer: a mute can occur once the 3.3 ms-filtered leg tap has been beyond +-V_LL (0.279...0.324 V) for >= 70.8 ms, and will occur after 91.9 ms plus the amplitude-dependent tap crossing (unbounded near V_LL; +11.6 ms at 0.5 V) and <= 1.8 ms comparator delays; in raw-leg terms a FS excursion can mute after >= 62.9 ms (e.g. FS sine < 6.5 Hz, squares <= ~7 Hz, offset >= 0.145 FS)', 'protection p21 (c1), p21b (d2)/(d3)', 'sub-20 Hz content and offset tests at bring-up'),
    ('A-45', '32 ohm balanced frozen FS: HIGH MODE without the swing credit (owner item); Default mode capped by U503', 'High mode: E-3 alone <= 15 mJ only up to 2.175 V per leg; 15.23 / 15.77 / 17.14 mJ at 2.192 / 2.230 / 2.325 V per leg; '
     '-4.5 dB default at the 3.66 V basis 15.07 mJ; with the typical swing credit 13.67 / 14.87 mJ; physics floor 14.55 mJ at 2.325 V; 32 ohm stage not adopted (option B to the owner). '
     'Default mode (F-8): capped by U503 (IOS max 222.6 mA), legs settle <= 1.781 V per leg, worst 11.10 mJ (26 % margin, no swing / dropout / UVLO credit, capacitor energy and 1.5 x ILIM overshoot for 0.3 ms included), removed by E-3 <= 25.4 ms; typical 5.0 mJ; TPS2596 has no fault timer / auto-retry, RAILS_OK_N is firmware-only',
     'protection p22 (options A-D)', 'CPLD frozen 0 dBFS code at the calibrated level into a 32 ohm balanced dummy: energy until the switch opens <= 15 mJ, and the leg swing'),
    ('R-74', 'History-robust hardware protection with a level floor (Spec v1.1)', 'the hardware requirement holds from every reachable state for |leg| >= 0.34 V and |pair| >= 0.68 V '
     '(rounded up over the LPW level max 0.32401 V, IB only / 0.33401 V with the 10 nA surface-leakage allowance [ASSUMP]); bounded delay at the floor 118.8 ms, 3.43 mJ; '
     'below the floor the firmware tiers apply (R-24: <= 17.4 / 8.7 mJ pair, 14.3 / 7.2 mJ leg)', 'protection p21 (a)(b2)(b3)(c2)',
     'DC injection just above and below the floor at bring-up; the p21 history states on the first boards'),
]
# ---- R10 text updates of existing EXTRA rows (value only)
EXTRA_R10_VALUE = {
    'A-31': 'T_P 19.50-23.37 ms (p21); sines >= 20 Hz never trip: margins 6.4 / 5.7 / 4.3 % at 2.192 / 2.230 / 2.325 V per leg (13.9 / 6.6 % at the -4.5 dB default); '
            'FS squares mute certainly <= 21.4 Hz, may up to 25.6 Hz; guaranteed only at or below the calibrated FS (F-5)',
    'A-18': 'RETIRED (R10 F-1): C601-C604 removed with the leg windows; no ageing term left in the detector timing',
    'A-23': 'RETIRED (R10 F-1): the leg windows are gone; content transparency of OR / LPW is in R-26',
    'A-10': '3 % pair offset mismatch / 1 mV null (offset terms, closed only by the per-board test); the 22 % CM mismatch used for '
            'pop and CM content is a plain assumption in R-23 / R-30',
}

# ---- stream class lists (R10): stream -> {row: (class stated by the stream, [inputs], note)}. Applied over the walk; the
#      class that counts is always the derived one; a stream class that differs from its own inputs is reported.
STREAM_R10 = {
    # r10-analog list (message 26 Sep 06:02; analog/report.md 'R10 fixes', analog/out/r10_fixes.txt)
    'analog': {
        'R-05': ('E', ['TYP: ES9018K2M / OPA2210 / OPA1622 THD+N typical only', 'CON: switch distortion bound <= -164 dB (analog r2_switch)'], 'unchanged'),
        'R-06': ('E', ['TYP: ESS DR / DNR and op-amp noise densities typical only'], 'unchanged'),
        'R-07': ('Q', ['TYP: ESS full-scale source 0.924 x AVCC (TYP column): the lowest-gain unit spare -0.54 dB rests on it',
                       'DS: Rs 806 ohm +-11 % (datasheet note, TA 25 C only)',
                       'ASSUMP: no Rs tempco over 0-50 C',
                       'ASSUMP: AVCC current 8 mA (nominal used as the maximum)',
                       'DS: 3V3A window +-0.35 dB (LP5907 +-2 % over TJ) for the post-calibration drift',
                       'TYP: ESS tempco unpublished (+-0.1 dB holds at the calibration temperature only)',
                       'MEAS: the level is SET per board by the production calibration (caps the row)'], 'analog_budget s1, r10_fixes F-5; digital firmware_sequences s20'),
        'R-08': ('E', ['TYP: ESS full-scale source 0.924 x AVCC',
                       'DS: Rs 806 ohm +-11 % (datasheet note, 25 C)',
                       'ASSUMP: AVCC current 8 mA',
                       'DS: Rf, leg resistors, 3V3A tolerances',
                       'CON: trim word 0x4C3EA838 = -4.5000 dB (the untrimmed range is not a calibration result)'], 'analog_budget s1, r10_fixes F-5'),
        'R-09': ('E', ['DS: OPA1622 AOL test range -> guaranteed floor; High IOS min 395.4 mA',
                       'A-11: rails in regulation: RNEG <= 5.42 ohm at VBUS 4.60 V (4.09 ohm at 4.40 V) needed; RNEG typical only',
                       'ASSUMP: LDO dropout slope TYP x1.5',
                       'ASSUMP: the High need contains the LM27762 IQ (no maximum) and CP 1.03 (estimated)',
                       'SCOPE: calibrated unit (construction parameter): needed leg peak 1.803 V vs 2.167 V (calibrated FS at -0.1 dB) -> >= 0.78 dB level margin, >= 0.43 dB with the DS 3V3A drift; no measured value is relied on (analog 06:28)'], 'E confirmed; calibration is a precondition, not an input'),
        'R-10': ('E', ['DS: OPA1622 AOL test range; High IOS min 395.4 mA',
                       'A-11: RNEG <= 5.13 ohm at VBUS 4.60 V (3.86 ohm at 4.40 V) needed; RNEG typical only',
                       'ASSUMP: LDO dropout slope TYP x1.5',
                       'ASSUMP: High need IQ / CP terms',
                       'SCOPE: calibrated unit (construction parameter): needed leg peak 1.786 V vs 2.167 V (calibrated FS at -0.1 dB) -> >= 0.78 dB level margin, >= 0.43 dB with the DS 3V3A drift; no measured value is relied on (analog 06:28)'], 'E confirmed; calibration is a precondition'),
        'R-11': ('E', ['A-11: rails in regulation: the floor needs |V-| >= 3.523 V at I- pk 104.9 mA -> RNEG <= 7.93 ohm at 4.60 V (6.03 ohm at 4.40 V); RNEG typical only',
                       'TYP: LDO dropout slope 0.45 ohm (30 mV TYP x1.5)',
                       'ASSUMP: placeholder VIN from power c04',
                       'SCOPE: calibrated unit (construction parameter): needed leg peak 1.981 V vs 2.167 V (calibrated FS at -0.1 dB) -> >= 0.78 dB level margin, >= 0.43 dB with the DS 3V3A drift; no measured value is relied on (analog 06:28)'], 'r2_power s3-5, r10_fixes F-2'),
        'R-12': ('Q', ['CON: 30 mW at 300 ohm needs 2.124 V pk per leg',
                       'R-07: the calibrated -0.1 dB level 2.167 V leaves 0.17 dB (1.98 %): the row rests on the MEASURED calibration accuracy',
                       'DS: the 3V3A drift (3.9 %) could exceed the 1.98 % left',
                       'A-11: |V-| min 3.661 V >= 3.625 V holds only while the LM27762 regulates (RNEG <= 11.02 ohm)'], 'analog confirms Q'),
        'R-13': ('E', ['DS: U503 Default IOS min 180.05 mA (R509 4.75 k 0.1 %)',
                       'A-35: Default need 178.96 mA -> +1.09 mA; used up at LM27762 IQ 2.09 mA (5.4 x TYP) or CP 1.038', 'SCOPE: calibrated unit (construction parameter): needed leg peak 1.572 V vs 2.167 V (calibrated FS at -0.1 dB) -> >= 0.78 dB level margin, >= 0.43 dB with the DS 3V3A drift; no measured value is relied on (analog 06:28)'],
                 'no G path (R509 fixed by S3 <= 500 mA); Q: first-board LM27762 overhead measurement + production test i-4'),
        'R-14': ('Q', ['DS: U503 Default IOS min 180.05 mA',
                       'A-35: 60 / 120 ohm margins +11.0 / +4.4 mA (tolerate IQ <= 12.0 / 5.4 mA or CP <= 1.164 / 1.081)',
                       'SCOPE: calibrated unit (construction parameter): needed leg peak 0.719 / 1.454 (60 / 120 ohm) V vs 2.167 V (calibrated FS at -0.1 dB) -> >= 0.78 dB level margin, >= 0.43 dB with the DS 3V3A drift; no measured value is relied on (analog 06:28)',
                       'R-12: the 300 ohm target sits at the calibrated FS (rests on the measured calibration accuracy)'], 'analog confirms Q via the 300 ohm target'),
        'R-15': ('E', ['DS: TLP3545A RON 60 mOhm max at 25 C', 'A-02: RON x1.35 at 60 C',
                       'ASSUMP: J701/J702 contact resistance 50 mOhm per contact and 0 ohm links 50 mOhm each; the maker drawings give no contact-resistance maximum, so the owner kept this assumption (27 Sep 2026); these terms stay E until the bring-up output-impedance measurement'], 'unchanged'),
        'R-16': ('E', ['CON: poles from C0G +-5 % and 0.1 % R (-0.073 dB)',
                       'DS: ESS filter passband 0.454 fs (max column)',
                       'MODEL: ideal op-amps (analog_budget s7); the typical-model closed-loop run (stability_switch) shows no op-amp term at 20 kHz: second order, ~1e-5 dB at TYP GBW, fails only below ~TYP/100; no GBW minimum published'], 'E and insensitive'),
        'R-17': ('E', ['ASSUMP: layout return-path target 2 mOhm (routing pending)', 'CON: balanced <= 0.3 pF rule; switch-to-switch -166 dB'], 'unchanged'),
        'R-18': ('Q', ['A-02: RON mismatch <= 0.081 ohm (x1.35 at 60 C)',
                       'MEAS: the balance after trim rests on the per-channel calibration measurement',
                       'ASSUMP: ESS L/R Rs tempco unpublished (3V3A common, cancels)',
                       'DS: P/N leg mismatch 0.041 dB -> budget worst case 0.05 + 0.044 + 0.041 = 0.135 dB'], 'r2_switch s2, analog_budget s10'),
        'R-19': ('Q', ['DS: published terms (resistor tolerance + TCR, OPA1622/OPA2210 offset maxima, 3V3A) -> G sub-result 5.61 / 11.21 mV (ESS Rs at half nominal adds 0.07 mV)',
                       'A-10: DAC terms (3 % pair, 1 mV null) unpublished -> 7.73 / 15.47 mV (E); compliance rests on the per-board E-4 test'], ''),
        'R-30': ('E', ['A-03: COFF <= 1 nF', 'ASSUMP: 22 % DAC pin mismatch (ESS publishes none)', 'A-12: LP5907 current limit (unpublished)', 'TYP: ESS ramp end state'], 'unchanged'),
        'R-31': ('Q', ['MODEL: hold-up model (unplug_model_r3, power c14): DAC pins inside GND..AVCC, exposure 0 ms (E part)',
                       'A-05: PMEG VF 0-50 C',
                       'A-12: LP5907 reverse behaviour',
                       'A-16: MCU reset thresholds',
                       'MEAS: the requirement (jack transient <= 20 mV) is the measured target L-5 (i-13 / M11), not calculated'], 'unplug_model_r3'),
        'R-46': ('E', ['A-11: LM27762 RNEG typical only (L-3)'], 'unchanged'),
        'R-59': ('E', ['A-13: OPA2210 600 ohm swing row at 25 C only (the -40..125 C 10 k row covers 1.5 mA; the I/V sources ~3 mA)',
                       'A-05: PMEG VF from the 25 C max + typical tempco'], 'unchanged'),
        'A-03': ('E', ['TYP: TLP3545A COFF 640 pF', 'ASSUMP: x1.5 bound'], 'unchanged'),
        'A-05': ('E', ['DS: PMEG2010AEH VF maxima at 25 C', 'TYP: VF tempco'], 'unchanged'),
        'A-10': ('Q', ['ASSUMP: DAC pair offset mismatch 3 % and null 1 mV (ESS publishes no matching)',
                       'MEAS: per-board offset test at 0-5 / 25 / 50 C (E-4 procedure, all 5 boards) replaces the assumption'],
                 'Q for the offset use; the 22 % CM mismatch feeding pop / CM content is E (R-23, R-30)'),
        'A-13': ('E', ['DS: OPA2210 600 ohm swing row at 25 C', 'ASSUMP: the 25 C row applies over 0-50 C'], 'unchanged'),
        'A-17': ('E', ['DS: BAT54 VF maxima', 'ASSUMP: -1 mV/K tempco and the MnO2 reverse-limit rule'], 'unchanged'),
        'A-35': ('E', ['DS: op-amp and comparator quiescent maxima on VPOS / VNEG',
                       'CON: ES9018K2M pin currents through Rf into the I/V outputs (the DAC does not load VPOS/VNEG)',
                       'ASSUMP: leakage rules: AVX DCL x10 at 85 C = 0.22 mA per rail; BAT54 x2 per 10 K = 25 uA per rail',
                       'TYP: LM27762 IQ 1.0 mA (390 uA TYP, no maximum; PFM at light load, so it does not bound the full-load overhead)',
                       'ASSUMP: charge-pump input-current factor 1.03 (estimate)',
                       'CON: 32 ohm Default peak from the target power; ANA_SENSE 0.038 mA; block 6 budgeted at <= 2.738 / 2.566 mA (I+ / I-): a deliberate conservative bound (orchestrator 07:18; no re-run unless a later protection stage exceeds it); the design 2.714 / 2.542 mA lies inside it'], 'r2_common, r2_power s1-2, r9_fixes E-6, r10_fixes F-2'),
        'A-36': ('E', ['MODEL: OPA1622 fitted to TYP Fig. 10 (AOL / phase) and Fig. 40 (Zo magnitude, minimum-phase; Zo phase unpublished)',
                       'ASSUMP: GBW x0.8-1.25',
                       'A-02: switch RON up to 0.081 ohm at 60 C',
                       'ASSUMP: 5-15 nH switch wiring; 0-1 nF + cable load family (37 cases)'], 'stability_switch, models_v, calibrate_opa1622, digitize_opa1622*'),
        'A-37': ('E', ['MODEL: OPA1622 model fitted to TYP curves', 'ASSUMP: GBW x0.8-1.25', 'A-03: COFF bound 0.1-1 nF'], 'Q: step with the switch open'),
        'A-38': ('E', ['MODEL: OPA2210 3-pole fit to TYP A0 / GBW / PM with a reconstructed Zo family',
                       'ASSUMP: GBW +-30 %',
                       'ASSUMP: Cdac 0-15 pF (ESS silent)'], 'released case with the CM-summing load; stability_iv'),
    },
    # r10-power list (message 26 Sep 06:13; power/report.md 'R10 fixes', power c21 R10 addendum)
    'power': {
        'R-13': ('E', ['DS: U503 Default IOS min 180.05 mA (R509 4.75 k 0.1 %)',
                       'A-35: the need 178.96 mA contains the LM27762 IQ (390 uA typ, no max) and CP 1.03 (estimated) -> +1.09 mA is E'], ''),
        'R-14': ('Q', ['DS: U503 Default IOS min 180.05 mA',
                       'A-35: Default need (LM27762 IQ / CP 1.03 terms) - the power share'], 'power 06:43: Q through R-07 (analog 300 ohm input), no objection'),
        'R-32': ('Q', ['A-08: MCU 80 mA planning value (L-1) -> S1 82.40 mA',
                       'MEAS: S1 <= 90 mA production test on every board (E-17) is the acceptance evidence'], 'agreed 06:22'),
        'R-33': ('Q', ['A-24: S3 493.46 mA (NDK 497.96 mA) on the planning values (L-1)',
                       'DS: U503 Default IOS max 222.6 mA',
                       'MEAS: S3 <= 480 mA production test on every board (E-17) is the acceptance evidence'], 'agreed 06:22'),
        'R-34': ('G', ['CON: gating: CC ADC classification thresholds 0.20 / 0.66 / 1.23 V (divider tolerances), ILIM_HI -> Default at reset, U505'],
                 'split: the S4 budget is row A-41 (E)'),
        'R-35': ('E', ['DS: C102 2.2 uF +10 %, U102 soft start >= 3.31 ms, TPS70933 current limit (power c22)', 'CON: USB-IF CU #45 region method',
                       'ASSUMP: region separation uses U502 start <= 1 ms', 'ASSUMP: the 3V3M term uses a load credit (1 - 0.1 A / ICL max)',
                       'ASSUMP: D102 10 nF is not a datasheet maximum'],
                 'a bound re-run without the credit (A <= 33.6 / B <= 40.4 uC, either region) could restore G'),
        'R-36': ('Q', ['A-07: MCU Stop 1.9 mA planning value (L-1)',
                       'A-28: Q507 hot leakage estimate',
                       'CON: firmware suspend sequence <= 8.75 ms (digital firmware_sequences 19)',
                       'MEAS: suspend current on the first board, then on every board (R9-C3), is the acceptance evidence for the L-1 2.5 mA limit'], 'power 06:22: Q for consistency with R-32/R-33'),
        'R-37': ('E', ['A-20: thermal model (RthJA values, +10 C local rise)', 'ASSUMP: U202 40 mA'], 'keep'),
        'R-42': ('E', ['DS: U303 accuracy -> 1V3 1.2716-1.3248 V (G part)', 'CON: U303 EN tied to 3V3D; U605B gates AUD_EN on 3V3A good',
                       'MODEL: DVDD - DVCC <= +5 mV from the power c14 model (resistive-dropout LDOs)', 'A-16: assumed MCU reset thresholds',
                       'A-04: TLV3402 delay typ x3'], 'or split, keeping the 1V3 range G'),
        'R-43': ('E', ['A-16: MCU reset thresholds 1.8/2.3 V', 'A-12: LP5907 reverse behaviour (both variants modelled)'], 'keep'),
        'R-44': ('E', ['A-16: PA1 leakage 1 uA dominates the band',
                       'A-32: PVD threshold >= 2.9 V (L-12)',
                       'A-22: brown-out margin +67...+114 mV at the 4.40 V corner (U502 fed from VBUS ahead of U102 since E-16; power 06:43)'], 'value +67..+114 mV'),
        'R-45': ('E', ['A-08: planning values (L-1)'], 'keep'),
        'R-51': ('G', ['CON: EN+/EN- tied to VIN (5V_ANA_F) by construction; RAIL_EN, R506, R507 deleted'],
                 'the rails-good <= 18.8 ms / T_START note is E (c18 model) and is labelled so'),
        'R-52': ('E', ['A-19: cable model 0.25-1.5 uH / 0.05-0.4 ohm', 'DS: D102 SMDJ12A clamp; C102 2.2 uF (1.1-2.42 uF effective)'], 'keep'),
        'R-53': ('E', ['DS: BAT54 VF maxima (D104/D105 OUT->IN)', 'A-12: input-collapse corners of the power c14 model', 'PROC: limitation L-8 (target 0.3 V not met)'], 'keep'),
        'R-54': ('G', ['CON: a 5V_ANA short reads ~0 V on ANA_SENSE, far below the 4.00 V threshold, in every state (no ADC-accuracy input: c20 c ignores the ADC error)'], 'the no-false-fault band is the E row A-42'),
        'R-65': ('G', ['DS: U102 clamp 5.25-5.55 V; LP5907/LM27762 ROC and abs max; USBLC6 VRM', 'PROC: limitation L-10 (out-of-spec source)'], 'keep'),
        'R-67': ('E', ['ASSUMP: MCU boot <= 10 ms', 'DS: R109 470 k + C104 EN delay'], 'keep'),
        'R-69': ('-', ['PROC: owner-fitting order (parts layout_package 13a)'], 'keep'),
        'R-73': ('Q', ['A-35: need 178.96 mA vs IOS min 180.05 mA: +1.09 mA, E (the "G" clause becomes E via R-13)',
                       'A-24: USB <= 500 mA on the planning values',
                       'MEAS: S3 <= 480 mA / S1 <= 90 mA production test on every board (E-17) is the acceptance evidence'], 'agreed 06:22'),
        'A-06': ('G', ['CON: D103 deleted; D104/D105 unbiased in Stop; the TPS25200 OUT discharge holds 5V_SYS at 0 V -> 0 in the S6 budget'], 'keep'),
        'A-11': ('E', ['TYP: LM27762 R_NEG 2.5 ohm, UVLO 2.4/2.6 V, PGOOD and start-up current typical only'], 'keep'),
        'A-12': ('E', ['TYP: LP5907 current limit 500 mA typical; no minimum rise time', 'ASSUMP: <= 0.75 A; both reverse variants modelled'], 'keep'),
        'A-17': ('E', ['DS: BAT54 VF maxima',
                       'ASSUMP: -1 mV/K tempco and the AVX TAJ reverse-limit rule'], 'one set agreed (power 06:43): register = analog r9_fixes E-8 (13.0 mA, <= 0.469 / 0.386 V vs 1.00 / 0.71 V); power c21 E-8 = cross-check (AVX 10 -> 3 % rule, >= +0.17 V at 17.4 / 14.8 mA)'),
        'A-19': ('E', ['ASSUMP: cable 0.25-1.5 uH, 0.05-0.4 ohm'], 'keep'),
        'A-20': ('E', ['ASSUMP: RthJA values and +10 C local rise'], 'keep'),
        'A-22': ('E', ['A-16: PA1 leakage 1 uA dominates the band',
                       'DS: power c21 R10 band (divider, ADC, TPS70933 VDDA range); 5V_SYS min 4.318 V (U502 current no longer through U102)'], 'margin +67..+114 mV (power 06:43)'),
        'A-24': ('E', ['A-08: planning values (L-1)',
                       'DS: U503 Default IOS max 222.6 mA',
                       'DS: Kyocera X201 8.0 mA maximum',
                       'ASSUMP: NDK X201 second source 12.7 mA is a parts budget (9 mA at 25 C + CV^2f), +4.5 mA (E-27)'], 'power 06:22'),
        'A-27': ('G', ['DS: TPS70933 1 % + line + load; dropout <= 650 mV at 50 mA'], 'keep'),
        'A-28': ('E', ['DS: MMBT3904 ICEX 50 nA / ICBO 100 nA at 25 C', 'ASSUMP: hot leakage scaled to 50 C'], 'keep'),
        'A-35': ('E', ['CON: c17 basis = analog need_for() 178.9230 mA (F-1 leg taps, block 6 2.738 / 2.566 mA) + ANA_SENSE 0.0378 mA = 178.961 mA (no flat term)',
                       'TYP: LM27762 IQ (analog r9_fixes)', 'ASSUMP: CP 1.03 (analog r9_fixes)'], 'power 06:22; the T495/AVX DCL bound is ASSUMP per analog (06:17)'),
        'A-41': ('E', ['A-08: S4 760.77 mA (NDK 765.27 mA) rests on the MCU/CPLD/DVDD planning values (L-1)', 'DS: U102 IOS min 870 mA (R108 100 k)'],
                 'split from R-34'),
        'A-42': ('E', ['DS: divider tolerances, ADC 11 LSB, TPS70933 VDDA range',
                       'A-16: PA0 leakage 1 uA (assumed) - the only E input',
                       'CON: thresholds 1587 counts (4.00 V, Default) / 1548 counts (3.90 V = 1.247 V, High); switched with ILIM_HI only with the switch open or inside the downgrade sequence'], 'power 06:37 / 06:43: E only because of the assumed pin leakage'),
    },
    # r10-protection-2 list (message 26 Sep 07:42; protection p21 / p21b / p21c / p21d / p22)
    'protection': {
        'R-20': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-01: switch tOFF x2',
                       'A-33: E-3 node leakage <= 1 uA (T_P max side)',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'CON: DC >= 2 V removed <= 27.1 ms from any state (b3 27.2 ms), single leg, any partner content: OR U611/U612 (330 k / 1 nF) -> E-3 timer -> H -> switch; margin 73 %'], 'p21 (b2)/(b3); Q test: 2.00 V per leg and polarity -> 19.5-27 ms; 3.8 V with FS 100 Hz on the partner leg -> <= 27 ms'),
        'R-21': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-01: switch tOFF x2',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-33: E-3 node leakage <= 1 uA',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'CON: DC >= 1 V removed <= 101.3 ms (b3 102.7 ms): LPW U613-U620 (1 M / 3.3 nF C0G; V_LL +0.279...0.322 / -0.283...-0.324 V; T_P2 51.3-68.5 ms) -> E-3; margin 59 %'], 'p21'),
        'R-22': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-01: switch tOFF x2',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-33: E-3 node leakage <= 1 uA',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'ASSUMP: ISC 190 mA (16 ohm balanced one-leg-stuck only: 14.9 mJ)',
                       'CON: rail-stuck SE 26.40 / 13.20 mJ at 16 / 32 ohm at 4.049 V (b3 26.48 / 13.24; 24.69 / 12.35 mJ at 3.915 V), removal <= 25.8 ms, any partner content; margin 12 %',
                       'PROC: OPEN DEFINITION ITEM (orchestrator / owner), 32 ohm only: the Spec defines the energy as DC energy (V^2/R x t; SE loads never see partner content); the TOTAL terminal energy with FS partner content on a balanced load in High mode is 24.1 mJ at 32 ohm (24.70 mJ without the ISC credit) vs 15 mJ; 16 ohm: <= 23.85 mJ vs 30 mJ without the ISC credit (U503 IOS max 489.7 mA cap, p22 section 6b; 14.93 mJ with it); Default mode <= 11.3 mJ (p22 sections 6 / 6b); a fast high over-range fix (V_H 2.45-2.80 V) was evaluated and NOT adopted (the loaded stuck leg sags to 2.82 V at 32 ohm / 0.25 V at 16 ohm at the eFuse minimum; 16 parts + a test provision, Z4 ~60 %; p22 section 7); protection recommends keeping the Spec DC-energy definition and publishing the total-terminal figures as information'], 'p21; p22 section 6'),
        'R-23': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-01: switch tOFF x2',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-33: E-3 node leakage <= 1 uA',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'TYP: OPA1622 typical swing limit (0.8 V + 8 ohm/A)',
                       'CON: balanced sweep over every level up to the swing limit (no calibration input): 16 ohm 25.70 mJ (b3 26.08); 32 ohm 14.87 mJ at the fallback swing limit / 13.67 mJ released'], 'corrected Q -> E (protection 07:54); the CM-window and 22 % mismatch inputs are no longer used; p21, p22'),
        'R-24': ('E', ['DS: p06 / p09 / p10 limits',
                       'CON: FIR estimator; history robustness shown over the p21c history set (short opposite bursts added, 08:37)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-16: MCU pin leakage 1 uA',
                       'ASSUMP: the p21c history set is FINITE (pre-states i-iv), not a universal bound: a history outside it can delay a trip slightly (independent check: +9 ms at 0.176 V, +1 ms at T2); over the swept histories: T1 >= 1.001 / 1.015 V within 218 ms, T2 >= 0.313 / 0.312 V within 603 ms, T3 >= 0.178 / 0.195 V within 2.36 s - the 3 s owner rule keeps a margin of > 0.6 s',
                       'CON: rail-bounded variant (E basis, no R-07 input): T1 1.007 / 1.027, T2 0.316 / 0.316, T3 0.179 / 0.197 V (same deadlines); below the 0.34 / 0.68 V floor pair 17.4 / 8.7 mJ, leg 14.5 / 7.3 mJ at 16 / 32 ohm'], 'p21c (c864b62a); the exact deadlines are stated for the tested history set'),
        'R-25': ('E', ['R-24: tier T3 levels 0.178 / 0.195 V (rail variant 0.179 / 0.197 V)',
                       'CON: residual <= 0.197 V^2 / 16 ohm = 2.43 mW (rail variant; 2.38 mW content-bounded)'], 'inherits R-24'),
        'R-26': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'A-04: TLV3402 delay 3 x typical',
                       'MODEL: -4.5 dB default level 1.828 V (ESS TYP model)',
                       'SCOPE: content <= the calibrated ceiling incl. drift, 2.325 V per leg (R-07 + A-40): the E-3 20 Hz sine first trips at 2.659 V per leg: +1.16 dB, 7 x the +-0.15 dB calibration window, so no measured value is relied on',
                       'A-40: uncalibrated boards run at the -4.5 dB default: margins 13.9 / 6.6 %',
                       'CON: margins 6.4 / 5.7 / 4.3 % (2.192 / 2.230 / 2.325 V per leg); FS squares 21.4 / 25.6 Hz; bursts and polarity reversals do not trip; one FS 20 Hz square cycle and the asymmetric 2nd-harmonic wave trip E-3 (pre-existing)'], 'corrected to E with SCOPE (protection 07:54); A-18 dropped; p21b'),
        'R-27': ('G', ['CON: OD-1 rules P1-P4, digital thresholds and counts on digital samples (exact arithmetic, protection p15 / p16)'], 'unchanged; analog agrees'),
        'R-28': ('E', ['CON: OD-1 guard removal <= 23.6 ms',
                       'ASSUMP: DAC filter delay <= 1 ms',
                       'A-01: switch tOFF x2'], 'unchanged'),
        'R-29': ('E', ['A-04: TLV3402 delay 3 x typical (3V3A path)',
                       'A-15: MCLK-alive tap margin',
                       'R-61: frozen DC removed <= 25.4 ms by E-3'], 'p10 / p21'),
        'R-40': ('E', ['A-27: 3V3M minimum 3.207 V -> RELAY_EN >= 2.81 V',
                       'DS: R641 / R642 24.9 ohm 0.1 %',
                       'ASSUMP: LED VF tempco -2.2 mV/K and hFE at 0 C',
                       'CON: IF >= 5.0 mA needs 5V_SYS >= 4.30 V (min 4.303 V with the J101 drop)'], 'resolved; p05'),
        'R-41': ('E', ['A-01: switch tOFF x2',
                       'CON: E-2 latch: re-close only after a fresh RELAY_EN edge with H recovered; H trip <= 1.96 ms released / 2.00 ms fallback'], ''),
        'R-49': ('E', ['A-27: TPS70933 3V3M range',
                       'DS: TLV3402 thresholds and hysteresis',
                       'A-04: TLV3402 delay 3 x typical (gate timing)'], 'unchanged'),
        'R-55': ('G', ['CON: E-2 latch logic: RELAY_EN static high can never re-arm; clear dominates',
                       'DS: HREF 2.883-3.029 V released, up to 3.133 V fallback (VPOS x 330/430)'], ''),
        'R-56': ('E', ['A-16: MCU pin leakage 1 uA',
                       'DS: ADC and divider error budget (protection R3.17)',
                       'ASSUMP: offset estimate 7.73 / 15.47 mV with the assumed DAC terms (analog)',
                       'CON: per-board offset acceptance limit (design parameter) -> margins 4.2 / 9.2 mV'], 'unchanged'),
        'R-57': ('Q', ["CON: self-test windows: (f) LPW 72.4-99.8 ms, pass 65-110 ms; (g) OR 19.5-24.9 ms, pass 18-32 ms (PC15 settle <= 90 us, 1 ms used; R951 threshold 0.086-0.141 V); (e) 18-26 ms; a' deleted; total 3.68 s, or 2.96 s rotating (owner)",
                       'DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-33: E-3 node leakage',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'ASSUMP: analog E-4 leg offset 7.73 mV',
                       'SCOPE: content <= the calibrated ceiling incl. drift, 2.325 V per leg (R-07 + A-40): (f) pair at the ceiling 1.395 V vs V_L min 1.802 V = 29 %; (f) lowest word 0.417 V vs V_LL max 0.324 V = 29 %; (g) 0.347 V vs 0.30 V = 16 %'], 'p21b (e2); Q accepted by protection (07:58); per-channel coverage from the production per-leg injection (08:20)'),
        'R-61': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-01: switch tOFF x2',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-33: E-3 node leakage <= 1 uA',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'TYP: OPA1622 typical swing limit (0.8 V + 8 ohm/A)',
                       'CON: E-3 removes frozen codes >= V_L/2 in <= 25.4 ms; LPW removes 0.324 V ... V_L/2 in <= 101.3 ms; energies as R-23 (without the swing credit: A-45)'], 'p21'),
        'R-62': ('G', ['DS: CH32V307 IINJ(PIN) +-5 mA, sum +-25 mA [DS Tab 4-1]',
                       'CON: R242-R246 330 ohm 1 %'], 'unchanged'),
        'R-66': ('Q', ['A-26: I2S2 slave capture at 22.6 / 24.6 MHz BCLK',
                       'ASSUMP: 15 CPU cycles per frame (CPU <= 13.3 %)'], 'unchanged; text: "E-3 detector" instead of "leg windows"'),
        'R-72': ('E', ['CON: E-2 latch logic (clear dominates; power-up cleared; re-arm only by a fresh RELAY_EN edge after H > HREF)',
                       'DS: 74LVC1G74 / U606 thresholds',
                       'ASSUMP: timing estimate: a trip that pulls N6_H below HREF clears ARM within <= 0.346 ms (released) / 0.383 ms (fallback) after the comparator switches; a disturbance that never reaches HREF neither clears the latch nor opens the switch; all R10 stages act through TLV1704 outputs on H'], 'F-4 wording; the tests are the Q row A-39'),
        'R-74': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'CON: reachable pre-fault states bounded by the rails (p21 b3, p21c rail variant) - replaces the zero-history assumption',
                       'A-01: switch tOFF x2',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-33: E-3 node leakage',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'TYP: OPA1622 typical swing limit (0.8 V + 8 ohm/A)',
                       'ASSUMP: ISC 190 mA',
                       'ASSUMP: surface-leakage allowance 10 nA on the 1 M LPW tap: LPW level max 0.32401 V (IB only) -> 0.33401 V',
                       'CON: requirement floor |leg| >= 0.34 V, |pair| >= 0.68 V, rounded up over the level max; the hardware requirement holds from every reachable state above it (bounded delay at the floor 118.8 ms, 3.43 mJ); below it R-24 applies'], 'history-robust hardware protection + level floor (protection 08:25); p21 (a)(b2)(b3)(c2)'),
        'A-01': ('E', ['DS: TLP3545A tON/tOFF maxima at 25 C',
                       'TYP: temperature curves typical only',
                       'ASSUMP: x2 design factor (L-2)'], 'unchanged'),
        'A-04': ('E', ['TYP: TLV3402 delay 55-300 us, no maximum published',
                       'ASSUMP: x3 bound'], 'unchanged; now also used by LPW'),
        'A-15': ('E', ['DS: 74AUP1G17 VT+/VT- at 3.0 V',
                       'ASSUMP: VT scaled to the operating supply; CI/CPD unpublished (2.4 pF bound)'], 'unchanged'),
        'A-18': ('-', ['PROC: RETIRED in R10: C601-C604 removed with the leg windows; all detector timing is now C0G or PPS (no ageing term); C608-C611 ageing only shortens the DC-sense tau and the tiers use tau max'], 'retired'),
        'A-21': ('G', ['CON: E-2 re-arm latch logic (clear dominates; independent of the node-H discharge depth)'], 'unchanged'),
        'A-23': ('-', ['PROC: RETIRED in R10: the leg windows are gone; the OR / LPW transparency is covered by R-26'], 'retired'),
        'A-30': ('E', ['DS: ESS XI 10 pF max',
                       'ASSUMP: tap 2.4 pF bound (74AUP1G17 CI unpublished) and XI trace <= 10 mm (layout not routed)'], 'unchanged'),
        'A-31': ('E', ['DS: C_T 220 nF +-2 % PPS, R_T 110 k 0.1 %, V_T divider 0.1 %',
                       'A-33: timer leakage (T_P max only, not the false-trip side)',
                       'SCOPE: content <= the calibrated ceiling incl. drift, 2.325 V per leg (R-07 + A-40): as R-26: +1.16 dB to the first 20 Hz trip, 7 x the calibration window',
                       'CON: T_P 19.50-23.37 ms; margins as R-26; squares 21.4 / 25.6 Hz'], 'p21 / p21b'),
        'A-33': ('E', ['ASSUMP: <= 1 uA per timer node (NPN ICBO hot, C_T insulation, PCB surface); affects only T_P max (the energy side), not the false-trip side'], 'unchanged'),
        'A-34': ('Q', ['MEAS: production test: latch cleared + RELAY_EN high -> every photorelay open, LED current < 10 uA (Q622 short not detectable at boot)'], 'unchanged'),
        'A-39': ('Q', ['MEAS: E-2 latch tests: trips of 1, 3 and 10 ms with RELAY_EN held high; an H dip that stays above HREF; a hung MCU; power-up with RELAY_EN high; R692 open / U608 unpowered; the Q622 D-S short production test'], 'open'),
        'A-43': ('E', ['ASSUMP: TLV1704 tpd <= 5 us (10 x typ)',
                       'ASSUMP: LPW timer-node leakage <= 0.1 uA'], 'new (F-1)'),
        'A-44': ('E', ['DS: TLV1704 / TLV3402 VOS, IB, VOL; 0.1 % / 1 % resistors; C0G +-5 % +30 ppm/K; C_T PPS +-2 %; 3V3A +-2 %',
                       'DS: rails: released dividers + the R501 232 k fallback (RAIL_DESIGN envelope, VPOS 3.789-4.049 V)',
                       'A-04: TLV3402 delay 3 x typical',
                       'A-43: TLV1704 tpd, LPW node leakage',
                       'CON: OR (U611/U612, 330 k / 1 nF) V_OR +1.764...1.964 / -1.762...-1.959 V; LPW (U613-U620, 1 M / 3.3 nF) V_LL +0.279...0.322 / -0.283...-0.324 V, T_P2 51.3-68.5 ms, reset <= 9.6 ms; content boundary stated on the timer: a mute can occur once the 3.3 ms-filtered leg tap has been beyond +-V_LL (0.279...0.324 V) for >= 70.8 ms, and will occur after 91.9 ms plus the amplitude-dependent tap crossing (unbounded near V_LL; +11.6 ms at 0.5 V) and <= 1.8 ms comparator delays; in raw-leg terms a FS excursion can mute after >= 62.9 ms (e.g. FS sine < 6.5 Hz, squares <= ~7 Hz, offset >= 0.145 FS)'], 'p21 (c1), p21b (d2)/(d3)'),
        'A-45': ('E', ['TYP: OPA1622 typical swing credit (High mode: 13.67 / 14.87 mJ with it)',
                       'SCOPE: content <= the calibrated ceiling incl. drift, 2.325 V per leg (R-07 + A-40): evaluated at 2.192 / 2.230 / 2.325 V per leg',
                       'CON: High mode without the swing credit 15.23 / 15.77 / 17.14 mJ at 2.192 / 2.230 / 2.325 V per leg; physics floor 14.55 mJ',
                       'DS: Default mode: U503 IOS max 222.6 mA (R509 0.1 %) caps the load current; charge-pump k >= 1 and I+ = I- by construction -> legs <= 1.781 V per leg, <= 11.10 mJ (G cap)',
                       'A-01: switch tOFF x2 (Default-mode removal <= 25.4 ms)',
                       'A-33: E-3 node leakage (removal time)'], 'owner item for High mode; F-8 Default-mode check (protection 08:03); p22 section 5'),
    },
}

KIND = {'DS': 'G', 'CON': 'G', 'ASSUMP': 'E', 'TYP': 'E', 'MODEL': 'E', 'MEAS': 'Q', 'PROC': '-',
        'SCOPE': '-'}   # SCOPE = a precondition that is not an input: allowed only with a stated margin showing no measured value is relied on
RANK = {'G': 0, 'E': 1, 'Q': 2}
REFPAT = re.compile(r'^[RA]-\d\d$')
SOURCE = {k: f'integration walk R10 (pending {OWNER.get(k, "?")} list)' if OWNER.get(k) in ('power', 'analog', 'protection')
          else f'integration walk R10 ({OWNER.get(k, "?")} row)' for k in INPUTS}
WALK_NOTE = {   # integration judgements recorded with the row (class_source column)
    'R-27': 'the OD-1 rules act on digital samples and do not depend on the analog gain: the calibration is not an input (analog agrees 06:28; protection to confirm)',
    'R-12': 'the 0.17 dB margin is computed at the calibrated FS: R-07 (Q) is an input, so the row is Q by propagation',
    'R-14': 'the 300 ohm target sits at the calibrated FS (R-12): Q by propagation',
}
# integration walk additions on top of the stream lists (the rule applied to what the documents say the claim rests on)
_A46 = 'A-46: E-3 timer reset level VCE(sat) <= 0.20 V at low current is not a datasheet bound (independent check 08:09)'
_TC = 'TYP: ESS full-scale tempco unpublished: post-calibration drift beyond the DS 3V3A term is covered only by the +1.16 dB margin (independent check 08:09 suggests Q; E kept: no measured value is relied on)'
WALK_EXTRA = {
    'R-20': [_A46], 'R-21': [_A46], 'R-22': [_A46], 'R-23': [_A46], 'R-61': [_A46], 'R-74': [_A46],
    'R-26': [_A46, _TC], 'A-31': [_A46, _TC],
    'R-57': [_A46, 'CON: the boot self-test words are PAIRWISE: balanced words cannot separate LP+ from LN-, so a single dead channel or a one-sided reference fault (e.g. R937 or R939 open) is masked - stated as a limitation (option A; per-channel options B / C for the owner, issue 3c); the (e) word is +-0.55 FS calibrated (pair >= 2.27 V, +250 mV over V_L max 2.016 V; OR silent), +-0.85 FS at the default; window 19.5-24.2 ms, pass 18-26 ms',
             'MEAS: per-channel coverage comes only from the production per-leg injection (owner items 3b / 3c); a dead channel is masked by its mate on the same N6_OL base; the independent firmware tiers still cover single-leg faults (T1 >= 1 V within 218 ms) - stated limitation (option A), options B / C for the owner'],
    'R-40': ['DS: 5V_SYS min 4.318 V at the final loads, 4.303 V with the J101 contact drop (U502 fed from VBUS ahead of U102 since E-16; power 06:43): the 4.30 V condition of the row holds'],
}
WALK_NOTE.update({
    'R-57': 'boot self-test pairwise (protection 08:20): per-channel coverage rests on the production per-leg injection -> MEAS -> Q; owner items 3b / 3c',
    'R-26': 'independent check (08:09): Q if the over-temperature compliance rested on the measured calibrated level / ESS tempco; kept E - the +1.16 dB SCOPE margin covers the calibration window 7 x, the unpublished ESS tempco is an E input; protection agrees (08:46); orchestrator may overrule',
    'A-31': 'as R-26 (independent check 08:09)',
    'R-34': 'split per power R10: gating stays here (G); the S4 budget is A-41 (E); traceability text to drop the S4 clause at the final rebuild',
})
# ---- R11 (26 Sep 2026): the amendment after the independent summary check (docs/delta_r10_final.md Part A, A1-A10) and the
#      schematic-capture review (decisions_r10 SE-1...SE-8). Applied over the R10 lists before they are merged; texts follow the delta.
def _r11_set(stream, rid, old, new):
    lst = STREAM_R10[stream][rid][1]
    hits = [i for i, t in enumerate(lst) if t.startswith(old)]
    assert len(hits) == 1, ('R11 input not found once', rid, old, hits)
    lst[hits[0]] = new


def _r11_add(stream, rid, new):
    lst = STREAM_R10[stream][rid][1]
    if new not in lst:
        lst.append(new)


_TL = 'ASSUMP: OR test line (PC15 / N6_ORTEST) low at <= 10 mV (<= 5 uA): V_OR- rests on it (p21 c1; delta A3)'
_r11_set('protection', 'R-20', 'CON: DC >= 2 V removed',
         'CON: DC >= 2 V removed <= 27.2 ms from every reachable state (rail-bounded, b3; 27.1 ms with pre-fault content at or below the calibrated '
         'ceiling, b2), single leg, any partner content: OR U611/U612 (330 k / 1 nF) -> E-3 timer -> H -> switch; margin 73 %')
_r11_add('protection', 'R-20', _TL)
_r11_set('protection', 'R-21', 'CON: DC >= 1 V removed',
         'CON: DC >= 1 V removed <= 102.7 ms from every reachable state (rail-bounded, b3; 101.3 ms with pre-fault content at or below the calibrated '
         'ceiling, b2): LPW U613-U620 (1 M / 3.3 nF C0G; V_LL +0.279...0.322 / -0.283...-0.324 V; T_P2 51.3-68.5 ms) -> E-3; margin 59 %')
_r11_set('protection', 'R-22', 'CON: rail-stuck SE',
         'CON: rail-stuck SE 26.48 / 13.24 mJ at 16 / 32 ohm at 4.049 V and 24.78 / 12.39 mJ at 3.915 V (rail-bounded, b3), removal <= 25.9 ms, any partner '
         'content (with pre-fault content at or below the calibrated ceiling, b2: 26.40 / 13.20 and 24.69 / 12.35 mJ, <= 25.8 ms); margin 12 %')
_r11_add('protection', 'R-22', _TL)
_r11_set('protection', 'R-23', 'CON: balanced sweep',
         'CON: balanced sweep over every level up to the swing limit (no calibration input): 16 ohm 26.08 mJ at 1.008 V per leg, 102.7 ms (rail-bounded, b3; '
         '25.70 mJ with pre-fault content at or below the calibrated ceiling); 32 ohm 14.87 mJ at the fallback swing limit / 13.67 mJ released (E-3 path)')
_r11_set('protection', 'R-61', 'CON: E-3 removes frozen codes',
         'CON: E-3 removes frozen codes with |pair| > 2.016 V (|leg| > 1.008 V) in <= 25.4 ms; LPW removes 0.34 V <= |leg| <= 1.008 V in <= 118.8 ms '
         '(the bound at the floor, c2; 3.43 / 1.72 mJ balanced 16 / 32 ohm); energies as R-23 (without the swing credit: A-45)')
_r11_set('protection', 'R-26', 'CON: margins 6.4 / 5.7 / 4.3 %',
         'CON: margins 6.4 / 5.7 / 4.3 % (2.192 / 2.230 / 2.325 V per leg); FS squares 21.4 / 25.6 Hz; the tested FS 20 Hz burst and polarity-reversal '
         'waveforms do not trip; one FS 20 Hz square cycle and the asymmetric 2nd-harmonic wave trip E-3 (pre-existing)')
_r11_set('protection', 'A-43', 'ASSUMP: TLV1704 tpd', 'ASSUMP: TLV1704 tpd <= 5 us (OR / E-3 comparators; no maximum published)')
_r11_set('protection', 'A-43', 'ASSUMP: LPW timer-node leakage',
         'ASSUMP: LPW timer-node leakage <= 0.1 uA: the capping input of T_P2 51.3-68.5 ms (the TLV3402 delays are separate: <= 0.9 ms each, 3 x typical, A-04)')
_r11_set('protection', 'A-44', 'CON: OR (U611/U612',
         'CON: OR (U611/U612, 330 k / 1 nF) V_OR +1.764...1.964 / -1.762...-1.959 V; LPW (U613-U620, 1 M / 3.3 nF) V_LL +0.279...0.322 / -0.283...-0.324 V '
         '(0.279-0.324 V on input bias alone), T_P2 51.3-68.5 ms, reset <= 9.6 ms; content boundary stated on the timer: a mute can occur once the 3.3 ms-filtered '
         'leg tap has been beyond +-V_LL for >= 70.8 ms, and will occur after 91.9 ms plus the amplitude-dependent tap crossing (unbounded near V_LL; +11.6 ms at '
         '0.5 V) and <= 1.8 ms comparator delays; in raw-leg terms a FS excursion can mute after >= 62.9 ms')
_r11_add('protection', 'A-44',
         'ASSUMP: 10 nA tap surface-leakage allowance (LPW level 0.269-0.334 V): steady offsets below 0.116 FS never mute (drift-ceiling FS 2.325 V) and at or '
         'above 0.162 FS mute on every unit (lowest FS 2.059 V); can / will mute per FS reference: 2.154 V 0.125 / 0.155, 2.192 V 0.123 / 0.152, 2.230 V '
         '0.120 / 0.150, 2.325 V 0.116 / 0.144, 2.059 V 0.130 / 0.162 FS; FS sines below 6.5 Hz (6.54 Hz with the allowance); squares up to about 7 Hz '
         '(0.8 / 0.5 / 0.35 V squares 7.4 / 7.2 / 6.9 Hz; 0.30 V squares up to 6.7 Hz) (p21b d3; delta A8)')
_r11_add('protection', 'A-44', _TL)
_R11_NEW = {
    'A-43': ('A-43', 'F-1 comparator timing and LPW node leakage (assumption)',
             'LPW timer T_P2 51.3-68.5 ms rests on the assumed LPW timer-node leakage <= 0.1 uA; the comparator delays are separate: TLV3402 (LPW level / timer '
             'outputs) <= 0.9 ms each (3 x typical, A-04); TLV1704 (OR / E-3) tpd <= 5 us assumed (no maximum published)',
             'protection p21 design basis (no maxima published)', 'LPW timer T_P2 and OR / LPW trip timing at 0 / 50 C on the first boards'),
    'A-44': ('A-44', 'LPW / OR detectors and the new content boundary (adopted by default)',
             'OR V_OR +1.764...1.964 / -1.762...-1.959 V (E: V_OR- assumes the OR test line low at <= 10 mV); LPW V_LL 0.279-0.324 V on input bias alone, '
             '0.269-0.334 V with the 10 nA leakage allowance, T_P2 51.3-68.5 ms, reset <= 9.6 ms; content boundary stated on the timer: a mute can occur once the '
             '3.3 ms-filtered leg tap has been beyond +-V_LL for >= 70.8 ms, and will occur after 91.9 ms plus the amplitude-dependent tap crossing (unbounded near '
             'V_LL; +11.6 ms at 0.5 V) and <= 1.8 ms comparator delays; in raw-leg terms a FS excursion can mute after >= 62.9 ms; steady offsets below 0.116 FS '
             'never mute and at or above 0.162 FS mute on every unit (can / will per FS reference: 2.154 V 0.125 / 0.155, 2.192 V 0.123 / 0.152, 2.230 V 0.120 / '
             '0.150, drift ceiling 2.325 V 0.116 / 0.144, lowest unit 2.059 V 0.130 / 0.162 FS); examples: FS sines below 6.5 Hz (6.54 Hz with the allowance), '
             'squares up to about 7 Hz (0.8 / 0.5 / 0.35 V squares 7.4 / 7.2 / 6.9 Hz; 0.30 V squares up to 6.7 Hz)',
             'protection p21 (c1), p21b (d2)/(d3)', 'sub-20 Hz content and offset tests at bring-up'),
}
assert set(_R11_NEW) <= {t[0] for t in NEW_R10}
NEW_R10 = [_R11_NEW.get(t[0], t) for t in NEW_R10]
_st = [r for r in csv.DictReader(open(os.path.join(HERE, '..', 'parts', 'stress_table.csv'), encoding='utf-8')) if r['status'] == 'current'] \
    if os.path.exists(os.path.join(HERE, '..', 'parts', 'stress_table.csv')) else []
if _st:   # R-38 from the current stress rows (T1 re-run with the R11 connector rows)
    _vc = {v: sum(1 for r in _st if r['verdict'] == v) for v in ('OK', 'AVAIL', 'THIN', 'DATA-GAP', 'FAIL')}
    INPUTS['R-38'][0] = (f"DS: part ratings (parts stress table: {len(_st)} current rows, OK {_vc['OK']}, AVAIL {_vc['AVAIL']}, FAIL {_vc['FAIL']}; "
                         f"every F-1 part covered, onsemi Q623-Q627 rows OK; R11 connector rows J101 / J701 / J702)")
    INPUTS['R-38'][1] = f"ASSUMP: DATA-GAP ({_vc['DATA-GAP']}) and THIN ({_vc['THIN']}) rows rest on missing or assumed data; the E-3 reset level is E via A-46"
# SE-9 / SE-10 (maker drawings supplied by the owner, 26 Sep 2026 ~15:15 UTC; delta_r10_final Part E): the J701 / J702 maps are documented from
# the maker drawings (no longer provisional); G-2 confirms them on two samples. Supersedes the SE-4 / SE-5 wording of R-47 where they differ.
INPUTS['R-47'] = ['MEAS: connector pin maps: gates G-1 / G-2 / G-3, two samples each (J701 / J702 maps documented from the maker drawings supplied on 26 Sep 2026: '
                  'the G-Switch drawing C-GT03321667P-01 confirms the owner-approved J701 12-pad map, pads 11/12 = Contact H mounting tabs, NC but soldered; '
                  'the HRO PJ-332A drawing gives the J702 map 1 sleeve GND, 2 ring 2 GND, 3 ring 1 JACK_RP, 4 tip JACK_LP, 5/6 break contacts NC; '
                  'G-2 confirms both on two samples; SE-4 / SE-7 / SE-9 / SE-10)']
INPUTS['R-70'] = ['PROC: OPEN process item until JLCPCB confirms SE-1 / SE-2 in writing (G-6): soldering of the J101 shell stakes S1-S4 and the J702 slot '
                  'terminals 1/2 (the two GND terminals per the maker drawing, SE-9: ground and mechanical retention only); owner hand-solder fallback (SE-8)']
WALK_NOTE.update({
    'R-47': 'SE-4 / SE-5 / SE-7 / SE-8 (schematic-capture review, 26 Sep 2026) and SE-9 / SE-10 (maker drawings, 26 Sep 2026): the J701 map confirmed by the '
             'G-Switch drawing (pads 11/12 = mounting tabs), the J702 map from the HRO drawing (pins 5/6 = break contacts, NC) and the G-2 record procedure',
    'R-70': 'SE-8 (schematic-capture review, 26 Sep 2026): G -> open process item until JLCPCB confirms SE-1 / SE-2 in writing (class counts G 14 -> 13, - 4 -> 5)',
})
QTEST_R11 = {
    'R-47': 'G-1 continuity (two samples, J101 incl. S1-S4) and G-3 1:1 overlay (J101; the J701 slots and peg holes per the G-Switch drawing; the J702 slots '
            'and peg holes); G-2 record on two samples of each jack confirming the maker-drawing maps (no plug / plug inserted / slow insertion; J702 with TRS and '
            'any allowed TRRS plug: tip, ring 1, ring 2, sleeve and the break contacts 5/6 opening on insertion; internally common terminals; J701 pads 11/12 '
            'common with the sleeve / bushing or not)',
    'R-70': 'JLCPCB written answer before the order (G-6): can the Standard top-side PCBA solder J101 S1-S4 and J702 pads 1/2, with F.Paste apertures or an order '
            'remark, and which aperture geometry / hand-solder step; else the owner fallback (hand-solder from L4 before the first plug-in)',
}
QSTAT_ROW = {'R-70': 'OPEN process item: open until JLCPCB confirms in writing how the J101 shell stakes S1-S4 and the J702 slot terminals are soldered '
                     '(G-6; SE-1 / SE-2); owner fallback at no cost unless JLCPCB quotes a hand-solder step'}
# R11 strict guards: R9-era protection strings, the old J701 map, the old assembly / self-test / timing / content wording. The register rows
# are checked with STALE_R10 (strict); the merged BOM, the current stress rows and the cost report are scanned at the end (strict asserts).
R11_STALE = [
    (r'\b23\.2 ms|\b23\.23\b|\b5\.8 %|\b8\.1 %|\b27\.5 mJ|\b14\.43\b|\b20\.0-22\.2\b',
     'R9-era E-3 figures superseded by p21: T_P 19.50-23.37 ms; 20 Hz sine margins 6.4 / 5.7 / 4.3 %; worst 26.08 / 13.67 mJ balanced, 26.48 / 13.24 mJ rail-stuck'),
    (r'pin 2 (?:->|→) JACK_LN|pin 4 (?:->|→) JACK_RN', 'J701 follows the owner-approved 12-pad map (SE-4)'),
    (r'no THT part in the JLCPCB order', 'no through-hole-only part in the JLCPCB order; J101 / J702 mix SMT lands and plated terminations (SE-8)'),
    (r'full coverage', 'self-test: all implemented (pairwise) tests every boot, 3.68 s (delta A9)'),
    (r'10 x typ|10 × typ', 'the "comparator delay 10 x typical" wording is deleted (delta A4)'),
    (r'offset (?:>=|≥) ?0\.145 FS', 'steady offsets: below 0.116 FS never, from 0.162 FS on every unit (delta A8)'),
    (r'(?<!tested FS 20 Hz )(?<!tested full-scale 20 Hz )bursts and polarity reversals do not trip', 'the tested FS 20 Hz burst and polarity-reversal waveforms do not trip (delta A7)'),
    (r'provisional until G-2|role unconfirmed|no net until (?:the )?G-2|carry no net until|maps? (?:stays?|are|were) (?:already )?provisional|maker drawings? image-only|'
     r'measured pin \+ 0\.2|hole / peg sizes and pads|sleeve (?:GND |ground )?is on pin 4|\b1 tip\b|pin 1 tip|Terminal [56]\b|PIN NUMBER PROVISIONAL',
     'J701 / J702 maps documented from the maker drawings (SE-9 / SE-10: J702 1 sleeve GND, 2 ring 2 GND, 3 ring 1 JACK_RP, 4 tip JACK_LP, 5/6 break contacts NC); G-2 confirms'),
]
R11_EXT_PATS = [R11_STALE[0], R11_STALE[1], R11_STALE[2], R11_STALE[7]]   # scanned in the merged BOM, the current stress rows and the cost report (+ SE-9: merged netlist)


def r11_every_case(text):
    """'every case meets 30 / 15 mJ' is allowed only with its exception (A-45) stated right after it (delta A5)."""
    return [m.group(0) for m in re.finditer(r'every (?:calculated )?case meets 30 / 15 mJ', text)
            if not re.search(r'exception|A-45', text[m.end():m.end() + 400])]


# text a row must no longer carry once its claim was split or re-scoped (strict mode asserts)
TEXT_MUST_NOT = {'R-34': (r'S4 7\d\d', 'the S4 budget moved to A-41 (power R10 split)')}
TEXT_MUST_NOT['R-24'] = (r'from any state', 'independent check 08:22: state the tier deadlines for the swept history set (independent model 604.0 ms / 2.367 s; the 3 s requirement holds)')
for _r in ('R-20', 'R-21', 'R-22', 'R-26', 'R-61', 'R-66'):
    TEXT_MUST_NOT[_r] = (r'leg window|R601|C601|X-9', 'the F-1 OR / LPW detectors replaced the leg windows (R601-R604 / C601-C604 removed)')
CONFLICTS, STATED = [], {}
for _stream, _lst in STREAM_R10.items():
    for _rid, (_scls, _ins, _note) in _lst.items():
        _tag = f'{_stream} list R10' + (f' ({_note})' if _note else '')
        if _rid in STATED:                 # a row in two lists: union of the inputs, both stated classes are checked
            INPUTS[_rid] += [x for x in _ins if x not in INPUTS[_rid]]
            SOURCE[_rid] = SOURCE[_rid].replace('; integration walk', '') + ' + ' + _tag + '; integration walk'
        else:
            INPUTS[_rid] = list(_ins)
            SOURCE[_rid] = _tag + '; integration walk'
        STATED.setdefault(_rid, []).append((_stream, _scls))
for _rid, _extra in WALK_EXTRA.items():
    INPUTS[_rid] = INPUTS[_rid] + [x for x in _extra if x not in INPUTS[_rid]]

_derived = {}


def derive(rid, stack=()):
    """-> (class, capping inputs, [(class, input)]) from the recorded inputs; recursive over row references."""
    if rid in _derived:
        return _derived[rid]
    if rid in stack:
        raise SystemExit('evidence cycle: ' + ' -> '.join(stack + (rid,)))
    ins = INPUTS.get(rid)
    if not ins:
        raise SystemExit(f'{rid}: no inputs recorded (every row must record its inputs)')
    marks = []
    for tok in ins:
        k = tok.split(':', 1)[0].strip()
        if k in KIND:
            c = KIND[k]
        elif REFPAT.match(k):
            if k not in INPUTS:
                raise SystemExit(f'{rid}: input {k} is not a register row')
            c = derive(k, stack + (rid,))[0]
        else:
            raise SystemExit(f'{rid}: unknown input kind {k!r} in {tok!r}')
        marks.append((c, tok))
    tech = [c for c, _ in marks if c != '-']
    cls = max(tech, key=RANK.get) if tech else '-'
    cap = [t for c, t in marks if c == cls] if cls in ('E', 'Q') else []
    _derived[rid] = (cls, cap, marks)
    return _derived[rid]


# calculation scripts that combine the inputs (as named by the stream lists, R10)
SCRIPTS = {
    'R-32': 'power c17', 'R-33': 'power c17', 'R-45': 'power c17', 'A-24': 'power c17', 'R-34': 'power c17, c20 a', 'A-41': 'power c17, c20 a',
    'R-36': 'power c22 s5; digital firmware_sequences 19', 'R-37': 'power c10, c22', 'R-43': 'power c14', 'R-53': 'power c14', 'R-44': 'power c14, c21',
    'R-52': 'power c22 s3', 'A-19': 'power c22 s3', 'R-67': 'power c20 b, c22', 'A-17': 'analog r9_fixes E-8 (register); power c21 E-8 (cross-check)', 'A-20': 'power c10',
    'A-27': 'power c22 s1, s6', 'A-28': 'power c22 s1, s6', 'R-35': 'power c22 s2', 'R-42': 'power c12 (1V3 range), c14 (order); protection p10',
    'R-54': 'power c20 c', 'A-42': 'power c21 R10 addendum; digital firmware_sequences 3, adc_settings 3', 'A-22': 'power c21 (R10)', 'R-13': 'power c17 s2; analog r9_fixes E-6, r10_fixes F-2',
    'R-14': 'power c17 s2; analog r9_fixes E-6, r10_fixes F-2', 'R-73': 'power c17, c21', 'A-35': 'analog r2_common, r2_power s1-2, r9_fixes E-6, r10_fixes F-2; power c17 s2',
    'R-07': 'analog analog_budget s1, r10_fixes F-5; digital firmware_sequences 20', 'R-08': 'analog analog_budget s1, r10_fixes F-5',
    'R-09': 'analog r2_power s3-5, r10_fixes F-2', 'R-10': 'analog r2_power s3-5, r10_fixes F-2', 'R-11': 'analog r2_power s3-5, r10_fixes F-2',
    'R-12': 'analog r2_power s3-5, r10_fixes F-2 / F-5', 'R-16': 'analog analog_budget s7, stability_switch', 'R-18': 'analog r2_switch s2, analog_budget s10',
    'R-19': 'analog analog_budget s5, r9_fixes E-4', 'R-31': 'analog unplug_model_r3; power c14', 'A-36': 'analog stability_switch, models_v, calibrate_opa1622',
    'A-37': 'analog stability_switch', 'A-38': 'analog stability_iv', 'A-40': 'digital firmware_sequences 20; analog r10_fixes F-5',
}
QSTAT = {'Q': 'OPEN qualification obligation: open until the measurement record exists (no board built yet; nothing has passed)',
         'E': 'estimate: holds as far as the capping input(s); the listed test is a planned confirmation (no result yet)',
         'G': 'guaranteed by worst-case calculation from limits; the listed test verifies, it is not an input',
         '-': 'n/a (process / documentation)'}

rows = list(csv.reader(open(os.path.join(HERE, 'traceability.csv'), encoding='utf-8')))
out = [['id', 'requirement_or_limit', 'value', 'class', 'capped_by', 'inputs', 'calculation', 'evidence', 'qualification_test',
        'qualification_status', 'class_v1.0', 'class_source']]
TEXT = {}   # id -> text that states the class-relevant claims (value, label, margin, status)


QTEST_R10 = {   # qualification tests restated by the R10 stream lists
    'R-20': '2.00 V per leg and polarity -> removal 19.5-27 ms; 3.8 V with FS 100 Hz content on the partner leg -> <= 27 ms (p21)',
    'R-21': '0.35 V -> 76-105 ms; FS 20 Hz for 1 s, then +0.97 V -> <= 102 ms (p21)',
    'R-23': 'balanced +-x injection from the p21 history states (after a 20 Hz half-cycle, pre-charged sub-threshold DC, just above the floor); E-3 T_P at 50 C (19.50-23.37 ms)',
    'R-26': 'FS 20 Hz sine at the calibrated level: no trip; FS squares 21.4 Hz mute, 26 Hz no mute; uncalibrated board at -4.5 dB (p21b)',
    'R-57': 'boot self-test on every board: (e) 18-26 ms, (f) LPW 65-110 ms, (g) OR 18-32 ms; total 3.68 s, or 2.96 s rotating (owner choice); PB0 low after each self-test trip',
    'A-31': 'FS 20 Hz sine at the calibrated level: no trip; FS squares 21.4 Hz mute, 26 Hz no mute (p21b)',
}
QTEST_R10.update(QTEST_R11)


def emit(rid, req, val, evidence, qtest, v10):
    qtest = QTEST_R10.get(rid, qtest)
    cls, cap, marks = derive(rid)
    capped = '; '.join(cap) if cap else ('all inputs G (datasheet limits, construction, G rows)' if cls == 'G' else 'process / documentation')
    ins = ' | '.join(f'{t} [{c}]' for c, t in marks)
    src = SOURCE.get(rid, 'integration walk R10') + (f'; note: {WALK_NOTE[rid]}' if rid in WALK_NOTE else '')
    out.append([rid, req, val, cls, capped, ins, SCRIPTS.get(rid, ''), evidence, qtest, QSTAT_ROW.get(rid, QSTAT[cls]), v10, src])


for r in rows[1:]:
    rid, req, feat, val, margin, label, src, status = r[:8]
    v10, _flag, qtest, _r9 = C.get(rid, ('?', '', '', ''))
    emit(rid, req, val, f'{label}; {src}; feature: {feat}; margin: {margin}; status: {status}', qtest, v10)
    TEXT[rid] = ' / '.join((feat, val, margin, label, status))
for e in EXTRA:   # (id, requirement/limit, value, class, evidence, flag note, qualification test, r9 status)
    val = EXTRA_R10_VALUE.get(e[0], e[2])
    emit(e[0], e[1], val, e[4], e[6], e[3])
    TEXT[e[0]] = ' / '.join((val, e[4]))
TRACE_IDS = {r[0] for r in rows[1:]}
for rid, req, val, ev, qt in NEW_R10:
    if rid in TRACE_IDS:              # moved into traceability.csv (e.g. R-74 at the final rebuild): the traceability row wins
        continue
    emit(rid, req, val, ev, qt, 'new (R10)')
    TEXT[rid] = ' / '.join((val, ev))

# ---- R10 guards
missing = [r[0] for r in rows[1:] if r[0] not in C]
assert not missing, missing
extra_inputs = sorted(set(INPUTS) - {x[0] for x in out[1:]})
assert not extra_inputs, f'inputs recorded for rows that do not exist: {extra_inputs}'
G_HIDDEN = re.compile(r'\btyp\b|typical|ASSUMP|\[PH\]|planning value|estimat|assumed|scaled|reconstruct', re.I)
CLAIM_G = re.compile(r'\[G\]|\bG \+|met \(G\)|\(G/E\)')
warn_g = [(x[0], G_HIDDEN.search(TEXT[x[0]]).group(0)) for x in out[1:] if x[3] == 'G' and G_HIDDEN.search(TEXT[x[0]])]
SCOPED_G = re.compile(r'\[G\][^|]{0,80}\[[EQ]\]')        # '5.61 mV [G]; with DAC terms 7.73 mV [E]': a correctly scoped sub-result
warn_claim = []
for x in out[1:]:
    _m = CLAIM_G.search(SCOPED_G.sub('', TEXT[x[0]])) if x[3] in ('E', 'Q') else None
    if _m:
        warn_claim.append((x[0], x[3], _m.group(0)))
for rid, lst in STATED.items():
    dcls = derive(rid)[0]
    for stream, scls in lst:
        if scls != dcls:
            CONFLICTS.append(f'{rid}: {stream} states {scls}, the recorded inputs give {dcls} ({"; ".join(derive(rid)[1]) or "all G"})')
warn_text = [(rid, why) for rid, (pat, why) in TEXT_MUST_NOT.items() if rid in TEXT and re.search(pat, TEXT[rid])]

# ---- stale-value guard (session 14): superseded values that must never reach the register. The final values live in
# traceability.csv (patched by _work/r9/fix_trace_final.py) and in the tables above; a hit aborts the build.
import re
STALE = [
    (r'390\.4', 'High IOS min is 395.4 mA'), (r'177\.9 mA', 'Default IOS min is 180.05 mA'),
    (r'>= 4\.0 mA', 'Default margin is +1.23 mA'), (r'178\.8[145]', 'Default need is 178.82 mA'),
    (r'\+1\.2[158] mA', 'Default G margin is +1.23 mA'), (r'4\.81 k', 'R509 is 4.75 k'),
    (r'\b8 % / 4 %', 'E-3 energy margins are 8.3 % / 3.5 %'), (r'integration calc|CALC integration', 'write "worst-case calculation"'),
    (r'TPS7A20', 'U502 is the TPS70933'), (r'109 rows|rows 109|150 current', 'stress table: 165 current rows'),
    (r'80 x 60|80 × 60', 'board is 100 x 80 mm (E-19)'), (r'16\.99', 'hard-short kick is 17.08 V'),
    (r'D103-D105|U502/U302/U503', 'D103 deleted; D104/D105 on U302/U503'), (r'\b8\.1 %', 'E-3 sine margin is 5.8 %'),
    (r'ECH-U1H223', 'C_T is ECH-U1H224GX9 (2416)'), (r'3\.006|3\.125 V', 'U605 fall 2.970-3.122 V'),
    (r'126 / 152|0\.118|1\.297', 'round-3 values superseded (R3.17 / VE-14)'), (r'<= 8\.45 ms', 'suspend level <= 8.75 ms'),
    (r'5\.315', 'LED current min ~5.26 mA'), (r'65\.6 / 80\.2|9\.23 / 18\.45', 'E-4 offset 7.73 / 15.47 mV'),
    (r'758\.11|741\.89|\+112 mA', 'S4 is 760.76 mA'),   # R10: '117 lines' removed - the value check decodes 117 lines again (F-1 parts)
    (r'490\.80|342\.28|357\.62|350\.43|2\.4965|493\.42|497\.92|348\.68|765\.2\b', 'final S-states (power c17)'),   # R10: 364.05 (NDK S3f) is current again
    (r'45-120 ms', "self-test a' window is 70-140 ms"), (r'x11 at 60 C|at 60 C \(x11\)', 'Q507: 50 C, hot leakage estimated'),
    (r'minor: minor', 'duplicated flag prefix'), (r'T_START 60', 'T_START is 40 ms'),
    (r'rail-stuck SE 12\.8 / 6\.4', 'rail-stuck SE is 25.6 / 12.8 mJ (p03)'), (r'2\.30 mW', 'residual <= 2.31 mW (p06)'),
    (r'6\.7 ohm', 'no clipping up to >= 6.85 ohm (c04 VIN)'), (r'minor: (process|documented)', "class '-' rows carry n/a"),
]
# R10 superseded values: warned now, asserted by --strict (traceability.csv is rewritten at the final rebuild)
STALE_R10 = [(r'178\.82\b|178\.83\b|178\.79\b|178\.794|178\.996|178\.829', 'Default need is 178.96 mA (analog F-1 final, 06:53)'),
             (r'\+1\.23 mA|\+1\.22 mA|\+1\.2565|\+1\.06 mA|\+1\.055', 'Default margin is +1.09 mA (E)'),
             (r'73\.51|73\.48', 'quiescent 5V_ANA is 73.65 mA (analog F-1)'), (r'88\.2[14]\b', 'DAC in reset 88.38 mA (analog F-1)'), (r'\+52\.\.\.\+98|\+52\.\.\+98', 'brown-out margin +58...+105 mV (power R10)'),
             (r'344\.17|359\.50|352\.31|348\.67|364\.00|147\.69|344\.22|359\.55|352\.36|348\.72|364\.05|147\.64|493\.45|497\.95|760\.76|765\.26|\+6\.55 mA|\+2\.05 mA',
              'F-1 final states: S2 344.39 / S3 493.46 / S3f 359.72 / S4 760.77 / S5 352.53 (+147.47); NDK 348.89 / 497.96 / 364.22 / 765.27; S3 +6.54 / +2.04 mA (power 07:00)'),
             (r'115\.4 C|\+9\.6 C|158\.6 mA|87\.7 C', 'thermal: LM27762 overload 116.1 C / +8.9 C; TLV767 S5 165.0 mA / 88.8 C (power 06:35)'),
             (r'fill ~53 %|~61 % at 100 x 70', 'placement fill 59.6 % at 100 x 80 mm (parts R10: Z4 52 %, Z7 59.0 %)'),
             (r'0\.324 / 0\.648|0\.648 V|15\.8 / 7\.9|14\.3 / 7\.1', 'requirement floor 0.34 / 0.68 V; below-floor 17.4 / 8.7 mJ (pair), 14.3 / 7.2 mJ (leg) (protection 08:25)'),
             (r'0\.176 / 0\.193|0\.177 / 0\.194|0\.312 / 0\.309|0\.999 / 1\.010|1\.003 / 1\.017|2\.33 mW|2\.35 mW', 'tier levels T1 1.001 / 1.015, T2 0.313 / 0.312, T3 0.178 / 0.195 V; residual 2.43 mW (protection p21c 08:37)'),
             (r'<= 2\.25 s|<= 574 ms|<= 208 ms', 'the v1.0 rest-state tier deadlines (p06) are replaced by the p21c history values (218 ms / 603 ms / 2.36 s)'),
             (r'2\.49 / 2\.37|2\.49/2\.37|2\.47 / 2\.35|2\.47/2\.35', 'High R_NEG allowance at 4.40 V is 2.53 / 2.41 ohm (c15 convention A, LM27762 VIN 4.224 V; power 06:43)'),
             (r'\+58\.\.\.\+105|\+58\.\.\+105|4\.310 V|4\.294 V|\+63 mV|\+115 mV|\+100 mV', 'superseded by power 06:43 (5V_SYS 4.318 / 4.303 V, brown-out +67..+114 mV, ANA_SENSE +71 / +124 / +108 mV)'),
             (r'23\.23|27\.52|14\.47|27\.5 / 14\.5|19\.5-23\.2\b|51\.2 ms|111\.0 ms|25\.6 / 12\.8|21\.5 Hz|\b6\.2 %|25\.2 ms|1\.98 ms|2\.88-3\.11|0\.373 ms|2\.84 s|2\.31 mW|4\.014',
              'R9 protection values superseded by p21 (T_P 19.50-23.37 ms; 25.70 / 14.87 mJ; 27.1 / 101.3 ms; 26.40 / 13.20 mJ; squares 21.4 Hz; 25.4 ms; H 1.96 ms; HREF 2.883-3.029 V; 0.346 ms; 3.68 s; 2.33 mW; RAIL_DESIGN)')]
STALE_R10 += R11_STALE
hits_r10 = [(x[0], p, why) for x in out[1:] for p, why in STALE_R10 if any(re.search(p, str(c)) for c in x)]
hits_r10 += [(x[0], 'every case meets (no exception)', 'delta A5') for x in out[1:] if any(r11_every_case(str(c)) for c in x)]
if hits_r10:
    print('STALE (R10, fix traceability.csv at the final rebuild):', '; '.join(f'{i} /{p}/' for i, p, w in hits_r10))
hits = [(x[0], p, why) for x in out[1:] for p, why in STALE if any(re.search(p, str(c)) for c in x)]
assert not hits, 'stale values in the register: ' + '; '.join(f'{i} /{p}/ -> {w}' for i, p, w in hits)
OUTP = os.path.join(HERE, 'evidence_register.csv')
if '--out' in sys.argv:                  # R10: trial outputs outside the release file (e.g. _work/r10/...)
    OUTP = os.path.abspath(sys.argv[sys.argv.index('--out') + 1])
with open(OUTP, 'w', newline='', encoding='utf-8') as f:
    csv.writer(f).writerows(out)
cnt = Counter(x[3] for x in out[1:])
changed = [(x[0], x[10], x[3], x[4]) for x in out[1:] if x[10] != x[3]]
pending = [s for s in ('power', 'analog', 'protection') if s not in STREAM_R10]
print(f'{os.path.basename(OUTP)}: {len(out) - 1} rows; class {dict(sorted(cnt.items()))} (v1.0 register: G 49, E 49, Q 7, - 2); '
      f'Q = open qualification obligations: {cnt["Q"]}; class changed or new vs v1.0: {len(changed)}')
for rid, a, b, cap in changed:
    print(f'  {rid}: {a} -> {b}  capped by: {cap[:150]}')
if warn_g:
    print('GUARD G-hidden (G row whose text names an assumption/typical/model):', '; '.join(f'{r} /{m}/' for r, m in warn_g))
if warn_claim:
    print('GUARD text-claims-G (E/Q row whose traceability text still claims G; fix traceability.csv at the final rebuild):',
          '; '.join(f'{r} ({c}) /{m}/' for r, c, m in warn_claim))
if warn_text:
    print('GUARD split/re-scoped text (traceability.csv to change at the final rebuild):', '; '.join(f'{r}: {w}' for r, w in warn_text))
if CONFLICTS:
    print('STREAM-LIST CONFLICTS (derived class wins):', *CONFLICTS, sep='\n  ')
print('stream lists applied:', ', '.join(STREAM_R10) or 'none', '| pending:', ', '.join(pending) or 'none')
# ---- R11 external scan (strict): the R9-era strings, the old J701 map and "no THT part" in the merged BOM and the current stress rows;
#      "no THT part" in the cost report. Files are read relative to this script (project and package layouts are the same).
ext_hits = []
for _lab, _p, _pats, _only in (('merged BOM', os.path.join(HERE, 'bom_merged.csv'), R11_EXT_PATS, None),
                               ('stress table (current rows)', os.path.join(HERE, '..', 'parts', 'stress_table.csv'), R11_EXT_PATS, 'current'),
                               ('merged netlist (SE-9)', os.path.join(HERE, 'netlist_merged.csv'), [R11_STALE[7]], None),
                               ('cost report', os.path.join(HERE, 'cost_report.md'), [R11_STALE[2], R11_STALE[7]], None)):
    if not os.path.exists(_p):
        ext_hits.append(f'{_lab}: file missing')
        continue
    if _only:
        _cells = [(r['refs'], ' | '.join(str(v) for v in r.values())) for r in csv.DictReader(open(_p, encoding='utf-8')) if r.get('status') == _only]
    elif _p.endswith('.csv'):
        _cells = [(r[1] if len(r) > 1 else r[0], ' | '.join(r)) for r in csv.reader(open(_p, encoding='utf-8'))]
    else:
        _cells = [(f'line {i}', ln) for i, ln in enumerate(open(_p, encoding='utf-8').read().split('\n'), 1)]
    for _ref, _txt in _cells:
        for _pat, _why in _pats:
            _m = re.search(_pat, _txt)
            if _m:
                ext_hits.append(f'{_lab} {_ref}: /{_m.group(0)}/ -> {_why}')
print('R11 guard (merged BOM, current stress rows, cost report):', 'clean' if not ext_hits else f'{len(ext_hits)} hit(s)')
for _h in ext_hits:
    print('  ' + _h[:260])
if '--strict' in sys.argv:               # final R10 rebuild: no pending list, no text contradicting a class
    assert not (warn_g or warn_claim or warn_text or CONFLICTS or pending or hits_r10), 'strict mode: guards not clean'
    assert not ext_hits, 'strict mode (R11): superseded text in the merged BOM / current stress rows / cost report'
