import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""E-15 (R9) / F-3 (R10): build the calculation package <project>/calc_package_v11/ (zip with --zip).

R10: v1.1 goes to calc_package_v1.1/ (+ calc_package_v1.1.zip) so that v1.0 (calc_package/, calc_package.zip) stays untouched;
--dest DIR builds elsewhere (trials). The release-verification command verify_release.py (source integration/verify_release.py)
is shipped at the package root; INDEX.md lists (1) release calculations, verified by that command, and (2) historical
generators, kept for traceability only. Change-list baselines are shipped in integration/baselines/.

Collects every stream's scripts and outputs (power, protection, analog, digital, parts), the integration scripts and
data, and writes INDEX.md (key claim -> script -> output -> run command). All paths inside the package are relative:
absolute project paths in scripts are replaced by a package root computed from the script's own location, and in
text files by package-relative paths. Datasheet PDFs/text extracts and web caches are not copied (external sources).
Re-run after the round: python3 integration/build_calc_package.py [--zip] [--dest DIR]
"""
import os, re, shutil, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, '..'))
VERSION = '1.1'                     # R10: calculation package v1.1; v1.0 stays untouched in calc_package/ + calc_package.zip
DEST = os.path.join(PROJ, 'calc_package_v11')   # orchestrator 26 Sep: new folder calc_package_v11/, zip DAC_HPA_Calculation_Package_v1.1.zip
ZIP_NAME = 'DAC_HPA_Calculation_Package_v1.1.zip'
if '--dest' in sys.argv:            # R10: trial builds elsewhere (e.g. integration/_work/r10/...); the zip goes next to DEST
    DEST = os.path.abspath(sys.argv[sys.argv.index('--dest') + 1])
STREAMS = ['power', 'protection', 'analog', 'digital', 'parts']
SKIP_DIRS = {'__pycache__', 'web', 'sources', '_work', 'calc_package'}
SKIP_FILES = {'protection/p21b_run.log'}   # R10: a copy of a run's stdout, not a script output (protection 07:54)
TEXT_EXT = {'.py', '.sh', '.txt', '.json', '.csv', '.md', '.log'}
DS_EXT = {'.json', '.csv'}            # derived model data used by scripts (e.g. analog OPA1622 curve fits)
INTEGRATION_FILES = ['check_design.py', 'build_package.py', 'build_changes.py', 'cost_calc.py', 'build_evidence_register.py',
                     'build_calc_package.py', 'bom_merged.csv', 'netlist_merged.csv', 'nets_summary.csv', 'bom_changes_vs_v06.csv',
                     'build_package_out.txt', 'check_result.json', 'cost_report.md', 'traceability.csv', 'evidence_register.csv', 'bom_changes_vs_v09.csv', 'bom_changes_vs_v10.csv', 'design_v10_summary.md',
                     'consistency_log.md', 'design_v09_summary.md', 'decisions_r8b.md', 'decisions_r8c.md', '_diff_raw.json',
                     'design_v11_summary.md']
EXTRA_FILES = [('current/parts_list_current.csv', 'current/parts_list_current.csv'),          # v0.6 Parts List (build_changes diff input)
               ('integration/_work/r9/test_value_decode.py', 'integration/tests/test_value_decode.py'),
               ('integration/_work/r9/scan_parts_list_values.py', 'integration/tests/scan_parts_list_values.py'),
               ('r9/decisions_r9.md', 'r9/decisions_r9.md'), ('r9/reviews_r9.md', 'r9/reviews_r9.md'), ('r9/brief_r9_integration.md', 'r9/brief_r9_integration.md'), ('r9/review_r9_check.md', 'r9/review_r9_check.md'),
               ('integration/_work/r3/bom_merged_pre_R9.csv', 'integration/baselines/bom_merged_v0.9.csv'),   # build_changes vs-v0.9 input (R10 F-3)
               ('integration/_work/r10/bom_merged_v1.0.csv', 'integration/baselines/bom_merged_v1.0.csv'),   # v1.0 merged BOM (change list vs v1.0)
               ('r10/decisions_r10.md', 'r10/decisions_r10.md'), ('r10/reviews_r10.md', 'r10/reviews_r10.md'),
               ('r10/history_check.py', 'r10/history_check.py'), ('r10/history_check_out.txt', 'r10/history_check_out.txt'),
               ('r10/railstuck_check.py', 'r10/railstuck_check.py'), ('r10/railstuck_check_out.txt', 'r10/railstuck_check_out.txt')]
ABS_V11 = PROJ.replace('\\', '/')                         # this project's absolute root
ABS_ANY = re.compile(r'external/[A-Za-z0-9_./\-]*')


def is_backup(name):
    return '.bak' in name or '_backup' in name


def rel_root(dst_rel):
    depth = len(os.path.normpath(dst_rel).split(os.sep)) - 1
    return '/'.join(['..'] * depth) if depth else '.'


def sanitize_py(src, dst_rel):
    """Replace absolute project paths in code by _PKG_ROOT (package root from __file__); other absolute paths -> external/."""
    if 'external/' not in src:
        return src
    s = src
    s = s.replace(_PKG_ROOT + '/external/input/', ABS_V11 + '/external/input/')        # external datasheet inputs (not included)
    esc = re.escape(ABS_V11)
    s = re.sub(r'([fF][rR]?|[rR][fF])([\'"])' + esc, r'\1\2{_PKG_ROOT}', s)      # f-strings
    s = re.sub(r'(?<![A-Za-z_])([rRbB]?)([\'"])' + esc, r'_PKG_ROOT + \1\2', s)  # plain / raw strings starting with the root
    s = s.replace(ABS_V11 + '/', '').replace(ABS_V11, '.')                    # remaining mentions (docstrings, comments)
    s = ABS_ANY.sub(lambda m: 'external' + m.group(0)[4:], s)
    hdr = ('import os as _os_pkg  # calc_package: package root from this file (no absolute paths)\n'
           f"_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '{rel_root(dst_rel)}'))\n")
    if s.startswith('#!'):
        first, rest = s.split('\n', 1)
        return first + '\n' + hdr + rest
    return hdr + s


def sanitize_text(t):
    t = t.replace(_PKG_ROOT + '/external/input/', 'external/input/')
    t = t.replace(ABS_V11 + '/', '').replace(ABS_V11, '.')
    return ABS_ANY.sub(lambda m: 'external' + m.group(0)[4:], t)


def copy(src_abs, dst_rel, log):
    dst = os.path.join(DEST, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    ext = os.path.splitext(src_abs)[1].lower()
    if ext in TEXT_EXT:
        t = open(src_abs, encoding='utf-8', errors='replace').read()
        t = sanitize_py(t, dst_rel) if ext == '.py' else sanitize_text(t)
        open(dst, 'w', encoding='utf-8').write(t)
    else:
        shutil.copy2(src_abs, dst)
    log[dst_rel.split('/')[0]] += 1


def main():
    import time
    for _ in range(5):                      # the project filesystem can race on large deletes
        if not os.path.isdir(DEST):
            break
        shutil.rmtree(DEST, ignore_errors=True)
        time.sleep(1)
    os.makedirs(DEST, exist_ok=True)
    log = collections.Counter()
    for s in STREAMS:
        base = os.path.join(PROJ, s)
        for dp, dn, fn in os.walk(base):
            dn[:] = [d for d in dn if d not in SKIP_DIRS and not d.startswith('_')]   # R10: '_' folders are stream scratch (e.g. power/_r10_repro)
            in_ds = os.path.basename(dp) == 'ds'
            for f in fn:
                ext = os.path.splitext(f)[1].lower()
                if is_backup(f) or ext not in TEXT_EXT or (in_ds and ext not in DS_EXT):
                    continue
                rel = os.path.relpath(os.path.join(dp, f), PROJ).replace(os.sep, '/')
                if rel in SKIP_FILES:
                    continue
                copy(os.path.join(dp, f), rel, log)
    for f in INTEGRATION_FILES:
        p = os.path.join(HERE, f)
        if os.path.exists(p):
            copy(p, 'integration/' + f, log)
    for src, dst in EXTRA_FILES:
        p = os.path.join(PROJ, src)
        if os.path.exists(p):
            copy(p, dst, log)
    # the E-1 self-tests read check_design.py relative to their own folder
    for t in ('test_value_decode.py', 'scan_parts_list_values.py'):
        p = os.path.join(DEST, 'integration', 'tests', t)
        if os.path.exists(p):
            s = open(p, encoding='utf-8').read().replace("os.path.join(os.path.dirname(__file__), '..', '..', 'check_design.py')",
                                                         "os.path.join(os.path.dirname(__file__), '..', 'check_design.py')")
            open(p, 'w', encoding='utf-8').write(s)
    # R10 F-3: the release-verification command sits at the package root
    if os.path.exists(os.path.join(HERE, 'verify_release.py')):
        copy(os.path.join(HERE, 'verify_release.py'), 'verify_release.py', log)
    write_index()
    # verification: no absolute path anywhere in the package
    bad = []
    for dp, dn, fn in os.walk(DEST):
        for f in fn:
            p = os.path.join(dp, f)
            try:
                if 'external/' in open(p, encoding='utf-8', errors='ignore').read():
                    bad.append(os.path.relpath(p, DEST))
            except Exception:
                pass
    n = sum(len(fn) for _, _, fn in os.walk(DEST))
    print(f'calc_package: {n} files ({dict(log)}); files with absolute paths: {bad or "none"}')
    if bad:
        return 1
    if '--zip' in sys.argv:
        import zipfile
        zp = os.path.join(os.path.dirname(DEST.rstrip('/\\')), ZIP_NAME) if '--dest' not in sys.argv else DEST.rstrip('/\\') + '.zip'
        with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
            for dp, dn, fn in os.walk(DEST):
                for f in sorted(fn):
                    full = os.path.join(dp, f)
                    z.write(full, os.path.join(os.path.basename(DEST.rstrip('/\\')), os.path.relpath(full, DEST)))
        print(f'zip: {zp} ({os.path.getsize(zp) / 1e6:.2f} MB)')
    return 0


# R10 F-3: INDEX.md has two lists.
# 1. Release calculations: key claim -> scripts -> outputs -> single-run command -> verify_release.py check id(s). Every one is
#    re-run by `python3 verify_release.py` (package root), which compares its outputs with the shipped files and the key
#    results with the document values.
# 2. Historical generators: kept for traceability, not verified, not guaranteed to re-run (reason given).
RELEASE = [
    ('Netlist/BOM consistency incl. the value-decodes-from-MPN check (E-1) and its self-test', 'integration/check_design.py; integration/tests/test_value_decode.py', 'integration/check_result.json', 'python3 integration/check_design.py power protection analog digital', 'I1, I2'),
    ('BOM/netlist reconciliation: merged BOM and netlist, cross-checks (counts in build_package_out.txt; incl. the 52 TP pads); independent re-check in verify_release', 'integration/build_package.py', 'integration/bom_merged.csv; netlist_merged.csv; nets_summary.csv; build_package_out.txt; _diff_raw.json', 'cd integration && python3 build_package.py', 'I3, I3b'),
    ('Change lists vs Parts List v0.6, vs the v0.9 set and vs the v1.0 release (baselines shipped in integration/baselines/)', 'integration/build_changes.py', 'integration/bom_changes_vs_v06.csv; bom_changes_vs_v09.csv; bom_changes_vs_v10.csv', 'cd integration && python3 build_changes.py', 'I4'),
    ('Cost report: an estimate until the supplier orders and the JLCPCB quote exist (F-6)', 'integration/cost_calc.py', 'integration/cost_report.md', 'cd integration && python3 cost_calc.py', 'I5'),
    ('Evidence register: classes derived from the recorded inputs (F-2 propagation; Q rows = open qualification obligations)', 'integration/build_evidence_register.py', 'integration/traceability.csv; integration/evidence_register.csv', 'cd integration && python3 build_evidence_register.py', 'I6'),
    ('Plug/adapter isolation 24/24 cases (four-leg switch)', 'protection/p02_connection_cases.py', 'protection/p02_connection_cases_out.txt', 'cd protection && python3 p02_connection_cases.py', 'P02'),
    ('I/V common-mode window (band, margins, stuck-pin coverage, CM-path energies)', 'protection/p04_cm_monitor.py', 'protection/p04_cm_monitor_out.txt', 'cd protection && python3 p04_cm_monitor.py', 'P04'),
    ('Photorelay drive, permit node H, switch open/close times', 'protection/p05_switch_drive.py', 'protection/p05_switch_drive_out.txt', 'cd protection && python3 p05_switch_drive.py', 'P05'),
    ('DC-sense networks, firmware tiers T1-T3, combined energy envelope', 'protection/p06_dcsense_tiers.py', 'protection/p06_dcsense_tiers_out.txt', 'cd protection && python3 p06_dcsense_tiers.py', 'P06'),
    ('Stream-guard proofs (round-3 rule, OD-1 rules P1-P4; 13.8 / 25.3 mJ; no-false-trigger boundary)', 'protection/p07_stream_guard.py; p15_od_guard.py; p16_od_p2_scan.py; p16b_od_p4_scan.py', 'protection/p07_stream_guard_out.txt; p15_od_guard_out.txt; p16_od_p2_scan_out.txt; p16b_od_p4_scan_out.txt', 'cd protection && python3 p15_od_guard.py', 'P07'),
    ('ADC2 sampling (settling, charge sharing) of the sense channels', 'protection/p09_adc_sampling.py', 'protection/p09_adc_sampling_out.txt', 'cd protection && python3 p09_adc_sampling.py', 'P09'),
    ('DAC-supply / MCLK supervisor, frozen-code removal, boot self-test windows', 'protection/p10_supervisor.py', 'protection/p10_supervisor_out.txt', 'cd protection && python3 p10_supervisor.py', 'P10'),
    ('R10 F-1 history-robust hardware protection: OR (U611/U612) and LPW (U613-U620) detectors + E-3, removal and energies from every reachable state, content boundary (sines >= 20 Hz, squares 21.4 / 25.6 Hz, LPW offsets with the 10 nA allowance), firmware tiers over the swept (finite) history set, hardware level floor 0.34 V per leg / 0.68 V pair, protection BOM/netlist rows, 32 ohm frozen-FS option study', 'protection/p21_r10_f1.py; p21b_r10_content.py; p21c_r10_tiers.py; p21d_r10_bom.py; p22_r10_fs32.py', 'protection/p21_r10_f1_out.txt; p21b_r10_content_out.txt; p21c_r10_tiers_out.txt; p21d_r10_bom_out.txt; p22_r10_fs32_out.txt; bom_rows.csv; netlist.csv', 'cd protection && python3 p21_r10_f1.py && python3 p21b_r10_content.py && python3 p21c_r10_tiers.py && python3 p21d_r10_bom.py && python3 p22_r10_fs32.py', 'P21'),
    ('E-16 suspend power cut: TPS70933, Q507, attach A 29.6 / B 20.1 uC, S6 2.2755 mA', 'power/calc/c22_e16_suspend_cut.py', 'power/calc/c22_e16_suspend_cut.out.txt; c22_results.json', 'cd power/calc && python3 c22_e16_suspend_cut.py', 'C22'),
    ('USB states S1-S6 and the U503 limits (R509 4.75 k: IOS 180.05 / 201.3 / 222.6 mA vs the Default need, register A-35); c17_basis.json = the one input set read by c04, c09, c10, c11, c14, c15, c16, c18 (run c03 -> c17 -> consumers)', 'power/calc/c17_budget_r3.py; c03_usb_budget_ilim.py; c16_r3_review_fixes.py', 'power/calc/c17_budget_r3.out.txt; c17_results.json; c17_basis.json; c03_usb_budget_ilim.out.txt; c03_results.json; c16_r3_review_fixes.out.txt; c16_results.json', 'cd power/calc && python3 c03_usb_budget_ilim.py && python3 c17_budget_r3.py && python3 c16_r3_review_fixes.py', 'C17, C03, C16'),
    ('R9 power checks (c21): E-5 suspend inventory, E-8 reverse bias, brown-out margin, E-6 Default numbers (R509 4.75 k)', 'power/calc/c21_r9_checks.py', 'power/calc/c21_r9_checks.out.txt; c21_results.json', 'cd power/calc && python3 c21_r9_checks.py', 'C21'),
    ('Attach inrush regions (USB-IF #45), C104 delay', 'power/calc/c02_attach_inrush.py', 'power/calc/c02_attach_inrush.out.txt', 'cd power/calc && python3 c02_attach_inrush.py', 'C02'),
    ('VBUS hard-short kick with D102, U102 IOS with R108 100 k, EN delay with R109 470 k, ANA_SENSE divider', 'power/calc/c20_ve_checks.py', 'power/calc/c20_ve_checks.out.txt', 'cd power/calc && python3 c20_ve_checks.py', 'C20'),
    ('Rail start-up with the X-8 reservoirs (T_START 40 ms); four appended runs (10 / 470 nF, reduced + timing)', 'power/calc/c18_x8_rail_start.py', 'power/calc/c18_x8_rail_start.out.txt; c18_10nF.json; c18_470nF.json; c18_10nF_timing.json; c18_470nF_timing.json', 'cd power/calc && rm -f c18_x8_rail_start.out.txt && for a in "10 reduced" "470 reduced" "10 timing" "470 timing"; do python3 c18_x8_rail_start.py $a; done', 'C18'),
    ('Discharge times (3V3A 0.385 ms, 3V3D 0.63 ms, 1V3 0.134 ms)', 'power/calc/c06_discharge.py', 'power/calc/c06_discharge.out.txt', 'cd power/calc && python3 c06_discharge.py', 'C06'),
    ('U503 TPS2596 limits (reads the c17 basis)', 'power/calc/c11_u503_tps2596.py', 'power/calc/c11_u503_tps2596.out.txt', 'cd power/calc && python3 c17_budget_r3.py && python3 c11_u503_tps2596.py', 'C11'),
    ('Regulator margins, thermal table, VBUS sense band, LM27762 envelopes', 'power/calc/c04_regulators.py; c10_thermal.py; c09_vbus_sense.py; c15_lm27762_headroom.py', 'power/calc/c04_regulators.out.txt; c10_thermal.out.txt; c09_vbus_sense.out.txt; c15_lm27762_headroom.out.txt', 'cd power/calc && python3 c10_thermal.py', 'C04'),
    ('Hard-unplug rail ordering, brown-out action before the MCU reset (288 corners)', 'power/calc/c14_unplug_order.py', 'power/calc/c14_unplug_order.out.txt', 'cd power/calc && python3 c14_unplug_order.py', 'C14'),
    ('Analog budget and offset: levels, swing, reset state, E-4 offset split (5.61 / 11.21 mV G; 7.73 / 15.47 mV with DAC terms), power tables, Default need', 'analog/scripts/analog_budget.py; r2_power.py; r9_fixes.py', 'analog/out/analog_budget.txt; offset_budget.csv; r2_power.txt; power_table.csv; headroom_table.csv; r9_fixes.txt', 'cd analog/scripts && python3 analog_budget.py && python3 r2_power.py && python3 r9_fixes.py', 'A1'),
    ('Hold-up at every hard unplug: I/V supply outlives 3V3A in 1,944 corners (X-8; 176 uF case)', 'analog/scripts/unplug_model_r3.py', 'analog/out/unplug_model_r3.txt', 'cd analog/scripts && python3 unplug_model_r3.py', 'A2'),
    ('OPA1622 macro-model calibration to the datasheet curves (typical-curve model: evidence class E)', 'analog/scripts/calibrate_opa1622.py; validate_opa1622.py', 'analog/out/calibrate_opa1622.txt; validate_opa1622.txt; analog/ds/opa1622_calibrated.json', 'cd analog/scripts && python3 calibrate_opa1622.py', 'A3'),
    ('Leg stability with the output switch (37 load cases x 4 models; PM >= 51.3 deg; model-based: E)', 'analog/scripts/stability_switch.py', 'analog/out/stability_switch.txt', 'cd analog/scripts && python3 stability_switch.py', 'A4'),
    ('I/V stability with the CM-summing load (1,080 corners; reconstructed OPA2210 shapes: E)', 'analog/scripts/stability_iv.py', 'analog/out/stability_iv.txt', 'cd analog/scripts && python3 stability_iv.py', 'A5'),
    ('R10 analog: F-5 leg peaks at 0 dBFS (uncalibrated, -4.5 dB default, calibrated), post-calibration drift, F-2 class sensitivities (RNEG needs, IQ/CP margins)', 'analog/scripts/r10_fixes.py', 'analog/out/r10_fixes.txt', 'cd analog/scripts && python3 r10_fixes.py', 'A7'),
    ('Pop bounds, DAC-pin safety, switch THD/Zout/crosstalk, round-3 fixes', 'analog/scripts/dac_timing_pop.py; dac_pin_safety.py; r2_switch.py; r3_fixes.py; protection/p01_switch_choice.py', 'analog/out/dac_timing_pop.txt; dac_pin_safety.txt; r2_switch.txt; r3_fixes.txt; protection/p01_switch_choice_out.txt', 'cd analog/scripts && python3 dac_timing_pop.py', 'A6'),
    ('Clock timing (I2S setup/hold 14.0 / 16.1 ns, link timing with U208, MCLK/FSR, jitter)', 'digital/clock_timing.py', 'digital/clock_timing_output.txt', 'cd digital && python3 clock_timing.py > clock_timing_output.txt', 'D1'),
    ('Firmware sequences (suspend level <= 8.75 ms, TSIGATT <= 23.9 ms, power-down order, E-2 re-arm), ADC settings, currents, levels, MCLK gate race, USB feedback', 'digital/firmware_sequences.py; adc_settings.py; currents.py; levels_and_pullups.py; mclk_gate_race.py; usb_feedback.py', 'digital/firmware_sequences_output.txt; adc_settings_output.txt; currents_output.txt; levels_and_pullups_output.txt; mclk_gate_race_output.txt; usb_feedback_output.txt', 'cd digital && python3 firmware_sequences.py > firmware_sequences_output.txt', 'D2'),
    ('Component stress table (FAIL 0)', 'parts/stress_calc.py', 'parts/stress_table.csv; parts/stress_calc_out.txt', 'cd parts && python3 stress_calc.py', 'T1'),
    ('PCBA class / ordering plan, placement density, value decode (parts; reads the stream BOMs)', 'parts/pcba_class_scan.py; placement_density.py; value_decode_check.py', 'parts/pcba_class_scan_out.txt; pcba_class_table.csv; placement_density_out.txt; value_decode_out.txt', 'cd parts && python3 pcba_class_scan.py', 'T2'),
    ('USB 90 ohm differential pair geometry (field solver on the nominal stack-up: E)', 'parts/usb_diffpair_impedance.py', 'parts/usb_impedance_out.txt; usb_impedance_out.json', 'cd parts && python3 usb_diffpair_impedance.py', 'T3'),
]
HISTORICAL = [
    ('protection/p19_r9_bom.py', 'R9 generator of the E-2/E-3 BOM/netlist rows (R665 check, self-test windows): reads bom_rows_ve.csv.bak and netlist_ve.csv.bak (pre-R9 stream files, not shipped); the R10 rows come from p21d (P21), checked by I1/I3; outputs p19_r9_bom_out.txt, p19_r9_e11_out.txt and p20_r9_selftest_out.txt (its generator p20 was never shipped) kept'),
    ('analog/scripts/stability_legs.py; stability_legs_T.py; stability_legs_T2.py; stability_legs_lead.py; stability_final.py', 'round-1 selection sweeps (relay placeholder path, T network, lead capacitor); superseded by stability_switch.py / stability_iv.py (A4/A5); outputs analog/out/stability_legs*.txt, stability_final.txt kept'),
    ('analog/scripts/digitize_opa1622.py; digitize_opa1622_b.py; pdf_dump_region.py', 'read the OPA1622 datasheet PDF (external, not shipped); their derived data analog/ds/*.json is shipped and feeds A3'),
    ('analog/scripts/unplug_model.py; unplug_model_r2.py; dac_timing_pop_r1.py', 'earlier rounds, superseded by unplug_model_r3.py (A2) and dac_timing_pop.py (A6)'),
    ('analog/scripts/gen_netlist_bom.py; power/calc/gen_bom_netlist.py; gen_sch_part.py; digital/gen_netlist_bom.py; protection/p08_bom_netlist.py; p12_r3_bom_netlist.py; p14_ve_bom.py', 'stream BOM/netlist generators of earlier rounds; the released bom_rows.csv / netlist.csv carry later text-only corrections and are the release inputs (checked by I1/I3)'),
    ('protection/p03_detector.py; p11_x9_filter.py', 'the retired leg windows (R601-R604 / C601-C604 removed in R10 F-1): their zero-state sweeps are what R10-A1 invalidated; outputs kept'),
    ('protection/p17_r9_e3.py; p17b_r9_e3_2pole.py; p18_r9_e2e3.py', 'R9 generators: the E-2 / E-3 hardware is unchanged, but the p18 energies and T_P 23.23 ms are superseded by p21 (T_P 23.37 ms with the design rails and a 0 V start); p17/p17b (filter-type windows rejected) kept for the R9 rationale; outputs kept'),
    ('protection/p03b_threshold_scan.py', 'round-1 threshold scan (basis of the window choice); it imports the current p03/pcommon constants, so a re-run no longer reproduces its shipped output p03b_threshold_scan_out.txt (kept); the released windows are verified by P03'),
    ('parts/ve_cost_model.py', 'VE-round cost model on the stream BOMs of 25 Sep 11:06 (output ve_cost_model_out.txt, ve_lines.csv kept); superseded by integration/cost_calc.py (I5)'),
    ('integration/tests/scan_parts_list_values.py', 'reads the Parts List workbook (docs, not shipped)'),
    ('integration/build_calc_package.py', 'builds this package from the project tree (not runnable inside the package)'),
]
MODULES = ['protection/pcommon.py', 'power/calc/pw_common.py', 'analog/scripts/r2_common.py', 'analog/scripts/mna.py', 'analog/scripts/mna_v.py',
           'analog/scripts/models_v.py', 'analog/scripts/opamp_models.py']
# claim texts must not carry superseded values (R10-C: the v1.0 INDEX still showed R509 4.81 k / 490.80 / 177.9 mA)
INDEX_STALE = [r'4\.81 ?k', r'490\.80', r'177\.9 mA', r'176\.97', r'<= 8\.45 ms', r'<= 8\.50 ms', r'9\.23 / 18\.45', r'7\.19 / 14\.39', r'758\.1\b', r'390\.4',
               r'178\.82\b', r'\+1\.23 mA', r'73\.51', r'tiers from every state', r'from any state', r'0\.324 V per leg', r'full coverage', r'344\.17', r'359\.50', r'352\.31', r'348\.67', r'364\.00', r'178\.83\b', r'\+1\.22 mA', r'73\.48', r'344\.22', r'359\.55', r'352\.36', r'493\.45', r'760\.76',
               r'no net until the G-2', r'provisional until G-2', r'role unconfirmed', r'measured pin \+ 0\.2']   # R11 SE-9 / SE-10: J701 / J702 maps from the maker drawings


def write_index():
    import glob
    L = [f'# Calculation package v{VERSION} — USB DAC + balanced headphone amplifier (R10 final with the R11 update, 26 Sep 2026)', '',
         'Reproducible calculations behind the design documents (decisions_r9 E-15, decisions_r10 F-3). Every path below is relative to this '
         'folder; run the commands from this folder with Python 3.8+ and numpy.', '',
         '**R11 update (26 Sep 2026):** the schematic-capture review and the maker drawings supplied by the owner (J701 owner-approved 12-pad map, '
         'confirmed by the G-Switch drawing, pads 11/12 = mounting tabs; J702 contact map from the HRO PJ-332A drawing: 1 sleeve / 2 ring 2 GND, '
         '3 ring 1 JACK_RP, 4 tip JACK_LP, 5/6 break contacts no net; G-2 confirms both on two samples; J101 / J702 plated-termination soldering '
         'open with JLCPCB, owner fallback), the corrected connector and protection BOM texts '
         'and stress rows with the parts T1 / T2 re-runs, and the register and summary corrections of the independent summary check. This '
         'package supersedes the earlier v1.1 build of 26 Sep 2026 10:43.', '',
         '## Release verification — one command', '',
         '```', 'python3 verify_release.py', '```', '',
         'It copies the package to `_verify/run/` (the shipped files are never overwritten), runs every release calculation of list 1 in '
         'dependency order with the inputs shipped here, compares every file a calculation writes with the shipped file of the same path '
         '(line endings normalised; an output the package does not ship is a failure) and the key results with the values stated in the '
         'documents, prints a pass/fail table and writes `_verify/verify_release_report.txt`. Exit status 0 = all pass, 1 = any mismatch or '
         'error, 2 = a declared release calculation is still pending. `python3 verify_release.py --list` lists the checks, '
         '`--only <id> ...` runs selected ones (with their dependencies). A full run takes about 20 minutes on a slow disk.', '',
         '**Not included (external sources):** datasheet PDFs and their text extracts, web caches and quote files (`ds/*.txt`, `web/`, '
         '`sources/`). Scripts that digitise datasheet figures are historical generators (list 2); their derived data (`analog/ds/*.json`) '
         'is shipped, so every release calculation runs without the PDFs.', '',
         '## 1. Release calculations (verified by `python3 verify_release.py`)', '',
         '| Claim | Script(s) | Output(s) | Single run (from the package root) | Check |', '|---|---|---|---|---|']
    miss, stale = [], []
    named = set()
    for claim, scr, outp, cmd, chk in RELEASE:
        for group in (scr, outp):
            if group == '-':
                continue
            base = ''
            for x in [x.strip() for x in group.split(';')]:
                if '/' in x:                       # a bare file name belongs to the folder of the last path named before it
                    base = os.path.dirname(x)
                pth = x if '/' in x else f'{base}/{x}'
                if group is scr:
                    named.add(pth)
                if '*' not in pth and not os.path.exists(os.path.join(DEST, pth)):
                    miss.append(pth)
        stale += [(claim, p) for p in INDEX_STALE if re.search(p, claim)]
        L.append(f'| {claim} | `{scr}` | `{outp}` | `{cmd}` | {chk} |')
    L += ['', '## 2. Historical generators (kept for traceability; not verified, not guaranteed to re-run)', '',
          '| Generator(s) | Why historical |', '|---|---|']
    for scr, why in HISTORICAL:
        base = ''
        for x in [x.strip() for x in scr.split(';')]:
            if '/' in x:
                base = os.path.dirname(x)
            named.add(x if '/' in x else f'{base}/{x}')
        L.append(f'| `{scr}` | {why} |')
    named |= set(MODULES)
    rest = sorted(os.path.relpath(p, DEST).replace(os.sep, '/') for p in glob.glob(os.path.join(DEST, '**', '*.py'), recursive=True))
    rest = [p for p in rest if p not in named and p != 'verify_release.py' and not p.startswith(('r9/', 'r10/'))
            and not any(part.startswith('_') for part in p.split('/')[:-1])]      # _verify/ run copies, scratch folders
    if rest:
        L.append('| ' + '; '.join(f'`{p}`' for p in rest) + ' | other scripts not named in list 1 (earlier-round calculations, or R10 scripts not yet assigned to a release claim): kept for traceability, not verified |')
    L += ['', f'Shared modules imported by the release calculations: ' + ', '.join(f'`{m}`' for m in MODULES) + '. '
          '`r9/` and `r10/` hold the review digests and decisions of those rounds (the orchestrator reproductions in `r10/` are inputs '
          'of this round, not release calculations).']
    L += ['', '## Folder map', '', '| Folder | Content |', '|---|---|',
          '| `verify_release.py` | the release-verification command (this folder) |',
          '| `power/` | power stream report, BOM/netlist, `calc/` scripts `cNN_*.py` with `.out.txt` / `*_results.json` |',
          '| `protection/` | protection report, BOM/netlist, scripts `pNN_*.py` with `*_out.txt` |',
          '| `analog/` | analog report, BOM/netlist, `scripts/` (models, sweeps) with `out/`, derived curve data `ds/*.json` |',
          '| `digital/` | digital report, BOM/netlist, scripts with `*_output.txt` (their stdout) |',
          '| `parts/` | parts report, layout package, stress and PCBA tables, cost/placement scripts |',
          '| `integration/` | checker, merge/cost/evidence scripts, merged BOM/netlist, traceability, evidence register, summaries, decisions; `tests/` E-1 self-tests; `baselines/` merged BOMs of the v0.9 and v1.0 sets (change-list inputs) |',
          '| `current/` | Parts List v0.6 CSV (input of the change list) |',
          '| `r9/`, `r10/` | review digests and decisions of R9 and R10 (inputs of those rounds) |']
    if miss:
        L += ['', '## Index check', '', 'Paths named in list 1 but not present at build time (a stream may still be writing them): ' + ', '.join(f'`{m}`' for m in sorted(set(miss)))]
    else:
        L += ['', '## Index check', '', 'Every script and output named in list 1 is present in the package.']
    if stale:
        raise SystemExit('INDEX claim text carries superseded values: ' + '; '.join(f'{p} in "{c[:60]}"' for c, p in stale))
    open(os.path.join(DEST, 'INDEX.md'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('INDEX.md: %d release claims, %d historical groups (+%d other scripts); missing paths: %s'
          % (len(RELEASE), len(HISTORICAL), len(rest), sorted(set(miss)) or 'none'))


if __name__ == '__main__':
    sys.exit(main())
