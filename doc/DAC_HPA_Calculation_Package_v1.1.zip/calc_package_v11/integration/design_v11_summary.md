# DAC-HPA design summary v1.1 (tenth review round)

This summary is the single source for Spec v1.1, Notes v1.0 and Parts List v0.9. The documents are updated from their v1.0-set versions (Spec v1.0, Notes v0.9, Parts List v0.8): every statement here replaces the corresponding v1.0 text, and anything not stated here is unchanged. Section a ends with the list of v1.0 statements that must be removed or replaced.

**Figures.** The documents use the v1.1 figures, which replace the v1.0 ones: the signal-chain figure fig1_signal_v13.png (protection block: 6 × TLV1704, 9 × TLV3402, re-arm latch) and the power figure fig2_power_v13.png (the ±rail loads now include 6 × TLV1704 and 8 × TLV3402), with their reduced versions (suffix _small).

**Evidence classes.** Every number carries its class:
- **[G]** comes only from datasheet limits, construction facts or other G results.
- **[E]** rests on at least one assumption, typical value or reconstructed model; the capping input is named.
- **[Q]** rests on a measurement. A Q item is an open qualification obligation: it stays open until its measurement record exists. **No board exists yet, so no Q item has passed.**

Requirement limits, chosen design values and pass windows are stated without a class; every computed or measured result carries one, either on the line or in the heading of its block.

**State of the set.** The merged design passes the netlist/BOM check with 0 issues: 474 parts, 247 nets and 1393 pins, with the value-from-part-number decode on 118 lines [G]. With the 52 layout test pads the merged netlist has 1445 pin rows. The BOM has 179 lines, 462 fitted parts (7 owner-fitted), 9 DNF and 115 fitted part numbers; 1339 SMT and 18 THT joints per board. The cost is US$ 949.43 = NTD 30,125 for the five-board order (US$ 189.89 = NTD 6,025 per board), +US$ 93.29 against the v1.0 set's US$ 856.14 [E], an estimate until the supplier orders and the JLCPCB quote exist. The evidence register has 120 rows: G 13, E 80, Q 22, and 5 retired or process rows, one of them the open JLCPCB process item R-70. The v1.0 register had G 49, E 49, Q 7 and 2.

## a. What changed and why, per review finding

**R10-A1 — the hardware energy proof assumed that every fault starts from rest.**
- The v1.0 sweep started each fault with the filter capacitors discharged. A fault during playback instead starts with charge of either polarity, and that charge delays detection.
- Both counterexamples reproduce on the v1.0 circuit:
  - after one 20 Hz half-cycle at 1.5 V peak, a ±0.97 V/leg fault was removed in 137.6 ms at 32.4 mJ (16 Ω), above 30 mJ [E];
  - with the filter pre-charged by sub-threshold DC, removal took 195 ms at 46.0 / 23.0 mJ [E].
- A second hole was found in this round: one leg stuck at the rail while its partner leg still plays full-scale content at ≥ 50 Hz. The pair difference then drops below the pair threshold every cycle, so the pair detector never trips. In v1.0 only the per-leg windows were left to act.
- The fix is a new hardware stage per leg, described in section b. The per-leg RC window stage is removed. Removal times and energies are now computed from every reachable pre-fault state: any filter and timer charge the rails allow, any prior content, bursts, polarity reversals, and any partner-leg content.

**R10-A2 — some G classes were stronger than their inputs.**
- The evidence register now derives every class from the inputs each row records: a row is G only if every input is G.
- R-13 (Default 32 Ω power) moves to E. The Default need contains the LM27762 quiescent current, which has no published maximum, and an estimated charge-pump input factor of 1.03.
- The stability rows A-36 to A-38 are E. They rest on a typical-curve OPA1622 model and reconstructed OPA2210 output-impedance shapes.
- Section k gives the complete re-walk.

**R10-A3 — not every advertised calculation command reproduced.** Three causes:
- one calculation read unshipped files;
- the protection common rail constants were stale;
- some shipped outputs had been assembled from partial runs.

What was done:
- The calculation package now has one release-verification command that re-runs every release calculation with the inputs shipped, and a clear split between release calculations and historical generators (section j).
- The protection rails now come from the released dividers: VPOS 3.789–3.915 V, |VNEG| 3.661–3.781 V [G]. The R501 232 k fallback is named separately (VPOS 3.919–4.049 V [G]), and every R10 release calculation uses the envelope of the two.
- The power calculations share one input set.

**R10-A4 — latch wording.** The unbounded v1.0 sentence is replaced by the implemented condition (section b), and the latch tests are open qualification obligations (A-39, [Q]).

**R10-B — the calibration boundary.**
- The detectors' content boundary is guaranteed only at or below the calibrated full-scale level.
- A board without a valid calibration record runs at the −4.5 dB default.
- The firmware never sets a gain above the calibrated level.

Section f gives the rule and section g the margins. Watch items:
- the calibrated-level margin of the 300 Ω output-power target (0.17 dB, R-12 [Q]);
- the 20 Hz sine margin at the calibrated ceiling (4.3 % [E]).

**R10-C — a stale release-package defect and the holds.**
- The power checks and the v1.0 index still quoted the superseded R509 value, and the Default total and current limit derived from it, in current-looking sections.
- The checks were regenerated with R509 4.75 kΩ. The state narratives were aligned to the final budget (section i).
- The index now carries a stale-value guard, and the register build refuses any superseded value.
- The holds stand:
  - gates G-1 to G-4: two samples each of J101 / J701 / J702, 1:1 overlays and polarity;
  - G-5 and G-6, including the JLCPCB reflow of the 2416 film capacitors and JLCPCB's written confirmation of how the J101 stakes and the J702 slot terminals are soldered (section q).

**Independent re-check of the protection fix (this round).** Findings and their handling:
1. **32 Ω balanced frozen full scale in High mode** holds ≤ 15 mJ only with the typical OPA1622 swing credit. It is stated as an E item with a bring-up test (A-45; section e).
2. **The definition of fault energy.** Counting the partner leg's content, the total terminal energy on a balanced load exceeds 15 mJ at 32 Ω. The Spec definition is kept, and the totals are published for information (section e).
3. **The boot self-test is pairwise.** One dead channel can be masked by its mate. This is stated as a limitation; per-channel coverage comes from the production per-leg injection (section h).
4. **The timer reset VCE(sat) basis.** The fitted transistor's datasheet had no low-current row. Q623–Q627 moved to onsemi MMBT3904LT1G, whose datasheet gives ≤ 0.2 V at 10 mA / 1 mA. The extension to about 35 µA stays E (A-46), with a bring-up test.
5. **The exact firmware-tier boundaries.** They hold for the swept history set only, and are stated that way (section d).
6. **The precision of the requirement floor.** The floor is rounded up over the LPW level maximum including a leakage allowance (section c).
7. **The wording of the LPW content boundary.** It is stated both on the timer and in raw-leg terms (section g); the checker has closed the finding.

**Independent summary check (this round).** Its corrections are applied: the headline protection figures are the rail-bounded values, which need no calibration input, and the content-bounded ones are quoted only for pre-fault content at or below the calibrated ceiling (section b); frozen codes between the floor and 1.008 V/leg are bounded at 118.8 ms; the over-range thresholds and the LPW timer are E, with their capping inputs named; the energy-definition sentence names its one exception (section e); the calibrated ceiling's class (section f); the burst wording and the LPW offset boundary with the leakage allowance (section g); the self-test wording (section h); the TPS70933 thermal figure (section i).

**Schematic-capture review (26 Sep 2026).** The review of capture v1.0 found connector soldering and pin-map issues; section q gives the dispositions SE-1 to SE-8, updated by the maker drawings the owner supplied the same day (SE-9 / SE-10):
- J101's four plated shell stakes and J702's two plated slot terminals need JLCPCB's written confirmation of how they are soldered, with an owner hand-solder fallback at no cost; until then the register row on process limits (R-70) is an open process item.
- J701 follows the owner-approved 12-pad map, which the G-Switch maker drawing confirms (pads 11/12 are mounting tabs). J702 takes its contact map from the HRO maker drawing: sleeve and ring 2 on GND, ring 1 on JACK_RP, tip on JACK_LP, and pins 5/6, the break contacts, with no connection. G-2 confirms both maps on two samples; the G-2 record procedure is defined.
- No manufacturing data is made from the provisional connector assignments; the stage table (section l) is updated.
- The capture is still on the R9 protection sheet and must be updated to Parts List v0.9.

**v1.0 statements to remove or replace in the documents:**
- the per-leg RC window stage (two quad comparators with RC filters and threshold dividers), its thresholds, filter time constants and self-test step: removed (sections b, h and o);
- the hardware removal times and energies computed from rest: replaced by section b;
- the hardware requirement without a level floor: replaced by section c;
- the firmware tier table: replaced by section d, stated for the swept history set;
- the unconditional no-mute claim for 20 Hz sines and its v1.0 margin: replaced by sections f and g;
- the latch sentence without a bound: replaced by section b;
- the boot self-test sequence and time: replaced by section h;
- the Default need, the USB state currents and the 5V_ANA narratives: replaced by section i;
- the register counts and classes: replaced by section k;
- the BOM, part counts and cost: replaced by section o;
- the seven-pin J701 map, the J702 contact map (pins 1–4 and the pins 5/6 ground assignment), the J702 "SMD" description, the sentence that the JLCPCB order has no through-hole part and the unconfirmed pin-in-paste prescription for the J101 stakes: replaced by section q;
- the stage table: replaced by section l.

## b. The new protection design

**Topology.**
- Each audio channel keeps its **pair-difference persistence detector**, unchanged: one TLV1704 per channel, with an NPN-reset timer.
- Two new stage types feed the same timer node and node H:
  - a per-leg **over-range (OR) stage**, for large DC on one leg;
  - a per-leg **low-level persistence (LPW) stage**, for small DC.
- Node H drives the latch and the output photorelays as before.

**Per-leg OR stages** (U611 / U612, TLV1704):
- 330 kΩ / 1 nF C0G prefilter.
- Thresholds V_OR +1.764…+1.964 V and −1.762…−1.959 V [E: V_OR− relies on the assumed test-line low level of ≤ 10 mV].
- They act through the persistence timer. A single leg stuck anywhere above the OR threshold is removed with any partner-leg content.

**Per-leg LPW stages** (U613–U620, TLV3402IDGKR):
- 1.00 MΩ / 3.3 nF C0G tap (0603).
- Level V_LL +0.279…+0.322 V and −0.283…−0.324 V [G], or 0.269–0.334 V with a 10 nA surface-leakage allowance [E].
- Timer 910 kΩ / 100 nF C0G (1206): T_P2 51.3–68.5 ms [E: the timer-node leakage is assumed ≤ 0.1 µA]. The comparator delay is separate: ≤ 0.9 ms, 3 × typical [E].
- Reset ≤ 9.6 ms [E].
- An LPW timer charges only while its leg holds beyond ±V_LL, and resets as soon as the level condition fails. No sine of 20 Hz or above can charge it long enough to trip.

**Pair-difference persistence detector** (unchanged hardware):
- V_L 1.802–2.016 V on the pair difference [G]; timer R_T 110 kΩ, C_T 220 nF PPS ±2 %.
- T_P 19.50–23.37 ms with the design rails [E: node leakage ≤ 1 µA; reset VCE(sat) extension, A-46].
- The reset NPNs Q623–Q626 are now onsemi MMBT3904LT1G, same land.

**Latch** (implemented condition):
- A trip that pulls node H below HREF clears the ARM latch within ≤ 0.346 ms (0.383 ms with the R501 fallback) after the comparator switches [E, timing estimate].
- HREF is 2.883–3.029 V released, up to 3.133 V with the fallback [G].
- A disturbance that never reaches HREF neither clears the latch nor opens the switch [G, logic].
- After any trip, the switch re-closes only on a fresh RELAY_EN edge with H recovered. A hung MCU holding RELAY_EN high can never re-close it [G, logic].
- All R10 stages act through TLV1704 outputs on H.
- H trip to switch open ≤ 1.96 ms (2.00 ms fallback) [E: photorelay tOFF 2 × the 25 °C maximum].
- The latch tests are open obligations (A-39, [Q]).

**Removal times and energies from every reachable pre-fault state.**
- Scope: any filter and timer charge within the rails, any content history, any partner-leg content.
- The headline figures are rail-bounded: the pre-fault taps are bounded by the rail, so the figures need no calibration input.
- Class E for all, capped by: photorelay tOFF 2 × the 25 °C maximum; timer node leakage ≤ 1 µA; comparator delays; the OR test-line low level; the reset VCE(sat) extension.
- Figures, from any reachable state:
  - DC ±2 V on a leg: removed ≤ 27.2 ms; margin 73 % to 100 ms (R-20).
  - DC ±1 V on a leg: removed ≤ 102.7 ms; margin 59 % to 250 ms (R-21).
  - Rail-stuck leg, single-ended load, any partner content: 26.48 / 13.24 mJ at 16 / 32 Ω on the 4.049 V R501-fallback rail, removal ≤ 25.9 ms, margin 12 % (R-22). On the released 3.915 V rail: 24.78 / 12.39 mJ.
  - Balanced ±x at every level up to the swing limit (R-23):
    - 16 Ω: worst 26.08 mJ at 1.008 V/leg, removal 102.7 ms, margin 13.1 %;
    - 32 Ω: 13.67 mJ at the released swing limit of 2.077 V/leg (margin 8.8 %), 14.87 mJ at 2.166 V/leg with the R501 fallback (margin 0.8 %). Both depend on the typical OPA1622 swing credit (A-45).
  - Frozen DAC codes (R-61):
    - |pair| > 2.016 V (|leg| > 1.008 V): removed ≤ 25.4 ms by the persistence detector;
    - 0.34 V ≤ |leg| ≤ 1.008 V: removed ≤ 118.8 ms by the LPW stages, the bound at the floor;
    - the energy at the floor is 3.43 / 1.72 mJ (balanced 16 / 32 Ω); the worst energies are those of the balanced case.
- With pre-fault content at or below the calibrated ceiling, the same cases give 27.1 ms, 101.3 ms, 26.40 / 13.20 mJ rail-stuck (removal ≤ 25.8 ms; 24.69 / 12.35 mJ at 3.915 V) and 25.70 mJ for 16 Ω balanced (101.2 ms).
- The v1.0 counterexamples are closed [E]:
  - balanced ±0.97 V/leg after a prior history: with pre-fault content at or below the calibrated ceiling it is removed in 101.4 ms at 23.85 / 11.92 mJ (16 / 32 Ω); from any reachable state it stays inside the balanced worst case above; before: 32.4–46.0 / 16.2–23.0 mJ;
  - one leg stuck at the rail with full-scale partner content: removed in ≤ 25.9 ms at 26.48 / 13.24 mJ (single-ended 16 / 32 Ω) on the 4.049 V fallback rail and 24.78 / 12.39 mJ at 3.915 V, from any reachable state; before: 44.6–46.2 / 22.3–23.1 mJ.
- Added loads [E]: VPOS +0.054 mA, VNEG +0.062 mA, 3V3A +0.007 mA; R951 draws nothing in normal operation.

## c. The hardware requirement with the level floor

**Requirement.** The hardware-only protection holds from every reachable state for |leg| ≥ 0.34 V and |pair| ≥ 0.68 V (R-74, [E]).
- Removal: ≥ 2 V within 100 ms and ≥ 1 V within 250 ms.
- Energy: ≤ 30 mJ at 16 Ω and ≤ 15 mJ at 32 Ω.
- The floor is rounded up over the LPW level maximum: 0.32401 V from the comparator input bias only [G], or 0.33401 V with the 10 nA leakage allowance [E].
- At the floor, the bounded delay is 118.8 ms and the energy 3.43 / 1.72 mJ (balanced 16 / 32 Ω) [E].

**Below the floor**, the firmware tiers take over (section d). The worst below-floor energy is [E]:
- ≤ 17.4 / 8.7 mJ for a pair at 16 / 32 Ω;
- ≤ 14.5 / 7.3 mJ for a leg (rail-bounded pre-state).

## d. Firmware tiers

The tiers act on the DC-sense channels through the same estimator as before. Their history robustness is shown over the swept histories [E]. The history set is finite, not a universal bound. It covers sines, steady DC, bursts, polarity reversals, short opposite pulses (5–19.4 ms), excursions limited by the LPW stage, and gaps. Levels per leg / pair:

| Tier | Level removed | Within | Rail-bounded variant |
|---|---|---|---|
| T1 | ≥ 1.001 / 1.015 V | 218 ms | ≥ 1.007 / 1.027 V |
| T2 | ≥ 0.313 / 0.312 V | 603 ms | ≥ 0.316 / 0.316 V |
| T3 | ≥ 0.178 / 0.195 V | 2.36 s | ≥ 0.179 / 0.197 V |

- The exact deadlines are stated for the swept histories, not for every conceivable history. A history outside the set can delay a trip slightly: the independent check found +1 ms at T2 and +9 ms at 0.176 V, a level below the guaranteed T3 level.
- The 3 s owner rule keeps a margin of more than 0.6 s over the T3 deadline.
- The safety conclusion holds: DC ≥ 0.2 V is removed well within 3 s [E].
- The residual below T3 is ≤ 2.43 mW into 16 Ω, or 2.38 mW content-bounded (R-25, [E]). The owner accepted it.

## e. Fault-energy definition and the published totals

**Definition.** The Spec keeps E = V_DC² / R × removal time, where V_DC is the fault DC at the load. Under this definition every calculated case meets 30 / 15 mJ under the stated engineering-estimate assumptions (sections b and c). The one exception needing the owner's attention is the High-mode 32 Ω balanced frozen full-scale case: it meets 15 mJ only with the typical output-swing credit (A-45), so it remains an owner decision with a bring-up energy test.

**Published for information:** the total terminal energy when a balanced load has one leg stuck and full-scale content on the partner leg [E]:

| Case | Total terminal energy |
|---|---|
| 32 Ω balanced, High mode | 24.1–24.7 mJ (exceeds 15 mJ) |
| 16 Ω balanced, High mode (U503 current cap, no partner current-limit credit) | ≤ 23.85 mJ |
| Default mode | ≤ 11.3 mJ |
| Single-ended loads | equal to the DC energy |

A fast high-level over-range stage was evaluated and rejected. Its threshold window would be 2.45–2.80 V, but at the eFuse minimum the loaded stuck leg sags to 2.82 V at 32 Ω and 0.25 V at 16 Ω. It would also need 16 parts plus a test provision, and zone Z4 would reach about 60 %.

**32 Ω balanced frozen full scale, High mode (A-45, [E]; owner item).**
- The persistence detector alone keeps ≤ 15 mJ only up to 2.175 V/leg.
- Without the typical swing credit: 15.23 / 15.77 / 17.14 mJ at 2.192 / 2.230 / 2.325 V/leg.
- At the −4.5 dB default, on the 3.66 V basis: 15.07 mJ.
- With the typical swing credit: 13.67 mJ (released) / 14.87 mJ (R501 fallback).
- The physics floor, keeping the full-scale square boundary at 25.6 Hz, is 14.55 mJ at 2.325 V/leg.
- Bring-up test: a CPLD frozen 0 dBFS code at the calibrated level into a 32 Ω balanced dummy. The energy until the switch opens must be ≤ 15 mJ; the leg swing is logged.

**Default mode** has a current cap:
- U503's limit (IOS max 222.6 mA [G]) holds the legs at ≤ 1.781 V.
- The worst frozen-code case is 11.10 mJ, a 26 % margin [E]. It takes no swing, dropout or UVLO credit, and includes the capacitor energy and a 1.5 × limit overshoot for 0.3 ms.
- Typical is 5.0 mJ.
- The eFuse has no fault timer and no auto-retry. The rails-OK signal is firmware-only.

## f. Calibration rule

**Record.**
- The calibration record is 48 bytes under a CRC-32 plus a verified word, in its own flash page.
- It is bound to the MCU's unique ID.
- At every boot, which is every attach, the firmware checks magic, version and length, CRC, ID and range.

**Gain rule.**
- Master trim = the recorded value. The DAC resets its trim registers at every reset; the firmware re-writes them.
- Without a valid record the board runs at the −4.5 dB default, trim word 0x4C3EA838 (exact), with a red double-flash and a log entry.
- The firmware never sets a gain above the calibrated level. The volume registers attenuate only, and the USB volume maximum is 0 dB.
- The pre-close check and the periodic DAC status poll compare the trim registers with the recorded value.

**Calibrated full-scale ceiling.** 1.55 Vrms +0.15 dB per leg: 0.10 dB production acceptance plus 0.05 dB instrument allowance (A-40, [E]; the calibration itself is R-07, [Q]).

**Levels per leg at 0 dBFS:**

| Case | Peak per leg | Pair | Class |
|---|---|---|---|
| Highest-gain unit, untrimmed | 3.069 V | 6.138 V | E, typical DAC full scale |
| Highest-gain unit at the −4.5 dB default | 1.828 V | 3.656 V | E |
| Uncalibrated range at the default | 0.983–1.293 Vrms | — | E |
| Calibrated ceiling (1.55 Vrms +0.15 dB) | 2.230 V | — | Q, calibration record |
| Calibrated ceiling with the datasheet 3V3A drift | 2.325 V | — | Q (calibration record), with a G increment for the 3V3A drift; the DAC gain tempco is unpublished (E) |

Post-calibration drift stays within ±0.35 dB from the 3V3A window [G], plus the unpublished DAC tempco [E].

**Production tests** P-1 to P-7 cover calibration, including an erased-record test.

## g. Content boundaries

**Sines ≥ 20 Hz never trip** (R-26 and A-31, [E], with the calibrated level as a precondition):
- Margins: 6.4 / 5.7 / 4.3 % at 2.192 / 2.230 / 2.325 V/leg; 13.9 / 6.6 % at the −4.5 dB default (1.828 V model / 2.180 V basis).
- The first 20 Hz trip is at 2.659 V/leg, +1.16 dB over the 2.325 V ceiling. That is seven times the calibration window, so no measured value is relied on.
- If the reset VCE(sat) were 0.30 V instead of 0.20 V, the margins would fall to 3.1 / 2.4 / 0.9 %, and squares might mute up to 26.5 Hz (A-46).

**Full-scale squares** mute certainly at ≤ 21.4 Hz and possibly up to 25.6 Hz [E]. The tested full-scale 20 Hz burst and polarity-reversal waveforms do not trip. One full-scale 20 Hz square cycle, and the asymmetric second-harmonic wave, do trip, as in v1.0.

**LPW content boundary** (A-44, [E]; adopted by default and presented to the owner). The boundary is stated on the LPW timer, which runs while the 3.3 ms-filtered leg tap is beyond ±V_LL: ±0.279–0.324 V on input bias alone (about −17 dBFS), or 0.269–0.334 V with the 10 nA leakage allowance [E]:
- a mute **can** occur once the tap has been beyond ±V_LL for ≥ 70.8 ms;
- a mute **will** occur after 91.9 ms, plus the amplitude-dependent tap crossing and ≤ 1.8 ms of comparator delays. The crossing time grows without bound as the level approaches V_LL max; it is +11.6 ms for a step from −2.325 V to 0.5 V;
- in terms of the raw leg voltage, a full-scale excursion can mute after ≥ 62.9 ms, because the tap lags the leg by ≤ 7.0 ms and the release adds 0.9 ms.

**Steady offsets** on one leg, as a fraction of that unit's full-scale peak, with the leakage allowance: below 0.116 FS they never mute; at or above 0.162 FS they mute on every unit.

| FS reference | Can mute from | Mutes from |
|---|---|---|
| −0.15 dB, 2.154 V | 0.125 FS | 0.155 FS |
| Nominal, 2.192 V | 0.123 FS | 0.152 FS |
| +0.15 dB, 2.230 V | 0.120 FS | 0.150 FS |
| Drift ceiling, 2.325 V | 0.116 FS | 0.144 FS |
| Lowest unit, 2.059 V | 0.130 FS | 0.162 FS |

Examples of content that can mute:
- full-scale sines below 6.5 Hz (6.54 Hz with the allowance);
- squares up to about 7 Hz (0.8 / 0.5 / 0.35 V squares 7.4 / 7.2 / 6.9 Hz; 0.30 V squares up to 6.7 Hz).

The independent checker has closed this wording finding.

## h. Boot self-test

**Default:** all implemented (pairwise) tests every boot, 3.68 s [E, timing model]. The alternative is 2.96 s, rotating the over-range direction, so all implemented tests run within four boots. First audio after an attach comes about 4.2 s after enumeration.

| Test | Stimulus | Result [E] | Pass window |
|---|---|---|---|
| (e) persistence detector | ±0.55 FS on calibrated units (pair ≥ 2.27 V, +250 mV over V_L max 2.016 V; OR silent); ±0.85 FS at the default | 19.5–24.2 ms | 18–26 ms |
| (f) LPW | ±0.30 FS | 72.4–99.8 ms | 65–110 ms |
| (g) OR | PC15 (N6_ORTEST) high: settle ≤ 90 µs, 1 ms used; R951 sets the positive test threshold to 0.086–0.141 V; ±0.25 FS | 19.5–24.9 ms | 18–32 ms |

- The supervisor tests (b), (c) and (d) are unchanged, and PB0 is low after every trip.
- PC15 is the last free MCU pin: 49 of 49 GPIO are now used.
- **Limitation:** coverage is pairwise. A balanced test word drives two parallel paths into one timer base. One dead channel, or a one-sided reference fault such as R937 or R939 open, is masked by its mate.
  - Per-channel coverage comes only from the production per-leg injection.
  - The firmware tiers still cover single-leg faults: T1, ≥ 1 V within 218 ms.
  - R-57 is [Q].

## i. Power

**USB states**, final after R10 [E: planning values for the MCU, CPLD and DVDD currents; the USB limit per board is closed by the production test, Q]:

| State | Current (mA) | Limit (mA) | Margin (mA) | With the NDK X201 second source (mA) |
|---|---|---|---|---|
| S1 before configuration | 82.40 | 100 | +17.60 | — |
| S2 | 344.39 | 500 | +155.61 | 348.89 |
| S3 Default total | 493.46 | 500 | +6.54 | 497.96 (+2.04) |
| S3f | 359.72 | 500 | +140.28 | 364.22 |
| S4 High | 760.77 | 1500 | +739.23 | 765.27 |
| S5 programming mode | 352.53 | 500 | +147.47 | — |
| S6 suspend (legacy / C-to-C cable) | 2.2755 / 2.1815 | 2.5 | +0.224 | — |

- The production test on every board, S3 ≤ 480 mA and S1 ≤ 90 mA, is the acceptance evidence for the USB limits (R-32, R-33, R-73: [Q]).
- The High-mode total S4 is 760.77 mA against the U102 limit of IOS min 870 mA. That leaves +109 mA, or +105 mA with the NDK [E] (A-41).
- The High-only-after-a-≥1.5 A-advertisement gating is by construction (R-34, [G]).

**Default need** (A-35, [E]):
- 178.961 mA at 5V_ANA against the U503 Default IOS min of 180.05 mA [G, R509 4.75 k 0.1 %]. The margin is +1.090 mA.
- It is capped by the LM27762 quiescent current (390 µA typical, no published maximum), the estimated charge-pump input factor of 1.03, and the assumed capacitor and BAT54 leakage rules.
- The margin is used up if the LM27762 overhead reaches 2.09 mA (5.4 × typical) or the charge-pump factor reaches 1.038.
- The first-board LM27762 overhead measurement and the production test confirm it.
- The quiescent 5V_ANA is 73.65 mA [E], and 88.38 mA with the DAC in reset.

**Block 6 budget:** the budget carries the protection block at ≤ 2.738 mA (I+) and ≤ 2.566 mA (I−). This is a deliberate conservative bound. The R10 design draws 2.714 / 2.542 mA, which lies inside it; the released Default need of 178.961 mA and its +1.090 mA margin are computed on the bound.

**Current limits** [G] (R509 4.75 k, R510 3.74 k):
- Default IOS 180.05 / 201.3 / 222.6 mA;
- High IOS 395.4 / 442.7 / 489.7 mA, against a High peak need of 320.1 mA.

**High-mode headroom** [E: LM27762 R_NEG typical only]:
- At VBUS 4.60 V the power floors need R_NEG ≤ 5.42 / 5.13 / 7.93 / 11.02 Ω (32 Ω SE / 60 / 120 / 300 Ω). The datasheet gives 2.5 Ω typical.
- At VBUS 4.40 V strict regulation needs R_NEG ≤ 2.53 / 2.41 Ω at LM27762 VIN 4.224 V. That corner is a measured item.

**5V_SYS** is ≥ 4.318 V, or ≥ 4.303 V with the J101 contact drop [E]. Since the suspend power cut, U502 is fed from VBUS ahead of U102. The photorelay drive (R-40) therefore keeps its 4.30 V condition.

**Brown-out**: the margin at the VBUS 4.40 V corner is +67…+114 mV, a thin margin [E: PA1 leakage 1 µA assumed]. The action comes 0.046–0.080 ms after source loss, before the MCU reset, in 96 of 96 corners. The PVD backs up a slow sag.

**ANA_SENSE supply-fault thresholds** [E: PA0 leakage assumed] (A-42):
- Default: 4.00 V (1587 counts), band 3.704–4.236 V, no-false-fault margin +71 mV at VBUS 4.40 V.
- High: 3.90 V (1548 counts), band 3.608–4.133 V, margin +124 mV at the High peak need, or +108 mV with the J101 drop.
- The threshold changes only with the switch open, or inside the downgrade sequence.
- A 5V_ANA short reads about 0 V in every state [G].

**Thermal** [E: RthJA and a +10 °C local rise assumed]:
- The hottest part is the TPS70933 (U502): 185 mW at VBUS 5.50 V gives TJ ≈ 89 °C, or 99 °C with the +10 °C local-rise allowance (212 °C/W, datasheet).
- TLV767 in S5: 88.8 °C at 165.0 mA.
- LM27762 overload bound ≤ 116.1 °C (+8.9 °C).
- U102 at the out-of-spec clamp: 137.9 °C (+17.1 °C).
- TPS2596 Default dead short: 125.1 °C, fault only.

**Suspend** ([Q]: the first-board, then every-board suspend current is the acceptance evidence): the USB current reaches the suspend level ≤ 8.75 ms after the last SOF; the limit is 10 ms.

## j. Reproducibility

**One command.** The calculation package has one release-verification command, `verify_release.py`, run from the package root. It works as follows:
- It copies the package so the shipped files stay untouched.
- It re-runs every release calculation in dependency order, using only the inputs shipped in the package.
- It compares every file a calculation writes with the shipped file. Line endings are normalised and numbers are compared to 1 ppm. The declared volatile lines (run times, input file dates) are masked. An output the package does not ship counts as a failure.
- It compares the key results with the values stated in this summary.
- It prints a pass/fail table and exits non-zero on any mismatch.

**Release rule.** The command runs 39 release checks, covering the netlist/BOM check with the value decode, the BOM/netlist reconciliation, the change lists, the cost report, the evidence register, every protection, power, analog and digital release calculation and the parts tables. The package is published only when every check passes from a clean copy of the published archive.

**Release vs historical.** The package index has two lists:
- **Release calculations**, verified by the command.
- **Historical generators**, kept for traceability and not guaranteed to re-run:
  - the retired leg-window calculations and their threshold scan;
  - the R9 persistence-detector and filter-window studies, superseded by the R10 calculation;
  - the R9 BOM generator, which needs unshipped earlier stream files;
  - the round-1 stability sweeps;
  - the datasheet digitisers, which need the PDFs;
  - superseded unplug and pop models;
  - the stream BOM generators, whose released BOM/netlist files carry later corrections;
  - the value-engineering cost model;
  - the Parts-List workbook scan.

## k. Evidence

**Rule.** A register row records its inputs, and its class follows from them:
- Datasheet limits and construction facts are G. A row is G only if every input is G.
- Any assumption, typical value or reconstructed model makes it E.
- Anything resting on a measurement makes it Q.
- A precondition that is not an input is recorded separately, only with a stated margin showing that no measured value is relied on.
- The strict build refuses any row whose text claims G while its inputs say E or Q, and any superseded value.

**Counts.** 120 rows: G 13, E 80, Q 22, and 5 retired or process rows (A-18, A-23, R-60, R-69 and the open process item R-70). The v1.0 register had G 49, E 49, Q 7 and 2. Rows R-74 and A-35 to A-46 are new; A-18 and A-23 are retired.

**Complete re-walk against the v1.0 register** (58 rows changed or new; the capping input is named in each row):
- **G → E (28 rows):**
  - output and levels: R-09 to R-11 (High-mode power; LM27762 R_NEG typical only), R-13 (Default 32 Ω power; the LM27762 quiescent current has no maximum and the charge-pump factor 1.03 is estimated), R-08 (the −4.5 dB default; typical DAC full-scale source), R-16 (frequency response; ideal op-amp model);
  - hardware protection: R-20 to R-22 (photorelay tOFF 2 × the 25 °C maximum, timer-node leakage, comparator delays, reset-level extension), R-28 and R-29 (frozen-word and failed-clock cases; DAC filter delay, comparator delay, tOFF), R-41 (switch opening; tOFF), R-72 (latch clear timing estimate);
  - firmware protection: R-24 and R-25 (finite swept history set), R-56 (pre-close limits; pin leakage and offset estimate);
  - content boundary: R-26 and A-31 (DAC tempco; calibration as a precondition with a +1.16 dB margin);
  - power and sequencing: R-35 (attach inrush; start-time and load-credit assumptions), R-40 (photorelay drive current; LED tempco and gain at 0 °C), R-42 (DAC power order; dropout model and comparator delay), R-49 (DAC supply order; comparator delay);
  - digital timing: R-03 (I2S timing; board skew before routing), R-50 (domain crossing; skew and leakage assumptions), A-15 (clock-activity tap; unpublished input capacitance), A-30 (X201 load; tap capacitance and trace length before routing);
  - parts and layout: R-38 (component stress; thin and data-gap rows), R-39 (PCB; field-solver model and placement-fill estimate).
- **G → Q (6 rows):** R-07 and R-18 (calibrated level and balance), R-12 and R-14 (300 Ω power at the calibrated level), R-19 (offset with the DAC terms), R-57 (self-test coverage).
- **E → Q (8 rows):** R-02 (host support), R-31 (unplug pop target), R-32, R-33, R-36 and R-73 (USB limits accepted by the production test), R-66 and A-26 (I2S2 slave capture).
- **New (13 rows):** R-74 (level floor), A-35 (Default need), A-36 to A-38 (stability models: typical-curve OPA1622 fit and reconstructed OPA2210 output impedance), A-40 (calibration rule), A-41 (High-mode USB total), A-42 (supply-fault threshold band), A-43 (comparator timing and LPW node leakage), A-44 (LPW content boundary), A-45 (32 Ω High-mode frozen full scale) and A-46 (timer reset level at low current), all E; A-39 (latch qualification), Q.
- **Retired (2 rows):** A-18 (window filter capacitor ageing) and A-23 (window 20 Hz false-trip margin), with the window stage.
- R-23 and R-61 (balanced and frozen-code energies) stay E, now capped by the new stage inputs and the typical swing credit.
- R-34 is split: the High-mode gating stays G (construction), and the High-mode USB total moves to A-41 (E).
- **G → open process item (1 row):** R-70 (no JLCPCB-placed part at a process limit) stays open until JLCPCB confirms in writing how the J101 shell stakes and the J702 slot terminals are soldered (section q).
- R-47 (connector maps) stays Q; it now records the J701 and J702 contact maps documented from the maker drawings (the owner-approved J701 12-pad map, confirmed; the J702 map with the break contacts 5/6 on no connection) and the G-2 record that confirms them on two samples.

## l. Stage table

| Stage | Verdict |
|---|---|
| Schematic capture | GO. Capture v1.0 uses the old J702 map: recapture sheet 7 to the J702 map of section q, and sheet 6 to Parts List v0.9 (the protection sheet) |
| Provisional placement | GO (100 × 80 mm) |
| Schematic freeze | HOLD for G-1…G-4. J701 and J702 contact maps are documented from the maker drawings and confirmed on two samples at G-2 (including J701 pads 11/12 and the J702 break contacts); J101 at G-1. |
| Routing | HOLD; no manufacturing data from the provisional connector assignments |
| Fabrication/assembly order | HOLD for the layout review and G-5/G-6, including JLCPCB's written confirmation of how the J101 shell stakes S1–S4 and the J702 pads 1/2 are soldered (or the owner fallback), and the 2416 film-capacitor reflow |

Gates G-1 to G-4 use two samples each of J101 / J701 / J702, with 1:1 overlays and polarity checks; section q gives the G-2 record.

## m. Owner decisions

Each decision has an adopted default, shown first; the alternatives follow with their costs.

1. **32 Ω balanced frozen full scale in High mode.**
   - **Default A:** a stated E item (A-45) plus the bring-up energy test, 0 parts.
   - **B:** calibrated full scale −0.6 dB (1.55 → 1.45 Vrms per leg) and a −5.1 dB default, 0 parts. It breaks the 300 Ω power targets: R-12 High 30 mW and the 300 Ω target of R-14 need 2.124 V pk/leg, but the calibrated −0.1 dB level falls from 2.167 V to about 2.022 V, giving about 27 mW. It also cuts every other power-target margin from ≥ 0.78 dB to ≥ 0.18 dB, and lowers the maximum output by 0.6 dB.
   - **Rejected:** a fast level stage, which would mute full-scale squares up to 50 Hz, and a precision persistence stage, which would need a timer spread ≤ 3.4 %.
2. **Fault-energy definition.**
   - **Default:** keep the Spec DC-energy definition and publish the total terminal energies (section e).
   - **Alternative:** a total-energy requirement would need a hardware change. The evaluated fast over-range stage does not work at the eFuse minimum, needs 16 parts plus a test provision, and would take Z4 to about 60 %.
3. **Boot self-test time.**
   - **Default:** all implemented (pairwise) tests every boot, 3.68 s.
   - **Alternative:** 2.96 s, rotating the over-range direction, so all implemented tests run within four boots.
   - In both cases the pairwise limitation stays: per-channel coverage comes at production (item 4).
4. **Self-test coverage.**
   - **Default A:** pairwise coverage stated as a limitation, with per-channel coverage at the production per-leg injection; 0 parts.
   - **B:** per-channel OR test. The OR test line is split in two, one half driven from a spare CPLD pin with an external pull-down: +1 part, one more CPLD register bit, 8 OR runs; self-test 4.65 s.
   - **C:** B plus per-channel LPW tests by one-sided threshold switching: about +4 to 6 parts and a second CPLD line; self-test 5.92 s.
5. **LPW content boundary** (A-44).
   - **Adopted by default:** sustained content that keeps one leg's filtered tap beyond ±V_LL (about −17 dBFS) for ≥ 70.8 ms may mute; a full-scale excursion of the raw leg can mute after ≥ 62.9 ms (section g); 0 parts.
   - **Alternative:** none that keeps the hardware requirement. Removing or slowing the LPW stage reopens the low-level history case, for which the v1.0 design reached 32.4–46.0 mJ. The adopted boundary is narrower than the v1.0 one for sub-20 Hz content: full-scale sines mute only below 6.5 Hz (v1.0: below 11.5 Hz). Steady offsets below 0.116 FS never mute, and offsets at or above 0.162 FS mute on every unit (v1.0: from 0.12–0.14 FS after about 1 s).
6. **Board size.**
   - **Carried over:** 100 × 80 mm, same PCB price tier as v1.0 [E, not quoted].
   - **Alternative:** 100 × 70 mm raises the overall fill to 68 %, with zones up to 67–68 %, above the 60 % zone rule [E]; not recommended.
   - The fill at 100 × 80 mm is now 59.6 %: Z4 52 %, Z7 59.0 % against the 60 % zone limit.
7. **Slot-pad copper ring of J701 / J702** (open; no pad size change).
   - Open point for the owner, to decide before the G-3 overlay: the maker-drawing slot pads leave a copper ring of 0.20 mm on J702 (0.60 mm slots in 1.00 mm pads) and 0.25 mm on J701 (0.50 mm slots in 1.00 mm pads; 0.20 mm at the +0.10 mm slot tolerance) — above JLCPCB's 0.18 mm minimum, at or below its 0.25 mm recommendation, and below this design's 0.30 mm rule. Until the owner decides, the pads stay as the maker drawings give them.
8. **Output-impedance contact terms (R-15)** (decided by the owner on 27 Sep 2026).
   - **Kept:** the assumption of 50 mΩ per J701 / J702 contact and 50 mΩ per 0 Ω link. The maker drawings give no contact-resistance maximum, so these terms stay E until the bring-up output-impedance measurement.
   - R-15 is unchanged: 3.5 mm 0.251 Ω and 4.4 mm 0.383 Ω against ≤ 0.5 Ω, margins 0.249 / 0.117 Ω [E].

## n. Thin margins, open qualification obligations and new bring-up tests

**Thin margins:**

| Item | Margin | Class |
|---|---|---|
| Default need vs U503 IOS min | +1.09 mA | E |
| Default USB total | +6.54 mA (+2.04 mA with the NDK) | E, plus the production-test Q |
| 20 Hz sine at the calibrated ceiling | 4.3 % (0.9 % if the reset VCE(sat) were 0.30 V) | E |
| 300 Ω output power at the calibrated level | 0.17 dB | Q |
| 32 Ω balanced frozen full scale, High mode, with the R501 fallback and the typical swing credit | 14.87 mJ, 0.8 % | E |
| Rail-stuck energy | 12 % | E |
| Brown-out margin at VBUS 4.40 V | +67 mV | E |
| ANA_SENSE Default no-false-fault margin | +71 mV | E |
| X201 duty against the DAC limit | zero margin | Q |
| X201 load | 14.2 pF against 15 pF | E |
| Z7 placement fill | 59.0 % against 60 % | E |

**Open qualification obligations.** Every Q row is listed, and none has passed, because no board exists:

| Row | Obligation | Measurement that closes it | Status |
|---|---|---|---|
| R-02 | USB Audio Class 2, High-Speed, on Windows, macOS, Linux and Android | enumeration and playback on each system | open until the measurement record exists |
| R-04 | DAC master clock ≥ 192 × FSR within the period, high and low limits | duty and edges at the DAC clock pin; fallbacks R203 0 Ω or the NDK oscillator | open until the measurement record exists |
| R-07 | Level after calibration 1.55 Vrms per leg (3.1 Vrms at the 4.4 mm jack) ±0.1 dB | production calibration to 1.55 Vrms ±0.05 dB | open until the measurement record exists |
| R-12 | High mode, 4.4 mm: ≥ 30 mW at 300 Ω | output power at 300 Ω balanced | open until the measurement record exists |
| R-14 | Default mode, 4.4 mm: ≥ 17 / 35 / 30 mW at 60 / 120 / 300 Ω | Default-mode power at 60 / 120 / 300 Ω | open until the measurement record exists |
| R-18 | Channel balance ≤ 0.3 dB (trim ±0.05 dB) | channel balance after trim | open until the measurement record exists |
| R-19 | DC offset ≤ ±10 mV unbalanced, ≤ ±20 mV balanced, 0–50 °C | offset test at 0–5 / 25 / 50 °C on all five boards | open until the measurement record exists |
| R-31 | Pop ≤ 20 mV at unplug or brown-out (target) | hot-unplug scope capture at music level | open until the measurement record exists |
| R-32 | USB current before configuration ≤ 100 mA | S1 current on every board (production test) | open until the measurement record exists |
| R-33 | USB Default ≤ 500 mA | production test on every board: S3 ≤ 480 mA, S1 ≤ 90 mA; fallback: a firmware current ceiling | open until the measurement record exists |
| R-36 | Suspend ≤ 2.5 mA within 10 ms of the last bus activity | suspend current on the first board, then on every board | open until the measurement record exists |
| R-47 | Connector pin maps continuity-tested before the schematic freeze: J101 12 lands and S1–S4; the J701 and J702 maps documented from the maker drawings, including J701 pads 11/12 (mounting tabs) and the J702 break contacts 5/6 (no connection) | G-1 continuity and G-3 1:1 overlay (J101; the J701 / J702 slots and peg holes); the G-2 record on two samples of each jack (section q) | open until the measurement record exists |
| R-57 | Boot self-test of the hardware DC path and the supervisor (pairwise coverage) | on every board: (e) 18–26 ms, (f) 65–110 ms, (g) 18–32 ms, PB0 low after each self-test trip; per-channel coverage by the production per-leg injection | open until the measurement record exists |
| R-64 | Leg-to-leg short of one channel | 30 min short-circuit survival test | open until the measurement record exists |
| R-66 | Stream guard after the CPLD (mitigation of a frozen CPLD word) | bit-exact capture at 352.8 / 384 kHz | open until the measurement record exists |
| R-73 | Default-mode acceptance criterion | production test S3 ≤ 480 mA, S1 ≤ 90 mA; firmware ceiling as the fallback | open until the measurement record exists |
| A-10 | DAC pin-pair mismatch and null offset | offset test at 0–5 / 25 / 50 °C on every board | open until the measurement record exists |
| A-14 | X201 duty cycle against the DAC limit (zero margin) | duty at the DAC clock pin; fallback R203 0 Ω | open until the measurement record exists |
| A-26 | I2S2 slave capture at 22.6 / 24.6 MHz | bit-exact capture at 352.8 / 384 kHz | open until the measurement record exists |
| A-29 | Reflow of the 2416 PPS film capacitors C631–C634 | JLCPCB confirms the reflow profile for the 2416 size (order remark), else owner-fit with the 1.5 mm iron clearance kept | open until the measurement record exists |
| A-34 | Latent single fault: Q622 drain–source short | production test: latch cleared and RELAY_EN high → every photorelay open, LED current < 10 µA | open until the measurement record exists |
| A-39 | Re-arm latch qualification | trips of 1 / 3 / 10 ms with RELAY_EN held high; an H dip above HREF; a hung MCU; power-up with RELAY_EN high; R692 open or U608 unpowered; the Q622 drain–source short production test | open until the measurement record exists |

**Open gates and the open process item** (section q):
- the G-2 record for J701 and J702 on two samples each, before schematic freeze (R-47, [Q]);
- JLCPCB's written confirmation of how the J101 shell stakes S1–S4 and the J702 pads 1/2 are soldered, before the order (R-70, open process item). Owner fallback: hand-solder them from the bottom side before the first plug-in; never use the board with the J101 stakes unsoldered.

**Open owner point** (section m, item 7): the copper ring of the J701 / J702 slot pads, to decide before the G-3 overlay; until then the pads stay as the maker drawings give them.

**New bring-up tests in R10:**
- **A-45 energy test:** a CPLD frozen 0 dBFS code at the calibrated level into a 32 Ω balanced dummy. Energy until the switch opens ≤ 15 mJ; the leg swing is logged.
- **A-46 reset level:** the timer reset level of Q623–Q626 is below 0.1 V; the timer T_P is checked at 0 / 50 °C.
- **A-39 latch set:**
  - trips of 1, 3 and 10 ms with RELAY_EN held high;
  - an H dip that stays above HREF;
  - a hung MCU;
  - power-up with RELAY_EN high;
  - R692 open, or U608 unpowered;
  - the Q622 drain–source short production test.
- **OR and LPW removal:**
  - 2.00 V per leg and polarity → 19.5–27 ms;
  - 3.8 V with full-scale 100 Hz content on the partner leg → ≤ 27 ms;
  - 0.35 V → 76–105 ms;
  - a full-scale 20 Hz sine for 1 s, then +0.97 V → ≤ 102 ms;
  - DC just above and just below the 0.34 V floor.
- **R-57 self-test** on every board: windows (e) 18–26 ms, (f) 65–110 ms, (g) 18–32 ms; PB0 low after each self-test trip. Per-channel coverage comes from the production per-leg injection.

## o. Parts

**BOM change against v1.0:** 65 designators added, 22 removed and 4 changed per board; 7 new part numbers and 3 retired (fitted part numbers 111 → 115; BOM lines 176 → 179).

| Change | Designators | Part | Function |
|---|---|---|---|
| added | U611, U612 | TI TLV1704AIPWR | per-leg over-range (OR) stages, left / right |
| added | R926–R929, C639–C642 | 330 kΩ, 1 nF C0G | OR tap filters (τ 0.33 ms) |
| added | R934 (360 kΩ), R935–R937 (470 kΩ) | UNI-ROYAL 0402 1 % | OR threshold dividers (R937 returned to the OR test line) |
| added | U613–U620 | TI TLV3402IDGKR | per-leg low-level persistence (LPW) stages, one per leg and polarity |
| added | R930–R933, C643–C646 | 1.00 MΩ, 3.3 nF C0G 0603 (FH 0603CG332J500NT) | LPW tap filters (τ 3.3 ms) |
| added | R942–R949, C647–C654 | 910 kΩ, 100 nF C0G 1206 (FH 1206CG104J500NT) | LPW timers |
| added | R938, R939 (100 kΩ), R940, R941 (88.7 kΩ) | 1.00 MΩ tops | LPW threshold dividers |
| added | Q627, R950 (100 kΩ), R951 (10 kΩ) | onsemi MMBT3904LT1G | OR self-test switch on the PC15 test line; R951 sets the positive test threshold |
| added | C655–C666 | 100 nF X5R 0402 | decoupling of U611–U620 |
| changed | Q623–Q626 | JSCJ MMBT3904 → onsemi MMBT3904LT1G (C81464) | persistence-timer reset transistors (same land) |
| removed | U601, U602 | TI TLV1704AIPWR | per-leg RC window stage |
| removed | R601–R604, C601–C604 | 115 kΩ, 2.2 µF | window filters |
| removed | R607–R610 | 121 kΩ / 115 kΩ / 10.0 kΩ 0.1 % | window threshold dividers |
| removed | R649–R652, C612–C615 | 100 kΩ, 100 nF | window comparator input resistors and decoupling |

**Buy now** into the JLCPCB part library:
- TLV3402IDGKR (C140314, 8 per board, U613–U620). JLCPCB shows 152 available against 40 + attrition (web-page copy of 26 Sep 2026).
- TLV1704AIPWR: the condition stays ≥ 31 in LCSC stock at order time (6 per board: U603, U606, U609–U612), priced at the 30+ tier of US$ 1.5567.

**Transistor change.** Q623–Q627 are onsemi MMBT3904LT1G (C81464, Extended, MSL 1): same pinout and land, datasheet VCE(sat) ≤ 0.2 V at 10 mA / 1 mA. Q612, Q614 and Q507 stay on JSCJ MMBT3904 (Basic).

**New C0G lines**, both LCSC-stocked, so no global sourcing is needed:
- FH 0603CG332J500NT (C190576, Extended), 3.3 nF 0603;
- FH 1206CG104J500NT (C46348, Extended), 100 nF 1206.

**New part numbers (7):** TLV3402IDGKR (C140314), onsemi MMBT3904LT1G (C81464), 360 kΩ (C45956), 88.7 kΩ (C25922), 910 kΩ (C25800), 3.3 nF C0G 0603 (C190576) and 100 nF C0G 1206 (C46348).

**Retired part numbers (3):**
- 115 kΩ 1 % (C25747);
- the globally sourced 0.1 % 121 kΩ (C852503) and 115 kΩ (C852488).

**Reduced quantities per board:** 10.0 kΩ 0.1 % (C190095) −2, 2.2 µF (C23630) −4, JSCJ MMBT3904 (C20526) −4, 100 kΩ −2.

**Zone fills** [E, nominal courtyards]: Z4 52 %, Z7 59.0 % against the 60 % zone rule; 59.6 % overall at 100 × 80 mm. The component stress table has 181 current rows: 146 OK, 14 availability notes, 17 thin, 4 data gaps, 0 FAIL.

**Connectors** (section q):
- J101 GCT USB4105-GF-A: 12 lands (four shared, eight single) plus four plated shell stakes S1–S4 and two locating holes; the provisional footprint has the 16 JLCPCB pad IDs.
- J701 G-Switch GT-3321667P-01 (owner-fitted): the owner-approved 12-pad map, confirmed by the G-Switch maker drawing (pads 11/12 are mounting tabs); 12 plated slots from the drawing; 12 THT joints.
- J702 HRO PJ-332A-6A (C2848643): SMD with two plated slot terminals, which are the two GND terminals (sleeve, ring 2); contact map from the HRO maker drawing, with the break contacts 5/6 on no connection; G-2 confirms it.
- The JLCPCB order has no through-hole-only part; the J101 stakes and the J702 slot terminals are soldered as JLCPCB confirms, or by the owner fallback at no cost unless JLCPCB quotes a hand-solder step.

**Sourcing data** (prices, stock, JLCPCB class) come from web-page copies read on 26 Sep 2026. Re-check them in the JLCPCB BOM tool at order.

**Cost** [E: attrition, PCB and shipping prices are assumptions; prices and stock are those of the day]. **Every total is an estimate until the supplier orders and the JLCPCB quote exist.**

| Item | US$ | NTD |
|---|---:|---:|
| JLCPCB-placed parts per board | 71.29 | 2,262 |
| Owner-fitted parts per board | 22.75 | 722 |
| All fitted parts per board | 94.04 | 2,984 |
| JLCPCB parts for five boards (exact need + attrition) | 397.33 | 12,607 |
| JLCPCB Standard PCBA fees, including the handling-fee top-up of US$ 40.50 | 312.97 | 9,930 |
| Global-sourcing extras | 29.52 | 937 |
| PCB, five panels | 23.00 | 730 |
| Shipping to Taiwan | 25.00 | 793 |
| JLCPCB order | 787.83 | 24,998 |
| Owner purchase: two distributor orders (owner-fitted parts and gate samples) | 161.60 | 5,128 |
| **Total, five-board order** | 949.43 | 30,125 |
| **Per assembled board** (JLCPCB 157.57 + owner 32.32) | 189.89 | 6,025 |

- Rate 31.73 NTD/USD, the v1.0 rate.
- Change against the v1.0 set (US$ 856.14): +US$ 93.29. JLCPCB parts +79.96 (the new protection stages, the TLV1704 line at the 30+ tier of US$ 1.5567, the onsemi transistor), assembly fees +13.35 (more Extended part types), global sourcing −0.02; PCB, shipping and the owner purchase unchanged.
- Information only: Economic PCBA would give US$ 934.50; it is not used (fine-pitch and reflow limits).

## p. Review dispositions

| Review item | What was done | Result |
|---|---|---|
| R10-A1: the zero-state sweep does not prove the 30 mJ limit for every fault history | Reachable pre-fault states defined; OR and LPW stages added; the removal and energy sweeps redone from every reachable state; the leg-window stage removed; no-false-trip checks re-run | Both counterexamples closed; under the Spec definition every calculated case meets 30 / 15 mJ above the 0.34 / 0.68 V floor under the stated engineering-estimate assumptions [E]; the one exception, the High-mode 32 Ω balanced frozen full-scale case, meets 15 mJ only with the typical output-swing credit (A-45) and remains an owner decision with a bring-up energy test |
| R10-A2: some G classes stronger than their inputs | Classes derived from the recorded inputs; the power, analog and protection class lists applied and every row re-walked; strict guards | 120 rows G 13 / E 80 / Q 22 / 5; R-13 and the stability rows E; Q rows stated as open obligations |
| R10-A3: not every advertised command reproduces | One release-verification command; release vs historical split; rails from the released dividers; one power input set; stale outputs regenerated | One command re-runs the 39 release checks from a clean copy; the package is published only when every check passes |
| R10-A4: latch wording | The unbounded sentence replaced by the implemented condition; latch tests listed | R-55 G (logic), R-72 E (timing), A-39 Q |
| R10-B: the no-mute claim holds only after calibration | Calibration rule (record, −4.5 dB default, gain ceiling); margins at both levels | Boundary guaranteed at or below the calibrated level; 13.9 / 6.6 % at the default |
| R10-C: stale R509 values in the power checks and the index | Regenerated with R509 4.75 k; report text marked; index stale guard | Package consistent; guard blocks the old values |
| R10-C holds G-1 to G-4, G-5 / G-6 | Kept | Freeze, routing and order stay on HOLD (section l) |
| R10-C first-board item: USB Default margin | Final budget regenerated | +6.54 mA (+2.04 mA with the NDK) [E]; production test S3 ≤ 480 mA (R-33, R-73 [Q]) |
| R10-C first-board item: MCU suspend current | Kept as a measurement | R-36 [Q]: first board, then every board |
| R10-C first-board item: photorelay timing over temperature | Kept as an assumption with a test | A-01 [E]: tOFF taken as 2 × the 25 °C maximum; tON / tOFF at 0 / 50 °C at bring-up |
| R10-C first-board item: the 32 Ω energy margin | Recomputed for the new design from every reachable state | 13.67 mJ (8.8 %) released, 14.87 mJ (0.8 %) with the fallback, on the typical swing credit; A-45 bring-up energy test |
| R10-C first-board item: MCLK duty | Kept as a measurement | R-04 and A-14 [Q]: duty at the DAC clock pin; fallback R203 0 Ω |
| R10-C first-board item: connector maps | Kept as gates | R-47 [Q]: G-1 / G-2 / G-3, two samples of each connector; the J701 and J702 maps are documented from the maker drawings and G-2 confirms them (section q) |
| R10-C first-board item: offset over temperature | Kept as a measurement | R-19 and A-10 [Q]: 0–5 / 25 / 50 °C on all five boards |
| Second hole: rail-stuck leg with full-scale partner content | The OR stage removes it with any partner content | ≤ 26.48 / 13.24 mJ at the fallback rail, removal ≤ 25.9 ms, from any reachable state [E] |
| Independent check: 32 Ω frozen full scale | Stated E item plus bring-up test; Default mode capped | A-45 (owner item); Default ≤ 11.10 mJ |
| Independent check: total terminal energy | Spec definition kept; totals published | Section e |
| Independent check: pairwise self-test | Stated limitation; per-channel coverage at production | R-57 Q |
| Independent check: reset VCE(sat) basis | Q623–Q627 moved to onsemi; extension kept E | A-46 E, bring-up test |
| Independent check: exact tier boundaries | Stated for the swept history set; bursts added | T3 ≥ 0.178 / 0.195 V in 2.36 s; < 3 s holds |
| Independent check: requirement floor precision | Floor rounded up with a leakage allowance | 0.34 / 0.68 V (R-74 E) |
| Independent check: LPW content-boundary wording | Stated on the timer (≥ 70.8 ms can, 91.9 ms plus the tap crossing and ≤ 1.8 ms will) and in raw-leg terms (≥ 62.9 ms) | Closed by the checker (A-44 E) |
| Cost statement | Stated as an estimate until the supplier orders and the JLCPCB quote exist | Section o |
| Independent summary check: headline figures and wording | Rail-bounded headline values; content-bounded values only for pre-fault content at or below the calibrated ceiling; frozen-code bound 118.8 ms at the floor; classes of the OR thresholds, the LPW timer and the calibrated ceiling; energy-definition exception; burst, offset, self-test and thermal wording | Sections b to i |
| SE-1: J101 shell-stake paste | Accepted; no F.Paste on S1–S4 until JLCPCB confirms in writing | G-6 order-release item; owner fallback (section q) |
| SE-2: J702 slot pads | Accepted; "SMD with two plated slot terminals" | G-6; owner fallback (section q) |
| SE-3: J101 12 lands / 16 pad IDs | Accepted; mapping stated | G-1 / G-3 (section q) |
| SE-4: J701 map | Accepted (owner-approved 26 Sep 2026); confirmed by the maker drawing; pads 11/12 are mounting tabs | G-2 confirms pads 11/12 (section q) |
| SE-5: J702 map | Corrected from the maker drawing (the stored map was wrong on pins 1–4); pins 5/6 are break contacts, no connection | G-2 confirms (section q) |
| SE-6: no manufacturing data from provisional assignments | Accepted | Stage table (section l) |
| SE-7: G-2 record procedure | Accepted | Section q |
| SE-8: register and wording | Accepted | R-70 open process item; R-47 extended; assembly wording (section q) |

## q. Schematic-capture review (26 Sep 2026)

**Basis.** The owner's message of 26 Sep 2026 (connector soldering-process hold; connector pin-map review) and the capture itself: nine sheets, "Schematic capture v1.0", built from Spec v1.0, Notes v0.9 and Parts List v0.8. Checked by the orchestrator:
- The GCT USB4105 drawing text lists 12 lands (A1/B12, A4/B9, B8, A5, B7, A6, A7, B6, A8, B5, B4/A9, B1/A12), four stake slots and two Ø0.65 mm locating holes.
- JLCPCB's stencil standard opens no paste on through-hole pads unless they are designed on the paste layer or remarked.
- JLCPCB lists C2848643 as SMT assembly, Economic and Standard, difficulty High, surface mount, TRRS.
- Our layout package already prescribed pin-in-paste on the USB4105 stakes, but gave no aperture geometry and had no JLCPCB approval.
- The capture is on the R9 design: sheet 6 still has U601/U602, R601 and C601, and none of U611–U620, Q627 or R951.
- The owner then supplied the maker drawings (26 Sep 2026): the HRO drawing "PHONE JACKES PJ-332A" (Rev A, 2021-06-03) with the PJ-332A-A schematic, PCB layout (top view) and bottom view; the G-Switch customer drawing C-GT03321667P-01 (GT-3321667P-01, Rev A0, 2020-07-10) with its schematic, recommended PCB layout, 3D view and BOM; and the JLCPCB / EasyEDA symbols and footprints of C2848643 and C2762984. They give the J701 and J702 contact maps (SE-9 / SE-10), which supersede SE-4 / SE-5 where they differ.
- Symbol convention, verified on the G-Switch drawing, whose contacts are labelled: the rectangle is the sleeve, the hook nearest it is the contact nearest the entrance, and the farthest hook is the tip.

**Dispositions:**

| Item | Disposition | Follow-up |
|---|---|---|
| SE-1 J101 shell-stake paste | Accepted | No F.Paste on S1–S4 until JLCPCB confirms pin-in-paste and the aperture geometry, or an order remark, in writing; a G-6 order-release item; owner fallback |
| SE-2 J702 slot pads | Accepted | Described as "SMD with two plated slot terminals"; JLCPCB confirms how pads 1/2 are soldered (G-6); owner fallback |
| SE-3 J101 12 lands / 16 pad IDs | Accepted | Mapping stated below; G-1 two-sample continuity and G-3 1:1 overlay decide |
| SE-4 J701 map | Accepted, owner-approved 26 Sep 2026; confirmed by the maker drawing; pads 11/12 are mounting tabs | 12-pad map below; G-2 confirms pads 11/12 |
| SE-5 J702 contact map | J702 map → corrected from the maker drawing (the stored map was wrong on pins 1–4); pins 5/6 are break contacts, no connection; G-2 confirms | Map below. History: the stored map had JACK_LP on pin 1, JACK_RP on pin 2 and GND on pins 3/4, which would have put both driven legs on the plug's sleeve contacts |
| SE-6 No manufacturing data from provisional connector assignments | Accepted | Stated in the stage table (routing and order rows) |
| SE-7 G-2 record procedure | Accepted | Procedure below |
| SE-8 Register and wording | Accepted | R-70 becomes an open process item until JLCPCB confirms SE-1 / SE-2; R-47 gains the J701 map, the J702 pins 5/6 rule and the G-2 record; assembly wording below |

**J101, GCT USB4105-GF-A.**
- The GCT drawing gives 12 solder lands:
  - four shared: A1/B12, A4/B9, B4/A9, B1/A12;
  - eight single: A5, A6, A7, A8, B5, B6, B7, B8.
- It also gives four plated shell-stake slots S1–S4 and two Ø0.65 mm non-plated locating holes.
- The netlist keeps the 12 composite labels plus S1–S4. The provisional footprint (DAC_HPA:J101_USB4105-GF-A_12lands_4stakes) uses the 16 JLCPCB pad IDs: each shared land is two touching pads on one net. It also has S1–S4 and the two unnumbered locating holes.
- **Soldering process:**
  - The design intent is pin-in-paste on S1–S4.
  - JLCPCB's stencil standard opens no paste on through-hole pads unless they are on the paste layer or remarked. So S1–S4 get F.Paste apertures only after JLCPCB confirms the process and gives the aperture geometry.
  - Fallback, no part change and no cost: JLCPCB reflows the 12 surface lands, and the owner hand-solders S1–S4 from the bottom side (no parts there) before the first plug-in. The stakes carry the shell and the mechanical retention; never use the board with them unsoldered.
  - A JLCPCB hand-solder step, if JLCPCB proposes one, is priced from their quote.
- Gates: G-1 continuity on two samples; G-3 1:1 overlay; process confirmation at G-6.

**J702, HRO PJ-332A-6A (C2848643).**
- The HRO drawing and the JLCPCB footprint have four surface lands (pins 3–6) and two plated slot terminals (pins 1/2): it is "SMD with two plated slot terminals", not "SMD".
- JLCPCB lists it as SMT assembly (Economic and Standard, difficulty High), but that does not establish how the slots are soldered.
- JLCPCB must confirm the method at G-6. The fallback is the owner hand-soldering pads 1/2 from the bottom side (2 joints). If JLCPCB cannot assemble it at all, J702 becomes owner-fitted, bought in the owner's LCSC order.
- **Contact map, from the HRO PJ-332A drawing.** The drawing's schematic (variant A) and its PCB layout both support it, and the JLCPCB footprint matches:

| Pin | Contact | Net |
|---|---|---|
| 1 | Sleeve | GND (dedicated sleeve return) |
| 2 | Ring 2 | GND (a TRS plug's sleeve spans it) |
| 3 | Ring 1 | JACK_RP |
| 4 | Tip | JACK_LP |
| 5 | Break contact of ring 1 (closed to pin 3 with no plug) | no connection |
| 6 | Break contact of the tip (closed to pin 4 with no plug) | no connection |

- Why pins 5/6 carry no net: tied to ground they would short JACK_LP / JACK_RP, which the 4.4 mm jack shares, whenever the 3.5 mm jack is empty.
- Pads: pins 1/2 are the plated slots, 0.60 × 1.5 mm holes in 1.00 × 1.9 mm pads. They are the two ground terminals, so the JLCPCB slot-soldering question concerns ground and retention only. Pins 3–6 are 1.6 × 1.5 mm surface lands. There are two Ø1.20 mm locating pegs. The 0.20 mm copper ring of the slot pads is an open point for the owner (section m, item 7).
- Reflow rating: the drawing gives none (housing PPA). The existing reflow-rating check stays open.
- Verification: the map is documented. G-2 on two samples confirms it, including the break contacts opening on insertion.
- The per-net pin counts are unchanged.

**J701, G-Switch GT-3321667P-01 (owner-fitted).** The owner approved the manufacturer / JLCPCB 12-pad map on 26 Sep 2026 (footprint JLC_Imported:AUDIO-TH_GT-3321667P-01); the G-Switch drawing C-GT03321667P-01 confirms it:

| Pad | Contact | Net |
|---|---|---|
| 1 | GND | GND (dedicated sleeve return, ≥ 4 vias) |
| 2, 3 | R− | JACK_RN |
| 4, 5 | R+ | JACK_RP |
| 6 | L− | JACK_LN |
| 7, 8 | L+ | JACK_LP |
| 9 | SWITCH | no connection |
| 10 | DETECT | no connection |
| 11, 12 | "ep": the two "Contact H" mounting tabs | no connection (soldered) |

- It replaces the seven-pin map, which wrongly put JACK_LP on pad 1.
- Pads 11/12 are the two tabs of the maker's BOM item "Contact H" (phosphor bronze, Ni-plated, not a gold contact); the maker schematic does not show them. They are mounting or retention tabs. They stay unconnected but soldered. G-2 checks whether they are common with the sleeve or the bushing; if they are, they may be tied to GND in a later revision, and no connection is safe either way.
- Holes, from the drawing: 12 plated slots of 0.50 (+0.10/0) × 1.40 (+0.10/0) mm in 1.00 × 1.90 mm pads, and two Ø1.20 mm locating holes for the Ø1.00 ± 0.05 mm pegs. The former G-2 step "measure the hole and peg sizes" becomes a 1:1 overlay confirmation at G-3. The copper ring of the slot pads (0.25 mm; 0.20 mm at the slot tolerance) is an open point for the owner (section m, item 7).
- Owner fitting: 12 THT joints (10 contact pins plus the two mounting tabs).

**G-2 record** (gate table and bring-up chapter):
- On two samples of each jack, label the physical terminals from the JLCPCB footprint top view.
- Record continuity from every terminal to the tip, each ring, the sleeve and any metal shell:
  - with no plug;
  - with the plug fully inserted;
  - while slowly inserting and removing the plug, to identify the switch / detect contacts.
- For J702, test with a TRS plug and with any TRRS plug the design allows; the record confirms the maker-drawing map, including the break contacts 5/6 opening on insertion.
- For J701, the record confirms the maker-drawing map and whether pads 11/12 are common with the sleeve or the bushing.
- Record every pair of terminals that are internally common.
- The resulting table sets the final symbol pin names, nets and footprint pad assignments.

**Question to JLCPCB** (owner action before the order; quoted as written): "For a top-side Standard PCBA order, can you solder the four plated shell slots S1–S4 of GCT USB4105-GF-A (J101) and the two plated slots 1/2 of HRO PJ-332A-6A, C2848643 (J702)? Do you require F.Paste apertures or an order remark, and what aperture geometry/hand-solder step do you recommend?"

**Assembly wording.**
- The JLCPCB order has no through-hole-only part. J101 (four plated shell stakes) and J702 (two plated slot terminals) mix surface lands with plated terminations, and JLCPCB must confirm how those are soldered (G-6).
- Exposed bottom-side copper now also includes the J702 slot rings.
- The earlier check that no JLCPCB-placed part is at a process limit is no longer guaranteed: it stays open until JLCPCB's answer (R-70, open process item).
- A capture scan or ERC confirms consistency only. It does not verify a connector's physical contact map.

**Capture note for the schematic engineer.** Capture v1.0 uses the old J702 map. Recapture sheet 7 to the J702 map above, and sheet 6 to Parts List v0.9 (the R10 protection changes). The other sheets change only where Parts List v0.9 "Changes vs v0.8" lists them.
