# R8 integration decisions (orchestrator), 25 Sep 2026 — read this first

Context: v0.9 redesign of Diego Yang's USB DAC + balanced headphone amplifier (CH32V307 → AGRV2K CPLD → ES9018K2M → OPA2210 I/V → OPA1622 legs → 3.5 mm J702 / 4.4 mm J701). Budget is not a constraint; the goal is flawless operation meeting every requirement, layout-ready. Master brief: `brief_r8_master.md` (requirements §4, conventions §5). Each stream folder `<stream>/` holds `report.md`, `bom_rows.csv`, `netlist.csv` and scripts from round 1. Round-2 follow-ups were interrupted; this file replaces the lost follow-up messages. Integration checker: `python3 integration/check_design.py power protection analog digital` (writes `integration/check_result.json`).

Status of round 2 before the interruption:
- power: `calc/pw_common.py` and `calc/c03_usb_budget_ilim.py/.out.txt` updated (TPS2596 U503, TMUX1101 U505, TLV758P U303, TPD2E2U06 U103, USB4105 J101, R532); report/BOM/netlist NOT yet updated.
- digital: netlist/BOM updated (PA12/PB9 freed, R233 4.7 k DAC_RESETB series, TP732, U206 → 74LVC1G11 with MCLK_PERMIT on PB14 + R234), `firmware_sequences`, `mclk_gate_race`, `levels_and_pullups` outputs written; report.md NOT updated; `currents` not updated.
- analog: nothing from round 2 saved.
- protection: round-1 report complete (4 PhotoMOS, TLV1704 comparators, CM window, 3 firmware tiers); it assumed Panasonic AQV251GAX.
- parts: `followup_r8.md` Follow-up 1 and 2 saved; Follow-up 3 (X201 search) and `layout_package.md` update NOT done.

## Decisions (binding for all streams)

D-1 Output switch. Four photorelays, one per leg, K601 LEG_LP→JACK_LP, K602 LEG_LN→JACK_LN, K603 LEG_RP→JACK_RP, K604 LEG_RN→JACK_RN (protection stream's architecture A2, 24/24 plug cases isolated). Part: **Toshiba TLP3545A(TP1,F)** (60 V, 4 A, Ron ≤ 0.06 Ω at 25 °C with IF 5 mA, IFT ≤ 3 mA, ton ≤ 5 ms, toff ≤ 0.5 ms, LED VF 1.64 typ / 1.80 V max at 10 mA, reflow 260 °C/10 s). Pins (parts stream, same for both parts): 1 LED anode, 2 LED cathode, 3 unused (no copper, per Panasonic; confirm on the Toshiba drawing), 4 and 6 switch outputs, 5 common source — leave unconnected. Panasonic AQV251GA(X) is a second source ONLY if JLCPCB confirms a Standard-PCBA reflow peak ≤ 250 °C (its limit); otherwise excluded. Drive: protection stream's two current-limited LED strings from 5V_SYS (MMBT3904 limiter), in series with Q616 (gate MCLK_EN) and Q617 (gate permit node H). Must guarantee IF ≥ 5.0 mA per string at 5V_SYS = 4.30 V with TLP3545A VF maxima. Budget: ≤ 14.3 mA on 5V_SYS + ≤ 1.02 mA on 3V3M while RELAY_EN is high (protection p05) unless recomputed.

D-2 Jack wiring (fixes a round-1 conflict). J701 pin 2 (ring 1, L−) → **JACK_LN**, pin 4 (ring 3, R−) → **JACK_RN** (not LEG_LN/LEG_RN). D701–D704 all sit on the jack side (JACK_LP, JACK_RP, JACK_LN, JACK_RN) and must be **bidirectional** (legs swing ±3.8 V) with VRWM ≥ 4.1 V; verify LESD5D5.0CT1G (C41399463) from its datasheet, state its clamp voltage, or replace it. Every DC-sense and detector tap stays on LEG_xx. R417–R420 0 Ω DFT links stay between the OPA1622 outputs (N4_xx_OUT) and LEG_xx.

D-3 X201 (DAC MCLK) — REVISED 25 Sep 2026 after parts Follow-up 3. The Epson SG-210STF 75 MHz is end-of-life (all 75 MHz codes obsolete, EOL notice 25 Jun 2020; current list stops at 72 MHz, which fails 192 x FSR). X201 = **Kyocera KC2520K80.0000C1GE00**: 80.000 MHz CMOS SPXO, 2.5 x 2.0 mm, pin 1 stand-by (H or open = run, L = oscillation stop, VIH >= 0.7 VCC, VIL <= 0.3 VCC, disable <= 200 ns, enable/start-up <= 3 ms), 2 GND, 3 OUT, 4 VCC; Icc <= 8.0 mA at 2.8-3.63 V, 62.5-80 MHz, with the maximum 15 pF load over temperature; stand-by <= 5 uA; symmetry 45-55 %; tr/tf <= 4.5 ns; +-50 ppm, -40...85 C; phase jitter 1.0 ps max (12 kHz-20 MHz) per the Kyocera catalogue (not in the spec text: [MEAS]); reflow 260 C x2, MSL 1; DigiKey 2,964, Mouser 1,375 (JLCPCB global sourcing; LCSC C1988889 not stocked). ESS: 80 MHz / 384 kHz = 208.3 > 192 (+8.5 %); period 12.5 ns >= 10 ns; high/low >= 5.5 ns >= 4.5 ns; soft start 104.9 ms (soft_start_time 10); DPLL ratio with 80 MHz. Budget X201 + R227 = 8.2 mA [DS + CALC]. C217 = 10 nF at the pad. Conditional second source: NDK NSC5338D-80M (NZ2520SH-80.000M), 9.0 mA max at 25 C only, needs bring-up checks (disable time, edges), budget 12.7 mA. TXC 7X-80.000MBE-T is withdrawn (3,000-piece factory order, output-disable only, 8 ns edges). SCTF SX3M80 is NOT approved (40 mA, Default non-compliant). Combined 2520/3225 land unchanged.

D-4 Other clocks unchanged: X202/X203 NDK NZ2520SDA (NSC5083D) 49.152/45.1584 MHz with stand-by; U205 74LVC1G157 mux; U206 74LVC1G11 = MCLK_EN AND AVCC_EN AND MCLK_PERMIT driving X201 ST; R227 holds XI low. The SCTF SX3M49.152/45.1584 parts are a **non-compliant fallback** (output-disable only, both run, +25 mA → Default targets not met); say so wherever they appear.

D-5 Analog current limiter: U503 → **TI TPS259621DDAR** (SO-8 PowerPAD, auto-retry, OV-clamp variant, LCSC C2155774), Default/High ILM switching with **U505 TMUX1101** (R510 in series with the switch, parallel to R509), R509/R510 0.1 % 25 ppm. Selection rule (power stream): Default total = non-analog maximum + IOS max + IQ ≤ 490 mA (10 mA reserve to 500 mA); High IOS min ≥ 390 mA and ≥ the analog High peak need. Default IOS min must be ≥ the analog stream's recomputed need (was 174.2 mA with LM339B; recompute with TLV1704 and the new DC-sense networks) and ≥ 180 mA if the budget allows.

D-6 Rails (final): R501 221 k / R502 100 k and R503 205 k / R504 100 k, 0.1 % thin film → VPOS 3.789 / 3.852 / 3.915 V, |VNEG| 3.661 / 3.721 / 3.781 V [power CALC].

D-7 1V3: U303 → **TI TLV75801PDBVR** (LCSC C2877852, 113,390 in stock) with 15.0 k / 11.0 k 0.1 % → 1.283–1.317 V (ESS needs 1.235–1.365 V); internal active discharge. Power stream decides whether Q506/R530 stay; DVDD ≤ DVCC in every ramp.

D-8 Input and misc. power: J101 → **GCT USB4105-GF-A** (C3020560; 48 V/5 A; soldering 255 °C (−0/+5) ≤ 5 s — Standard PCBA, confirm with JLCPCB); map USB-C contact names to GCT pad numbers from the GCT drawing. **U103 TPD2E2U06DRLR** (C1972959) on CC1/CC2 at J101. U102 TPS25200 unchanged. **R532 470 kΩ** pin-side pull-down on PB4/RAILS_OK_N (digital data: FT VIH ≥ 1.756 V worst case, leakage ≤ 3 µA → R_pd ≤ 560 k). C301/C302 → 2.2 µF 16 V 0603 (C23630) (parts P-M2). OPA2210: buy 12 now.

D-9 Comparators: U601–U603 **TLV1704AIPWR** (protection). Rail currents I+ ≤ 1.26 mA, I− ≤ 1.25 mA including dividers and the H pull-up (replaces 2 × LM339B).

D-10 3V3A loads: ESS AVCC_L + AVCC_R 16 mA, VCCA 0.8 mA (nominal), VREF divider 0.167 mA, protection networks 1.82 mA (5 DC-sense/reference networks 1.69 + CM threshold chain 0.13).

D-11 Retired nets: DOM_DIS, AMP_EN, FLT, FLT_CLR. MCU PA12 and PB9 are spare (analog input). OPA1622 EN (pin 8) tied to VPOS.

D-12 Net names at the OPA2210 outputs: rename the analog stream's N4_IVL → **N4_IVL_P** (DACL I/V output), N4_IVLB → **N4_IVL_N**, N4_IVR → **N4_IVR_P**, N4_IVRB → **N4_IVR_N** (protection's R653–R656 connect there). The analog stream changes its netlist; protection keeps its names.

D-13 ADC: ADC2 continuous DMA scan of DC_SENSE_LP/LN/RP/RN, V3A_MON (+ CC1_ADC, CC2_ADC), ≥ 10 kHz per sense channel (protection requirement), sampling time chosen from the WCH R_AIN table for each source impedance (sense nodes R_TH 2.49 kΩ; CC nodes ≈ 15 kΩ) at ADCCLK 12 MHz; ADC offset handled by the protection reference network (reading = leg − reference). ADC1 single channel VBUS_SENSE (C103 10 nF), analog watchdog 4.00 V. The round-1 digital choice (239.5 cycles, 147 µs per 7-channel scan = 6.8 kHz) does not meet ≥ 10 kHz and must change.

D-14 Assembly: **JLCPCB Standard PCBA, top side only**, panel with rails and fiducials (≥ 70 × 70 mm with rails). Leadless parts need X-ray.

D-15 Programming mode (CPLD/JTAG): because ESS needs VCCA/AVCC no later than DVCC and the analog stream needs the I/V rails whenever 3V3A is up, programming mode = normal power-up through AUD_EN (ANA_EN, RAIL_EN, rails good, AVCC_EN, AUD_EN), RESETB low, MCLK off, output switch open. The source must supply this current (charger/bench, ≤ 500 mA).

D-16 Suspend: SOF-loss timer 1.0 ms → RELAY_EN low → wait 1.1 ms → MCLK off → domain order; digital CALC: suspend current reached ≤ 2.76 ms after the last SOF (margin 7.24 ms).

D-17 Hot unplug: the Schottky output clamps D405–D408 (Nexperia BAT54S,215 on the I/V outputs) bound the DAC-pin excursion; the analog stream evaluates a simple hardware fix (time-boxed) or states the residual plainly as "every hot unplug".

D-19 Output-switch MCLK permit (digital round-2 finding): the protection tap R645 (1 k to the Q616 gate) is fed from **U206 output N2_MCLK_OE** (= MCLK_EN AND AVCC_EN AND MCLK_PERMIT, the actual X201 run signal), not from MCLK_EN, so any MCLK stop (CPLD, MCU reset via MCLK_PERMIT, AVCC_EN low) opens the output switch in hardware. R235 100 k pull-down on N2_MCLK_OE; MCU PB1 reads it back for a boot self-test of U206/R234.

D-18 Requirements unchanged (brief §4): Default-mode power targets (3.5 mm 32 Ω ≥ 38 mW; 4.4 mm 60 Ω ≥ 17 mW, 120 Ω ≥ 35 mW, 300 Ω ≥ 30 mW) and High-mode targets stay requirements; USB ≤ 100 mA unconfigured, ≤ 500 mA Default, suspend ≤ 2.5 mA within 10 ms; protection energies ≤ 30/15 mJ; offset limits; pop ≤ 5 mV controlled.

## Load table to use (maxima, labelled) — power stream owns the final table
3V3M: MCU 80 mA [ASSUMP; WCH typ 22.4 mA at 144 MHz all peripherals on, PHY unpublished], LEDs 0.80 + 0.73 mA, pull-ups/pull-downs per power c03, switch drive 1.02 mA (RELAY_EN high), R234 0.33 mA (PB14 high), R233 0.032 mA.
3V3D: CPLD 40 mA [ASSUMP], X201 + R227 8.2 mA [D-3 revised], one NDK 15 mA + other stand-by 0.035 mA [DS 25 °C], U205 4.7 mA, U206 + pull-downs + I²C 4.7 k ≈ 2.9 mA [digital], DAC DVCC 14.2 mA [DS nominal], DVDD 60 mA through U303 [PH; ESS nominal 50 mA at 80 MHz/192 kHz], TLV758P IGND + divider.
3V3A: D-10.
5V_SYS direct: LED strings 14.3 mA (RELAY_EN high), TPS25200 IQ 0.19 mA, dividers, USBLC6, legacy-cable Rp.
5V_ANA: analog stream's quiescent (recompute: OPA1622 4.2 mA/ch and OPA2210 3.25 mA/ch over temperature [DS], TLV1704 per D-9, DC-sense networks draw ≈ 0.24 mA per leg from V− (node ≈ 1.61 V through 6.8 kΩ into a 0 V leg) [CALC to confirm], CM summing ≤ 14 µA, LM27762 1.0 mA [ASSUMP], PGOOD pull-up 55 µA, charge-pump factor 1.03 on I− [PH]) + TPS2596 IQ.
