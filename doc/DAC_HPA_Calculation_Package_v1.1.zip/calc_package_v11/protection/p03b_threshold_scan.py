#!/usr/bin/env python3
"""p03b - Threshold / time-constant scan for the 1-pole leg windows.

Rule: for each nominal threshold Vth, pick the smallest E96 R1 (C1 = 1.0 or 2.2 uF) such that a
FULL-SCALE SQUARE wave at 20 Hz (the worst bounded waveform for an RC, so any full-scale content with
half-period <= 25 ms) never trips at the fastest components and lowest trip level. Then report
worst-case energies: rail-stuck (SE 16/32 ohm), moderate balanced +-x from a stuck DAC pin at silence
(x from the trip level to 1.2 V, above which the CM window acts in <= 2.9 ms, p04), and the frozen-code
case (leg windows only)."""
import numpy as np
from pcommon import *
import p03_detector as d3

def trip(vth_target):
    rb = 10e3
    ra = d3.e96(rb * (VPOS_NOM / vth_target - 1)); ran = d3.e96(rb * (VNEG_NOM / vth_target - 1))
    return ra, rb, ran, rb

out = [__doc__, ' Vth_nom  |trip| worst    C1    R1     tau(min/nom/max) ms  sine fc  sq fc | E_rail16 E_rail32 | '
       'moderate +-x max E32 (x)  E16 (x)   | frozen E32  E16 | t(1V) t(2V)']
for vt in (0.20, 0.25, 0.30, 0.35, 0.40, 0.55):
    ra, rb, ran, rbn = trip(vt)
    best = None
    for c1 in (1.0e-6, 2.2e-6, 3.3e-6):
        for r1 in sorted({d3.e96(x) for x in np.geomspace(30e3, 400e3, 300)}):
            th = d3.thresholds(ra, rb, ran, rbn, r1, 100e3)
            dd = dict(r1=r1, c1=c1)
            (Af, Bf), (As, Bs) = d3.corners_of(dd)
            if d3.square_peak(Af, Bf, 20.0, A_FS) < th['trip_min']:
                best = (r1, c1, th, dd); break
        if best and best[0] <= 220e3:
            break
    r1, c1, th, dd = best
    (Af, Bf), (As, Bs) = d3.corners_of(dd)
    fs = d3.corner(Af, Bf, A_FS, th['trip_min'])
    fq = d3.corner(Af, Bf, A_FS, th['trip_min'], kind='square')
    ev = d3.evaluate(dd, th)
    # moderate +-x (balanced, stuck pin at silence), CM covers x >= 1.2 V
    em32 = (0, 0); em16 = (0, 0)
    for x in np.linspace(th['trip_max'] * 1.005, 1.2, 120):
        t = d3.step_time(As, Bs, x, th['trip_max']) + d3.T_EXTRA
        e32 = (2 * x) ** 2 / 32 * t
        x16 = leg_dc_max(x, 8.0, VPOS_MAX); e16 = (2 * x16) ** 2 / 16 * (d3.step_time(As, Bs, x16, th['trip_max']) + d3.T_EXTRA)
        if e32 > em32[0]: em32 = (e32, x)
        if e16 > em16[0]: em16 = (e16, x)
    f32 = d3.frozen_pm_x(dd, th, 32.0); f16 = d3.frozen_pm_x(dd, th, 16.0)
    tn = r1 * c1 * 1e3
    out.append(f'  {vt:5.2f}  {th["trip_min"]:.3f}-{th["trip_max"]:.3f}  {c1*1e6:4.1f}u {r1/1e3:5.0f}k  '
               f'{tn*(1-d3.R_TOL_FILT)*d3.C_LO:5.0f}/{tn:4.0f}/{tn*(1+d3.R_TOL_FILT)*d3.C_HI:4.0f}   '
               f'{fs:5.1f}   {fq:5.1f} |  {ev["E_rail16"]*1e3:5.1f}   {ev["E_rail32"]*1e3:5.1f}  |   '
               f'{em32[0]*1e3:5.1f} ({em32[1]:.2f})  {em16[0]*1e3:5.1f} ({em16[1]:.2f}) | {f32[0]*1e3:5.1f} {f16[0]*1e3:5.1f} | '
               f'{ev["t1V"]*1e3:4.0f} {ev["t2V"]*1e3:4.0f}')
txt = '\n'.join(out); print(txt); open(__file__.replace('.py', '_out.txt'), 'w').write(txt + '\n')
