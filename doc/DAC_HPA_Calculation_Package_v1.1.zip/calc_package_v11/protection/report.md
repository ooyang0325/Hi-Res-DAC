# Protection stream (brief §7.2) — R8 / v0.9 report

Diego Yang USB DAC + balanced headphone amplifier · protection engineer · round 1: 24 Sep 2026 · round 2: 25 Sep 2026 · round 3 (review fixes): 25 Sep 2026 · VE: 25 Sep 2026 · OD-1/OD-2: 25 Sep 2026 · R9: 25 Sep 2026 · R10: 26 Sep 2026
Scope: block 6 (DC detector, thresholds, filters, permit, DC-sense ADC networks, 3V3A reference/monitor), the output switch K601–K604 with its driver, firmware protection numbers (tiers, stream DC guard, fault policy).

Labels: **[DS]** datasheet min/max (source in §13), **[DS-typ]** typical only, **[CALC]** worst case from a script in this folder (file named), **[ASSUMP]** assumption, **[MEAS]** bring-up measurement with a designed-in fallback.
All [CALC] numbers come from the scripts `p01…p09*.py`; their full outputs are the matching `*_out.txt` files. The round-2 section comes first; the round-1 report follows unchanged except for "⟶ R2" markers on superseded numbers.

---

# R10 fixes — 26 Sep 2026

Binding inputs: `r10/decisions_r10.md` (facts 1–9, F-1…F-7) and `r10/reviews_r10.md`; orchestrator reproductions `r10/history_check.py`, `r10/railstuck_check.py`. My items: **F-1 (lead)**, F-3 (share), F-4, F-5 (share). All numbers below are **class E** (they rest on [ASSUMP] bounds: tOFF 2 × the 25 °C maximum, TLV3402 delay 3 × typical, the X7R C_T2 bound, the ≤ 1 µA / ≤ 0.1 µA node-leakage bases, the typical OPA1622 swing model for the balanced sweep cap and the ISC bound); every bring-up test below is an **open qualification obligation (Q)** — no board exists.

New scripts (release calculations, self-contained, each with `_out.txt`): **`p21_r10_f1.py`** (reachable states, v1.0 reproduction, R10 design numbers, sweeps from just above every trip, floor, loads), **`p21b_r10_content.py`** (time-domain no-false-trip checks at the most sensitive corners, content boundaries, self-test windows), **`p21c_r10_tiers.py`** (firmware tiers below the floor over a swept, finite history set), **`p21d_r10_bom.py`** (BOM/netlist generator, idempotent, reads only the shipped CSVs), **`p22_r10_fs32.py`** (hand-over: 32 Ω balanced frozen-FS case without the swing credit, option study). One command reproduces them: `cd protection && python3 p21_r10_f1.py && python3 p21b_r10_content.py && python3 p21c_r10_tiers.py && python3 p21d_r10_bom.py && python3 p22_r10_fs32.py`. `check_design.py power protection analog digital`: **474 parts, 247 nets, 1388 pins, 0 issues** (118 value-decode lines with R951 and the FH C0G lines, hand-over; 473 / 246 / 1386 and 116 lines before). Backups: `*_r10pre.*`.

| Item | Action | Result | Evidence |
|---|---|---|---|
| **F-1 (a)** reachable pre-fault states | Defined per node: v1.0 leg-window filter anywhere inside its trips (worst −0.320 V for a positive fault); R10 prefilter taps anywhere in the content range (worst −A_PRE = −2.325 V, the calibrated peak incl. the G-bounded 3V3A drift, analog F-5); LPW timers anywhere from full reset (VNEG + VOL) to 0 V; E-3 timers anywhere 0 V … V_T (0 V bound added; p18 used 0.02 V); CM node (τ 0.55 ms) anywhere in its window (≤ 0.16 ms extra, inside p04's 3 τ); CIC² windows and DC-sense networks: any sub-threshold state, FS content, or both; partner leg: any content ≤ A_PRE (E-3 therefore not credited for single-leg faults) | used as the sweep starting points in (b) | `p21_r10_f1_out.txt` (a) |
| **F-1 (b)** v1.0 from reachable states | Both counterexamples reproduced with the orchestrator model and with the package model (design rails incl. the R501 fallback) | **Fact 2:** ±0.97 V/leg after one 20 Hz negative half-cycle 137.6 ms → **32.4 / 16.2 mJ**; from −0.320 V 195 ms → 46.0 / 23.0 mJ; from rest at 1.005 / 1.01 × trip 38.7 / 34.1 mJ. **Fact 3:** single leg stuck at 3.789 / 3.915 / 4.049 V with FS partner content ≥ 50 Hz (E-3 reset every cycle), from −0.32 V: **44.6 / 46.2 / 47.8 mJ** at 16 Ω SE (22.3 / 23.1 / 23.9 mJ at 32 Ω). Package sweep from the worst state, just above the trip: 106.9 mJ (16 Ω bal., logarithmic divergence). v1.0 fails the hardware requirement from history | `p21_r10_f1_out.txt` (b1) |
| **F-1 (c)** design (least cost that holds from every state) | **(1) Per-leg over-range (OR) stages** U611 (L legs) / U612 (R legs), **TLV1704** (existing line): LEG_xx → 330 k → 1 nF C0G tap → tap > V_OR+ and tap < V_OR−; the open-collector outputs sink the **E-3 NPN-reset base of the natural direction** (LP+ & LN− → c+, LP− & LN+ → c−), so the existing E-3 timers (19.50–23.37 ms) and their TLV1704 timer comparators on N6_H give persistence and the strong H pull; V_OR+ = 3V3A × 470/(360 + 470) = **1.764–1.964 V**, V_OR− = VNEG × ½ = **−1.762…−1.959 V** (divider returned to the OR test line). Transparent to balanced content (V_OR min / (V_L max/2) = 1.75). **(2) Per-leg low-level persistence (LPW) stages** U613–U620, TLV3402IDGKR, one per leg and polarity: LEG_xx → 1.00 M → 3.3 nF C0G tap; ch1 releases its timer (910 k from VPOS, 100 nF C0G 0805) while the tap is beyond **V_LL+ 0.279–0.322 V / V_LL− −0.283…−0.324 V** (3V3A × 100/1100, VNEG × 88.7/1088.7), else sinks it to VNEG (fast reset, ≤ 9.6 ms full); ch2 sinks the E-3 base when the timer passes 0 V: **T_P2 51.3–68.5 ms** (history-independent; combined LPW + E-3 persistence 70.8–91.9 ms). C0G and 910 k are needed so that a polarity reversal of FS content ≥ 20 Hz (a 50 ms one-sided lobe) cannot trip: with 680 k or 820 k and X7R the LPW output asserted inside E-3's second window and bridged it (p21b runs 06:12–07:06). **(3) The RC leg windows are retired** (U601/U602, R601–R604, C601–C604, R607–R610, R649–R652, C612–C615): every function they had is covered from any state by LPW/OR, and their 0.8 mA per rail pays for the OR comparators. **(4) OR self-test**: when N6_ORTEST is high, Q627 (MMBT3904) pulls V_OR+ to a defined **0.086–0.141 V through R951 10 k** (hand-over fix: without R951 V_OR+ sat at Q627's VCE(sat) ≈ 15–50 mV, below the ≤ 20 mV idle-leg offset + comparator error, so a positive OR channel could fire with no test word — false self-test pass or fail) and the test line lifts V_OR− to −0.147…−0.287 V. **Why TLV1704 for OR:** a TLV3402 OR stage releases up to 0.9 ms late at a square edge and moved the FS-square boundary 25.6 → 26.8 Hz (p21b first run); with the TLV1704 the boundary is unchanged. Rejected: a low-level *pair* stage (cannot see single-leg faults with partner content, and conflicts with the leg-window self-test), a CM-sum detector (current-limit clipping into 16 Ω balanced creates CM), faster RC windows (sine/square rejection), diode clamps on the E-3 taps (leakage on 328 kΩ nodes), keeping U601/U602 as LPW level comparators (current and placement) | from the worst reachable state, every level from just above each trip: **balanced 16 Ω 25.7 mJ** (1.008 V/leg, 101 ms, 14 %), **32 Ω 14.87 mJ** at the fallback swing limit 2.166 V/leg (0.8 %; **13.67 mJ, 8.8 % with the released rails**); **single leg / rail-stuck, any partner content: 16 Ω SE 26.4 mJ** (4.049 V fallback, 25.8 ms, 12 %; 24.7 mJ at 3.915 V), 32 Ω SE 13.2 mJ; 16 Ω balanced one-leg-stuck 14.9 mJ; **DC ±1 V removed ≤ 101 ms, ±2 V ≤ 27.1 ms** (limits 250 / 100 ms). Counterexamples now: fact 2 → 23.9 / 11.9 mJ, fact 3 → 23.1–26.4 / 11.6–13.2 mJ. Near the LPW level the time grows only through the 3.3 ms prefilter: at V_LL(1 + 10⁻⁹) 176 ms, 4.6 mJ | `p21_r10_f1_out.txt` (c1, b2) |
| F-1 (c) **level floor** (to be written into Spec v1.1) | The hardware requirement holds from every reachable state above the LPW level maximum (0.32401 V/leg, 0.64803 V pair; 0.33401 / 0.66803 V with a 10 nA tap leakage allowance). **Requirement floor, rounded UP with clearance (hand-over, indep-check): \|leg DC\| ≥ 0.34 V (single leg) and \|pair\| ≥ 0.68 V (balanced ±x), class E.** At the floor the delay is bounded: ≤ 118.8 ms, 3.43 mJ at 16 Ω balanced. A floor equal to the comparator maximum would have an unbounded delay just above it, and 0.324 V was rounded down; below it no hardware detector acts (physics of any level detector). **Surface leakage (parts THIN row):** 10 nA on a 1.00 M LPW tap moves the level by 10 mV (0.269–0.334 V). The requirement floor above is set to 0.34 / 0.68 V for this reason (p21 c2; p21c uses the same floor). Proposed Spec v1.1 text: "hardware-only: DC ≥ 2 V removed ≤ 100 ms, ≥ 1 V ≤ 250 ms from any prior state; ≤ 30 / 15 mJ at 16 / 32 Ω for a rail-stuck output of either polarity (incl. the R501 fallback) and for balanced ±x with \|2x\| ≥ 0.68 V, balanced up to the swing limit; below the floor the firmware tiers keep ≤ 30 / 15 mJ and remove ≥ 0.2 V within 3 s" | firmware below the floor (p21c, over the swept history set — steady, FS content, short opposite-polarity bursts, LPW-limited excursions; finite, not a universal bound; an unswept history delayed a trip by ≤ 9 ms in the independent check): T1 ≥ 1.001 / 1.015 V within 218 ms, T2 ≥ 0.313 / 0.312 V within 603 ms, T3 ≥ 0.178 / 0.195 V within 2.36 s (rail-bounded variant 1.007 / 1.027, 0.316 / 0.316, 0.179 / 0.197 V; residual ≤ 2.43 mW) → worst below the 0.68 V pair floor **17.4 mJ (16 Ω) / 8.7 mJ (32 Ω)** (was 15.8 / 7.9 mJ with the 0.648 V floor), owner 0.2 V / 3 s rule met. **The tiers are history-robust as they are** (FIR CIC², memory 2 W; the worst history raises their guaranteed levels by ≤ 3 mV and the deadlines by ≤ 5 %): no firmware tier change | `p21c_r10_tiers_out.txt` |
| F-1 (c) budget, space | Fact 9 rule (≪ 1.2 mA at 5V_ANA, preferably ≤ 0.3 mA); Z7 ≤ 60 % | **VPOS +0.054 mA, VNEG +0.062 mA, 3V3A +0.007 mA, 3V3M/3V3D 0** (test line only in the self-test) → **5V_ANA +0.12 mA** (Default margin +1.23 → ≈ +1.11 mA); block 6 I+ ≤ 2.71 / I− ≤ 2.54 mA (the 06:55 message to power gave +0.078 / +0.086 mA with the first timer values — a bound). Area: Z7 −133.6 mm² retired, +128.4 mm² (U611/U612, OR taps/references, Q627, decoupling) + R951 → **59.0 %** (parts courtyard model, 806.8 / 1,368 mm²; headroom ≈ 14 mm²); Z4 +193.6 mm² (U613–U620 with the C0G timers, LPW taps and references, decoupling) → ≈ 47 %; with the LCSC-stocked C0G parts in 0603 (3.3 nF) and 1206 (100 nF) chosen at hand-over, +33 mm² → **≈ 52 %** (parts courtyard model; the R half of the LPW group may sit in Z4s) | `p21_r10_f1_out.txt` (e1); sent to power 06:55 |
| **F-1 (d)** no-false-trip | Time-domain model of E-3 + OR + LPW at the most sensitive corner of every part (T_P min, T_P2 min, lowest levels, slowest taps, release delays, slowest resets), every onset phase, 20 Hz–2 kHz (above: taps below every OR/LPW level, E-3 window < 0.25 ms) | Sines ≥ 20 Hz never trip at the calibrated level (2.192 / 2.230 V, +G drift 2.325 V) nor at the −4.5 dB default (1.828 / 2.180 V): E-3 alone and the combined system give the same peak timer progress (OR/LPW add no run time); LPW timers stay ≤ −1.46 V (threshold 0 V). **Squares: unchanged** (E-3: certain ≤ 21.4 Hz, possible ≤ 25.6 Hz). Bursts and reversals: a FS 20 Hz single half-cycle burst and a FS 20 Hz polarity reversal at a zero crossing do not trip; one FS 20 Hz square cycle and the asymmetric 20 Hz + 2nd-harmonic wave trip **E-3 alone** (pre-existing v1.0 boundary: a pair lobe beyond V_L for ≥ 19.5 ms); a 0.30 V offset with a 0.9 V 20 Hz sine does not trip | `p21b_r10_content_out.txt` (d1, d2) |
| F-1 (d) **new content boundary** (stated plainly) | Stated on the timer (wording corrected at hand-over, indep-check): the LPW timer runs while the **3.3 ms-filtered leg tap** is beyond ±0.279–0.324 V (≈ −17 dBFS). A mute **can** occur once the tap has stayed beyond V_LL for ≥ 70.8 ms. It **will** occur after 91.9 ms plus the amplitude-dependent tap crossing and ≤ 1.8 ms of comparator delays; the crossing is unbounded as the level approaches V_LL max, e.g. +11.6 ms for a step from −2.325 V to 0.5 V. In raw-leg terms, a FS excursion can mute after ≥ 62.9 ms, because the tap lags by ≤ 7.0 ms and the release adds 0.9 ms. **DC offset with the 10 nA leakage allowance (level 0.269–0.334 V; p21b d3):** it CAN mute from 0.116 FS (drift-ceiling FS 2.325 V; 0.120 at +0.15 dB, 0.123 at nominal) and WILL mute on every unit from 0.162 FS (lowest FS 2.059 V; 0.150 at +0.15 dB, 0.152 at nominal). Examples with the allowance: FS sine < 6.54 Hz (6.52 without, unchanged at 6.5 Hz); squares 0.8 / 0.5 / 0.35 V up to 7.4 / 7.2 / 6.9 Hz (unchanged), 0.30 V squares up to 6.7 Hz | sustained sub-20 Hz content: a FS sine below 6.5 Hz (old RC windows: 11.5 Hz), squares between −17 dBFS and the E-3 level at or below ≈ 7 Hz (0.35 V: 6.9 Hz, 0.8 V: 7.4 Hz), a steady offset ≥ 0.145 FS (old windows ≥ 0.12–0.14 FS after ~1 s; OD-1 P4 ≥ 0.15 FS), any asymmetric waveform with a one-sided excursion ≥ 71 ms. The old aged-capacitor square corner (FS 20 Hz square, 6.2 %) is gone | `p21b_r10_content_out.txt` (d3) |
| **F-1 (e)** BOM/netlist | `p21d_r10_bom.py`; designators continue after the existing ones | **new 65 parts:** U611/U612 TLV1704AIPWR (existing line), U613–U620 TLV3402IDGKR (new MPN), R926–R951 (R951 10 k = global Basic line C25744, hand-over), C639–C666, Q627; **retired 22** (list above). Nets N6_ORxx, N6_LWxx, N6_TWxxx, N6_VORP/N, N6_VLLP/N, N6_ORTEST, N6_ORTB, N6_ORQC | `p21d_r10_bom_out.txt`, `bom_rows.csv`, `netlist.csv` |
| F-1 (e) boot self-test (digital implements) | a′ (RC windows) deleted; **(f) LPW:** CPLD DC ±0.30 FS on L then R → DC_PERMIT_N high 72.4–99.8 ms + DAC ≤ 1 ms (pass 65–110 ms); **(g) OR:** N6_ORTEST high (reference nodes settle ≤ 90 µs to 1 mV: digital's 1 ms confirmed), DC ±0.25 FS → 19.5–24.9 ms + DAC (pass 18–32 ms; a failed OR shows as a late LPW trip; test thresholds +0.086…+0.141 / −0.147…−0.287 V, idle-leg margins 66 / 128 mV, word margins 186 / 41 mV); (e) E-3 unchanged (18–26 ms). Word **±0.55 FS on calibrated units** (digital's proposal; 0.50 FS left only +44 mV at the calibration low end with the drift down) and **±0.85 FS at the −4.5 dB default**; pair ≥ 2.27 V, +250 mV over V_L max; the OR is silent on calibrated units; b, c, d unchanged; PB0 low after every trip | coverage is **pairwise** (hand-over correction of "every new channel"). LP+/LN− and LP−/LN+ share one N6_OL base, so a failed pair, a failed shared path or a both-sided reference fault is detected. A single dead channel or an open one-sided reference (e.g. R937 → all negative OR channels, R939 → all positive LPW channels) is masked by its mate. Per-channel coverage comes only from the production / bring-up per-leg injection; a boot-time per-channel test needs a one-sided test mode (a second test line, no MCU pin left) — owner item; **3.68 s** with all channels at every boot, or **2.96 s** with one OR direction per boot (all four within 4 boots) | `p21b_r10_content_out.txt` (e2); sent to digital 06:55 |
| F-1 (e) bring-up tests (Q) | amplifier link R417–R420 removed, DC injected on LEG_xx, tiers in test mode | per leg and polarity: 0.25 V 10 s → no trip; 0.35 V → trip 76–105 ms (LPW); 0.50 V → 73–100 ms; 1.70 V → 71–97 ms (OR silent); 2.00 V → 19.5–27 ms (OR); 3.8 V with FS 100 Hz content on the partner leg → ≤ 27 ms (fact-3 case); FS 20 Hz sine for 1 s, then +0.97 V → ≤ 102 ms (fact-2 case); content: FS sines 20 Hz–20 kHz at the calibrated level and at −4.5 dB, 60 s each → no trip; FS square 26 Hz no trip / 21 Hz trip (unchanged); 0.35 V square 5 Hz trip / 8 Hz no trip (new); FS 20 Hz polarity reversal at a zero crossing → no trip; OR test line high + ±0.25 FS → 19.5–26 ms | this table |
| **F-3** rails, p19, sweeps | pcommon: **RAIL_REL** (VPOS 3.789–3.915, \|VNEG\| 3.661–3.781 V), **RAIL_FB** (R501 232 k: VPOS 3.919–4.049 V), **RAIL_DESIGN** envelope used by every R10 release calculation; the legacy bound (3.789–4.014 / 3.618–3.828 V) is kept only for the unchanged historical scripts and documented: exact on the minimum side (V_L min, sine margins), conservative at the released maximum, **not** covering the fallback 4.049 V, which p21 covers. **p19 marked HISTORICAL GENERATOR** (not a release calculation); `p20_r9_selftest.py` was never shipped (output only) → historical; release equivalents p21d / p21b. Every R10 sweep starts just above its trip (V_LL(1 + 10⁻⁹), V_L/2 and V_OR ± 10⁻⁶ refinements) | no historical constant enters a release number | `pcommon.py`, `p19_r9_bom.py` header |
| **F-4** latch wording | "however short" replaced by the implemented condition | **Any trip that pulls N6_H below HREF (2.883–3.029 V released, up to 3.133 V with the R501 fallback) clears the E-2 latch within ≤ 0.373 ms after the comparator switches (0.346 ms with the released rails; 0.383 ms if the R501 fallback is fitted): H from VPOS to HREF at ≥ 4 mA into 1.1 µF + 330 k × 60 pF + 1 k × 1 nF.** **A disturbance that never reaches HREF neither clears the latch nor opens the switch (Q617 keeps ≥ 2.88 V gate drive, above its 2.5 V RDS(on) point).** All R10 stages trip through TLV1704 outputs on H, so the same bound holds. **Qualification obligations (Q, none passed):** comparator-path trips of 1, 3, 10 ms with RELAY_EN held high → switch stays open, PB0 low until a fresh edge; an H dip that stays above HREF → no clear, no opening; RELAY_EN held high (hung MCU) → no re-close after any trip; power-up with RELAY_EN high → open; R692 open / U608 unpowered → Q622 off; Q622 D–S short production test (LED current ≈ 0 after a trip) | the latch is bounded by the implemented timing | `p21_r10_f1_out.txt` (F-4) |
| **F-5** margins (share) | E-3 20 Hz sine time above V_L min vs T_P min 19.50 ms | **calibrated 2.192 V 6.4 %, +0.15 dB 2.230 V 5.7 %, + G drift 2.325 V 4.3 %; −4.5 dB default 13.9 % (model 1.828 V) / 6.6 % (3.66 V basis, 2.180 V)**; untrimmed highest gain 3.069 V → 20.26 ms > 19.50 → trips. **Reset-level sensitivity (indep-check):** T_P min 19.50 ms uses VCE(sat) ≤ 0.20 V for Q623–Q626, the 10 mA / 1 mA row of other MMBT3904 sources. The fitted JSCJ C20526 datasheet gives only ≤ 0.30 V at 50 mA / 5 mA, which would mean T_P min 18.84 ms, margins 3.1 / 2.4 / 0.9 % (calibrated / +0.15 dB / + drift), 10.8 / 3.3 % at the default, and FS squares possibly muted up to 26.5 Hz. Ebers–Moll at the real operating point (IC ≈ 35 µA, forced β ≈ 3.5) gives ≤ ≈ 0.11 V [E] (p21 sensitivity line). The content boundary is guaranteed only at or below the calibrated level; an uncalibrated board must run at the −4.5 dB default (digital's record check). OR/LPW add no run time at any of these levels | `p21b_r10_content_out.txt` (d1) |
| F-2 dependencies (for integration) | classes of my results; row-by-row list sent to r10-integration (hand-over) | F-1 energies/times **E** (A-01 tOFF, A-33, A-04, new A-43 = TLV1704 tpd 5 µs + LPW node leakage 0.1 µA, TYP swing model for 32 Ω); the calibrated content ceiling (A_PRE 2.325 V) is only a SCOPE with margin: the p21 (b3) variant bounds the pre-fault taps by the rail instead (±2 V 27.2 ms, ±1 V 102.7 ms, rail-stuck 26.48 / 13.24 mJ, balanced 16 Ω 26.08 mJ) and the p21c variant bounds the tier content pre-state by the rails (T1 1.003 / 1.017 V, T2 0.313 / 0.312 V, T3 0.177 / 0.194 V, same deadlines, energies unchanged, residual ≤ 2.35 mW) → R-20…R-25 and R-61 stay E without R-07; R-26 / A-31 proposed E with SCOPE (E-3 20 Hz sine first trips at 2.659 V/leg, +1.16 dB over the 2.325 V ceiling), Q if the calibration is read as an input; floor (new R-74) G; LPW content boundary (new A-44) E; 32 Ω without swing credit (new A-45) E + Q test; A-18 and A-23 retired | `p21_r10_f1_out.txt` (b3), `p21c_r10_tiers_out.txt` (variant) |

**Issues for the owner / orchestrator (stated plainly):**
1. **Self-test time:** full coverage at every boot is 3.68 s (> the 3 s target); rotating the OR test gives 2.96 s with full coverage every 4 boots. Recommendation: full coverage (3.68 s).
2. **E-3 at 32 Ω balanced full swing (not changed by R10; class E):** 13.67 mJ (8.8 %) with the released rails, **14.87 mJ (0.8 %) if the R501 fallback is fitted**; the sweep is capped by the typical OPA1622 swing model as decided ("up to the swing limit"). **Without that credit** (p22): E-3 alone stays ≤ 15 mJ only up to 2.175 V/leg; a frozen code gives **15.23 / 15.77 / 17.14 mJ at 2.192 / 2.230 / 2.325 V/leg** (and 15.07 mJ at the −4.5 dB default on the 3.66 V basis). **Physics:** a frozen code is the first half-period of a FS square, so keeping FS squares ≥ 25.6 Hz unmuted forces ≥ 19.53 ms at any level ≤ 2.325 V/leg → floor **14.55 mJ**, leaving a 3.4 % window for every timer tolerance (6.6 % if the E-2 latch clear were credited) — no RC timer fits. **The proposed high-level short-persistence stage (V_H 3.9–4.1 V pair, T_H 10–13 ms) was checked and NOT adopted:** sines pass (8 % margin at 2.325 V), but it mutes FS squares up to 50 Hz (fails F-1 d) and needs ≈ 12–14 parts. Options: **(A)** keep it as a stated E item + bring-up qualification test (CPLD frozen 0 dBFS code at the calibrated level into a 32 Ω balanced dummy: energy until the switch opens ≤ 15 mJ, and the leg swing) — 0 parts, recommended; **(B)** calibrated full scale −0.6 dB (1.55 → 1.45 Vrms per leg) and uncalibrated default −5.1 dB → 14.93 / 13.12 mJ without any swing credit, 0 parts, owner decision (max output −0.6 dB; firmware: two constants, M_DEF 0x4727DEE6 and target 1.4465 Vrms/leg (digital); self-test word (g) then 0.30 FS instead of 0.25 FS (negative-side margin 82 mV instead of 17 mV at the lowest default gain), (f) stays 0.30 FS (72.5–100.8 ms); pass windows and totals unchanged); (C) the H stage only with an owner-accepted FS-square boundary ≤ 50 Hz; (D) a precision stage — not viable. **Default mode (orchestrator check, p22 §5):** the U503 limit (IOS max 222.6 mA) caps the load current. It is never removed: TPS2596 current limiting has no fault timer, no FLT and no auto-retry, and thermal shutdown cannot occur within 25 ms. **Bound ≤ 11.10 mJ** (legs settle at ≤ 1.781 V/leg). The bound credits no quiescent current, no swing, no LDO dropout and no UVLO, and it includes the capacitor energy and a 0.3 ms 1.5 × ILIM overshoot; the typical view gives 5.0 mJ. The removal is always by E-3 (≤ 25.4 ms): RAILS_OK_N is firmware-only (< 25 ms = headroom event), the CM window is not disturbed (I/V reservoirs) and the X-6 supervisor does not act. Class E (current cap G; E-3 timing E) → **A-45 exists in High mode only** (IOS ≥ 395.4 mA gives no cap).
3. The new LPW content boundary (row F-1 d) is adopted by default.
3b. **E-3 reset transistor source — adopted at hand-over (parts proposal):** Q623–Q627 → **onsemi MMBT3904LT1G (C81464, Extended, MSL 1, US$ 0.0167)**. Its datasheet gives VCE(sat) ≤ 0.2 V at 10 mA / 1 mA and ICEX ≤ 50 nA; the pinout and land are unchanged. The 0.20 V design value now rests on a datasheet row of the fitted part. Extending it to IC ≈ 35 µA at forced β ≈ 3.5 is register A-46 (ASSUMP, E; Ebers–Moll ≤ ≈ 0.11 V). Bring-up Q test: measure the timer reset level (expected < 0.1 V). Cost: ≈ +US$ 0.16 per order in parts (25 pcs × (0.0167 − 0.0104)) plus ≈ US$ 1.53 per order for one more feeder-loading type (parts, cost_calc Standard rule). Q627 is included to keep the row single-MPN (+≈ US$ 0.03 versus leaving it on C20526). Q612/Q614 stay on JSCJ C20526.
3c. **Self-test coverage is pairwise**, not per channel (see the F-1 e row). Options (digital data, 26 Sep):
   - **(A) State it as a limitation** — 0 parts; per-channel coverage at production. **Recommended:** the independent firmware tiers still remove single-leg DC ≥ 1 V within 218 ms.
   - **(B) Per-channel OR** — split N6_ORTEST into T+ (PC15 → Q627) and T− (a spare CPLD IO → R937 return, with an external pull-down); +1 part, +1 RTL bit, 8 OR runs; self-test **4.65 s** (digital timing model).
   - **(C) Also per-channel LPW** — one-sided V_LL switching; ≈ +4–6 parts and a second CPLD line; self-test **5.92 s**.
   Digital has implemented option A (§12, report F-1b). Under option B (−0.6 dB FS) the (e) words keep +98 / +99 mV.
   Owner decision.
3a. **Energy definition (raised by r10-indep-check, 26 Sep; owner/orchestrator decision needed):** every rail-stuck figure above follows the Spec definition "terminal energy E = V²/R × removal time" (V = the fault DC; decisions_r10 fact 3 uses V_stuck²/R on an SE load). An SE load (leg to GND) never sees the partner-leg content, so for SE loads the DC energy is the total terminal energy (26.48 / 13.24 mJ). **For a balanced load with one leg stuck at the rail while the partner leg keeps playing FS content**, the TOTAL terminal energy ∫v²/R dt is higher (p22 §6, 20 Hz–2 kHz, worst phase, removal 25.85 ms): **≈ 24.1 mJ at 32 Ω in High mode** (24.7 mJ without the 190 mA partner current limit [ASSUMP]; worst near 20 Hz, where the partial content cycle adds to the DC). At 16 Ω the partner current limit (190 mA [ASSUMP]) holds it to 14.9 mJ; without that credit (49.4 mJ unclipped) the High-mode U503 cap (IOS max 489.7 mA, loop current ≤ 245 mA) still bounds it to **23.85 mJ ≤ 30 mJ** (p22 §6b). In Default mode the U503 cap gives ≤ 11.3 mJ. So under a total-energy reading the High-mode 32 Ω balanced one-leg-stuck case fails. **Hardware fix evaluated (orchestrator time-box, p22 §7): a fast high over-range stage is NOT adopted.**
- **Threshold window:** V_H must lie between ≈ 2.45 V (content 2.325 V + 5 %) and 2.80 V. At 2.80 V a leg held just below V_H and removed by OR in 25.85 ms gives 14.90 mJ at 32 Ω balanced, so every tolerance (3V3A, resistors, VOS, the ±0.1 V VF of a diode selector) must fit in 0.35 V.
- **The loaded stuck leg sags:** a leg shorted to its rail follows the rail. With the High-mode eFuse minimum (395.4 mA) and the maximum quiescent current, it sags to 2.82 V at the partner's negative peak at 32 Ω and to 0.25 V at 16 Ω. After a step it stays above 2.75 V for only 1.4–1.6 ms. Detection would have to beat that, the TLV3402 delay has no maximum, and a drifting fault defeats it.
- **Cost:** the least-part topology (diode max/min selectors, one TLV3402 dual, references, RCs, trip via the E-3 V_T node — a sketch, not checked in the netlist) needs 16 parts plus a self-test provision (> 12). Z7 is full and Z4 would reach ≈ 60 %. It adds ≈ +0.06 mA.
- **A-45:** not closed; frozen codes ≤ 2.325 V lie below any usable V_H.
- **Recommendation:** keep the Spec definition E = V_DC²/R × t and publish the total-terminal figures plainly (32 Ω balanced one-leg-stuck, High mode 24.1–24.7 mJ; 16 Ω ≤ 23.85 mJ without the ISC credit; SE = DC energy; Default ≤ 11.3 mJ).
4. New MPN TLV3402IDGKR (VSSOP-8, LCSC C140314, Extended, US$ 1.3642; 152 in stock against a need of 40 + attrition, so buy at order) and five new passive lines: 360 k C45956, 88.7 k C25922, 910 k C25800 (0402); 3.3 nF C0G 50 V **FH 0603CG332J500NT C190576 (0603)**; 100 nF C0G 50 V **FH 1206CG104J500NT C46348 (1206)**. The two C0G lines are the LCSC-stocked fallbacks, chosen at hand-over because no 0402 / 0805 C0G 50 V listing exists (no global sourcing); electrically the same C0G ±5 %. The optional 10 nF on N6_VLLP/N6_VLLN is declined: the TLV3402's slow response and the 51 ms LPW timer reject clock pickup, so the 10 mm layout rule suffices. N6_ORTEST pin for digital; leg-tap loading for analog.

**Hand-over additions (successor r10-protection-2, 26 Sep, file times 07:17–07:50):**
- **Consistency:** p21, p21c and p21d re-run byte-identical to the shipped outputs (BOM/netlist identical); the checker (run from a copy so the integration file stayed untouched) gave 473 / 246 / 1386, 0 issues, **116** value-decode lines (this section had said 117).
- **p21b text fix:** the self-test pass windows and totals are now generated from one table, with an inside-window check: (f) 72.4–99.8 ms, pass 65–110; (g) 19.5–24.9 ms, pass 18–32; (e) 19.5–24.2 ms, pass 18–26; totals 3.68 s, or 2.96 s rotating. Re-run 07:37; (d1)–(d3) are unchanged.
- **R951 added:** see F-1 (c)(4). BOM 51 lines / 210 parts; checker 474 / 247 / 1388, 0 issues, 117 lines.
- **p21 (b3):** new class-E variant with the pre-fault taps bounded by the rail, so there is no calibration input.
- **p22:** new option study for owner issue 2.
- **Tripped state (analog question; analog is not running):** block 6 in the tripped state is **not** just "normal + 79 µA per rail through R647". Each E-3 NPN base that is sunk (by E-3, OR or LPW; up to 4 bases through R916–R919, 330 k) adds +15.0 µA on VPOS and +24.0 µA on VNEG.
  - Bound: **VPOS ≤ normal + 139 µA, VNEG ≤ normal + 175 µA**; a single-leg fault gives +94 / +103 µA.
  - Released timers reduce this: E-3 −35 µA on VPOS each; LPW −8.7 µA on both rails each.
  - This applies only while the switch is open, so the Default budget is unaffected.
- **Other analog answers:** the TLV3402 (U613–U620) and TLV1704 (U611/U612) stages run on VPOS/VNEG; their references come from 3V3A and VNEG. The I/V-side CM network (R653–R656, U603, R660–R664 and caps) is unchanged.
- **Messages sent:**
  - r10-integration: the F-2 row list, the P18S steps/keys and the historical-generator split.
  - r10-digital: 1 ms settle confirmed, R951, and a resend of the 06:55 content with the final values.
  - r10-parts and r10-indep-check: the R951 delta.
  - r10-power-2: the load FYI (the budget stays on the conservative bound).
  - r10-analog and r10-power are cancelled; their answers are above.

---

# R9 fixes — 25 Sep 2026

> **Superseded in part by "R10 fixes" (above):** the RC leg windows U601/U602 (R601–R604, C601–C604, R607–R610, R649–R652, C612–C615) are retired; every energy or time below that credits them "from rest" is replaced by the any-state results of p21. The E-3 detector is unchanged; its timers now also serve the R10 OR and LPW stages.

> **Superseded in part by "R9 check fixes" (end of this section):** the E-3 timer now uses an NPN reset (Q623–Q626). D611/D612 and R_D are deleted, R_T is 110 k, C_T 220 nF and V_T 0.5889 × VPOS. E-2 gains R696, and its test pulses are ≥ 1 ms. The E-3 numbers in the table below are the pre-check values; the final ones are in the subsection.

Binding inputs: `r9/decisions_r9.md` (E-1…E-15) and `r9/reviews_r9.md`. My items were E-2, E-3 (lead), E-11 (with digital), the U605 alternate (E-14), the energy tables and the bring-up tests. New scripts:
- `p17_r9_e3.py` / `p17b_r9_e3_2pole.py`: filter-type windows, rejected;
- `p18_r9_e2e3.py`: adopted design numbers;
- `p19_r9_bom.py`: BOM/netlist;
- `p19_r9_e11_out.txt`: R665 check.

Round-VE/OD files are kept as `*_ve*.bak` / `report_od.md.bak`. `check_design.py power protection analog digital`: **no issue on protection nets** (the only remaining issue, N5_U102_OFF, is digital/power's).

| Item | Action | Result | Evidence |
|---|---|---|---|
| **E-2** minimum off-time after ANY trip (R9-B1) | **Hardware re-arm latch.** U608 74LVC1G74 on 3V3D: CP = RELAY_EN, D = RD̄ = N6_CLR_N, Q = N6_ARM → R692 1 k → **Q622 AO3400A in series with Q617** (Q617 source now N6_M3). N6_CLR_N comes from R691 100 k to 3V3D, pulled low by Q621 2N7002 whose gate N6_TRIP (R690 330 k to 3V3D) is released by the **spare U606 ch4** only while H > N6_HREF = VPOS × 330/430 (R693/R694). PB0 reads N6_ARM through R695 (digital netted it). | Any H dip below **2.88–3.11 V** clears ARM asynchronously; clear dominates. That is above the level at which Q617 loses drive (≤ 2.5 V), so every dip that can touch Q617 disarms. ARM is re-set only by a fresh RELAY_EN low→high edge while H is OK. A hung MCU with RELAY_EN static high can never re-close. Power-up, U606 unpowered, or 3V3D off → disarmed. No new closing path (series switch only). Single failures either keep the old H path or keep the switch open. Clear path ≤ 0.37 ms (faster than Q617; not credited). | `p18_r9_e2e3_out.txt` |
| E-2 firmware (digital) | Re-arm: RELAY_EN low (≥ 1 ms) → wait until DC_PERMIT_N has read low ≥ 150 ms (H may need ≤ 80 ms more to pass HREF; replaces the pre-close "≥ 50 ms") → pre-close → RELAY_EN low→high → PB0 high within 1 ms, else retry after 20 ms (max 3, then fault). Only PB0 is needed; E-3 adds no MCU pin, ADC tap or readback. | agreed with digital (17:23); implemented in firmware_sequences §18 (PB0 must also read low after each self-test trip). Effect: the power-up close moves to **540.8 ms** (was ≤ 405 ms in R2.7) and the worst rate/family change to **972 ms**. | messages |
| **E-3** close L-11 in hardware (R9-B2/D5) | **[superseded by "R9 check fixes": NPN reset, R_T 110 k, C_T 220 nF, V_T 0.5889 × VPOS; T_P 19.5–23.2 ms; 32 Ω 14.5 mJ / 16 Ω 27.5 mJ]** **Pair-difference large-DC persistence detector.** One TLV1704 per channel (U609 L, U610 R), outputs on N6_H. Level channels c+/c− compare LEG_cP and LEG_cN through matched 487 k / 1.00 M dividers, one returned to VPOS: trip when \|LEG_cP − LEG_cN\| > VPOS × Ra/Rb. Each level output drives a timer node through R_D 68 k: C_T 22 nF C0G ±2 %, R_T 750 k from VPOS, BAS70-05 clamp to GND. The timer channels trip H when the node passes V_T = 0.6994 × VPOS (R924/R925). Filter-type windows were rejected (p17/p17b): with the rail-derived threshold spread, no 1- or 2-pole RC separates a full-scale 20 Hz sine at onset from 2.14 V DC within 23 ms. | **V_L 1.80–2.00 V** (pair difference); **T_P 19.7–22.4 ms** (C_T = Panasonic ECH-U1H223GX5 PPS film ±2 %, 1210, parts E-21: no stocked C0G ±2 % found). Full-scale sine ≥ 20 Hz stays beyond V_L for ≤ 18.4 ms → **never trips (6.0 % margin after the reset residual)**. Full-scale squares mute ≤ 22.4 Hz on every unit, may mute up to 25.3 Hz. Frozen code ±1.51/2.02/2.14 V removed in **≤ 24.3 ms** (was 69/51/48 ms). | `p18_r9_e2e3_out.txt` |
| E-3 new worst case over **all DC levels** (balanced and SE; levels just below V_L fall to the old windows) | **[superseded by "R9 check fixes": NPN reset, R_T 110 k, C_T 220 nF, V_T 0.5889 × VPOS; T_P 19.5–23.2 ms; 32 Ω 14.5 mJ / 16 Ω 27.5 mJ]** min(new detector, old leg windows, p03 slow corner) | **16 Ω balanced 27.5 mJ (8 %)** at 0.99 V/leg (old windows, 112 ms); **32 Ω balanced 14.0 mJ (7 %)** at 2.14 V/leg (new detector, 24.4 ms); SE 12.8 / 6.4 mJ (57 %) → **30/15 mJ met for every fault class; L-11 removed.** p06's stuck-pin envelope (27.2/13.6 mJ) is unchanged. | `p18_r9_e2e3_out.txt` |
| E-3 C_T sourcing (parts 18:00) | **[superseded: C_T is now Panasonic ECH-U1H224GX9 220 nF, 2416]** C631–C634 Panasonic ECH-U1H223GX5: reflow 260 °C max and ≤ 95 s above 220 °C vs JLCPCB Standard peak ≤ 245 °C, 45–90 s above melting → JLCPCB global sourcing, placed in reflow. Order remark: "confirm time above 220 °C ≤ 95 s". If not confirmed → owner-fitted (1210, O-4; 1.5 mm iron clearance already reserved in layout_package §13a). | agreed | parts 18:00 |
| E-3 cost and loads | **[superseded: D611/D612 deleted, Q623–Q626 added; block 6 I+ 2.66 / I− 2.48 mA]** +2 TLV1704, 16 + 4 + 4 + 2 resistors, 4 C0G, 2 BAS70-05, 4 decoupling caps | VPOS +0.85 mA, VNEG +1.02 mA max (≈ ½ typical) → **block 6 I+ 2.51 / I− 2.65 mA**; sent to power/analog for E-6 (a TLV3404 level stage would save ≈ 0.4 mA if needed). Analog to confirm leg loading (2 × 1.487 MΩ per leg, ≤ 2.7 µA injected). | messages 17:20 |
| E-3 leg interface (for analog) | Taps are on LEG_xx (amplifier side), two resistive dividers per leg: 487 k + 1.00 M 0.1 %, 1.487 MΩ each, 0.74 MΩ Thevenin. One returns to GND (node ≈ 0 V). The other returns to VPOS (node 1.24–1.31 V) and sources ≤ 2.7 µA into the leg. No C on the nodes beyond ≈ 3 pF of comparator input behind the 487 k; ≤ 1 pF of pads on the leg. | Well above analog's ≥ 20 kΩ resistive-tap bound; analog to confirm the ≤ 2.7 µA DC injection | message 17:23 |
| E-3 analog confirmation and the TLV3404 variant | Analog (17:27/17:29): leg load 0.744 MΩ per leg, < 1 nV offset, noise < 1e-15 V/√Hz, THD/CM/stability unaffected. **Pop:** while VPOS ramps with the switch open, the leg is held only by the DC-sense path (10.7 kΩ), so the VPOS-returned taps shift it by ≤ 29 mV. Through COFF 1 nF that is ≤ 1.09 mV at 300 Ω even as a 20 kHz-band edge, far less over the ms ramp, and a separate event from the AVCC_EN step; block 6 raises the guaranteed Default need to 178.81 mA (G margin +0.13 mA at R509 4.78 k). **TLV3404 level-stage variant (−0.4 mA per rail) not adopted as default:** the TLV340x has no guaranteed maximum delay. On typical × 3 it would cut the sine false-trip margin 6.4 → ≈ 4 % and the 32 Ω energy margin 7 → ≈ 4 %. | Proposed to power/analog: R509 ≤ 4.78 k keeps G positive with TLV1704. The variant (U609 TLV3404 × 4 level, U610 TLV1704 × 4 timers) was offered as a netlist regroup. **Closed by orchestrator E-18:** R509 = 4.75 k 0.1 % owner-fitted, TLV1704 kept, analog G margin +1.23 mA at IOS min 180.1 mA. **Power (17:33):** Default IOS 180.1 / 201.3 / 222.6 mA vs need 178.81 mA → G +1.21…+1.29 mA; USB Default total 493.45 mA ≤ 500 (planning values); High (R510 3.74 k) 395.4 / 442.7 / 489.7 mA. | messages 17:27/17:29/17:32/17:33 |
| **E-11** R665 330 Ω (R9-A9) | **Adopted: R665 = 330 Ω** (own BOM line, UNI-ROYAL 0402WGF3300TCE, LCSC C25104 to confirm), with digital's layout rule: X201 → R203 → XI ≤ 10 mm, R665 at the XI pin, R665 → U607 ≤ 3 mm | U607 toggling now **provable at the Kyocera 4.5 ns edge: +141 mV** to VT+max at the 2.4 pF CI bound (+248 mV at 1.5 pF); the round-3 limitation is closed. MCLK-alive dead ≤ 0.452 ms is unchanged. X201 load **≤ 14.2 pF even without the effective-C credit** (digital 17:26: 13.1 pF excluding the tap, XI 10 pF = ESS maximum, trace 1.3 pF with the rule, 2.4 pF counted behind R665) → 0.8 pF margin; XI high/low ≥ 5.49 ns vs 4.5 ns. Without the rule it would be 15.5 pF, so the rule is **mandatory** and was sent to parts for layout_package.md: ≤ 10 mm absolute (no 20 mm allowance), R665 pad on XI ≤ 1.5 mm from pin 7, R665 → U607 ≤ 3 mm. | `p10_supervisor_out.txt`, `p19_r9_e11_out.txt`, digital 17:23/17:26 |
| **E-14** U605 alternate | onsemi **NCS3402DR2G**, SOIC-8, same pinout, IQ ≤ 640 nA (parts); DigiKey 48 / Mouser 290 / LCSC 0 → owner or global sourcing only | **Accepted** as the named alternate if its datasheet guarantees VOL ≤ 0.45 V at 35 µA, IQ ≤ 1 µA/ch over 0–60 °C and an input range covering 0–2.8 V at VCC 3.25 V. Its 220–250 µs typical response is inside my 0.9 ms bound, so no timing change. | bom_rows.csv note; parts 17:20 |
| Placement (for parts) | E-2: U608, Q621, R690/R691/R693–R695, C630 in Z7 at U606 pin 13; Q622 + R692 in Z6 at Q617. E-3: everything in Z7 (≈ 135 mm² extra courtyard), with the Z4s high-impedance rules on the divider, timer and V_T nodes. | sent to parts | message 17:22 |
| E-14 C617 voltage (R9-B claim "25 V") | Samsung code CL10**A**105**K****B**8NNNC: A = X5R, B = **50 V** | claim not confirmed: C617 is the 50 V part | Samsung part-number code |
| **E-16** (owner) 3V3M from **TI TPS70933DBVR** on VBUS; U102 off in Stop | Re-ran p10 with power's static range **3.207–3.343 V (−2.8/+1.3 %)**; a ±2 % run was superseded | U605 3V3A-good: fall **2.966–3.119 V**, rise **3.011–3.161 V** (supersedes R3.3). Margin to 3V3A min 3.234 V is **73 mV**. A +60 mV 3V3M load transient (not in power's extract; my allowance) moves the falling threshold to ≤ 3.18 V, still 50 mV below 3V3A min. Downward dips only lower the thresholds (no false trip), and the TLV3402's 55–300 µs response filters short steps. FET gate ≥ 3.20 V (≥ 2.5 V spec); pull-up 34 µA ≤ 50 µA. U605 in Stop: 7.6 µA on 3V3M (power's new S6). LED drive: RELAY_EN high ≥ 3.207 − 0.4 = 2.81 V (p05 used 2.834 V) → V_IREF −0.95 % → **LED current min ≈ 5.26 mA ≥ 5.0 mA** (margin 5 %, was 6.3 %). E-2/E-3 (3V3D/VPOS) are unaffected. | `p10_supervisor_out.txt`; power 17:27 |
| **Parts E-21 blocker**: YAGEO RT0402 ±0.1 % 25 ppm (BRD) only covers 4.7 Ω–240 kΩ (7 MPNs, 28 parts/board unorderable) | Re-picked, no new part types: <br>• U605: R675/R682 **44.2 k** and R676/R683 **200 k** (0402 BRD, re-scaled 3V3A dividers); R677/R684 **300 k 0603** RT0603BRD07300KL (C705762); R678/R685 **1.00 M 0603** RT0603BRD071ML (C326730). <br>• E-3: Ra **487 k 0603** RT0603BRD07487KL (C861426), also used as **R_T** (R920–R923); Rb **1.00 M 0603** (C326730); V_T divider **33.2 k / 187 k 0402** (k_T 0.8492). | **U605 (p10, TPS70933 range):** fall **2.970–3.122 V**, rise **3.011–3.161 V**, hysteresis 42 mV, margin 73 mV to 3V3A min; 3V3A load 27.6 µA; Stop 7.8 µA on 3V3M. **E-3 (p18):** T_P **20.00–22.24 ms**; full-scale 20 Hz sine margin **8.1 %** (≈ 7.3 % after the reset residual); squares mute ≤ 22.5 Hz (may up to 25.0 Hz); worst **13.9 mJ** (32 Ω bal, 7 %) / **27.5 mJ** (16 Ω bal, 8 %). VPOS +25 µA. check_design (incl. the value-decode check) clean. **Stock/class (parts 18:05):** 0603 1 M C326730 / 487 k C861426 / 300 k C705762 Extended (LCSC-stocked); 0402 44.2 k C705633 Extended; 200 k C728556, 187 k C852576 and 33.2 k C852727 out of stock at LCSC → JLCPCB global sourcing (DigiKey stock). For R924 the approved LCSC alternate is UNI-ROYAL TC0225B3322TCC C50670386: 25 V rating vs ≤ 0.61 V stress, so accepted; it needs a decoder pattern if swapped. | `p10_supervisor_out.txt`, `p18_r9_e2e3_out.txt`, parts 17:51/18:05 |
| Designators | E-3 resistors use **R900–R925**, because the free R6xx numbers are retired (R611–R618, R623, R636–R638) and R7xx is block 7. Integration/parts to note the exception. | R696–R699 unused | p19 |

**Bring-up tests (new):**
- **E-2** (corrected per R9 check E-26; the earlier 50 µs / 0.3 ms list is superseded): with RELAY_EN held high, inject **comparator-path trips of 1, 3 and 10 ms** (PB8 1V3-test pulses or DC steps; the clear path needs ≤ 0.373 ms). The switch must stay open (LED current ≈ 0, jack continuity open) and PB0 must read low until a fresh RELAY_EN edge after H has recovered. Power up with RELAY_EN high → stays open. Remove R692 (or unpower U608) with RELAY_EN high → Q622 off. A direct low-impedance pull on N6_H may be shorter. See "R9 check fixes".
- **E-3** (amplifier link removed, DC injected on LEG_xx):
  - differential DC 1.70 V → no new-detector trip (the old windows trip later);
  - 2.10 V → DC_PERMIT_N high within 19.5–23.2 ms + ≤ 2 ms (R9-check timer, incl. ≤ 1 µA leakage);
  - full-scale 20 Hz sine at the legs for 60 s → no trip;
  - full-scale square at **21.0 Hz → trips** (guaranteed-trip boundary 21.5 Hz); at **26 Hz → no trip** (may mute up to 25.6 Hz);
  - repeat on R, both polarities.

**Boot self-test update (the E-3 detector trips before the old windows at ±0.5 FS):**
- **a′) old leg windows (final, ≤ 3 s plan):** digital DC ±**0.39 FS** per channel (0.869 V/leg, pair 1.74 V, below the E-3 V_L min 1.80 V) → DC_PERMIT_N high **77–131 ms** after the DC reaches the legs (**pass 70–140 ms**). At the −4.5 dB default gain use ±0.65 FS.
- **Self-test time ≤ 3 s (orchestrator 17:29):** digital clears the DC at the trip (EXTI), so each run holds it only until its trip. Recovery R ≤ **209 ms** (DAC removal ≤ 1 ms + release ≤ 3 ms + H from ≈ VNEG to Q618 on ≤ 205 ms). Total = 4 × 140 (a′) + 4 × 26 (e) + 8 × 209 + 2 × 252 (b, c) = **2.84 s** (2.94 s with a′ at 0.35 FS). Coverage is unchanged: every comparator channel, both E-3 polarities per channel, and PB0 low after every trip (E-2 clear path). No hardware change: faster H recovery in test mode would need a path that pulls H up, which is rejected. [CALC p20]
- **e) E-3 detector:** digital DC **+0.5 FS** on L, then **−0.5 FS** (pair ±2.23 V; tests the c+ and c− level/timer channels separately), then the same on R → DC_PERMIT_N high **19.5–25.1 ms** (R9-check timer 19.5–23.2 ms incl. leakage + readback ≤ 0.83 ms + DAC ≤ 1 ms) (pass 18–26 ms). At the −4.5 dB default gain use ±0.85 FS.
- Recovery is as before (≤ 700 ms). Sent to digital.

**Not verified:** the LCSC codes and stock of U608 and the ECH-U1H224GX9 2416 reflow (order remark). The 1 µA leakage per timer node is an E-class design basis. (The earlier 750 k/300 k/698 k, 22 nF C0G, BAS70-05 and Schottky-VF items are superseded by the R9 check fixes.) TLV1704 stock at LCSC now needs 30 per order. E-11 closed with digital's load figure (14.23 pF).

## R9 check fixes (review_r9_check.md; decisions E-22…E-26) — 25 Sep 2026

| Item | Action | Result | Evidence |
|---|---|---|---|
| **E-22** (CHK-01, High) D611/D612 topology | The BAS70-05 is common-cathode, so the timer nodes were clamped near +VF and E-3 could never trip. **Fixed by removing the clamp altogether:** each timer is now reset by an **NPN switch (Q623–Q626 MMBT3904**, C = timer node, E = GND, B = level-comparator output with **R916–R919 330 k pull-up to VPOS**). The level comparators' inputs are swapped so they sink only while the DC condition is true; that turns the NPN off and lets the timer run. Normal state: NPN saturated, timer held at VCE(sat) 0.02–0.20 V. **D611/D612 and the R_D path are deleted** (no BAS70-06 needed; pin maps checked: MMBT3904 B/E/C = 1/2/3 as Q612). | E-3 trips as intended. The reset is fast (≥ 0.4 mA discharge, ≤ 1.5 ms ≪ the 7.4 ms sine gap), and there is no continuous R_D current into VNEG (−0.17 mA). | `p18_r9_e2e3_out.txt`, netlist |
| **E-24** (CHK-03, Medium) leakage | Timer re-dimensioned for **≤ 1 µA total leakage per node** (NPN ICBO, C_T, PCB; design basis E) plus comparator IB: **R_T 110 k 0.1 %** (charging current at threshold ≈ 15 µA, was 1.2 µA), **C_T 220 nF PPS film ±2 %** (+0.5 % TC), **V_T = 0.5889 × VPOS** (R924 69.8 k / R925 100 k). The comparator-output and diode leakages are gone with the new topology. | **T_P 19.50–23.23 ms** incl. 1 µA (22.10 ms without). Full-scale 20 Hz sine beyond V_L ≤ 18.38 ms → **margin 5.8 %**. Squares mute ≤ 21.5 Hz, may mute up to 25.6 Hz. **Worst energies:** 32 Ω balanced **14.5 mJ (4 %)** at 2.14 V/leg (new detector, 25.2 ms); 16 Ω balanced **27.5 mJ (8 %)** at 0.99 V/leg (old windows); SE 12.8 / 6.4 mJ. Frozen code ±1.51/2.02/2.14 V removed ≤ 25.2 ms. V_L 1.80–2.00 V unchanged. Rails: I+ ≈ 2.66 mA, I− ≈ 2.48 mA (5V_ANA −0.03 mA vs the E-18 basis). | `p18_r9_e2e3_out.txt` |
| **E-23** (CHK-02, High) E-2 single faults | **R696 100 k Q622 gate pull-down** (N6_ARMG → GND): R692 open or U608 unpowered (Q Hi-Z) now turns Q622 off → switch open. | Covered below | netlist |
| E-23 self-test coverage | The boot self-test checks after every trip that PB0 reads low, and after each re-arm edge that PB0 reads high. That detects: R690 open, Q621 open, U606 ch4 output stuck low, U608 Q stuck high (PB0 stays high after a trip → fault, no closure); Q621 short, U606 ch4 stuck high-Z, U608 Q stuck low, R691 open (never arms → no closure). Fail-safe but not detected at boot: R692 open, Q622 open (switch cannot close → found at production/bring-up). **Latent:** Q622 D–S short (bypasses the latch), R696 open (matters only with a second fault). | Residual stated plainly: a Q622 short returns the pre-E-2 behaviour (the H path and Q616 still act) until the production test finds it | — |
| E-23 production test (Q622 short) | After a trip with the latch cleared (PB0 low, H recovered) and RELAY_EN held high: every photorelay open (leg-to-jack continuity open) **and** LED-string current ≈ 0 (voltage across R641/R642 < 0.25 mV, i.e. IF < 10 µA). | Added to the production test list; no cheaper hardware option (no free MCU pin for an N6_M3 readback) | — |
| **E-26** (CHK-06, Low) test pulses | E-2 bring-up trips through the comparator path last **≥ 1 ms** (clear path ≤ 0.373 ms). PB8 1V3-test pulses stay 5 ms. Direct low-impedance pulls on N6_H may be shorter. | Bring-up list below corrected | — |

**E-2 bring-up (corrected):** with RELAY_EN held high, inject comparator-path trips of 1, 3 and 10 ms (PB8 pulses or DC steps). The switch must stay open (IF ≈ 0, jack continuity open) and PB0 must read low until a fresh RELAY_EN edge after H has recovered. Power up with RELAY_EN high → stays open. Remove R692 (or unpower U608) with RELAY_EN high → Q622 off.

**Self-test windows:** e) E-3 still 18–26 ms (T_P 19.5–23.2 ms + readback ≤ 0.83 ms + DAC ≤ 1 ms = ≤ 25.1 ms); a′) unchanged; recovery R unchanged (NPN reset is fast).

**Parts to check (stock/class):**
- Q623–Q626 MMBT3904 (C20526, existing Basic line);
- R925 100 k 0.1 % 0402 (existing RT0402BRD07100KL line);
- R696 100 k 1 % (existing Basic line);
- **C631–C634:** parts (19:22) selected **Panasonic ECH-U1H224GX9** (0.22 µF ±2 %, 50 V, PPS, 2416 = 6.0 × 4.1 × 2.8 mm, MSL 1; Mouser 19,207; US$ 1.36). It is global sourcing. The ECHU reflow (260 °C, ≤ 95 s above 220 °C) goes on the order remark for the 2416 size; owner-fit is the fallback. The 2416 footprint is in the BOM.
- R920–R923 110 k: LCSC C705063 (8,000, Extended).
- R924 69.8 k: C852893, treated as global sourcing; alternate Vishay TNPW040269K8BEED.
- R916–R919: merged into the R660 330 k line (C25778, **Extended**, not Basic; drop-in YAGEO RC0402FR-07330KL C138006).
- **deleted:** D611/D612, and the 68 k R_D line.

---

# OD-1/OD-2 (owner decisions) — 25 Sep 2026

Decisions DZ-11 (OD-1 stricter stream check, was R-2) and DZ-12 (OD-2 DAC lock-status check, was R-5); brief `ve/brief_od.md`. Firmware only, no hardware change. New scripts: **`p15_od_guard.py`** (rule, false-trigger boundary, digital-DC envelope, OD-2 energies), **`p16_od_p2_scan.py`** and **`p16b_od_p4_scan.py`** (threshold/window scans). The detection times for OD-2 and the implementation latency come from digital (`digital/firmware_sequences_output.txt` §13–§14). Energy = DC energy at the driver, legs swing/current-bounded at the maximum rail (as p03/p07). `p07` is kept as the round-2 model; its rule is superseded by the one below.

## OD.1 Stream-guard rule — USB-side guard (decoded PCM) and post-CPLD guard (captured I²S words, PB12/13/15); per channel, all rates

| Path | Rule | Status |
|---|---|---|
| **P1** | **level persistence:** every sample of the last **22.0 ms** is ≥ +0.30 FS, or every sample is ≤ −0.30 FS (run counter; reset by any sample inside ±0.30 FS or a sign change) | **new** |
| **P2** | CIC² (2 × 50 ms boxcars), \|D\| ≥ **0.25 FS** | threshold 0.30 → 0.25 |
| **P3** | flat: range ≤ 1e-3 FS over 26 ms and \|mean\| ≥ 0.02 FS | unchanged |
| **P4** | CIC² (2 × **150 ms** boxcars), \|D\| ≥ **0.15 FS** | **new** |

Decision latency ≤ 1 ms (digital: 0.60 ms). Actions: **USB-side** trigger → zero the channel pair (1 ms ramp) + log, release after \|D\| < 0.05 FS for 1 s (as before). **Post-CPLD** trigger (the USB stream is clean, so the CPLD/link is faulty) → **RELAY_EN low at once** (switch open ≤ 1.008 ms) + zero + log; re-close only through the full pre-close sequence. Exposure for full-scale DC = 22.0 + 0.60 + 1.008 = **23.6 ms** (≤ 24 ms used below).

## OD.2 Energies (worst case; ≤ 15 mJ at 32 Ω and ≤ 30 mJ at 16 Ω, balanced and SE) [CALC p15]

| Case | 32 Ω bal | 16 Ω bal | 32 Ω SE | 16 Ω SE |
|---|---|---|---|---|
| Full-scale digital DC, flat or with small content, and a constant CPLD word ≥ 0.30 FS (P1, ≤ 24 ms) | **13.8 mJ** (8 %) | 13.9 mJ | 3.6 mJ | 6.9 mJ |
| **Envelope over every DC level 0.04–1.0 FS and content (none, small, or the maximum 20 Hz tone c = 1 − d at worst phase)**, removal = min(guard, firmware tiers, hardware leg windows) | **13.8 mJ** (8 %; d = 0.98 FS, P1) | **25.3 mJ** (16 %; d = 0.65 FS + 0.35 FS 20 Hz, P2 51 ms) | **3.6 mJ** | **6.9 mJ** |
| Round-3 rule (for comparison) | 15.5–22.8 mJ | ≤ 25.6 mJ | 4.0–6.0 mJ | 7.7–11.4 mJ |

Below the T3 pair level (d < 0.044 FS) the DC is the owner-accepted < 0.2 V residual. P3 covers flat DC of 0.02–0.30 FS in 28 ms (≤ 1.5 mJ). Without P4 and with P2 at 0.30 FS, the "DC 0.4 FS + loud 20 Hz tone" case reached 15.0/30.1 mJ (no margin), which is why P2 and P4 changed (p16/p16b).

## OD.3 New no-false-trigger boundary for legitimate content (stated plainly) [CALC p15, p16, p16b]
- **Sines:** a full-scale sine at any frequency **≥ 20 Hz**, any amplitude, phase or onset, **never mutes**. It stays beyond ±0.30 FS for at most 20.15 ms against the 22 ms limit (8 % margin; sampled checks at 44.1/48/384 kHz give 20.16 ms). P2 sees ≤ 0.159 FS against 0.25 (36 % margin) and P4 ≤ 0.053 FS against 0.15 (65 %).
- **Squares:** a **full-scale square wave (≥ 0.30 FS) at or below 22.7 Hz now mutes** (its plateau lasts ≥ 22 ms). Squares above 22.7 Hz play (P2 ≤ 0.209 FS, 16 % margin; P4 ≤ 0.077 FS, 49 %). Squares below 0.30 FS never trigger P1.
- **DC offset in programme:**
  - a steady digital offset ≥ 0.15 FS (−16.5 dBFS) mutes (P4, after 0.17–0.3 s);
  - with a full-scale 20 Hz tone, an offset ≥ 0.10 FS may mute (P4), and ≥ 0.138 FS triggers P1;
  - with 30 Hz content the offset would have to reach 0.53 FS;
  - real programme offsets are < 0.01 FS (−40 dBFS), so music does not mute.
- Flat content ≥ 0.02 FS for 26 ms (e.g. digital silence with an offset) mutes, as before.

## OD.4 OD-2 — DAC plausibility check (digital implements; times from firmware_sequences §14) [CALC p15]

| Fault signature | Switch open ≤ | E 32 Ω bal | E 16 Ω bal | E 32 Ω SE | E 16 Ω SE |
|---|---|---|---|---|---|
| (a) DPLL lock lost: DAC_LOCK falling on PC9, EXTI9 + 20 µs confirm (masked during rate/family changes and start-up, switch open then) | **1.04 ms** | 0.60 mJ | 0.60 mJ | 0.16 mJ | 0.30 mJ |
| (b) poll A (10 ms): lock_status 0, automute 1, chip ID, GPIO2 ≠ PC9, reg 0–20 mismatch | **16.45 ms** | 9.44 mJ | 9.50 mJ | 2.47 mJ | 4.72 mJ |
| (c) poll A: DAC I²C NACK (one retry) | 16.45 ms | 9.44 mJ | 9.50 mJ | 2.47 mJ | 4.72 mJ |
| (c′) I²C bus stuck low (1 ms timeout + 9-clock recovery) | 17.45 ms | 10.0 mJ | 10.1 mJ | 2.62 mJ | 5.01 mJ |
| (d) poll B (100 ms): DPLL ratio out of range | 102.4 ms | — | — | — | — |

**Times confirmed final by digital (14:13):** (a) 1.04 ms; (b)/(c) 16.45 ms, with the full reg 0–20 read-back now in the 10 ms poll because the 100 ms version (106.8 ms) was slower than the leg windows; (c′) 17.45 ms; (d) 102.4 ms. I²C load 27.4 %. OD-1 decision latency ≤ 0.60 ms post-CPLD and ≤ 0.225 ms USB-side (≤ 1 ms assumed above); CPU 13.3 % worst for both guards at 384 kHz. p15 already uses these values, so its output is unchanged. (d) is a clocking error rather than a frozen code; any DC that comes with it is still removed by the leg windows first (≤ 39.6/25.9 mJ at 16/32 Ω). All detected signatures (a)–(c′) are ≤ 10.1 mJ at 16/32 Ω, with the worst full-scale frozen code. False-alarm risk (digital): lock loss is expected only during rate/family changes and start-up, when the check is masked and the switch is open. A spurious NACK is confirmed by a retry, and each event is logged and counted.

**Residual — documented limitation (replaces R-5):** a DAC-core hang that keeps DPLL lock, answers I²C, returns the written registers and keeps MCLK, 1V3 and 3V3A good is not detected by any supervisor, guard or plausibility check. Its differential frozen output is invisible to the CM window, so it is removed only by the hardware leg windows (0.30 V; firmware tiers are slower at these levels): worst **39.6 mJ at 16 Ω balanced** (±1.51 V, 69.1 ms) and **25.9 mJ at 32 Ω balanced** (±2.02 V, 50.7 ms); 16.2 mJ at 60 Ω, 3.4 mJ at 300 Ω. That is above the 30/15 mJ hardware-fault figures at 16/32 Ω. ESS publishes no failure mode that produces it; it is stated as a limitation, not compliance.

## OD.5 Fault-policy table (§10) and test-list changes
- §10.2 firmware policy, **stream guard row** → rule OD.1 (P1–P4). USB-side trigger → zero + log. Post-CPLD trigger → RELAY_EN low + pre-close to re-close (a fault strike is counted by digital).
- New row, **DAC plausibility (OD-2):** lock loss (EXTI9), poll-A/B failures, NACK and stuck bus → RELAY_EN low, log, controlled recovery (digital §14).
- **Guard unit tests (bring-up, stream guard in test mode):**
  - full-scale sines 19.998–2000 Hz × 24 phases, onset included, never trigger;
  - full-scale square at 22.8 Hz does not trigger; at 22.6 Hz it triggers in 22.0–23.6 ms;
  - flat digital DC 1.0 FS triggers in ≤ 23.6 ms; 0.65 FS DC + 0.35 FS 20 Hz triggers (P2) in ≤ 51 ms;
  - DC offset 0.15 FS triggers (P4) in ≤ 0.3 s; 0.08 FS offset for 10 s does not trigger;
  - post-CPLD guard: a forced constant CPLD word opens the switch in ≤ 23.6 ms.
- **Boot self-test:** digital adds the DAC_LOCK check (GPIO2 forced low/high → PC9 and the EXTI flag follow) at every start (2.3 ms). The R3.9 self-test windows are unchanged. The leg-window self-test uses the CPLD test register below the guard, so the new guard does not interfere.

## OD.6 Not verified
The worst-content model uses a 20 Hz tone at the maximum amplitude without clipping. Sub-20 Hz content in a fault is not modelled; P4 covers such DC partially. Digital's latencies (0.60 ms decision, 1.04/16.45/17.45/102.4 ms) are theirs; I did not re-derive them. ESS behaviour in a core hang is unpublished, so the coverage of (a)–(c′) for real hangs is unknown.

---

# VE (value engineering) — 25 Sep 2026

Binding inputs: `ve/brief_ve.md` (owner decisions O-1…O-4). Scripts: `p14_ve_bom.py` (BOM/netlist edits), `p10_supervisor.py` re-run (R668/R669), p05 numbers unchanged (R641/R642 keep 24.9 Ω 0.1 % 25 ppm). Round-3 files kept as `*_r3*.bak`. `check_design.py power protection analog digital` after the edits: **378 parts, 1111 pins, no issues**. Savings are against `integration/cost_report.md` (global sourcing: +10 % price difference, 30 % duty on relays; Standard US$ 1.53 per part type, Economic US$ 3.07 per Extended type). Owner-purchase freight/import is the parts stream's model; my figures assume the owner's DigiKey order ships free with the other owner-fitted parts and pays 5 % Taiwan business tax [ASSUMP].

| # | Candidate | Verdict | Saving per board / per 5-board order | Checks re-run |
|---|---|---|---|---|
| VE-P1 | K601–K604 TLP3545A(TP1,F): JLCPCB global sourcing 25 × US$ 3.60 + 10 % + 30 % duty = US$ 126.0 | **Owner-fitted** (O-4 lists DIP-SMD photorelays; 2.54 mm gull wing, MSL 1). Owner buys exactly 20 at DigiKey (264-TLP3545A(TP1FCT-ND, 28,529 in stock, **US$ 3.684 at 10+**, 18 Sep 2026) = US$ 73.68 + ≈ 3.7 tax | **≈ US$ 10 / ≈ US$ 50** (126.0 + type fee 1.53–3.07 − 77.4; minus freight if the owner order does not ship free) | Part unchanged → all switch numbers (RON, IFT, COFF, tON/tOFF, LED window) unchanged; reflow limit no longer applies. Layout: hand-solder lands (toes +0.3 mm, 1.5 mm iron clearance); fit after the rail/MCU/DAC bring-up and before the protection tests. Hand-iron limits are not in the extracted datasheet → the parts stream's O-4 procedure applies [not verified] |
| VE-P2 | R641/R642 Vishay PATT0402E24R9BGT1 (global, US$ 0.70) | **Adopted drop-in:** YAGEO RT0402BRD0724R9L, **LCSC C852667**, 19,000 in stock (LCSC page 23 Sep 2026), US$ 0.034, same 24.9 Ω 0.1 % 25 ppm thin film | **US$ 3.0 / US$ 14.9** | p05 already used this part: LED current 5.315–6.599 mA (≥ 5.0 mA), 5V_SYS ≤ 13.20 mA, power 1.1 mW — unchanged |
| VE-P3 | U605 TLV3402IDR (TBC, US$ 1.20 estimate) | **Evidence update:** **LCSC C91242**, 745 in stock (LCSC page Mar 2026; recheck at order), **US$ 0.68 at 10+**; Extended | **US$ 1.0 / US$ 5.2** | Same part (no design change) |
| VE-P4 | U601–U603, U606 TLV1704AIPWR (costed as global sourcing, 25 × US$ 1.37 + 10 %) | **Order from LCSC stock** (C181596, 61 pcs on the LCSC page 7 Jul 2026, US$ 1.25) if ≥ 25 are in stock at order time; otherwise global sourcing as before | **≈ US$ 1.3 / ≈ US$ 6.4** (conditional) | Same part |
| VE-P5 | R668 866 k 0.1 % (global) + R669 100 k 0.1 % (MCLK-alive threshold) | **Adopted:** R668 → **1.00 MΩ 1 % UNI-ROYAL 0402WGF1004TCE, C26083, Basic** (JLCPCB 2,055,430, PCBA Economic and Standard, 20 Sep 2026; shares the R666 line); R669 → 100 k 1 % (Basic line of R646) | **US$ 0.3–0.6 / US$ 1.5–3.1** (one Extended type and one global line fewer) | p10: threshold 0.326–0.384 V (was 0.382–0.426 V); running node ≥ 0.890 V → margin 0.506 V (2.32×); **MCLK dead ≤ 0.452 ms** (≤ 0.5 ms); frozen code removed ≤ 2.43 ms, ≤ 1.39 / 1.24 mJ (16/32 Ω); self-test b) window 0.06–1.28 ms (pass ≤ 2.0 ms unchanged) |
| VE-P6 | D610 BAS70,215 (LCSC C109295 **out of stock**) | **Adopted:** same part as D609, **BAS70-04,215 LCSC C389351** (36,430 in stock, 9 Sep 2026, US$ 0.096); diode 1 used (A1 pin 1, K1 pin 3), pin 2 NC — netlist connections unchanged | **≈ US$ 0.5 / ≈ US$ 2.7** (one part type fewer at Economic, US$ 1.2 at Standard; +US$ 0.33 part price) | Same die (VF ≤ 410 mV at 1 mA): 1V3-good test level ≤ 0.65 V < reference min 1.116 V, unchanged |
| — | **Total adopted** | | **≈ US$ 16.5 / ≈ US$ 83 per 5-board order** (Economic; ≈ US$ 79 at Standard; VE-P4 conditional on LCSC stock) | |

**Rejected (looked cheap, but):**
- **LCSC-stocked photorelays instead of the TLP3545A:** Panasonic AQV25x — reflow 250 °C < the Economic 255 ± 5 °C (and D-1 excluded them). Low-cost Toshiba TLP241A/TLP172A/TLP3553-class parts — RON 0.1–2 Ω against the 60 mΩ-class output-impedance and THD budget, or no guaranteed COFF ≤ 1 nF (pop). Owner-fitting the existing part is cheaper and needs no re-verification.
- **TLV1704 → LM339/LM2901:** IB up to 250 nA gives ≈ +80 mV threshold error through 115 k + 100 k; the CM range (V+ − 2 V) excludes the U603/U606 upper inputs; higher IQ. **LMV339/TLV7034:** 5.5 V supply maximum < 7.84 V. **TLV3404:** VOL is specified only at 50 µA, so it cannot pull C617 down in ~1 ms. **TLV1704 owner-fitted:** saving ≤ US$ 6 per order for 20 hand-soldered TSSOP-14 parts.
- **U605 → 2 × TLV7041:** not verified in time; saving < US$ 3 per order.
- **U604 OPA2333 → TLV9002-class:** needs a new LED-loop stability analysis (3× GBW against the 1.5 MHz base pole); saving ≈ US$ 0.45/board.
- **R641/R642 → a 1 % Basic 24 Ω:** could save one more Extended type (US$ 3.07 at Economic) at +3.8 % LED current (+0.66 mA on 5V_SYS). Basic status not verified and p05 not re-run → not done.
- **U605 dividers to 1 %:** the release threshold would reach 3V3A minimum (3.234 V) → must stay 0.1 %. **22 MΩ/4.7 MΩ/2.2 MΩ/470 k/2.2 k (1 %) and 237 k/330 k/953 k/1.00 M (0.1 %)** kept; their LCSC stock/class is left to the parts stream's final check (values tied to the thresholds). **74AUP1G17:** no verified LCSC-stocked equivalent found in time; saving < US$ 1.
- **Stock findings for the parts stream's final check (not solved here):** R679/R686 **22 MΩ 0402 (C407703) is out of stock at LCSC** (10 MΩ C26082 too). The tolerance is uncritical (5 % moves the U605 release threshold by ≤ 2 mV against the 66 mV margin), so any in-stock 22 MΩ ≤ 5 % in 0402 or 0603 will do; otherwise JLCPCB global sourcing. **U607 74AUP1G17GW (C545626) is out of stock at LCSC** → global sourcing as costed; a second maker's AUP1G17 needs the VT+/VT−, CI and Ioff check first. R688/R689 470 k = C25790 (Extended, 452,700). The 0.1 % 237 k/330 k/953 k/1.00 M, 2.2 M, 4.7 M and 2.2 k were not checked.
- **Economic PCBA check** of the parts JLCPCB still places: smallest pitch 0.65 mm (TLV1704 TSSOP-14, 74AUP1G17 SC-70-5), SOIC-8, SOT-23, passives ≥ 0402; TLV1704 MSL 2 at 260 °C; no protection part needs X-ray or SPI; the only reflow-limited part (TLP3545A) is now owner-fitted.

---

# R8 review fixes (round 3) — 25 Sep 2026

Inputs: `integration/decisions_r8c.md` (X-6, X-9, firmware rules), `decisions_r8b.md`, review findings states #6, #7, #13, #15, #18, #27, #34 and signal F1, F3, F6. New scripts: **`p10_supervisor.py`** (X-6 + firmware numbers), **`p11_x9_filter.py`** (X-9 candidates), **`p12_r3_bom_netlist.py`** (BOM/netlist); re-run: `p03_detector.py` (R601–R604 115 k, aged C range), `p06_dcsense_tiers.py`, `p04_cm_monitor.py` (analog X-8 I/V supply, R3.14). Every number below is in the matching `*_out.txt`. This section supersedes R2 and §0–§15 where they differ (list in R3.12). Round-2 files are kept as `*_r2*.bak`.

## R3.1 Changes at a glance

| # | Item | Round 2 | Round 3 | Why |
|---|---|---|---|---|
| 1 | DAC-supply / MCLK supervisor (X-6) | none; frozen code = residual 36.2/23.7 mJ | **U605 TLV3402** (3V3M) + **Q619/Q620** AO3400A pull-downs on N2_AVCC_EN_G / AUD_EN; **U606 TLV1704** (VPOS/VNEG) into N6_H: 1V3 good, MCLK alive, 3V3A-good repeater; **U607 74AUP1G17** + **D609 BAS70-04** pump | states #15, #18, #27, signal F1 |
| 2 | Frozen DAC code (X201 dead, open MCLK, DVDD collapse) | 36.2 / 23.7 mJ (leg windows) | **removed ≤ 2.40 ms, ≤ 1.38 mJ (16 Ω) / ≤ 1.22 mJ (32 Ω)** | requirement ≤ 3 ms / ≤ 2 mJ |
| 3 | R601–R604 (X-9) | 105 kΩ, C −15/+10 % | **115 kΩ**, C601–C604 2.2 µF kept, aged range 1.79–2.42 µF (C-25) | states #13 |
| 4 | Pre-close DC limits | 0.10 V leg / 0.12 V pair | **0.070 V / 0.090 V** | states #7 |
| 5 | IWDG | /4, 625 → 41.7–100 ms | **/4, reload 239 → 16.0–38.4 ms** | states #6 |
| 6 | Boot self-test | none | leg windows (±0.5 FS per channel), MCLK alive, 1V3 good, 3V3A good, U206 (PB1) — windows in R3.9 | signal F6, X-6 |
| 7 | New MCU connections (digital request) | — | PB8 → N6_V13_TEST (open drain), PA12 ← N6_V3AG_A_MCU, PB9 ← N6_V3AG_B_MCU | boot self-test |

## R3.2 X-6 circuit in words and the part choice [CALC p10]
- **U605 TI TLV3402IDR on 3V3M, two independent "3V3A good" channels.** Per channel: IN− = 3V3A × 953 k/(237 k + 953 k) (R676/R675, R683/R682); IN+ = 3V3M × 1.00 M/(330 k + 1.00 M) (R678/R677, R685/R684, all 0.1 % 25 ppm) with 22 MΩ hysteresis (R679, R686) from the output; output pull-up 100 k (R680, R687) to 3V3M. Output **low = 3V3A good** (FET off); output **high = not good** → **Q619** (drain N2_AVCC_EN_G = U206 input B after R236 10 k) and **Q620** (drain AUD_EN after R237 4.7 k) conduct. Readback to the MCU through 470 k (R688 → PA12, R689 → PB9), so a mis-driven MCU pin cannot mask the gate.
- **Why not the TLV1704 on 3V3M named as an example in X-6:** its IQ (4 × 100 µA max) sits on the always-on 3V3M and would consume the S6 suspend margin (31 µA) thirteen times over, and its low level (≤ 0.6 V at 0 mA, ≤ 0.9 V at 4 mA, only a 36 V row) is not a guaranteed logic low for U206 (VIL 0.8 V). The TLV3402 draws ≤ 0.95 µA/channel; the FETs give VOL ≈ 0.
- **U606 TI TLV1704AIPWR on VPOS/VNEG**, outputs wired-OR on N6_H exactly like U601–U603, so they tolerate H at ≈ VNEG (no series Schottky needed, no VOL penalty). ch1 **1V3 good** (IN+ = 1V3 via R670 10 k, C629 1 nF, 2.2 MΩ hysteresis R671 from N6_H; IN− = VPOS × 100 k/337 k, R672/R673); ch2 **MCLK alive** (below); ch3 **3V3A-good repeater** (IN− = N6_V3AG_A via R681 4.7 MΩ, IN+ = the 1V3 reference) — every U605A trip also pulls N6_H, so the ≥ 53 ms permit recovery applies to every 3V3A event and nothing can re-close through Q616 alone; ch4 spare (IN+ GND, IN− VNEG, output unconnected) — **superseded (R9 E-2): ch4 = latch H-OK detector, 4IN− = N6_H, 4IN+ = N6_HREF, 4OUT = N6_TRIP**.
- **MCLK alive:** MCLK at the U301 XI pin (after R203) → **R665 1.00 kΩ** → **U607 74AUP1G17GW** (3V3D, Ioff, C623) → **C624 100 pF C0G** → node N6_PMP → **D609 BAS70-04** (a1 = GND clamp, a2 → k2 rectifier) → N6_MCK_RC (**C625 82 pF C0G ∥ R666 1.00 MΩ**) → R667 100 k → U606 ch2 IN+; IN− = VPOS × 100 k/966 k (R668/R669).
- **Boot-test hook:** MCU PB8 (spare after X-1) open drain → D610 BAS70 → R674 2.2 k → N6_V13_CMP pulls the 1V3-good input to ≤ 0.65 V; D610 blocks a mis-driven PB8 (no masking).

## R3.3 Thresholds and levels [CALC p10]

| Channel | Falling (trip) | Rising (release) | Operating level | Margin |
|---|---|---|---|---|
| U605A/B 3V3A good (3V3M ±1.5 %, 0.1 % dividers, VOS 4.4 mV, IB 1.5 nA, VOL 0–0.3 V) | 3.064 V nom, **3.006–3.125 V** | 3.110 V nom, **3.052–3.168 V** (hysteresis 46 mV) | 3V3A ≥ 3.234 V | **66 mV** to the highest release |
| U606 ch1 1V3 good (VPOS ±2.9 %, VOS 5.5 mV) | 1.145 V nom, **1.103–1.189 V** | ≤ **1.223 V** | 1V3 ≥ 1.283 V | **60 mV** |
| U606 ch2 MCLK alive | threshold **0.382–0.426 V** | — | running ≥ **0.890 V** | **0.464 V (2.09×)** |
| U606 ch3 3V3A repeater | gate high ≥ 3.15 V vs ref ≤ 1.200 V | gate low ≤ 0.394 V vs ref ≥ 1.116 V | — | ≥ 0.72 V |

- Sink currents: Q619 sinks ≤ **0.338 mA** (R236 10 k from AVCC_EN) → VOL ≈ **21 µV**; Q620 sinks ≤ **0.720 mA** (R237 4.7 k from PC10) → VOL ≈ **45 µV** (RDS(on) ≤ 48 mΩ × 1.3 at VGS 2.5 V; gate ≥ 3.25 V). Guaranteed U206 low (VIL 0.8 V), TLV767 EN low and Q504 off. Off state: TLV3402 VOL ≤ 0.30 V at the 33.8 µA pull-up current (spec point 50 µA) < AO3400A VGS(th) min 0.65 V (margin 0.35 V).
- U605 timing: TLV3402 delay 55–300 µs typ, **no maximum published** → 0.9 ms bound [ASSUMP ×3] + gate 138 µs → gate applied ≤ 1.04 ms after 3V3A crosses its threshold.
- ESS DVDD minimum 1.235 V is 46 mV above the highest 1V3 trip: a DVDD sag that stays between 1.235 V and the trip is not detected (ESS behaviour there unpublished).

## R3.4 MCLK-alive detector [CALC p10]
- Running (80 MHz, any duty 45–55 %): node ≥ k × swing − 2 VF = 0.950 × 1.80 V − 2 × 0.41 V = **0.890 V** (U607 swing from VOH 2.30 V / VOL 0.50 V at ±4 mA and VCC 3.0 V, −40…125 °C; BAS70 VF ≤ 410 mV at 1 mA; Cd ≤ 2 pF; f·C·R = 7524 → saturated, duty-independent; ripple 0.14 mV per cycle).
- Stopped at any static level: **"dead" ≤ 0.421 ms** (stopped high: C624 discharges with C625, τ ≤ 0.197 ms, from ≤ 3.17 V to ≥ 0.382 V); stopped low (XI held by R227, or an open R203/joint) ≤ 0.196 ms; never faster than 0.057 ms. 3V3D off → U607 unpowered → node 0 → "dead" (fail-safe).
- MCLK loading: through 1 kΩ any input capacitance appears as ≤ 1/(2ωR) = **0.99 pF** at 80 MHz, + ≤ 0.3 pF pad/stub = **≤ 1.29 pF** (≤ 1.5 pF); MCLK net 13.1 pF (digital) → 14.4 pF ≤ 15 pF (Kyocera).
- **Limitation, stated plainly:** with the Kyocera maximum edge (4.5 ns at 15 pF, i.e. a near-triangle at 80 MHz) and the assumed 0.1/0.9 VCC levels, the U607 input behind 1 kΩ does **not** provably reach the Schmitt VT+ maximum (−120 mV with 1.5 pF, −380 mV with 2.4 pF input capacitance); with edges ≤ 2.5 ns (1.5 pF) or ≤ 1.5 ns (2.4 pF) it toggles with margin. The failure direction is safe (reads "dead" → switch open, no audio) and every board is checked at every boot (R3.9 b) and in production. **[MEAS]** edge time and U607-input swing at 0 °C/50 °C on all boards; designed-in fallback without layout change: R665 fitted 0 Ω (direct tap, +1.4 pF typ, 14.5 pF total).

## R3.5 Frozen-DAC-code cases — hardware only [CALC p10]
Removal = detection + H fall to Q617 off (0.980 ms, one comparator ≥ 4 mA, C617 +10 %) + TLP3545A tOFF (1.0 ms design, 0.5 ms at 25 °C [DS]). Worst frozen code = full-scale DC ±2.228 V on both legs: 573 mW into 16 Ω (current bound 0.19 A), 509 mW into 32 Ω.

| Case | Detection | Removed | E 16 Ω | E 32 Ω |
|---|---|---|---|---|
| X201 dead while enabled (MCLK stops at any level) | ≤ 0.421 ms | **≤ 2.40 ms** | **≤ 1.38 mJ** | **≤ 1.22 mJ** |
| Open MCLK (R203/joint; XI held low by R227) | ≤ 0.196 ms | ≤ 2.18 ms | ≤ 1.25 mJ | ≤ 1.11 mJ |
| DVDD (1V3) collapse, from the 1V3 trip | ≤ 0.038 ms | ≤ 2.02 ms | ≤ 1.16 mJ | ≤ 1.03 mJ |
| (information) 3V3A collapse: U605A → U206 → Q616, from the 3V3A trip | ≤ 1.04 ms [typ×3] | ≤ 2.04 ms | ≤ 1.17 mJ | — |

All ≤ 3 ms and ≤ 2 mJ. **CPLD/serialiser frozen word (DZ-6):** the MCU also runs the stream guard (p07) on the post-CPLD I²S words it captures (PB12/13/15), so this case is bounded like R-2: a constant word is flat digital DC → detected in 26 ms, exposure 27 ms → **≤ 15.5 mJ (32 Ω balanced) / 15.6 mJ (16 Ω balanced) / 4.0 mJ (32 Ω SE) / 7.7 mJ (16 Ω SE)** at 1 FS; a stuck pattern that still carries content → CIC² path, ≤ 22.8 / 25.6 mJ (32/16 Ω balanced) at 0.8–1 FS — the R-2 figures (firmware bound, owner decision R-2). Condition: the guard must also trip when no post-CPLD frame is captured for ≥ 2 ms while RELAY_EN is high (clock stop). **R-5 residual (owner decision, DZ-6) = DAC-core hang only** (MCLK, 1V3, 3V3A and the I²S stream all good; the core output frozen at any code, differential, invisible to the CM window): leg windows alone (0.30 V; the firmware tiers are slower at these levels) → worst **39.6 mJ at 16 Ω** (±1.51 V per leg, current-bounded, removal 69.1 ms) and **25.9 mJ at 32 Ω** (±2.02 V, 50.7 ms); 16.2 mJ at 60 Ω, 3.4 mJ at 300 Ω [CALC p03, R601 115 k] — above 30/15 mJ at 16/32 Ω, so it stays an explicit owner decision, not compliance.

## R3.6 Start-up and normal states — no false trip [CALC p10]
- Power-up: ANA_EN (U606 powered; ch1/ch2/ch3 hold H low because 1V3, 3V3D and 3V3A are off — the switch cannot close anyway) → AVCC_EN (3V3A above the release maximum 3.168 V → U605 and ch3 release) → AUD_EN (only now effective: U605B) → 1V3 → ch1 releases → MCLK_EN/MCLK_PERMIT → X201 ≤ 3 ms → ch2 alive within ~1 µs of the first edges → RESETB → soft start 104.9 ms → the CM window releases last. The new channels release ≥ 68 ms before the CM window, so the R2.7 timeline (pre-close pass ≤ 405 ms) is unchanged; the switch can never close earlier than 53 ms after MCLK is alive (Q617) and never while X201 is stopped (Q616): MCLK always starts first.
- Normal operation (playback, mute/idle, Default/High, rate or family change with MCLK running): node ≥ 0.89 V vs ≤ 0.426 V; 1V3 ≥ 1.283 V vs ≤ 1.223 V; 3V3A ≥ 3.234 V vs ≤ 3.168 V → no trip in any normal state.
- Intentional H-low states: programming mode (MCLK off), MCU reset (MCLK_PERMIT low), suspend/power-down (MCLK stops after RELAY_EN low), any firmware stop of X201 — re-close then waits for DC_PERMIT_N low ≥ 50 ms (≤ 205 ms after MCLK restarts). Firmware should not stop MCLK for a rate change.

## R3.7 Supply currents for the power budget (maxima) [CALC p10]

| Rail | Normal | Suspend | Note |
|---|---|---|---|
| 3V3M | **74.2 µA** (pull-ups with 3V3A good) | **7.6 µA** (S6 margin 31 → 23.4 µA) | PB8 test pulse 0.11 mA × 5 ms per boot |
| 3V3A | 5.7 µA | 0 | two dividers |
| 3V3D | **3.36 mA** (U607 at 80 MHz, CPD ≤ 6 pF [ASSUMP], pump load 4.8 pF) + X201 extra 0.35 mA inside its 8.0 mA maximum | 0 | new load for power/digital |
| VPOS/VNEG | **0.40 mA** (U606 4 × 100 µA, V+ → V−) + 16 µA dividers | 0 | block 6 now I+ ≤ **1.660 mA**, I− ≤ **1.631 mA** (D-9 said 1.26/1.25) |

## R3.8 X-9 — leg filter at the aged-capacitor corner [CALC p11, p03, p06]
R601–R604 **105 k → 115 kΩ** (1 %), C601–C604 unchanged (2.2 µF X5R), analysed with the C-25 range **1.79–2.42 µF**:
- full-scale 20 Hz square wave at the fastest corner (R −1.4 %, C 1.79 µF, lowest trip 0.275 V): node peak 0.258 V → **no trip, 6.2 % margin**; no trip down to C −24 %; square corner 18.7 Hz; sine corner 11.5 Hz (was 12.0).
- removal: **1 V 111.0 ms** (≤ 250), **2 V 51.2 ms** (≤ 100), full-scale digital DC 46.6 ms.
- energies: rail-stuck SE **25.6 mJ / 12.8 mJ** at 16/32 Ω (15 % margin, was 22 %); combined stuck-pin envelope **27.2 / 13.6 mJ** (9 % margin, was 17 %); opposite-sign legs 14.7/7.4 mJ; CM path unchanged (≤ 12.4/7.4 mJ). All within 30/15 mJ.
- Rejected: 110/113 k (2.3/4.7 % margin), 118/121 k (rail-stuck margin 12/10 %; lower envelope margin); a C0G 220 nF + 1.05 MΩ network (IB error 44 mV at the node).

## R3.9 Firmware numbers [CALC p10]
- **IWDG:** prescaler /4, reload 239 → **16.0–38.4 ms** (LSI 25–60 kHz); refresh every ≤ 8 ms, only when all tasks are alive. No autonomous re-close before the reset: a healthy MCU services the DC_PERMIT_N EXTI (highest priority; interrupts never masked > 1 ms) → RELAY_EN low, latched until the full pre-close sequence; a hung MCU resets ≤ 39.4 ms after the trip → switch open ≤ 40.4 ms, while Q617 cannot conduct again before **53 ms** after the trip clears (margin 12.3 ms). After a reset RELAY_EN rises only after the boot self-test and pre-close (fresh edge). 3V3A events reach H through U606 ch3; MCLK stops through ch2. Suspend: per orchestrator **DX-2** (decisions_r8c, supersedes my earlier "wake ≤ 12 ms or /32 reload 624" option): only in Stop with RELAY_EN low and all switched domains off, the IWDG is lengthened to ≤ 1.6 s (digital: /16, reload 2499 = 0.667–1.600 s, RTC wake 0.50–1.20 s) and the ≤ 40 ms setting is restored before any domain is enabled on resume. The permit argument is unaffected: with ANA_EN low H is held at 0 V (R647 to the collapsed VPOS) and with 3V3D off MCLK is dead, so nothing can close while the long timeout is active.
- **Pre-close DC limits** (updated for DZ-1, R3.17): guaranteed sensing error with the DAC muted = e_leg 60.30 − aliasing 4.21 = **56.10 mV** (pair **61.30 mV**) + 2.5 % gain. A healthy board (offset ≤ 6.24 / 12.48 mV) reads ≤ **62.5 / 74.1 mV**, and a board at the 10/20 mV offset spec reads ≤ 66.3 / 81.8 mV → limits **|leg| ≤ 0.070 V, |pair| ≤ 0.090 V** unchanged (50 ms average; margins 7.5 / 15.9 mV healthy, 3.7 / 8.2 mV at the spec). Closure is guaranteed refused for true DC > **129 mV (leg) / 155 mV (pair)** (round-2 limits allowed up to 160/186 mV). Below that the guarantee rests on the analog offset design and T3 (0.176/0.192 V in 2.25 s; R3.17); advisory: |reading − stored factory baseline| ≤ 25 mV, logged, three consecutive failures → refuse.
- **Boot self-test** (every attach, switches open, before the first closure, stream guard bypassed):
  a) leg windows: digital DC +0.5 FS on L only (1.114 V per leg), then −0.5 FS, then the same on R: DC_PERMIT_N "not permitted" between **58 and 97 ms** after the DC reaches the legs (pass window 45–120 ms), back ≤ 599 ms after mute (pass ≤ 700 ms); ≤ 3.3 s total. Without a stored calibration (−4.5 dB pre-calibration default, 0.664 V per leg): **109–187 ms** (pass window 95–210 ms), back ≤ 453 ms (pass ≤ 550 ms). "After the DC reaches the legs" = after the CPLD test register is written plus the DAC's own ramp if a volume ramp is active. Covers each channel and polarity, the filter values (timing), H and Q618; one dead window of a balanced pair is not seen (the other leg trips) → production test per leg (latent-fault limitation, states #34/F3 unchanged: L-6).
  b) MCLK alive (permit present ≥ 50 ms): MCLK_PERMIT low → PB1 low within 10 µs (U206/R234) and DC_PERMIT_N high within **0.06–1.25 ms** (pass ≤ 2.0 ms); MCLK_PERMIT high → DC_PERMIT_N low within 64–208 ms (pass ≤ 250 ms).
  c) 1V3 good: PB8 low 5 ms → DC_PERMIT_N high within **0.87 ms** (pass ≤ 2.0 ms); release → low within 61–205 ms (pass ≤ 250 ms).
  d) 3V3A good: before AVCC_EN, PA12 and PB9 read high; ≥ 2 ms after V3A_MON ≥ 3.20 V both read low. Optional: with 3V3A off, N2_AUD_EN_MCU high for 1 ms must leave I²C low (Q620 holds 3V3D off). U606 ch3 and Q619 are production-test items (masked by other channels at boot).
  Any failure → RELAY_EN stays low, error over USB, no audio.

## R3.10 Component stress — R3 rows (worst operating conditions, all states)

| Part | Stress | Rating | Margin |
|---|---|---|---|
| U605 TLV3402 | VCC ≤ 3.35 V; inputs ≤ 2.72 V (≤ 3.37 V at 3V3A max with 3V3M low); output sink ≤ 34 µA | 16 V; VCC + 5 V; — | large |
| U606 TLV1704 | VS ≤ 7.84 V; inputs VNEG…3.35 V; unpowered input current ≤ 32 µA; output sink ≤ 4 mA (20 mA short) | 36 V; 10 mA | large |
| U607 74AUP1G17 | VCC ≤ 3.37 V; input ≤ 3.37 V (Ioff when 3V3D off); average 3.4 mA | 4.6 V abs | large |
| D609 BAS70-04 | VR ≤ 3.4 V; IF avg ≤ 3 µA | 70 V; 70 mA | large |
| D610 BAS70 | VR ≤ 3.35 V; IF ≤ 0.11 mA (test only) | 70 V; 70 mA | large |
| Q619/Q620 AO3400A | VDS ≤ 3.35 V; ID ≤ 0.72 mA; VGS ≤ 3.35 V | 30 V; 5.7 A; ±12 V | large |
| R665 1 k | ≤ 2 mW at 80 MHz | 62.5 mW | ×30 |
| C624/C625/C629 C0G 50 V | ≤ 3.4 V / 3.2 V / 1.32 V | 50 V | large |
| R601–R604 115 k | ≤ 4.0 V, 0.14 mW | 62.5 mW | large |

## R3.11 BOM, netlist, interfaces and the integration check
- BOM (`bom_rows.csv`, 42 lines): new lines U605, U607, D609, D610, R666, R668, R671, R672/R675/R682, R674, R676/R683, R677/R684, R678/R685, R679/R686, R681, R688/R689, C624, C625, C629; U606 added to the TLV1704 line (qty 4), Q619/Q620 to the AO3400A line (qty 4), R665 to the 1 k line, R667/R680/R687 to the 100 k 1 % line, R669/R673 to the 100 k 0.1 % line, R670 to the 10.0 k 0.1 % line, C623/C626–C628 to the decoupling line; R601–R604 value 115 k. LCSC codes marked **TBC** are not verified (C624 = C1546 as C103). Netlist: every pin of the new parts (U607 pin 1 and U606 pin 13 → NC) — **superseded (R9 E-2) for U606 ch4: 4IN− = N6_H, 4IN+ = N6_HREF, 4OUT (pin 13) = N6_TRIP (latch H-OK detector)**.
- Requests: **digital** — MCU PB8 → net N6_V13_TEST (open drain, default high-Z), PA12 ← N6_V3AG_A_MCU, PB9 ← N6_V3AG_B_MCU (inputs, no pull); R3 firmware rules (R3.9); U606 ch2 needs the MCLK net routed to R665 at the XI pin; +3.36 mA on 3V3D. **Power** — 3V3M +74.2 µA normal / +7.6 µA suspend; 3V3D +3.36 mA; VPOS/VNEG +0.42 mA; D-9 figure becomes 1.66/1.63 mA. **Analog** — none (C601–C604 unchanged).
- `check_design.py power protection analog digital` (09:01 UTC): 371 parts, 1095 pins; issues on my nets then: single_pin_net N6_V13_TEST, N6_V3AG_A_MCU, N6_V3AG_B_MCU (MCU ends) — **resolved 09:16 by digital (R3.16)**. Other issues (not protection): ANA_SENSE cross-stream name without N-prefix (power/digital), RAIL_EN absent (deleted by X-1; the checker's interface list is stale).

## R3.12 Superseded numbers
R2.6/§4: R601–R604 105 k → 115 k; 1 V 101.3 → 111.0 ms; 2 V 46.9 → 51.2 ms; rail-stuck 23.6/11.8 → 25.6/12.8 mJ; envelope 24.9/12.4 → 27.2/13.6 mJ; "false-trip corner 19.6 Hz square" → 18.7 Hz at the aged corner; frozen-code residual row → removed (R3.5). §8.3 pre-close 0.10/0.12 V → 0.070/0.090 V. R2/§6 error budget e_leg 51.0 (R2.6) / 57.50 mV (06:51) → **60.30 mV**, e_pair → **65.51 mV** (DZ-1); T1–T3 levels → R3.17; T3 pair threshold 0.118 → 0.120 V. IWDG 41.7–100 ms (digital) → 16.0–38.4 ms. D-9 block-6 load → R3.7.

## R3.13 What I could not verify
TLV3402 propagation delay has typical values only (bounded ×3); TLV3402, 74AUP1G17, BAS70(-04), the 0.1 % 237 k/330 k/866 k/953 k/1.00 M and the 1 % 2.2 M/4.7 M/22 M resistors: LCSC codes, stock and prices not checked; 74AUP1G17 CPD and a CI maximum are not published (bounds assumed); VT+/VT− only at VCC 3.0 V (scaled with VCC); Kyocera output levels (0.1/0.9 VCC) and the 10–90 % edge definition assumed — hence the MCLK-tap limitation in R3.4 ([MEAS] with a 0 Ω fallback); ESS behaviour with DVDD between 1.235 V and the 1V3 trip is unpublished; photorelay timing over temperature remains ×2 extrapolated (L-2). Not simulated in SPICE: the pump at 80 MHz (analysed with bounds only).

## R3.14 Analog round-3 interface (message 25 Sep 09:05) [CALC p04 re-run]
- **X-8 adopted by analog** (U403/U404 on N4_VPOS_IV/N4_VNEG_IV through D411/D412, VF ≤ 0.30 V): `p04_cm_monitor.py` now takes the I/V supply as VPOS/VNEG ∓ 0.30 V (`IV_VF`; round-2 script kept as `p04_cm_monitor_r2.py.bak`). Results: **I/V stuck high at 2.89 V** (new lowest level) still trips the CM window at silence; worst content removal 25.7 ms → **10.3 mJ (16 Ω) / 5.2 mJ (32 Ω)**; stuck low at −2.72 V trips in 3.6 ms (2.1/1.8 mJ); CM-path envelope unchanged (≤ 12.4 / 7.4 mJ); stuck-pin CM coverage unchanged (≥ 0.98 V per leg), so `p06` and the R3.8 envelope are unchanged. **Reset-state CM ≥ 2.889 V** (swing-limited, analog agrees) > CMTH_HI max 2.151 V → margin **0.738 V** (was 0.756 V); the switch still cannot close with RESETB low or in programming mode.
- Normal content: analog gives +0.087 V I/V headroom at calibrated full scale → no clipping, CM-window margins unchanged (264/210 mV). Only the double fault "trim AND −4.5 dB default lost" (untrimmed 0 dBFS, −0.332 V headroom) clips; the CM then dips by ≤ 0.17 V at the clip peaks, eating the 165 mV lower margin of that case → a protective mute is possible there (no hazard).
- Hot unplug with the reservoirs: the I/V outputs stay powered while U603 loses VPOS/VNEG; each CM node then injects ≤ 3.4 V / 50 kΩ ≈ **68 µA** into the unpowered U603 input clamp (TLV1704 limit 10 mA) and H is low anyway (R647 to the collapsing VPOS). Same bound for U606 ch1 from 1V3 through R670: ≤ 0.13 mA.
- **VREF trims R446/R447 (DNF, change-controlled with p04):** CM sensitivity = 3V3A × (1 + Rf/Rs) ≤ 1.97 × ΔVREF; keeping ≥ 100 mV CM-window margin allows a trimmed **VREF/3V3A of 0.489 … 0.531** (today 0.50526–0.50689) [CALC, linear from the p04 model]; any trim value must be entered in `p04` (`VREF_R`) and re-run before fitting.
- **Conflict flagged — analog's I²C-failure fallback** ("MCLK off → AVCC_EN low → wait 3V3A < 0.1 V → RESETB low → AUD_EN low") cannot run as written: by X-6 (binding), U605B/Q620 force AUD_EN low ≤ 1.04 ms after 3V3A falls below 3.006–3.125 V, so DVCC/DVDD (and RESETB, pulled up to DVCC per X-7) collapse while 3V3A is still ≈ 3 V. This is the ESS-correct order (DVCC not after VCCA), but the 0.045 mV pop figure assumed DVCC on until 3V3A < 0.1 V → **analog to re-evaluate the fallback pop with DVCC collapsing at 3V3A ≈ 3.0–3.1 V** (ESS output behaviour with DVCC off and AVCC up is unpublished → [MEAS]). The normal power-down order (AUD_EN before AVCC_EN) is unaffected.
- C440 2.2 µF on VCCA / C441 DNF: the LP5907 COUT question is power's. Protection impact: slower 3V3A ramp and decay only; U605 thresholds and timing are unaffected (the gates act on the level).
- **Analog reply (09:24, analog R3.12):** X-8 p04 result agreed; every listed VREF trim value (worst 237 k: 0.495–0.517) lies inside 0.489–0.531. Fallback conflict closed by analog: with the U605B trip (3.006–3.125 V, ≤ 1.04 ms) the worst case is the reset step at VREF(3V3A 3.125 V) through COFF: ≤ 12.0 mV (22 % mismatch) / 2.0 mV (3 %) at 300 Ω, vs 12.9/2.1 mV for RESETB-first, so the fallback order stays as a **logged double-I²C-fault path, not a controlled transition** (the switch is open; no DC or energy effect; the X-6 gate is unchanged). Block-6 currents (1.660/1.631 mA) are in analog's budget (5V_ANA 71.56 mA; Default need 176.9 mA). C442/C443 are now KEMET T495D227K010ATE100 (MnO2 tantalum, 10 V, DCL ≤ 0.22 mA at 85 °C). Protection view: a shorted reservoir collapses N4_VPOS_IV/N4_VNEG_IV, the I/V outputs leave the CM window, and H trips (≤ 3.6 ms at silence, p04); the rail overload also reaches firmware through RAILS_OK_N. No protection change. R665 placement at the U301 XI pin agreed.

## R3.15 Digital round-3 interface (message 25 Sep 09:10) — answers
- **As-built mapping** (decision naming → R3): "U605A" → U605 ch A + **Q619** (drain N2_AVCC_EN_G = U206 pin 3); "U605B" → U605 ch B + **Q620** (drain AUD_EN); "U605C" (1V3 good) → **U606 ch1**; "U605D" (MCLK alive) → **U606 ch2**; plus U606 ch3 (3V3A repeater into N6_H). The sinks are AO3400A drains, not comparator outputs.
- **VOL at digital's currents** (≤ 0.35 mA on N2_AVCC_EN_G, ≤ 0.74 mA on AUD_EN): RDS(on) ≤ 48 mΩ × 1.3 (hot) at VGS ≥ 3.25 V → **VOL ≤ 22 µV / ≤ 46 µV** → below U206 VIL 0.8 V, TLV767 VEN(LO) and Q504 VGS(th) min with essentially the full threshold as margin. FET off: IDSS ≤ 5 µA (30 V, 55 °C bound) → ≤ 16 mV off the AUD_EN high level (2.24 V min, 3.2 kΩ Thevenin) and ≤ 50 mV off N2_AVCC_EN_G high.
- **MCLK-alive test limits — corrected:** DC_PERMIT_N high **0.06–1.25 ms** after PB14 low (dead detection ≤ 0.421 ms + H fall to the Q618 threshold ≤ 0.83 ms) → pass **≤ 2.0 ms** (not ≤ 1 ms); back low **64–208 ms** after PB14 high (X201 start ≤ 3 ms + permit recovery 61–205 ms) → pass **≤ 250 ms** (the 155 ms figure is the retired 470 k/220 nF value).
- **3V3A-good positive check** needs the readbacks **PA12 ← N6_V3AG_A_MCU, PB9 ← N6_V3AG_B_MCU** (high = gate active/3V3A not good; low = good): high before AVCC_EN, low ≥ 2 ms after V3A_MON ≥ 3.20 V. **PB8 → N6_V13_TEST** (open drain) is used for the 1V3-good test (U606 ch1), not for a U605 threshold shift; the wrong-order negative test stays in production.
- **Leg self-test criteria:** R3.9 a) (calibrated 45–120 ms / back ≤ 700 ms; default gain 95–210 ms / back ≤ 550 ms), four runs L+, L−, R+, R−.
- **IWDG:** agreed (16.0–38.4 ms; switch open ≤ 39.4 ms after a hang vs Q617 ≥ 53 ms after a trip clears). **Pre-close finals:** |leg| ≤ **0.070 V**, |pair| ≤ **0.090 V** (50 ms average); guaranteed refusal above 129 / 155 mV (after DZ-1, R3.17).

## R3.16 Later orchestrator items DX-1, DX-2, DX-4 (decisions_r8c, 09:02) and digital confirmation (09:16)
- **Digital (09:16):** PB8 = N6_V13_TEST (open drain), PA12 = N6_V3AG_A_MCU, PB9 = N6_V3AG_B_MCU are in `digital/netlist.csv`; R3.9 adopted (IWDG /4 reload 239, EXTI priority, ≤ 1 ms masking, RELAY_EN latch, 0.070/0.090 V, self-test windows a–d, no MCLK stop for rate changes); R665 tap included (X201 load 14.4 pF, clock timing passes). `check_design` now shows **no issue on protection nets** (R3.11 updated below).
- **DX-2** (suspend IWDG ≤ 1.6 s): referenced in R3.9; p10's suspend sentence is superseded by it.
- **DX-1** (suspend: 1 ms CPLD fade + DAC mute, minimum-volume wait with a 5.31 ms deadline, then RELAY_EN low): supersedes the R2.4 suspend row — the switch is now open **≤ 6.32 ms after the last SOF** (5.31 ms + 1.008 ms RELAY_EN path; ≤ 5.81 ms with the 25 °C tOFF). Protection is unaffected: MCLK stops only after RELAY_EN low, so the MCLK-alive trip happens with the switch already open.
- **DX-4** (designed-in fallback R501 221 k → 232 k, VPOS +0.13 V, only if bring-up requires it) [CALC `p13_r501_fallback_check.py`]: leg trip +0.285…+0.330 V; 1 V 115.1 ms, 2 V 52.9 ms; rail-stuck SE **27.3 / 13.6 mJ** (9 % margin); FS 20 Hz square unchanged (the lowest trip is on the VNEG side); MCLK threshold ≤ 0.440 V (running node ≥ 0.890 V); **1V3-good release maximum 1.262 V → only 21 mV below 1V3 min → if R501 = 232 k is fitted, fit R672 = 243 k as well (1.240 V, 43 mV margin; trip minimum 1.121 V)**. The combined stuck-pin envelope rises by an estimated ≈ 4 % (≈ 28.3 mJ at 16 Ω, not re-run) → re-run p03/p04/p06/p10 with the fitted value before release (change-controlled like the VREF trims).

## R3.17 Final check DZ-1 / DZ-6 (orchestrator, 10:12) [CALC p09, p06, p10]
- **DZ-1:** digital's R242–R246 330 Ω 1 % sit between each 4.7 µF node (DC_SENSE_LP/LN/RP/RN, V3A_MON) and its MCU pin (PC0–PC4). They leave the node time constant and the aliasing term unchanged (C at the node) and add to the pin-side source resistance: R_TH 2.486 k + 333 Ω = **2.819 kΩ** (RAIN limit 13.5 kΩ at 13.5 cycles, ×4.8). Error-budget terms: pin leakage 13.60 → **15.42 mV**, sampling charge (20 kHz, CADC start 0…VDDA) 7.32 → **8.31 mV**; others unchanged → **e_leg 57.50 → 60.30 mV, e_pair 62.70 → 65.51 mV** (+2.5 % gain).
- **Firmware tiers** (guaranteed trip, leg / pair): T1 **0.995 / 1.000 V** within 208 ms; T2 **0.311 / 0.306 V** within 574 ms; T3 **0.176 / 0.192 V** within 2.25 s (owner rule ≥ 0.2 V in 3 s met). No-trip levels (leg/pair): T1 644/465 mV, T2 115/41 mV, T3 32.3/**22.1 mV** — **the T3 pair threshold changes 0.118 → 0.120 V** (firmware constant): with 0.118 V the pair no-trip level would have been 20.1 mV, only 0.1 mV above the 20 mV offset spec. Boundary tests: T3 leg 0.180 V / pair 0.196 V → trip ≤ 2246 ms; 29 / 20 mV for 10 s → no trip. Combined envelope unchanged (SE 25.5/12.8 mJ, stuck-pin 27.2/13.6 mJ, opposite-sign 14.7/7.4 mJ); residual never removed by firmware < 0.176 / 0.192 V (≤ 2.31 mW into 16 Ω).
- **Pre-close:** R3.9 (0.070 / 0.090 V unchanged; healthy margins 7.5 / 15.9 mV).
- **DZ-6 / R-5:** R3.5 updated — the CPLD frozen word is bounded by the post-CPLD stream guard like R-2 (≤ 15.5/15.6 mJ flat, ≤ 22.8/25.6 mJ with content); R-5 is now the DAC-core hang only (39.6 / 25.9 mJ at 16 / 32 Ω).
- Scripts: `p09` (R_SER, R_PIN), `p06` (leakage and sampling terms, T3 pair 0.120 V), `p10` (reads e_leg/e_pair from p06, healthy-board check) re-run; previous versions `*_r3a.py.bak`, report `report_r3a.md.bak`.

---

# R8 follow-up (round 2) — 25 Sep 2026

> **Addendum 25 Sep 2026, 05:53 (orchestrator update, binding):** D-3 revised — X201 = Kyocera KC2520K80.0000C1GE00 (80 MHz; the Epson 75 MHz part is end-of-life), so MCLK is 80 MHz again and the ESS soft start is **104.9 ms** (R2.7 recomputed). New D-19 — R645 (1 kΩ to the Q616 gate) is fed from the U206 output **N2_MCLK_OE** (= MCLK_EN AND AVCC_EN AND MCLK_PERMIT, the actual X201 run signal) instead of MCLK_EN, so every MCLK stop opens the output switch in hardware (R2.4, netlist). All numbers below include both changes.

Inputs: orchestrator decisions D-1…D-18 (`integration/decisions_r8b.md`), brief §4/§5, `../digital/firmware_sequences_output.txt`, `../digital/levels_and_pullups_output.txt`, `../digital/netlist.csv`, `../analog/report.md` + netlist, `../power/report.md`, `../parts/followup_r8.md` (Follow-ups 1–2).
This section supersedes the round-1 text (§0–§15 below) wherever they differ; superseded round-1 numbers are listed in R2.14 and flagged **"⟶ R2"** in the round-1 sections. Scripts re-run: p01, p02, p03, p03b, p04, p05 (rewritten), p06, p08; new p09. Every number below comes from their `*_out.txt`.

## R2.1 Changes at a glance

| # | Item | Round 1 | Round 2 | Why |
|---|---|---|---|---|
| 1 | K601–K604 | Panasonic AQV251GAX | **Toshiba TLP3545A(TP1,F)**; AQV251GA(X) only as conditional second source (BOM note column) | D-1 (Toshiba 260 °C reflow; Panasonic 250 °C) |
| 2 | LED drive | MMBT3904 VBE limiter (Q612–Q615, R641/R642 100 Ω, R643/R644 from RELAY_EN) | **low-dropout op-amp current sink**: U604 OPA2333AIDR (on 3V3D) + pass Q612/Q614 + R641/R642 24.9 Ω 0.1 %; reference R662/R663 from RELAY_EN; Q613/Q615 deleted | TLP3545A VF 1.80 V max: the VBE limiter fails by 0.25–0.42 V at 5V_SYS 4.30 V |
| 3 | Permit node H | R647 470 kΩ, C617 220 nF 16 V X7R 0402 | **R647 100 kΩ, C617 1 µF 50 V X5R 0603** — the p05 edit found in the folder (21:06, not run) is adopted | comparator-leakage tolerance 1.7× → 9.1× the listed TLV1704 70 nA (column/temperature of that figure uncertain) |
| 4 | ADC2 | "≥ 28.5 cycles at 14 MHz, ≥ 10 kHz" | ADCCLK 12 MHz: TS 13.5 cycles on the five sense channels (≥ 7.5 required), timer-triggered **20 kHz** 8-conversion scan with a dummy conversion before V3A_MON | D-13 |
| 5 | MCLK | 80 MHz, soft start 104.9 ms | **80 MHz again (Kyocera KC2520K80, D-3 revised): soft start 104.9 ms**; CM-window release and pre-close timeline recomputed against the digital round-2 timeline | D-3 (revised) |
| 6 | Error budget | e_leg 50.2 mV | **51.0 mV** (new sampling-charge term of the chosen scan order) | p09 |
| 7 | Firmware constants | volume ramp 5 ms after RELAY_EN high; "permit recovered ≤ 155 ms" | **10 ms**; **poll DC_PERMIT_N**, recovery ≤ 205 ms after the last trip clears | TLP3545A tON over temperature; Q618 threshold (not Q617) sets the readback |
| 8 | Q616 gate source | MCLK_EN (CPLD pin 21) via R645 | **N2_MCLK_OE** (U206 output, X201 run signal) via R645 | D-19: any MCLK stop — CPLD register, AVCC_EN low, MCLK_PERMIT low at an MCU reset — opens the switch |

## R2.2 Toshiba TLP3545A(TP1,F) — datasheet facts
Source: Toshiba TLP3545A/TLP3545AF datasheet EN edition 2023-05-24, `https://toshiba.semicon-storage.com/info/TLP3545A_datasheet_en_20230526.pdf?did=60318&prodName=TLP3545A` (text in `ds/TLP3545A_toshiba_20230524_extract.txt`; identical tables in the 2020 Mouser copy `../analog/ds/tlp3545a_webfetch.txt`). Ta = 25 °C unless noted.

| Parameter | Value | Label |
|---|---|---|
| Output | 1-Form-A, two MOSFETs; A connection between pins 4 and 6 (AC/DC) | [DS §16.2] |
| VOFF / ION (A) | 60 V / 4 A, −40 mA/K above 25 °C → 2.6 A at 60 °C; IONP 12 A (100 ms, 1/10) | [DS §8] |
| RON (A connection) | 35 typ / **60 mΩ max** at ION 3 A, **IF = 5 mA**, t < 1 s | [DS §13] |
| RON vs temperature | Fig. 16.1.5 is typical only → **×1.35 at 60 °C kept** → 0.081 Ω | [ASSUMP] |
| IFT (trigger) | 0.3 typ / **3 mA max** (ION 1 A) | [DS §13] |
| IFC (return) | **≥ 0.01 mA** (IOFF 10 µA): every unit is off once IF ≤ 10 µA | [DS §13] |
| LED VF | **1.50 / 1.64 / 1.80 V at IF = 10 mA**; no 5 mA row (curve only) | [DS §12] |
| VF bound used | ≤ 1.855 V for any IF ≤ 10 mA at 0 °C (monotone I–V; −2.2 mV/K bound) | [ASSUMP] |
| LED abs max | IF 30 mA (−0.3 mA/K → 19.5 mA at 60 °C), **VR 6 V**, PD 50 mW (−0.5 mW/K → 32.5 mW at 60 °C), Tj 125 °C | [DS §8] |
| Recommended IF | 5 min / 10 typ / 25 max mA | [DS §9] |
| tON / tOFF | IF 5 mA: 1.2 typ / **5 ms max**, 0.1 typ / **0.5 ms max**; IF 10 mA: 0.5 / 3 ms, 0.1 / 0.5 ms (RL 200 Ω, VDD 20 V) | [DS §15] |
| at our IF 5.32–6.60 mA | tON ≤ 5 ms, tOFF ≤ 0.5 ms at 25 °C (tON falls with IF); design values over 0–60 °C: tON 10 ms, tOFF 1.0 ms (Fig. 16.1.8 typical only) | [DS] / [ASSUMP ×2] |
| Off-state leakage | IOFF 0.01 µA typ at 60 V; the **maximum cell is not legible** in either edition → 1 µA design bound | [DS-typ] / [ASSUMP] |
| Output capacitance | COFF 640 pF typ at 0 V, 1 MHz (falls with VOFF, Fig. 16.1.11) → 960 pF bound for coupling | [DS-typ] / [ASSUMP ×1.5] |
| I/O capacitance | CS 0.8 pF typ; BVS 2500 Vrms | [DS-typ] / [DS] |
| Thermal | PO 700 mW, −7 mW/K → ≈ 143 K/W junction-ambient | [DS] / [CALC] |
| Temperature, soldering | Topr −40…110 °C (recommended −40…85 °C); Tsol 260 °C 10 s; reflow once or twice, all within 2 weeks | [DS §8, §17] |
| Pins | **1 anode, 2 cathode, 3 N.C., 4 drain, 5 source (common), 6 drain**; isolation test shorts 1–3 and 4–6 (pin 3 is on the LED side) | [DS, JA edition pin table via parts follow-up 2; §8 note 2] |
| (TP1,F) | **LF1 lead form = surface-mount gull wing, 7.62 mm row pitch**, package TOSHIBA 11-7A801S, 0.39 g, tape and reel 1,500 pcs; body 7.12 × 10.0 × 3.65 mm (parts stream, package page); MSL 1 (parts follow-up 3) | [DS §19] |

Netlist: pin 5 (common source) and pin 3 (N.C.) → net `NC`, isolated pads without traces (Toshiba N.C.; Panasonic "internal circuit – do not connect"; parts follow-up 3 confirms: pin 3 solder pad, no trace; pin 5 unconnected in the A connection); pins 4/6 → LEG_xx / JACK_xx (A connection; the two drains are interchangeable). Pin names now ANODE/CATHODE/N.C./DRAIN/SOURCE/DRAIN.
**Second source (note column only): Panasonic AQV251GA(X)** — same pin assignment; allowed ONLY if JLCPCB confirms a Standard-PCBA reflow peak ≤ 250 °C with ≤ 30 s above 230 °C (Panasonic limit), otherwise excluded. The round-2 drive covers it (VF ≤ 1.5 V at 5 mA, IFon ≤ 3 mA, turn-off current ≥ 0.2 mA ≫ the off-state 5 µA, VR 5 V ≫ ~0 V); its RON 0.08 Ω gives 0.108 / 0.216 Ω at 60 °C.

## R2.3 LED drive redesign and permit node (p05)
**Why the topology changed [CALC p05]:** two LEDs at their 0 °C bound need 3.710 V, leaving **0.590 V** at 5V_SYS = 4.30 V; the round-1 MMBT3904 limiter needs VBE (0.54–0.71 V) + VCE ≥ 0.3 V = 0.84–1.01 V → fails by 0.25–0.42 V. Rejected alternatives: resistor-only drive (≥ 5 mA at 4.30 V gives ≈ 24 mA/string at 5.55 V, above the 19.5 mA 60 °C rating and the budget); four single-LED strings (21–29 mA, ~2× the budget); matched-pair current mirror (spread ≈ ±20 % built on VBE-model and thermal-coupling assumptions, 0.09–0.14 V headroom); op-amp supplied from RELAY_EN through 220 Ω + 100 nF (an intermediate version: the capacitor would hold RELAY_EN up for ms after an MCU reset, defeating R646).

**Circuit in words:** String L: 5V_SYS → K601 LED (1→2) → N6_SL_A → K602 LED → N6_SL_C → Q612 collector (MMBT3904); Q612 emitter N6_EL → R641 24.9 Ω → N6_EM. U604A (OPA2333, V+ = 3V3D, C622 100 nF at the pin): +IN = N6_IREF, −IN = N6_EL, OUT = N6_OAL → R643 4.7 kΩ → Q612 base. String R identical (K603, K604, Q614, R642, R644, U604B; N6_SR_A, N6_SR_C, N6_ER, N6_OAR, N6_BR). N6_IREF = RELAY_EN × R663/(R662 + R663) = RELAY_EN × 5.1 k/105.1 k (0.1 %). N6_EM → Q616 (AO3400A, gate **N2_MCLK_OE** via R645 1 kΩ — D-19; N2_MCLK_OE = U206 output = MCLK_EN ∧ AVCC_EN ∧ MCLK_PERMIT, R235 100 k pull-down, digital stream) → N6_M2 → Q617 (AO3400A, gate N6_H) → GND. I_LED = (V_IREF − VOS − V_FET)/R_S, independent of 5V_SYS and VF while Q612 is active. The three permits: RELAY_EN (reference), the MCLK run signal N2_MCLK_OE (Q616), H (Q617).

| Quantity | Value | Label |
|---|---|---|
| RELAY_EN high level | 2.834–3.366 V (3V3M ±2 %, VOH ≥ VDD − 0.4 V at ≤ 8 mA) | [DS via digital] |
| V_IREF | 137.0–164.0 mV (divider 0.1 % + 25 ppm × 40 K) | [CALC p05] |
| OPA2333 offset | ≤ 24 µV incl. drift and PSRR (VOS ≤ 10 µV at 25 °C, 0.05 µV/K) | [DS SBOS351E §6.6] |
| **LED current per string** | **5.315 … 6.599 mA** (≥ 5.0 mA at every corner, margin 6.3 %; hFE ≥ 49 at 0 °C [ASSUMP ×0.7 of the 70 min], FET drop ≤ 1.65 mV) | [CALC p05] |
| Headroom at 4.30 V, 0 °C, VF max | Q612 VCE ≥ **0.426 V** (0.3 V active-region rule: +0.126 V; VCE(sat) 0.2 V [DS]: +0.226 V) → each LED may exceed the 1.855 V bound by 63 / 113 mV (the round-1 limiter, saturated with 100 Ω, would give only 4.7 mA here — below 5.0 mA) | [CALC p05] |
| Regulation (IF ≥ 5 mA) down to | 5V_SYS 4.17 V worst (0 °C, VF max), ≈ 3.49 V typical | [CALC/ASSUMP LED model] |
| 5V_SYS current (RELAY_EN high) | **10.63 … 13.20 mA** at any 5V_SYS 4.30–5.55 V | [CALC p05] |
| 3V3M current | **0.100 mA** (RELAY_EN pin 66 µA: divider 32 µA + R646 34 µA; DC_PERMIT_N pull-up 34 µA) | [CALC p05] |
| 3V3D current | **0.320 mA** (U604 IQ 56 µA [DS 28 µA/ch max] + base drive ≤ 264 µA); 56 µA while 3V3D is up and RELAY_EN low | [CALC p05] |
| USB total | **≤ 13.62 mA** (D-1 budget 14.3 + 1.02 = 15.32 mA: inside); 0 on 5V_SYS/3V3M with RELAY_EN low; U604 off when 3V3D is off (suspend) | [CALC p05] |
| LED stress | IF ≤ 6.60 mA vs 19.5 mA (60 °C, ×3.0); PD ≤ 12.2 mW vs 32.5 mW; VR ≈ 0 V in every state (6 V; AQV 5 V) | [DS/CALC] |
| Q612/Q614 | VCE ≤ 2.68 V and P ≤ 17.7 mW at 5.55 V (hot, VF min 1.368 V); ≤ 5.55 V off (40 V); ≈ 144 mW rating at 60 °C | [CALC p05] |
| Q616/Q617 | ID ≤ 13.2 mA, VDS ≤ 5.55 V off, P ≤ 11 µW; Q617 VGS −3.83…+4.01 V (±12 V) | [CALC p05] |
| U604 | V+ ≤ 3.366 V (7 V abs), +IN ≤ 164 mV, −IN within the rails, output ≤ 0.54 mA even with Q612 saturated or a string open (ISC 5 mA) | [DS/CALC] |
| **Off state** | RELAY_EN low → V_IREF = 0 → IF ≤ **1.15 µA** (VOS + IB·4.85 kΩ over 24.9 Ω); Q616 or Q617 off → IF ≤ IDSS ≤ 5 µA (30 V/55 °C spec, here VDS ≤ 0.2 V); both below IFC min 10 µA → guaranteed off. 3V3D off → U604 unpowered | [DS/CALC p05] |
| Loop stability (estimate) | crossover ≈ 303 kHz (GBW 350 kHz × follower 0.86); base pole 1.51 MHz (−11°); PM ≥ 44° with ≥ 55° op-amp margin [ASSUMP]. [MEAS] LED-current step response; fallback R643/R644 → 1 kΩ (value change only) | [CALC/ASSUMP p05] |

**Permit node H — the p05 edit (R647 470 k → 100 k, C617 220 nF → 1 µF 50 V) is correct and adopted:** H(high) ≥ 3.68 V (was 3.30 V) and H stays ≥ 3.0 V (Q618 VGS(th) 2.5 V + 0.5 V) up to 7.81 µA total leakage = 634 nA per comparator output = **9.1×** the listed 70 nA (470 k: 1.7×); the TLV1704 table gives 70 nA without a clear max column and at 25 °C only, so 1.7× was not a guarantee. Costs: H fall **0.980 ms** (was 0.216 ms; +0.76 ms on every hardware removal, energies below) and +62 µA rail current only while tripped (switch open). C617 sees −3.83…+4.01 V on a 50 V part; ≤ 34 µJ per trip into the comparator.
Recovery after the last trip condition clears (τ 72–111 ms): **Q617 conducts again after 53 … 135 ms** (minimum switch-off time; no chatter, no latch); **DC_PERMIT_N reads "permitted" after 61 … 205 ms** (Q618 up to 2.5 V). The thresholds overlap (Q618 1.0–2.5 V, Q617 0.65–1.45 V): the readback lags Q617 by ≤ 0.15 ms on a trip and may lead it by ≤ 20 ms on recovery, so the pre-close rule "DC_PERMIT_N low ≥ 50 ms" always finds Q617 on (round 1 said the readback is always conservative — not exactly true; corrected).
Block-6 load on the rails: permitted (normal operation) I+ ≤ 1.244 mA, I− ≤ 1.231 mA (inside D-9's 1.26/1.25 mA); tripped I+ ≤ 1.323 mA, I− ≤ 1.310 mA (R647 79 µA) — only while the switch is open, i.e. without any headphone current, so the D-5 Default budget is unaffected.

## R2.4 Switch-open and switch-close times [CALC p05] (tOFF ≤ 0.5 ms at 25 °C [DS]; 1.0 ms design over 0–60 °C [ASSUMP ×2])

| Event | LED current interrupted | Switch open ≤ (design) | at 25 °C tOFF |
|---|---|---|---|
| RELAY_EN falls (tiers, EXTI on DC_PERMIT_N, suspend, controlled power-down) | V_IREF → 0; U604 slews 1.63 → 0.40 V in ≤ 7.7 µs | **1.008 ms** | 0.508 ms |
| MCU reset / IWDG (RELAY_EN high-Z) | R646 pulls RELAY_EN low in ≈ 2.6 µs (no capacitance on the net) | **1.010 ms** | 0.51 ms |
| MCLK run signal N2_MCLK_OE falls (D-19: MCLK_EN, AVCC_EN or MCLK_PERMIT low; U206 push-pull) | Q616 gate 1 kΩ × ≤ 1 nF → off in 1.9 µs; the same edge stops X201 in ≤ 200 ns [DS Kyocera] | **1.002 ms** | 0.50 ms |
| U206 unpowered (3V3D off; R235 100 kΩ) | 204 µs (U604 has lost its supply as well) | **1.204 ms** | 0.70 ms |
| H falls (any leg or CM window trips) | H 4.014 → 0.45 V in ≤ 0.980 ms | **1.98 ms** after the comparator switches | 1.48 ms |
| Unplug, firmware path (VBUS_SENSE watchdog 3.77–4.23 V [power c09]) | watchdog reached ≤ 0.153 ms after VBUS loss, + ADC 11.3 µs + ISR 20 µs [ASSUMP] | **1.19 ms** after VBUS loss | 0.69 ms |
| Unplug, hardware alone | sink loses regulation below 5V_SYS 4.17 V (worst) / ≈ 3.49 V (typ); IF < 0.3 mA below ≈ 2.86 V; IF ≤ 10 µA below 1.99 V [ASSUMP LED model]; 5V_SYS falls ≥ 11.7 V/ms (≥ 100 mA load from ≤ 8.6 µF [ASSUMP/power]) | **1.31 ms** after VBUS loss | 0.81 ms |
| Suspend (D-16) | SOF-loss timer 1.0 ms + ISR → RELAY_EN low at 1.02 ms | **≤ 2.03 ms after the last SOF** — before the 1.1 ms wait ends and MCLK stops (2.13 ms); suspend current at 2.76 ms [digital], 10 ms limit | 1.53 ms |
| Turn-on after the last condition | U604 slews up ≤ 10 µs | closed ≤ 5.01 ms [DS, 25 °C]; **10 ms design** → firmware waits 10 ms before the volume ramp | — |

The digital constant "wait 1.1 ms after RELAY_EN low" stays valid (bound 1.010 ms). U604 start-up glitches at 3V3D power-up cannot close anything: Q616 (N2_MCLK_OE low) and Q617 (H low, DAC in reset) are open then. At a hard unplug the rails collapse within tens of µs to ms [power], so the unplug pop stays the analog stream's measured target (≤ 20 mV goal); the switch cannot open faster than tOFF.

## R2.5 Switch-dependent analog numbers [CALC p01, p02]
- **Output impedance** (RON 60 mΩ × 1.35 at 60 °C): **+0.081 Ω** on the 3.5 mm path (one switch), **+0.162 Ω** on the 4.4 mm path (two in series); L/R mismatch ≤ 0.081 Ω; leaves ≥ 0.338 Ω (balanced) / 0.419 Ω (3.5 mm) of the 0.5 Ω budget. AQV251GA second source: 0.108 / 0.216 Ω (≥ 0.284 Ω left).
- **THD bound** (round-1 method: anti-series channel cubic term + self-heating at 2f with |Zth| ≤ 250 K/W [ASSUMP; the PO derating implies ≈ 143 K/W DC], gate overdrive ≥ 3 V, tempco 1 %/K [ASSUMP]): 300 Ω balanced (THD+N requirement point) **≤ −164 dB**; 32 Ω SE ≤ −124 dB; 60 Ω balanced ≤ −122 dB; 32 Ω balanced full scale near 20 Hz (not rated) ≤ −106 dB. [MEAS] THD+N at LEG_xx vs JACK_xx remains the bring-up comparison.
- **Open-switch coupling** (COFF ≤ 960 pF): a 35 mV/1 µs leg step gives ≤ 0.40 mV at 300 Ω (0.04 mV at 32 Ω); a 3.5 V/1 ms ramp ≤ 1.0 mV; only a multi-volt µs step would matter (3.5 V/1 µs → 40 mV at 300 Ω) — the analog sequence must not step the legs by volts in µs while the switch is open (rail ramps are ms). **Largest controlled step while open (analog R2.15): the reset-state leg step at AVCC_EN, ≤ 0.343 V in ≥ 21 µs → ≤ 4.37 mV at 300 Ω with the 960 pF bound, ≤ 2.91 mV with the 640 pF typical (20 kHz band limit), ≤ 0.47 mV at 32 Ω** — inside the 5 mV power-on pop target but with only 13 % margin at the bound → [MEAS] (R2.15); the power-down ESS ramp to ground (0.819 ms) gives ≤ 0.12 mV [CALC p01]. LED-to-output coupling through CS 0.8 pF: ≤ 1.6 pC per LED-node step of 2 V → ≈ 0.02 mV band-limited at 300 Ω (negligible). Closing step = the leg DC offset (≤ 10/20 mV), excluded from "pop" by definition; the switch closes only with the DAC muted.
- **Isolation with the switches open (p02 sensitivity):** the plug/adapter analysis (24/24 isolated, architecture A2) holds with the TLP3545A: worst |V| across any driver 0.002 mV (1 µA at 60 V), 0.032 mV (1 µA at 4 V bound), 0.32 mV even at 10 µA at 4 V (10× the bound), with the jack ESD leakage at 1 GΩ or 5 MΩ (LESD5D5.0CT1G IR ≤ 1 µA at 5 V [DS-listing]).

## R2.6 Hardware removal times and energies with the new H fall and tOFF [CALC p03, p04, p06]

| DC on a leg (leg windows) | worst removal R2 (R1) | requirement |
|---|---|---|
| 1.0 V | **101.3 ms** (100.6) ⟶ R3 111.0 ms | 250 ms |
| 2.0 V | **46.9 ms** (46.1) ⟶ R3 51.2 ms | 100 ms |
| 2.19 V (full-scale digital DC) | 42.7 ms (41.9) | — |
| rail-stuck +3.789 / +4.014 V | 24.7 / 23.4 ms | — |
| rail-stuck −3.618 / −3.828 V | 25.8 / 24.5 ms | — |

| Energy case (DC energy at the driver) | 16 Ω | 32 Ω | 60 Ω | 300 Ω |
|---|---|---|---|---|
| Rail-stuck, SE, High mode, worst polarity | **23.6 mJ** (limit 30, 22 % margin) | **11.8 mJ** (limit 15, 22 %) | 6.3 mJ | 1.3 mJ |
| Rail-stuck, balanced (other leg current-bounded) | 14.9 mJ | 11.8 mJ | — | — |
| Balanced ±x, failed I/V or stuck pin ≥ 0.98 V/leg — CM window (removal 3.63 ms at silence, worst content included; analog round-2 I/V values, R2.7a) | **≤ 12.4 mJ** | **≤ 7.4 mJ** | — | — |
| Moderate stuck-pin ±x at silence (leg windows + CM + firmware envelope) | **24.9 mJ** (17 %) | **12.4 mJ** (17 %) | — | — |
| SE / single-leg envelope incl. firmware | 23.5 mJ | 11.7 mJ | — | — |
| Opposite-sign sub-threshold legs (firmware T2) | 14.5 mJ (52 %) | 7.2 mJ | — | — |
| **⟶ R3: removed by X-6, ≤ 1.38 mJ (R3.5).** Residual (not compliance): frozen DAC code while N2_MCLK_OE is high (X201 fails while enabled; every commanded MCLK stop opens the switch via D-19), leg windows only | 36.2 mJ | 23.7 mJ | 14.9 mJ | 3.1 mJ |

False-trip corner unchanged (12.0 Hz sine, 19.6 Hz full-scale square; the filter is unchanged). Firmware tiers (p06, RELAY_EN path 1.008 ms): e_leg **51.0 mV**, e_pair **56.6 mV** (+2.5 % gain); **T1 0.985 / 0.991 V within 208 ms; T2 0.301 / 0.297 V within 574 ms; T3 0.167 / 0.181 V within 2.25 s** (leg / pair); never-trip levels 653/474, 124/50, 41.6/29.0 mV (all above the 10/20 mV offset spec); residual never removed < 0.167 V (leg) / 0.181 V (pair) (owner: < 0.2 V accepted). Boundary tests (§8.5) shift by ≤ 1 mV: T1 1.005/1.011 V, T2 0.307/0.303 V, T3 0.170/0.184 V; no-trip 588/426, 112/45, 37/26 mV. Stream-guard energies (§9) are switch-independent and unchanged.

## R2.7 MCLK 80 MHz (D-3 revised) — DAC reset, soft start, CM window and the pre-close checks [CALC p04]
- Soft start = 4096 × 2^(10+1)/80 MHz = **104.86 ms** (±50 ppm) [DS ESS reg. 14, D-3 revised: X201 Kyocera KC2520K80.0000C1GE00] (the withdrawn 75 MHz part would have given 111.9 ms).
- RESETB low with 3V3A up (normal power-up before RESETB, and programming mode D-15): DAC pins at ground → CM = VREF(1 + RF/Rs), bounded by the OPA2210 swing ((V+) − 0.6 V at 600 Ω, 25 °C [DS SBOS924H]; the reset load is ≈ 830 Ω, 3.29–4.07 mA sourced [analog]) → **CM ≥ 2.907 V** > CMTH_HI max 2.151 V (margin 0.756 V) → H held low, the switch cannot close (round 1 said ≥ 3.3 V; with the analog round-2 values Rf 698 Ω and VREF 0.50607·3V3A the reset-state I/V outputs are 2.907–3.369 V, set by VREF(1 + Rf/Rs) and not by the swing [analog R2.15]; the OPA2210 600 Ω swing row, (V+) − 0.6 V = 3.19 V [DS SBOS924H via parts], lies above that floor).
- During the ramp (DAC source 0 → AVCC/2) the CM falls linearly with the source voltage and leaves the window at **65–76 % of the ramp** (68–79 ms after the ramp starts if the ramp is linear in time [ASSUMP: ESS gives the duration only]); bound: at the end of the ramp, ≤ 104.9 ms. The legs stay near 0 V throughout (the leg difference amplifier rejects the I/V common mode), so the ramp is invisible at LEG_xx apart from mismatch; the switch is open anyway (RELAY_EN low).
- After the release: Q617 conducts ≤ 135 ms, **DC_PERMIT_N low ≤ 205 ms**, so the pre-close rule "DC_PERMIT_N low ≥ 50 ms" is met ≤ 360 ms after the ramp starts.
- Against the digital round-2 power-up timeline (`firmware_sequences_output.txt`, 05:42), CPLD configuration 10 ms: I²C init 45 ms → soft start done ≤ 149.9 ms → DC_PERMIT_N low ≤ 355 ms → **pre-close checks pass ≤ 405 ms** → RELAY_EN high → volume ramp ≥ 415 ms; with the digital stream's 1.2× soft-start allowance (125.8 ms): ≤ 426 / 436 ms. CPLD 100 ms: ≤ 495 / 505 ms (≤ 516 / 526 ms with the allowance). V3A_MON-valid ≥ 150 ms (175 ms) and "≥ 50 ms of valid readings" are not limiting. The digital table's "permit H recovered ≤ 155 ms" (Q617-based, 470 k/220 nF) is replaced by DC_PERMIT_N polling with a CM/clock-fault timeout of 300 ms after the soft-start end. Pre-close list (§8.3) otherwise unchanged; the volume-ramp wait becomes 10 ms.

## R2.7a CM window with the analog round-2 I/V values [CALC p04]
The analog stream's round-2 I/V design differs from the round-1 inputs of p04: Rf **698 Ω** 0.1 % (was ≈ 836 Ω), VREF = **0.50607 × 3V3A** (0.50526–0.50689; was 0.500 or 0.516), leg gain R2/R1 = 2.00/1.98 kΩ = 1.0101 (was 1.0) [analog BOM/`analog_budget.txt` 2, 25 Sep 05:56]. I also corrected the content model: the I/V differential at calibrated full scale is A_FS/G = 2.206 V pk, and the CM ripple of a pin pair with the full ±11 % Rs mismatch is A_FS/G × (w − 0.5) = 121 mV (w = 0.555 = largest pin share). Thresholds and parts are unchanged.

| Quantity | Round 2 | Round 1 |
|---|---|---|
| Normal CM band at 3V3A 3.3 V (all tolerances, content with 22 % pin mismatch) | 1.512–1.816 V | 1.427–1.928 V |
| No-false-trip margin, worst corner (upper / lower) | **264 / 210 mV** | 157 / 129 mV |
| Same with the trim lost (untrimmed 0 dBFS 3.06 V pk per leg) | 218 / 165 mV | — |
| Content peak on the healthy I/V output | ±1.22 V | ±1.41 V |
| I/V stuck high/low: trip at silence / worst content | ≤ 3.63 ms / ≤ 21.6 ms | 2.87 / 22.1 ms |
| Stuck DAC pin: CM coverage at silence | **≥ 0.98 V per leg** | ≥ 1.07 V |
| CM-path energies (16 / 32 Ω), worst content | **≤ 12.4 / 7.4 mJ** | ≤ 12.7 / 8.0 mJ |
| Reset-state CM | ≥ 2.907 V (Rf at −0.16 %, Rs +11 %, VREF min) | ≥ 3.3 V (3.12 V in the first round-2 draft) |

The trip thresholds are ratiometric to 3V3A like VREF, so the narrower VREF band only widens the margins. Below 0.98 V/leg the stuck-pin case is covered by the leg windows and firmware tiers; recomputed in p06 with this coverage the combined stuck-pin envelope is **24.9 / 12.4 mJ (16 / 32 Ω, 17 % margin; worst at 1.96 V across, removal 104 ms)**, down from 26.7 / 13.4 mJ.

## R2.8 ADC2 (D-13) [CALC p09]
- WCH formula (Table 4-42; CADC 8 pF, RADC ≤ 1 kΩ, tCONV = TS + 12.5 cycles) at 12 MHz: RAIN max 0.6 / 7.1 / 13.5 / 29.6 / 43.5 kΩ at 1.5 / 7.5 / 13.5 / 28.5 / 41.5 cycles.
- **Sense channels (DC_SENSE_LP/LN/RP/RN, V3A_MON; R_TH 2.486 kΩ): TS ≥ 7.5 cycles required; use 13.5 cycles** (RAIN max 13.5 kΩ, 5.4×). With ≥ 3.4 µF effective at each pin the charge-share step is ≤ 7.8 µV (0.01 LSB) for a full-scale jump, so the table is conservative here. CC1/CC2 (14.67 kΩ): ≥ 28.5 cycles (digital stream).
- 7-channel scan: 17.7 µs (56.6 kHz per channel if continuous); **recommended: timer-triggered 20 kHz scan with DMA, 8 conversions: CC1, CC2, V3A_MON (dummy, discarded), V3A_MON, LP, LN, RP, RN** — 19.8 µs, ADC2 40 % busy, **20 kHz per sense channel ≥ 10 kHz (×2)**. Round-1 digital choice (239.5 cycles, 6.8 kHz) is not used.
- The rate enters only two terms: aliasing (kept at the 10 kHz value 4.2 mV, conservative) and the new **sampling-charge term** CADC × f × ΔV × R_TH: 0.398 mV per volt of difference to the previous channel → ≤ 0.80 mV per leg, ≤ 1.19 mV per pair at 20 kHz with the dummy before the reference (2.0 mV if run continuously at 50 kHz). Added to p06 → the tier numbers of R2.6. Estimator unchanged: the firmware averages sample pairs to the 10 kHz stream; windows are defined in time.

## R2.9 Programming mode (D-15) and back-feed
- **State:** rails up, 3V3A/AVCC/DVCC up, RESETB low, MCLK off, RELAY_EN low → the switch is open three times over: RELAY_EN low (V_IREF = 0, IF ≤ 1.15 µA), N2_MCLK_OE low because MCLK_EN is low (Q616 off; X201 stopped), CM window tripped (DAC in reset: CM ≥ 2.907 V) → H low (Q617 off). DC_PERMIT_N reads high ("not permitted") — expected in this mode, the firmware must not log it as a fault. The leg windows and CM windows are powered and valid. U604 draws 56 µA from 3V3D.
- **Back-feed:** with the rails up whenever 3V3A is up (D-15), the DC-sense networks load driven OPA1622 outputs: (a·3V3A)/R_S = **0.232–0.241 mA per leg into the leg at 0 V** (sunk by the OPA1622 output to VNEG → ≈ 0.96 mA on V− for four legs, confirming the D-10 note "≈ 0.24 mA per leg") — no back-feed into an unpowered amplifier.
- **Remaining case:** the rails collapse while 3V3A stays up — 5V_ANA overload/short (TPS2596 limit or auto-retry), LM27762 UVLO — until the firmware takes AVCC_EN low (RAILS_OK_N/ANA_FAULT_N → controlled shutdown, ≈ ms) or, with a hung MCU, until the IWDG reset (≤ 100 ms) lets the EN pull-downs act. During that time each DC-sense network pushes ≤ 0.24 mA (2.59 V Thevenin through 10.7 kΩ) into the unpowered OPA1622 output (abs max ±10 mA on all non-supply pins [DS SBOS727B §6.1], ×40), and the CM threshold chain (3V3A → R657) feeds ≤ 0.34 mA into U603's input clamps (TLV1704 ±10 mA [DS]). Both are bounded and harmless; the switch is open (H low as the rails fall, RELAY_EN low by firmware).

## R2.10 Interface nets (D-2, D-12) and the integration check
My nets are unchanged: K601/K603 → JACK_LP/JACK_RP, **K602/K604 → JACK_LN/JACK_RN**; all sense/detector taps on LEG_xx; R653–R656 on **N4_IVL_P, N4_IVL_N, N4_IVR_P, N4_IVR_N**. New block-6 connections to interface nets: U604 V+ and C622 on **3V3D**; R662 on RELAY_EN; **R645 moved from MCLK_EN to the digital net N2_MCLK_OE (D-19)**. New internal nets: N6_IREF, N6_OAL, N6_OAR (N6_VOP of the intermediate version is not used).
`python3 integration/check_design.py power protection analog digital` (25 Sep 2026, 06:45, after the D-19 and analog round-2 updates): 309 parts, 309 netlisted, 177 nets, 936 pins, **no issues** (earlier runs listed only `iface_absent` DOM_DIS/AMP_EN, the retired D-11 nets). The round-1 single-pin issues on JACK_LN/JACK_RN and N4_IV* are gone: the analog netlist has J701 pins 2/4 and D703/D704 on JACK_LN/JACK_RN and the renamed OPA2210 outputs. Verified connectivity: JACK_LN = K602.6 + J701.2 + D703.1; JACK_RN = K604.6 + J701.4 + D704.1; N4_IVL_P = R653.1 + U403.1 …; LEG_xx = R417–R420 + my three taps each; RELAY_EN = U201.44; DC_PERMIT_N = U201.55; **N2_MCLK_OE = R645.1 + U206.4 (Y) + X201.1 (INH) + R235.1 + U201.27 (PB1 readback)**; MCLK_EN = U202.21, U206.1, R218 (no protection pin any more).

## R2.11 Component stress table — round-2 rows (other rows of §11 unchanged)

| Ref | Part | Stress (worst, all power states) | Rating [DS] | OK |
|---|---|---|---|---|
| K601–K604 | TLP3545A(TP1,F) | off: ≤ 4.1 V steady, ≤ 18.6 V during a jack ESD clamp (LESD5D5.0CT1G VC 18.6 V at 9.4 A 8/20 µs LRC original, 16 V GOODWORK listing [parts follow-up 3]); on: ≤ 0.25 A (rail-stuck into 16 Ω), PO ≤ 5.1 mW; LED IF ≤ 6.60 mA, PD ≤ 12.2 mW, VR ≈ 0 V; ≤ 60 °C | 60 V; 2.6 A and 455 mW at 60 °C; IF 19.5 mA and PD 32.5 mW at 60 °C; VR 6 V; Topr 110 °C | yes |
| Q612, Q614 | MMBT3904 | VCE ≤ 5.55 V, IC ≤ 6.6 mA, P ≤ 17.7 mW | 40 V, 200 mA, ≈ 144 mW at 60 °C | yes |
| U604 | OPA2333AIDR | VS ≤ 3.366 V; inputs 0…V+; output ≤ 0.54 mA; unpowered with inputs at ~0 V (suspend) | 7 V abs, (V−) − 0.3…(V+) + 0.3 V, ±1 mA input, output short continuous | yes |
| Q616, Q617 | AO3400A | VDS ≤ 5.55 V, ID ≤ 13.2 mA, VGS −3.83…+4.01 V (Q617), 0…3.4 V (Q616) | 30 V, 5.7 A, ±12 V | yes |
| R641, R642 | 24.9 Ω 0.1 % | 1.08 mW, ≤ 0.17 V | 50 mW (PATT) / 62.5 mW (RT) | yes |
| R643, R644 | 4.7 kΩ | ≤ 0.8 mW (saturated/open-string case 0.54 mA) | 62.5 mW | yes |
| R647 | 100 kΩ | ≤ 7.84 V, 0.62 mW (tripped) | 50 V, 62.5 mW | yes |
| R662, R663 | 100 k / 5.1 k 0.1 % | ≤ 3.37 V, ≤ 0.11 mW | 50 V | yes |
| C617 | 1 µF 50 V X5R 0603 | −3.83…+4.01 V | 50 V | yes |
| C622 | 100 nF 16 V X7R | ≤ 3.47 V | 16 V | yes |

## R2.12 Parts changed / added / removed (round 2) and cost
- **Changed:** K601–K604 AQV251GAX → **Toshiba TLP3545A(TP1,F)** (no LCSC; JLCPCB global sourcing; DigiKey 28,529 on the TP1 page on 18 Sep 2026 and Mouser 15,326 on 3 Aug 2026 [parts follow-ups 2–3]; MSL 1); R641/R642 100 Ω → **24.9 Ω 0.1 % 25 ppm** (Vishay PATT0402E24R9BGT1, alt. Yageo RT0402BRD0724R9L; global sourcing; a 1 % 100 ppm 24.9 Ω also meets D-1 with 5.25–6.68 mA); R643/R644 4.7 kΩ now from U604 outputs (same part C25900); **R647 470 k (C25790) → 100 k (C25741)**; **C617 220 nF 16 V 0402 (C16772) → 1 µF 50 V X5R 0603 Samsung CL10A105KB8NNNC (C15849)**.
- **Added:** **U604 TI OPA2333AIDR** (C38732, LCSC 5,082 on 25 Sep 2026, SOIC-8); **R662** 100 k 0.1 % (C852472 line); **R663** 5.1 k 0.1 % (C852856 line, global sourcing as before); **C622** 100 nF (C1525 line).
- **Stock updates (parts follow-up 3):** TLV1704AIPWR DigiKey 6,948 (23 Sep 2026) besides LCSC 61 → global sourcing is easy (MSL 2-260C-1 year); RT0402BRD07121KL (R607) DigiKey 25,651 (re-read 25 Sep 2026).
- **Removed (retired designators):** **Q613, Q615** (MMBT3904 sense transistors). R664 was used only in an unreleased intermediate draft — not in any BOM/netlist; left unused.
- Totals: 77 parts, 217 pins, 24 BOM lines (round 1: 75 / 209 / 24); block 6 ≈ US$ 21.4 per board at 100-board prices [p08; TLP3545A price US$ 3.60 estimated, not verified].

## R2.13 Interface requests (round 2)
**Power stream:** (1) switch drive while RELAY_EN is high: **5V_SYS ≤ 13.20 mA, 3V3M ≤ 0.10 mA, 3V3D ≤ 0.32 mA** (total ≤ 13.62 mA; replaces 14.3 + 1.02 mA); 3V3D 56 µA whenever 3V3D is up and RELAY_EN is low; 0 in suspend. (2) VPOS/VNEG from block 6: normal operation I+ ≤ 1.244 mA, I− ≤ 1.231 mA (D-9 holds); tripped +79 µA each (switch open). (3) 3V3A 1.82 mA unchanged (D-10); the sense networks add ≈ 0.24 mA per leg (≈ 0.96 mA) to the OPA1622 V− current — confirm it is in the analog quiescent. (4) The unplug numbers assume ≥ 100 mA board load and ≤ 8.6 µF on VBUS + 5V_SYS; tell me if either is wrong.
**Digital stream:** (1) ADC2: TS 13.5 cycles on PC0–PC4 (DC_SENSE_x, V3A_MON), 28.5 on CC1/CC2; timer-triggered 20 kHz 8-conversion scan (CC1, CC2, V3A_MON dummy, V3A_MON, LP, LN, RP, RN) with DMA; the firmware averages pairs to 10 kHz for the tiers. (2) Firmware constants: volume ramp **10 ms** after RELAY_EN high (was 5 ms); keep 1.1 ms after RELAY_EN low. (3) Power-up: after the soft start (104.9 ms at 80 MHz) **poll DC_PERMIT_N** (low ≤ 205 ms after the soft-start end; pre-close pass ≤ 405 ms from configuration in the 10 ms CPLD case, ≤ 426 ms with your 1.2× soft-start allowance); CM/clock-fault timeout 300 ms after the soft-start end; replace "permit H recovered ≤ 155 ms". (4) RELAY_EN load is 66 µA resistive (no capacitor on the net); R646 stays; **R645 now on N2_MCLK_OE (D-19)** — matches your netlist (U206.4, R235, PB1); the Q616 gate adds 1 kΩ + ≤ 1 nF to that net (≤ 3.3 mA edge current, X201 INH edge unaffected). (5) Programming mode: DC_PERMIT_N high is expected, not a fault. (6) Fault policy R2.13a: RAILS_OK_N dips < 25 ms with ANA_FAULT_N high are headroom events (log, no RELAY_EN action; optional −1 dB High ceiling below VBUS_SENSE 4.60 V); ≥ 25 ms or ANA_FAULT_N low → overload policy.
**Analog stream:** (1) output impedance + ≤ 0.081 Ω (3.5 mm) / ≤ 0.162 Ω (4.4 mm) at 60 °C; L/R mismatch ≤ 0.081 Ω. (2) THD bounds R2.5. (3) COFF ≤ 960 pF: avoid multi-volt µs leg steps while the switch is open (3.5 V/1 µs → 40 mV at 300 Ω). (4) Answered (analog R2.15, parts FU3): the reset-state I/V outputs are 2.907–3.369 V, set by VREF(1 + Rf/Rs) and not by the swing → CM ≥ 2.907 V, used in R2.7/R2.7a; D701–D704 (LESD5D5.0CT1G) are bidirectional on JACK_xx (p02 used ≤ 1 µA at 5 V). Please keep me informed if Rf, VREF/3V3A or the leg gain R2/R1 change again — they set the CM band (R2.7a).
**Parts / layout:** TLP3545A(TP1,F) land pattern (11-7A801S LF1) — confirm the shared footprint with AQV251GA against Toshiba's reference land figure; pins 3 and 5 isolated pads; U604 SOIC-8 with C622 at pin 8, close to Q612/Q614 and R641/R642 (keep the R641/R642–N6_EM–Q616 loop short; sense at the resistor pads, Kelvin-style to U604 pins 2/6); C617 0603 next to Q617/Q618; test pads for N6_H, DC_PERMIT_N, RELAY_EN, N6_EL, N6_ER (LED current = V/24.9 Ω). JLCPCB Standard-PCBA profile (peak, time above 230 °C) — needed only for the AQV251GA option.

## R2.13a Fault policy change — short RAILS_OK_N dips (analog request, 25 Sep 06:44)
At VBUS 4.40 V the LM27762 negative LDO can drop out briefly at High-mode signal peaks (32 Ω SE / 60 Ω balanced) and PGOOD may dip [analog R2.5]. New rule (replaces the RAILS_OK_N line of §10.2): **RAILS_OK_N high while ANA_EN is high and ANA_FAULT_N is high for < 25 ms → headroom event**: log it, no RELAY_EN action, optional −1 dB adaptive High ceiling while VBUS_SENSE < 4.60 V (analog R2.5). **RAILS_OK_N high ≥ 25 ms, or ANA_FAULT_N low at any time → overload policy unchanged** (RELAY_EN low, controlled shutdown, ceiling −3 dB per event, retry ≥ 1 s). Why this is safe: PGOOD is not a DC-protection element — the leg windows (thresholds track the rails), the CM window and the firmware tiers stay armed during the dip, and a collapse below VPOS − VNEG ≈ 2.2 V removes the hardware permit H by itself (§4.6); a genuine rail collapse held for the 25 ms qualification adds ≤ 1.9 mJ at 16 Ω (≤ 1.1 V leg, §4.6) [CALC], and clipping against a sagging rail makes ≤ 0.12 V of content-induced DC (sine 2.2 V pk clipped at −1.5 V), below every trip level. The pre-close rule "rails good = RAILS_OK_N low AND ANA_EN high for ≥ 20 ms" is unchanged.

## R2.14 Superseded round-1 numbers (marked "⟶ R2" in §0–§15)

| Round 1 | Round 2 |
|---|---|
| AQV251GAX: 30 V, 3.5 A, RON ≤ 0.08 Ω, VF ≤ 1.5 V at 5 mA, leak ≤ 1 µA, Coff ≈ 450 pF | TLP3545A: 60 V, 4 A, RON ≤ 0.060 Ω, VF ≤ 1.80 V at 10 mA, IOFF typ 0.01 µA (max not legible), COFF 640 pF typ |
| LED 5.24–7.14 mA/string; 5V_SYS 10.5–14.3 mA; 3V3M ≤ 1.02 mA; USB ≤ 15.3 mA | 5.32–6.60 mA; 10.6–13.2 mA; 3V3M 0.10 mA + 3V3D 0.32 mA; ≤ 13.6 mA |
| Q612 VCE ≥ 0.49 V (VF 1.55 V), Q612 ≤ 21 mW, R641 ≤ 5.1 mW | VCE ≥ 0.426 V (VF 1.855 V, op-amp sink), 17.7 mW, 1.08 mW |
| H ≥ 3.30 V; fall 0.22 ms; removal via H ≤ 1.22 ms | H ≥ 3.68 V; 0.980 ms; ≤ 1.98 ms |
| Minimum off-time 52–155 ms; rails-up to permit 12–67 ms; "readback always conservative" | Q617 53–135 ms; DC_PERMIT_N 61–205 ms (the CM window, not the rails, now sets power-up); readback may lead Q617 by ≤ 20 ms |
| Unplug: strings drop out below ≈ 3.9–4.1 V, open ≤ 0.5–1 ms later | regulation lost ≤ 4.17 V, guaranteed off ≤ 1.99 V; open ≤ 1.19 ms (firmware) / 1.31 ms (hardware) after VBUS loss |
| Output impedance ≤ 0.108 / 0.216 Ω | ≤ 0.081 / 0.162 Ω |
| THD ≤ −159 (300 Ω bal), −119 (32 Ω SE), −117 (60 Ω bal), −101 dB (32 Ω bal, not rated) | −164, −124, −122, −106 dB |
| Coupling 0.19 mV / 18.9 mV at 300 Ω (35 mV / 3.5 V in 1 µs) | 0.40 mV / 40.3 mV (COFF bound 960 pF); real worst sequence step (0.343 V/21 µs, analog): ≤ 4.37 mV at 300 Ω |
| Removal 1 V 100.6 ms, 2 V 46.1 ms, FS DC 41.9 ms, rail-stuck 22.6–25.1 ms | 101.3, 46.9, 42.7, 23.4–25.8 ms |
| Rail-stuck SE 22.8 / 11.4 / 6.1 / 1.2 mJ; balanced one-leg 14.5 / 11.4 mJ | 23.6 / 11.8 / 6.3 / 1.3 mJ; 14.9 / 11.8 mJ |
| CM window removal 2.87 ms; ≤ 12.7 / 8.0 mJ (16/32 Ω) | 3.63 ms; ≤ 12.4 / 7.4 mJ |
| Envelope: SE 22.7 / 11.3 mJ; stuck pin 26.5 / 13.3 mJ (12 %) | 23.5 / 11.7 mJ; 24.9 / 12.4 mJ (17 %; worst at 1.96 V, removal 104 ms) |
| Frozen-code residual 35.8 / 23.3 / 14.6 / 3.0 mJ | 36.2 / 23.7 / 14.9 / 3.1 mJ |
| e_leg 50.2 mV, e_pair 55.4 mV; T1 0.984/0.990, T2 0.301/0.296, T3 0.166/0.180 V; residual < 0.166/0.180 V | 51.0 / 56.6 mV; 0.985/0.991, 0.301/0.297, 0.167/0.181 V; < 0.167/0.181 V |
| ADC ≥ 28.5 cycles at 14 MHz, 10 kHz | 13.5 cycles at 12 MHz, 20 kHz timer-triggered |
| Reset-state CM ≥ 3.3 V | ≥ 2.907 V (analog round-2 values) |
| CM normal band 1.427–1.928 V, margins 157 / 129 mV; stuck-pin coverage ≥ 1.07 V/leg; CM energies ≤ 12.7 / 8.0 mJ | 1.512–1.816 V, 264 / 210 mV; ≥ 0.98 V/leg; ≤ 12.4 / 7.4 mJ (analog round-2 I/V values) |
| Rail currents I+ ≤ 1.26, I− ≤ 1.25 mA (incl. tripped H) | permitted 1.244 / 1.231 mA; tripped 1.323 / 1.310 mA |
| Firmware: volume ramp 5 ms after RELAY_EN; permit recovered ≤ 155 ms | 10 ms; DC_PERMIT_N ≤ 205 ms, poll |
| Q616 gate from MCLK_EN via R645 (switch opens on MCLK_EN low only) | from N2_MCLK_OE (D-19): opens on MCLK_EN, AVCC_EN or MCLK_PERMIT low, ≤ 1.002 ms |
| 75 parts, 209 pins, ≈ US$ 22 | 77 parts, 217 pins, ≈ US$ 21.4 |

## R2.15 Open items (round 2) and what I could not verify
| Item | Why | Designed-in fallback |
|---|---|---|
| [MEAS] TLP3545A tOFF and RON at 60 °C | datasheet curves typical only (×2 / ×1.35 assumed) | none needed: switch-open ≤ 1.0 ms design vs 100/250 ms and energy margins ≥ 11 % |
| [MEAS] LED current per string at 0/25/50 °C and 5V_SYS 4.30 V (V across R641/R642) | hFE at 0 °C and VF temperature coefficient assumed | R641/R642 value change (24.9 → 22.1 Ω raises IF by 13 %) |
| [MEAS] TLP3545A VF at 5–6.6 mA and 0 °C on samples (parts-stream request) | no VF maximum at 5 mA and no tempco are tabulated; the design bounds VF by the 10 mA maximum + 2.2 mV/K (1.855 V) | none needed: each LED may exceed that bound by 63 mV (active-region rule) / 113 mV (VCE(sat)) before IF leaves regulation (a tempco down to −4.7 mV/K is tolerated) [CALC p05] |
| [MEAS] U604 loop step response | PM ≈ 44° is an estimate | R643/R644 → 1 kΩ (value change) |
| [MEAS] H level at 50 °C (TLV1704 output leakage) | leakage maximum over temperature not specified | R647 → 47 kΩ with C617 → 2.2 µF (value changes, same footprints) |
| [MEAS] ESS soft-start shape / CM release time | ramp shape not in the datasheet | none: firmware polls DC_PERMIT_N with a 300 ms timeout |
| [MEAS] power-on pop at 300 Ω with the switch open (reset-state leg step 0.343 V/21 µs through COFF) | bound 4.37 mV vs 5 mV (COFF maximum not specified; ×1.5 of 640 pF typ assumed) | if > 5 mV: slower reset-state step at AVCC_EN (analog/power stream: 3V3A ramp) — ≥ 50 µs halves it; no protection-block change possible (COFF is inherent) |

Not verified: TLP3545A IOFF maximum and IFP (cells not legible in the extracted text); all TLP3545A curves (IF–VF, RON–Ta, tON/tOFF–Ta, IFT–Ta, COFF–VOFF) are typical and were not readable — the VF −2.2 mV/K bound, RON ×1.35, tON/tOFF ×2 and COFF ×1.5 are assumptions; Toshiba's reference land-pattern numbers (figure only); TLP3545A price (DigiKey TP1 stock 28,529 on 18 Sep 2026 is now confirmed by the parts stream); JLCPCB class of OPA2333AIDR and CL10A105KB8NNNC (LCSC pages read, JLCPCB pages not); LCSC stock of 24.9 Ω 0.1 % (none found — global sourcing); the OPA2333 unity-gain phase margin with the BJT stage; the MMBT3904 hFE at 0 °C (×0.7); the board load at unplug (≥ 100 mA) and the LED low-current model (n = 2, Rs 3 Ω); the OPA2210 swing used for the reset-state CM (VPOS − 0.5 V); ESS soft-start ramp shape; the round-1 unverified items of §14 still apply (CH32V307 pin leakage ±1 µA, VOH below 8 mA — the VDD − 0.4 V bound is used, ADC gain error; OPA1622 current limit maximum; ES9018K2M lock-loss state; MLCC DC-bias factors).

---


## 0. Summary of decisions (and where the brief's §3 baseline is overridden)

| # | Brief §3 proposal | Decision | Evidence |
|---|---|---|---|
| 1 | One DPDT relay in L+ and R+ only | **Disproved.** Opening only L+/R+ fails 12 of 24 plug combinations — every case with a plug in J702 while J701 holds a plug that uses JACK_LN/JACK_RN (balanced plug or a 4.4→3.5 adapter with L−/R− connected): the balanced driver and the 3.5 mm driver end up in series between LEG_LN (LEG_RN) and GND through the shared JACK_LP (JACK_RP) net, 0.31–4.0 V across a driver with the switch open. Switching **all four legs** isolates 24/24. | `p02_connection_cases_out.txt` (DC nodal analysis, all 81 fault polarity combinations, 5 × 5 plug/adapter cases) |
| 2 | Electromechanical DPDT relay(s) | **4 × PhotoMOS relay Panasonic AQV251GAX** (K601 L+, K602 L−, K603 R+, K604 R−). **⟶ R2: Toshiba TLP3545A(TP1,F) (D-1), AQV251GA(X) conditional second source; drive ≤ 13.6 mA (R2.2–R2.3).** Two DPDT relays (needed for 4 legs) draw **69–93 mA** at 5.5 V/0 °C with a coil that still operates at 4.3 V/60 °C (only 4.5 V coils do; every 5 V coil fails the low-VBUS/hot corner). The PhotoMOS drive needs **≤ 15.3 mA** at every VBUS, opens in **≤ 0.5 ms** [DS] (relays 3–5 ms), has no bounce, no flyback, no dry-circuit issue. | `p01_switch_choice_out.txt`, `p05_switch_drive_out.txt` |
| 3 | LM339B, windows at ≈ ±0.55 V, single- or two-pole filter | **TI TLV1704** (rail-to-rail input, ≤ 100 µA/ch, IB ≤ 20 nA over temperature [DS]); **single-pole** filter (the passive 2-pole ladder is worse for every metric here); windows at **±0.30 V** with **τ = 231 ms** (105 kΩ / 2.2 µF). Same content rejection as a 0.55 V/113 ms design (sized so that even a full-scale 20 Hz *square* wave cannot trip), but half the sub-threshold envelope and faster removal of moderate faults. | `p03_detector_out.txt`, `p03b_threshold_scan_out.txt` |
| 4 | Balanced ±x covered by the leg windows | **Not achievable by any leg-voltage filter**: at 32 Ω a current-limited ±x (4.3 V across, 0.57 W) must be removed in ≈ 25 ms, but a full-scale 20 Hz sine looks the same for 25 ms. Added a content-independent **I/V common-mode window** (U603): the mean of the two I/V outputs of a channel is constant for any audio content and moves ≥ 0.5 V for a failed I/V op-amp or stuck DAC pin. Also blocks the permit while the DAC is in reset and while 3V3A is absent (DC-sense network invalid). | `p04_cm_monitor_out.txt` |
| 5 | Permit = RELAY_EN AND H | **RELAY_EN AND MCLK_EN AND H** (**⟶ R2/D-19: MCLK run signal N2_MCLK_OE instead of MCLK_EN**); H also carries the CM windows; C617 on H gives a 52–155 ms minimum off-time (no latch, no chatter) **⟶ R2: R647 100 k / C617 1 µF, 53–135 ms (R2.3)**. MCLK_EN gate: a CPLD/firmware MCLK stop freezes the DAC at an arbitrary code (a balanced ±x of up to full scale that no filter can catch fast) – the switch now opens ≤ 1.01 ms after MCLK_EN falls (**⟶ R2: 1.002 ms, R2.4**). | `p05_switch_drive_out.txt` |
| 6 | PGOOD / FAULT to the MCU only | **Confirmed**, with the argument in §7. | §7 |
| 7 | Four firmware tiers | **Three tiers** (guaranteed trip levels, leg / pair: T1 0.984 / 0.990 V within 208 ms, T2 0.301 / 0.296 V within 574 ms, T3 0.166 / 0.180 V within 2.25 s **⟶ R2: 0.985/0.991, 0.301/0.297, 0.167/0.181 V (R2.6)**), CIC² estimator, guaranteed physical levels including every error; combined hardware+firmware envelope ≤ 30 / 15 mJ with ≥ 12 % margin. | `p06_dcsense_tiers_out.txt` |
| 8 | DC-sense network 15 k/10 k/22 k + 3V3A/2 monitor | Redesigned: 6.8 k / 5.1 k / 16.9 k 0.1 % 25 ppm + 4.7 µF 25 V (DC-bias robust) on the **amplifier side** of the switch; the 3V3A monitor becomes an identical **reference network** (same pin V3A_MON) so the reading (leg − reference) cancels ADC offset, 3V3A value and drift. e_leg ≤ 50.2 mV, e_pair ≤ 55.4 mV + 2.5 % (**⟶ R2: 51.0 / 56.6 mV**). | `p06_dcsense_tiers_out.txt` |
| 9 | Stream guard (R8-A3) | CIC² of two 50 ms running means, trigger ≥ 0.30 FS, plus a "flat for 26 ms" path. Worst full-scale sine ≥ 20 Hz: 0.159 FS (47 % margin); full-scale 20 Hz square wave 0.250 FS: no trigger. | `p07_stream_guard_out.txt` |

Deleted: the whole fault latch (Q601–Q611, R611–R617, R623, R638, C605–C607, D605, D606), R636/R637 (series threshold parts), R618 (AMP_EN kill resistor), blanking and interlock networks, the FLT / FLT_CLR / ANA_FAULT-as-output signals, the firmware start-up DC watch. No relay coil suppression parts are needed.

---

## 1. R8 items in this scope — dispositions

| ID | Finding | Disposition | Status |
|---|---|---|---|
| A2 | TPS2553 FAULT → D606 → node F margin | Path deleted. ANA_FAULT_N (TPS2553 FAULT) is a plain MCU input; no hardware path is needed (§7). | Closed (design) |
| A3 | Stream guard mutes valid FS 20 Hz | New rule §9: no trigger for any FS sine ≥ 20 Hz × (1 − 100 ppm), any phase, onset included (worst 0.159 FS vs 0.30 FS threshold) and none for a FS 20 Hz square wave (0.250 FS) [CALC p07]. Balanced digital DC energy recomputed with the switch (§9). | Closed (design); unit tests listed |
| B2 | Start-up negative-DC check without ADC bias | The switch is open during every start-up; the CM window holds the permit off while 3V3A is absent (CMTH_LO ≥ 70 mV vs CM ≈ 0 V) [CALC p04]; firmware closes the switch only after the pre-close checks (§8.3) with a valid, settled network. | Closed (design) |
| B3 | MCLK not stopped in the fault shutdown | Fault policy opens the switch first (≤ 1.01 ms), then clears MCLK_EN (§10). Hardware: MCLK_EN low opens the switch (**⟶ R2/D-19: any N2_MCLK_OE low — MCLK_EN, AVCC_EN or MCLK_PERMIT**). The VCCA/XI back-power question when the MCU is unavailable belongs to the power/digital streams (interface request §12). | Closed for the headphones; interface item |
| B5 | Tier deadlines ignore measurement error | Every tier now has a measured threshold, a guaranteed physical trip level (error, gain error, 99 % settling included), a deadline at the slow network corner, initialised windows and a no-trip level above the offset spec (§8). | Closed (design); boundary tests §8.5 |
| B8 | Comparator inputs below V− at shutdown | R649–R652 100 kΩ between each filter node and the comparator inputs: clamp current ≤ 45 µA vs 10 mA abs max (TLV1704 [DS]) [CALC p03]. | Closed (design) |
| C1 | 0.2 s start-up gap for negative legs | Blanking deleted. The switch is open during start-up; the permit is valid as soon as VPOS − VNEG ≥ 2.2 V. | Closed (architecture) |
| C3 | Balanced ±x from hardware faults, 32.8 mJ at 16 Ω | CM window: failed I/V (stuck high or low) ≤ 8.0 mJ at 32 Ω and ≤ 12.7 mJ at 16 Ω even with worst opposing content; stuck DAC pin ≥ 1.07 V/leg at silence ≤ 2.87 ms; below that, leg windows + firmware ≤ 13.3 / 26.5 mJ (32 / 16 Ω) [CALC p04, p06]. | Closed (design) |
| C4 | RAILS_OK_N reads "good" with 5V_ANA off | Not used in hardware. Firmware rule: rails good = RAILS_OK_N low **and** ANA_EN high for ≥ 20 ms (§10). | Closed (firmware rule) |
| D1 | Power-down with frozen DAC → DC step | The switch opens before any power-down step; nothing reaches the headphones (§10.2). | Closed (architecture) |
| D2 | Comparator current flows V+→V− | TLV1704: I+ ≤ 1.26 mA, I− ≤ 1.25 mA total incl. dividers [DS/CALC] (LM339 ×2 was 4 mA); handed to the analog/power budgets (§12). | Answered |
| D3 | RAILS_OK_N / blanking at resume | Blanking deleted; resume = normal power-up with the switch open. | Closed |
| C2, D5 | DAC reset state saturates the I/V | Harmless for the headphones (switch open, CM window keeps it open in reset). DAC-pin safety stays with the analog stream. | Closed for this stream |

---

## 2. Top-down: requirements affected by this block and how they are met

| Requirement (brief §4) | Result | Margin | Source |
|---|---|---|---|
| DC ≥ 2 V on any leg removed within 100 ms (hardware) | ≤ 46.1 ms worst case **⟶ R2: 46.9 ms** | 53 % | [CALC p03] |
| DC ≥ 1 V removed within 250 ms (hardware) | ≤ 100.6 ms **⟶ R2: 101.3 ms** | 59 % | [CALC p03] |
| Rail-stuck, High mode, either polarity: ≤ 30 mJ at 16 Ω, ≤ 15 mJ at 32 Ω | 22.8 mJ / 11.4 mJ (SE); 14.5 / 11.4 mJ (balanced, one leg stuck) **⟶ R2: 23.6 / 11.8; 14.9 / 11.8 mJ** | 22 % | [CALC p03] |
| Balanced ±x failure (current-limited) ≤ 30 / 15 mJ | failed I/V: 12.7 / 8.0 mJ; stuck DAC pin: 26.5 / 13.3 mJ **⟶ R2: 12.4 / 7.4; 24.9 / 12.4 mJ** | ≥ 17 % | [CALC p04, p06] |
| Firmware: any DC ≥ 0.2 V across a driver removed within 3 s; every sub-hardware-trip case ≤ 30 / 15 mJ | removal ≤ 2.25 s; worst sub-trip case 14.5 / 7.2 mJ | 25 % (time), 52 % (energy) | [CALC p06] |
| Residual < 0.2 V accepted (owner) | never removed: < 0.166 V (leg) / < 0.180 V (pair) | — | [CALC p06] |
| No false trip for full-scale content ≥ 20 Hz; state the corner | hardware: sine corner **12.0 Hz** worst case (10.1 Hz nominal), full-scale square wave corner 19.6 Hz; firmware tiers: no tier can trip on FS content ≥ 20 Hz with every error included (never-trip levels above the offset spec, §8.2); stream guard 47 % margin | 40 % below 20 Hz | [CALC p03, p06, p07] |
| Output impedance ≤ 0.5 Ω incl. contacts | switch adds ≤ 0.108 Ω (3.5 mm) / ≤ 0.216 Ω (4.4 mm) at 60 °C **⟶ R2 (TLP3545A): 0.081 / 0.162 Ω** | 0.34 Ω left (R2) | [DS ×1.35 ASSUMP, p01] |
| Pop ≤ 5 mV (controlled transitions) | switch closes only with the DAC muted and the legs settled (only the DC-offset step, excluded by definition); opens before every power-down step; open-switch coupling of a 35 mV leg step ≤ 0.19 mV at 300 Ω | — | [CALC p01] |
| USB: ≤ 100 mA unconfigured, suspend ≤ 2.5 mA | switch drive 0 mA unless RELAY_EN high; comparators and networks are on switched rails (0 in suspend) | — | [CALC p05] |
| USB Default ≤ 500 mA | switch drive ≤ 15.3 mA (placeholder was ≤ 30 mA) **⟶ R2: ≤ 13.6 mA** | 16 mA freed | [CALC p05] |
| Thermal 50 °C, parts within ratings | stress table §11 | — | |

---

## 3. Output switch

### 3.1 L+/R+-only contacts — disproved [CALC p02]
Model: every leg an independent source at −4.014 / 0 / +4.014 V (81 combinations, covers rail-stuck, balanced ±x and opposite-sign faults by linearity), drivers 16 Ω, adapter shorts 0.01 Ω, open switch 60 MΩ (1 µA at 60 V [DS]), jack ESD bidirectional (1 GΩ at ≤ 4.1 V) or, as a what-if, unidirectional (conducting).
Plugs: J701 none / balanced / 4.4→3.5 adapter with L−, R−, GND commoned / adapter with sleeve to GND only / adapter with sleeve to L−,R− only; J702 none / TRS / TRRS CTIA / TRRS OMTP / half-inserted plug shorting T–R1.

| Architecture | Isolated (switch open), bidirectional jack ESD | unidirectional ESD |
|---|---|---|
| A1: L+/R+ only (brief) | **12/24** — fails whenever J702 has a plug and the J701 plug uses L−/R− (balanced + TRS: 2.0 V across the balanced L driver; balanced + half-inserted TRS: 3.99 V; commoned-return adapter + TRS: 0.31 V) | 9/24 (even a single balanced headphone fails: 3.4 V) |
| A2: all four legs switched (**chosen**) | **24/24** (worst 2 µV) | 24/24 |
| A3: L+/R+ per jack (4 switches, L−/R− hard-wired) | 24/24 | 9/24 |

A2 is chosen over A3: same part count, independent of the ESD part type, net names as in the brief (JACK_LP/LN/RP/RN), and the adapter short on L−/R− is disconnected while open. Conditions of the proof (interface items §12): D701–D704 on the JACK_xx side and bidirectional (the parts list says LESD5D5.0CT1G bidirectional, VRWM 5 V — also needed because the legs swing ±3.8 V); no jack switch contact connected; PhotoMOS pin 5 unconnected; no other DC path from JACK_xx (all sense networks are on LEG_xx).

### 3.2 Technology choice [CALC p01]
Coil corners: coil voltage 4.29 V (5V_SYS 4.30 V [BRIEF] − 10 mV driver), local ambient 60 °C (50 °C + 10 K [ASSUMP]), operate voltage × (1 + 0.393 %/K) (copper; datasheets state pick-up at 23 °C and that it varies with temperature), coil current at 5.5 V with R −10 % at 0 °C, self-heating 250 K/W [ASSUMP].

| Candidate (datasheet coil data) | I at 5.5 V/0 °C | 2 relays | Operates at 4.29 V up to | Hot re-operate |
|---|---|---|---|---|
| Omron G6K-2F-Y 5 V (237 Ω, 80 %) | 28.3 mA | 56.7 mA | 41 °C coil | fail |
| Omron G6K-2F-Y 4.5 V / TE IM12 (194 Ω, 80 %) | 34.6 mA | 69.3 mA | 72 °C | fail (79 °C) |
| TE IM02 4.5 V (145 Ω, 75 %, 140 mW) | 46.3 mA | 92.7 mA | 92 °C | OK |
| TE IM22 4.5 V ultra-sensitive (50 mW, 100 %) | 16.6 mA | 33.2 mA | 11 °C | fail |
| Panasonic TQ2SA-5V (178 Ω, 75 %) | 37.7 mA | 75.5 mA | 60 °C | fail |
| **AQV251GAX ×4** | LED strings 10.5–14.3 mA + 1.0 mA base drive | — | no operate corner (IF ≥ 5 mA down to 5V_SYS ≈ 3.9 V) | — |

Release: TE IM 3 ms max without / 5 ms max with a diode [DS]; Omron G6K 3 ms max (no suppression stated) [DS]; AQV251G Toff ≤ 0.5 ms at 25 °C, IF 5 mA [DS] (design value 1.0 ms over temperature [ASSUMP: ×2]).

### 3.3 AQV251GAX facts [DS, Panasonic HE DIP6 1 Form A catalog / AQV251GAX product page]
> **⟶ R2:** superseded by R2.2 (TLP3545A(TP1,F)); the AQV251GA(X) is now only the conditional second source. The distortion/coupling figures below are replaced by R2.5.
30 V load voltage, 3.5 A continuous, Ron (A connection 4–6) 0.035 typ / 0.08 Ω max at IF = 5 mA, 25 °C; LED operate current ≤ 3.0 mA, turn-off current ≥ 0.2 mA, VF 1.14 typ / 1.5 V max (5 mA); off-state leakage ≤ 1 µA; Ton ≤ 5.0 ms; Toff ≤ 0.5 ms; recommended IF 5–30 mA; IF abs max 50 mA, VR 5 V; −40…+85 °C; SMD-6 (DIP6 gull wing, body 8.8 × 6.4 mm). Pins: 1 LED anode, 2 LED cathode, 3 NC, 4/6 output (A connection), 5 output common (B/C only → **leave unconnected**). Same-footprint drop-in: AQV252GAX (60 V, 0.12 Ω) [DS].
Ron over temperature: ×1.35 at 60 °C [ASSUMP; datasheet curve is typical only] → 0.108 Ω per switch.
Distortion (first-order bounds, [CALC p01] on [ASSUMP] gate overdrive ≥ 3 V, Ron tempco 1 %/K, |Zth(2f)| ≤ 250 K/W — none of these is in the datasheet): the A connection is two MOSFETs in anti-series, so even orders cancel; channel HD3 ≤ −166 dB everywhere. Self-heating (Ron modulated at 2f) is the larger term: ≤ −159 dB at 300 Ω balanced (the THD+N requirement point, −105 dB), ≤ −119 dB at 32 Ω SE, ≤ −117 dB at 60 Ω balanced, and ≤ −101 dB at 32 Ω balanced full scale near 20 Hz (not a rated condition; the DC Rth bound is very conservative at 40 Hz). A relay contact would be distortion-free; this is the price of the PhotoMOS and is handed to the analog THD budget with a bring-up comparison against a bypass (§12).
Open-switch coupling (Coff ≈ 450 pF [DS-typ, Fig. 12]): a 35 mV/1 µs leg step gives ≤ 0.19 mV at 300 Ω; only a multi-volt µs step would matter (≈ 19 mV at 300 Ω) — the analog sequence must not step the legs by volts in µs while the switch is open (§12).

### 3.4 Drive, permit and readback (schematic in words) [CALC p05]
> **⟶ R2:** superseded by R2.3/R2.4 — the MMBT3904 limiter (Q613/Q615 deleted) is replaced by the U604 op-amp sink; R641/R642 24.9 Ω; R647 100 k; C617 1 µF; all currents and times below are round-1 values.
- String L: 5V_SYS → K601 LED → K602 LED → Q612 (MMBT3904 pass) → R641 100 Ω → N6_EM; Q613 senses R641 (current ≈ VBE/R641); RELAY_EN → R643 4.7 kΩ → Q612 base. String R: K603, K604, Q614, Q615, R642, R644.
- N6_EM → **Q616** AO3400A (gate MCLK_EN via R645 1 kΩ) → N6_M2 → **Q617** AO3400A (gate N6_H) → GND.
- N6_H: R647 470 kΩ to VPOS, C617 220 nF to GND, 12 TLV1704 open-collector outputs. Readback **Q618** 2N7002 (gate N6_H) pulls **DC_PERMIT_N** low (R648 100 kΩ to 3V3M) when permitted. RELAY_EN pull-down R646 100 kΩ.
- LED current 5.24–7.14 mA per string over 0–60 °C (VBE model from the MMBT3904 SPICE IS with ±2× process [ASSUMP]; hFE ≥ 100 [DS]); Q612 VCE ≥ 0.49 V at 5V_SYS 4.30 V with VF 1.55 V (regulating); Q612 ≤ 21 mW; R641 ≤ 5.1 mW.
- H high ≥ 3.30 V (leakage ≤ 1.04 µA: 12 × 70 nA TLV1704 + 100 nA + 100 nA × 470 kΩ) → Q617 VGS ≥ 3.30 V (RDS(on) ≤ 48 mΩ at 2.5 V [DS]); Q618 VGS ≥ 3.30 V > VGS(th) max 2.5 V.
- Trip: one comparator sinks ≥ 4 mA [DS test condition] → H below 0.45 V (0.2 V under the lowest VGS(th), drain current ≪ the 0.2 mA LED turn-off current) in ≤ 0.22 ms → switch open ≤ **1.22 ms** after the comparator trips (0.72 ms with the 25 °C Toff).
- RELAY_EN low or MCLK_EN low → switch open ≤ 1.01 ms. Turn-on ≤ 5 ms after the last condition is met [DS].
- Minimum off-time after a trip clears: 52–155 ms (R647·C617 recovery from H ≈ VNEG; C617 −15 % × 0.75 DC-bias factor [ASSUMP] … +10 %) — prevents chatter; no latch. Rails-up to permit: 12–67 ms. (DC bias only lowers C617, so the 0.22 ms fall-time bound, computed with +10 %, stays conservative.)
- Readback thresholds (Q618 1.0–2.5 V vs Q617 0.65–1.45 V): the MCU always sees the conservative state (reports "not permitted" first on a trip, "permitted" last on recovery).
- Supply: 5V_SYS 10.5–14.3 mA and 3V3M ≤ 1.02 mA only while RELAY_EN is high; 0 mA before configuration, in suspend and whenever RELAY_EN is low.

---

## 4. Hardware DC detector (leg windows)

### 4.1 Comparator: TI TLV1704AIPWR [DS, TI SBOS589D, tables 7.1–7.6]
Supply 2.2–36 V; VOS ±3.5 mV (25 °C, 2.2 V), ±5.5 mV (−40…125 °C); IB 5 typ / 15 max nA (25 °C), 20 nA max (−40…125 °C); common-mode range V− to V+ over temperature; IQ 55 typ / 75 max µA/ch (25 °C), 100 µA/ch max (−40…125 °C); inputs diode-clamped to both rails, (V−) − 0.5 V … (V+) + 0.5 V, ±10 mA; open collector usable up to 36 V above V−; short-circuit sink 20 mA; ESD 1 kV HBM (TLV1704), 1.5 kV CDM; TSSOP-14, LM339-compatible pinout (1 2OUT, 2 1OUT, 3 V+, 4 1IN−, 5 1IN+, 6 2IN−, 7 2IN+, 8 3IN−, 9 3IN+, 10 4IN−, 11 4IN+, 12 V−, 13 4OUT, 14 3OUT). LCSC C181596, 61 pcs in stock (24 Sep 2026).
Why not LM339B [DS, TI SLCS006Z table 6.7]: VOS ±5.5 mV and IB ≤ 50 nA over temperature are fine, but its common mode ends at (V+) − 2.0 V (1.79 V at the minimum rail) — the CM window thresholds (≈ 1.2–2.2 V) would need attenuators — and IQ is ≤ 1.6 mA per package over temperature (36 V spec) vs 0.4 mA. Both behave correctly with one input beyond the range (LM339B note 1; TLV1704 has no upper limit). The TLV1704's 1 kV HBM rating is adequate: its inputs are behind ≥ 100 kΩ and never reach a connector.

### 4.2 Thresholds (single E96 resistors, 0.1 %, 25 ppm) [CALC p03]
VTH+ = VPOS × R609/(R607 + R609) = VPOS × 10.0 k/(121 k + 10.0 k) = +0.298 V nominal; VTH− = VNEG × R610/(R608 + R610) = VNEG × 10.0 k/(115 k + 10.0 k) = −0.298 V nominal.
Worst-case trip at the leg (rails 3.789–4.014 / 3.618–3.828 V, divider 0.1 % + 25 ppm × 40 K, VOS 5.5 mV, IB 20 nA through R601 + R649 and the dividers): **+0.276…+0.320 V and −0.276…−0.320 V**. The windows follow the rails (a sagging rail lowers the trip level).

### 4.3 Filter (single pole) [CALC p03, p03b]
Leg → R601–R604 105 kΩ 1 % (100 ppm) → node N6_Fxx with C601–C604 2.2 µF X5R 16 V → R649–R652 100 kΩ → both comparator inputs. τ = 231 ms nominal, 194 ms (fast: R −1.4 %, C −15 %) … 258 ms (slow: R +1.4 %, C +10 %) [BRIEF −15/+10 %].
Design rule (p03b): the smallest τ for which a **full-scale square wave at 20 Hz** (the largest possible RC response of any bounded waveform with 25 ms half period) never reaches the lowest trip level at the fastest corner. Comparison: the unbuffered 2-pole ladders tested (30/30 … 68/33 ms) are slower for the same corner (e.g. 2-pole 30/30 ms: rail-stuck 26.7 mJ vs 1-pole 18.9 mJ at a similar corner) → single pole.
Scan (p03b) — same content rejection, different threshold: 0.55 V/113 ms gives moderate balanced ±x up to 57.8 mJ at 16 Ω near its threshold, 0.30 V/231 ms gives 35.4 mJ there (and firmware covers the band); lower than 0.25 V makes the near-threshold band unbounded for the hardware. 0.30 V chosen.

### 4.4 Worst-case removal times and energies [CALC p03]
> **⟶ R2:** updated tables in R2.6 (H fall 0.98 ms instead of 0.22 ms).
| DC on a leg | nominal | worst case | requirement |
|---|---|---|---|
| 0.5 V | 209 ms | 264 ms | — |
| 1.0 V | 82 ms | **100.6 ms** | 250 ms |
| 2.0 V | 38 ms | **46.1 ms** | 100 ms |
| 2.19 V (full-scale digital DC) | 34 ms | 41.9 ms | — |
| rail-stuck +3.789 / +4.014 V | 19.3 / 18.2 ms | 23.9 / 22.6 ms | — |
| rail-stuck −3.618 / −3.828 V | 20.2 / 19.1 ms | 25.1 / 23.7 ms | — |

Energy (switch removes the DC, nothing flows afterwards; the old 0.6 mJ after-trip term disappears):

| Case | 16 Ω | 32 Ω | 60 Ω | 300 Ω |
|---|---|---|---|---|
| Rail-stuck output, leg to GND (SE), High mode, worst polarity/rail | **22.8 mJ** (limit 30) | **11.4 mJ** (limit 15) | 6.1 mJ | 1.2 mJ |
| Rail-stuck, balanced (other leg healthy, current-bounded 190 mA) | 14.5 mJ | 11.4 mJ | — | — |
| Balanced ±x from failed I/V / stuck pin — CM window, §5 | 12.7 mJ | 8.0 mJ | — | — |
| Moderate stuck-pin ±x at silence (leg windows + CM + FW) | 26.5 mJ | 13.3 mJ | — | — |
| Opposite-sign sub-threshold legs (≤ 0.64 V across) — firmware T2 | 14.5 mJ | 7.2 mJ | — | — |
| **Residual**: frozen DAC code with MCLK_EN still high (X201 stops) — leg windows only (**⟶ R2: 36.2 / 23.7 / 14.9 / 3.1 mJ; with D-19 only an X201 failing while enabled remains**) | 35.8 mJ | 23.3 mJ | 14.6 mJ | 3.0 mJ |

Load-current bound used for balanced cases: OPA1622 short-circuit current is typical only (+145/−130 mA at 25 °C [DS-typ SBOS727B 6.5, Fig. 37]); bound 190 mA [ASSUMP: 1.3 × typ]; swing bound (|rail| − 0.8 V)/(1 + 8 Ω/R) [DS-typ].
The frozen-code residual is the one case that exceeds the Section-4 energies: it is a hardware fault whose output is indistinguishable from full-scale content for ≥ 25 ms. The practical causes are covered: CPLD/firmware MCLK stop → MCLK_EN gate (≤ 1.01 ms; **⟶ R2/D-19: every commanded stop via N2_MCLK_OE, ≤ 1.002 ms**); DVCC/3V3D brown-out → DAC reset state → CM window. What remains is an oscillator stopping while enabled; with the typical OPA1622 current limit the 16 Ω figure is ≈ 28 mJ (inside 30 mJ). Stated as a residual risk, not as compliance.

### 4.5 False trips [CALC p03]
Full-scale sine 2.228 V pk (2.19 V × +0.15 dB calibration + trim tolerance), worst start phase, onset from rest, fastest components, lowest trip level: **no trip above 12.0 Hz** (10.1 Hz nominal); 20 Hz margin 38 %. Full-scale square wave: no trip above 19.6 Hz. Only if the −4.5 dB pre-calibration safety were lost (untrimmed 3.66 V) would a full-scale sine below 20.5 Hz trip — a protective mute, not a hazard.
Capacitor sensitivity [CALC p03, ASSUMP what-if]: the corners use the brief's −15 % for C601–C604 (DC bias ≤ 0.32 V until the trip, negligible). The X5R low-AC-level effect (node ripple ≈ 0.15 Vrms vs the 1 Vrms test level) is not covered by the datasheet: at −20 % / −25 % the sine corner moves to 12.7 / 13.6 Hz (requirement still met with ≥ 32 % frequency margin) and the full-scale *square-wave* corner to 20.8 / 22.2 Hz (a full-scale 20 Hz square wave never trips while C ≥ −16.9 %); below that it could cause a protective mute on a worst-case unit (no hazard). Raising R601–R604 would cost stuck-pin envelope margin (§8.4), so the values stay; bring-up measures τ (step response) and sweeps a full-scale square wave 15–25 Hz (§8.5).

### 4.6 Rail ramp-up, collapse, unplug, deep short
- Ramp-up: comparator outputs undefined below VPOS − VNEG = 2.2 V; H follows VPOS through R647 (12–67 ms); the switch stays open because RELAY_EN is low until the pre-close checks pass (§8.3). The CM windows keep H low until 3V3A is up, RESETB is high and the ESS soft start is complete.
- Controlled power-down: RELAY_EN low first (switch open ≤ 1.01 ms; **⟶ R2: 1.008 ms**), then any order. Charged filter capacitors discharge through R601–R604 into the legs and through R649–R652 into the input clamps (≤ 45 µA).
- Unplug: 5V_SYS falls → the LED strings drop out below ≈ 3.9–4.1 V → switch opens ≤ 0.5–1 ms later (**⟶ R2: regulation lost ≤ 4.17 V, guaranteed off ≤ 1.99 V; open ≤ 1.19 ms firmware path / 1.31 ms hardware after VBUS loss, R2.4**); the unplug pop stays the analog stream's measured target (the rails collapse in tens of µs).
- Deep short on 5V_ANA: the rails collapse; while VPOS − VNEG ≥ 2.2 V the windows work (thresholds scale down, the CM window trips because the I/V outputs cannot hold VREF); below that the LM27762 is in UVLO (2.4 V falling [DS SNVSAF7C, via Notes R5]) and the rails go to 0, so H = VPOS → 0 and Q617 turns off below 0.45 V. In the short interval with |rail| < 1.1 V a leg can carry at most 1.1 V (≤ 76 mW into 16 Ω) and firmware reacts to PGOOD/FAULT in ≤ 1 ms.

---

## 5. I/V common-mode window (new, U603) [CALC p04]
Per channel: IV_xP (DAC+ I/V output) and IV_xN (DAC− I/V output) → 2 × 100 kΩ 0.1 % → N6_CMx with 10 nF (τ 0.5–0.55 ms) → comparator vs CMTH_HI and CMTH_LO. Threshold chain from 3V3A (ratiometric to VREF): R657 10.0 k / R658 6.8 k / R659 10.0 k (0.1 %) plus R660 330 k from VPOS into CMTH_LO → HI 2.098 V, LO 1.281 V nominal at 3V3A = 3.3 V; worst CM > 2.151 V or < 1.245 V trips.
Normal CM range at 3.3 V: 1.427–1.928 V (**⟶ R2: 1.512–1.816 V with the analog round-2 values, margins 264 / 210 mV, R2.7a**), covering both VREF options (0.500/0.516 × 3V3A), the DAC centre (1.65 V voltage model or 1.702 V current model [DS p.31]), Rs ±11 % [DS] and a content ripple for a **22 % pin-to-pin mismatch** (the full ±11 % band, because ESS gives no matching figure) — no false trip, margin ≥ 129 mV at every corner [CALC].
Coverage:
- I/V output stuck high (V+ − 0.6 … V+ − 0.2 V) or low: trips at silence in ≤ 2.87 ms (**⟶ R2: 3.63 ms; energies ≤ 7.4 / 12.4 mJ**) (3 τ_CM 1.65 ms + H fall 0.22 ms + PhotoMOS 1.0 ms); worst-phase opposing 20 Hz full-scale content on the healthy I/V output can delay the trip ≤ 19.2 ms (removal ≤ 22.1 ms) → ≤ 8.0 mJ at 32 Ω, ≤ 12.7 mJ at 16 Ω (DC energy, legs bounded by swing/current).
- One DAC pin stuck: trips at silence for leg DC ≥ 1.07 V (**⟶ R2: ≥ 0.98 V**) (≤ 2.87 ms; ≤ 27.9 ms with worst content, energies inside the same ≤ 8.0 / 12.7 mJ bound); below 1.07 V the leg windows and firmware cover it (§8.4).
- DAC in reset (both pins at GND, I/V ≥ 3.3 V): trips → no permit while RESETB is low or during the ESS soft start. (**⟶ R2: CM ≥ 2.907 V; release at 65–76 % of the 104.9 ms ramp, R2.7**)
- 3V3A absent: CMTH_LO ≥ 70 mV vs CM ≈ 0 V → trips → the switch can never close while the DC-sense network is unbiased (B2 / §7.2-3 requirement). 3V3A present but out of range is checked by firmware (V3A_MON window).
Load on the I/V outputs: 100 kΩ each, ≤ 14 µA cross-current (negligible).

---

## 6. DC-sense ADC networks and the reference network [CALC p06]
LEG_xx → R624–R627 6.8 kΩ (R_S) → DC_SENSE_xx; → R628–R631 5.1 kΩ (R_U) to 3V3A; → R632–R635 16.9 kΩ (R_D) to GND; C608–C611 4.7 µF 25 V X5R 0805. Reference: R661 6.8 k to GND, R639 5.1 k to 3V3A, R640 16.9 k to GND, C616 4.7 µF → **V3A_MON = a·3V3A** (a = 0.4874). node = a·3V3A + g·leg, g = 0.3655, R_TH = 2.49 kΩ, τ 8.4–12.9 ms (C −15 %/+10 % [BRIEF] × 0.85 DC bias/AC level at the 0.8–2.4 V node [ASSUMP]; a 25 V 0805 part was chosen over the 16 V 0603 because the bias loss enters the alias term). Power-up: leg-vs-reference settling below 1 mV at the leg 108 ms after 3V3A is up [CALC] → readings valid only after V3A_MON has been in its window for ≥ 150 ms. Node 0.18–3.11 V for legs −3.828…+4.014 V at 3V3A ±2 % (no clipping, no pin injection). 3V3A load 1.69 mA (5 networks). All networks on the **amplifier side** of the switch (valid with the switch open; pre-close check).
Reading = (code_leg − code_ref)/g: ADC offset, 3V3A value and its drift cancel; V3A_MON also gives 3V3A for the validity check.

Error budget per leg reading (worst-case linear sum; ADC facts CH32V307 datasheet V3.5 tables 4-42/4-43 [DS]: EL ±4 LSB max at RAIN < 10 kΩ, ED ±3 LSB, EO ±4 LSB):

| Term | mV at the leg |
|---|---|
| pin leakage, 2 pins × 1 µA [ASSUMP] × R_TH / g | 13.6 |
| ADC INL difference, 2 × EL (8 LSB) / g | 18.0 |
| quantisation, 2 × 0.5 LSB / g | 2.2 |
| resistor drift, 2 networks, 25 ppm/K × 25 K since factory calibration | 11.2 |
| factory calibration (DMM + ADC noise) | 1.0 |
| aliasing of content at k × 10 kHz (network attenuation, τ min) | 4.2 |
| **e_leg** | **50.2** |
| **e_pair** (L+ − L−; reference cancels, second leg's alias/cal added) | **55.4** |
| gain error of the reading (VDDA 3V3M ±2 %, ratio 0.2 %, ADC gain 0.3 % [ASSUMP]) | 2.5 % of reading |

Sampling (**⟶ R2: 13.5 cycles at 12 MHz, timer-triggered 20 kHz 8-conversion scan, R2.8**): ADC2 scans the five channels continuously, ≥ 10 kHz per channel, ≥ 28.5 cycles at 14 MHz (RAIN 25.2 kΩ allowed [DS table 4-42] vs 2.49 kΩ); readings used only while V3A_MON is inside 1.526–1.691 V (3V3A 3.13–3.47 V) and has been for ≥ 150 ms.

---

## 7. Hardware vs firmware split — PGOOD and TPS2553 FAULT need no hardware path
- DC across a headphone can only come from a leg; every leg is watched by a window that acts in hardware, and every failure that makes the I/V pair asymmetric is watched by the CM window.
- An overload (TPS2553 current limit) is not DC: the rails sag, the windows keep working with lower thresholds, and the headphone sees clipped audio. PGOOD (RAILS_OK_N) and FAULT (ANA_FAULT_N) go to the MCU, which opens the switch (≤ 1 ms) and runs the overload policy.
- A deep short collapses 5V_ANA → LM27762 UVLO → rails → 0 → H → 0 → switch open (§4.6).
- Hung MCU: IWDG (≤ 100 ms timeout, request §12) resets the MCU → RELAY_EN floats → R646 → switch open; the hardware permit protects in the meantime.

---

## 8. Firmware tiers [CALC p06]
### 8.1 Estimator
Per leg and per pair difference (L+ − L−, R+ − R−): CIC² (two cascaded running means of W) of the 10 kHz readings, evaluated every 1 ms, windows initialised with the first valid reading when the tiers are armed (a fault present at arming trips on the first evaluation). Action: RELAY_EN low (switch open ≤ 1.01 ms), log, DC-fault class. Tiers are armed whenever RELAY_EN may be high.

### 8.2 Tiers
> **⟶ R2:** numbers updated in R2.6 (e_leg 51.0 mV: T1 0.985/0.991 V, T2 0.301/0.297 V, T3 0.167/0.181 V; deadlines unchanged).
| Tier | W | Measured threshold leg / pair | Guaranteed physical trip leg / pair | Deadline | Never trips below (leg / pair) | FS content ≥ 20 Hz (leg / pair) |
|---|---|---|---|---|---|---|
| T1 | 100 ms | 0.900 / 0.900 V | 0.984 / 0.990 V | 208 ms | 654 / 475 mV | 174 / 348 mV |
| T2 | 300 ms | 0.240 / 0.230 V | 0.301 / 0.296 V | 574 ms | 125 / 52 mV | 59 / 118 mV |
| T3 | 1.2 s | 0.110 / 0.118 V | 0.166 / 0.180 V | 2.25 s | 42 / 30 mV | 15 / 30 mV |

Guaranteed level = (threshold + e)/((1 − 2.5 %) × 0.99) (99 % settled at the slow network corner). "Never trips below" = true DC that cannot trip after every error and worst content; it exceeds the offset spec (10 mV / 20 mV) for every tier. T1 is the firmware backup of the hardware windows; T2 covers the balanced band the windows cannot see (opposite-sign legs); T3 implements the owner's 0.2 V/3 s rule.

### 8.3 Pre-close checks (every RELAY_EN rising edge)
Rails good = RAILS_OK_N low AND ANA_EN high for ≥ 20 ms (R8-C4); ANA_FAULT_N high; V3A_MON inside 1.526–1.691 V for ≥ 150 ms (sense networks settled, §6); DC_PERMIT_N low ≥ 50 ms; ≥ 50 ms of valid readings with |each leg| ≤ 0.10 V and |each pair| ≤ 0.12 V; tiers armed and initialised; MCLK_EN set (CPLD register read back; **⟶ R2/D-19: and N2_MCLK_OE high on PB1**) and DAC initialised and soft-muted; no lock-out; volume ramp starts only after the switch has been on ≥ 5 ms (Ton max) (**⟶ R2: 10 ms; DC_PERMIT_N polled after the soft start, R2.7**).

### 8.4 Combined envelope (hardware + CM + firmware), DC energy at the driver, V = 0.2–4.0 V
> **⟶ R2:** SE 23.5 / 11.7 mJ, stuck pin 24.9 / 12.4 mJ (17 %), opposite-sign 14.5 / 7.2 mJ (R2.6).
| Case | 16 Ω | 32 Ω |
|---|---|---|
| SE / single leg | 22.7 mJ (24 %) | 11.3 mJ (24 %) |
| Balanced ±x, stuck DAC pin, silence | 26.5 mJ (12 %) | 13.3 mJ (12 %) |
| Balanced opposite-sign sub-threshold | 14.5 mJ (52 %) | 7.2 mJ (52 %) |
Slowest removal of any DC ≥ 0.2 V: 2.25 s (< 3 s). Residual never removed: < 0.166 V (leg) / < 0.180 V (pair) → ≤ 2.0 mW into 16 Ω (owner-accepted < 0.2 V).

### 8.5 Boundary tests (bring-up, stream guard bypassed; DC injected on LEG_xx with the amplifier link removed, or digital DC for pairs)
- T1: leg 1.004 V and pair 1.010 V, both signs → RELAY_EN low within 208 ms; leg 589 mV / pair 427 mV for 10 s → no trip.
- T2: leg 0.307 V and pair 0.302 V → within 574 ms; leg 113 mV / pair 46 mV → no trip.
- T3: leg 0.169 V and pair 0.183 V → within 2.25 s; leg 38 mV / pair 27 mV → no trip.
- Each tier: arm with the fault already present → trip on the first evaluation.
- Filter check: step response of each N6_Fxx node (τ within 194–258 ms); full-scale square wave swept 15–25 Hz and full-scale sine at 20 Hz on each leg at 0 °C and 50 °C → record the lowest non-tripping square-wave frequency (expected ≤ 19.6 Hz at the brief's capacitor corner).
- Hardware: DC 0.33 V, 1.0 V, 2.0 V, 3.8 V (both signs) on each leg → DC_PERMIT_N high and switch current 0 within 1.0 s / 101 ms / 46 ms / 25 ms; 0.27 V for 10 s → no trip; full-scale 20 Hz sine and square at the leg → no trip; CM: short one I/V output to V+ through 100 Ω / to V− → trip < 3 ms; lift one DAC-pin resistor → trip; 3V3A off with rails on → DC_PERMIT_N high; MCLK_EN low → switch opens < 1.1 ms (**⟶ R2/D-19: repeat with AVCC_EN low and with MCLK_PERMIT low / MCU reset**).

---

## 9. Stream DC guard (firmware, R8-A3) [CALC p07]
Per channel on the decoded samples before the SPI link, all rates and word lengths normalised to FS: (a) D = CIC² of two running means of N = fs/20 samples (exactly 50 ms at every rate: 2205 … 19200 samples), trigger |D| ≥ 0.30 FS; (b) flat path: every sample of the last 26 ms within a range ≤ 1·10⁻³ FS and |mean| ≥ 0.02 FS. Trigger → zero the channel pair with a 1 ms ramp, log; release after |D| < 0.05 FS for 1 s. No latch, no RELAY_EN action. 64-bit integer running sums (no drift).
No false trigger: worst FS sine ≥ 20 Hz × (1 − 100 ppm), 24 phases, onset: 0.159 FS (47 % margin); FS 20 Hz square: 0.250 FS (a square or clipped wave ≥ 20 Hz changes sign within 25 ms, so the 26 ms flat rule cannot fire).
Detection and DC energy at the jack with the switch closed (FIFO latency delays the DC and the zeroing equally; + ≤ 1 ms DAC filter delay [ASSUMP]):

| Digital DC | detect | 32 Ω bal. | 16 Ω bal. | 32 Ω SE | 16 Ω SE |
|---|---|---|---|---|---|
| pure DC (flat), 1 FS | 26 ms | 15.5 mJ | 15.6 mJ | 4.0 mJ | 7.7 mJ |
| 1.0 FS with content | 38.7 ms | 22.8 mJ | 22.9 mJ | 6.0 mJ | 11.4 mJ |
| 0.8 FS with content | 43.3 ms | 17.0 mJ | **25.6 mJ** (worst, current-limited) | 4.2 mJ | 8.5 mJ |
| 0.6 FS with content | 50.0 ms | 11.0 mJ | 22.0 mJ | 2.8 mJ | 5.5 mJ |
| 0.5 FS with content | 55.2 ms | 8.4 mJ | 16.9 mJ | 2.1 mJ | 4.2 mJ |
| 0.31 FS with content | 87.3 ms | 5.1 mJ | 10.2 mJ | 1.3 mJ | 2.5 mJ |

Below 0.30 FS the hardware windows (≥ 0.32 V) and T2 act. At 16 Ω every digital-DC level stays ≤ 25.6 mJ (< 30 mJ) and every SE case ≤ 11.4 mJ. Full-scale digital DC into 32 Ω balanced is 15.5–22.8 mJ: physics, not rule quality — full-scale DC equals a full-scale 20 Hz square wave for 25 ms. It is content, not a hardware failure, and is reported, not claimed compliant with the 15 mJ hardware figure.

---

## 10. Fault policy
### 10.1 Hardware (works without firmware)
Permit H off when: any leg window (≥ 0.28–0.32 V filtered DC), any CM window (failed I/V, stuck DAC pin, DAC reset/soft start, 3V3A absent), rails below the comparator supply. Q616 off when MCLK_EN is low (**⟶ R2/D-19: when N2_MCLK_OE is low, i.e. MCLK_EN, AVCC_EN or MCLK_PERMIT low**). Switch open ≤ 1.22 ms after the condition; automatic re-close only after the condition has cleared and 52–155 ms have passed, and only if RELAY_EN is still high. (**⟶ R2: ≤ 1.98 ms via H, ≤ 1.01 ms via RELAY_EN/MCLK_EN; re-close after 53–135 ms**)
### 10.2 Firmware
| Event | Action | Class / recovery |
|---|---|---|
| DC_PERMIT_N rising (EXTI, highest priority) | RELAY_EN low ≤ 50 µs; freeze the last 0.5 s of the six readings; soft mute | DC if a leg/pair reading ≥ T2 level, else "CM/clock" (I/V, DAC, MCLK, 3V3A) |
| Tier T1–T3 trip | RELAY_EN low; log | DC |
| RAILS_OK_N high while ANA_EN high, or ANA_FAULT_N low (**⟶ R2.13a: dips < 25 ms with ANA_FAULT_N high = headroom event, no switch action**) | RELAY_EN low; controlled shutdown | Overload: ceiling −3 dB per event down to −12 dB; retry after ≥ 1 s; counts toward the 3-strike limit only at −12 dB |
| VBUS_SENSE below the brown-out level | RELAY_EN low first, then power-down | — |
| Stream guard | zero the stream; log | none (content) |
| Controlled power-down (suspend, host, fault) | t0: RELAY_EN low → ≥ 1.0 ms → MCLK_EN low, AVCC/rails/AUD in the order the power/analog streams require | — |
| DC or CM/clock class | retry after 2 s through the full pre-close checks; 3 within 10 s → locked until USB replug, red LED | — |
| Hung MCU | IWDG reset → RELAY_EN floats → R646 → open | — |
Suspend: RELAY_EN low at the suspend interrupt (3 ms) → switch open by 4.0 ms after the last bus activity; the rest of the timeline is the power stream's. (**⟶ R2 / D-16: SOF-loss rule, RELAY_EN low at 1.02 ms → switch open ≤ 2.03 ms after the last SOF, before the 1.1 ms wait ends and MCLK stops at 2.13 ms; suspend current at 2.76 ms [digital]**)

---

## 11. Component stress table (worst operating conditions, all power states)
> **⟶ R2:** rows for K601–K604, Q612–Q617, R641–R644, R647, C617 and the new U604/R662/R663/C622 are replaced by R2.11.
| Ref | Part | Stress | Rating [DS] | OK |
|---|---|---|---|---|
| U601–U603 | TLV1704AIPWR | VS ≤ 7.84 V; inputs within the rails (collapse: ≤ 45 µA clamp current); output ≤ 7.84 V above V−, sink into C617 ≤ short-circuit 20 mA (continuous allowed); P ≤ 9.4 mW | 36 V; ±10 mA; 36 V; continuous | yes |
| K601–K604 | AQV251GAX | off: ≤ 4.1 V steady (≤ ~16 V with the jack TVS clamping an ESD pulse [ASSUMP clamp ≤ 12 V]); on: ≤ 0.25 A (rail-stuck into 16 Ω), 6.8 mW; IF ≤ 7.14 mA; VR 0 V; 60 °C | 30 V; 3.5 A; 600 mW; 50 mA; 5 V; 85 °C | yes |
| Q612–Q615 | MMBT3904 | VCE ≤ 3.5 V, IC ≤ 7.14 mA, P ≤ 21 mW | 40 V, 200 mA, 200 mW | yes |
| Q616, Q617 | AO3400A | VDS ≤ 5.5 V, ID ≤ 14.3 mA, VGS −3.83…+4.01 V (Q617) | 30 V, 5.7 A, ±12 V | yes |
| Q618 | 2N7002 | VDS ≤ 3.37 V, VGS −3.83…+4.01 V | 60 V, ±20 V | yes |
| C601–C604 | 2.2 µF 16 V X5R 0603 | ≤ 4.01 V (filter node after a rail-stuck trip) | 16 V | yes |
| C608–C611, C616 | 4.7 µF 25 V X5R 0805 | ≤ 3.11 V (sense node) | 25 V | yes |
| C617 | 220 nF 16 V X7R | −3.83…+4.01 V | 16 V | yes |
| C612–C615, C618, C619 | 100 nF 16 V X7R | ≤ 4.01 V | 16 V | yes |
| R601–R604 | 105 k 0402 | ≤ 4.01 V, ≤ 0.15 mW | 50 V, 62.5 mW | yes |
| R624–R627 | 6.8 k 0402 | ≤ 3.9 V, ≤ 2.2 mW | 50 V, 62.5 mW | yes |
| R628–R631, R639 | 5.1 k 0402 | ≤ 3.2 V, ≤ 2.0 mW | 50 V, 62.5 mW | yes |
| R641, R642 | 100 Ω 0402 | 5.1 mW | 62.5 mW | yes |
| R647 | 470 k 0402 | ≤ 7.84 V, 0.13 mW | 50 V | yes |
| others | 0402 | < 1 mW, < 8 V | 50 V, 62.5 mW | yes |

---

## 12. Interface requests to the other streams
> **⟶ R2:** updated requests in R2.13 (supply currents, ADC settings, firmware constants, output impedance).
**Power stream**
1. Switch drive load: 5V_SYS 10.5–14.3 mA and 3V3M ≤ 1.02 mA **only while RELAY_EN is high**; 0 mA unconfigured and in suspend (replaces the ≤ 30 mA coil placeholder).
2. 3V3A load from block 6: **1.82 mA** (5 sense networks 1.69 mA + CM threshold chain 0.13 mA) instead of 0.87 mA.
3. Comparator rail currents (V+ → V− through the charge pump): **I+ ≤ 1.26 mA, I− ≤ 1.25 mA** max (−40…125 °C, all dividers, H pull-up with a trip); ≈ 0.7 mA typical.
4. The deep-short argument relies on the LM27762 UVLO taking both rails to 0 V below 2.4 V VIN — please confirm with your LM27762 facts.
5. Suspend: switch open ≤ 1.01 ms after RELAY_EN low; no other ordering constraint from this block.
6. RAIL_EN series resistor R507 and the TPS2553 FAULT link to the latch (R638/D606) are no longer needed by protection; FAULT → MCU input only (keep its pull-up). RAILS_OK_N → MCU only.

**Analog stream**
1. LEG_LP/LN/RP/RN are the OPA1622 outputs; if the 0 Ω links R417–R420 are kept, put them between the OPA1622 output and LEG_xx (removing a link then isolates the amplifier for the detector and failed-output tests).
2. JACK_LP/LN/RP/RN: all four jack legs are switched; D701–D704 sit on JACK_xx, must be **bidirectional**, VRWM ≥ 4.1 V; please state their clamp voltage (PhotoMOS rating 30 V).
3. Output impedance: + ≤ 0.108 Ω (3.5 mm) / + ≤ 0.216 Ω (4.4 mm) at 60 °C; L/R mismatch ≤ 0.08 Ω.
4. Name the OPA2210 outputs **N4_IVL_P, N4_IVL_N, N4_IVR_P, N4_IVR_N** (DACL, DACLB, DACR, DACRB I/V outputs); each gets 100 kΩ 0.1 % to the CM node (≤ 14 µA). Tell me if VREF/3V3A is not 0.500 or 0.516.
5. Comparator currents for the analog budget: see power item 3 (they replace the 2 × LM339 figures of R8-D2).
6. With 3V3A on and AMP_EN low the sense networks push ≤ 0.16 mA into a disabled OPA1622 output: sequence AMP_EN on before (or with) 3V3A, or accept it.
7. While the switch is open, avoid leg steps of volts in microseconds (≈ 19 mV at 300 Ω through Coff); ordinary sequencing steps (tens of mV) are negligible.
9. THD budget: the PhotoMOS adds ≤ −159 dB at 300 Ω (requirement point) and ≤ −119 dB at 32 Ω SE [CALC p01, bounds on assumptions]; at 32 Ω balanced full scale near 20 Hz the conservative bound is −101 dB (not a rated point). Bring-up: THD+N at LEG_xx vs at JACK_xx with the same load.
8. Confirm the ES9018K2M output state on DPLL lock loss during rate/family changes: if it drives the reset (ground) state, the CM window opens the switch during the change (safe; the relay-closed rate-change plan then becomes "switch reopens after lock").

**Digital stream**
1. MCU pins: **RELAY_EN** (push-pull output, no pull-up in the reset state, not a debug/JTAG pin), **DC_PERMIT_N** (input, EXTI both edges, no internal pull), DC_SENSE_LP/LN/RP/RN and V3A_MON on ADC2 (continuous 5-channel scan with DMA, ≥ 10 kHz per channel, ≥ 28.5-cycle sampling at 14 MHz). FLT, FLT_CLR and the ANA_FAULT output function are deleted (pins free).
2. Please confirm the CH32V307 I/O leakage maximum (I used ±1 µA), GPIO VOH at ≤ 0.5 mA (≥ VDD − 0.4 V), and the ADC gain error (≤ 0.3 %).
3. MCLK_EN gets a tap (R645 1 kΩ to the Q616 gate, 630 pF); keep R218. (**⟶ R2/D-19: the tap is on U206 output N2_MCLK_OE, R235 100 k**) The CPLD must hold MCLK_EN high during rate/family changes.
4. IWDG enabled with ≤ 100 ms timeout. Firmware items: tiers §8, pre-close checks §8.3, stream guard §9, policy §10.

**Parts / layout**
AQV251GAX × 4 (SMD-6, Panasonic land pattern) next to the jacks; TLV1704 decoupling at the pins; keep N6_Fxx, N6_CMx and the DC-sense nodes away from MCLK/BCLK; test pads for N6_H, DC_PERMIT_N, RELAY_EN, N6_CML, N6_CMR (reuse TP722/TP724, formerly FLT/node F); global-sourcing lines listed in bom_rows.csv.

---

## 13. Parts added / removed, sources, cost
> **⟶ R2:** round-2 changes in R2.12 (TLP3545A, U604, R641/R642 24.9 Ω, R647 100 k, C617 1 µF, R662/R663/C622 added, Q613/Q615 retired).
Added (bom_rows.csv): U603 TLV1704AIPWR (C181596; U601/U602 change from LM339DR C7948 to TLV1704AIPWR C181596); K601–K604 AQV251GAX (no LCSC number; Mouser/DigiKey via JLCPCB global sourcing); Q612–Q615 MMBT3904 (C20526, Basic); Q616, Q617 AO3400A (C20917, Basic); Q618 2N7002 (C8545, Basic); R641, R642 100 Ω (C25076, Basic); R643, R644 4.7 k (C25900); R645 1 k (C11702); R646, R648, R649–R652 100 k (C25741); R647 470 k (C25790); R653–R656 100 k 0.1 % (C852472); R657, R659 10.0 k 0.1 % (C190095); R658, R661 6.8 k 0.1 % (C33900832); R660 330 k (C25778); C617 220 nF (C16772); C618, C619 100 nF (C1525); C620, C621 10 nF (C15195).
Changed values: R601–R604 105 k (C25742); C601–C604 2.2 µF 16 V X5R 0603 (C23630, Basic); C608–C611, C616 4.7 µF 25 V X5R 0805 (Samsung CL21A475KAQNNNE, C1779, Basic, JLCPCB 2.86 M in stock); R607 121 k 0.1 % (C852503), R608 115 k 0.1 % (C852488), R609, R610 10.0 k 0.1 % (C190095); R624–R627 6.8 k 0.1 % (C33900832); R628–R631, R639 5.1 k 0.1 % (C852856); R632–R635, R640 16.9 k 0.1 % (C852560).
Removed (retired designators): Q601–Q611, R611–R617, R618, R623, R636, R637, R638, C605, C606, C607, D605, D606.
Block 6 parts ≈ US$ 22 per board (100-board tier; ≈ 80 % is the four PhotoMOS) [p08].

Sources: TI TLV1704 SBOS589D (ti.com/lit/ds/symlink/tlv1704.pdf); TI LM339B SLCS006Z (ti.com/lit/ds/symlink/lm339b.pdf); Panasonic AQV251GAX product page and HE DIP6 1 Form A catalog (na.industrial.panasonic.com …/model/12770); Panasonic AQV252G data (media.distrelec.com/…/cfAQV252G_data_e.pdf); Toshiba TLP3547 datasheet (toshiba-semicon-storage.com docget did=36853, alternative considered); TE Axicom IM datasheet (tti.com TE IM datasheet PDF); Omron G6K (omronfs.omron.com/en_US/ecb/products/pdf/en-g6k.pdf); Panasonic TQ-SMD (datasheet4u/Panasonic ASCTB14E); Hongfa HFD3 (source.hongfa.com/Uploads/Product/PDF/HFD3_en.pdf); AOS AO3400A rev 3 (media.digikey.com AO3400A_ds.pdf); JSCJ MMBT3904 (LCSC C20526); CH32V307 datasheet V3.5 tables 4-42/4-43 (wch-ic.com CH32V307DS0); OPA1622 SBOS727B and ES9018K2M v3.7 (supplied text files); LCSC/JLCPCB part pages for every C-number above (24 Sep 2026).

---

## 14. Open items (measurements with designed-in fallbacks) and what I could not verify
| Item | Why | Fallback (no board change) |
|---|---|---|
| [MEAS] ES9018K2M pin-to-pin output-resistance matching (CM ripple at full scale) | window sized for 22 % mismatch (unspecified) | if the ripple is ≤ 5 %, tighten R658 (value change) for more stuck-pin margin; if larger than assumed, widen R658 |
| [MEAS] AQV251GAX Ron and Toff at 60 °C **⟶ R2: TLP3545A, see R2.15** | datasheet curves are typical | AQV252GAX drop-in only if needed for stock; timing margins are ≥ 5× |
| [MEAS] CH32V307 pin leakage, INL at the operating codes | budget uses ±1 µA and 2 × EL | tier thresholds are firmware constants |
| [MEAS] TLV1704 stock beyond 61 pcs | LCSC stock | JLCPCB global sourcing |
| [MEAS] Effective C of C601–C604 at ≈ 0.15 Vrms ripple (X5R low-AC-level effect) | the brief's −15 % may be optimistic; a full-scale 20 Hz square wave can trip only if C < −16.9 % [CALC p03] | none needed for the sine requirement (≤ 13.6 Hz at −25 %); a square-wave false mute is protective only |
| [MEAS] PhotoMOS contribution to THD at 32 Ω balanced, 20 Hz | self-heating bound ≤ −101 dB is a DC-Rth bound | THD at LEG_xx vs JACK_xx with the same load isolates the switch; 300 Ω requirement point ≤ −159 dB |
Not verified: CH32V307 I/O leakage maximum, VOH at low current, ADC gain error; AQV251G VF minimum (assumed 1.0 V) and output capacitance (typical figure); MMBT3904 VBE at 0.2–0.5 mA (SPICE model value); OPA1622 current-limit maximum (typical only, bound 190 mA); ES9018K2M lock-loss output state and FIR delay; the jack TVS clamp voltage and polarity (parts list says bidirectional); JLCPCB class of TLV1704AIPWR (assumed Extended) and AO3400A (taken as Basic); the LM27762 UVLO behaviour (taken from the Notes); relay coil self-heating (250 K/W assumed, only used for the rejected option); MLCC DC-bias and AC-level derating (Samsung curves are typical only — stated factors 0.85 for C608–C611/C616 at ≤ 2.5 V and 0.75 for C617 at ≤ 4 V); PhotoMOS gate overdrive and Ron tempco (distortion bound only). The frozen-DAC-code residual (§4.4) and full-scale digital DC into 32 Ω balanced (§9) are stated limits, not compliance.

## 15. Files
report.md, bom_rows.csv (24 lines), netlist.csv (77 parts, 217 pins — round 2), pcommon.py, p01_switch_choice.py, p02_connection_cases.py, p03_detector.py, p03b_threshold_scan.py, p04_cm_monitor.py, p05_switch_drive.py (rewritten in round 2), p06_dcsense_tiers.py, p07_stream_guard.py, p08_bom_netlist.py, p09_adc_sampling.py (new), each with its *_out.txt; p04_cm_monitor_result.json (x_sil and CM removal time read by p03/p06); p06_content_cache.json (cache of the slow content-rejection runs; delete to recompute); ds/ (fetched datasheet text: TLV1704, LM339B, CH32V307, OPA2333, TLP3545A extract). Round-1 copies kept as *.bak (report_r1.md.bak, p05_switch_drive_r1edit.py.bak, p05_switch_drive_r1_out.txt.bak, p08_bom_netlist_r1.py.bak, p04_cm_monitor_pre_analog_r2.py.bak) — superseded, not deliverables.
