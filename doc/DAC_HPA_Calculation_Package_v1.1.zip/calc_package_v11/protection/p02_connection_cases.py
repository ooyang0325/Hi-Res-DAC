#!/usr/bin/env python3
"""p02 - Does opening the output switches protect every headphone / adapter case on both jacks?

DC nodal analysis (numpy) of the jack wiring with the output switches OPEN.
Every amplifier leg is an independent voltage source; each leg is swept over
{-4.014, 0, +4.014} V (81 combinations, covers rail-stuck, balanced +-x and
opposite-sign faults of any size by linearity). For each plug configuration the
worst |voltage| across every headphone driver is reported.

Architectures
  A0  no switch (legs hard-wired)                                   reference
  A1  brief v0.9 proposal: switch in L+ and R+ only (JACK_LP/JACK_RP shared by
      both jacks), L- and R- hard-wired to the 4.4 mm jack
  A2  switch in all four legs (JACK_LP, JACK_LN, JACK_RP, JACK_RN), both jacks fed
      from the same switched nets                               (chosen)
  A3  per-jack switching of L+/R+ (4 switches), L-/R- hard-wired

Jack wiring (Notes 3.5.3): J701 4.4 mm: T=L+, R1=L-, R2=R+, R3=R-, S=GND.
J702 3.5 mm TRRS body used with TRS plugs: T=L+, R1=R+, R2=GND, S=GND.

Element models (all DC):
  headphone driver         16 ohm (result scales with the leakage only)
  adapter / plug short     0.01 ohm
  closed switch            0.15 ohm
  open switch              60 Mohm   (AQV252G off-state leakage <= 1 uA at 60 V; round 2: TLP3545A sensitivity at the end)
  jack ESD diode           bidirectional: 1 Gohm at |V| <= 4.1 V (VRWM 5 V)
                           unidirectional (what-if): 1 ohm to GND (forward-biased
                           by a negative leg), shows why D701-D704 must be bidirectional
  amplifier leg            0.1 ohm source resistance
"""
import itertools
import numpy as np

VLEG = 4.014  # max |rail| (VPOS max) used as the fault amplitude
R_DRV, R_SHORT, R_SW_ON, R_SW_OFF, R_SRC = 16.0, 0.01, 0.15, 60e6, 0.1
R_ESD_BI, R_ESD_UNI = 1e9, 1.0


def build(arch, plug4, plug3, sw_closed=False, esd='bi'):
    """Return (edges, drivers). edges: list of (n1, n2, R). Nodes are strings.
    Source nodes 'LEG_LP','LEG_LN','LEG_RP','LEG_RN' are driven, 'GND' is 0 V."""
    e, drv = [], []
    rsw = R_SW_ON if sw_closed else R_SW_OFF
    # jack contact nets
    if arch == 'A0':
        j4 = dict(T='LEG_LP', R1='LEG_LN', R2='LEG_RP', R3='LEG_RN', S='GND')
        j3 = dict(T='LEG_LP', R1='LEG_RP', R2='GND', S='GND')
    elif arch == 'A1':
        e += [('LEG_LP', 'JACK_LP', rsw), ('LEG_RP', 'JACK_RP', rsw)]
        j4 = dict(T='JACK_LP', R1='LEG_LN', R2='JACK_RP', R3='LEG_RN', S='GND')
        j3 = dict(T='JACK_LP', R1='JACK_RP', R2='GND', S='GND')
    elif arch == 'A2':
        e += [('LEG_LP', 'JACK_LP', rsw), ('LEG_RP', 'JACK_RP', rsw),
              ('LEG_LN', 'JACK_LN', rsw), ('LEG_RN', 'JACK_RN', rsw)]
        j4 = dict(T='JACK_LP', R1='JACK_LN', R2='JACK_RP', R3='JACK_RN', S='GND')
        j3 = dict(T='JACK_LP', R1='JACK_RP', R2='GND', S='GND')
    elif arch == 'A3':
        e += [('LEG_LP', 'J4_LP', rsw), ('LEG_RP', 'J4_RP', rsw),
              ('LEG_LP', 'J3_LP', rsw), ('LEG_RP', 'J3_RP', rsw)]
        j4 = dict(T='J4_LP', R1='LEG_LN', R2='J4_RP', R3='LEG_RN', S='GND')
        j3 = dict(T='J3_LP', R1='J3_RP', R2='GND', S='GND')
    else:
        raise ValueError(arch)
    # jack ESD diodes on every non-GND jack contact net
    resd = R_ESD_BI if esd == 'bi' else R_ESD_UNI
    for n in set(list(j4.values()) + list(j3.values())):
        if n != 'GND' and not n.startswith('LEG'):
            e.append((n, 'GND', resd))
        if n.startswith('LEG') and arch == 'A0':
            e.append((n, 'GND', resd))
    for n in ('LEG_LN', 'LEG_RN'):   # hard-wired minus legs keep their ESD diode
        if arch in ('A1', 'A3'):
            e.append((n, 'GND', resd))

    def driver(a, b, name):
        drv.append((a, b, name))
        e.append((a, b, R_DRV))

    # 4.4 mm plugs
    if plug4 == 'none':
        pass
    elif plug4 == 'balanced':                       # 4 wires, shield on sleeve
        driver(j4['T'], j4['R1'], 'J701 bal L'); driver(j4['R2'], j4['R3'], 'J701 bal R')
    elif plug4 == 'commoned_return':                # 4.4-to-3.5 adapter L-/R-/GND commoned
        e += [(j4['R1'], 'CM4', R_SHORT), (j4['R3'], 'CM4', R_SHORT), (j4['S'], 'CM4', R_SHORT)]
        driver(j4['T'], 'CM4', 'J701 adapt L'); driver(j4['R2'], 'CM4', 'J701 adapt R')
    elif plug4 == 'adapter_gnd_only':               # adapter: SE sleeve to 4.4 sleeve only
        driver(j4['T'], j4['S'], 'J701 adaptG L'); driver(j4['R2'], j4['S'], 'J701 adaptG R')
    elif plug4 == 'adapter_legminus_only':          # adapter: SE sleeve to L- and R- only
        e += [(j4['R1'], 'CM4', R_SHORT), (j4['R3'], 'CM4', R_SHORT)]
        driver(j4['T'], 'CM4', 'J701 adaptM L'); driver(j4['R2'], 'CM4', 'J701 adaptM R')
    else:
        raise ValueError(plug4)
    # 3.5 mm plugs
    if plug3 == 'none':
        pass
    elif plug3 in ('TRS', 'TRRS_OMTP'):             # L: T-S, R: R1-S (S and R2 are GND)
        driver(j3['T'], j3['S'], 'J702 SE L'); driver(j3['R1'], j3['S'], 'J702 SE R')
    elif plug3 == 'TRRS_CTIA':                      # L: T-R2, R: R1-R2, mic S-R2
        driver(j3['T'], j3['R2'], 'J702 CTIA L'); driver(j3['R1'], j3['R2'], 'J702 CTIA R')
        e.append((j3['S'], j3['R2'], 2000.0))       # electret mic (both ends GND here)
    elif plug3 == 'half_inserted_TR_short':         # plug tip bridging T and R1 contacts
        e.append((j3['T'], j3['R1'], R_SHORT))
        driver(j3['T'], j3['S'], 'J702 SE L'); driver(j3['R1'], j3['S'], 'J702 SE R')
    else:
        raise ValueError(plug3)
    return e, drv


def solve(edges, vsrc):
    nodes = sorted({n for a, b, _ in edges for n in (a, b)} | set(vsrc))
    idx = {n: i for i, n in enumerate(nodes)}
    N = len(nodes)
    G = np.zeros((N, N)); I = np.zeros(N)
    for a, b, r in edges:
        g = 1.0 / r; i, j = idx[a], idx[b]
        G[i, i] += g; G[j, j] += g; G[i, j] -= g; G[j, i] -= g
    for n, v in vsrc.items():                       # Norton source per driven node
        g = 1.0 / R_SRC if n != 'GND' else 1e6
        G[idx[n], idx[n]] += g; I[idx[n]] += g * v
    return dict(zip(nodes, np.linalg.solve(G, I)))


def worst(arch, p4, p3, closed=False, esd='bi'):
    edges, drv = build(arch, p4, p3, closed, esd)
    if not drv:
        return None, None
    wv, wname = 0.0, ''
    for combo in itertools.product((-VLEG, 0.0, VLEG), repeat=4):
        vs = dict(zip(('LEG_LP', 'LEG_LN', 'LEG_RP', 'LEG_RN'), combo)); vs['GND'] = 0.0
        v = solve(edges, vs)
        for a, b, name in drv:
            dv = abs(v[a] - v[b])
            if dv > wv:
                wv, wname = dv, name + ' faults=' + ','.join('%+.1f' % c for c in combo)
    return wv, wname


def main():
    plugs4 = ['none', 'balanced', 'commoned_return', 'adapter_gnd_only', 'adapter_legminus_only']
    plugs3 = ['none', 'TRS', 'TRRS_CTIA', 'TRRS_OMTP', 'half_inserted_TR_short']
    out = []
    out.append(__doc__)
    out.append('Criterion: switches OPEN -> worst |V| across any driver must be < 1 mV '
               '(leakage level) for every leg fault combination.\n')
    summary = {}
    for esd in ('bi', 'uni'):
        for arch in ('A0', 'A1', 'A2', 'A3'):
            out.append(f'--- architecture {arch}, jack ESD model: {esd}directional ---')
            fails = 0; n = 0
            for p4 in plugs4:
                for p3 in plugs3:
                    wv, wname = worst(arch, p4, p3, False, esd)
                    if wv is None:
                        continue
                    n += 1
                    ok = wv < 1e-3
                    fails += (not ok)
                    out.append(f'  J701={p4:22s} J702={p3:23s} worst |Vdrv| = {wv:9.4g} V '
                               f'{"OK" if ok else "FAIL"}  {"" if ok else wname}')
            summary[(arch, esd)] = (n, fails)
            out.append(f'  => {arch}/{esd}: {n - fails}/{n} configurations isolated\n')
    # sanity: closed switches pass signal (A2)
    wv, wname = worst('A2', 'balanced', 'none', True, 'bi')
    out.append(f'Sanity (A2, switches CLOSED, balanced plug): worst |Vdrv| = {wv:.3f} V (signal passes)')
    out.append('\nSUMMARY (configurations isolated / total, switches open)')
    for (arch, esd), (n, f) in summary.items():
        out.append(f'  {arch} ESD={esd}: {n - f}/{n}  ({f} fail)')
    # round 2: TLP3545A off-state leakage max is not legible in the datasheet (typ 0.01 uA at 60 V) -> sensitivity of A2
    global R_SW_OFF
    out.append('\nRound 2 - A2 with the TLP3545A: off-state model sensitivity (IOFF max not legible; typ 0.01 uA at 60 V [DS-typ]); '
               'jack ESD LESD5D5.0CT1G IR <= 1 uA at 5 V (5 Mohm) [DS-listing]:')
    r_save = R_SW_OFF
    for roff, lbl in ((6e9, 'typ 0.01 uA at 60 V'), (60e6, '1 uA at 60 V (round 1)'), (4e6, '1 uA at 4 V [ASSUMP bound]'),
                      (4e5, '10 uA at 4 V (10 x bound)')):
        R_SW_OFF = roff
        wmax = 0.0
        for esd_r in (1e9, 5e6):
            globals()['R_ESD_BI'] = esd_r
            for p4 in plugs4:
                for p3 in plugs3:
                    wv, _ = worst('A2', p4, p3, False, 'bi')
                    if wv is not None:
                        wmax = max(wmax, wv)
        globals()['R_ESD_BI'] = 1e9
        out.append(f'  R_off {roff:9.3g} ohm ({lbl:28s}): worst |V| across any driver {wmax*1e3:8.4f} mV '
                   f'-> {"isolated (< 1 mV)" if wmax < 1e-3 else "NOT isolated"}')
    R_SW_OFF = r_save
    txt = '\n'.join(out)
    print(txt)
    open(__file__.replace('.py', '_out.txt'), 'w').write(txt + '\n')


if __name__ == '__main__':
    main()
