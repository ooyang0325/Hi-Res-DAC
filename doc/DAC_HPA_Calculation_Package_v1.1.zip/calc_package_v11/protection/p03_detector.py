#!/usr/bin/env python3
"""p03 - Hardware DC detector (block 6): leg windows, thresholds, filter, trip times, energies,
false-trip corner. numpy only.

Per leg:  LEG_xx -> R1 -> node A (C1 to GND) [-> R2 -> node B (C2 to GND)] -> Rin -> two
TLV1704 inputs (positive window: IN- = node, IN+ = VTH+;  negative window: IN+ = node,
IN- = VTH-).  VTH+ = VPOS*Rb/(Ra+Rb), VTH- = VNEG*Rb'/(Ra'+Rb') (single E96 resistors).
Outputs (open collector) wired-OR on node H (R_H to VPOS, C_H to GND) -> permit FET.

Removal time = detector crossing + H fall (p05: <= 0.98 ms with R647 100 k / C617 1 uF) + TLP3545A turn-off (design 1.0 ms).

Worst-case inputs (labels):
  rails VPOS 3.789-4.014 V, |VNEG| 3.618-3.828 V                           [BRIEF 5]
  TLV1704 VOS +-5.5 mV, IB +-20 nA (both -40..125 C)          [DS SBOS589D table 7.6]
  divider resistors 0.1 % + 25 ppm/K x 40 K                                   [DS/ASSUMP]
  filter R 1 % + 100 ppm/K x 40 K; C 1.79-2.42 uF effective (-18.6/+10 %: tolerance, temperature, ageing; C-25) [R3, X-9]
  full-scale content A = 2.19 V pk x (+0.15 dB cal + trim) = 2.228 V pk per leg  [Spec 2, Notes 3.5.4]
"""
import numpy as np
from pcommon import *

R1_CHOSEN, C1_CHOSEN = 115e3, 2.2e-6   # R3 (X-9): 105 k -> 115 k for the aged-capacitor corner (p11)
VTH_TARGET = 0.30
from p05_switch_drive import T_H_FALL   # s: C617 1 uF +10 % from 4.014 V to 0.45 V at >= 4 mA sink (round 1: 0.216 ms)
T_SW_OFF = SW_TOFF_DESIGN   # s, TLP3545A tOFF design value
T_EXTRA = T_H_FALL + T_SW_OFF

VOS = 5.5e-3                # [DS]
IB = 20e-9                  # [DS]
R_TOL_DIV = 0.001 + 25e-6 * 40
R_TOL_FILT = 0.01 + 100e-6 * 40
C_LO, C_HI = 1.79 / 2.2, 2.42 / 2.2   # R3 (X-9): consistency_log C-25 aged range 1.79-2.42 uF (was 0.85/1.10)

E96 = np.array([1.00, 1.02, 1.05, 1.07, 1.10, 1.13, 1.15, 1.18, 1.21, 1.24, 1.27, 1.30, 1.33, 1.37, 1.40,
                1.43, 1.47, 1.50, 1.54, 1.58, 1.62, 1.65, 1.69, 1.74, 1.78, 1.82, 1.87, 1.91, 1.96, 2.00,
                2.05, 2.10, 2.15, 2.21, 2.26, 2.32, 2.37, 2.43, 2.49, 2.55, 2.61, 2.67, 2.74, 2.80, 2.87,
                2.94, 3.01, 3.09, 3.16, 3.24, 3.32, 3.40, 3.48, 3.57, 3.65, 3.74, 3.83, 3.92, 4.02, 4.12,
                4.22, 4.32, 4.42, 4.53, 4.64, 4.75, 4.87, 4.99, 5.11, 5.23, 5.36, 5.49, 5.62, 5.76, 5.90,
                6.04, 6.19, 6.34, 6.49, 6.65, 6.81, 6.98, 7.15, 7.32, 7.50, 7.68, 7.87, 8.06, 8.25, 8.45,
                8.66, 8.87, 9.09, 9.31, 9.53, 9.76])


def e96(x):
    dec = 10 ** np.floor(np.log10(x)); m = x / dec
    return float(E96[np.argmin(abs(E96 - m))] * dec)


# ------------------------------------------------------------------ linear ladder simulation
def expm(M):
    n = np.linalg.norm(M, 1); s = max(0, int(np.ceil(np.log2(n))) + 1) if n > 0.5 else 0
    A = M / 2 ** s; E = np.eye(len(M)); T = np.eye(len(M))
    for k in range(1, 20):
        T = T @ A / k; E = E + T
    for _ in range(s):
        E = E @ E
    return E


def ladder(r1, c1, r2=None, c2=None):
    if r2 is None:
        A = np.array([[-1 / (r1 * c1)]]); B = np.array([1 / (r1 * c1)])
    else:
        A = np.array([[-1 / (r1 * c1) - 1 / (r2 * c1), 1 / (r2 * c1)],
                      [1 / (r2 * c2), -1 / (r2 * c2)]])
        B = np.array([1 / (r1 * c1), 0.0])
    return A, B


def simulate(A, B, u, h):
    """ZOH discretisation (first-order hold correction via midpoint input)."""
    n = len(B); Phi = expm(A * h)
    Gam = np.linalg.solve(A, (Phi - np.eye(n))) @ B
    x = np.zeros(n); out = np.empty(len(u))
    for k in range(len(u)):
        x = Phi @ x + Gam * u[k]
        out[k] = x[-1]
    return out


_STEP_CACHE = {}


def unit_step(A, B, tmax=2.0, h=2e-5):
    key = (A.tobytes(), B.tobytes(), tmax, h)
    if key not in _STEP_CACHE:
        n = len(B); Phi = expm(A * h); Gam = np.linalg.solve(A, (Phi - np.eye(n))) @ B
        N = int(tmax / h); y = np.empty(N + 1); st = np.zeros(n); y[0] = 0.0
        for k in range(N):
            st = Phi @ st + Gam
            y[k + 1] = st[-1]
        _STEP_CACHE[key] = (np.arange(N + 1) * h, y)
    return _STEP_CACHE[key]


def step_time(A, B, x, vtrip, tmax=2.0, h=2e-5):
    """Time for the output node to cross vtrip for a leg step x (x, vtrip > 0).
    Passive RC ladder step response is monotone, so y(t) = x*y1(t)."""
    if x <= vtrip:
        return np.inf
    t, y1 = unit_step(A, B, tmax, h)
    r = vtrip / x
    if y1[-1] < r:
        return np.inf
    i = int(np.searchsorted(y1, r))
    return t[i - 1] + (t[i] - t[i - 1]) * (r - y1[i - 1]) / (y1[i] - y1[i - 1])


def sine_peak(A, B, f, amp, nphase=36, h=None):
    """Worst |output| over all start phases for a sine switched on at t = 0 (zero state)."""
    per = 1.0 / f
    h = h or min(per / 400, 2e-4)
    tau_s = -1.0 / np.max(np.linalg.eigvals(A).real)
    t = np.arange(0, 3 * per + 6 * tau_s, h)
    n = len(B); Phi = expm(A * h); Gam = (np.linalg.solve(A, (Phi - np.eye(n))) @ B).reshape(n, 1)
    ph = np.linspace(0, np.pi, nphase, endpoint=False).reshape(1, nphase)
    st = np.zeros((n, nphase)); m = np.zeros(nphase)
    w = 2 * np.pi * f
    for k in range(len(t)):
        u = amp * np.sin(w * (t[k] + h / 2) + ph)
        st = Phi @ st + Gam * u
        m = np.maximum(m, np.abs(st[-1]))
    return float(m.max())


def square_peak(A, B, f, amp, h=None):
    per = 1.0 / f; h = h or min(per / 400, 2e-4)
    tau_s = -1.0 / np.max(np.linalg.eigvals(A).real)
    t = np.arange(0, 4 * per + 6 * tau_s, h)
    u = amp * np.sign(np.sin(2 * np.pi * f * (t + h / 2)))
    return np.max(np.abs(simulate(A, B, u, h)))


def corner(A, B, amp, vtrip, fmin=2.0, fmax=60.0, kind='sine'):
    """Lowest frequency above which the worst-case peak stays below vtrip (bisection, monotone)."""
    pk = sine_peak if kind == 'sine' else square_peak
    lo, hi = fmin, fmax
    if pk(A, B, hi, amp) >= vtrip:
        return np.inf
    if pk(A, B, lo, amp) < vtrip:
        return lo
    for _ in range(14):
        mid = np.sqrt(lo * hi)
        if pk(A, B, mid, amp) >= vtrip:
            lo = mid
        else:
            hi = mid
    return hi


# ------------------------------------------------------------------ thresholds
def thresholds(ra, rb, ran, rbn, r_filt_total, r_in, r_th_div_inputs=4):
    """Worst-case effective trip levels at the leg (V).  Returns dict of min/max magnitudes."""
    def kdiv(ra_, rb_, sign):
        lo = rb_ * (1 - R_TOL_DIV) / (rb_ * (1 - R_TOL_DIV) + ra_ * (1 + R_TOL_DIV))
        hi = rb_ * (1 + R_TOL_DIV) / (rb_ * (1 + R_TOL_DIV) + ra_ * (1 - R_TOL_DIV))
        return lo, hi
    kp = kdiv(ra, rb, +1); kn = kdiv(ran, rbn, -1)
    rth_p = ra * rb / (ra + rb); rth_n = ran * rbn / (ran + rbn)
    ib_node = 2 * IB * r_filt_total + IB * r_in           # node shift seen at the comparator pin
    ib_thp = r_th_div_inputs * IB * rth_p
    ib_thn = r_th_div_inputs * IB * rth_n
    vp_nom = VPOS_NOM * rb / (ra + rb); vn_nom = VNEG_NOM * rbn / (ran + rbn)
    vp_min = VPOS_MIN * kp[0] - VOS - ib_node - ib_thp
    vp_max = VPOS_MAX * kp[1] + VOS + ib_node + ib_thp
    vn_min = VNEG_MIN * kn[0] - VOS - ib_node - ib_thn
    vn_max = VNEG_MAX * kn[1] + VOS + ib_node + ib_thn
    return dict(p_nom=vp_nom, n_nom=vn_nom, p_min=vp_min, p_max=vp_max, n_min=vn_min, n_max=vn_max,
                trip_min=min(vp_min, vn_min), trip_max=max(vp_max, vn_max), ib_node=ib_node)


def design_ladder(tau1, tau2=None, r1=None, ratio_r=1.0):
    r1 = r1 or (tau1 / 1e-6 if tau2 is None else 100e3)
    """Nominal components for a given tau (1-pole) or tau1/tau2 (2-pole, R2 = ratio_r*R1)."""
    c1 = tau1 / r1
    if tau2 is None:
        return dict(r1=r1, c1=c1)
    r2 = ratio_r * r1
    return dict(r1=r1, c1=c1, r2=r2, c2=tau2 / r2)


def corners_of(d):
    """(fast, slow) state matrices for tolerance corners."""
    f = (1 - R_TOL_FILT) , C_LO
    s = (1 + R_TOL_FILT) , C_HI
    if 'r2' not in d:
        return (ladder(d['r1'] * f[0], d['c1'] * f[1]), ladder(d['r1'] * s[0], d['c1'] * s[1]))
    return (ladder(d['r1'] * f[0], d['c1'] * f[1], d['r2'] * f[0], d['c2'] * f[1]),
            ladder(d['r1'] * s[0], d['c1'] * s[1], d['r2'] * s[0], d['c2'] * s[1]))


def evaluate(d, th, verbose=False):
    (Af, Bf), (As, Bs) = corners_of(d)
    res = {}
    res['fc_sine'] = corner(Af, Bf, A_FS, th['trip_min'])
    # detection (slowest corner, highest trip level of the relevant polarity)
    def trem(x, pol):
        vt = th['p_max'] if pol > 0 else th['n_max']
        return step_time(As, Bs, x, vt) + T_EXTRA
    res['t1V'] = max(trem(1.0, 1), trem(1.0, -1))
    res['t2V'] = max(trem(2.0, 1), trem(2.0, -1))
    res['tFS'] = max(trem(2.19, 1), trem(2.19, -1))
    # rail-stuck single leg, SE: energy at both ends of the rail range
    e16 = []; e32 = []
    for v, pol in ((VPOS_MIN, 1), (VPOS_MAX, 1), (VNEG_MIN, -1), (VNEG_MAX, -1)):
        t = trem(v, pol)
        e16.append(v * v / 16 * t); e32.append(v * v / 32 * t)
    res['E_rail16'] = max(e16); res['E_rail32'] = max(e32)
    # rail-stuck detection times (for the table)
    res['t_rail_pos'] = trem(VPOS_MIN, 1); res['t_rail_neg'] = trem(VNEG_MIN, -1)
    return res


def frozen_pm_x(d, th, rload):
    """Balanced +-x from a frozen DAC code (MCLK loss, not caught by the CM windows):
    worst energy over x in (trip, 2.5 V], legs swing/current bounded at the minimum rail."""
    (_, _), (As, Bs) = corners_of(d)
    worst = (0.0, 0.0, 0.0)
    for x in np.linspace(th['trip_max'] * 1.02, 2.5, 25):
        xl = leg_dc_max(x, rload / 2, min(VPOS_MAX, VNEG_MAX))
        if xl <= th['trip_max']:
            continue
        t = step_time(As, Bs, xl, th['trip_max']) + T_EXTRA
        e = (2 * xl) ** 2 / rload * t
        if e > worst[0]:
            worst = (e, xl, t)
    return worst


def main():
    out = [__doc__]
    # ---------------- thresholds (single E96 resistors) --------------------------------
    target = VTH_TARGET
    rb = 10.0e3; ra = e96(rb * (VPOS_NOM / target - 1))
    rbn = 10.0e3; ran = e96(rbn * (VNEG_NOM / target - 1))
    out.append(f'Threshold dividers: VTH+ = VPOS*Rb/(Ra+Rb): Ra = {ra/1e3:.1f} k, Rb = {rb/1e3:.2f} k;  '
               f'VTH- = VNEG*Rb/(Ra+Rb): Ra = {ran/1e3:.1f} k, Rb = {rbn/1e3:.2f} k (0.1 %, 25 ppm)')

    # ---------------- design-space exploration ------------------------------------------
    out.append('\nDesign space at the OLD 0.55 V threshold (R1 = tau/1 uF; Rin = 100 k; C -15/+10 %): '
               'fc = lowest full-scale sine (worst onset phase) that never trips;'
               f' times are worst-case removal (incl. {T_EXTRA*1e3:.2f} ms H + photorelay)')
    out.append(' topology            tau1   tau2 |  fc_sine | t(1V)  t(2V)  t(2.19V) | E_rail16 E_rail32 | frozen+-x 32R / 16R')
    ra55 = e96(10e3 * (VPOS_NOM / 0.55 - 1)); ran55 = e96(10e3 * (VNEG_NOM / 0.55 - 1))
    cands = []
    for tau in (0.080, 0.100, 0.121, 0.140, 0.160):
        cands.append(('1-pole', tau, None))
    for t1, t2 in ((0.030, 0.030), (0.040, 0.040), (0.050, 0.050), (0.060, 0.060), (0.047, 0.022),
                   (0.068, 0.022), (0.068, 0.033)):
        cands.append(('2-pole', t1, t2))
    table = []
    for topo, t1, t2 in cands:
        d = design_ladder(t1, t2)
        rtot = d['r1'] + d.get('r2', 0.0)
        th = thresholds(ra55, rb, ran55, rbn, rtot, 100e3)
        r = evaluate(d, th)
        fz32 = frozen_pm_x(d, th, 32.0); fz16 = frozen_pm_x(d, th, 16.0)
        table.append((topo, t1, t2, r, fz32, fz16))
        out.append(f' {topo:8s}          {t1*1e3:5.0f}  {"" if t2 is None else f"{t2*1e3:5.0f}":>5s} | '
                   f'{r["fc_sine"]:6.2f} Hz | {r["t1V"]*1e3:5.0f} {r["t2V"]*1e3:6.1f} {r["tFS"]*1e3:7.1f}  | '
                   f'{r["E_rail16"]*1e3:6.1f}  {r["E_rail32"]*1e3:6.1f}   | {fz32[0]*1e3:5.1f} mJ / {fz16[0]*1e3:5.1f} mJ')

    # ---------------- chosen design --------------------------------------------------------
    # 1-pole at 0.30 V (p03b scan): R1 = 105 k 1 %, C1 = 2.2 uF (tau 231 ms).  The unbuffered 2-pole ladders above are
    # slower for the same false-trip corner (their dominant pole is ~2.6 x the component tau), so the
    # single pole is both simpler and better here.
    d = dict(r1=R1_CHOSEN, c1=C1_CHOSEN)
    rtot = d['r1']
    th = thresholds(ra, rb, ran, rbn, rtot, 100e3)
    r = evaluate(d, th)
    (Af, Bf), (As, Bs) = corners_of(d)
    (An, Bn) = ladder(d['r1'], d['c1'])
    out.append(f'\n==== CHOSEN (R3): 1-pole, |VTH| 0.30 V, R1 = {R1_CHOSEN/1e3:.0f} kOhm 1 %, C1 = {C1_CHOSEN*1e6:.1f} uF X5R 10 % (aged 1.79-2.42 uF), Rin = 100 kOhm ====')
    out.append(f' Trip level at the leg (worst case): positive {th["p_min"]:.3f}...{th["p_max"]:.3f} V '
               f'(nominal {th["p_nom"]:.3f}), negative -{th["n_min"]:.3f}...-{th["n_max"]:.3f} V (nominal -{th["n_nom"]:.3f})')
    out.append(f'   -> |trip| {th["trip_min"]:.3f}...{th["trip_max"]:.3f} V; bias-current share at the node {th["ib_node"]*1e3:.1f} mV')
    tn = R1_CHOSEN*C1_CHOSEN*1e3
    out.append(f' tau: nominal {tn:.0f} ms, fastest {tn*(1-R_TOL_FILT)*C_LO:.1f} ms, slowest {tn*(1+R_TOL_FILT)*C_HI:.1f} ms')
    fc = r['fc_sine']
    fcn = corner(An, Bn, A_FS, th['trip_min'])
    fc_ss = None
    out.append(f' False-trip corner, full-scale sine {A_FS:.3f} V pk, worst start phase and onset, fastest '
               f'components and lowest trip: {fc:.2f} Hz (nominal components: {fcn:.2f} Hz)')
    for f in (10, 12, 14, 16, 20, 25, 30):
        pk = sine_peak(Af, Bf, f, A_FS)
        out.append(f'   {f:3d} Hz: worst node peak {pk:.3f} V vs lowest trip {th["trip_min"]:.3f} V '
                   f'-> {"no trip" if pk < th["trip_min"] else "TRIP"} (margin {100*(1-pk/th["trip_min"]):5.1f} %)')
    fsq = corner(Af, Bf, A_FS, th['trip_min'], kind='square')
    out.append(f' (information) full-scale SQUARE wave corner: {fsq:.1f} Hz; untrimmed 3.66 V sine corner: '
               f'{corner(Af, Bf, A_FS_UNTRIM, th["trip_min"]):.1f} Hz (only if the -4.5 dB safety default were lost)')
    out.append(' Capacitor what-if [ASSUMP]: C601-C604 below the brief\'s -15 % (e.g. the X5R low-AC-level effect: the node '
               'ripple is ~0.15 Vrms vs the 1 Vrms test level; not covered by the datasheet). Removal times only get shorter:')
    for c_lo in (0.80, 0.75):
        Aq, Bq = ladder(R1_CHOSEN * (1 - R_TOL_FILT), C1_CHOSEN * c_lo)
        out.append(f'   C {100*(c_lo-1):.0f} %: sine corner {corner(Aq, Bq, A_FS, th["trip_min"]):.1f} Hz, '
                   f'square corner {corner(Aq, Bq, A_FS, th["trip_min"], kind="square"):.1f} Hz')
    lo_c, hi_c = 0.70, C_LO                         # bisection: capacitance factor at which a FS 20 Hz square just trips
    for _ in range(14):
        mid = 0.5 * (lo_c + hi_c)
        Aq, Bq = ladder(R1_CHOSEN * (1 - R_TOL_FILT), C1_CHOSEN * mid)
        if square_peak(Aq, Bq, 20.0, A_FS) >= th['trip_min']:
            lo_c = mid
        else:
            hi_c = mid
    out.append(f'   full-scale 20 Hz square wave never trips while C601-C604 >= {100*(hi_c-1):.1f} % of nominal '
               f'(fastest R, lowest trip level)')

    out.append(f'\n Removal time (worst: slow components, highest trip, + {T_H_FALL*1e3:.2f} ms H fall + {T_SW_OFF*1e3:.1f} ms photorelay):')
    rows = [('0.5 V DC', 0.5), ('1.0 V DC', 1.0), ('1.5 V DC', 1.5), ('2.0 V DC', 2.0), ('2.19 V (full-scale digital DC)', 2.19),
            (f'rail-stuck + {VPOS_MIN:.3f} V', VPOS_MIN), (f'rail-stuck + {VPOS_MAX:.3f} V', VPOS_MAX),
            (f'rail-stuck - {VNEG_MIN:.3f} V', -VNEG_MIN), (f'rail-stuck - {VNEG_MAX:.3f} V', -VNEG_MAX)]
    tt = {}
    for name, x in rows:
        vt = th['p_max'] if x > 0 else th['n_max']
        vtn = th['p_nom'] if x > 0 else th['n_nom']
        tw = step_time(As, Bs, abs(x), vt) + T_EXTRA
        tn = step_time(An, Bn, abs(x), vtn) + 0.25e-3 + 0.1e-3
        tt[name] = tw
        req = ' (limit 250 ms)' if abs(x) == 1.0 else (' (limit 100 ms)' if abs(x) == 2.0 else '')
        out.append(f'   {name:34s} nominal {tn*1e3:6.1f} ms   worst {tw*1e3:6.1f} ms{req}')

    out.append('\n Terminal energy, rail-stuck output (High mode, either polarity), switch removes it:')
    for rl in LOADS:
        es = []
        for v, pol in ((VPOS_MIN, 1), (VPOS_MAX, 1), (VNEG_MIN, -1), (VNEG_MAX, -1)):
            vt = th['p_max'] if pol > 0 else th['n_max']
            t = step_time(As, Bs, v, vt) + T_EXTRA
            es.append((v * v / rl * t, v, t))
        e, v, t = max(es)
        lim = E_LIMIT.get(rl)
        out.append(f'   {rl:5.0f} ohm SE (leg to GND): {e*1e3:6.2f} mJ at {v:.3f} V, {t*1e3:.1f} ms'
                   + (f'  limit {lim*1e3:.0f} mJ, margin {100*(1-e/lim):.0f} %' if lim else ''))
    # balanced with one leg stuck, the healthy leg current-limited (bound ISC_BOUND)
    for rl in (16.0, 32.0):
        es = []
        for v, pol in ((VPOS_MAX, 1), (VNEG_MAX, -1), (VPOS_MIN, 1), (VNEG_MIN, -1)):
            vt = th['p_max'] if pol > 0 else th['n_max']
            t = step_time(As, Bs, v, vt) + T_EXTRA
            vd = min(v, ISC_BOUND * rl)       # healthy leg can hold the far end only up to its current limit
            es.append((vd * vd / rl * t, vd, t))
        e, vd, t = max(es)
        out.append(f'   {rl:5.0f} ohm balanced, one leg stuck: {e*1e3:6.2f} mJ ({vd:.2f} V across, {t*1e3:.1f} ms)'
                   f'  limit {E_LIMIT[rl]*1e3:.0f} mJ')

    out.append('\n Balanced +-x failure (failed I/V op-amp or stuck DAC pin): the leg windows alone are too slow;'
               ' the I/V common-mode windows remove it (removal times and energies incl. worst opposing content: '
               'p04_cm_monitor_out.txt). Leg windows alone:')
    for rl in (16.0, 32.0):
        xl = leg_dc_max(4.0, rl / 2, VPOS_MAX)
        p = (2 * xl) ** 2 / rl
        t_leg = step_time(As, Bs, xl, th["trip_max"]) + T_EXTRA
        out.append(f'   {rl:4.0f} ohm: current/swing-bounded {2*xl:.2f} V across the driver, {p*1e3:.0f} mW;'
                   f' leg windows alone would take {t_leg*1e3:.1f} ms = {p*t_leg*1e3:.1f} mJ'
                   f' (limit {E_LIMIT[rl]*1e3:.0f} mJ)')
    for rl in (16.0, 32.0, 60.0, 300.0):
        e, xl, t = frozen_pm_x(d, th, rl)
        out.append(f'   frozen DAC code (X201 dead, MCLK_EN still high) {rl:4.0f} ohm balanced: worst {e*1e3:5.1f} mJ '
                   f'at +-{xl:.2f} V, {t*1e3:.1f} ms (leg windows only)')

    try:
        import json
        xcm = json.load(open(__file__.replace('p03_detector.py', 'p04_cm_monitor_result.json')))['x_cm_sil']
    except Exception:
        xcm = float('nan')
    out.append('\n Moderate balanced +-x (one DAC pin stuck, silence), leg windows only (the CM window covers'
               f' >= {xcm:.2f} V/leg at silence, p04; firmware tiers in parallel, p06):')
    for x in (0.33, 0.35, 0.40, 0.50, 0.60, 0.80, 1.00, 1.05, 1.20):
        t = step_time(As, Bs, x, th['trip_max']) + T_EXTRA
        e32 = (2 * x) ** 2 / 32 * t
        x16 = leg_dc_max(x, 8.0, VPOS_MAX); e16 = (2 * x16) ** 2 / 16 * (step_time(As, Bs, x16, th['trip_max']) + T_EXTRA)
        out.append(f'   x = {x:4.2f} V/leg ({2*x:4.2f} V across): removal {t*1e3:7.1f} ms  E32 {e32*1e3:5.1f} mJ  E16 {e16*1e3:5.1f} mJ')
    out.append('\n Opposite-sign sub-threshold legs (not seen by the leg windows): up to '
               f'2 x {th["trip_max"]:.3f} = {2*th["trip_max"]:.3f} V across a balanced driver -> firmware tiers (p06)')

    # ---------------- rail collapse / input protection -------------------------------------
    out.append('\n Rail collapse with a charged filter capacitor (R8-B8): node B at up to 4.014 V while the '
               'comparator rails collapse to 0;')
    i_in = (4.014 + 0.5) / 100e3
    out.append(f'   input clamp current <= (4.014 V + 0.5 V)/Rin = {i_in*1e6:.0f} uA  (TLV1704 limit 10 mA [DS 7.1]); '
               'the comparator output is undefined then, but H <= VPOS -> 0, so the permit is off anyway.')
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))


if __name__ == '__main__':
    main()
