#!/usr/bin/env python3
"""p17 - R9 E-3: hardware "large-DC" leg windows (second window set, higher threshold, fast C0G filter) that close L-11
(frozen DAC code with every supervisor good), and the new worst case over all DC levels.  Also E-2 timing numbers.
Per leg: LEG_xx -> R_F -> node F2 (C_F C0G to GND) -> R_IN 100 k -> two TLV1704 inputs; thresholds VTH2+ = VPOS x k+,
VTH2- = VNEG x k- (own dividers, 0.1 %); outputs wired-OR on N6_H (like U601/U602).  Removal = detection + H fall 0.98 ms
+ tOFF 1.0 ms (p05) - the E-2 latch path would be faster (not credited)."""
import numpy as np
import p03_detector as d3
from pcommon import VPOS_MIN, VPOS_NOM, VPOS_MAX, VNEG_MIN, VNEG_NOM, VNEG_MAX, A_FS, leg_dc_max, ISC_BOUND
out = [__doc__]; P = out.append
T_EXTRA = d3.T_EXTRA
R_TOL = 0.01 + 100e-6 * 40          # R_F 1 % thick film
C_TOL_LO, C_TOL_HI = 0.95 * 0.99, 1.05 * 1.01   # C0G +-5 %, +-30 ppm/K x 40 K + ageing none
VOS, IB = 5.5e-3, 20e-9
# existing windows (p03, R601 115 k, aged X5R)
ra = d3.e96(10e3 * (3.900 / 0.30 - 1)); ran = d3.e96(10e3 * (3.722 / 0.30 - 1))
th1 = d3.thresholds(ra, 10e3, ran, 10e3, d3.R1_CHOSEN, 100e3)
(Af1, Bf1), (As1, Bs1) = d3.corners_of(dict(r1=d3.R1_CHOSEN, c1=d3.C1_CHOSEN))


def t_old(x):
    return d3.step_time(As1, Bs1, x, max(th1['p_max'], th1['n_max'])) + T_EXTRA


def thr2(k_top, k_bot, rf):
    """worst trip magnitudes of the new windows at the leg (positive from VPOS, negative from VNEG)."""
    tol = 0.001 + 25e-6 * 40
    def kd(ra_, rb_, s):
        return rb_ * (1 + s * tol) / (rb_ * (1 + s * tol) + ra_ * (1 - s * tol))
    rth = k_top * k_bot / (k_top + k_bot)
    ib = 2 * IB * rf + IB * 100e3 + 8 * IB * rth / 2
    pmin = VPOS_MIN * kd(k_top, k_bot, -1) - VOS - ib; pmax = VPOS_MAX * kd(k_top, k_bot, 1) + VOS + ib
    nmin = VNEG_MIN * kd(k_top, k_bot, -1) - VOS - ib; nmax = VNEG_MAX * kd(k_top, k_bot, 1) + VOS + ib
    return min(pmin, nmin), max(pmax, nmax), VPOS_NOM * k_bot / (k_top + k_bot)


def power(x, rl, bal):
    xl = leg_dc_max(x, rl / 2 if bal else rl, VPOS_MAX)
    v = 2 * xl if bal else xl
    return v * v / rl, xl


P('\nCandidates (R_F 1 %, C_F C0G 5 %; divider top/bottom from VPOS/VNEG 0.1 %):')
P(' Rtop/Rbot   Vth2 min..max | tau s(fast) ms | FS sine 20 Hz peak vs Vth2 min | square corner | worst E over all DC: 16 bal / 32 bal / 16 SE / 32 SE (mJ)')
best = None
for rtop, rbot in ((30.9e3, 10e3), (31.6e3, 10e3), (32.4e3, 10e3)):
    for rf, cf in ((300e3, 100e-9), (330e3, 100e-9), (300e3, 82e-9), (270e3, 100e-9)):
        vmin, vmax, vnom = thr2(rtop, rbot, rf)
        Af, Bf = d3.ladder(rf * (1 - R_TOL), cf * C_TOL_LO); As, Bs = d3.ladder(rf * (1 + R_TOL), cf * C_TOL_HI)
        pk = d3.sine_peak(Af, Bf, 20.0 * (1 - 1e-4), A_FS)
        sq = d3.corner(Af, Bf, A_FS, vmin, fmin=5.0, fmax=60.0, kind='square')
        worst = {}
        for rl, bal in ((16.0, True), (32.0, True), (16.0, False), (32.0, False)):
            wm = (0.0, 0.0, 0.0)
            for x in np.linspace(0.2, 4.1, 391):
                p, xl = power(x, rl, bal)
                if xl < 0.2:
                    continue
                tn = d3.step_time(As, Bs, xl, vmax) + T_EXTRA if xl > vmax else np.inf
                to = t_old(xl)
                t = min(tn, to)
                e = p * t
                if e > wm[0]:
                    wm = (e, xl, t)
            worst[(rl, bal)] = wm
        ok = pk < 0.9 * vmin and worst[(16.0, True)][0] < 30e-3 and worst[(32.0, True)][0] < 15e-3
        P(f' {rtop/1e3:5.1f}k/{rbot/1e3:.0f}k  {vmin:.3f}..{vmax:.3f} | {rf*cf*1e3:5.1f} ({rf*(1-R_TOL)*cf*C_TOL_LO*1e3:.1f}) | '
          f'{pk:.3f} vs {vmin:.3f} ({100*(1-pk/vmin):4.1f} %) | {sq:5.1f} Hz | ' +
          ' / '.join(f'{worst[k][0]*1e3:5.1f} (x {worst[k][1]:.2f} V, {worst[k][2]*1e3:.0f} ms)' for k in ((16.0, True), (32.0, True), (16.0, False), (32.0, False)))
          + ('  <- OK' if ok else ''))
        if ok and (best is None or max(worst[(16.0, True)][0] / 30e-3, worst[(32.0, True)][0] / 15e-3) <
                   max(best[4][(16.0, True)][0] / 30e-3, best[4][(32.0, True)][0] / 15e-3)):
            best = (rtop, rbot, rf, cf, worst, vmin, vmax, pk, sq)
if best:
    rtop, rbot, rf, cf, worst, vmin, vmax, pk, sq = best
    P(f'\nCHOSEN: VTH2 dividers {rtop/1e3:.1f} k / {rbot/1e3:.0f} k (0.1 %) from VPOS and VNEG -> +-{vmin:.3f}...{vmax:.3f} V at the leg; '
      f'R_F {rf/1e3:.0f} k 1 %, C_F {cf*1e9:.0f} nF C0G 5 % (tau {rf*cf*1e3:.1f} ms); FS 20 Hz sine peak {pk:.3f} V '
      f'(margin {100*(1-pk/vmin):.1f} %); FS square corner {sq:.1f} Hz')
    for (rl, bal), v in worst.items():
        lim = 30e-3 if rl == 16.0 else 15e-3
        P(f'  {rl:.0f} ohm {"balanced" if bal else "SE      "}: worst {v[0]*1e3:.1f} mJ at {v[1]:.2f} V/leg, removal {v[2]*1e3:.0f} ms '
          f'(limit {lim*1e3:.0f} mJ, margin {100*(1-v[0]/lim):.0f} %)')
    As, Bs = d3.ladder(rf * (1 + R_TOL), cf * C_TOL_HI)
    for x in (1.0, 1.2, 1.52, 2.02, 2.14):
        tn = d3.step_time(As, Bs, x, vmax) + T_EXTRA if x > vmax else np.inf
        P(f'  frozen code +-{x:.2f} V/leg: new windows {tn*1e3:.1f} ms, old windows {t_old(x)*1e3:.1f} ms')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
