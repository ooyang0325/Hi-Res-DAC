#!/usr/bin/env python3
# HISTORICAL GENERATOR (R10 F-3): not a release calculation and not guaranteed to re-run. It rebuilt the R9 BOM/netlist
# from the round-VE backups (bom_rows_ve.csv.bak, netlist_ve.csv.bak), which are not shipped. The current rows are produced
# by the self-contained, idempotent release generator p21d_r10_bom.py on top of the shipped bom_rows.csv / netlist.csv.
"""p19 - R9 BOM/netlist edits (reads bom_rows_ve.csv.bak / netlist_ve.csv.bak = VE/OD state):
  E-2 re-arm latch: U608 74LVC1G74 (3V3D), Q621 2N7002, Q622 AO3400A (in series with Q617), R690-R695, C630; U606 ch4 used.
  E-3 pair-difference level-persistence detector: U609 (L), U610 (R) TLV1704, R900-R915 dividers, R916-R919 R_D 15 k,
      R920-R923 R_T 165 k, R924/R925 V_T divider (R9xx: the free R6xx numbers are retired and R7xx is block 7), C631-C634 C_T 100 nF C0G 2 %, D611/D612 BAS70-05, C635-C638 decoupling.
  LCSC codes 'TBC' are not verified (parts stream)."""
import csv
rows = list(csv.DictReader(open('bom_rows_ve.csv.bak', newline='', encoding='utf-8-sig')))
fields = list(rows[0].keys())
def line(prefix):
    for r in rows:
        if r['refs'].split(',')[0].strip() == prefix:
            return r
    raise KeyError(prefix)
def add(prefix, refs, extra=None):
    r = line(prefix); cur = [x.strip() for x in r['refs'].split(',')] + refs
    r['refs'] = ', '.join(cur); r['qty'] = str(len(cur))
    if extra:
        r['desc'] = r['desc'] + '; ' + extra
line('R601')['datasheet_url'] = 'https://www.lcsc.com/product-detail/C25747.html'   # R9 parts: stale 105 k link replaced (115 k, C25747)
add('U601', ['U609', 'U610'], 'U609/U610 (R9 E-3): pair-difference large-DC persistence detectors L/R (2 level + 2 timer channels each)')
add('Q616', ['Q622'], 'Q622 (R9 E-2): re-arm latch switch in series with Q617')
add('Q618', ['Q621'], 'Q621 (R9 E-2): H-OK inverter for the latch clear')
add('R660', ['R690', 'R694', 'R916', 'R917', 'R918', 'R919'], 'R690 N6_TRIP pull-up to 3V3D, R694 N6_HREF divider bottom (R9 E-2); R916-R919 E-3 NPN base pull-ups from VPOS (R9 check)')
r660 = line('R660'); r660['jlcpcb_stock_or_sourcing'] = 'LCSC ~72,700 (alternatives list 25 Sep 2026; parts R9 check); JLCPCB Extended; drop-in if short: YAGEO RC0402FR-07330KL C138006 (355,200)'
add('R646', ['R691', 'R693', 'R695', 'R696'], 'R691 N6_CLR_N pull-up, R693 N6_HREF divider top, R695 N6_ARM readback to PB0, R696 Q622 gate pull-down (R9 E-2/E-23)')
add('R645', ['R692'], 'R692 Q622 gate series (R9 E-2)')
r645 = line('R645'); refs = [x.strip() for x in r645['refs'].split(',') if x.strip() != 'R665']; r645['refs'] = ', '.join(refs); r645['qty'] = str(len(refs))
r645['desc'] = r645['desc'].replace('R665 (R3): MCLK tap at the U301 XI pin', 'R665 moved to its own 330 ohm line (R9 E-11)')
add('C612', ['C630', 'C635', 'C636', 'C637', 'C638'], 'C630 U608 VCC (3V3D), C635-C638 U609/U610 V+/V- (R9)')
add('R678', ['R901', 'R903', 'R905', 'R907', 'R909', 'R911', 'R913', 'R915'], 'R901-R915 odd: E-3 difference-divider Rb (R9)')
base = dict((k, '') for k in fields)
def new(**kw):
    d = dict(base); d.update({'block': '6 Protection and control', 'fit': 'Yes', 'leadless': 'No', 'tht_pins_per_part': '0',
                              'lcsc': 'TBC', 'jlcpcb_class': 'TBC', 'jlcpcb_stock_or_sourcing': 'not verified (R9)'}); d.update(kw)
    d['qty'] = str(len([x for x in d['refs'].split(',') if x.strip()]))
    rows.append(d)
TF = '0.1 %, 25 ppm/K thin film'
new(refs='R665', desc='MCLK-alive tap at the U301 XI pin (R9 E-11: 330 ohm; layout rule X201->R203->XI <= 10 mm, R665 at XI, R665->U607 <= 3 mm; X201 load <= 14.23 pF per digital)',
    value='330 Ohm', package='0402', rating_tolerance='1 %', mpn='UNI-ROYAL 0402WGF3300TCE', lcsc='C25104 (to confirm)', smt_pins_per_part='2', unit_price_usd='0.001')
new(refs='U608', desc='Single D flip-flop with preset/clear (R9 E-2 re-arm latch: CP = RELAY_EN, D = RD_N = N6_CLR_N, Q = N6_ARM), on 3V3D, Ioff',
    value='74LVC1G74', package='VSSOP-8 (DC)', rating_tolerance='1.65-5.5 V; inputs 5.5 V tolerant; Ioff', mpn='Nexperia 74LVC1G74DC,125',
    smt_pins_per_part='8', unit_price_usd='0.12')
new(refs='R900, R902, R904, R906, R908, R910, R912, R914', desc='487 kOhm 0.1 %: E-3 difference-divider Ra (V_L = VPOS x Ra/Rb = 1.80-2.00 V)',
    value='487 kOhm', package='0603', rating_tolerance='0.1 %, 25 ppm/K thin film, 75 V, 0.1 W', mpn='YAGEO RT0603BRD07487KL', lcsc='C861426', jlcpcb_class='Extended',
    jlcpcb_stock_or_sourcing='LCSC 1,840 (parts R9, 25 Sep 2026); RT0402 BRD is limited to 240 k', smt_pins_per_part='2', unit_price_usd='0.03')
new(refs='R920, R921, R922, R923', desc='E-3 timer charge resistor R_T from VPOS (R9 check E-24: 110 k, leakage-robust)', value='110 kOhm', package='0402',
    rating_tolerance=TF, mpn='YAGEO RT0402BRD07110KL', lcsc='C705063', jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC 8,000 (parts R9 check, 25 Sep 2026)',
    smt_pins_per_part='2', unit_price_usd='0.02')
new(refs='Q623, Q624, Q625, Q626', desc='E-3 timer reset switch (C = timer node, E = GND, B = level-comparator output; R9 check E-24: no clamp diode, no R_D)',
    value='MMBT3904', package='SOT-23', rating_tolerance='40 V, 200 mA; VCE(sat) <= 0.2 V; ICBO <= 50 nA; VEB 6 V', mpn='JSCJ MMBT3904 (RANGE:100-300)',
    lcsc='C20526', jlcpcb_class='Basic', jlcpcb_stock_or_sourcing='as the Q612/Q614 line (C20526)', smt_pins_per_part='3', unit_price_usd='0.0104')
new(refs='R924', desc='E-3 timer threshold divider top (R9 check: V_T = 0.5889 x VPOS)', value='69.8 kOhm', package='0402',
    rating_tolerance=TF, mpn='YAGEO RT0402BRD0769K8L', lcsc='C852893', jlcpcb_class='global sourcing',
    jlcpcb_stock_or_sourcing='LCSC stock only from a 2024 page -> treat as JLCPCB global sourcing; DigiKey US 0 until Feb 2027, DigiKey SG 6,577 (parts R9 check)', smt_pins_per_part='2', unit_price_usd='0.02',
    note='Same-spec alternate: Vishay TNPW040269K8BEED (0402, 0.1 %, 25 ppm), DigiKey 72,019')
add('R653', ['R925'], 'R925 E-3 V_T divider bottom (R9 check)')
# R9 parts E-21: RT0402 BRD is limited to 4.7 ohm-240 k -> U605 divider lines re-picked
r = line('R672'); r['refs'] = 'R672'; r['qty'] = '1'; r['desc'] = '1V3-good reference top (VPOS divider)'
new(refs='R675, R682', desc='U605 3V3A dividers top (R9: re-scaled to 0402 <= 240 k)', value='44.2 kOhm', package='0402', rating_tolerance=TF,
    mpn='YAGEO RT0402BRD0744K2L', lcsc='C705633', jlcpcb_class='Extended',
    jlcpcb_stock_or_sourcing='LCSC ~19,650 (LCSC alternatives list 18 Sep 2026; parts R9); DigiKey 27,744', smt_pins_per_part='2', unit_price_usd='0.02')
r = line('R676'); r.update(desc='U605 3V3A dividers bottom (IN-) (R9: re-scaled, was 953 k)', value='200 kOhm', mpn='YAGEO RT0402BRD07200KL', lcsc='C728556',
                           jlcpcb_class='global sourcing', jlcpcb_stock_or_sourcing='LCSC out of stock (min/multiple 50) -> JLCPCB global sourcing; DigiKey 171,161 (parts R9, 25 Sep 2026)')
r = line('R677'); r.update(desc='U605 3V3M reference dividers top (IN+) (R9: 300 k 0603, was 330 k 0402)', value='300 kOhm', package='0603',
                           rating_tolerance='0.1 %, 25 ppm/K thin film, 75 V, 0.1 W', mpn='YAGEO RT0603BRD07300KL', lcsc='C705762', jlcpcb_class='Extended',
                           jlcpcb_stock_or_sourcing='LCSC 65,780+ (parts R9, 25 Sep 2026)')
r = line('R678'); r.update(package='0603', rating_tolerance='0.1 %, 25 ppm/K thin film, 75 V, 0.1 W', mpn='YAGEO RT0603BRD071ML', lcsc='C326730',
                           jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC 1,200 (parts R9, 25 Sep 2026); 10 per board', unit_price_usd='0.03')
new(refs='C631, C632, C633, C634', desc='E-3 timer capacitor C_T (R9 check E-24: 220 nF, +-2 % required; T_P 19.5-23.2 ms incl. 1 uA leakage)',
    value='220 nF', package='2416 (6041 metric), 6.0 x 4.1 x 2.8 mm (3.0 max)', rating_tolerance='50 V DC PPS film +-2 % (G), TC bound +-0.5 % 0-60 C; MSL 1',
    mpn='Panasonic ECH-U1H224GX9', lcsc='none', jlcpcb_class='global sourcing',
    jlcpcb_stock_or_sourcing='Mouser 19,207, DigiKey 62; US$ 1.36 at 10 (parts R9 check); not at LCSC -> JLCPCB global sourcing; order remark: confirm reflow (ECHU 260 C, <= 95 s above 220 C) for the 2416 size, else owner-fitted',
    smt_pins_per_part='2', unit_price_usd='1.36')
ru = line('U605'); ru['note'] = (ru['note'] + '; R9 drop-in alternate: onsemi NCS3402DR2G (SOIC-8, same dual-comparator pinout; DigiKey lists it as a similar '
              'alternate) - check IQ <= 1 uA/ch, VOL <= 0.3 V at 50 uA and the input range before use [not verified]')
w = csv.DictWriter(open('bom_rows.csv', 'w', newline='', encoding='utf-8'), fieldnames=fields); w.writeheader(); w.writerows(rows)

nl = list(csv.DictReader(open('netlist_ve.csv.bak', newline='', encoding='utf-8-sig')))
nf = list(nl[0].keys())
NOTES = {'R675': '3V3A divider A top 44.2 k (R9)', 'R676': '3V3A divider A bottom 200 k (R9)', 'R677': 'reference A top 300 k 0603 (R9)',
         'R678': 'reference A bottom 1.00 M 0603 (R9)', 'R682': '3V3A divider B top 44.2 k (R9)', 'R683': '3V3A divider B bottom 200 k (R9)',
         'R684': 'reference B top 300 k 0603 (R9)', 'R685': 'reference B bottom 1.00 M 0603 (R9)'}
for x in nl:
    if x['refdes'] in NOTES and x['pin'] == '1':
        x['note'] = NOTES[x['refdes']]
    if x['refdes'] == 'R665' and x['pin'] == '1':
        x['note'] = 'MCLK tap 330 ohm at the U301 XI pin (R9 E-11; layout rule with digital)'
    if x['refdes'] == 'U606' and x['pin'] == '10':
        x.update(net='N6_H', note='ch4 (R9 E-2): H-OK detector, IN- = N6_H')
    if x['refdes'] == 'U606' and x['pin'] == '11':
        x.update(net='N6_HREF', note='ch4 IN+ = HREF 2.88-3.11 V')
    if x['refdes'] == 'U606' and x['pin'] == '13':
        x.update(net='N6_TRIP', note='ch4 OUT: low while H > HREF; high (R690) on a trip or with U606 unpowered')
    if x['refdes'] == 'Q617' and x['pin'] == '2':
        x.update(net='N6_M3', note='R9 E-2: source to Q622 (re-arm latch switch)')
def P(ref, pin, name, net, note=''):
    nl.append(dict(refdes=ref, pin=str(pin), pin_name=name, net=net, note=note))
# E-2
for pin, name, net, note in ((1, 'CP', 'RELAY_EN', 'R9 E-2 re-arm latch: rising RELAY_EN edge arms if H OK'), (2, 'D', 'N6_CLR_N', ''),
                             (3, 'Q_N', 'NC', 'unused output, no copper'), (4, 'GND', 'GND', ''), (5, 'Q', 'N6_ARM', ''),
                             (6, 'RD_N', 'N6_CLR_N', 'async clear dominates (any trip)'), (7, 'SD_N', '3V3D', 'preset inactive'),
                             (8, 'VCC', '3V3D', '')):
    P('U608', pin, name, net, note)
P('Q621', 1, 'G', 'N6_TRIP', 'R9 E-2: TRIP high -> CLR_N low'); P('Q621', 2, 'S', 'GND'); P('Q621', 3, 'D', 'N6_CLR_N')
P('Q622', 1, 'G', 'N6_ARMG', 'R9 E-2: LED return switch, on only while armed'); P('Q622', 2, 'S', 'GND'); P('Q622', 3, 'D', 'N6_M3')
two = [('R690', '3V3D', 'N6_TRIP', 'TRIP pull-up 330 k (fail-safe high when U606 is unpowered)'),
       ('R691', '3V3D', 'N6_CLR_N', 'CLR_N pull-up 100 k'), ('R692', 'N6_ARM', 'N6_ARMG', 'Q622 gate 1 k'),
       ('R693', 'VPOS', 'N6_HREF', 'HREF top 100 k'), ('R694', 'N6_HREF', 'GND', 'HREF bottom 330 k'),
       ('R695', 'N6_ARM', 'N6_ARM_MCU', 'ARM readback 100 k to MCU PB0 (digital)'), ('C630', '3V3D', 'GND', 'U608 decoupling'),
       ('R696', 'N6_ARMG', 'GND', 'Q622 gate pull-down 100 k (R9 check E-23: R692 open or U608 unpowered -> Q622 off)')]
# E-3
for c, legp, legn, u, rbase, dd, cc in (('L', 'LEG_LP', 'LEG_LN', 'U609', 900, 'D611', (631, 632, 635, 636)),
                                         ('R', 'LEG_RP', 'LEG_RN', 'U610', 908, 'D612', (633, 634, 637, 638))):
    A, B, C, D = f'N6_DA_{c}', f'N6_DB_{c}', f'N6_DC_{c}', f'N6_DD_{c}'
    OLP, OLN, TLP, TLN = f'N6_OLP_{c}', f'N6_OLN_{c}', f'N6_TLP_{c}', f'N6_TLN_{c}'
    two += [(f'R{rbase}', legp, A, f'E-3 {c}: A = LEG_{c}P divider Ra 487 k'), (f'R{rbase+1}', A, 'GND', 'Rb 1.00 M to GND'),
            (f'R{rbase+2}', legn, B, f'E-3 {c}: B = LEG_{c}N divider Ra'), (f'R{rbase+3}', B, 'VPOS', 'Rb 1.00 M to VPOS'),
            (f'R{rbase+4}', legp, C, f'E-3 {c}: C = LEG_{c}P divider Ra'), (f'R{rbase+5}', C, 'VPOS', 'Rb 1.00 M to VPOS'),
            (f'R{rbase+6}', legn, D, f'E-3 {c}: D = LEG_{c}N divider Ra'), (f'R{rbase+7}', D, 'GND', 'Rb 1.00 M to GND')]
    ri = 916 if c == 'L' else 918
    two += [(f'R{ri}', 'VPOS', OLP, 'NPN base pull-up 330 k (R9 check)'), (f'R{ri+1}', 'VPOS', OLN, 'NPN base pull-up 330 k (R9 check)')]
    qn = 623 if c == 'L' else 625
    P(f'Q{qn}', 1, 'B', OLP, f'E-3 {c}+ timer reset NPN (R9 check)'); P(f'Q{qn}', 2, 'E', 'GND'); P(f'Q{qn}', 3, 'C', TLP)
    P(f'Q{qn+1}', 1, 'B', OLN, f'E-3 {c}- timer reset NPN (R9 check)'); P(f'Q{qn+1}', 2, 'E', 'GND'); P(f'Q{qn+1}', 3, 'C', TLN)
    rt = 920 if c == 'L' else 922
    two += [(f'R{rt}', 'VPOS', TLP, 'R_T 110 k'), (f'R{rt+1}', 'VPOS', TLN, 'R_T 110 k')]
    two += [(f'C{cc[0]}', TLP, 'GND', 'C_T 220 nF PPS film 2 %'), (f'C{cc[1]}', TLN, 'GND', 'C_T 220 nF PPS film 2 %'),
            (f'C{cc[2]}', 'VPOS', 'GND', f'{u} V+ decoupling'), (f'C{cc[3]}', 'VNEG', 'GND', f'{u} V- decoupling')]
    for pin, name, net, note in ((1, '2OUT', OLN, f'E-3 {c}: level {c}- sinks (NPN off, timer runs) while LEG_{c}N - LEG_{c}P > V_L'), (2, '1OUT', OLP, f'level {c}+ sinks while LEG_{c}P - LEG_{c}N > V_L'),
                                 (3, 'V+', 'VPOS', ''), (4, '1IN-', A, 'R9 check: inputs swapped'), (5, '1IN+', B, ''), (6, '2IN-', D, ''), (7, '2IN+', C, ''),
                                 (8, '3IN-', TLP, 'timer c+ (T > V_T -> N6_H low)'), (9, '3IN+', 'N6_VT', ''), (10, '4IN-', TLN, 'timer c-'),
                                 (11, '4IN+', 'N6_VT', ''), (12, 'V-', 'VNEG', ''), (13, '4OUT', 'N6_H', ''), (14, '3OUT', 'N6_H', '')):
        P(u, pin, name, net, note)
two += [('R924', 'VPOS', 'N6_VT', 'E-3 V_T divider top 69.8 k'), ('R925', 'N6_VT', 'GND', 'V_T divider bottom 100 k')]
for ref, n1, n2, note in two:
    P(ref, 1, '1', n1, note); P(ref, 2, '2', n2)
w = csv.DictWriter(open('netlist.csv', 'w', newline='', encoding='utf-8'), fieldnames=nf); w.writeheader(); w.writerows(nl)
print(f'BOM lines {len(rows)}, netlist rows {len(nl)}')
