#!/usr/bin/env python3
"""p11 - X-9 (review states #13): retune the leg DC-window filter R601-R604 / C601-C604 so that a full-scale
20 Hz square wave cannot trip at the worst AGED capacitance, keeping the 1 V <= 250 ms / 2 V <= 100 ms removal
limits and the 30/15 mJ energies.  Uses the p03 models (thresholds, ladder, square_peak, step_time).

Capacitance range [consistency_log C-25, parts stress table]: 2.2 uF X5R 10 % -> 1.79 ... 2.42 uF effective
(tolerance -10 %, temperature -5 %, ageing -5 %; the leg node has ~0 V DC so there is no DC-bias loss).
R: 1 % + 100 ppm/K x 40 K (as p03).  Thresholds unchanged (R607-R610, |VTH| 0.30 V).
"""
import numpy as np
import p03_detector as d3
from pcommon import A_FS, VPOS_MIN, VPOS_MAX, VNEG_MIN, VNEG_MAX

C_NOM = 2.2e-6
C_AGED_LO, C_AGED_HI = 1.79e-6 / C_NOM, 2.42e-6 / C_NOM
out = [__doc__]
ra = d3.e96(10e3 * (3.900 / 0.30 - 1)); ran = d3.e96(10e3 * (3.722 / 0.30 - 1))
out.append(f'C factor range used: {C_AGED_LO:.4f} ... {C_AGED_HI:.4f} (p03 round 2 used 0.85 ... 1.10)')
out.append(' R601-R604 | tau fast/slow ms | FS square: peak @20 Hz vs trip_min (margin) | corner Hz | t(1V) t(2V) ms | '
           'E_rail 16/32 mJ | frozen+-x legs only 32/16 mJ')
rows = []
for r1 in (105e3, 110e3, 113e3, 115e3, 118e3, 121e3):
    th = d3.thresholds(ra, 10e3, ran, 10e3, r1, 100e3)
    Af, Bf = d3.ladder(r1 * (1 - d3.R_TOL_FILT), C_NOM * C_AGED_LO)
    As, Bs = d3.ladder(r1 * (1 + d3.R_TOL_FILT), C_NOM * C_AGED_HI)
    pk = d3.square_peak(Af, Bf, 20.0, A_FS)
    fsq = d3.corner(Af, Bf, A_FS, th['trip_min'], kind='square')
    def trem(x, pol):
        vt = th['p_max'] if pol > 0 else th['n_max']
        return d3.step_time(As, Bs, x, vt) + d3.T_EXTRA
    t1 = max(trem(1.0, 1), trem(1.0, -1)); t2 = max(trem(2.0, 1), trem(2.0, -1))
    e16 = max(v * v / 16 * trem(v, p) for v, p in ((VPOS_MIN, 1), (VPOS_MAX, 1), (VNEG_MIN, -1), (VNEG_MAX, -1)))
    e32 = e16 / 2
    tf = r1 * (1 - d3.R_TOL_FILT) * C_NOM * C_AGED_LO * 1e3; ts = r1 * (1 + d3.R_TOL_FILT) * C_NOM * C_AGED_HI * 1e3
    rows.append((r1, pk, th['trip_min'], fsq, t1, t2, e16, e32))
    out.append(f' {r1/1e3:6.0f} k  | {tf:6.1f} / {ts:6.1f} | {pk:.4f} V vs {th["trip_min"]:.4f} V ({100*(1-pk/th["trip_min"]):5.1f} %) | '
               f'{fsq:5.1f} | {t1*1e3:6.1f} {t2*1e3:5.1f} | {e16*1e3:5.1f} / {e32*1e3:5.1f}')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
