#!/usr/bin/env python3
"""p17b - R9 E-3 variant scan: 2-section RC ladder (R1-C1-R2-C2, R2 = 10 x R1, C2 = C1/10, C0G 5 %) before the new
high-threshold leg windows; thresholds from VPOS/VNEG dividers (0.1 %).  Energies: min(new windows, old windows)."""
import numpy as np
import p03_detector as d3
from p17_r9_e3 import thr2, power, t_old, R_TOL, C_TOL_LO, C_TOL_HI, T_EXTRA
from pcommon import A_FS
out = [__doc__]
for rtop in (30.9e3, 29.4e3, 28.7e3):
    for tau in (0.010, 0.012, 0.014, 0.016):
        r1 = 100e3; c1 = tau / r1; r2 = 1.0e6; c2 = tau / r2
        vmin, vmax, vnom = thr2(rtop, 10e3, r1 + r2)
        Af, Bf = d3.ladder(r1 * (1 - R_TOL), c1 * C_TOL_LO, r2 * (1 - R_TOL), c2 * C_TOL_LO)
        As, Bs = d3.ladder(r1 * (1 + R_TOL), c1 * C_TOL_HI, r2 * (1 + R_TOL), c2 * C_TOL_HI)
        pk = d3.sine_peak(Af, Bf, 20.0 * (1 - 1e-4), A_FS)
        sq = d3.corner(Af, Bf, A_FS, vmin, fmin=5.0, fmax=80.0, kind='square')
        res = []
        for rl, bal in ((16.0, True), (32.0, True)):
            wm = (0.0, 0.0, 0.0)
            for x in np.linspace(0.34, 4.1, 377):
                p, xl = power(x, rl, bal)
                if xl < 0.34:
                    continue
                tn = d3.step_time(As, Bs, xl, vmax) + T_EXTRA if xl > vmax else np.inf
                e = p * min(tn, t_old(xl))
                if e > wm[0]:
                    wm = (e, xl, min(tn, t_old(xl)))
            res.append(wm)
        out.append(f'2-pole tau {tau*1e3:4.1f}+{tau*1e3:4.1f} ms, Vth2 {vmin:.3f}..{vmax:.3f} V: FS 20 Hz sine peak {pk:.3f} V '
                   f'(margin {100*(1-pk/vmin):5.1f} %), square corner {sq:5.1f} Hz | worst 16 bal {res[0][0]*1e3:5.1f} mJ (x {res[0][1]:.2f}, '
                   f'{res[0][2]*1e3:.0f} ms), 32 bal {res[1][0]*1e3:5.1f} mJ (x {res[1][1]:.2f}, {res[1][2]*1e3:.0f} ms)')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
