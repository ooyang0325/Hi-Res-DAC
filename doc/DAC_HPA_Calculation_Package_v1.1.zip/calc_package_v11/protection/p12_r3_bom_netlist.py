#!/usr/bin/env python3
"""p12 - R3 (review fixes round 3) BOM and netlist update: X-9 value change (R601-R604 115 k) and the X-6 supervisor
(U605, U606, U607, Q619, Q620, D609, D610, R665-R689, C623-C629).  Reads the round-2 files (bom_rows_r2.csv.bak,
netlist_r2.csv.bak) and writes bom_rows.csv / netlist.csv.  LCSC codes marked 'TBC' are not verified."""
import csv
B_IN, N_IN = 'bom_rows_r2.csv.bak', 'netlist_r2.csv.bak'
rows = list(csv.DictReader(open(B_IN, newline='', encoding='utf-8-sig')))
fields = list(rows[0].keys())
def find(pred):
    for r in rows:
        if pred(r):
            return r
    raise KeyError
def add_refs(r, refs, extra_desc=None):
    cur = [x.strip() for x in r['refs'].split(',')]
    cur += refs
    r['refs'] = ', '.join(cur); r['qty'] = str(len(cur))
    if extra_desc:
        r['desc'] = r['desc'] + '; ' + extra_desc
# ---- X-9
r = find(lambda r: r['refs'].startswith('R601'))
r.update(desc='Leg DC-window filter resistor (tau 253 ms nominal with 2.2 uF; R3 X-9: aged-C corner)', value='115 kOhm',
         mpn='UNI-ROYAL 0402WGF1153TCE', lcsc='TBC', jlcpcb_class='Basic/Extended TBC',
         jlcpcb_stock_or_sourcing='not verified (R3)', note='R3 (X-9): was 105 kOhm; FS 20 Hz square no trip down to C -24 % (aged corner -18.6 %)')
r = find(lambda r: r['refs'].startswith('C601'))
r['desc'] = 'Leg DC-window filter capacitor (with 115 kOhm; aged range 1.79-2.42 uF used, consistency_log C-25)'
# ---- existing lines extended
add_refs(find(lambda r: r['refs'].startswith('U601')), ['U606'], 'U606 (R3 X-6): 1V3-good, MCLK-alive, 3V3A-good repeater into N6_H on VPOS/VNEG')
add_refs(find(lambda r: r['refs'].startswith('Q616')), ['Q619', 'Q620'], 'Q619/Q620 (R3 X-6): 3V3A-good pull-downs on N2_AVCC_EN_G / AUD_EN')
add_refs(find(lambda r: r['refs'].startswith('R645')), ['R665'], 'R665 (R3): MCLK tap at the U301 XI pin')
add_refs(find(lambda r: r['refs'].startswith('R646')), ['R667', 'R680', 'R687'], 'R667 MCLK-node series, R680/R687 U605 output pull-ups (R3)')
add_refs(find(lambda r: r['refs'].startswith('R653')), ['R669', 'R673'], 'R669/R673 VPOS reference dividers bottom (R3)')
add_refs(find(lambda r: r['refs'].startswith('R609')), ['R670'], 'R670 1V3 series into U606 ch1 (R3)')
add_refs(find(lambda r: r['refs'].startswith('C612')), ['C623', 'C626', 'C627', 'C628'], 'C623 U607 VCC (3V3D), C626/C627 U606 V+/V-, C628 U605 VCC (3V3M) (R3)')
# ---- new lines
base = dict((k, '') for k in fields)
def new(**kw):
    d = dict(base); d.update({'block': '6 Protection and control', 'fit': 'Yes', 'leadless': 'No', 'tht_pins_per_part': '0'}); d.update(kw)
    d['qty'] = str(len([x for x in d['refs'].split(',') if x.strip()]))
    rows.append(d)
TF = '0.1 %, 25 ppm/K thin film'
new(refs='U605', desc='Dual nanopower comparator, open drain, on 3V3M: two independent 3V3A-good channels (X-6)', value='TLV3402',
    package='SOIC-8', rating_tolerance='2.5-16 V; IQ <= 0.95 uA/ch (-40..125 C); VOS <= 4.4 mV; IB <= 1.5 nA; VOL <= 0.3 V at 50 uA; CM -0.1 V..VCC+5 V',
    mpn='TI TLV3402IDR', lcsc='TBC', jlcpcb_class='Extended TBC', jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='8',
    unit_price_usd='1.20', datasheet_url='https://www.ti.com/lit/ds/symlink/tlv3402.pdf', note='price estimate, not verified')
new(refs='U607', desc='Schmitt-trigger buffer, MCLK activity detector input (3V3D, Ioff)', value='74AUP1G17', package='SOT-353 (SC-70-5)',
    rating_tolerance='0.8-3.6 V; VT+ 1.88-2.32 V, VT- 0.88-1.24 V at 3.0 V; CI 1.1 pF typ; Ioff', mpn='Nexperia 74AUP1G17GW,125',
    lcsc='TBC', jlcpcb_class='Extended TBC', jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='5', unit_price_usd='0.10',
    datasheet_url='https://assets.nexperia.com/documents/data-sheet/74AUP1G17.pdf')
new(refs='D609', desc='Dual Schottky, series (BAS70-04): MCLK pump clamp + rectifier', value='BAS70-04', package='SOT-23',
    rating_tolerance='70 V, 70 mA; VF <= 410 mV at 1 mA; Cd <= 2 pF', mpn='Nexperia BAS70-04,215', lcsc='TBC', jlcpcb_class='TBC',
    jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='3', unit_price_usd='0.03', datasheet_url='https://assets.nexperia.com/documents/data-sheet/BAS70_SER.pdf')
new(refs='D610', desc='Schottky, 1V3-good boot-test injection (blocks a mis-driven PB8)', value='BAS70', package='SOT-23',
    rating_tolerance='70 V, 70 mA; VF <= 410 mV at 1 mA', mpn='Nexperia BAS70,215', lcsc='TBC', jlcpcb_class='TBC',
    jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='3', unit_price_usd='0.03', datasheet_url='https://assets.nexperia.com/documents/data-sheet/BAS70_SER.pdf')
for refs, desc, val, tol, mpn in [
    ('R666', 'MCLK pump bleed (tau with C625)', '1.00 MOhm', '1 %, 100 ppm/K', 'UNI-ROYAL 0402WGF1004TCE'),
    ('R668', 'MCLK-alive threshold divider top (VPOS x 100/966 = 0.404 V)', '866 kOhm', TF, 'YAGEO RT0402BRD07866KL'),
    ('R672, R675, R682', '237 kOhm 0.1 %: 1V3-good reference top (R672), 3V3A dividers top (R675, R682)', '237 kOhm', TF, 'YAGEO RT0402BRD07237KL'),
    ('R676, R683', '3V3A dividers bottom (U605 IN-)', '953 kOhm', TF, 'YAGEO RT0402BRD07953KL'),
    ('R677, R684', '3V3M reference dividers top (U605 IN+)', '330 kOhm', TF, 'YAGEO RT0402BRD07330KL'),
    ('R678, R685', '3V3M reference dividers bottom (U605 IN+)', '1.00 MOhm', TF, 'YAGEO RT0402BRD071ML'),
    ('R679, R686', 'U605 hysteresis (output to IN+)', '22 MOhm', '1 %, 100 ppm/K', 'UNI-ROYAL 0402WGF2205TCE'),
    ('R671', 'U606 ch1 hysteresis from N6_H', '2.2 MOhm', '1 %, 100 ppm/K', 'UNI-ROYAL 0402WGF2204TCE'),
    ('R674', '1V3-good boot-test injection (PB8 via D610)', '2.2 kOhm', '1 %', 'UNI-ROYAL 0402WGF2201TCE'),
    ('R681', 'U605A output to U606 ch3 (limits injection into the unpowered U606)', '4.7 MOhm', '1 %, 100 ppm/K', 'UNI-ROYAL 0402WGF4704TCE'),
    ('R688, R689', 'U605 output readback to MCU PA12 / PB9 (a mis-driven pin cannot mask the gate)', '470 kOhm', '1 %', 'UNI-ROYAL 0402WGF4703TCE')]:
    new(refs=refs, desc=desc, value=val, package='0402', rating_tolerance=tol, mpn=mpn, lcsc='TBC', jlcpcb_class='TBC',
        jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='2', unit_price_usd='0.002' if '1 %' in tol else '0.05')
new(refs='C624', desc='MCLK pump capacitor', value='100 pF', package='0402', rating_tolerance='50 V C0G +-5 %', mpn='Samsung CL05C101JB5NNNC',
    lcsc='C1546', jlcpcb_class='Basic', jlcpcb_stock_or_sourcing='as C103 (consistency_log C-32)', smt_pins_per_part='2', unit_price_usd='0.002')
new(refs='C625', desc='MCLK pump hold capacitor (dead detection <= 0.42 ms)', value='82 pF', package='0402', rating_tolerance='50 V C0G +-5 %',
    mpn='Samsung CL05C820JB5NNNC', lcsc='TBC', jlcpcb_class='TBC', jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='2', unit_price_usd='0.002')
new(refs='C629', desc='1V3-good input filter (tau 10 us with R670)', value='1 nF', package='0402', rating_tolerance='50 V C0G +-5 %',
    mpn='Samsung CL05C102JB5NNNC', lcsc='TBC', jlcpcb_class='TBC', jlcpcb_stock_or_sourcing='not verified (R3)', smt_pins_per_part='2', unit_price_usd='0.003')
w = csv.DictWriter(open('bom_rows.csv', 'w', newline='', encoding='utf-8'), fieldnames=fields); w.writeheader(); w.writerows(rows)

# ---------------- netlist
nl = list(csv.DictReader(open(N_IN, newline='', encoding='utf-8-sig')))
nf = list(nl[0].keys())
for r in nl:
    if r['refdes'] in ('R601', 'R602', 'R603', 'R604') and r['pin'] == '1':
        r['note'] = 'leg DC-window filter 115 k (R3 X-9)'
def P(ref, pin, name, net, note=''):
    nl.append(dict(refdes=ref, pin=str(pin), pin_name=name, net=net, note=note))
# U605 TLV3402 (SOIC-8: 1 OUT1, 2 IN1-, 3 IN1+, 4 GND, 5 IN2+, 6 IN2-, 7 OUT2, 8 VCC)
P('U605', 1, 'OUT1', 'N6_V3AG_A', 'TLV3402 on 3V3M: ch1 3V3A good -> Q619 (N2_AVCC_EN_G); output low = good; ch2 -> Q620 (AUD_EN)')
P('U605', 2, 'IN1-', 'N6_V3A_DA'); P('U605', 3, 'IN1+', 'N6_V3R_A'); P('U605', 4, 'GND', 'GND')
P('U605', 5, 'IN2+', 'N6_V3R_B'); P('U605', 6, 'IN2-', 'N6_V3A_DB'); P('U605', 7, 'OUT2', 'N6_V3AG_B'); P('U605', 8, 'VCC', '3V3M')
# U606 TLV1704 (TSSOP-14 as U601)
u606 = [(1, '2OUT', 'N6_H', 'ch2 MCLK alive'), (2, '1OUT', 'N6_H', 'ch1 1V3 good'), (3, 'V+', 'VPOS', ''), (4, '1IN-', 'N6_REF13', ''),
        (5, '1IN+', 'N6_V13_CMP', ''), (6, '2IN-', 'N6_REFMCK', ''), (7, '2IN+', 'N6_MCK_CMP', ''), (8, '3IN-', 'N6_V3AG_S', ''),
        (9, '3IN+', 'N6_REF13', ''), (10, '4IN-', 'VNEG', 'spare channel: IN+ GND > IN- VNEG, output off'), (11, '4IN+', 'GND', ''),
        (12, 'V-', 'VNEG', ''), (13, '4OUT', 'NC', 'spare output, no copper'), (14, '3OUT', 'N6_H', 'ch3 3V3A-good repeater')]
for pin, name, net, note in u606:
    P('U606', pin, name, net, note if pin != 1 else 'TLV1704 on VPOS/VNEG, outputs on N6_H (tolerate H at ~VNEG): ch1 1V3 good, ch2 MCLK alive, ch3 3V3A repeater, ch4 spare')
# U607 74AUP1G17GW (SOT-353: 1 n.c., 2 A, 3 GND, 4 Y, 5 VCC)
P('U607', 1, 'NC', 'NC', 'n.c. pin, no copper'); P('U607', 2, 'A', 'N6_MCK_IN', 'MCLK activity buffer on 3V3D (Ioff)')
P('U607', 3, 'GND', 'GND'); P('U607', 4, 'Y', 'N6_MCK_BUF'); P('U607', 5, 'VCC', '3V3D')
# D609 BAS70-04 (1 A1, 2 K2, 3 K1/A2)
P('D609', 1, 'A1', 'GND', 'pump clamp diode anode'); P('D609', 2, 'K2', 'N6_MCK_RC', 'rectifier cathode'); P('D609', 3, 'K1/A2', 'N6_PMP', 'common node')
# D610 BAS70 (1 A, 2 n.c., 3 K)
P('D610', 1, 'A', 'N6_V13_TI', '1V3-good test injection'); P('D610', 2, 'NC', 'NC', 'n.c.'); P('D610', 3, 'K', 'N6_V13_TEST', 'to MCU PB8 (open drain), digital interface request')
# Q619/Q620 AO3400A (1 G, 2 S, 3 D)
P('Q619', 1, 'G', 'N6_V3AG_A', '3V3A-good pull-down on N2_AVCC_EN_G (U206 input B)'); P('Q619', 2, 'S', 'GND'); P('Q619', 3, 'D', 'N2_AVCC_EN_G')
P('Q620', 1, 'G', 'N6_V3AG_B', '3V3A-good pull-down on AUD_EN (TLV767 EN, U303 via 3V3D, Q504)'); P('Q620', 2, 'S', 'GND'); P('Q620', 3, 'D', 'AUD_EN')
two = [('R665', 'MCLK', 'N6_MCK_IN', 'MCLK tap 1 k at the U301 XI pin (after R203); adds <= 1.3 pF'),
       ('R666', 'N6_MCK_RC', 'GND', 'pump bleed 1 M'), ('R667', 'N6_MCK_RC', 'N6_MCK_CMP', 'series 100 k into U606 ch2'),
       ('R668', 'VPOS', 'N6_REFMCK', 'MCLK threshold top 866 k'), ('R669', 'N6_REFMCK', 'GND', 'MCLK threshold bottom 100 k'),
       ('R670', '1V3', 'N6_V13_CMP', '1V3 series 10 k'), ('R671', 'N6_H', 'N6_V13_CMP', 'hysteresis 2.2 M'),
       ('R672', 'VPOS', 'N6_REF13', '1V3 reference top 237 k'), ('R673', 'N6_REF13', 'GND', '1V3 reference bottom 100 k'),
       ('R674', 'N6_V13_CMP', 'N6_V13_TI', 'test injection 2.2 k'),
       ('R675', '3V3A', 'N6_V3A_DA', '3V3A divider A top 237 k'), ('R676', 'N6_V3A_DA', 'GND', '3V3A divider A bottom 953 k'),
       ('R677', '3V3M', 'N6_V3R_A', 'reference A top 330 k'), ('R678', 'N6_V3R_A', 'GND', 'reference A bottom 1.00 M'),
       ('R679', 'N6_V3AG_A', 'N6_V3R_A', 'hysteresis A 22 M'), ('R680', '3V3M', 'N6_V3AG_A', 'pull-up A 100 k'),
       ('R681', 'N6_V3AG_A', 'N6_V3AG_S', 'to U606 ch3 4.7 M'),
       ('R682', '3V3A', 'N6_V3A_DB', '3V3A divider B top 237 k'), ('R683', 'N6_V3A_DB', 'GND', '3V3A divider B bottom 953 k'),
       ('R684', '3V3M', 'N6_V3R_B', 'reference B top 330 k'), ('R685', 'N6_V3R_B', 'GND', 'reference B bottom 1.00 M'),
       ('R686', 'N6_V3AG_B', 'N6_V3R_B', 'hysteresis B 22 M'), ('R687', '3V3M', 'N6_V3AG_B', 'pull-up B 100 k'),
       ('R688', 'N6_V3AG_A', 'N6_V3AG_A_MCU', 'readback A to MCU PA12 (digital interface request)'),
       ('R689', 'N6_V3AG_B', 'N6_V3AG_B_MCU', 'readback B to MCU PB9 (digital interface request)'),
       ('C623', '3V3D', 'GND', 'U607 VCC decoupling 100 nF'), ('C624', 'N6_MCK_BUF', 'N6_PMP', 'pump 100 pF C0G'),
       ('C625', 'N6_MCK_RC', 'GND', 'hold 82 pF C0G'), ('C626', 'VPOS', 'GND', 'U606 V+ decoupling'), ('C627', 'VNEG', 'GND', 'U606 V- decoupling'),
       ('C628', '3V3M', 'GND', 'U605 VCC decoupling'), ('C629', 'N6_V13_CMP', 'GND', '1V3 input filter 1 nF C0G')]
for ref, n1, n2, note in two:
    P(ref, 1, '1', n1, note); P(ref, 2, '2', n2)
w = csv.DictWriter(open('netlist.csv', 'w', newline='', encoding='utf-8'), fieldnames=nf); w.writeheader(); w.writerows(nl)
print(f'BOM lines {len(rows)}, netlist rows {len(nl)}')
