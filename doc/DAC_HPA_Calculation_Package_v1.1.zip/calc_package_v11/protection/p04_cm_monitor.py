#!/usr/bin/env python3
"""p04 - I/V common-mode window (new): catches the balanced +-x hardware failures (R8-C3: failed
I/V op-amp, stuck DAC pin), the DAC reset state and a missing 3V3A in ~1 ms, independent of content.

Principle: the two DAC pins of a channel carry complementary currents, so the mean of the two I/V
outputs (IV_xA + IV_xB)/2 is a content-independent constant (VREF + a small DC term). A failed
I/V op-amp or a stuck DAC pin moves this mean by >= 0.4 V; normal content does not move it.

Circuit (per channel): IV_xA -> R_CM 100 k -> N6_CMx <- R_CM 100 k <- IV_xB; C_CM 10 nF to GND.
Two TLV1704 comparators: IN- = N6_CMx vs IN+ = CMTH_HI (output low if CM > HI);
IN+ = N6_CMx vs IN- = CMTH_LO (output low if CM < LO). Outputs on node H (wired-OR).
Threshold chain from 3V3A (ratiometric to VREF): 3V3A -R_T1- CMTH_HI -R_T2- CMTH_LO -R_T3- GND,
plus R_T4 from VPOS into CMTH_LO so that CMTH_LO > 0 when 3V3A is absent (-> permit off).
"""
import numpy as np
from pcommon import *
from p03_detector import e96, VOS, IB, T_H_FALL

# ---------------- CM of the I/V pair, all ratios to 3V3A (analog stream round 2: analog_budget.txt 2, BOM 05:56) ------------
VREF_R = (0.50526, 0.50689)              # VREF/3V3A = 0.50607 (R431 9.76 k / R432 10.0 k 0.1 %), tolerance band [analog CALC]
VC_R = (0.5000, 1.702 / 3.3)             # DAC centre/AVCC: 1.65 V (voltage model) or 1.702 V (current model) [DS ES9018K2M p.31]
RS_NOM, RS_TOL = 806.0, 0.11             # DAC output resistance +-11 % [DS p.31]
RF = 698.0 * 1.0016                      # I/V feedback R423-R426 698 ohm 0.1 % 25 ppm (+-0.16 %) [analog BOM]  (round 1: 836 ohm)
RF_R = (698.0 * 0.9984, 698.0 * 1.0016)   # both tolerance limits (the reset-state floor uses the lower one)
G_LEG = 2.00 / 1.98                      # leg difference gain R2/R1 = 2.00 k / 1.98 k [analog R2.14/R2.15]  (round 1: 1.0)
W_PIN = (1 / (1 - RS_TOL)) / (1 / (1 - RS_TOL) + 1 / (1 + RS_TOL))   # largest share of one pin at the full Rs mismatch
A_IV_PAIR = A_FS / G_LEG                 # I/V differential peak at calibrated full scale (A_FS per leg incl. +0.15 dB, pcommon)
A_UNTRIM = 2.165 * 2 ** 0.5              # untrimmed 0 dBFS per leg, highest-gain unit [analog R2.14] - trim-lost check only
M_PINS = 0.22                            # pin-to-pin Rs mismatch bound = full +-11 % range (matching not specified) [ASSUMP, worst]
MCLK, MCLK_TOL, SS_TIME = 80.0e6, 50e-6, 10   # X201 Kyocera KC2520K80.0000C1GE00, +-50 ppm (D-3 revised); ESS reg 14 soft_start_time = 10 [DS]
IV_SWING = 0.60                          # OPA2210 swing (V+) - 0.6 V at RL 600 ohm, 25 C [DS SBOS924H via parts FU3]; the reset load is ~830 ohm
IV_VF = 0.30                             # R3 (analog X-8 adopted): U403/U404 on N4_VPOS_IV/N4_VNEG_IV = VPOS/VNEG through D411/D412, VF <= 0.30 V [analog r3_fixes]
T_CM_FIX = 3 * 50e3 * 10e-9 * 1.1 + T_H_FALL + AQV_TOFF_DESIGN   # large-deviation removal: 3 tau_CM + H fall + tOFF


def cm_range(v3a, a_leg=A_FS):
    """Normal CM band: DC term (both pins at the same Rs extreme) +- content ripple of a pin pair with the full Rs mismatch."""
    lo, hi = np.inf, -np.inf
    rip = a_leg / G_LEG * (W_PIN - 0.5)
    for vr in VREF_R:
        for vc in VC_R:
            for rs in (RS_NOM * (1 - RS_TOL), RS_NOM * (1 + RS_TOL)):
                for rf in RF_R:
                    dc = vr * v3a + (rf / rs) * (vr - vc) * v3a
                    lo = min(lo, dc - rip); hi = max(hi, dc + rip)
    return lo, hi


def cm_dc_range(v3a):
    lo, hi = np.inf, -np.inf
    for vr in VREF_R:
        for vc in VC_R:
            for rs in (RS_NOM * (1 - RS_TOL), RS_NOM * (1 + RS_TOL)):
                for rf in RF_R:
                    dc = vr * v3a + (rf / rs) * (vr - vc) * v3a
                    lo = min(lo, dc); hi = max(hi, dc)
    return lo, hi


def main():
    out = [__doc__]
    # threshold targets at 3V3A = 3.3 V
    lo_cm, hi_cm = cm_range(3.3)
    out.append(f'Round 2 inputs (analog stream): VREF/3V3A {VREF_R[0]}-{VREF_R[1]}, RF {RF:.1f} ohm, leg gain {G_LEG:.4f}, '
               f'Rs {RS_NOM:.0f} ohm +-{RS_TOL*100:.0f} %; content ripple = A_FS/G x (w - 0.5) = {A_IV_PAIR*(W_PIN-0.5)*1e3:.0f} mV '
               f'(pin share w = {W_PIN:.3f} at {M_PINS*100:.0f} % mismatch)')
    out.append(f'Normal CM range at 3V3A = 3.300 V (all tolerances, content ripple with '
               f'{M_PINS*100:.0f} % pin mismatch): {lo_cm:.3f} ... {hi_cm:.3f} V')
    HI_T, LO_T = 2.05, 1.31            # chosen window (V at 3V3A = 3.3 V): ~0.1 V beyond the 1.43-1.93 V normal range
    # divider: pick R_T3 = 10 k and solve with the VPOS injection R_T4
    rt4 = 330e3
    rt1, rt2, rt3 = 10.0e3, 6.8e3, 10.0e3          # verified LCSC parts (RT0402BRD0710KL C190095, RP0402BRD076K8L C33900832)
    G = np.array([[1/rt1 + 1/rt2, -1/rt2], [-1/rt2, 1/rt2 + 1/rt3 + 1/rt4]])
    I = np.array([3.3/rt1, VPOS_NOM/rt4])
    vh, vl = np.linalg.solve(G, I)
    best = (0, rt1, rt2, rt3, vh, vl)
    _, rt1, rt2, rt3, vh, vl = best
    out.append(f'Threshold chain: R_T1 = {rt1/1e3:.2f} k, R_T2 = {rt2/1e3:.2f} k, R_T3 = {rt3/1e3:.2f} k (0.1 %), '
               f'R_T4 = {rt4/1e3:.0f} k (1 %) from VPOS -> HI {vh:.3f} V, LO {vl:.3f} V (nominal)')

    def nodes(v3a, vpos, t1=1, t2=1, t3=1, t4=1):
        G = np.array([[1/(rt1*t1) + 1/(rt2*t2), -1/(rt2*t2)],
                      [-1/(rt2*t2), 1/(rt2*t2) + 1/(rt3*t3) + 1/(rt4*t4)]])
        I = np.array([v3a/(rt1*t1), vpos/(rt4*t4)])
        return np.linalg.solve(G, I)
    tol = 0.001 + 25e-6 * 40; tol4 = 0.01 + 100e-6 * 40
    # worst-case thresholds over tolerance corners
    his, los = [], []
    for v3a in (V3V3_MIN, V3V3_MAX):
        for vpos in (VPOS_MIN, VPOS_MAX):
            for s in np.array(np.meshgrid(*[[-1, 1]] * 4)).T.reshape(-1, 4):
                vh_, vl_ = nodes(v3a, vpos, 1 + s[0]*tol, 1 + s[1]*tol, 1 + s[2]*tol, 1 + s[3]*tol4)
                lo_c, hi_c = cm_range(v3a)
                his.append((vh_ - VOS - IB * 50e3 - 2 * IB * 3e3 - hi_c, vh_, v3a))
                los.append((lo_c - (vl_ + VOS + IB * 50e3 + 2 * IB * 3e3), vl_, v3a))
    m_hi = min(his); m_lo = min(los)
    out.append(f'No-false-trip margin in normal operation (worst corner): upper {m_hi[0]*1e3:.0f} mV, '
               f'lower {m_lo[0]*1e3:.0f} mV  (TLV1704 VOS 5.5 mV, IB 20 nA x 50 k)')

    # detection of faults (3V3A nominal-min corner, thresholds at their worst)
    hi_max = max(h[1] for h in his) + VOS + IB * 50e3
    lo_min = min(l[1] for l in los) - VOS - IB * 50e3
    out.append(f'Worst-case trip thresholds: CM > {hi_max:.3f} V or CM < {lo_min:.3f} V')
    vref_min, vref_max = VREF_R[0] * V3V3_MIN, VREF_R[1] * V3V3_MAX
    a_iv = A_IV_PAIR * W_PIN                                  # content peak on the healthy I/V output
    out.append(f'Content on the healthy I/V output: <= +-{a_iv:.2f} V around VREF (calibrated full scale, largest pin share; '
               f'round 1: 1.41 V)')
    # trim lost (untrimmed 0 dBFS): no-false-trip margin only (a trip would be a protective mute)
    m_hi_u = m_lo_u = np.inf
    for v3a in (V3V3_MIN, V3V3_MAX):
        lo_u, hi_u = cm_range(v3a, A_UNTRIM)
        for vpos in (VPOS_MIN, VPOS_MAX):
            for s_ in np.array(np.meshgrid(*[[-1, 1]] * 4)).T.reshape(-1, 4):
                vh_, vl_ = nodes(v3a, vpos, 1 + s_[0]*tol, 1 + s_[1]*tol, 1 + s_[2]*tol, 1 + s_[3]*tol4)
                m_hi_u = min(m_hi_u, vh_ - VOS - IB * 50e3 - 2 * IB * 3e3 - hi_u)
                m_lo_u = min(m_lo_u, lo_u - (vl_ + VOS + IB * 50e3 + 2 * IB * 3e3))
    out.append(f'  trim lost (untrimmed 0 dBFS {A_UNTRIM:.2f} V pk per leg): no-false-trip margin upper {m_hi_u*1e3:.0f} mV, '
               f'lower {m_lo_u*1e3:.0f} mV')
    tau_cm = 50e3 * 10e-9 * 1.1
    t_fix = 3 * tau_cm + T_H_FALL + AQV_TOFF_DESIGN

    def wait_20hz(cstar, below=True, f=20.0):
        """Longest time a full-scale sine c(t) of amplitude a_iv at >= f stays on the wrong side of c*."""
        r = np.clip(cstar / a_iv, -1, 1)
        if below:      # CM leaves the window only if c > c*: wait while c < c*
            frac = (np.pi + 2 * np.arcsin(r)) / (2 * np.pi)
        else:          # need c < c*: wait while c > c*
            frac = (np.pi - 2 * np.arcsin(r)) / (2 * np.pi)
        return frac / f
    out.append('\nFault detection by the CM window. "silence" = no content; "content" = worst-phase 20 Hz full-scale '
               'sine on the healthy I/V output (it can pull the CM back inside the window). DC-fault energy '
               'E = (2x)^2/R x removal, legs bounded by swing/current (pcommon):')
    out.append('  case                                x/leg   silence        content wait  removal(worst)  E(32 R)  E(16 R)')
    rows = []
    for vs in (VPOS_MIN - IV_VF - 0.6, VPOS_MIN - 0.6, VPOS_MIN - 0.3, VPOS_MAX - 0.2):   # I/V stuck high (OPA2210 swing; R3: X-8 supply VPOS - VF)
        sil = (vs + vref_min) / 2 > hi_max
        cstar = 2 * hi_max - vs - vref_min
        tw = 0.0 if cstar <= -a_iv else (np.inf if cstar >= a_iv else wait_20hz(cstar, below=True))
        rows.append((f'I/V stuck high at {vs:.2f} V', G_LEG * (vs - vref_min), sil, tw))
    for vs in (-(VNEG_MIN - IV_VF - 0.6), -(VNEG_MIN - 0.6), -(VNEG_MAX - 0.2)):   # I/V stuck low (R3: X-8 supply VNEG + VF)
        sil = (vs + vref_max) / 2 < lo_min
        cstar = 2 * lo_min - vs - vref_max
        tw = 0.0 if cstar >= a_iv else (np.inf if cstar <= -a_iv else wait_20hz(cstar, below=False))
        rows.append((f'I/V stuck low at {vs:.2f} V', G_LEG * (vref_max - vs), sil, tw))
    # ratiometric silence coverage: thresholds and CM evaluated at the same 3V3A
    x_sil = 0.0
    for v3a in (V3V3_MIN, 3.3, V3V3_MAX):
        dlo, dhi = cm_dc_range(v3a)
        for vpos in (VPOS_MIN, VPOS_MAX):
            for s in np.array(np.meshgrid(*[[-1, 1]] * 4)).T.reshape(-1, 4):
                vh_, vl_ = nodes(v3a, vpos, 1 + s[0]*tol, 1 + s[1]*tol, 1 + s[2]*tol, 1 + s[3]*tol4)
                x_sil = max(x_sil, 2 * G_LEG * (vh_ + VOS + IB * 50e3 - dlo), 2 * G_LEG * (dhi - (vl_ - VOS - IB * 50e3)))
    for xp in (0.6, 0.9, x_sil, 1.58):                                   # one DAC pin stuck -> leg DC x = 2 G dCM
        sil = xp >= x_sil
        cstar_hi = 2 * (hi_max - vref_min) - xp / G_LEG
        cstar_lo = 2 * (lo_min - vref_max) + xp / G_LEG
        tw_hi = 0.0 if cstar_hi <= -a_iv else (np.inf if cstar_hi >= a_iv else wait_20hz(cstar_hi, True))
        tw_lo = 0.0 if cstar_lo >= a_iv else (np.inf if cstar_lo <= -a_iv else wait_20hz(cstar_lo, False))
        rows.append((f'DAC pin stuck, leg DC {xp:.2f} V', xp, sil, max(tw_hi, tw_lo)))
    worst32 = worst16 = 0.0
    for name, x, sil, tw in rows:
        x32 = leg_dc_max(x, 16.0, min(VPOS_MAX, VNEG_MAX)); x16 = leg_dc_max(x, 8.0, min(VPOS_MAX, VNEG_MAX))
        trem = (tw if sil else np.inf) + t_fix
        tshow = tw + t_fix
        e32 = (2 * x32) ** 2 / 32 * tshow; e16 = (2 * x16) ** 2 / 16 * tshow
        if sil:
            worst32 = max(worst32, e32); worst16 = max(worst16, e16)
        trip_lbl = f'trips (<={t_fix*1e3:.1f} ms)'
        out.append(f'  {name:34s} {x:5.2f} V  {trip_lbl if sil else "NO trip        "}  {tw*1e3:7.1f} ms   '
                   f'{tshow*1e3:7.1f} ms     {e32*1e3:6.1f}   {e16*1e3:6.1f}'
                   + ('' if sil else '   <- silence: leg windows + firmware T0/T1 (p06)'))
    out.append(f'  => the CM path alone covers every I/V stuck-high/low failure and any stuck-pin DC >= {x_sil:.2f} V '
               f'(silence) with <= {worst32*1e3:.1f} mJ at 32 ohm (limit 15) and <= {worst16*1e3:.1f} mJ at 16 ohm '
               '(limit 30), worst content included.')
    import json
    json.dump(dict(x_cm_sil=x_sil, t_cm_fix=t_fix, worst32=worst32, worst16=worst16),
              open(__file__.replace('.py', '_result.json'), 'w'), indent=1)
    out.append(f'  => stuck-pin DC below {x_sil:.2f} V per leg (i.e. < {2*x_sil:.2f} V across a balanced driver) is the '
               'moderate-fault region covered jointly by the leg windows and the firmware tiers (p06 envelope).')
    out.append('  DAC in reset (both pins driven to GND, both I/V outputs high): CM >= 2.91 V > HI (section below) -> no permit '
               'while RESETB is low or during the first 65 %% of the ESS soft start; removal <= %.2f ms' % (t_fix * 1e3))
    # 3V3A absent
    vh0, vl0 = nodes(0.0, VPOS_MIN, 1 - tol, 1 - tol, 1 - tol, 1 + tol4)
    out.append(f'3V3A absent (0 V), VPOS {VPOS_MIN} V, low corner: CMTH_LO = {vl0*1e3:.0f} mV, CM node ~ 0 V '
               f'(I/V outputs at VREF = 0) -> the lower comparator sinks: overdrive {(vl0 - VOS - 0.002)*1e3:.0f} mV '
               f'-> permit off (DC-sense network unbiased = invalid)')
    vh1, vl1 = nodes(0.0, VPOS_MAX, 1 + tol, 1 + tol, 1 + tol, 1 - tol4)
    out.append(f'   (high corner {vl1*1e3:.0f} mV)')
    # removal time for the fast cases
    t_rem = t_fix
    out.append(f'Removal time for a large deviation: <= 3 tau_CM ({3*tau_cm*1e3:.2f} ms) + H fall '
               f'{T_H_FALL*1e3:.2f} ms + photorelay {AQV_TOFF_DESIGN*1e3:.1f} ms = {t_rem*1e3:.2f} ms')
    # loading of the I/V outputs
    out.append(f'I/V output load added: 100 k each (+ 10 nF through 100 k); cross-current between the two '
               f'I/V outputs <= {2*a_iv/200e3*1e6:.1f} uA peak -> negligible')

    # ---------------- DAC reset and ESS soft start with MCLK 75 MHz (D-3), round 2 ------------------------
    import p05_switch_drive as p05
    ss = 4096 * 2 ** (SS_TIME + 1) / (MCLK * (1 - MCLK_TOL))
    out.append(f'\nDAC reset / ESS soft start (round 2, X201 = {MCLK/1e6:.0f} MHz Kyocera, D-3 revised; soft_start_time {SS_TIME} '
               f'[DS ESS reg 14]): ramp = 4096 x 2^{SS_TIME+1} / MCLK = {ss*1e3:.2f} ms (+-50 ppm; the withdrawn 75 MHz part: 111.9 ms)')
    cm_rst_lo, cm_rst_hi = np.inf, 0.0
    x_lo, x_hi = np.inf, 0.0
    for v3a in (V3V3_MIN, V3V3_MAX):
        vh_w = [nodes(v3a, vp, 1 + s_[0]*tol, 1 + s_[1]*tol, 1 + s_[2]*tol, 1 + s_[3]*tol4)[0]
                for vp in (VPOS_MIN, VPOS_MAX) for s_ in np.array(np.meshgrid(*[[-1, 1]] * 4)).T.reshape(-1, 4)]
        for vr in VREF_R:
            for vc in VC_R:
                for rs in (RS_NOM * (1 - RS_TOL), RS_NOM * (1 + RS_TOL)):
                    vref = vr * v3a
                    for rf in RF_R:
                        cm0 = min(vref * (1 + rf / rs), VPOS_MIN - IV_VF - IV_SWING)      # both pins at 0 V, OPA2210 swing bound (R3: X-8 I/V supply)
                        cm_rst_lo = min(cm_rst_lo, cm0); cm_rst_hi = max(cm_rst_hi, vref * (1 + rf / rs))
                    for vth in (min(vh_w) - VOS - IB * 50e3, max(vh_w) + VOS + IB * 50e3):
                        # CM = VREF + (RF/Rs)(VREF - Vs); release when CM < HI, Vs ramps 0 -> Vc
                        vs_rel = vref - (vth - vref) * rs / RF
                        x = vs_rel / (vc * v3a)
                        x_lo = min(x_lo, x); x_hi = max(x_hi, x)
    out.append(f'  RESETB low (DAC pins at ground, 3V3A up): CM >= {cm_rst_lo:.3f} V (VREF(1 + RF/Rs), OPA2210 swing bound '
               f'VPOS - {IV_VF} V (X-8 Schottky) - {IV_SWING} V [DS, 600 ohm row]; analog R3: >= 2.889 V, swing-limited) > HI max 2.151 V -> H held low, switch cannot close; also in programming mode (D-15)')
    out.append(f'  Soft-start ramp (DAC source 0 -> AVCC/2): CM falls linearly with the source voltage and leaves the window '
               f'at {100*x_lo:.0f}...{100*min(x_hi,1):.0f} % of the ramp -> release {x_lo*ss*1e3:.0f}...{min(x_hi,1)*ss*1e3:.0f} ms '
               f'after the ramp starts if the ramp is linear in time [ASSUMP; ESS gives the duration only]; bound: '
               f'<= {ss*1e3:.1f} ms (end of the ramp)')
    # recovery bounds from p05 (computed there): Q617 / Q618 turn-on after the last trip clears
    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()):
        res5 = p05.main()
    t_ready_max = ss + res5['t_618_max'] + 50e-3
    out.append(f'  After release: Q617 conducts <= {res5["t_617_max"]*1e3:.0f} ms, DC_PERMIT_N low <= {res5["t_618_max"]*1e3:.0f} ms '
               f'(p05); pre-close rule "DC_PERMIT_N low >= 50 ms" satisfied <= {t_ready_max*1e3:.0f} ms after the ramp starts')
    for cfg, t_i2c in (('CPLD config 10 ms', 45e-3), ('CPLD config 100 ms', 135e-3)):   # digital firmware_sequences 05:42
        for lbl, t_ss in (('DS soft start', ss), ('digital 1.2 x allowance', 1.2 * ss)):
            t_ss_end = t_i2c + t_ss
            t_ready = t_ss_end + res5['t_618_max'] + 50e-3
            out.append(f'  digital power-up timeline ({cfg}, {lbl}): I2C init {t_i2c*1e3:.0f} ms -> soft start done <= '
                       f'{t_ss_end*1e3:.1f} ms -> DC_PERMIT_N low <= {(t_ss_end + res5["t_618_max"])*1e3:.0f} ms -> pre-close checks '
                       f'pass <= {t_ready*1e3:.0f} ms (V3A_MON >= 150 ms: 175 ms, not limiting) -> RELAY_EN high, volume ramp >= '
                       f'{(t_ready + SW_TON_DESIGN)*1e3:.0f} ms')
    out.append('  -> firmware polls DC_PERMIT_N after the soft start (no fixed 155 ms wait); CM/clock-fault timeout 300 ms after '
               'the soft-start end; the digital table value "permit H recovered <= 155 ms" is replaced by <= %.0f ms.'
               % (res5['t_618_max'] * 1e3))
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))


if __name__ == '__main__':
    main()
