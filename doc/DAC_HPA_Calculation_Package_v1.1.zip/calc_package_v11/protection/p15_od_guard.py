#!/usr/bin/env python3
"""p15 - OD-1 stricter stream guard (DZ-11) and OD-2 DAC lock-status check energies (DZ-12).  numpy only.

OD-1 rule (USB-side guard on the decoded PCM and post-CPLD guard on the captured I2S words; per channel; all rates):
  P1 NEW  level persistence: every sample of the last T_P = 22.0 ms is >= +L or every sample is <= -L, L = 0.30 FS
          (run counter per channel, reset by any sample inside +-L or a sign change)             -> trigger
  P2      CIC^2 (two cascaded 50 ms boxcars), |D| >= 0.25 FS (was 0.30, p07; set by the p16 scan)  -> trigger
  P3      flat: range <= 1e-3 FS over 26 ms and |mean| >= 0.02 FS (unchanged, p07)               -> trigger
  P4 NEW  CIC^2 (two cascaded 150 ms boxcars), |D| >= 0.15 FS (p16b scan)                         -> trigger
  decision latency <= 1 ms.  Action: USB-side -> zero the pair (1 ms ramp) + log (DAC filter delay <= 1 ms);
  post-CPLD -> RELAY_EN low (switch open <= 1.008 ms, p05) + zero + log; re-close only via the pre-close sequence.
Energy = DC energy at the driver (V_dc^2/R x exposure), legs swing/current-bounded at the maximum rail (pcommon), as p03/p07.
"""
import numpy as np
from pcommon import VPOS_MAX, leg_dc_max

L, T_P, T_DEC, T_ACT = 0.30, 22.0e-3, 1.0e-3, 1.008e-3      # T_ACT: max(DAC filter + ramp 1 ms, switch open 1.008 ms)
W, TH = 0.050, 0.25
W4, TH4 = 0.150, 0.15
RES2, RES4 = 0.159, 0.053     # worst |D| per unit amplitude of sines >= 20 Hz (p07/p16, p16b)
FS_LEG = 2.19                        # V per leg at 1.0 FS (p07)
LIM = {(32.0, True): 15e-3, (16.0, True): 30e-3, (32.0, False): 15e-3, (16.0, False): 30e-3}
out = [__doc__]
P = out.append


def power(d, rl, bal):
    xl = leg_dc_max(d * FS_LEG, rl / 2 if bal else rl, VPOS_MAX)
    v = 2 * xl if bal else xl
    return v * v / rl


def run_above(x, lvl, fs):
    """longest run (s) of samples all >= +lvl or all <= -lvl."""
    best = cur = 0; sgn = 0
    for v in x:
        s = 1 if v >= lvl else (-1 if v <= -lvl else 0)
        if s != 0 and s == sgn:
            cur += 1
        elif s != 0:
            cur = 1; sgn = s
        else:
            cur = 0; sgn = 0
        best = max(best, cur)
    return best / fs


# ---------------- 1. false-trigger boundary of P1 --------------------------------------------------------
P('\n1. P1 no-false-trigger boundary (L = 0.30 FS, T_P = 22.0 ms):')
f20 = 20.0 * (1 - 100e-6)
t_sine = (np.pi - 2 * np.arcsin(L)) / (2 * np.pi * f20)
P(f'  full-scale sine: longest stay beyond +-{L} FS per half cycle = (pi - 2 asin L)/(2 pi f) = {t_sine*1e3:.2f} ms at 20 Hz '
  f'(-100 ppm) < {T_P*1e3:.1f} ms -> never triggers for f >= 20 Hz at any amplitude (margin {100*(1-t_sine/T_P):.1f} %); '
  f'lowest never-triggering full-scale sine frequency {(np.pi - 2*np.arcsin(L))/(2*np.pi*T_P):.2f} Hz')
for fs in (44100.0, 48000.0, 384000.0):
    worst = 0.0
    for f in (f20, 20.5, 22.0, 30.0):
        for ph in np.linspace(0, np.pi, 12, endpoint=False):
            t = np.arange(int(fs * 0.12)) / fs
            worst = max(worst, run_above(np.sin(2 * np.pi * f * t + ph), L, fs) if fs < 1e5 else (np.pi - 2 * np.arcsin(L)) / (2 * np.pi * f20))
    P(f'    sampled check fs {fs/1e3:.1f} kHz: longest run {worst*1e3:.2f} ms (onset and 12 phases included) -> '
      f'{"no trigger" if worst < T_P else "TRIGGER"}')
f_sq = 1 / (2 * T_P)
P(f'  full-scale square (amplitude >= {L} FS): plateau = half period -> triggers (mutes) for f <= {f_sq:.2f} Hz, plays for f > {f_sq:.2f} Hz; '
  f'squares below {L} FS never trigger P1')
# DC offset + near-full-scale 20 Hz tone
lo, hi = 0.0, L
for _ in range(40):
    m = 0.5 * (lo + hi)
    a = 1 - m
    t = (np.pi - 2 * np.arcsin(min(1.0, (L - m) / a))) / (2 * np.pi * f20)
    if t >= T_P:
        hi = m
    else:
        lo = m
d_off = hi
def t_beyond(m, f):
    a = 1 - m
    r = (L - m) / a
    if r <= -1:
        return np.inf
    return (np.pi - 2 * np.arcsin(min(1.0, r))) / (2 * np.pi * f)
m30 = min(m for m in np.linspace(0, (1 + L) / 2, 6501) if t_beyond(m, 30.0) >= T_P)
m50 = min(m for m in np.linspace(0, (1 + L) / 2, 6501) if t_beyond(m, 50.0) >= T_P)
P(f'  DC offset + tone at the remaining full scale: 20 Hz tone -> triggers when the offset >= {d_off:.3f} FS ({20*np.log10(d_off):.1f} dBFS); '
  f'30 Hz tone -> offset >= {m30:.3f} FS; 50 Hz tone -> offset >= {m50:.3f} FS (real music offsets are < 0.01 FS)')
P('  P2 (50 ms, 0.25 FS): full-scale sines >= 20 Hz |D| <= 0.159 FS (margin 36 %), full-scale squares above 22.7 Hz |D| <= 0.209 FS '
  '(margin 16 %) [p16]; P4 (150 ms, 0.15 FS): sines 0.053 FS (65 %), squares 0.077 FS (49 %) [p16b]; P3 flat path only for range <= 1e-3 FS')
P('  P4 and DC offsets: a steady digital offset >= 0.15 FS (-16.5 dBFS) always mutes (after 0.17-0.3 s); with a full-scale 20 Hz tone '
  'an offset >= ' + f'{(TH4 - RES4)/(1 - RES4):.3f} FS may mute; real programme offsets are < 0.01 FS (-40 dBFS)')

# ---------------- 2. energies ----------------------------------------------------------------------------
P('\n2. Energies (DC at the driver, exposure = detection + decision 1 ms + action <= 1.008 ms):')
t_exp_p1 = T_P + T_DEC + T_ACT
P(f'  P1 (DC d >= {L} FS with content c <= d - {L}, incl. flat full-scale DC and a constant CPLD word >= {L} FS): '
  f'exposure <= {t_exp_p1*1e3:.1f} ms')
rows = {}
for (rl, bal), lim in LIM.items():
    e = power(1.0, rl, bal) * t_exp_p1
    rows[(rl, bal, 'P1')] = e
    P(f'    {rl:4.0f} ohm {"balanced" if bal else "SE      "}: P(1 FS) {power(1.0, rl, bal)*1e3:5.0f} mW -> {e*1e3:5.1f} mJ '
      f'(limit {lim*1e3:.0f} mJ, margin {100*(1-e/lim):.0f} %)')


def cic2_step(t):
    t = np.asarray(t, dtype=float)
    return np.where(t <= W, t * t / (2 * W * W), np.where(t <= 2 * W, 1 - (2 * W - t) ** 2 / (2 * W * W), 1.0))


def t_det_w(Wx, THx, d, resid):
    need = (THx + resid) / d
    if need >= 1:
        return np.inf
    tt = np.linspace(0, 2 * Wx, 20001)
    s_ = np.where(tt <= Wx, tt * tt / (2 * Wx * Wx), 1 - (2 * Wx - tt) ** 2 / (2 * Wx * Wx))
    return float(tt[np.argmax(s_ >= need)])


def t_det_p2(d, resid):
    need = (TH + resid) / d
    if need >= 1:
        return np.inf
    tt = np.linspace(0, 2 * W, 20001)
    return float(tt[np.argmax(cic2_step(tt) >= need)])


d_b = (1 + L) / 2
import p03_detector as d3
ra = d3.e96(10e3 * (3.900 / 0.30 - 1)); ran = d3.e96(10e3 * (3.722 / 0.30 - 1))
th3 = d3.thresholds(ra, 10e3, ran, 10e3, d3.R1_CHOSEN, 100e3)
(Af3, Bf3), (As3, Bs3) = d3.corners_of(dict(r1=d3.R1_CHOSEN, c1=d3.C1_CHOSEN))
tau_f3 = d3.R1_CHOSEN * (1 - d3.R_TOL_FILT) * d3.C1_CHOSEN * d3.C_LO
H20 = 1 / np.sqrt(1 + (2 * np.pi * 20.0 * tau_f3) ** 2)       # 20 Hz content ripple through the fastest leg filter


def t_hw(d, c):
    x = d * FS_LEG
    return d3.step_time(As3, Bs3, x, th3['p_max'] + FS_LEG * c * H20) + d3.T_EXTRA


def t_guard(d, c):
    if c <= 1e-3 * 0.5:                      # flat within 1e-3 FS range
        if d >= L:
            return T_P + T_DEC + T_ACT
        return 26e-3 + T_DEC + T_ACT if d >= 0.02 else np.inf   # P3 (P4 slower)
    if d - c >= L:
        return T_P + T_DEC + T_ACT
    td = min(t_det_p2(d, RES2 * c), t_det_w(W4, TH4, d, RES4 * c))
    return td + T_DEC + T_ACT


P(f'  Digital-DC envelope, every DC level d = 0.02...1.0 FS, content: none (flat), small (non-flat, 0.2 % FS), or the maximum '
  f'c = 1 - d at 20 Hz (worst CIC^2 residual 0.159 c, p07); removal = min(guard, firmware tiers T1-T3 (p06), hardware leg windows with the 20 Hz ripple '
  f'{100*H20:.1f} % of 2.19 V x c added to the trip level, p03 slow corner + H fall + tOFF); DC below the T3 pair level (2 x 2.19 V x d < 0.192 V, d < 0.044 FS) is the owner-accepted residual:')
TIERS_FW = ((0.995, 1.000, 0.208), (0.311, 0.306, 0.574), (0.176, 0.192, 2.246))   # p06 R3.17 guaranteed trip leg / pair, deadline


def t_fw(d):
    x = d * FS_LEG                   # digital DC drives the two legs of a channel in opposite directions: pair = 2 x
    for lvl, lvp, tdl in TIERS_FW:
        if x >= lvl or 2 * x >= lvp:
            return tdl + 1.008e-3
    return np.inf


env = {}
for (rl, bal), lim in LIM.items():
    worst = (0.0, 0, 0, 0, '')
    for d in np.linspace(0.02, 1.0, 197):
        if 2 * d * FS_LEG < 0.192:
            continue                     # below T3 (pair): owner-accepted residual (< 0.2 V), not an energy case
        for lab, c in (('flat', 0.0), ('small', 0.002), ('max', 1 - d)):
            tg = t_guard(d, c); th_ = t_hw(d, c); tf = t_fw(d)
            tr = min(tg, th_, tf)
            e = power(d, rl, bal) * tr
            if e > worst[0]:
                worst = (e, d, tr, lab, 'guard' if tr == tg else ('hardware' if tr == th_ else 'firmware tiers'))
    env[(rl, bal)] = worst
    P(f'    {rl:4.0f} ohm {"balanced" if bal else "SE      "}: worst {worst[0]*1e3:5.1f} mJ at d = {worst[1]:.2f} FS, content {worst[3]}, '
      f'removal {worst[2]*1e3:.0f} ms by the {worst[4]} (limit {lim*1e3:.0f} mJ, margin {100*(1-worst[0]/lim):.0f} %)')
rows[(32.0, True, 'P2')] = env[(32.0, True)][0]; rows[(16.0, True, 'P2')] = env[(16.0, True)][0]
P('  P3 (flat 0.02-0.30 FS): <= 0.30 FS -> <= ' + f'{power(0.30, 32.0, True)*(26e-3+T_DEC+T_ACT)*1e3:.1f} mJ at 32 ohm balanced')
P('  Round-3 rule for comparison: 22.8 mJ (32 ohm bal, DC with content) / 15.5 mJ (flat); new worst '
  f'{max(rows[(32.0, True, "P1")], rows[(32.0, True, "P2")])*1e3:.1f} mJ at 32 ohm balanced, '
  f'{max(rows[(16.0, True, "P1")], rows[(16.0, True, "P2")])*1e3:.1f} mJ at 16 ohm balanced')

# ---------------- 3. OD-2 energies (parametric; digital's detection times inserted below) ----------------
P('\n3. OD-2 DAC plausibility check - energy of a detected DAC-core hang (frozen code at full scale, worst load power):')
# detection -> switch-open times from digital (firmware_sequences_output.txt section 14, OD-2)
cases = [('(a) DPLL lock lost: DAC_LOCK falling, EXTI9 + 20 us confirm', 1.04e-3),
         ('(b) poll A (10 ms): lock_status 0 / automute 1 / chip ID / GPIO2 != PC9 / reg 0-20 mismatch', 16.45e-3),
         ('(c) poll A: DAC I2C NACK (one retry)', 16.45e-3),
         ("(c') I2C bus stuck low (1 ms timeout + 9-clock recovery)", 17.45e-3),
         ('(d) poll B (100 ms): DPLL ratio out of range', 102.43e-3)]
for name, tx in cases:
    es = [power(1.0, rl, bal) * tx for (rl, bal) in LIM]
    P(f'  {name}: switch open <= {tx*1e3:.2f} ms -> ' +
      ', '.join(f'{rl:.0f} ohm {"bal" if bal else "SE"} {e*1e3:.2f} mJ' for (rl, bal), e in zip(LIM, es)) +
      ('  (leg windows in parallel bound a frozen DC to 39.6/25.9 mJ at 16/32 ohm balanced, 69.1/50.7 ms)' if tx > 50e-3 else ''))
P('  Residual (not detected): a core hang that keeps DPLL lock, answers I2C and returns the written registers -> hardware leg '
  'windows only (0.30 V): 39.6 mJ (16 ohm balanced, +-1.51 V, 69.1 ms) / 25.9 mJ (32 ohm balanced, +-2.02 V, 50.7 ms), '
  '16.2 mJ (60 ohm), 3.4 mJ (300 ohm) [p03, R601 115 k]; firmware tiers are slower at these levels.')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
