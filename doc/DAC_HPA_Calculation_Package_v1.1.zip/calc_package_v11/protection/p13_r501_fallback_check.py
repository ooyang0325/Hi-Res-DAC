#!/usr/bin/env python3
"""p13 - impact on the protection numbers of the DX-4 designed-in fallback R501 221 k -> 232 k (VPOS +0.13 V, same
footprint), should the bring-up measurement require it.  Re-evaluates with VPOS 3.919-4.144 V (VNEG unchanged):
leg-window trip levels/removal/rail-stuck energy (p03 model), U606 ch1 1V3-good rising maximum and ch2 MCLK threshold
(p10 model).  Information only - the fallback is not fitted by default."""
import numpy as np
import pcommon
import p03_detector as d3
import p10_supervisor as p10   # noqa: runs p10 once (prints to its _out.txt)
out = [__doc__]
DV = 0.13
VPMIN, VPMAX = pcommon.VPOS_MIN + DV, pcommon.VPOS_MAX + DV
for name, (vmin, vmax) in (('baseline R501 221 k', (pcommon.VPOS_MIN, pcommon.VPOS_MAX)), ('fallback R501 232 k', (VPMIN, VPMAX))):
    d3.VPOS_MIN, d3.VPOS_MAX, d3.VPOS_NOM = vmin, vmax, 0.5 * (vmin + vmax)
    ra = d3.e96(10e3 * (3.900 / 0.30 - 1)); ran = d3.e96(10e3 * (3.722 / 0.30 - 1))
    th = d3.thresholds(ra, 10e3, ran, 10e3, d3.R1_CHOSEN, 100e3)
    (Af, Bf), (As, Bs) = d3.corners_of(dict(r1=d3.R1_CHOSEN, c1=d3.C1_CHOSEN))
    t1 = d3.step_time(As, Bs, 1.0, th['p_max']) + d3.T_EXTRA
    t2 = d3.step_time(As, Bs, 2.0, th['p_max']) + d3.T_EXTRA
    trs = d3.step_time(As, Bs, vmax, th['p_max']) + d3.T_EXTRA
    e16 = vmax ** 2 / 16 * trs
    sq = d3.square_peak(Af, Bf, 20.0, pcommon.A_FS)
    r13max = max(p10.thr13(vp, e, vo, ib, vh, True) for vp in (vmin, vmax) for e in (-p10.TOL01, p10.TOL01)
                 for vo in (-p10.TLV17_VOS, p10.TLV17_VOS) for ib in (-p10.TLV17_IB, p10.TLV17_IB)
                 for vh in (-pcommon.VNEG_MAX + 0.01, -pcommon.VNEG_MIN + 0.60))
    vthm_max = p10.vref_m(vmax, p10.TOL01) + p10.TLV17_VOS + p10.TLV17_IB * (p10.R_S2 + 90e3)
    out.append(f'{name}: VPOS {vmin:.3f}-{vmax:.3f} V | leg trip +{th["p_min"]:.3f}...+{th["p_max"]:.3f} V | 1 V {t1*1e3:.1f} ms, '
               f'2 V {t2*1e3:.1f} ms | rail-stuck +{vmax:.3f} V SE 16 ohm {e16*1e3:.1f} mJ (32 ohm {e16/2*1e3:.1f}) | FS 20 Hz square '
               f'peak {sq:.4f} V vs trip min {th["trip_min"]:.4f} V | 1V3 rising max {r13max:.3f} V (1V3 min 1.283 V, margin '
               f'{(1.283-r13max)*1e3:.0f} mV) | MCLK threshold max {vthm_max:.3f} V (running node >= 0.890 V)')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
