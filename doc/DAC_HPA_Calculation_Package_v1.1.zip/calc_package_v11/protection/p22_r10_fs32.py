#!/usr/bin/env python3
"""p22_r10_fs32 - R10 owner issue 2: 32 ohm balanced frozen full-scale code WITHOUT the typical OPA1622 swing credit.
RELEASE calculation (option study); self-contained: pcommon + p21_r10_f1 constants; numpy only.  Writes p22_r10_fs32_out.txt.

Question (orchestrator, hand-over 26 Sep): least-cost way to guarantee <= 15 mJ at 32 ohm balanced for ANY frozen code up to
2.325 V per leg (calibrated level + G-bounded 3V3A drift) without the swing credit, keeping every no-false-trip check
(sines >= 20 Hz at the calibrated level incl. drift and at the -4.5 dB default; FS-square boundary no worse than certain
<= 21.4 Hz / possible <= 25.6 Hz; bursts, polarity reversals).  Candidate checked: a high-level short-persistence (H) stage,
pair level V_H 3.9-4.1 V, own timer T_H 10-13 ms, trip into node H.
Labels: [DS] datasheet limit, [CALC] computed here, [ASSUMP] assumption, [E] estimate class.
"""
import io, contextlib
import numpy as np
from pcommon import A_CAL, A_CAL_TRIM, A_CAL_DRIFT, A_DEF_MODEL, A_DEF_BOUND, HEADROOM_NOLOAD as HEAD_TYP, ROUT_SWING as ROUTS, ISC_BOUND as ISC_B
with contextlib.redirect_stdout(io.StringIO()):
    import p21_r10_f1 as M

out = [__doc__]; P = out.append
RL = 32.0; ELIM = 15e-3
T_E3 = M.TP[1] + M.T_ACT                     # E-3 removal of a frozen code above V_L/2, from any state [CALC p21]
T_LATCH = M.V17_TPD + 0.383e-3 + M.T_OFF     # if the E-2 latch clear (<= 0.383 ms, R501 fallback) were credited instead of the H fall
F_SQ = 25.6                                  # FS-square boundary to keep: no mute above 25.6 Hz (E-3 T_P min 19.50 ms)
T_SQ = 1 / (2 * F_SQ)
pw = lambda x: (2 * x) ** 2 / RL             # 32 ohm balanced: pair 2x across 32 ohm

P('\n=== 1. Today (E-3 only above V_L/2), no swing credit [CALC]')
P(f'  E-3 removal from any state: T_P max {M.TP[1]*1e3:.2f} ms + switch allowance {M.T_ACT*1e3:.3f} ms = {T_E3*1e3:.2f} ms')
for lab, x in (('fallback typical swing limit (p21 sweep cap)', M.leg_max(9, 16, M.VPOS_MAX)),
               ('released typical swing limit', M.leg_max(9, 16, M.RAIL_REL['VPOS'][1])),
               ('calibrated 2.192 V', A_CAL), ('calibrated +0.15 dB 2.230 V', A_CAL_TRIM), ('calibrated + G drift 2.325 V', A_CAL_DRIFT),
               ('-4.5 dB default, model 1.828 V', A_DEF_MODEL), ('-4.5 dB default, 3.66 V basis 2.180 V', A_DEF_BOUND)):
    e = pw(x) * T_E3
    P(f'  {lab:46s} {x:.3f} V/leg: {pw(x):.3f} W x {T_E3*1e3:.2f} ms = {e*1e3:5.2f} mJ  {"ok" if e <= ELIM else "> 15 mJ"}')
x_c = np.sqrt(ELIM * RL / T_E3) / 2
P(f'  E-3 alone keeps <= 15 mJ up to {x_c:.4f} V/leg; frozen codes between {x_c:.3f} and {A_CAL_DRIFT} V/leg need something faster.')

P('\n=== 2. Physics bound (any causal detector, any technology)')
P(f'  A frozen code at x and the first half-period of a FS square of amplitude x are the same waveform for 1/(2f), from ANY starting')
P(f'  state (rest included).  Keeping FS squares >= {F_SQ} Hz unmuted up to {A_CAL_DRIFT} V/leg forces a persistence >= {T_SQ*1e3:.2f} ms at every')
P(f'  level up to {A_CAL_DRIFT} V/leg, so the removal time of a frozen code is >= {T_SQ*1e3:.2f} ms + the switch allowance:')
for lab, ta in (('switch allowance as released (H fall 0.99 ms + tOFF 1.0 ms)', M.T_ACT), ('E-2 latch clear credited instead of the H fall', T_LATCH)):
    emin = pw(A_CAL_DRIFT) * (T_SQ + ta)
    t_allow = ELIM / pw(A_CAL_DRIFT) - ta
    P(f'    {lab:62s}: E_min = {emin*1e3:.2f} mJ at {A_CAL_DRIFT} V/leg; a detector must keep its WHOLE '
      f'spread inside {T_SQ*1e3:.2f} ... {t_allow*1e3:.2f} ms ({100*(t_allow/T_SQ-1):.1f} %)')
P(f'  For comparison the E-3 timer spread is {M.TP[0]*1e3:.2f} ... {M.TP[1]*1e3:.2f} ms ({100*(M.TP[1]/M.TP[0]-1):.1f} %); a precision RC timer '
  f'(C0G 1 % + 30 ppm/K x 40 K, 0.1 % R, MOSFET reset, <= 0.1 uA leakage, VOS, tpd) still spans ~5-7 % -> no RC timer fits a 3-7 % window.')

P('\n=== 3. The proposed H stage (V_H 3.9-4.1 V pair, T_H 10-13 ms), checked at its most sensitive corner (V_H 3.9 V, T_H 10 ms)')
VH_MIN, VH_MAX, TH_MIN, TH_MAX = 3.9, 4.1, 10e-3, 13e-3
f20 = 20.0 * (1 - 1e-4)
for lab, A in (('calibrated +0.15 dB 2.230 V', A_CAL_TRIM), ('calibrated + G drift 2.325 V', A_CAL_DRIFT), ('-4.5 dB default 2.180 V basis', A_DEF_BOUND)):
    tab = (np.pi - 2 * np.arcsin(min(1.0, VH_MIN / (2 * A)))) / (2 * np.pi * f20) if 2 * A > VH_MIN else 0.0
    P(f'  sine 20 Hz {lab:34s}: pair {2*A:.3f} V pk above V_H min for {tab*1e3:5.2f} ms vs T_H min {TH_MIN*1e3:.0f} ms -> '
      f'{"no trip (margin %.0f %%)" % (100*(1-tab/TH_MIN)) if tab < TH_MIN else "TRIPS"}')
# time-domain: H timer (fastest corner) on FS squares, reset at once when the level condition is false
dt = 10e-6; t = np.arange(0, 0.4, dt)
def h_trips(sig):
    run = np.abs(sig) > VH_MIN; acc = 0.0
    for r in run:
        acc = acc + dt if r else 0.0
        if acc >= TH_MIN:
            return True
    return False
res = []
for f in (26.0, 30.0, 35.0, 40.0, 45.0, 49.0, 51.0):
    for A in (A_CAL, A_CAL_DRIFT):
        s = 2 * A * np.sign(np.sin(2 * np.pi * f * t + 1e-9))
        res.append((f, A, h_trips(s)))
P('  FS squares (pair +-2A, time domain, H stage alone): ' + '; '.join(f'{f:.0f} Hz/{A:.3f} V {"MUTE" if tr else "ok"}' for f, A, tr in res))
P(f'  -> FS squares mute up to {1/(2*TH_MIN):.0f} Hz (possible) / {1/(2*TH_MAX):.1f} Hz (certain) instead of 25.6 / 21.4 Hz: the FS-square '
  f'boundary gets WORSE -> the H stage fails F-1 (d) (squares) whatever its V_H inside the FS range; sines and bursts would pass.')
e_h = pw(A_CAL_DRIFT) * (TH_MAX + 2 * M.V34_TPD + M.T_ACT)
P(f'  (If the owner accepted the new square boundary: frozen 2.325 V/leg removed <= {(TH_MAX + 2*M.V34_TPD + M.T_ACT)*1e3:.1f} ms -> {e_h*1e3:.1f} mJ; '
  f'below V_H E-3 gives <= {pw(VH_MAX/2)*T_E3*1e3:.1f} mJ at {VH_MAX/2:.2f} V/leg.)')
P('  Cost of the H stage: 4 pair-level channels on the E-3 taps (one per E-3 timer), V_H divider, 4 charge-injection paths (R + diode) into the')
P('  E-3 timers (or its own timers), decoupling: ~12-14 parts (> 10); a TLV1704 quad adds 0.4 mA per rail (5V_ANA +0.8 mA > 0.1 mA), a')
P('  TLV3402 version ~+0.01 mA; Z7 has ~17 mm2 left below 60 % (58.9 % after R951) -> it would have to sit in Z4 with long tap runs.')

P('\n=== 4. Options (cost, effect) - none of the part-adding options meets every adoption condition')
opts = [
    ('A', 'Keep as a stated E item + bring-up qualification test (Q)', '0 parts, 0 mA',
     f'{pw(M.leg_max(9,16,M.RAIL_REL["VPOS"][1]))*T_E3*1e3:.2f} mJ released / {pw(M.leg_max(9,16,M.VPOS_MAX))*T_E3*1e3:.2f} mJ R501 fallback with the typical swing credit (E); '
     f'without it {pw(A_CAL)*T_E3*1e3:.1f} / {pw(A_CAL_TRIM)*T_E3*1e3:.1f} / {pw(A_CAL_DRIFT)*T_E3*1e3:.1f} mJ at 2.192 / 2.230 / 2.325 V/leg'),
    ('B', 'Lower the calibrated full scale by 0.6 dB and the uncalibrated default to -5.1 dB (spec: 1.55 -> 1.45 Vrms per leg)', '0 parts, 0 mA',
     f'ceiling + drift {A_CAL_DRIFT*10**(-0.6/20):.3f} V/leg -> {pw(A_CAL_DRIFT*10**(-0.6/20))*T_E3*1e3:.2f} mJ, default 3.66 V basis '
     f'{3.66*10**(-5.1/20):.3f} V -> {pw(3.66*10**(-5.1/20))*T_E3*1e3:.2f} mJ, no swing credit; every sine margin +0.6 dB; owner decision (max output -0.6 dB)'),
    ('C', 'H stage as proposed (V_H 3.9-4.1 V, T_H 10-13 ms)', '~12-14 parts, +0.01 (TLV3402) ... +0.8 mA (TLV1704)',
     'fails the FS-square boundary (mutes FS squares <= 50 Hz) and the 10-part cap; only with an owner-accepted square boundary'),
    ('D', 'Precision persistence stage inside the physics window', '>= 12 parts + E-2 latch credit',
     f'needs a total timer spread <= {100*((ELIM/pw(A_CAL_DRIFT)-M.T_ACT)/T_SQ-1):.1f} % (<= {100*((ELIM/pw(A_CAL_DRIFT)-T_LATCH)/T_SQ-1):.1f} % with the latch '
     'credit): not achievable with RC timing -> not viable'),
]
for k, lab, cost, eff in opts:
    P(f'  ({k}) {lab}\n      cost: {cost}\n      effect: {eff}')
P('  Note: the uncalibrated -4.5 dB default at the conservative 3.66 V basis (2.180 V/leg) gives '
  f'{pw(A_DEF_BOUND)*T_E3*1e3:.2f} mJ without the swing credit (model 1.828 V: {pw(A_DEF_MODEL)*T_E3*1e3:.1f} mJ) - the same class-E issue as option A.')
P('\n=== 5. Default mode: does the U503 eFuse limit cap the frozen code? (orchestrator check, 26 Sep)')
# Supply chain: 5V_SYS -> U503 TPS2596 (current limit; Default IOS 180.05/201.3/222.6 mA, High 395.4/442.7/489.7 mA with
# R509 4.75 k / R510 3.74 k [DS, power c11]) -> 5V_ANA (C506) -> FB501 -> 5V_ANA_F (C507) -> LM27762: positive LDO -> VPOS;
# inverting charge pump (C508 fly, C509 out) -> negative LDO -> VNEG.  The legs take the whole load current from VPOS/VNEG;
# nothing bypasses U503 (D105 conducts only 5V_ANA -> 5V_SYS; the I/V reservoirs C442/C443 sit behind D411/D412 and cannot
# feed VPOS/VNEG).  TPS2596 in current limit: regulates at ILIM (tLIM 87 us typ; fast clamp above 1.5 x ILIM within 5 us typ);
# NO fault timer, no FLT and no auto-retry for current limiting - FLT and auto-retry only after thermal shutdown (TSD 157 C
# typ), which a 25 ms event cannot reach (FET <= (5.5 - 1.8) V x 0.223 A = 0.83 W -> TJ(steady) <= 104 C) [DS, power c11].
# Bound model (no credit taken): quiescent 0, charge-pump input = output current (charge conservation, k = 1), LDO dropout 0,
# OPA1622 swing headroom 0, LM27762 UVLO ignored, eFuse overshoot 1.5 x ILIM for the first 0.3 ms [ASSUMP 3.4 x tLIM typ],
# capacitors +10 %, 5V_ANA starting at 5.50 V, rails at the fallback maximum; phases: VIN node (C506+C507+C508+C509) droops
# while both LDOs regulate, then VPOS merges with VIN (dropout 0), then VNEG; balanced load 32 ohm: I+ = I- = I_L.
C_IN = (1.0 + 10.0 + 1.0 + 10.0) * 1.1e-6
C_P = (3 * 10.0 + 8 * 0.1 + 8 * 0.1) * 1.1e-6      # C510, C413, C415 + 8 x 100 nF to GND + 8 x 100 nF across the rails
C_N = C_P
T_REM = T_E3
def default_energy(x_req, ilim, iq=0.0, k=1.0, head=lambda i: 0.0, vp0=M.VPOS_MAX, vn0=M.VNEG_MAX, vin0=5.5, t_os=0.3e-3):
    dt = 2e-6; vin, vp, vn = vin0, vp0, vn0; e = 0.0; t = 0.0; xs = []
    while t < T_REM:
        il_lim = ilim * (1.5 if t < t_os else 1.0)
        # leg voltages limited by the rails (headroom model) and by the request
        il = 0.0
        for _ in range(3):
            xp = max(0.0, min(x_req, vp - head(il))); xn = max(0.0, min(x_req, vn - head(il)))
            il = (xp + xn) / RL
        demand = iq + il + k * il
        if vin > vp0:                     # both LDOs regulate; only the VIN node moves
            dv = (min(il_lim, demand) - demand) / C_IN if demand > il_lim or vin < vin0 else 0.0
            vin = min(vin0, vin + dv * dt) if demand > il_lim else vin
        elif vin > vn0:                   # VPOS in dropout (merged with VIN), VNEG regulates
            vin = vin + (il_lim - demand) / (C_IN + C_P) * dt if demand > il_lim else vin
            vp = min(vp0, vin)
        else:                             # all merged
            vin = vin + (il_lim - demand) / (C_IN + C_P + C_N) * dt if demand > il_lim else vin
            vp = min(vp0, vin); vn = min(vn0, vin)
        e += RL * il * il * dt; xs.append(0.5 * (xp + xn)); t += dt
    return e, xs[-1]
worst = (0, 0, 0)
for xq in np.linspace(1.0, A_CAL_DRIFT, 27):
    e_, xe = default_energy(xq, 0.2226)
    if e_ > worst[0]:
        worst = (e_, xq, xe)
P(f'  Bound (Default IOS max 222.6 mA, no quiescent / swing / dropout / UVLO credit, caps +10 %): steady I_L <= ILIM/2 = '
  f'{0.2226/2*1e3:.1f} mA -> {0.2226/2*16:.3f} V/leg; worst over frozen codes 1.0 ... {A_CAL_DRIFT} V/leg: {worst[0]*1e3:.2f} mJ at '
  f'{worst[1]:.3f} V/leg requested (legs settle at {worst[2]:.3f} V/leg) within the E-3 removal {T_REM*1e3:.2f} ms (pair >= '
  f'{2*worst[2]:.2f} V > V_L max {M.VL[1]:.3f} V, so E-3 acts) -> limit 15 mJ, margin {100*(1-worst[0]/ELIM):.0f} %')
e_t, x_t = default_energy(A_CAL_DRIFT, 0.2226, iq=73.65e-3, k=1.03, head=lambda i: HEAD_TYP + ROUTS * i, vp0=M.RAIL_REL['VPOS'][1])
P(f'  Typical view (orchestrator arithmetic: analog quiescent 73.65 mA credited, charge-pump factor 1.03, typical swing): legs settle '
  f'at {x_t:.3f} V/leg -> {e_t*1e3:.2f} mJ (4.4 mJ quoted). Not a bound: 73.65 mA is the quiescent MAXIMUM, so crediting it '
  f'understates the load current; the swing is typical.')
P(f'  High mode (IOS max 489.7 mA): steady I_L <= {0.4897/2*1e3:.0f} mA -> {0.4897/2*16:.2f} V/leg > {A_CAL_DRIFT} V -> no cap: '
  f'the A-45 case (15.23 / 15.77 / 17.14 mJ without the swing credit) exists in High mode only.')
P('  Earlier trips: RAILS_OK_N (LM27762 PGOOD, rails < 95 %) goes only to MCU PB4 - firmware, no hardware path to N6_H, and the')
P('  R2.13a rule treats RAILS_OK_N < 25 ms as a headroom event -> not earlier than E-3 and not creditable for the hardware')
P('  requirement.  CM window U603: the I/V stages run from the C442/C443 220 uF reservoirs behind D411/D412, so the I/V common')
P('  mode is not disturbed by the VPOS/VNEG droop within 25 ms -> no guaranteed earlier trip.  3V3A (LP5907 from 5V_SYS), 1V3')
P('  and MCLK are unaffected -> the X-6 supervisor does not act.  Q617 gate drive follows VPOS; the switch may open below ~2.5-2.9 V')
P('  but that is not guaranteed -> no credit.  Result: removal by E-3 (<= 25.4 ms) in every case.')
P(f'  Class: current cap G (IOS max DS with R509 0.1 %; k >= 1 and I+ = I- by construction; capacitor maxima DS); energy E through the '
  f'E-3 removal time (A-01 tOFF x2, A-33 leakage) and the 0.3 ms overshoot bound; no TYP/MODEL input -> the swing-credit issue '
  f'(A-45) does not apply in Default mode.')

P('\n=== 6. Single leg stuck at the rail with FS content on the partner leg: DC energy (Spec definition) vs total terminal energy')
# Spec v0.8 defines "terminal energy E = V^2/R x (removal time) + after-trip energy" with V the fault DC; decisions_r10 fact 3 uses
# V_stuck^2/R (SE).  Here, for information (indep-check 26 Sep), the TOTAL terminal energy int v^2/R dt with the partner leg playing
# FS content A sin(2 pi f t + ph) (A = 2.325 V, 20 Hz ... 2 kHz, 24 phases; E-3 not credited), removal from p21 (b3 state).
A_C = A_CAL_DRIFT
with contextlib.redirect_stdout(io.StringIO()):
    _a0 = M.A_PRE; M.A_PRE = M.VPOS_MAX
    T_RS = {vr: M.t_single(vr, 1) for vr in (M.RAIL_REL['VPOS'][1], M.RAIL_FB['VPOS'][1])}
    M.A_PRE = _a0
def e_total(vr, rl, t_rem, isc=None):
    best = 0.0; tt = np.linspace(0, t_rem, 4001); dt_ = tt[1] - tt[0]
    for f in np.geomspace(20.0, 2000.0, 160):
        for ph in np.linspace(0, 2 * np.pi, 24, endpoint=False):
            i = (vr - A_C * np.sin(2 * np.pi * f * tt + ph)) / rl
            if isc is not None:
                i = np.clip(i, -isc, isc)
            best = max(best, float(np.sum(i * i * rl) * dt_))
    return best
for vr, t_rem in T_RS.items():
    for rl, lim in ((16.0, 30e-3), (32.0, 15e-3)):
        e_dc_se = vr * vr / rl * t_rem
        e_dc_bal = min(vr, ISC_B * rl) ** 2 / rl * t_rem
        e_tot = e_total(vr, rl, t_rem); e_tot_c = e_total(vr, rl, t_rem, ISC_B)
        P(f'  stuck {vr:.3f} V, removal {t_rem*1e3:.2f} ms, {rl:.0f} ohm: SE load (leg to GND; partner content does not reach it) '
          f'{e_dc_se*1e3:5.2f} mJ = DC energy; balanced load: DC energy (partner at 0 V) {e_dc_bal*1e3:5.2f} mJ, TOTAL with FS partner content '
          f'{e_tot*1e3:5.2f} mJ ({e_tot_c*1e3:5.2f} mJ with the partner-leg current limit {ISC_B*1e3:.0f} mA [ASSUMP]) vs {lim*1e3:.0f} mJ '
          f'{"ok" if e_tot_c <= lim else "> limit"}')
c_all = 0.5 * (C_P * M.VPOS_MAX ** 2 + C_N * M.VNEG_MAX ** 2 + C_IN * 5.5 ** 2) + 0.5 * 0.2226 * 0.3e-3 * 5.5
t_rs = max(T_RS.values())
P(f'  Default mode: the U503 cap bounds the loop current to ILIM/2 = 111.3 mA whatever the content -> <= {RL*0.1113**2*t_rs*1e3 + c_all*1e3:.1f} mJ at '
  f'32 ohm (incl. {c_all*1e3:.2f} mJ stored-capacitor and overshoot energy); SE and 16 ohm lower.')
# 6b (integration 26 Sep): the 16 ohm balanced figure above needs the partner-leg ISC credit [ASSUMP].  Without it, High mode is still
# capped by U503 (IOS max 489.7 mA, DS): the stuck leg sources I_L from VPOS and the partner sinks it into VNEG, so I_eFuse >= 2 I_L
# (charge-pump k >= 1, quiescent 0).  Merged-node model of section 5 (caps +10 %, 1.5 x ILIM for 0.3 ms, dropout 0, no UVLO), stuck leg
# = VPOS(t), partner = FS content limited by its rail, 16 and 32 ohm, 20-200 Hz, 12 phases.
def onestuck_energy(ilim, rl, f, ph, t_rem, vp0=M.VPOS_MAX, vn0=M.VNEG_MAX, vin0=5.5, t_os=0.3e-3, dt=10e-6):
    vin, vp, vn = vin0, vp0, vn0; e = 0.0; t = 0.0
    while t < t_rem:
        il_lim = ilim * (1.5 if t < t_os else 1.0)
        v_p = max(-vn, min(vp, -A_C * np.sin(2 * np.pi * f * t + ph)))
        il = max(0.0, (vp - v_p) / rl)
        demand = 2 * il
        if demand > il_lim:
            if vin > vp0:
                vin += (il_lim - demand) / C_IN * dt
            elif vin > vn0:
                vin += (il_lim - demand) / (C_IN + C_P) * dt; vp = min(vp0, vin)
            else:
                vin += (il_lim - demand) / (C_IN + C_P + C_N) * dt; vp = min(vp0, vin); vn = min(vn0, vin)
        e += rl * il * il * dt; t += dt
    return e
for rl, lim in ((16.0, 30e-3), (32.0, 15e-3)):
    w = max((onestuck_energy(0.4897, rl, f, ph, max(T_RS.values())), f) for f in (20.0, 25.0, 30.0, 40.0, 54.0, 70.0, 100.0, 200.0)
            for ph in np.linspace(0, 2 * np.pi, 12, endpoint=False))
    P(f'  High mode, balanced {rl:.0f} ohm, one leg stuck at {M.VPOS_MAX:.3f} V, FS partner content, NO partner current-limit credit, U503 cap '
      f'(IOS max 489.7 mA): worst TOTAL {w[0]*1e3:.2f} mJ (at {w[1]:.0f} Hz) vs {lim*1e3:.0f} mJ {"ok" if w[0] <= lim else "> limit"}')
P('  -> Under the Spec definition (DC energy) every rail-stuck case passes (26.48 / 13.24 mJ). If the owner means the TOTAL terminal energy')
P('     including the partner-leg content, the High-mode 32 ohm balanced one-leg-stuck case exceeds 15 mJ (rows above); 16 ohm stays inside')
P('     through the U503 cap even without the ISC credit (6b); SE loads and Default mode stay inside.  A remedy would be a fast rail-stuck level (|leg| well above any content, e.g. ~2.9 V vs <= 2.325 V)')
P('     with a ~2 ms persistence; not designed here (orchestrator/owner decision on the definition first).')

P('\n=== 7. Hardware fix evaluated (orchestrator, 26 Sep): fast high over-range stage per leg (threshold V_H between content and a stuck leg)')
# window: V_H min above the highest legitimate content (2.325 V/leg; default 2.180 V) with margin for Gibbs / inter-sample overshoot
# (a short filter handles those); V_H max such that a leg held just below V_H, removed by the existing OR path in 25.85 ms, keeps the
# 32 ohm balanced TOTAL (FS partner content, worst phase) <= 15 mJ.
t_or = max(T_RS.values())
for x in (2.45, 2.6, 2.75, 2.8, 2.9):
    P(f'  leg held at {x:.2f} V (just below V_H), OR path {t_or*1e3:.2f} ms: 32 ohm balanced TOTAL {e_total(x, 32.0, t_or)*1e3:5.2f} mJ, SE 16 ohm '
      f'{x*x/16*t_or*1e3:5.2f} mJ')
P('  -> window for V_H: ~2.45 V (content 2.325 V + 5 %) ... 2.80 V (14.90 mJ at 32 ohm); all tolerances (3V3A 2 %, resistors, VOS, a diode VF')
P('     of a max/min selector, typically +-0.1 V over temperature) must fit in 0.35 V.')
P('  Does a stuck leg stay above V_H under load?  A leg shorted to its rail follows the rail.  The High-mode eFuse minimum (395.4 mA) with the')
for rl in (32.0, 16.0):
    for iq in (73.65e-3, 0.0):
        il = (0.3954 - iq) / 2
        P(f'    {rl:.0f} ohm balanced, quiescent {iq*1e3:5.2f} mA: loop current <= {il*1e3:.1f} mA -> stuck leg (= VPOS) sags to {rl*il - A_C:5.2f} V at the '
          f'partner negative peak')
_def = 2 * (M.VPOS_MAX + A_C) / 32 + 73.65e-3 - 0.3954
P(f'  -> at 32 ohm the stuck leg can sag to ~2.8 V (the top of the V_H window) and at 16 ohm deep into the content range.  After a step fault the rails'
  f' droop at {_def/(C_IN + C_P + C_N):.0f} V/s, so the leg stays above 2.75 V for only {(M.VPOS_MAX-2.75)/(_def/(C_IN+C_P+C_N))*1e3:.1f} ms '
  f'({(M.RAIL_REL["VPOS"][1]-2.75)/(_def/(C_IN+C_P+C_N))*1e3:.1f} ms from 3.915 V); detection must finish inside that (TLV3402 delay has no maximum; '
  f'0.9 ms is an assumption), and a fault that drifts into the rail instead of stepping defeats it.')
P('  Cost of the least-part topology (diode max selector over the four legs + diode min selector, one TLV3402 dual, V_H+ / V_H- references,')
P('  selector bias and filter RCs, trip by sinking the existing E-3 V_T node so the TLV1704 timer comparators pull N6_H): 4 diode packs +')
P('  2 bias R + 2 series R + 2 C + 1 IC + 1 decoupling + 4 reference R = 16 parts, plus a test provision for the new channel (F-1 e);')
P('  about +0.06 mA at 5V_ANA (ok); Z7 has ~14 mm2, so it would go to Z4 (~52 % -> ~60 %).  It does not close A-45: frozen codes <= 2.325 V lie')
P('  below any V_H that keeps content unmuted.')
P('  VERDICT: not adopted (> 12 parts, space at the Z4 limit, and no clean guarantee because the loaded stuck leg can sag to the window).')
P('  Options: (1) keep the Spec definition E = V_DC^2/R x t and publish the total-terminal figures (0 parts); (2) this stage (~16 parts +')
P('  test provision, closes the 32 ohm total case only if detection beats the rail droop, <= ~1.4 ms); (3) per-leg fast comparators (8')
P('  channels, ~20+ parts, ~+0.2 mA) - rejected.')

P('\n=== Summary')
P(f'  not adopted: the H stage mutes FS squares up to {1/(2*TH_MIN):.0f} Hz; physics floor {pw(A_CAL_DRIFT)*(T_SQ+M.T_ACT)*1e3:.2f} mJ at 2.325 V/leg '
  f'leaves a {100*((ELIM/pw(A_CAL_DRIFT)-M.T_ACT)/T_SQ-1):.1f} % timer window; recommended A (E item + Q test), B offered to the owner (0 parts, -0.6 dB).')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
