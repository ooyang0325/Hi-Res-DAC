#!/usr/bin/env python3
"""p08 - Generates bom_rows.csv and netlist.csv for block 6 (protection) and the output switches K601-K604.

Pin numbers:
  TLV1704AIPWR TSSOP-14 (TI SBOS589D pin table, LM339-compatible): 1 2OUT, 2 1OUT, 3 V+, 4 1IN-, 5 1IN+,
    6 2IN-, 7 2IN+, 8 3IN-, 9 3IN+, 10 4IN-, 11 4IN+, 12 V-, 13 4OUT, 14 3OUT
  TLP3545A(TP1,F) DIP6 LF1 surface-mount lead form (Toshiba 11-7A801S; datasheet EN 2023-05 pin table, JA edition
    section 6): 1 anode, 2 cathode, 3 N.C., 4 drain, 5 source (common source: B/C connections only -> unconnected
    in the A connection used here), 6 drain; A connection = output between 4 and 6.  Conditional second source
    Panasonic AQV251GA(X): same assignment (1 LED+, 2 LED-, 3 internal - leave unconnected, 4/6 load, 5 common).
  OPA2333AIDR SOIC-8 (TI SBOS351E pin table): 1 OUT A, 2 -IN A, 3 +IN A, 4 V-, 5 +IN B, 6 -IN B, 7 OUT B, 8 V+
  MMBT3904 SOT-23 (JSCJ): 1 B, 2 E, 3 C;  AO3400A SOT-23 (AOS): 1 G, 2 S, 3 D;  2N7002 SOT-23 (JSCJ): 1 G, 2 S, 3 D
  2-terminal passives: pins 1/2.
Interface nets per brief section 5; block-internal nets prefixed N6_. The I/V output nets N4_IVL_P/N4_IVL_N/
N4_IVR_P/N4_IVR_N are requested from the analog stream (OPA2210 outputs for DACL, DACLB, DACR, DACRB).
"""
import csv

B6 = '6 Protection and control'
parts = []   # (ref, bomkey, pins{pin: (name, net)}, note)
BOM = {}     # bomkey -> dict of bom fields


def bom(key, **kw):
    BOM[key] = kw


def add(ref, key, pins, note=''):
    parts.append((ref, key, pins, note))


def r(ref, key, n1, n2, note=''):
    add(ref, key, {1: ('1', n1), 2: ('2', n2)}, note)


def c(ref, key, n1, n2, note=''):
    add(ref, key, {1: ('1', n1), 2: ('2', n2)}, note)


# ---------------- BOM lines ----------------------------------------------------------------
bom('U_TLV', desc='Comparator, quad, micropower, rail-to-rail input, open-collector output, on VPOS/VNEG',
    value='TLV1704', package='TSSOP-14', rating='2.2-36 V; IQ <= 100 uA/ch (-40..125 C); VOS <= 5.5 mV; IB <= 20 nA; CM V-..V+',
    mpn='TI TLV1704AIPWR', lcsc='C181596', cls='Extended', stock='LCSC 61 pcs (24 Sep 2026); DigiKey 6,948 (23 Sep 2026, parts follow-up 3) -> JLCPCB global sourcing; MSL 2-260C-1 year',
    lead='No', smt=14, tht=0, price=1.37, url='https://www.ti.com/lit/ds/symlink/tlv1704.pdf')
bom('K_AQV', desc='Photorelay 1 Form A, MOSFET output (A connection 4-6), output switch in each leg',
    value='TLP3545A', package='DIP6 LF1 surface-mount gull wing (Toshiba 11-7A801S, 7.62 mm row pitch), tape 1,500',
    rating='60 V, 4 A (A conn., -40 mA/K > 25 C); RON <= 60 mOhm (25 C, IF 5 mA); IFT <= 3 mA; tON <= 5 ms / tOFF <= 0.5 ms (IF 5 mA); '
           'LED IF abs 30 mA, VR 6 V; Topr -40..110 C; Tsol 260 C 10 s, reflow x2 max',
    mpn='Toshiba TLP3545A(TP1,F)', lcsc='none', cls='Global sourcing',
    stock='DigiKey 28,529 on the TP1 page (18 Sep 2026, parts follow-up 3); Mouser 15,326 (3 Aug 2026); MSL 1; JLCPCB global sourcing',
    lead='No', smt=6, tht=0, price=3.60,
    url='https://toshiba.semicon-storage.com/info/TLP3545A_datasheet_en_20230526.pdf?did=60318&prodName=TLP3545A',
    note='Conditional second source: Panasonic AQV251GA(X) (same pinout; RON 0.08 ohm max; VR 5 V) ONLY if JLCPCB confirms a '
         'Standard-PCBA reflow peak <= 250 C with <= 30 s above 230 C (Panasonic limit), otherwise excluded. Price estimate [not verified].')
bom('Q_3904', desc='NPN, LED-string current-sink pass transistor (driven by U604)', value='MMBT3904', package='SOT-23',
    rating='40 V, 200 mA, 200 mW, hFE 100-300', mpn='JSCJ MMBT3904 (RANGE:100-300)', lcsc='C20526', cls='Basic',
    stock='LCSC 25,800', lead='No', smt=3, tht=0, price=0.0104, url='https://www.lcsc.com/product-detail/C20526.html')
bom('Q_AO3400', desc='N-MOSFET, series permit switches (MCLK run-signal gate Q616, hardware permit H Q617)', value='AO3400A', package='SOT-23',
    rating='30 V, 5.7 A, VGS +-12 V, RDS(on) <= 48 mOhm at 2.5 V, VGS(th) 0.65-1.45 V', mpn='AOS AO3400A', lcsc='C20917',
    cls='Basic', stock='LCSC 489,895', lead='No', smt=3, tht=0, price=0.0524, url='https://media.digikey.com/pdf/Data%20Sheets/Alpha%20&%20Omega/AO3400A_ds.pdf')
bom('Q_7002', desc='N-MOSFET, permit readback DC_PERMIT_N (open drain to 3V3M)', value='2N7002', package='SOT-23',
    rating='60 V, VGS +-20 V, VGS(th) 1.0-2.5 V', mpn='JSCJ 2N7002', lcsc='C8545', cls='Basic', stock='LCSC (Basic)',
    lead='No', smt=3, tht=0, price=0.0177, url='https://www.lcsc.com/product-detail/C8545.html')
bom('U_OPA', desc='Dual zero-drift RRIO op-amp, LED-string current-sink regulator (supply 3V3D, reference from RELAY_EN)', value='OPA2333',
    package='SOIC-8', rating='1.8-5.5 V (7 V abs); VOS <= 10 uV, 0.05 uV/K; IQ <= 28 uA/ch (-40..125 C); GBW 350 kHz',
    mpn='TI OPA2333AIDR', lcsc='C38732', cls='Extended [class not re-read]', stock='LCSC 5,082 (25 Sep 2026)', lead='No', smt=8,
    tht=0, price=0.6555, url='https://www.ti.com/lit/ds/symlink/opa2333.pdf')
bom('R105k', desc='Leg DC-window filter resistor (tau 231 ms with 2.2 uF)', value='105 kOhm', package='0402',
    rating='1 %, 100 ppm/K, 62.5 mW', mpn='UNI-ROYAL 0402WGF1053TCE', lcsc='C25742', cls='Extended', stock='JLCPCB 47,600',
    lead='No', smt=2, tht=0, price=0.0006, url='https://jlcpcb.com/partdetail/26485-0402WGF1053TCE/C25742')
bom('R100k', desc='100 kOhm: comparator input series (R649-R652), RELAY_EN pull-down (R646), H pull-up to VPOS (R647), DC_PERMIT_N pull-up (R648)',
    value='100 kOhm', package='0402', rating='1 %, 62.5 mW', mpn='UNI-ROYAL 0402WGF1003TCE', lcsc='C25741', cls='Basic',
    stock='LCSC (Basic)', lead='No', smt=2, tht=0, price=0.0005, url='https://www.lcsc.com/product-detail/C25741.html')
bom('R121k', desc='Positive threshold divider, top (VTH+ = VPOS x 10/131 = +0.298 V nom.)', value='121 kOhm', package='0402',
    rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RT0402BRD07121KL', lcsc='C852503', cls='Extended',
    stock='LCSC out of stock -> global sourcing (DigiKey 25,651 re-read 25 Sep 2026, Mouser 29,723)', lead='No', smt=2, tht=0, price=0.0144,
    url='https://www.lcsc.com/product-detail/C852503.html')
bom('R115k', desc='Negative threshold divider, top (VTH- = VNEG x 10/125 = -0.298 V nom.)', value='115 kOhm', package='0402',
    rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RT0402BRD07115KL', lcsc='C852488', cls='Extended',
    stock='LCSC out of stock -> global sourcing (Mouser 13,540, DigiKey 19,542)', lead='No', smt=2, tht=0, price=0.0143,
    url='https://www.lcsc.com/product-detail/C852488.html')
bom('R10k01', desc='10.0 kOhm 0.1 %: threshold dividers bottom (R609, R610), CM threshold chain top/bottom (R657, R659)',
    value='10.0 kOhm', package='0402', rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RT0402BRD0710KL', lcsc='C190095',
    cls='Extended', stock='LCSC 428,500', lead='No', smt=2, tht=0, price=0.0104, url='https://www.lcsc.com/product-detail/C190095.html')
bom('R6k8', desc='6.8 kOhm 0.1 %: DC-sense series R_S (R624-R627), reference R_S (R661), CM chain middle (R658)',
    value='6.8 kOhm', package='0402', rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RP0402BRD076K8L (RT0402BRD076K8L alt.)',
    lcsc='C33900832', cls='Extended', stock='LCSC 7,070 (RT0402BRD076K8L 27,100 listed as alternative)', lead='No', smt=2, tht=0,
    price=0.0338, url='https://www.lcsc.com/product-detail/C33900832.html')
bom('R5k1', desc='5.1 kOhm 0.1 %: DC-sense bias R_U to 3V3A (R628-R631), reference R_U (R639), LED-sink reference bottom (R663)', value='5.1 kOhm', package='0402',
    rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RT0402BRD075K1L', lcsc='C852856', cls='Extended',
    stock='LCSC out of stock -> global sourcing (DigiKey 25,165)', lead='No', smt=2, tht=0, price=0.0141,
    url='https://www.lcsc.com/product-detail/C852856.html')
bom('R16k9', desc='16.9 kOhm 0.1 %: DC-sense R_D to GND (R632-R635), reference R_D (R640)', value='16.9 kOhm', package='0402',
    rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RT0402BRD0716K9L', lcsc='C852560', cls='Extended', stock='LCSC 6,250',
    lead='No', smt=2, tht=0, price=0.0124, url='https://www.lcsc.com/product-detail/C852560.html')
bom('R100k01', desc='100 kOhm 0.1 %: I/V common-mode summing resistors (R653-R656), LED-sink reference top (R662)', value='100 kOhm', package='0402',
    rating='0.1 %, 25 ppm/K thin film', mpn='YAGEO RT0402BRD07100KL', lcsc='C852472', cls='Extended', stock='LCSC 742,100',
    lead='No', smt=2, tht=0, price=0.0195, url='https://www.lcsc.com/product-detail/C852472.html')
bom('R330k', desc='CM threshold offset from VPOS into CMTH_LO (permit off when 3V3A is absent)', value='330 kOhm', package='0402',
    rating='1 %, 100 ppm/K', mpn='UNI-ROYAL 0402WGF3303TCE', lcsc='C25778', cls='Extended', stock='JLCPCB library (LCSC stock varies)',
    lead='No', smt=2, tht=0, price=0.0008, url='https://jlcpcb.com/partdetail/26521-0402WGF3303TCE/C25778')
bom('R100R', desc='LED-string current-sense resistor R_S (5.32-6.60 mA per string with V_IREF 137-164 mV)', value='24.9 Ohm', package='0402',
    rating='0.1 %, 25 ppm/K thin film, 50 mW (uses 1.1 mW)', mpn='Vishay PATT0402E24R9BGT1 (alt. Yageo RT0402BRD0724R9L)', lcsc='none',
    cls='Global sourcing', stock='DigiKey 3,285 (Feb 2026, recheck); a 1 % 100 ppm 24.9 ohm part also meets D-1 (5.25-6.68 mA)',
    lead='No', smt=2, tht=0, price=0.70, url='https://www.vishay.com/doc?60093')
bom('R4k7', desc='Base resistor, U604 output to the pass-transistor base', value='4.7 kOhm', package='0402',
    rating='1 %', mpn='UNI-ROYAL 0402WGF4701TCE', lcsc='C25900', cls='Basic', stock='LCSC (Basic)', lead='No', smt=2, tht=0,
    price=0.0005, url='https://www.lcsc.com/product-detail/C25900.html')
bom('R1k', desc='Gate series resistor, N2_MCLK_OE (X201 run signal, D-19) tap to Q616 (keeps the X201 INH edge clean)', value='1 kOhm', package='0402',
    rating='1 %', mpn='UNI-ROYAL 0402WGF1001TCE', lcsc='C11702', cls='Basic', stock='LCSC (Basic)', lead='No', smt=2, tht=0,
    price=0.0005, url='https://www.lcsc.com/product-detail/C11702.html')
bom('C2u2', desc='Leg DC-window filter capacitor (tau 231 ms with 105 kOhm)', value='2.2 uF',
    package='0603', rating='16 V X5R +-10 % (-15/+10 % incl. temperature [brief]; DC bias <= 0.32 V until the trip)',
    mpn='Samsung CL10A225KO8NNNC', lcsc='C23630', cls='Basic', stock='LCSC 2,105,100', lead='No', smt=2, tht=0, price=0.0104,
    url='https://www.lcsc.com/product-detail/C23630.html')
bom('C4u7', desc='DC-sense filter (C608-C611) and reference-network filter (C616)', value='4.7 uF',
    package='0805', rating='25 V X5R +-10 % (-15/+10 % tol./temperature [brief] x 0.85 DC bias/AC level at <= 2.5 V [ASSUMP])',
    mpn='Samsung CL21A475KAQNNNE', lcsc='C1779', cls='Basic', stock='JLCPCB 2,855,148; LCSC 1,903,760 (24 Sep 2026)',
    lead='No', smt=2, tht=0, price=0.0152, url='https://jlcpcb.com/partdetail/2131-CL21A475KAQNNNE/C1779')
bom('C100n', desc='Decoupling: TLV1704 V+/V- to GND (C612-C615, C618, C619), U604 supply (C622)', value='100 nF', package='0402',
    rating='16 V X7R', mpn='Samsung CL05B104KO5NNNC', lcsc='C1525', cls='Basic', stock='LCSC (Basic)', lead='No', smt=2, tht=0,
    price=0.0011, url='https://www.lcsc.com/product-detail/C1525.html')
bom('C220n', desc='Permit node H capacitor (minimum switch-off time 53-135 ms with R647 100 k, glitch filter)', value='1 uF', package='0603',
    rating='50 V X5R +-10 % (sees -3.8...+4.0 V; DC bias x0.85 [ASSUMP])', mpn='Samsung CL10A105KB8NNNC', lcsc='C15849', cls='Basic [class not re-read]',
    stock='LCSC (in stock, 25 Sep 2026)', lead='No', smt=2, tht=0, price=0.0060, url='https://www.lcsc.com/product-detail/C15849.html')
bom('C10n', desc='I/V common-mode node filter (tau 0.5 ms with 50 kOhm)', value='10 nF', package='0402', rating='50 V X7R',
    mpn='Samsung CL05B103KB5NNNC', lcsc='C15195', cls='Basic', stock='LCSC (Basic)', lead='No', smt=2, tht=0, price=0.0011,
    url='https://www.lcsc.com/product-detail/C15195.html')

# ---------------- instances: comparators ----------------------------------------------------
def tlv(ref, ins, note):
    """ins: list of 4 tuples (in_minus_net, in_plus_net) for channels 1..4; outputs all on N6_H."""
    p = {1: ('2OUT', 'N6_H'), 2: ('1OUT', 'N6_H'), 3: ('V+', 'VPOS'), 12: ('V-', 'VNEG'),
         13: ('4OUT', 'N6_H'), 14: ('3OUT', 'N6_H')}
    pinmap = {1: (4, 5), 2: (6, 7), 3: (8, 9), 4: (10, 11)}
    for ch, (inm, inp) in enumerate(ins, start=1):
        pm, pp = pinmap[ch]
        p[pm] = (f'{ch}IN-', inm); p[pp] = (f'{ch}IN+', inp)
    add(ref, 'U_TLV', p, note)


tlv('U601', [('N6_CLP', 'N6_VTHP'), ('N6_VTHN', 'N6_CLP'), ('N6_CLN', 'N6_VTHP'), ('N6_VTHN', 'N6_CLN')],
    'Leg windows L+ (ch1 positive, ch2 negative) and L- (ch3, ch4); output low = DC on the leg')
tlv('U602', [('N6_CRP', 'N6_VTHP'), ('N6_VTHN', 'N6_CRP'), ('N6_CRN', 'N6_VTHP'), ('N6_VTHN', 'N6_CRN')],
    'Leg windows R+ (ch1, ch2) and R- (ch3, ch4)')
tlv('U603', [('N6_CML', 'N6_CMTH_HI'), ('N6_CMTH_LO', 'N6_CML'), ('N6_CMR', 'N6_CMTH_HI'), ('N6_CMTH_LO', 'N6_CMR')],
    'I/V common-mode windows L (ch1 high, ch2 low) and R (ch3, ch4); low also when 3V3A is absent or the DAC is in reset')
for ref, u, rail in (('C612', 'U601', 'VPOS'), ('C613', 'U601', 'VNEG'), ('C614', 'U602', 'VPOS'), ('C615', 'U602', 'VNEG'),
                     ('C618', 'U603', 'VPOS'), ('C619', 'U603', 'VNEG')):
    c(ref, 'C100n', rail, 'GND', f'{u} {"V+" if rail == "VPOS" else "V-"} decoupling, at the pin')

# ---------------- leg filters and input resistors ---------------------------------------------
for leg, rf, cf, rin, fn, cn in (('LEG_LP', 'R601', 'C601', 'R649', 'N6_FLP', 'N6_CLP'),
                                 ('LEG_LN', 'R602', 'C602', 'R650', 'N6_FLN', 'N6_CLN'),
                                 ('LEG_RP', 'R603', 'C603', 'R651', 'N6_FRP', 'N6_CRP'),
                                 ('LEG_RN', 'R604', 'C604', 'R652', 'N6_FRN', 'N6_CRN')):
    r(rf, 'R105k', leg, fn, 'leg DC-window filter')
    c(cf, 'C2u2', fn, 'GND', 'leg DC-window filter capacitor')
    r(rin, 'R100k', fn, cn, 'comparator input series resistor (R8-B8: limits clamp current <= 45 uA at rail collapse)')
r('R607', 'R121k', 'VPOS', 'N6_VTHP', 'VTH+ divider top'); r('R609', 'R10k01', 'N6_VTHP', 'GND', 'VTH+ divider bottom')
r('R608', 'R115k', 'VNEG', 'N6_VTHN', 'VTH- divider top'); r('R610', 'R10k01', 'N6_VTHN', 'GND', 'VTH- divider bottom')

# ---------------- CM monitor ------------------------------------------------------------------
r('R653', 'R100k01', 'N4_IVL_P', 'N6_CML', 'from the DACL I/V output (analog-stream net)')
r('R654', 'R100k01', 'N4_IVL_N', 'N6_CML', 'from the DACLB I/V output')
c('C620', 'C10n', 'N6_CML', 'GND', 'CM node filter L')
r('R655', 'R100k01', 'N4_IVR_P', 'N6_CMR', 'from the DACR I/V output')
r('R656', 'R100k01', 'N4_IVR_N', 'N6_CMR', 'from the DACRB I/V output')
c('C621', 'C10n', 'N6_CMR', 'GND', 'CM node filter R')
r('R657', 'R10k01', '3V3A', 'N6_CMTH_HI', 'CM threshold chain top (ratiometric to VREF)')
r('R658', 'R6k8', 'N6_CMTH_HI', 'N6_CMTH_LO', 'CM threshold chain middle')
r('R659', 'R10k01', 'N6_CMTH_LO', 'GND', 'CM threshold chain bottom')
r('R660', 'R330k', 'VPOS', 'N6_CMTH_LO', 'offset: CMTH_LO >= 70 mV when 3V3A = 0 -> permit off')

# ---------------- permit node, readback ---------------------------------------------------------
r('R647', 'R100k', 'VPOS', 'N6_H', 'permit pull-up (100 k: tolerates 9 x the listed comparator leakage)')
c('C617', 'C220n', 'N6_H', 'GND', 'permit node capacitor (off-time stretch, 1 uF 50 V)')
add('Q617', 'Q_AO3400', {1: ('G', 'N6_H'), 2: ('S', 'GND'), 3: ('D', 'N6_M2')}, 'hardware permit switch (bottom of the LED stack)')
add('Q616', 'Q_AO3400', {1: ('G', 'N6_GMC'), 2: ('S', 'N6_M2'), 3: ('D', 'N6_EM')}, 'MCLK permit gate (switch opens whenever X201 is stopped: MCLK_EN, AVCC_EN or MCLK_PERMIT low)')
r('R645', 'R1k', 'N2_MCLK_OE', 'N6_GMC', 'gate series resistor from U206 output N2_MCLK_OE = MCLK_EN AND AVCC_EN AND MCLK_PERMIT (D-19; R235 100 k pull-down, digital)')
add('Q618', 'Q_7002', {1: ('G', 'N6_H'), 2: ('S', 'GND'), 3: ('D', 'DC_PERMIT_N')}, 'readback: DC_PERMIT_N low = hardware permit present')
r('R648', 'R100k', 'DC_PERMIT_N', '3V3M', 'DC_PERMIT_N pull-up')
r('R646', 'R100k', 'RELAY_EN', 'GND', 'RELAY_EN pull-down (switches open when the MCU is in reset)')

# ---------------- LED strings and current limiters ---------------------------------------------
for s, ka, kb, qp, rs, rb, na, nc, ne, nb, no in (
        ('L', 'K601', 'K602', 'Q612', 'R641', 'R643', 'N6_SL_A', 'N6_SL_C', 'N6_EL', 'N6_BL', 'N6_OAL'),
        ('R', 'K603', 'K604', 'Q614', 'R642', 'R644', 'N6_SR_A', 'N6_SR_C', 'N6_ER', 'N6_BR', 'N6_OAR')):
    add(qp, 'Q_3904', {1: ('B', nb), 2: ('E', ne), 3: ('C', nc)}, f'string {s} current-sink pass transistor (Q613/Q615 retired)')
    r(rs, 'R100R', ne, 'N6_EM', f'string {s} sense resistor R_S (I = V_IREF/R_S)')
    r(rb, 'R4k7', no, nb, f'string {s} base resistor from U604')
add('U604', 'U_OPA', {1: ('OUT A', 'N6_OAL'), 2: ('-IN A', 'N6_EL'), 3: ('+IN A', 'N6_IREF'), 4: ('V-', 'GND'),
                      5: ('+IN B', 'N6_IREF'), 6: ('-IN B', 'N6_ER'), 7: ('OUT B', 'N6_OAR'), 8: ('V+', '3V3D')},
    'LED-string current-sink regulator (A: string L, B: string R); V+ = 3V3D; RELAY_EN low -> V_IREF = 0 -> IF <= 1.2 uA')
r('R662', 'R100k01', 'RELAY_EN', 'N6_IREF', 'LED-sink reference divider top (V_IREF 137-164 mV)')
r('R663', 'R5k1', 'N6_IREF', 'GND', 'LED-sink reference divider bottom')
c('C622', 'C100n', '3V3D', 'GND', 'U604 V+ (3V3D) decoupling, at the pin')

legs = {'K601': ('LEG_LP', 'JACK_LP', '5V_SYS', 'N6_SL_A'), 'K602': ('LEG_LN', 'JACK_LN', 'N6_SL_A', 'N6_SL_C'),
        'K603': ('LEG_RP', 'JACK_RP', '5V_SYS', 'N6_SR_A'), 'K604': ('LEG_RN', 'JACK_RN', 'N6_SR_A', 'N6_SR_C')}
for k, (leg, jack, an, ca) in legs.items():
    add(k, 'K_AQV', {1: ('ANODE', an), 2: ('CATHODE', ca), 3: ('N.C.', 'NC'), 4: ('DRAIN', leg), 5: ('SOURCE', 'NC'), 6: ('DRAIN', jack)},
        f'TLP3545A output switch {leg} -> {jack}; A connection (pins 4-6); pin 5 (common source) and pin 3 unconnected (isolated pads)')

# ---------------- DC-sense networks and reference -------------------------------------------
for leg, node, rs, ru, rd, cc in (('LEG_LP', 'DC_SENSE_LP', 'R624', 'R628', 'R632', 'C608'),
                                  ('LEG_LN', 'DC_SENSE_LN', 'R625', 'R629', 'R633', 'C609'),
                                  ('LEG_RP', 'DC_SENSE_RP', 'R626', 'R630', 'R634', 'C610'),
                                  ('LEG_RN', 'DC_SENSE_RN', 'R627', 'R631', 'R635', 'C611')):
    r(rs, 'R6k8', leg, node, 'DC-sense series R_S')
    r(ru, 'R5k1', node, '3V3A', 'DC-sense bias R_U')
    r(rd, 'R16k9', node, 'GND', 'DC-sense R_D')
    c(cc, 'C4u7', node, 'GND', 'DC-sense filter (tau 8.4-12.9 ms)')
r('R661', 'R6k8', 'V3A_MON', 'GND', 'reference network R_S (leg input tied to GND)')
r('R639', 'R5k1', 'V3A_MON', '3V3A', 'reference network R_U (V3A_MON = a x 3V3A, a = 0.487)')
r('R640', 'R16k9', 'V3A_MON', 'GND', 'reference network R_D')
c('C616', 'C4u7', 'V3A_MON', 'GND', 'reference network filter (same tau as the leg networks)')

# ---------------- write ---------------------------------------------------------------------
with open('netlist.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['refdes', 'pin', 'pin_name', 'net', 'note'])
    for ref, key, pins, note in sorted(parts, key=lambda p: (p[0][0], int(''.join(ch for ch in p[0] if ch.isdigit())))):
        for pin in sorted(pins):
            nm, net = pins[pin]
            w.writerow([ref, pin, nm, net, note if pin == min(pins) else ''])

groups = {}
for ref, key, pins, note in parts:
    groups.setdefault(key, []).append(ref)


def refsort(rs):
    return sorted(rs, key=lambda x: (x[0], int(''.join(ch for ch in x if ch.isdigit()))))


with open('bom_rows.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['block', 'refs', 'qty', 'desc', 'value', 'package', 'rating_tolerance', 'mpn', 'lcsc', 'jlcpcb_class',
                'jlcpcb_stock_or_sourcing', 'fit', 'leadless', 'smt_pins_per_part', 'tht_pins_per_part', 'unit_price_usd',
                'datasheet_url', 'note'])
    total = 0.0
    for key, b in BOM.items():
        refs = refsort(groups.get(key, []))
        if not refs:
            continue
        total += b['price'] * len(refs)
        w.writerow([B6, ', '.join(refs), len(refs), b['desc'], b['value'], b['package'], b['rating'], b['mpn'], b['lcsc'],
                    b['cls'], b['stock'], 'Yes', b['lead'], b['smt'], b['tht'], f'{b["price"]:.4f}', b['url'], b.get('note', '')])
nparts = len(parts); npins = sum(len(p[2]) for p in parts)
print(f'{nparts} parts, {npins} pins, BOM lines {len([k for k in BOM if groups.get(k)])}, parts cost ~US$ {total:.2f} per board')
open('p08_bom_netlist_out.txt', 'w').write(f'{nparts} parts, {npins} pins, BOM lines {len([k for k in BOM if groups.get(k)])}, '
                                          f'parts cost ~US$ {total:.2f} per board (100-board tier prices)\n')
