#!/usr/bin/env python3
"""p09 - ADC2 sampling for the DC-sense and reference channels at ADCCLK 12 MHz (decision D-13).

WCH CH32V307 ADC [DS Table 4-42 and its formula, via digital/sources/source_quotes.txt]:
  RAIN_max = TS / (fADC x CADC x ln(2^(N+2))) - RADC,  N = 12, CADC = 8 pF, RADC <= 1 kOhm, RAIN <= 50 kOhm;
  tCONV = TS + 12.5 cycles.  (The formula assumes no external capacitor at the pin: conservative here.)
Sources: DC_SENSE_xx and V3A_MON: Thevenin R_TH = 6.8 k || 5.1 k || 16.9 k = 2.486 kOhm with 4.7 uF at the node (p06);
CC1_ADC / CC2_ADC: 14.67 kOhm (digital stream adc_settings).
"""
import numpy as np
from pcommon import V3V3_MIN

FADC, CADC, RADC, N = 12e6, 8e-12, 1e3, 12
R_TH = 1 / (1 / 6.8e3 + 1 / 5.1e3 + 1 / 16.9e3)
G = R_TH / 6.8e3
R_SER = 330.0 * 1.01     # DZ-1 (R3 final): R242-R246 330 ohm 1 % between each sense/reference node and its MCU pin (digital)
R_PIN = R_TH + R_SER     # source resistance seen at the pin for DC terms (leakage, average sampling charge)
C_NODE = 4.7e-6 * 0.85 * 0.85
R_CC = 14.67e3
TS_LIST = (1.5, 7.5, 13.5, 28.5, 41.5, 55.5, 71.5, 239.5)


def rain_max(ts):
    return min(ts / (FADC * CADC * np.log(2 ** (N + 2))) - RADC, 50e3)


def main():
    out = [__doc__]
    out.append('RAIN max at fADC = 12 MHz:  ' + ', '.join(f'{ts:g} cyc {rain_max(ts)/1e3:.1f} k' for ts in TS_LIST))
    ts_need = min(ts for ts in TS_LIST if rain_max(ts) >= R_PIN)
    ts_cc = min(ts for ts in TS_LIST if rain_max(ts) >= R_CC)
    out.append(f'Sense nodes R_TH {R_TH/1e3:.3f} k + R242-R246 {R_SER:.0f} ohm (DZ-1) = {R_PIN/1e3:.3f} k at the pin: table minimum TS = {ts_need:g} cycles (RAIN max {rain_max(ts_need)/1e3:.1f} k, '
               f'x{rain_max(ts_need)/R_PIN:.1f}); chosen 13.5 cycles (RAIN max {rain_max(13.5)/1e3:.1f} k, x{rain_max(13.5)/R_PIN:.1f}). '
               f'With {C_NODE*1e6:.1f} uF (min) at the pin the charge-share step is <= {CADC/C_NODE*3.3*1e6:.1f} uV '
               f'(= {CADC/C_NODE*3.3/(V3V3_MIN/4096):.3f} LSB) for a full-scale jump, so any TS would do.')
    out.append(f'CC1_ADC / CC2_ADC {R_CC/1e3:.2f} k: TS >= {ts_cc:g} cycles (RAIN max {rain_max(ts_cc)/1e3:.1f} k) - digital stream choice')
    # digital stream implementation (25 Sep 06:49): one TS for all channels (dual regular-simultaneous mode, ADC1 on
    # VBUS_SENSE in every slot), TS = 41.5 cycles, timer-triggered 20.000 kHz (TIM4 CC4), 8 conversions, DMA every 1 ms
    ts_all = 41.5
    seq = [('CC1_ADC', ts_all), ('CC2_ADC', ts_all), ('V3A_MON (dummy, discarded)', ts_all), ('V3A_MON', ts_all),
           ('DC_SENSE_LP', ts_all), ('DC_SENSE_LN', ts_all), ('DC_SENSE_RP', ts_all), ('DC_SENSE_RN', ts_all)]
    t_scan = sum(ts + 12.5 for _, ts in seq) / FADC
    f_rec = 20e3
    out.append(f'\nDigital implementation: TS {ts_all} cycles on every channel (RAIN max {rain_max(ts_all)/1e3:.1f} k >= {R_TH/1e3:.2f} k, '
               f'x{rain_max(ts_all)/R_TH:.0f}; the >= 7.5-cycle requirement is met), 8 conversions {t_scan*1e6:.1f} us per scan, '
               f'timer-triggered {f_rec/1e3:.0f} kHz (ADC2 {t_scan*f_rec*100:.0f} % busy) -> {f_rec/1e3:.0f} kHz per sense channel '
               f'(>= 10 kHz: met, x{f_rec/10e3:.0f})')
    # sampling-charge DC error: with 4.7 uF at the node the DC shift is the AVERAGE charge per scan drawn through R_TH:
    # dV_node = CADC x (V_node - V_cadc,start) x f_scan x R_TH.  The dummy draws the same charge from V3A_MON, so it
    # removes only the per-sample step (<= CADC/C_node x dV = 8 uV), not the DC shift (correction of the first p09 draft,
    # pointed out by the digital stream).
    k = CADC * f_rec * R_PIN    # DZ-1: the average sampling charge flows through R_TH + 330 ohm
    vddamax = 3.366
    e_ch_bound = k * vddamax / G                  # guaranteed: CADC may start anywhere in 0..VDDA (SAR state not specified)
    v_ref_lo, v_ref_hi = 0.50526 * 0.0 + 0.4874 * 3.234, 0.4874 * 3.366
    e_ref_prev = k * max(v_ref_hi - 0.0, 2.04 - v_ref_lo) / G   # model: CADC holds the previous channel (CC2 0..2.04 V)
    e_leg_prev = k * 2.0                          # legs follow legs, |legs| <= 1 V (difference <= 2 V)
    out.append(f'Sampling-charge DC error at {f_rec/1e3:.0f} kHz (CADC {CADC*1e12:.0f} pF x dV x f x (R_TH + 330 ohm), referred to the leg /g = {G:.4f}): '
               f'{k*1e3/G:.3f} mV per volt of CADC start voltage difference')
    out.append(f'  guaranteed bound (CADC start anywhere 0...VDDA {vddamax} V): <= {e_ch_bound*1e3:.2f} mV per channel -> leg reading '
               f'(leg - reference, independent signs) <= {2*e_ch_bound*1e3:.2f} mV; pair (reference cancels, two legs) <= '
               f'{2*e_ch_bound*1e3:.2f} mV  <- used in p06')
    out.append(f'  previous-channel model (information): reference after CC2 (0...2.04 V) <= {e_ref_prev*1e3:.2f} mV on every leg reading '
               f'(same sign, cancels in pairs); legs <= {e_leg_prev*1e3:.2f} mV; the dummy removes only the per-sample step '
               f'(<= {CADC/C_NODE*3.3*1e6:.0f} uV), not this DC shift')
    out.append(f'  (at 10 kHz every term halves: bound {e_ch_bound*0.5*1e3:.2f} mV per channel)')
    out.append('Tiers/estimator: the CIC^2 windows are defined in time (100 ms / 300 ms / 1.2 s); the firmware averages sample pairs '
               'to the 10 kHz stream used in p06 (DMA block of 20 scans = 1.000 ms), so deadlines and content rejection are '
               'unchanged; the 10 kHz alias term in p06 is kept (conservative: 20 kHz halves it).')
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))
    return dict(e_ch_bound=e_ch_bound, f=f_rec, ts=ts_all)


if __name__ == '__main__':
    main()
