#!/usr/bin/env python3
"""p21b_r10_content - R10 F-1 (d) and F-5 share: no-false-trip checks of the R10 hardware (E-3 + OR + LPW stages), content
boundaries, and (e) the boot self-test windows.  RELEASE calculation; self-contained (pcommon + p21_r10_f1 constants).

Time-domain model at the fastest / most sensitive corner of every part (worst case for false trips):
  * E-3 level c+ = (LP - LN > V_L min), c- mirrored (TLV1704, 5 us ignored); E-3 timer charges at the T_P-min corner while ANY
    of its inputs is true and is discharged at the slowest NPN reset (1.8 V/ms, >= 0.4 mA into 220 nF) otherwise.
  * OR: 1-pole taps at the SLOWEST tau (most lag), lowest thresholds; TLV1704 outputs stretched by the 5 us release bound.
  * LPW: 1-pole taps (slowest tau), lowest V_LL; LPW timer at the T_P2-min corner, slowest reset (50 uA minus the R_T2 current),
    level and timer outputs stretched by 0.9 ms each; its output (timer > 0 V) feeds the E-3 timer of the natural direction.
Balanced content LN = -LP (clipping only shortens every window, so the unclipped case is the worst).
"""
import numpy as np
import p21_r10_f1 as M
from pcommon import A_CAL, A_CAL_TRIM, A_CAL_DRIFT, A_DEF_MODEL, A_DEF_BOUND, A_UNCAL_MODEL, A_UNCAL_BOUND

out = [__doc__]; P = out.append
VL_MIN = M.VL[0]; TPMIN = M.TP[0]
VORP_MIN, VORN_MIN = M.VORP[0], M.VORN[0]
VLLP_MIN, VLLN_MIN = M.VLLP[0], M.VLLN[0]
TAU_OR, TAU_LP = M.TAU_OR[1], M.TAU_LP[1]
STRETCH = M.V34_TPD          # LPW (TLV3402) output release bound
STRETCH_OR = M.V17_TPD       # OR (TLV1704) output release bound
# E-3 timer at the T_P-min corner (p21: T_P min 19.50 ms): normalised charging toward vinf with threshold vt, reset level 0.20 V
VP = M.VPOS_MAX
R_, C_ = M.RT * (1 - M.TOL01), M.CT * 0.98 * 0.995
VT = M.kt[0] * VP - M.V17_OS
VINF = VP + M.V17_IB * R_
V0 = 0.20
t_chk = R_ * C_ * np.log((VINF - V0) / (VINF - VT))
DIS = 1.8e3        # V/s slowest NPN discharge of C_T (0.4 mA / 220 nF)
# LPW timer fastest corner
R2, C2 = M.RT2 * (1 - M.TOL1), M.CT2 * M.CT2_LO
T0_2 = -M.VNEG_MIN + M.V34_VOL50
VINF2 = VP + M.V34_IB * R2
VT2 = -M.V34_OS
DIS2 = (50e-6 - (VP + M.VNEG_MAX) / R2) / (M.CT2 * M.CT2_HI)      # slowest reset slope, V/s
t_chk2 = R2 * C2 * np.log((VINF2 - T0_2) / (VINF2 - VT2))


def lp1(u, tau, dt):
    """1-pole low-pass along the last axis (rows = cases), exact ZOH step, zero initial state"""
    u = np.atleast_2d(u); a = np.exp(-dt / tau); y = np.empty_like(u); s = np.zeros(u.shape[0])
    for i in range(u.shape[1]):
        s = u[:, i] + (s - u[:, i]) * a
        y[:, i] = s
    return y


def stretch(b, n):
    """output stays asserted n samples after the input drops (release delay bound)"""
    if n <= 0:
        return b
    c = np.concatenate([np.zeros((b.shape[0], 1), int), np.cumsum(b.astype(int), axis=1)], axis=1)
    idx = np.arange(b.shape[1]); lo = np.maximum(idx - n, 0)
    return (c[:, idx + 1] - c[:, lo]) > 0


def _timer(run, dt, vinf, tau, v0, vfloor, dis, thr):
    """charge toward vinf while run, else discharge at dis (V/s) down to vfloor; returns max voltage and above-threshold mask"""
    a = np.exp(-dt / tau); v = np.full(run.shape[0], v0, float); vmax = v.copy(); above = np.zeros(run.shape, bool)
    for i in range(run.shape[1]):
        r = run[:, i]
        v = np.where(r, vinf + (v - vinf) * a, np.maximum(vfloor, v - dis * dt))
        vmax = np.maximum(vmax, v); above[:, i] = v > thr
    return vmax, above


def sim(lp, ln, dt):
    """rows = cases. returns per row: (max E-3 timer fraction of V_T, max LPW timer voltage, trip flag)"""
    lp = np.atleast_2d(lp); ln = np.atleast_2d(ln); n = int(round(STRETCH / dt)); n_or = int(round(STRETCH_OR / dt + 0.5))
    e3p = (lp - ln) > VL_MIN; e3n = (ln - lp) > VL_MIN
    tlp, tln = lp1(lp, TAU_OR, dt), lp1(ln, TAU_OR, dt)
    orp = stretch((tlp > VORP_MIN) | (tln < -VORN_MIN), n_or)   # -> c+ base
    orn = stretch((tlp < -VORN_MIN) | (tln > VORP_MIN), n_or)   # -> c- base
    wlp, wln = lp1(lp, TAU_LP, dt), lp1(ln, TAU_LP, dt)
    outp = np.zeros(lp.shape, bool); outn = np.zeros(lp.shape, bool); lmax = np.full(lp.shape[0], -9.0)
    for cond, dest in (((wlp > VLLP_MIN), 'p'), ((wlp < -VLLN_MIN), 'n'), ((wln > VLLP_MIN), 'n'), ((wln < -VLLN_MIN), 'p')):
        vm, ab = _timer(stretch(cond, n), dt, VINF2, R2 * C2, T0_2, T0_2, DIS2, VT2)
        lmax = np.maximum(lmax, vm)
        if dest == 'p':
            outp |= stretch(ab, n)
        else:
            outn |= stretch(ab, n)
    fr = np.zeros(lp.shape[0]); trip = np.zeros(lp.shape[0], bool)
    for run in (e3p | orp | outp, e3n | orn | outn):
        vm, ab = _timer(run, dt, VINF, R_ * C_, V0, V0, DIS, VT)
        fr = np.maximum(fr, (vm - V0) / (VT - V0)); trip |= ab.any(axis=1)
    return fr, lmax, trip


def e3_only(lp, ln, dt):
    lp = np.atleast_2d(lp); ln = np.atleast_2d(ln); fr = np.zeros(lp.shape[0])
    for run in ((lp - ln) > VL_MIN, (ln - lp) > VL_MIN):
        vm, _ = _timer(run, dt, VINF, R_ * C_, V0, V0, DIS, VT)
        fr = np.maximum(fr, (vm - V0) / (VT - V0))
    return fr


P(f'\nCorners: V_L min {VL_MIN:.3f} V, E-3 timer T_P min corner check {t_chk*1e3:.2f} ms (p21 {TPMIN*1e3:.2f} ms); OR V_OR min '
  f'+{VORP_MIN:.3f}/-{VORN_MIN:.3f} V, tap tau {TAU_OR*1e3:.3f} ms; LPW V_LL min +{VLLP_MIN:.3f}/-{VLLN_MIN:.3f} V, tap tau {TAU_LP*1e3:.2f} ms, '
  f'timer corner {t_chk2*1e3:.1f} ms (p21 T_P2 min {M.TP2[0]*1e3:.1f} ms), reset slope {DIS2:.0f} V/s; output stretch {STRETCH*1e3:.1f} ms')

# ------------------------------------------------------------------ (d1) sines: analytic E-3 margins (F-5) and time-domain checks
P('\n(d1) Sines >= 20 Hz (x (1 - 100 ppm) clock), E-3 time above V_L min per half cycle vs T_P min [CALC, F-5 margins]:')
levels = [('calibrated 2.192 V', A_CAL), ('calibrated +0.15 dB 2.230 V', A_CAL_TRIM), ('calibrated + G drift 2.325 V', A_CAL_DRIFT),
          ('-4.5 dB default, model 1.828 V', A_DEF_MODEL), ('-4.5 dB default, 3.66 V basis 2.180 V', A_DEF_BOUND),
          ('(information) untrimmed highest gain 3.069 V', A_UNCAL_MODEL), ('(information) untrimmed 3.66 V bound', A_UNCAL_BOUND)]
f20 = 20.0 * (1 - 1e-4)
for lab, A in levels:
    tab = (np.pi - 2 * np.arcsin(min(1.0, VL_MIN / (2 * A)))) / (2 * np.pi * f20)
    P(f'  {lab:46s}: pair {2*A:.3f} V pk, above V_L {tab*1e3:6.2f} ms vs T_P min {TPMIN*1e3:.2f} ms -> '
      f'{"no trip, margin %.1f %%" % (100*(1-tab/TPMIN)) if tab < TPMIN else "TRIPS (outside the F-5 rule)"}')
P('  Time-domain check of the combined system (E-3 + OR + LPW, worst corners), every onset phase, frequencies 20 Hz ... 2 kHz:')
worst = {}
FREQS = (f20, 21.0, 22.0, 25.0, 30.0, 40.0, 50.0, 70.0, 100.0, 150.0, 200.0, 300.0, 400.0, 500.0, 700.0, 1000.0, 2000.0)
dt = 10e-6; t = np.arange(0, 0.30, dt)
ph = np.linspace(0, np.pi, 8, endpoint=False)
FF, PH = np.meshgrid(np.array(FREQS), ph, indexing='ij'); FF = FF.ravel()[:, None]; PH = PH.ravel()[:, None]
for lab, A in levels[:5]:
    s = A * np.sin(2 * np.pi * FF * t[None, :] + PH)
    fr, lm, tr = sim(s, -s, dt)
    low = (FF[:, 0] < 30)
    fe = e3_only(s[low], -s[low], dt).max()
    worst[lab] = (fr.max(), lm.max(), bool(tr.any()))
    P(f'    {lab:40s}: max E-3 timer progress {100*fr.max():5.1f} % of V_T (E-3 alone {100*fe:5.1f} %), max LPW timer {lm.max():+.2f} V '
      f'(threshold 0 V), trip: {"YES" if tr.any() else "no"}')
P('  Above 2 kHz: OR/LPW taps attenuate content below every OR/LPW threshold above ~430 Hz (p21), and the E-3 window per half cycle '
  'is < 0.25 ms (reset each cycle): no trip at any amplitude up to 2.325 V.')

# ------------------------------------------------------------------ (d2) squares, bursts, asymmetric content, polarity reversals
P('\n(d2) Squares, bursts, asymmetric content, polarity reversals (time domain, worst corners):')


def first_trip_f(amps, fmin=4.0, fmax=40.0):
    """per amplitude: highest square frequency that still trips (bisection, vectorised over amplitudes)"""
    amps = np.asarray(amps, float)[:, None]; dt = 20e-6; t = np.arange(0, 0.5, dt)
    def trips(fv):
        s = amps * np.sign(np.sin(2 * np.pi * fv[:, None] * t[None, :] + 1e-9))
        return sim(s, -s, dt)[2]
    lo = np.full(len(amps), fmin); hi = np.full(len(amps), fmax)
    ok_lo = trips(lo); ok_hi = trips(hi)
    for _ in range(12):
        mid = 0.5 * (lo + hi); tm = trips(mid)
        lo = np.where(tm, mid, lo); hi = np.where(tm, hi, mid)
    return [None if not a else (fmax if b_ else l) for a, b_, l in zip(ok_lo, ok_hi, lo)]


SQ = (('FS square 2.325 V', A_CAL_DRIFT), ('FS square 2.192 V', A_CAL), ('0.8 V square', 0.8), ('0.5 V square', 0.5), ('0.35 V square', 0.35))
for (lab, A), fm in zip(SQ, first_trip_f([a for _, a in SQ])):
    P(f'  {lab:22s}: may mute up to {fm:.1f} Hz (fastest corners)' if fm else f'  {lab:22s}: never mutes (>= 4 Hz)')
P(f'  E-3 FS-square boundary unchanged: certain <= {1/(2*(M.TP[1]+0.0))/1:.1f} Hz, possible <= {1/(2*M.TP[0]):.1f} Hz (plateau vs T_P); '
  f'LPW (squares between V_LL and V_L/2): possible <= {1/(2*(M.TP2[0]+M.TP[0])):.1f} Hz, certain <= {1/(2*(M.TP2[1]+M.TP[1])):.1f} Hz')
# bursts / reversals
dt = 20e-6; t = np.arange(0, 0.6, dt)
cases = []
A = A_CAL_DRIFT
s1 = A * np.sin(2 * np.pi * f20 * t) * (t < 0.025)                                  # single half-cycle burst
s2 = np.where(t < 0.025, A, np.where(t < 0.05, -A, 0.0))                           # one FS square cycle, then silence
s3 = A * np.sin(2 * np.pi * f20 * t) * (t < 0.1) - A * np.sin(2 * np.pi * f20 * (t - 0.1)) * (t >= 0.1)   # polarity reversal
s4 = A * (0.75 * np.sin(2 * np.pi * f20 * t) + 0.25 * np.sin(4 * np.pi * f20 * t + np.pi / 2)) / 0.94  # asymmetric 20 Hz + 2nd
s5 = np.where(t < 0.3, 0.30 * np.sign(np.sin(2 * np.pi * 8 * t)), 0.0)            # 8 Hz 0.3 V square (sub-20 Hz, low level)
s6 = 0.30 + 0.9 * np.sin(2 * np.pi * 20 * t)                                       # 0.3 V DC offset in programme + 20 Hz
for lab, s in (('FS 20 Hz single half-cycle burst', s1), ('one FS 20 Hz square cycle then silence', s2),
               ('FS 20 Hz sine with a polarity reversal at a peak', s3), ('asymmetric 20 Hz (2nd harmonic, peak 2.325 V)', s4),
               ('8 Hz square 0.30 V (sub-20 Hz, below V_L)', s5), ('0.30 V offset + 0.9 V 20 Hz sine', s6)):
    fr, lm, tr = sim(s, -s, dt); fe = e3_only(s, -s, dt)[0]
    P(f'  {lab:48s}: E-3 progress {100*fr[0]:5.1f} % (E-3 alone {100*fe:5.1f} %), LPW timer max {lm[0]:+.2f} V -> '
      f'{"TRIP (mute)" if tr[0] else "no trip"}{" - pre-existing E-3 boundary" if (tr[0] and fe >= 1) else (" - NEW (LPW)" if tr[0] else "")}')

# ------------------------------------------------------------------ content boundary stated plainly
P('\n(d3) New content boundary (R10), stated plainly:')
tl = M.TP2[0] + M.TP[0]; th = M.TP2[1] + M.TP[1]
fs_sine = (np.pi - 2 * np.arcsin(M.VLL_MIN / A_CAL_DRIFT)) / (2 * np.pi * tl)
P(f'  * Unchanged for full-scale content: sines >= 20 Hz never mute up to the calibrated level incl. drift ({A_CAL_DRIFT} V/leg); '
  f'FS squares may mute <= {1/(2*M.TP[0]):.1f} Hz, certainly <= {1/(2*M.TP[1]):.1f} Hz (E-3, as v1.0).')
_lag = M.TAU_LP[1] * np.log((A_CAL_DRIFT - M.VLL_MIN) / M.VLL_MIN) + M.V34_TPD      # tap decay lag after a FS excursion + release delay
_x5 = 0.5
_cross5 = M.TAU_LP[1] * np.log((_x5 + A_CAL_DRIFT) / (_x5 - M.VLL_MAX)) + 2 * M.V34_TPD
P(f'  * New (LPW), stated on the timer: the LPW timer runs while the 3.3 ms-filtered leg tap is beyond +-V_LL ({M.VLL_MIN:.3f} ... {M.VLL_MAX:.3f} V, '
  f'about -17 dBFS). A mute CAN occur once the tap has stayed beyond V_LL for >= {tl*1e3:.1f} ms (T_P2 min + T_P min) and WILL occur after '
  f'{th*1e3:.1f} ms plus the amplitude-dependent tap crossing and <= {2*M.V34_TPD*1e3:.1f} ms comparator delays (the crossing grows without bound '
  f'as the level approaches V_LL max; e.g. {_cross5*1e3:.1f} ms extra for a leg stepping from -{A_CAL_DRIFT} V to {_x5} V).')
P(f'    In raw-leg terms: the tap decays more slowly than the leg, so a FS excursion ({A_CAL_DRIFT} V) can mute after >= {(tl-_lag)*1e3:.1f} ms '
  f'(tap lag <= {(_lag-M.V34_TPD)*1e3:.1f} ms + {M.V34_TPD*1e3:.1f} ms release). Examples from the time-domain model (tap included): '
  f'sustained sub-20 Hz content, e.g. a full-scale sine below {fs_sine:.1f} Hz (the old RC windows muted below 11.5 Hz), a -10 dBFS sine below about '
  f'{(np.pi-2*np.arcsin(M.VLL_MIN/(0.316*A_CAL_TRIM)))/(2*np.pi*tl):.1f} Hz, squares at or below ~7 Hz (d2), a DC offset '
  f'>= {M.VLL_MAX/A_CAL_TRIM:.3f} FS (the old windows muted >= 0.123-0.144 FS after ~1 s; OD-1 P4 mutes >= 0.15 FS).')
# ---- (d3) with the 10 nA tap surface-leakage allowance (p21 c2): LPW level range widened by +-10 mV (orchestrator, 26 Sep)
_lk = M.I_SURF * 1e6
_vmin_lk, _vmax_lk = M.VLL_MIN - _lk, M.VLL_MAX_LK
_fs = (('calibrated -0.15 dB', A_CAL * 10 ** (-0.15 / 20)), ('calibrated nominal', A_CAL), ('calibrated +0.15 dB', A_CAL_TRIM),
       ('drift ceiling', A_CAL_DRIFT), ('lowest (P-4 low end, smaller leg, drift down)', A_CAL * 10 ** (-0.181 / 20) * 0.9593))
P(f'  * DC-offset boundary with the {M.I_SURF*1e9:.0f} nA leakage allowance (LPW level {_vmin_lk:.3f} ... {_vmax_lk:.3f} V; without it '
  f'{M.VLL_MIN:.3f} ... {M.VLL_MAX:.3f} V), offset = steady DC on one leg as a fraction of that unit\'s FS peak:')
for _lab, _f in _fs:
    P(f'      FS {_f:.3f} V ({_lab:44s}): CAN mute >= {_vmin_lk/_f:.3f} FS, WILL mute >= {_vmax_lk/_f:.3f} FS '
      f'(without the allowance {M.VLL_MIN/_f:.3f} / {M.VLL_MAX/_f:.3f} FS)')
P(f'      -> over all units and corners: an offset below {_vmin_lk/A_CAL_DRIFT:.3f} FS never mutes (drift-ceiling FS); an offset of '
  f'>= {_vmax_lk/_fs[-1][1]:.3f} FS mutes on every unit (lowest FS).')
_save = (globals()['VLLP_MIN'], globals()['VLLN_MIN'])
VLLP_MIN, VLLN_MIN = VLLP_MIN - _lk, VLLN_MIN - _lk
_sq = first_trip_f([0.8, 0.5, 0.35, 0.30])
VLLP_MIN, VLLN_MIN = _save
_fs_sine_lk = (np.pi - 2 * np.arcsin(_vmin_lk / A_CAL_DRIFT)) / (2 * np.pi * tl)
P(f'      examples with the allowance (most sensitive corner): FS sine below {_fs_sine_lk:.2f} Hz (without: {fs_sine:.2f} Hz); squares may mute up to '
  + ', '.join(f'{a} V {f_:.1f} Hz' if f_ else f'{a} V never' for a, f_ in zip((0.8, 0.5, 0.35, 0.30), _sq)) + ' (without the allowance: the (d2) values 7.4 / 7.2 / 6.9 Hz; the 0.30 V square was not bounded there, only its 8 Hz case = no trip).')
P('  * Removed: the RC leg-window boundary (FS 20 Hz square at the aged-capacitor corner, 6.2 % margin) no longer exists.')

# ------------------------------------------------------------------ (e) boot self-test windows
P('\n(e2) Boot self-test windows for the new channels (switch open, stream guard bypassed, CPLD test word; times from the DC at the legs):')
def win(x_lo, x_hi, path):
    if path == 'LPW':
        tmin = M.TAU_LP[0] * np.log(x_hi / (x_hi - M.VLL_MIN)) + M.TP2[0] + M.TP[0]
        tmax = M.TAU_LP[1] * np.log(x_lo / (x_lo - M.VLL_MAX)) + 2 * M.V34_TPD + M.TP2[1] + M.TP[1]
    elif path == 'OR':
        vt = 0.30                                       # test-mode reference magnitude bound (V_OR- test level, see below)
        tmin = M.TP[0]; tmax = M.TAU_OR[1] * np.log(x_lo / (x_lo - vt)) + M.V17_TPD + M.TP[1]
    else:
        tmin = M.TP[0]; tmax = M.TP[1] + 5e-6
    return tmin, tmax + 0.83e-3
rows = []
# pass windows (upper ends also size the self-test time); each computed window + DAC <= 1 ms must lie inside its pass window
PASS = {'(f) LPW': (0.065, 0.110), '(g) OR': (0.018, 0.032), '(e) E-3': (0.018, 0.026)}
# per-leg levels of the test words: calibrated units 0.30 FS -> 0.30 x 2.192...2.325; default gain -> x 1.390...1.828 V FS
for name, lab, fs, path in (('(f) LPW', '+-0.30 FS', 0.30, 'LPW'), ('(g) OR', '+-0.25 FS with the OR test line', 0.25, 'OR')):
    x_lo, x_hi = fs * 1.390, fs * A_CAL_DRIFT
    tmin, tmax = win(x_lo, x_hi, path)
    rows.append((name, tmin, tmax))
    ok = PASS[name][0] <= tmin and tmax + 1e-3 <= PASS[name][1]
    P(f'  {name + " " + lab:40s}: leg {x_lo:.3f}...{x_hi:.3f} V -> DC_PERMIT_N high {tmin*1e3:5.1f} ... {tmax*1e3:5.1f} ms (+ DAC <= 1 ms) '
      f'-> pass window {PASS[name][0]*1e3:.0f}-{PASS[name][1]*1e3:.0f} ms: {"inside" if ok else "NOT INSIDE - FIX"}')
# (e) E-3: the word must put the pair above V_L max at every gain: +-0.50 FS on calibrated units, +-0.85 FS at the -4.5 dB default
# low ends as digital derives them: calibration P-4 low end + smaller leg (-0.181 dB) and the G drift downwards (x 0.9593)
_k_lo = 10 ** (-0.181 / 20) * 0.9593
_e3 = (('calibrated, +-0.55 FS', 0.55 * A_CAL * _k_lo, 0.55 * A_CAL_DRIFT), ('-4.5 dB default, +-0.85 FS', 0.85 * 1.390 * 0.9593, 0.85 * A_DEF_BOUND))
tmin, tmax = win(0, 0, 'E3')
ok = PASS['(e) E-3'][0] <= tmin and tmax + 1e-3 <= PASS['(e) E-3'][1] and all(2 * lo > M.VL[1] for _, lo, _ in _e3)
P(f'  (e) E-3 ' + '; '.join(f'{lab_}: leg {lo:.3f}...{hi:.3f} V (pair >= {2*lo:.2f} V > V_L max {M.VL[1]:.3f} V)' for lab_, lo, hi in _e3) +
  f' -> DC_PERMIT_N high {tmin*1e3:5.1f} ... {tmax*1e3:5.1f} ms (+ DAC <= 1 ms) -> pass window {PASS["(e) E-3"][0]*1e3:.0f}-{PASS["(e) E-3"][1]*1e3:.0f} ms: '
  f'{"inside" if ok else "NOT INSIDE - FIX"}; pair margins over V_L max ' + ' / '.join(f'{(2*lo - M.VL[1])*1e3:+.0f} mV' for _, lo, _ in _e3) +
  f'; OR silent on calibrated units (leg <= {0.55*A_CAL_DRIFT:.3f} V < V_OR min {M.VOR_MIN:.3f} V) and at the default for the model range '
  f'(<= {0.85*1.828:.3f} V; with the 3.66 V basis {0.85*A_DEF_BOUND:.3f} V the OR may co-fire: masking only, same window); LPW slower (>= 71 ms). '
  f'(0.50 FS would leave only {(2*0.50*A_CAL*_k_lo - M.VL[1])*1e3:+.0f} mV on calibrated units and a {2*0.50*1.390:.2f} V pair at the lowest default gain.)')
# OR test mode (N6_ORTEST high): Q627 saturates (IB >= (3.207 - 0.75 V) / 101 k = 24 uA vs IC <= 9.3 uA) and pulls V_OR+ through
# R951 10 k 1 %; V_OR- = (T + VNEG)/2.  Comparator errors: TLV1704 VOS + IB x 330 k tap; idle-leg offset <= 7.73 mV (analog E-4) [E]
R951, VCESAT_MAX = 10e3, 0.05            # VCE(sat) at IC ~9 uA, IB ~24 uA (forced beta < 0.4): 0 ... 50 mV bound [E, Ebers-Moll]
k_lo = R951 * 0.99 / (360e3 * 1.01 + R951 * 0.99); k_hi = R951 * 1.01 / (360e3 * 0.99 + R951 * 1.01)
vorp_t = (3.234 * k_lo, 3.366 * k_hi + VCESAT_MAX * (1 - k_hi))
err_t = M.V17_OS + M.V17_IB * M.R_ORT
off_idle = 7.73e-3
t_test_vorn = [(-M.VNEG_MAX + 3.207) / 2, (-M.VNEG_MIN + 3.366) / 2]
P(f'  OR test line high (3V3 logic 3.207-3.366 V): Q627 pulls V_OR+ through R951 10 k to {vorp_t[0]:.3f} ... {vorp_t[1]:.3f} V '
  f'(defined positive test threshold; comparator error <= {err_t*1e3:.1f} mV); V_OR- = (T + VNEG)/2 = {t_test_vorn[0]:+.3f} ... {t_test_vorn[1]:+.3f} V.')
P(f'    idle leg (offset <= {off_idle*1e3:.2f} mV) vs the test thresholds: positive margin {(vorp_t[0]-err_t-off_idle)*1e3:.0f} mV, negative margin '
  f'{(-t_test_vorn[1]-err_t-off_idle)*1e3:.0f} mV -> no spurious OR firing in test mode (without R951, V_OR+ = VCE(sat) ~15-50 mV '
  f'could fall below the ~20 mV idle-leg + comparator error: false self-test pass or fail); test word |leg| >= {0.25*1.390:.3f} V fires its '
  f'channel with >= {(0.25*1.390 - off_idle - err_t - vorp_t[1])*1e3:.0f} mV (positive) / {(0.25*1.390 - off_idle - err_t + t_test_vorn[0])*1e3:.0f} mV (negative) margin; LPW (level >= {M.VLL_MIN:.3f} V) is '
  f'slower (>= {(M.TP2[0]+M.TP[0])*1e3:.0f} ms) and E-3 silent (pair <= {2*0.25*A_CAL_DRIFT:.2f} V < V_L min) -> an OR failure shows as a late trip.')
c_node = 50e-12                          # reference-node capacitance bound (4 comparator inputs + trace; no capacitor on N6_VORP/N6_VORN) [E]
tau_n, tau_p = 235e3 * 1.01 * c_node, (R951 * 1.01) * c_node
P(f'  Settle after N6_ORTEST goes high: no capacitor on N6_VORP / N6_VORN; tau <= {tau_n*1e6:.1f} us (V_OR-, 235 k x 50 pF) / '
  f'{tau_p*1e6:.1f} us (V_OR+, R951 x 50 pF), Q627 turn-on < 5 us -> within 1 mV after <= {tau_n*np.log(2.0/1e-3)*1e6:.0f} us; the taps do not '
  f'move. Digital\'s 1 ms settle [ASSUMP] is confirmed (>= 10 x); the same holds after PC15 returns low (tau <= {204e3*1.01*c_node*1e6:.1f} us).')
P('  Pass windows: ' + ', '.join(f'{k} {v[0]*1e3:.0f}-{v[1]*1e3:.0f} ms' for k, v in PASS.items()) + ' (E-3 unchanged). Each word on L then R, '
  'both signs (LP+/LN- and LP-/LN+ pairs, as the old a\' test). Old a\' (RC leg windows) deleted.')
P('  Coverage is PAIRWISE: a balanced word makes LP+ and LN- (or LP- and LN+) true together on one N6_OL base, so the test detects a failed')
P('  pair, a failed shared path (timer, E-3 timer, H) or a both-sided reference fault, but a single dead channel - or an open one-sided')
P('  reference (e.g. R937 open disables all four negative OR channels, R939 open all four positive LPW channels) - is masked by its mate.')
P('  Per-channel coverage comes once from the')
P('  production / bring-up per-leg DC injection (amplifier link R417-R420 removed); a boot-time per-channel test would need a one-sided')
P('  test mode (second test line) - not in this design.')
R = 0.209
t_lpw_pass, t_or_pass, t_e3_pass = PASS['(f) LPW'][1], PASS['(g) OR'][1], PASS['(e) E-3'][1]   # each test ends at its trip
tot_full = 4 * t_lpw_pass + 4 * t_or_pass + 4 * t_e3_pass + 12 * R + 2 * 0.252
tot_rot = 4 * t_lpw_pass + 1 * t_or_pass + 4 * t_e3_pass + 9 * R + 2 * 0.252
P(f'  Self-test time: all channels every boot {tot_full:.2f} s (R9: 2.84 s); with one OR direction per boot (rotating, all four within '
  f'4 boots) {tot_rot:.2f} s (<= 3 s).')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
