#!/usr/bin/env python3
"""p10 - X-6 DAC-supply and MCLK supervisor (review states #6, #15, #18, #27; signal F1, F6) and the R3 firmware
numbers (IWDG, pre-close DC limits, boot self-test).  numpy only.

Circuit (designators R3):
  U605 TI TLV3402IDR (dual nanopower comparator, open drain) on 3V3M, two independent "3V3A good" channels.
       ch A: IN- = 3V3A x R676/(R675+R676) (N6_V3A_DA); IN+ = 3V3M x R678/(R677+R678) + hysteresis R679 22 M from
             OUT A (N6_V3AG_A, pull-up R680 100 k to 3V3M).  OUT A low = 3V3A good.  OUT A high (not good) turns on
             Q619 AO3400A (D = N2_AVCC_EN_G, S = GND) -> U206 input B low -> X201 stopped, Q616 off.
       ch B: identical parts R682-R687 -> N6_V3AG_B -> Q620 AO3400A (D = AUD_EN) -> TLV767 (3V3D) and U303 off.
       Readback: N6_V3AG_A -> R688 470 k -> MCU PA12, N6_V3AG_B -> R689 470 k -> MCU PB9 (spare pins, D-11).
       Why not TLV1704 on 3V3M (decision example): IQ 4 x 100 uA on the always-on rail breaks the 31 uA S6
       suspend margin, and its output low level (<= 0.6 V at 0 mA / 0.9 V at 4 mA, VS 36 V) is not a guaranteed
       logic low for U206 (VIL 0.8 V).  The FET pull-downs give VOL ~ 0 V at the 0.34 / 0.72 mA sink currents.
  U606 TI TLV1704AIPWR on VPOS/VNEG (outputs wired-OR on N6_H like U601-U603, so they tolerate H at ~VNEG):
       ch1 1V3 good: IN+ = 1V3 via R670 10 k (N6_V13_CMP, C629 1 nF, hysteresis R671 2.2 M from N6_H,
                     boot-test injection R674 2.2 k + D610 BAS70 from MCU PB8 = V13_TEST_N, open drain);
                     IN- = VPOS x R673/(R672+R673) (N6_REF13).
       ch2 MCLK alive: MCLK (U301 XI) -> R665 330 R (R9) -> U607 74AUP1G17 (3V3D, C623) -> C624 100 pF C0G -> N6_PMP ->
                     D609 BAS70-04 (a1 = GND clamp, a2 -> k2 = N6_MCK_RC) -> C625 82 pF C0G || R666 1 M ->
                     R667 100 k -> IN+ (N6_MCK_CMP); IN- = VPOS x R669/(R668+R669) (N6_REFMCK).
       ch3 3V3A-good repeater: IN- = N6_V3AG_A via R681 4.7 M (N6_V3AG_S); IN+ = N6_REF13.  Every U605A trip
                     also pulls N6_H -> the >= 53 ms permit recovery applies to every 3V3A event (no autonomous
                     re-close through Q616).
       ch4 spare: IN+ = GND, IN- = VNEG, output not connected.
Labels: [DS] datasheet min/max, [DS-typ], [CALC], [ASSUMP].
"""
import itertools
import numpy as np
from pcommon import VPOS_MIN, VPOS_NOM, VPOS_MAX, VNEG_MIN, VNEG_MAX, A_FS, ISC_BOUND, leg_dc_max
from p05_switch_drive import T_H_FALL, R_H, C_H, C_H_LO, C_H_HI, AO_VTH, N7002_VTH, TLV_SINK
from pcommon import SW_TOFF_DESIGN, SW_TOFF_MAX_25

out = [__doc__]
P = out.append

# ------------------------------------------------------------------ rails and part data
V3M = (3.207, 3.3, 3.343)                     # 3V3M TPS70933 static range -2.8/+1.3 % (power R9 E-16; was +-1.5 %)
V3A = (3.234, 3.300, 3.366)                    # 3V3A (LP5907) +-2 % [pcommon]
V3D = (3.234, 3.300, 3.366)                    # 3V3D (TLV767) +-2 % [pcommon]
V13 = (1.283, 1.300, 1.317)                    # 1V3 (TLV75801, D-7) [power]
TOL01 = 0.001 + 25e-6 * 40                     # 0.1 % 25 ppm thin film over 40 K
TOL1 = 0.01 + 100e-6 * 40                      # 1 % thick film
TLV34_VOS, TLV34_IB = 4.4e-3, 1.5e-9           # TLV3402 full range [DS SBOS160 7.7]
TLV34_VOL50 = 0.30                             # V at IOL 50 uA, full range [DS]
TLV34_IQ_HI, TLV34_IQ_LO = 0.95e-6, 0.75e-6    # per channel, output high / low, full range [DS]
TLV34_TPD_TYP = 300e-6                         # t(PHL) at 2 mV overdrive, 25 C [DS-typ]; no maximum published
TLV34_TPD_BOUND = 3 * TLV34_TPD_TYP            # [ASSUMP] x3 on the worst typical
TLV17_VOS, TLV17_IB, TLV17_IQ = 5.5e-3, 20e-9, 100e-6   # TLV1704 full range [DS SBOS589D 7.6]
TLV17_TPD_BOUND = 5e-6                         # [ASSUMP] 10 x the 460 ns typ (100 mV overdrive) for small overdrive
AO_CISS_B, AO_RDS25, AO_HOT = 1.0e-9, 0.048, 1.3
AUP_VTP_MAX, AUP_VTN_MIN = 2.32, 0.88          # 74AUP1G17 VT+ max / VT- min at VCC 3.0 V, -40..125 C [DS Nexperia t.9]
AUP_VOH4, AUP_VOL4 = 2.30, 0.50                # VOH at -4 mA / VOL at 4 mA, VCC 3.0 V, -40..125 C [DS]
AUP_CI, AUP_CO, AUP_CPD = 1.1e-12, 1.7e-12, 6e-12   # CI/CO typ [DS-typ]; CPD bound [ASSUMP; DS typ < 5 pF]
AUP_ICC = 0.9e-6
BAS_VF_MAX, BAS_VF_MIN, BAS_CD = 0.41, 0.10, 2.0e-12  # BAS70: VF <= 410 mV at 1 mA [DS]; >= 0.1 V near 0 A [ASSUMP]; Cd <= 2 pF at 0 V [DS]
F_MCLK = 80e6
R665 = 330.0                                   # R9 E-11: MCLK tap resistor (was 1 k); digital layout rule
X201_TR = 4.5e-9                               # tr/tf max at 15 pF [DS Kyocera, D-3]; 10-90 % assumed
X201_VOL_F, X201_VOH_F = 0.10, 0.90            # output levels as a fraction of VCC [ASSUMP: CMOS SPXO 0.1/0.9 VCC]

# ------------------------------------------------------------------ helpers
def vdiv(v, rt, rb, e=0.0):
    return v * rb * (1 + e) / (rb * (1 + e) + rt * (1 - e))


# ================================================================== 1. U605 3V3A good (3V3M)
P('\n1. U605 TLV3402 "3V3A good" channels (A -> Q619 -> N2_AVCC_EN_G, B -> Q620 -> AUD_EN); per channel:')
R_IT, R_IB = 44.2e3, 200e3       # R675/R682 (3V3A top), R676/R683 (bottom), 0.1 % 0402 (R9: YAGEO RT0402 BRD <= 240 k; was 237 k / 953 k)
R_RT, R_RB = 300e3, 1.00e6       # R677/R684 (3V3M top), R678/R685 (bottom), 0.1 % 0603 RT0603BRD (R9: was 330 k / 1.00 M 0402)
R_HY, R_PU = 22e6, 100e3         # R679/R686 1 %, R680/R687 1 %


def u605_thr(v3m, e_it, e_rt, e_hy, e_pu, vos, ib, vol, rising):
    """3V3A level at which channel A/B switches.  rising=True: output high (not good) -> good."""
    rt = R_RT * (1 + e_rt); rb = R_RB * (1 - e_rt)
    rhy = R_HY * (1 + e_hy); rpu = R_PU * (1 + e_pu)
    # output node: low -> vol; high -> pull-up to 3V3M loaded by R_HY into IN+ (~2.5 V) and the 470 k readback
    if rising:
        vin_guess = 2.55
        vout = v3m - rpu * (v3m - vin_guess) / (rhy + rpu)
    else:
        vout = vol
    g = 1 / rt + 1 / rb + 1 / rhy
    vplus = (v3m / rt + vout / rhy - ib) / g
    k = R_IB * (1 - e_it) / (R_IB * (1 - e_it) + R_IT * (1 + e_it))
    rth_in = R_IT * R_IB / (R_IT + R_IB)
    return (vplus + vos + ib * rth_in) / k


def corners_605(rising):
    vals = []
    for v3m, a, b, c, d, s, ibs, vol in itertools.product((V3M[0], V3M[2]), (-TOL01, TOL01), (-TOL01, TOL01),
                                                         (-TOL1, TOL1), (-TOL1, TOL1), (-TLV34_VOS, TLV34_VOS),
                                                         (-TLV34_IB, TLV34_IB), (0.0, TLV34_VOL50)):
        vals.append(u605_thr(v3m, a, b, c, d, s, ibs, vol, rising))
    return min(vals), max(vals)


fall_nom = u605_thr(3.3, 0, 0, 0, 0, 0, 0, 0.0, False)
rise_nom = u605_thr(3.3, 0, 0, 0, 0, 0, 0, 0.0, True)
f_lo, f_hi = corners_605(False)
r_lo, r_hi = corners_605(True)
P(f'  dividers: 3V3A {R_IT/1e3:.0f} k / {R_IB/1e3:.0f} k (k = {R_IB/(R_IT+R_IB):.4f}); 3V3M {R_RT/1e3:.0f} k / {R_RB/1e6:.2f} M '
  f'(0.1 %, 25 ppm); hysteresis {R_HY/1e6:.0f} M; pull-up {R_PU/1e3:.0f} k')
P(f'  falling threshold (good -> not good): nominal {fall_nom:.3f} V, worst {f_lo:.3f} ... {f_hi:.3f} V')
P(f'  rising threshold (not good -> good):  nominal {rise_nom:.3f} V, worst {r_lo:.3f} ... {r_hi:.3f} V; '
  f'hysteresis {1e3*(rise_nom-fall_nom):.0f} mV nominal')
P(f'  3V3A in regulation >= {V3A[0]:.3f} V -> margin to the highest rising threshold {1e3*(V3A[0]-r_hi):.0f} mV '
  f'({"OK" if V3A[0] > r_hi else "FAIL"}); the gates release on every unit once 3V3A is in tolerance')
P('  (inputs: IN- common mode <= 2.72 V, IN+ <= 2.50 V; TLV3402 input range -0.1 V ... VCC + 5 V [DS], so 3V3A above 3V3M '
  'during sequencing is harmless)')
# output stage and sink currents
i_236 = V3M[2] / (10e3 * 0.99)
i_237 = V3M[2] / (4.7e3 * 0.99)
v_on_gate_min = V3M[0] - R_PU * 1.01 * (V3M[0] - 2.40) / (R_HY * 0.986)
P(f'  output low (good): pull-up current {V3M[2]/(R_PU*0.99)*1e6:.1f} uA <= 50 uA (VOL <= {TLV34_VOL50} V spec point) -> '
  f'Q619/Q620 VGS <= 0.30 V < AO3400A VGS(th) min {AO_VTH[0]} V (margin {AO_VTH[0]-0.30:.2f} V): FETs off, '
  f'drain leakage <= 5 uA (30 V spec; ~0 at 3.3 V)')
P(f'  output high (not good): gate >= {v_on_gate_min:.2f} V (>= 2.5 V RDS(on) spec point)')
P(f'  Q619 sinks N2_AVCC_EN_G: MCU AVCC_EN high through R236 10 k -> {i_236*1e3:.3f} mA x {AO_RDS25*AO_HOT*1e3:.0f} mOhm '
  f'-> VOL {i_236*AO_RDS25*AO_HOT*1e6:.0f} uV (74LVC1G11 VIL 0.8 V: guaranteed low)')
P(f'  Q620 sinks AUD_EN: MCU PC10 high through R237 4.7 k -> {i_237*1e3:.3f} mA -> VOL {i_237*AO_RDS25*AO_HOT*1e6:.0f} uV '
  f'(TLV767 EN low and Q504 off with any threshold >= 0.1 V); MCU pin sources <= {i_237*1e3:.2f} mA while blocked (8 mA pin)')
P('  (a TLV1704 output on 3V3M would give VOL <= 0.6-0.9 V [DS, VS 36 V; no 3.3 V row] -> not a guaranteed U206 low)')
t_gate = R_PU * 1.01 * AO_CISS_B * np.log((V3M[0] - 0.3) / (V3M[0] - 2.5))
t_605 = TLV34_TPD_BOUND + t_gate
P(f'  timing: comparator {TLV34_TPD_TYP*1e6:.0f} us typ (no maximum published) -> {TLV34_TPD_BOUND*1e6:.0f} us bound [ASSUMP x3]; '
  f'gate 0.3 -> 2.5 V through R680 into <= 1 nF: {t_gate*1e6:.0f} us -> gate applied <= {t_605*1e3:.2f} ms after 3V3A '
  f'crosses the falling threshold; release (good) through the comparator sink: <= {TLV34_TPD_BOUND*1e3:.1f} ms + 3V3A rise')

# ================================================================== 2. U606 channels
P('\n2. U606 TLV1704 on VPOS/VNEG (outputs on N6_H):')
# ch1 1V3 good
R13T, R13B, R_S1, R_F1 = 237e3, 100e3, 10.0e3, 2.2e6
def ref13(vpos, e):
    return vdiv(vpos, R13T, R13B, e)
def thr13(vpos, e, vos, ib, vh, rising):
    vr = ref13(vpos, e) + vos
    # IN+ = (V13*R_F1 + VH*R_S1)/(R_S1+R_F1) - ib*(R_S1||R_F1)
    rp = R_S1 * R_F1 / (R_S1 + R_F1)
    return (vr + ib * rp - vh * R_S1 / (R_S1 + R_F1)) * (R_S1 + R_F1) / R_F1
th13 = []
for vpos, e, vos, ib in itertools.product((VPOS_MIN, VPOS_MAX), (-TOL01, TOL01), (-TLV17_VOS, TLV17_VOS), (-TLV17_IB, TLV17_IB)):
    th13.append((thr13(vpos, e, vos, ib, VPOS_MIN - 0.3 if True else 0, False), thr13(vpos, e, vos, ib, -VNEG_MAX + 0.01, True)))
# falling uses H high (VPOS - leakage drop ~0.3 V bound .. VPOS); rising uses H low (~VNEG .. VNEG + 0.6)
f13 = [thr13(vp, e, vo, ib, vh, False) for vp, e, vo, ib in itertools.product((VPOS_MIN, VPOS_MAX), (-TOL01, TOL01),
       (-TLV17_VOS, TLV17_VOS), (-TLV17_IB, TLV17_IB)) for vh in (vp - 0.34, vp)]
r13 = [thr13(vp, e, vo, ib, vh, True) for vp, e, vo, ib in itertools.product((VPOS_MIN, VPOS_MAX), (-TOL01, TOL01),
       (-TLV17_VOS, TLV17_VOS), (-TLV17_IB, TLV17_IB)) for vh in (-VNEG_MAX + 0.01, -VNEG_MIN + 0.60)]
f13n = thr13(VPOS_NOM, 0, 0, 0, VPOS_NOM - 0.1, False); r13n = thr13(VPOS_NOM, 0, 0, 0, -VNEG_MAX + 0.3, True)
P(f'  ch1 1V3 good: ref VPOS x {R13B/1e3:.0f} k/({R13T/1e3:.0f} k + {R13B/1e3:.0f} k) = {ref13(VPOS_NOM,0):.3f} V nominal; '
  f'1V3 via {R_S1/1e3:.0f} k, hysteresis {R_F1/1e6:.1f} M from N6_H, C629 1 nF (tau 10 us)')
P(f'    falling (permit up): nominal {f13n:.3f} V, worst {min(f13):.3f} ... {max(f13):.3f} V; rising (permit down): nominal '
  f'{r13n:.3f} V, worst up to {max(r13):.3f} V')
P(f'    1V3 in regulation >= {V13[0]} V -> margin to the highest rising threshold {1e3*(V13[0]-max(r13)):.0f} mV '
  f'({"OK" if V13[0] > max(r13) else "FAIL"}); ESS DVDD minimum 1.235 V lies {1e3*(1.235-max(f13)):.0f} mV above the highest '
  'falling threshold (a DVDD sag inside 1.235 V ... threshold is not detected; ESS behaviour there is unpublished)')
P('    H low for another reason only raises the 1V3 level needed to release (<= the rising maximum above): no latch')
v_test = 1.317 * 2.2e3 / (10e3 + 2.2e3) + BAS_VF_MAX
P(f'    boot test: PB8 (V13_TEST_N, open drain) low -> IN+ <= {v_test:.2f} V (via R674 2.2 k + D610) < ref min '
  f'{ref13(VPOS_MIN,-TOL01)-TLV17_VOS:.3f} V -> trip; PB8 high-Z: leakage 1 uA x 10 k = 10 mV; PB8 driven high by mistake: '
  'D610 blocks (no masking)')
# ch2 MCLK alive
RMT, RMB = 1.00e6, 100e3         # VE: R668 1.00 M 1 % (C26083, Basic), R669 100 k 1 % (C25741, Basic); was 866 k / 100 k 0.1 %
TOLM = TOL1                      # VE: 1 % 100 ppm/K thick film for the MCLK-threshold divider
R_B, C_HOLD, C_PUMP, R_S2 = 1.0e6, 82e-12, 100e-12, 100e3
C_STRAY = 1.0e-12
vref_m = lambda vp, e: vdiv(vp, RMT, RMB, e)
vth_m_max = vref_m(VPOS_MAX, TOLM) + TLV17_VOS + TLV17_IB * R_S2 + TLV17_IB * RMT * RMB / (RMT + RMB)
vth_m_min = vref_m(VPOS_MIN, -TOLM) - TLV17_VOS - TLV17_IB * R_S2 - TLV17_IB * RMT * RMB / (RMT + RMB)
k_att_min = C_PUMP * 0.95 / (C_PUMP * 0.95 + 2 * BAS_CD + C_STRAY)
v_sw_min = AUP_VOH4 - AUP_VOL4                    # at VCC 3.0 V (3V3D >= 3.234 V is better) [DS]
# pump droop per cycle (charge drawn by R_B between edges) and the finite-frequency factor
fcr = F_MCLK * C_PUMP * 0.95 * R_B * 0.99
v_r_min = (k_att_min * v_sw_min - 2 * BAS_VF_MAX) * fcr / (1 + fcr)
v_r_max = V3D[2] - 2 * BAS_VF_MIN
P(f'  ch2 MCLK alive: threshold VPOS x {RMB/1e3:.0f} k/({RMT/1e3:.0f} k + {RMB/1e3:.0f} k) = {vref_m(VPOS_NOM,0):.3f} V nominal, '
  f'worst {vth_m_min:.3f} ... {vth_m_max:.3f} V (VOS, IB x (R667 + R_th))')
P(f'    pump: C624 {C_PUMP*1e12:.0f} pF C0G 5 % into D609 BAS70-04 (Cd <= 2 pF each), C625 {C_HOLD*1e12:.0f} pF C0G 5 % || '
  f'R666 {R_B/1e6:.1f} M; U607 swing >= {v_sw_min:.2f} V (VOH 2.30 V at -4 mA, VOL 0.50 V at 4 mA, VCC 3.0 V, -40..125 C)')
P(f'    running (80 MHz, 45-55 %): node >= k x swing - 2 VF = {k_att_min:.3f} x {v_sw_min:.2f} - 2 x {BAS_VF_MAX} = {v_r_min:.3f} V '
  f'(f C R = {fcr:.0f}: the pump is saturated, duty-cycle independent) vs threshold max {vth_m_max:.3f} V -> margin '
  f'{v_r_min - vth_m_max:.3f} V ({v_r_min/vth_m_max:.2f} x) -> never "dead" while U607 toggles')
ripple = (v_r_min / R_B / F_MCLK) / C_HOLD
P(f'    ripple per MCLK cycle {ripple*1e3:.3f} mV; the level holds down to ~{1/(C_PUMP*R_B)/1e3:.0f} kHz toggle rate (any activity = alive)')
tau_hi = R_B * (1 + TOL1) * (C_HOLD * 1.05 + C_PUMP * 1.05 + BAS_CD + C_STRAY)   # MCLK stopped high: C624 discharges via D2 too
tau_lo_stop = R_B * (1 + TOL1) * (C_HOLD * 1.05 + BAS_CD + C_STRAY)            # stopped low: node P clamped by D1
tau_min = R_B * (1 - TOL1) * (C_HOLD * 0.95)
t_dead_max = tau_hi * np.log(v_r_max / vth_m_min) + TLV17_TPD_BOUND
t_dead_lo = tau_lo_stop * np.log(v_r_max / vth_m_min) + TLV17_TPD_BOUND
t_dead_min = tau_min * np.log(v_r_min / vth_m_max)
P(f'    MCLK stopped (any static level; XI held low by R227, or stuck high): node from <= {v_r_max:.2f} V to the lowest threshold '
  f'{vth_m_min:.3f} V: stopped high tau <= {tau_hi*1e3:.3f} ms -> "dead" <= {t_dead_max*1e3:.3f} ms; stopped low <= '
  f'{t_dead_lo*1e3:.3f} ms; never faster than {t_dead_min*1e3:.3f} ms  (requirement <= 0.5 ms: '
  f'{"OK" if t_dead_max <= 0.5e-3 else "FAIL"})')
P('    3V3D off: U607 unpowered (Ioff input, no pump) -> node 0 V -> "dead" (fail-safe); U606 unpowered with the node '
  'charged: injection <= 3.2 V / 100 k = 32 uA (TLV1704 limit 10 mA)')
# input swing at U607 (R665 + input capacitance) - periodic steady state
def u607_input(tau, tr, duty, vcc, n=8, pts=2000):
    T = 1 / F_MCLK
    t = np.linspace(0, n * T, n * pts, endpoint=False); dt = t[1] - t[0]
    ramp = tr / 0.8                            # 0-100 % edge from a 10-90 % spec
    tp = (t % T)
    th = duty * T                              # time at >= 50 %
    # trapezoid centred so that the 50 % crossings are at 0 and th
    def wave(x):
        up = np.clip((x + ramp / 2) / ramp, 0, 1)
        dn = np.clip((th + ramp / 2 - x) / ramp, 0, 1)
        return np.minimum(up, dn)
    src = X201_VOL_F * vcc + (X201_VOH_F - X201_VOL_F) * vcc * wave(tp)
    y = np.empty_like(src); y[0] = src.mean()
    a = np.exp(-dt / tau)
    for i in range(1, len(src)):
        y[i] = src[i] + (y[i - 1] - src[i]) * a
    last = y[-pts:]
    return last.max(), last.min()
P(f'    U607 input through R665 {R665:.0f} ohm (MCLK at XI: {X201_VOL_F:.1f}/{X201_VOH_F:.1f} VCC levels [ASSUMP], duty 45/55 %), '
  f'Schmitt VT+ <= {AUP_VTP_MAX} V / VT- >= {AUP_VTN_MIN} V at VCC 3.0 V, scaled with VCC [ASSUMP]:')
inp_rows = []
for tr in (X201_TR, 2.5e-9, 1.5e-9):
    for cin in (1.5e-12, 2.4e-12):
        worst_hi = 9; worst_lo = 9
        for duty in (0.45, 0.55):
            for vcc in (V3D[0], V3D[2]):
                pk, vl = u607_input(R665 * 1.01 * cin, tr, duty, vcc)
                vtp = AUP_VTP_MAX * vcc / 3.0; vtn = AUP_VTN_MIN * vcc / 3.0
                worst_hi = min(worst_hi, pk - vtp); worst_lo = min(worst_lo, vtn - vl)
        inp_rows.append((tr, cin, worst_hi, worst_lo))
        P(f'      edges {tr*1e9:.1f} ns, C_in {cin*1e12:.1f} pF (tau {1.01*cin*R665*1e9:.2f} ns): peak - VT+max {worst_hi*1e3:+.0f} mV, '
          f'VT-min - valley {worst_lo*1e3:+.0f} mV -> {"toggles" if min(worst_hi, worst_lo) > 0 else "NOT GUARANTEED"}')
P('    -> R9 E-11: with R665 = 330 ohm the U607 input crosses both Schmitt limits at every corner including the Kyocera 4.5 ns '
  'edge (rows above) - the round-3 limitation (1 k: not provable at 4.5 ns) is closed; the boot self-test still checks it.')
c_eff = 2.5e-12 / (1 + (2 * np.pi * F_MCLK * R665 * 2.5e-12) ** 2)   # <= 2.5 pF behind R665 (digital R9)
P(f'    MCLK loading (R9 E-11, R665 330 ohm): <= 2.5 pF behind R665 appears as C/(1 + (wRC)^2) = {c_eff*1e12:.2f} pF at 80 MHz; '
  'digital R9: X201 load <= 14.23 pF with the layout rule X201 -> R203 -> XI <= 10 mm, R665 at XI, R665 -> U607 <= 3 mm')
# ch3 repeater
v_gate_lo = TLV34_VOL50 + TLV17_IB * 4.7e6
v_gate_hi = v_on_gate_min - TLV17_IB * 4.7e6
P(f'  ch3 3V3A repeater: IN- = N6_V3AG_A through R681 4.7 M: good <= {v_gate_lo:.3f} V vs ref min '
  f'{ref13(VPOS_MIN,-TOL01)-TLV17_VOS:.3f} V; not good >= {v_gate_hi:.2f} V vs ref max {ref13(VPOS_MAX,TOL01)+TLV17_VOS:.3f} V; '
  f'delay 4.7 M x 3.5 pF = {4.7e6*3.5e-12*1e6:.0f} us after the U605A output')
P('    -> every U605A trip also trips H (>= 53 ms recovery), and U206 stops X201 at the same time')
P('  ch4 spare: IN+ = GND > IN- = VNEG -> output off (not connected)')

# ================================================================== 3. frozen-code cases
P('\n3. Frozen-DAC-code cases (hardware only; removal = detection + H fall to Q617 off + TLP3545A tOFF):')
t_hfall = T_H_FALL
cases = [('X201 dead while enabled / MCLK stops at any level', t_dead_max),
         ('open MCLK joint or R203 (XI held low by R227)', t_dead_lo),
         ('DVDD (1V3) collapse, from the 1V3 threshold crossing', 3 * 10e3 * 1.1e-9 + TLV17_TPD_BOUND),
         ]
T_OE_OPEN = 1.002e-3   # p05: N2_MCLK_OE falls -> Q616 off -> switch open (tOFF design included)
P(f'  H fall (one comparator, >= 4 mA, C617 1 uF +10 %): {t_hfall*1e3:.3f} ms; tOFF {SW_TOFF_DESIGN*1e3:.1f} ms design '
  f'(0-60 C, x2 [ASSUMP]) / {SW_TOFF_MAX_25*1e3:.1f} ms at 25 C [DS]')
p16 = (2 * leg_dc_max(A_FS, 8.0, min(VPOS_MAX, VNEG_MAX))) ** 2 / 16.0
p32 = (2 * leg_dc_max(A_FS, 16.0, min(VPOS_MAX, VNEG_MAX))) ** 2 / 32.0
P(f'  worst frozen code = full-scale DC on both legs (+-{A_FS:.3f} V): 16 ohm {p16*1e3:.0f} mW (current bound {ISC_BOUND} A), '
  f'32 ohm {p32*1e3:.0f} mW; SE 16 ohm {A_FS**2/16*1e3:.0f} mW')
res_frozen = []
for name, tdet in cases:
    trem = tdet + t_hfall + SW_TOFF_DESIGN
    res_frozen.append((name, tdet, trem, p16 * trem, p32 * trem))
    P(f'  {name:62s}: detect <= {tdet*1e3:.3f} ms -> removed <= {trem*1e3:.2f} ms (<= 3 ms: {"OK" if trem <= 3e-3 else "FAIL"}); '
      f'E16 <= {p16*trem*1e3:.2f} mJ, E32 <= {p32*trem*1e3:.2f} mJ (<= 2 mJ: {"OK" if max(p16, p32)*trem <= 2e-3 else "FAIL"})')
t_3v3a = t_605 + T_OE_OPEN
P(f'  (information, not a frozen code) 3V3A collapse: U605A gate <= {t_605*1e3:.2f} ms [TLV3402 typ x3] -> U206 stops X201 and '
  f'Q616 opens the LEDs -> switch open <= {t_3v3a*1e3:.2f} ms after 3V3A crosses the threshold (U606 ch3 trips H 16 us later; '
  'the CM window also sees the collapse); E16 <= ' + f'{p16*t_3v3a*1e3:.2f} mJ')
P('  Not covered (stated): DAC core hang with MCLK, 1V3 and 3V3A all good; CPLD/serialiser freezing one word; DVDD sag between '
  'the threshold and 1.235 V -> leg windows (0.30 V) + CM window + firmware tiers as before (p03/p06).')

# ================================================================== 4. start-up and normal states
P('\n4. Start-up and normal states (no false trip; permit timing):')
tau_h_lo = R_H * 0.99 * C_H * C_H_LO; tau_h_hi = R_H * 1.01 * C_H * C_H_HI
t617_min = tau_h_lo * np.log((VPOS_MAX - (-VNEG_MIN + 0.6)) / (VPOS_MAX - AO_VTH[0]))
P(f'  H recovery after the last channel releases: Q617 on after >= {t617_min*1e3:.0f} ms (<= 135 ms), DC_PERMIT_N low <= 205 ms (p05)')
P('  order: ANA_EN (VPOS/VNEG; U606 powered: ch1 low (1V3 off), ch2 low (3V3D off), ch3 low (3V3A off)) -> AVCC_EN '
  '(3V3A >= rising max -> U605 releases; ch3 releases) -> AUD_EN (now allowed by U605B; 3V3D, 1V3 -> ch1 releases) -> '
  'MCLK_EN/MCLK_PERMIT -> X201 runs <= 3 ms [DS] -> ch2 alive within ~1 us of the first edges -> RESETB release -> soft start '
  '104.9 ms -> CM window releases last (65-100 % of the ramp)')
P('  -> all new channels release >= 68 ms before the CM window (they release before the DAC soft start starts); the last '
  'release, and hence the pre-close timeline of R2.7 (pre-close pass <= 405 ms), is unchanged.  The switch cannot close '
  f'earlier than {t617_min*1e3:.0f} ms after MCLK is alive (Q617) and never while X201 is stopped (Q616): MCLK always starts first.')
P(f'  playback: MCLK node >= {v_r_min:.2f} V vs <= {vth_m_max:.3f} V; 1V3 >= 1.283 V vs <= {max(r13):.3f} V; 3V3A >= 3.234 V vs '
  f'<= {r_hi:.3f} V; U605 outputs low -> no trip in any normal state (playback, idle/mute, rate or family change with MCLK '
  'running, High/Default switch)')
P('  states where the new channels hold H low on purpose: programming mode (MCLK off), MCU reset (MCLK_PERMIT low), suspend '
  'and power-down (MCLK stopped after RELAY_EN low), any firmware stop of X201: re-close then needs DC_PERMIT_N low >= 50 ms '
  '(adds <= 205 ms after MCLK restarts).')

# ================================================================== 5. currents
P('\n5. Supply currents (maxima) for the power budget:')
i605_ok = 2 * (TLV34_IQ_LO + V3M[2] / (R_PU * 0.99) + V3M[2] / ((R_RT + R_RB) * (1 - TOL01)))
i605_susp = 2 * (TLV34_IQ_HI + V3M[2] / ((R_RT + R_RB) * (1 - TOL01)) + (V3M[2] - 2.4) / (R_HY * 0.986)) + (V3M[2] - 0.5) / (4.7e6 * 0.99)
i3v3a = 2 * V3A[2] / ((R_IT + R_IB) * (1 - TOL01))
c_load = C_PUMP * 1.05 * (2 * BAS_CD + C_STRAY) / (C_PUMP * 1.05 + 2 * BAS_CD + C_STRAY)
i607 = F_MCLK * V3D[2] * (AUP_CPD + AUP_CO + c_load) + AUP_ICC + v_r_max / R_B
i_x201 = F_MCLK * V3D[2] * (c_eff + 0.3e-12)
i606 = 4 * TLV17_IQ
i_vpos_div = VPOS_MAX / ((R13T + R13B) * (1 - TOL01)) + VPOS_MAX / ((RMT + RMB) * (1 - TOL01))
P(f'  3V3M: U605 + dividers + pull-ups, 3V3A good (normal): {i605_ok*1e6:.1f} uA; suspend (3V3A off, U606 unpowered): '
  f'{i605_susp*1e6:.1f} uA (S6 margin 31 uA -> {31-i605_susp*1e6:.1f} uA left); PB8 test pulse 0.11 mA for 5 ms per boot')
P(f'  3V3A: two 3V3A dividers {i3v3a*1e6:.1f} uA')
P(f'  3V3D: U607 at 80 MHz (CPD <= 6 pF [ASSUMP], CO 1.7 pF, pump load {c_load*1e12:.2f} pF) {i607*1e3:.2f} mA; X201 extra '
  f'drive {i_x201*1e3:.2f} mA (inside the Kyocera 8.0 mA maximum, total load <= 15 pF); 0 with 3V3D off')
P(f'  VPOS/VNEG: U606 4 x 100 uA = {i606*1e3:.2f} mA (flows V+ -> V-) + VPOS dividers {i_vpos_div*1e6:.1f} uA; 1V3 input '
  f'<= 0.2 uA; tripped state: the existing R647 term only')
P(f'  block-6 totals (D-9 1.26/1.25 mA): I+ <= {1.244+i606*1e3+i_vpos_div*1e3:.3f} mA, I- <= {1.231+i606*1e3:.3f} mA (permitted)')

# ================================================================== 6. firmware numbers
P('\n6. Firmware numbers (R3):')
LSI = (25e3, 60e3)
for pr, rl in ((4, 239),):
    tmin = pr * (rl + 1) / LSI[1]; tmax = pr * (rl + 1) / LSI[0]
P(f'  IWDG: prescaler /4, reload 239 -> timeout {tmin*1e3:.1f} ... {tmax*1e3:.1f} ms (LSI 25-60 kHz, WCH Tab 4-15) <= 40 ms; '
  f'refresh every <= 8 ms (half the minimum), only when all tasks report alive')
t_irq_mask = 1e-3
P(f'  no autonomous re-close before the reset: a trip seen while the MCU is healthy -> EXTI on DC_PERMIT_N (highest priority, '
  f'interrupts never masked > {t_irq_mask*1e3:.0f} ms) -> RELAY_EN low, latched until the full pre-close sequence; a hung MCU '
  f'(last refresh <= trip + {t_irq_mask*1e3:.0f} ms) resets <= {(tmax+t_irq_mask)*1e3:.1f} ms after the trip -> RELAY_EN high-Z, '
  f'R646 -> switch open <= {(tmax+t_irq_mask+1.010e-3)*1e3:.1f} ms, while Q617 cannot conduct again before {t617_min*1e3:.0f} ms '
  f'after the trip clears -> margin {(t617_min-tmax-t_irq_mask-1.010e-3)*1e3:.1f} ms.  After reset RELAY_EN rises only after '
  'the boot self-test and the pre-close checks (fresh edge).  3V3A events: U606 ch3 puts them on H as well; MCLK stops: ch2.')
P('  suspend: per orchestrator DX-2 the IWDG is lengthened to <= 1.6 s only in Stop with RELAY_EN low and all switched domains '
  'off (digital: /16, reload 2499 = 0.667-1.600 s) and restored to /4, 239 before any domain is enabled; H is held low (VPOS off) '
  'and MCLK is dead (3V3D off) meanwhile, so the permit argument is unaffected.')
# pre-close
import p06_dcsense_tiers as p06   # R3 final (DZ-1): e_leg/e_pair include the 330 ohm pin resistors
_e, E_LEG, E_PAIR, _tm = p06.errors()
E_ALIAS = [v for k_, v in _e.items() if k_.startswith('aliasing')][0]
GAIN = 0.025
e_pre_leg = E_LEG - E_ALIAS; e_pre_pair = E_PAIR - E_ALIAS
L_leg, L_pair = 0.070, 0.090
OFS_HEALTHY_LEG, OFS_HEALTHY_PAIR = 6.24e-3, 12.48e-3   # healthy-board offset (analog calculation)
rd_h_leg = OFS_HEALTHY_LEG * (1 + GAIN) + (E_LEG - E_ALIAS); rd_h_pair = OFS_HEALTHY_PAIR * (1 + GAIN) + (E_PAIR - E_ALIAS)
need_leg = 10e-3 * (1 + GAIN) + e_pre_leg; need_pair = 20e-3 * (1 + GAIN) + e_pre_pair
blk_leg = (L_leg + e_pre_leg) / (1 - GAIN); blk_pair = (L_pair + e_pre_pair) / (1 - GAIN)
P(f'  pre-close DC limits: guaranteed sensing error with the DAC muted = e_leg {E_LEG*1e3:.2f} - content aliasing '
  f'{E_ALIAS*1e3:.2f} = {e_pre_leg*1e3:.2f} mV (pair {e_pre_pair*1e3:.2f} mV) + 2.5 % gain (p06); a healthy board inside the '
  f'10/20 mV offset spec reads <= {need_leg*1e3:.1f} / {need_pair*1e3:.1f} mV')
P(f'    -> limits |leg| <= {L_leg*1e3:.0f} mV, |pair| <= {L_pair*1e3:.0f} mV (averaged over the 50 ms pre-close window; margin '
  f'{(L_leg-need_leg)*1e3:.1f} / {(L_pair-need_pair)*1e3:.1f} mV); closure guaranteed refused for true DC > {blk_leg*1e3:.0f} mV '
  f'(leg) / {blk_pair*1e3:.0f} mV (pair) (the round-2 limits 0.10/0.12 V allowed up to '
  f'{(0.10+e_pre_leg)/(1-GAIN)*1e3:.0f} / {(0.12+e_pre_pair)/(1-GAIN)*1e3:.0f} mV)')
P(f'    healthy board (offset <= {OFS_HEALTHY_LEG*1e3:.2f} / {OFS_HEALTHY_PAIR*1e3:.2f} mV): reads <= {rd_h_leg*1e3:.1f} / '
  f'{rd_h_pair*1e3:.1f} mV -> passes with {(L_leg-rd_h_leg)*1e3:.1f} / {(L_pair-rd_h_pair)*1e3:.1f} mV margin')
P('    advisory (not a guarantee): |reading - stored factory baseline| <= 25 mV, logged; three consecutive failures -> '
  'refuse and report')
# boot self-test
from p03_detector import thresholds, e96, R1_CHOSEN, C1_CHOSEN, C_LO, C_HI, R_TOL_FILT
ra = e96(10e3 * (3.900 / 0.30 - 1)); ran = e96(10e3 * (3.722 / 0.30 - 1))
th = thresholds(ra, 10e3, ran, 10e3, R1_CHOSEN, 100e3)
x = 0.5 * A_FS
tau_f = R1_CHOSEN * (1 - R_TOL_FILT) * C1_CHOSEN * C_LO; tau_s = R1_CHOSEN * (1 + R_TOL_FILT) * C1_CHOSEN * C_HI
t_tr_min = tau_f * np.log(x / (x - th['trip_min']))
t_rb = C_H * C_H_HI * (VPOS_MAX - N7002_VTH[0]) / TLV_SINK
t_tr_max = tau_s * np.log(x / (x - th['trip_max'])) + t_rb
t_clr_max = tau_s * np.log(x / th['trip_min']) + 0.205
P(f'  boot self-test (every attach, switches open, stream guard bypassed, DAC volume at 0 dB after its ramp):')
P(f'   a) leg windows: digital DC +0.5 FS on L only ({x:.3f} V per leg, LP +, LN -), then -0.5 FS, then the same on R '
  f'(4 runs): DC_PERMIT_N must go "not permitted" between {t_tr_min*1e3:.0f} and {t_tr_max*1e3:.0f} ms after the DC reaches '
  f'the legs (pass window 45 ... 120 ms), and return <= {t_clr_max*1e3:.0f} ms after mute (pass <= 700 ms); <= 3.3 s total.  '
  'Covers each channel, each polarity, R601-R604/C601-C604 values (timing), the shared dividers N6_VTHP/N6_VTHN in the sense '
  'that one window of each polarity trips, H, Q618.  Not covered: one dead window of a pair (the other leg of the balanced '
  'pair trips first) -> production test injects DC per leg.')
x_def = x * 10 ** (-4.5 / 20)
t_d_min = tau_f * np.log(x_def / (x_def - th['trip_min']))
t_d_max = tau_s * np.log(x_def / (x_def - th['trip_max'])) + t_rb
t_d_clr = tau_s * np.log(x_def / th['trip_min']) + 0.205
P(f'      (without a stored calibration, i.e. at the -4.5 dB pre-calibration default: {x_def:.3f} V per leg -> "not permitted" '
  f'between {t_d_min*1e3:.0f} and {t_d_max*1e3:.0f} ms (pass window 95 ... 210 ms), back <= {t_d_clr*1e3:.0f} ms (pass <= 550 ms); '
  f'trip levels {th["trip_min"]:.3f} ... {th["trip_max"]:.3f} V, tau {tau_f*1e3:.0f} ... {tau_s*1e3:.0f} ms, readback lag <= {t_rb*1e3:.2f} ms)')
P(f'   b) MCLK alive (after the permit is present >= 50 ms): MCLK_PERMIT low -> PB1 low within 10 us (U206/R234 test, D-19) '
  f'and DC_PERMIT_N high between {t_dead_min*1e3:.2f} and {(t_dead_max+t_rb)*1e3:.2f} ms (pass <= 2.0 ms); MCLK_PERMIT high '
  '-> DC_PERMIT_N low within 64 ... 208 ms (X201 start <= 3 ms + recovery; pass <= 250 ms).')
P(f'   c) 1V3 good: PB8 (V13_TEST_N) low for 5 ms -> DC_PERMIT_N high within {(3*10e3*1.1e-9+TLV17_TPD_BOUND+t_rb)*1e3:.2f} ms '
  '(pass <= 2.0 ms); release -> low within 61 ... 205 ms (pass <= 250 ms).')
P('   d) 3V3A good: before AVCC_EN, PA12 and PB9 read high (gates active); >= 2 ms after V3A_MON reads >= 3.20 V both read low '
  '(pass); with 3V3A off, N2_AUD_EN_MCU high for 1 ms must leave the I2C lines low (3V3D held off by Q620) - optional, '
  'production test otherwise. U606 ch3 and Q619 are production-test items (their effect is masked by other channels at boot).')
P('   any failure -> RELAY_EN stays low, error reported over USB, no audio.')

open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
