#!/usr/bin/env python3
"""p06 - DC-sense ADC networks, guaranteed error budget, firmware tiers and the combined
hardware + firmware energy envelope.

Network per leg (on LEG_xx, amplifier side of the switch):  LEG -> R_S -> node -> R_U -> 3V3A,
node -> R_D -> GND, C_N node -> GND, node -> MCU ADC pin.  Reference network (new, replaces the
3V3A/2 monitor, same MCU pin V3A_MON): identical R_S/R_U/R_D/C_N with the R_S input tied to GND ->
V3A_MON = a*3V3A exactly equals every leg node at 0 V leg, so reading = (code_leg - code_ref)/g cancels
the ADC offset, the 3V3A value and its drift.  node = a*3V3A + g*leg.

ADC facts (CH32V307 datasheet V3.5, tables 4-42/4-43) [DS]: EO +-4 LSB, ED +-3 LSB max, EL +-4 LSB max
(RAIN < 10 k, VDDA 3.3 V); RAIN <= 50 k at 55.5 cycles, larger sample times allowed (table 4-42).
Pin input leakage +-1 uA (v0.7 figure, not confirmed) [ASSUMP - digital stream to confirm].
Round 2: ADC2 at ADCCLK 12 MHz, TS 13.5 cycles on the sense channels, timer-triggered 20 kHz scan with a dummy conversion
before V3A_MON (p09); the sampling-charge term of that scan order is now in the budget. CM-window removal time and
H fall come from p04/p05 (R647 100 k / C617 1 uF); switch tOFF is the TLP3545A design value.
"""
import numpy as np
from pcommon import *
import json as _json, os as _os
X_CM_SIL = _json.load(open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'p04_cm_monitor_result.json')))['x_cm_sil']
# silence coverage of the CM window from p04 (round 2 with the analog round-2 I/V values: 0.98 V; round 1: 1.07 V)
from p04_cm_monitor import T_CM_FIX              # CM-window removal time for a large deviation (3 tau + H fall + tOFF)
import p09_adc_sampling as p09
from p03_detector import e96, ladder, corners_of, step_time, thresholds, T_EXTRA, R1_CHOSEN, C1_CHOSEN, VTH_TARGET
import p03_detector as d3

# ---------------- network values -----------------------------------------------------------
R_S, R_U, R_D = 6.8e3, 5.1e3, 16.9e3          # 0.1 % 25 ppm (Yageo RT0402BRD07)
C_N = 4.7e-6                                      # Samsung CL21A475KAQNNNE, 25 V X5R 0805 +-10 %
C_LO, C_HI = 0.85, 1.10                           # tolerance + temperature [BRIEF 7.2: -15/+10 %]
C_BIAS = 0.85                                     # DC bias (node 0.8-2.4 V) + low AC level [ASSUMP, conservative for 25 V 0805]
R_TH = 1 / (1 / R_S + 1 / R_U + 1 / R_D)
G = R_TH / R_S; A = R_TH / R_U
LSB = V3V3_MIN / 4096                              # worst (VDDA = 3V3M min) - absolute LSB size ~0.79 mV
I_LKG = 1e-6
TCR, DT_SESSION = 25e-6, 25.0                      # resistor TCR, temperature change since factory calibration
F_SAMPLE = 10e3                                    # per channel (ADC2 5-channel scan, 239.5 cycles)
EPS_G = 0.020 + 0.002 + 0.003                      # reading gain: VDDA (3V3M +-2 %), resistor ratio, ADC gain [DS/ASSUMP]
_k = p09.CADC * 20e3 * p09.R_PIN / p09.G            # sampling-charge DC error at the leg per V of CADC start difference (p09, 20 kHz)
_E_CH = _k * 3.366                                  # guaranteed bound per channel: CADC may start anywhere in 0..VDDA (p09)
SAMP_LEG, SAMP_PAIR = 2 * _E_CH, 2 * _E_CH          # leg reading (leg + reference) / pair difference (two legs, reference cancels)


def errors():
    tau_min = R_TH * 0.999 * C_N * C_LO * C_BIAS
    e = {}
    e['pin leakage (2 pins x 1 uA x (R_TH + 330 ohm DZ-1) / g)'] = 2 * I_LKG * (R_TH + p09.R_SER) / G
    e['ADC INL difference (2 x EL 4 LSB) / g'] = 8 * LSB * 1.0 / G * (V3V3_MAX / V3V3_MIN)
    e['quantisation (2 channels x 0.5 LSB) / g'] = 1 * LSB / G
    e['bias drift, 2 networks x 2 x TCR x dT x a*3V3A / g'] = 2 * 2 * TCR * DT_SESSION * A * V3V3_MAX / G
    e['factory calibration (DMM 0.5 mV + ADC noise)'] = 1.0e-3
    alias = A_FS / (2 * np.pi * F_SAMPLE * tau_min)
    e['aliasing of content at k x 10 kHz (network attenuation)'] = alias
    e['sampling charge, 20 kHz, CADC start 0..VDDA (leg + reference, p09)'] = SAMP_LEG
    e_leg = sum(e.values())
    # pair difference: two leg channels (reference cancels), aliasing of two channels
    ep = dict(e)
    e_pair = e_leg - SAMP_LEG + SAMP_PAIR + alias + 1.0e-3   # second leg's alias and calibration terms; leakage/INL/drift already 2-channel
    return e, e_leg, e_pair, tau_min


def cic2_step(W, tau, t):
    """Response at time t of CIC^2 (two boxcars of length W) to the network step 1-exp(-t/tau)."""
    dt = 1 / F_SAMPLE
    n = int(t / dt) + 1
    x = 1 - np.exp(-np.arange(n) * dt / tau)
    k = int(W / dt)
    c1 = np.convolve(x, np.ones(k) / k)[:n]
    c2 = np.convolve(c1, np.ones(k) / k)[:n]
    return c2


def trip_time(W, tau, frac):
    dt = 1 / F_SAMPLE
    y = cic2_step(W, tau, 2 * W + 20 * tau)
    i = np.argmax(y >= frac)
    return i * dt if y[i] >= frac else np.inf


_CACHE_F = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'p06_content_cache.json')


def content_peak(W, amp, fmin=20.0, fmax=200.0):
    """Worst |CIC^2(network(content))| for a sine of amplitude amp at f >= fmin, any phase, onset included (cached)."""
    tau = R_TH * 0.999 * C_N * C_LO * C_BIAS     # fastest network passes the most content
    key = f'{W:.6f}|{amp:.6f}|{tau:.9f}|{F_SAMPLE:.1f}|{fmin}|{fmax}'
    cache = _json.load(open(_CACHE_F)) if _os.path.exists(_CACHE_F) else {}
    if key in cache:
        return cache[key]
    v = _content_peak(W, amp, fmin, fmax)
    cache[key] = v
    _json.dump(cache, open(_CACHE_F, 'w'), indent=1)
    return v


def _content_peak(W, amp, fmin=20.0, fmax=200.0):
    dt = 1 / F_SAMPLE; k = int(W / dt)
    tau = R_TH * 0.999 * C_N * C_LO * C_BIAS     # fastest network passes the most content
    worst = 0.0
    for f in np.concatenate([np.linspace(fmin, 3 * fmin, 25), np.geomspace(3 * fmin, fmax, 10)]):
        t = np.arange(int((3 * W + 5 / f) / dt)) * dt
        for ph in np.linspace(0, np.pi, 12, endpoint=False):
            u = amp * np.sin(2 * np.pi * f * t + ph)
            # network (1-pole) exact discretisation
            hk = np.exp(-np.arange(int(12 * tau / dt)) * dt / tau); hk /= hk.sum()
            y = np.convolve(u, hk)[:len(u)]
            c1 = np.convolve(y, np.ones(k) / k)[:len(u)]
            c2 = np.convolve(c1, np.ones(k) / k)[:len(u)]
            worst = max(worst, np.max(np.abs(c2)))
    return worst


def main():
    out = [__doc__]
    out.append(f'Network: R_S {R_S/1e3:.2f} k, R_U {R_U/1e3:.2f} k, R_D {R_D/1e3:.1f} k (0.1 %, 25 ppm), C_N {C_N*1e6:.1f} uF '
               f'(x {C_LO:.2f}...{C_HI:.2f} tolerance/temperature, x {C_BIAS:.2f} DC bias/AC level on the low side): '
               f'R_TH = {R_TH/1e3:.3f} k, g = {G:.4f}, a = {A:.4f}')
    for v3a in (V3V3_MIN, V3V3_MAX):
        lo = A * v3a - G * VNEG_MAX; hi = A * v3a + G * VPOS_MAX
        out.append(f'  3V3A {v3a:.3f} V: node {lo:.3f} ... {hi:.3f} V for legs -{VNEG_MAX}...+{VPOS_MAX} V '
                   f'(ADC range 0 ... VDDA >= {V3V3_MIN} V; margin {lo:.3f} / {V3V3_MIN - hi:.3f} V; no clipping, no pin injection)')
    ib = V3V3_MAX / (R_U + R_S * R_D / (R_S + R_D))
    out.append(f'  3V3A load: 5 networks x <= {ib*1e3:.3f} mA = {5*ib*1e3:.2f} mA (was 0.87 mA); leg load <= '
               f'{(VPOS_MAX + A*V3V3_MAX)/(R_S + R_U*R_D/(R_U+R_D))*1e3:.2f} mA (driven OPA1622 output, negligible)')
    out.append(f'  ADC source impedance {R_TH/1e3:.2f} k (< 10 k: EL spec condition; <= 25.2 k at 28.5 cycles, table 4-42); '
               f'C_N {C_N*1e6:.1f} uF >> 5 pF sample capacitor (charge-share error < 0.01 LSB)')
    e, e_leg, e_pair, tau_min = errors()
    tau_max = R_TH * 1.001 * C_N * C_HI
    out.append(f'  network tau {tau_min*1e3:.2f} ... {tau_max*1e3:.2f} ms; 20 kHz content attenuated by {20*np.log10(2*np.pi*20e3*tau_min):.0f} dB')
    # power-up: leg and reference networks charge from 3V3A with different tau; their difference must decay
    # below 1 mV referred to the leg before readings are valid
    t_ = np.arange(0, 0.5, 1e-4)
    d_ = A * V3V3_MAX * np.abs(np.exp(-t_ / tau_min) - np.exp(-t_ / tau_max)) / G
    t_settle = t_[np.nonzero(d_ > 1e-3)[0][-1] + 1]
    out.append(f'  power-up: leg-vs-reference settling (tau {tau_min*1e3:.1f} vs {tau_max*1e3:.1f} ms) below 1 mV at the leg '
               f'{t_settle*1e3:.0f} ms after 3V3A is up -> readings valid only after V3A_MON has been in its window for >= 150 ms')
    out.append('\nGuaranteed error budget per leg reading (worst-case linear sum):')
    for k, v in e.items():
        out.append(f'   {k:58s} {v*1e3:6.2f} mV')
    out.append(f'   {"=> e_leg (absolute)":58s} {e_leg*1e3:6.2f} mV;  pair difference e_pair {e_pair*1e3:.2f} mV; '
               f'plus gain error {EPS_G*100:.1f} % of the reading')
    rss = np.sqrt(sum(v * v for v in e.values()))
    out.append(f'   (RSS {rss*1e3:.1f} mV - information only; tiers use the linear sum)')

    # ---------------- tiers --------------------------------------------------------------
    TIERS = [  # name, W (s), measured threshold leg/pair (V)
        ('T1', 0.100, 0.90, 0.90),
        ('T2', 0.300, 0.24, 0.23),
        ('T3', 1.200, 0.110, 0.120),   # R3 final (DZ-1): pair 0.118 -> 0.120 V keeps the pair no-trip level >= 20 mV + 2 mV
    ]
    out.append('\nFirmware tiers on each leg reading and each balanced pair difference (L+ - L-, R+ - R-); estimator = '
               'CIC^2 (two cascaded boxcars of W) of the 10 kHz readings, evaluated every 1 ms, initialised with the '
               'first valid reading at arming; action RELAY_EN low (switch open <= 1.01 ms).')
    out.append('  tier   W      Th leg/pair   guaranteed trip (leg / pair)   deadline   no-trip below (leg/pair)   '
               'content >= 20 Hz FS: leg / pair')
    tier_res = []
    for name, W, thl, thp in TIERS:
        tt = trip_time(W, tau_max, 0.99)
        dead = tt + 1e-3 + AQV_TOFF_DESIGN + 0.1e-3
        vgl = (thl + e_leg) / ((1 - EPS_G) * 0.99)
        vgp = (thp + e_pair) / ((1 - EPS_G) * 0.99)
        cl = content_peak(W, A_FS); cp = content_peak(W, 2 * A_FS)
        # no false trip: offset + error + content must stay below Th/(1+eps)
        ntl = thl / (1 + EPS_G) - e_leg - cl
        ntp = thp / (1 + EPS_G) - e_pair - cp
        tier_res.append((name, W, vgl, vgp, dead, ntl, ntp))
        out.append(f'  {name}  {W*1e3:5.0f} ms  {thl:5.3f}/{thp:5.3f} V      {vgl:5.3f} V / {vgp:5.3f} V          '
                   f'{dead*1e3:6.0f} ms      {ntl*1e3:6.1f} / {ntp*1e3:6.1f} mV            {cl*1e3:6.1f} / {cp*1e3:6.1f} mV')
    out.append('  "no-trip below": largest true DC (offset) that can never trip the tier after all errors and '
               'worst content; must exceed the offset spec 10 mV (leg) / 20 mV (pair).')
    ok_off = all(r[5] > 0.010 and r[6] > 0.020 for r in tier_res)
    out.append(f'  -> offset-spec margin {"OK" if ok_off else "VIOLATED"}; owner rule ">= 0.2 V within 3 s": T3 guarantees '
               f'{tier_res[2][2]:.3f} V (leg) / {tier_res[2][3]:.3f} V (pair) within {tier_res[2][4]:.2f} s')

    # ---------------- combined envelope ---------------------------------------------------
    rt = d3.thresholds(e96(10e3 * (VPOS_NOM / VTH_TARGET - 1)), 10e3, e96(10e3 * (VNEG_NOM / VTH_TARGET - 1)), 10e3,
                       R1_CHOSEN, 100e3)
    (Af, Bf), (As, Bs) = corners_of(dict(r1=R1_CHOSEN, c1=C1_CHOSEN))

    def t_fw(v, pair):
        best = np.inf
        for name, W, vgl, vgp, dead, _, _ in tier_res:
            vg = vgp if pair else vgl
            if v >= vg:
                best = min(best, dead)
        return best

    def t_hw_leg(x):
        return step_time(As, Bs, x, rt['trip_max']) + T_EXTRA if x > rt['trip_max'] else np.inf

    X_CM = X_CM_SIL  # p04: CM window trips at silence for stuck-pin DC >= this per leg
    out.append('\nCombined envelope (hardware leg windows + CM window + firmware tiers), DC energy at the driver, '
               'worst case over V in 0.2-4.0 V:')
    cases = {
        'SE / single leg DC (leg to GND or healthy other leg)': lambda v: (v, min(t_hw_leg(v), t_fw(v, False))),
        'balanced +-x (stuck DAC pin, silence), V = 2x': lambda v: (v, min(t_hw_leg(v / 2), t_fw(v, True),
                                                                          (T_CM_FIX if v / 2 >= X_CM else np.inf))),
        'balanced opposite-sign sub-threshold legs': lambda v: (v, t_fw(v, True) if v <= 2 * rt['trip_max'] else 0.0),
    }
    grid = np.linspace(0.20, 4.0, 761)
    for cname, fn in cases.items():
        for rl in (16.0, 32.0):
            worst = (0.0, 0, 0)
            tmax_02 = 0
            for v in grid:
                vv, t = fn(v)
                # current limit of the legs caps the driver voltage
                vd = min(vv, ISC_BOUND * rl) if 'balanced' in cname else min(vv, VPOS_MAX)
                e_ = vd * vd / rl * t
                if e_ > worst[0]:
                    worst = (e_, v, t)
                tmax_02 = max(tmax_02, t)
            lim = E_LIMIT[rl]
            out.append(f'  {cname:52s} {rl:3.0f} ohm: worst {worst[0]*1e3:5.1f} mJ at {worst[1]:.2f} V '
                       f'(removal {worst[2]*1e3:.0f} ms), limit {lim*1e3:.0f} mJ, margin {100*(1-worst[0]/lim):.0f} %;'
                       f' slowest removal {tmax_02:.2f} s')
    out.append('  (0.2 V case: removal <= %.2f s everywhere -> owner rule "any DC >= 0.2 V across a driver within 3 s" met)'
               % max(r[4] for r in tier_res))
    out.append('  Residual never removed by firmware: < %.3f V (leg) / %.3f V (pair) -> <= %.2f mW into 16 ohm (owner-accepted < 0.2 V)'
               % (tier_res[2][2], tier_res[2][3], tier_res[2][3] ** 2 / 16 * 1e3))

    # ---------------- boundary tests -----------------------------------------------------
    out.append('\nBoundary tests (bring-up, test mode with the stream guard bypassed; inject DC on LEG_xx with the '
               'amplifier link removed, or digital DC for pairs):')
    for name, W, vgl, vgp, dead, ntl, ntp in tier_res:
        out.append(f'  {name}: leg DC {vgl*1.02:.3f} V and pair {vgp*1.02:.3f} V (both signs) -> RELAY_EN low within '
                   f'{dead*1e3:.0f} ms; leg DC {max(ntl,0)*0.9*1e3:.0f} mV / pair {max(ntp,0)*0.9*1e3:.0f} mV for 10 s -> no trip; '
                   'arm the tier with the fault already present -> trip on the first evaluation')
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))


if __name__ == '__main__':
    main()
