#!/usr/bin/env python3
"""p01 - Output switch technology: electromechanical DPDT signal relays vs PhotoMOS (MOSFET) relays.
Round 2: the photorelay is the Toshiba TLP3545A(TP1,F) (D-1); RON/COFF/tOFF from pcommon (Toshiba datasheet 2023-05).

p02 shows that four legs must be switched (L+/R+ only fails every simultaneous-use case), i.e.
2 DPDT relays or 4 PhotoMOS. This script compares the coil / LED supply current at the USB corners,
the guaranteed operate margin at the low-VBUS / hot corner, the release time and the output-impedance
contribution.

Coil model: operate voltage scales with coil resistance (copper +0.393 %/K; the relay datasheets state
the pick-up voltage at 23 C and that it varies with temperature) [physics/ASSUMP]; coil current at the
high corner uses R -10 % and 0 C. Coil self-heating R_th = 250 K/W [ASSUMP; Hongfa HFD3 states 50 K max rise
at 140 mW, i.e. up to 357 K/W]. Coil voltage available: 5V_SYS min 4.30 V - 10 mV driver drop.
"""
import numpy as np
from pcommon import *
import p05_switch_drive as p05

ALPHA = 0.00393
RTH_COIL = 250.0
V_COIL_MIN = V5SYS_MIN - 0.01

RELAYS = [  # name, rated V, R23 (ohm, +-10 %), operate V at 23 C (max), release (with diode, max), contact R max, source
    ('Omron G6K-2F-Y 5 VDC', 5.0, 237, 4.00, None, 0.100, 'Omron G6K datasheet (en-g6k.pdf): 21.1 mA, 80 % max, 3 ms max'),
    ('Omron G6K-2F-Y 4.5 VDC', 4.5, 194, 3.60, None, 0.100, 'Omron G6K datasheet: 23.2 mA, 80 % max, 3 ms max'),
    ('TE IM13 (sensitive 5 V)', 5.0, 234, 4.00, 5e-3, 0.050, 'TE IM datasheet: 100 mW, release 3 ms (no diode) / 5 ms (diode)'),
    ('TE IM12 (sensitive 4.5 V)', 4.5, 194, 3.60, 5e-3, 0.050, 'TE IM datasheet'),
    ('TE IM03 (standard 5 V)', 5.0, 178, 3.75, 5e-3, 0.050, 'TE IM datasheet: 140 mW'),
    ('TE IM02 (standard 4.5 V)', 4.5, 145, 3.38, 5e-3, 0.050, 'TE IM datasheet: 140 mW, DigiKey 27 k in stock'),
    ('TE IM22 (ultra-sensitive 4.5 V)', 4.5, 405, 4.50, 5e-3, 0.050, 'TE IM datasheet: 50 mW, operate = 100 % of rated'),
    ('Panasonic TQ2SA-5V', 5.0, 178, 3.75, None, 0.075, 'Panasonic TQ-SMD: 140 mW, 75 %'),
]


def main():
    out = [__doc__]
    out.append(f'{"relay":34s} {"I(5.5V,0C)":>11s} {"2 relays":>9s} {"Vop@60C":>8s} {"Tcoil,max for operate at 4.29 V":>33s}  hot re-operate')
    for name, vr, r23, vop, trel, rc, src in RELAYS:
        i_hi = V5SYS_MAX / (r23 * 0.9 * (1 + ALPHA * (0 - 23)))
        vop60 = vop * (1 + ALPHA * (T_LOCAL_MAX - 23))
        tmax = 23 + (V_COIL_MIN / vop - 1) / ALPHA
        p_hold = V_COIL_MIN ** 2 / (r23 * 1.1 * (1 + ALPHA * (T_LOCAL_MAX - 23)))
        t_hot = T_LOCAL_MAX + p_hold * RTH_COIL
        ok_cold = vop60 <= V_COIL_MIN
        ok_hot = vop * (1 + ALPHA * (t_hot - 23)) <= V_COIL_MIN
        out.append(f'{name:34s} {i_hi*1e3:8.1f} mA {2*i_hi*1e3:6.1f} mA {vop60:7.2f} V {tmax:26.0f} C'
                   f'         {"cold OK" if ok_cold else "COLD FAIL"} / {"hot OK" if ok_hot else "hot FAIL"} ({t_hot:.0f} C)')
    out.append('  (cold = first operate at 60 C local ambient; hot = re-operate right after long energisation at the low corner)')
    out.append('')
    # PhotoMOS drive from p05
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        res = p05.main()
    out.append(f'Photorelay TLP3545A(TP1,F) x 4 (D-1), LEDs 2 per string, low-dropout op-amp current sink (p05): LED supply '
               f'{2*res["i_min"]*1e3:.1f}-{2*res["i_max"]*1e3:.1f} mA, total USB load <= {res["i_usb"]*1e3:.1f} mA at every '
               f'VBUS (IF >= 5.0 mA at 5V_SYS 4.30 V with VF at its 0 C maximum; round 1: AQV251GAX, 15.3 mA)')
    # release / turn-off
    out.append('\nRelease / turn-off (guaranteed):')
    out.append('  TE IM: 3 ms max without diode, 5 ms max with a parallel diode (datasheet); bounce <= 5 ms on make')
    out.append('  Omron G6K: release 3 ms max (datasheet value, suppression not stated -> only valid without a diode)')
    out.append(f'  Photorelay TLP3545A: tOFF <= 0.5 ms (25 C, IF 5 mA and 10 mA) [DS]; design value {SW_TOFF_DESIGN*1e3:.1f} ms over '
               'temperature [ASSUMP]; no bounce, no coil flyback -> no suppression parts (AQV251GA second source: same 0.5 ms [DS])')
    # output impedance
    ron_hot = SW_RON_MAX_25 * SW_RON_TC
    ron_aqv = AQV_RON_MAX_25 * SW_RON_TC
    out.append('\nOutput impedance added (at 60 C device temperature):')
    out.append(f'  Photorelay TLP3545A: RON <= {SW_RON_MAX_25:.3f} ohm (25 C, IF 5 mA; IF >= 5.0 mA guaranteed by p05) x {SW_RON_TC} '
               f'[ASSUMP, RON-Ta curve typical only] = {ron_hot:.3f} ohm per switch -> 3.5 mm path {ron_hot:.3f} ohm, 4.4 mm balanced '
               f'path {2*ron_hot:.3f} ohm (two switches in series); L/R mismatch <= {ron_hot:.3f} ohm')
    out.append(f'  (AQV251GA second source: {ron_aqv:.3f} / {2*ron_aqv:.3f} ohm; round-1 figures 0.108 / 0.216 ohm superseded)')
    out.append('  TE IM relay: <= 0.050 ohm initial per contact (0.100 ohm balanced); Omron G6K <= 0.100 ohm (0.200 balanced)')
    out.append('  Budget 0.5 ohm including the jack contacts: TLP3545A leaves >= %.3f ohm (balanced) / %.3f ohm (3.5 mm) for the '
               'OPA1622, traces and jack (AQV251GA: %.3f ohm balanced).' % (0.5 - 2 * ron_hot, 0.5 - ron_hot, 0.5 - 2 * ron_aqv))
    # coupling through the open switch: COFF 640 pF typ at 0 V [DS-typ], x1.5 allowance for the missing maximum [ASSUMP]
    c = SW_COUT_BOUND
    out.append(f'  open-switch capacitance: COFF {SW_COUT_TYP*1e12:.0f} pF typ at 0 V, 1 MHz [DS-typ, falls with VOFF, Fig. 16.1.11]; '
               f'bound used {c*1e12:.0f} pF [ASSUMP x1.5]')
    for rl in (32.0, 300.0):
        for dv, tr in ((0.035, 1e-6), (3.5, 1e-6), (3.5, 1e-3)):
            # band-limited peak of the current C dV/dt through R_load: v = R*C*dV/tr for tr >> R*C
            v = rl * c * dv / tr
            v_bl = min(v, rl * c * dv * 2 * np.pi * 20e3 / np.pi)   # 20 kHz band limit of a fast edge (area x bandwidth)
            out.append(f'  open-switch coupling (Coff <= {c*1e12:.0f} pF): leg step {dv:5.3f} V in {tr*1e6:6.0f} us into {rl:4.0f} ohm '
                       f'-> <= {v_bl*1e3:6.3f} mV band-limited')
    # round 2: the largest controlled leg step while the switch is open (analog R2.15: reset-state step at AVCC_EN,
    # <= 0.343 V in >= 21 us; power-down uses the ESS ramp to ground over 0.819 ms) -> power-on pop through COFF
    dv_r, tr_r = 0.343, 21e-6
    tau_bl = 1 / (2 * np.pi * 20e3)                     # 20 kHz band limit (1st order)
    for rl in (32.0, 300.0):
        for cc, lbl in ((SW_COUT_TYP, 'typ'), (SW_COUT_BOUND, 'bound')):
            v_raw = rl * cc * dv_r / tr_r               # rectangular current pulse C dV/dt into R (R C << tr)
            v_1p = v_raw * (1 - np.exp(-tr_r / tau_bl))
            v_bw = rl * cc * dv_r * 2 * 20e3            # brick-wall 20 kHz: area x 2 x 20 kHz
            out.append(f'  reset-state leg step {dv_r} V in {tr_r*1e6:.0f} us (analog R2.15) into {rl:4.0f} ohm, COFF {cc*1e12:.0f} pF '
                       f'({lbl}): {v_raw*1e3:.2f} mV raw, <= {max(v_1p, v_bw)*1e3:.2f} mV band-limited (pop target 5 mV)')
    v_esd = 300.0 * SW_COUT_BOUND * 0.343 / 0.819e-3
    out.append(f'  power-down ESS ramp to ground (0.343 V over 0.819 ms): <= {v_esd*1e3:.3f} mV at 300 ohm -> negligible')

    # distortion of the conducting switch: first-order bounds (not datasheet values)
    VOV_MIN = 3.0                          # V, gate overdrive of the output MOSFETs [ASSUMP, not in the datasheet]
    alpha_r = (SW_RON_TC - 1) / (60 - 25)   # 1/K, Ron tempco implied by the x1.35 (25 -> 60 C) assumption
    RTH_SW = 250.0                         # K/W, DC junction-to-ambient bound, used as |Zth(2f)| bound [ASSUMP]
    a_fs = 2.228                           # V pk per leg, calibrated full scale incl. trim (p03)
    out.append('\nDistortion of the conducting switch, first-order bounds at calibrated full scale '
               f'(Ron {ron_hot:.3f} ohm per switch; gate overdrive >= {VOV_MIN:.0f} V [ASSUMP]; Ron tempco '
               f'{alpha_r*100:.1f} %/K; |Zth(2f)| <= Rth {RTH_SW:.0f} K/W [ASSUMP, conservative: the die Zth at 2f is far lower]):')
    out.append('  channel: A connection = two MOSFETs in anti-series -> even orders cancel; V = I*R0*(1 + (V_sw/Vov)^2/8) '
               '-> HD3 = V_sw^3/(32 Vov^2)')
    out.append('  self-heating: P(2f) = I^2 R/2 -> dT = P*Rth -> R modulated at 2f -> HD3 = V_sw * alpha * dT / 2')
    worst300 = -400.0
    for label, rl, nsw, vpk in (('3.5 mm SE, 32 ohm', 32.0, 1, a_fs), ('4.4 mm balanced, 32 ohm (not rated)', 32.0, 2, 2 * a_fs),
                                ('4.4 mm balanced, 60 ohm', 60.0, 2, 2 * a_fs),
                                ('3.5 mm SE, 300 ohm', 300.0, 1, a_fs), ('4.4 mm balanced, 300 ohm', 300.0, 2, 2 * a_fs)):
        i = vpk / rl
        vsw = i * ron_hot
        hd3_ch = nsw * vsw ** 3 / (32 * VOV_MIN ** 2)
        d_t = i * i * ron_hot / 2 * RTH_SW
        hd3_th = nsw * vsw * alpha_r * d_t / 2
        hd3_db = 20 * np.log10((hd3_ch + hd3_th) / vpk)
        if rl == 300.0:
            worst300 = max(worst300, hd3_db)
        out.append(f'  {label:36s} I {i*1e3:5.1f} mA pk, V_sw {vsw*1e3:5.2f} mV/switch: channel HD3 '
                   f'{20*np.log10(hd3_ch/vpk):6.0f} dB, self-heating HD3 <= {20*np.log10(hd3_th/vpk):6.0f} dB (dT <= {d_t*1e3:.1f} mK)')
    out.append(f'  -> THD+N requirement point (300 ohm, 1 kHz): switch contribution <= {worst300:.0f} dB (requirement -105 dB); '
               'the bound is weakest at 32 ohm balanced full scale near 20 Hz (not a rated condition) -> bring-up check '
               'with the bypass (analog stream)')
    out.append('\nDecision (D-1): 4 x Toshiba TLP3545A(TP1,F) (K601-K604), one per leg; Panasonic AQV251GA(X) only as a '
               'conditional second source (reflow peak <= 250 C). Two DPDT relays would draw 69-93 mA at '
               '5.5 V/0 C with a coil that still operates at 4.3 V/60 C (4.5 V coils); 5 V coils fail the hot/low corner. '
               f'The photorelay drive needs <= {res["i_usb"]*1e3:.1f} mA, opens in <= 0.5 ms (vs 3-5 ms), has no bounce, '
               'no flyback and no dry-circuit issue.')
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))


if __name__ == '__main__':
    main()
