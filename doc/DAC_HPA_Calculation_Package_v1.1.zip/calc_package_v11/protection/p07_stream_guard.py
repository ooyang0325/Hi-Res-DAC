#!/usr/bin/env python3
"""p07 - Stream DC guard (firmware, per channel, on the PCM samples before the CPLD link).

Rule (replaces "no zero crossing for 25 ms and |mean| >= 0.25 FS", R8-A3):
  (a) D = CIC^2 of the samples: two cascaded running means of N = fs/20 samples each (exactly 50 ms at every
      rate: 2205 ... 19200 samples, integer for all eight rates);  |D| >= 0.30 FS  -> trigger.
  (b) flat path: all samples of the last 26 ms within a range <= 1e-3 FS and |mean| >= 0.02 FS -> trigger
      (a full-scale square or clipped wave with fundamental >= 20 Hz changes sign within 25 ms, so it can
      never be flat for 26 ms; a stuck/repeated sample or a DC file is caught 13 ms earlier than by (a)).
  Trigger -> zero the channel pair (1 ms ramp) and log; release after |D| < 0.05 FS for 1 s.  No latch, no RELAY_EN action (the hardware and
  the firmware tiers remain the protection; the guard only keeps program DC off the headphones).
Checks: (1) no trigger for any full-scale sine >= 20 Hz (clock -100 ppm), any start phase, onset included,
and none for a full-scale 20 Hz square wave; (2) detection time for digital DC; (3) energy with the switch.
The link FIFO delays the DC and the zeroing equally, so the exposure at the jack = detection time + DAC
filter delay (<= 1 ms) [ASSUMP: ES9018K2M FIR group delay < 45 samples at 44.1 kHz].
"""
import numpy as np
from pcommon import *

W = 0.050
TH = 0.30
FS_TEST = 48000.0


def cic2(x, n):
    c1 = np.convolve(x, np.ones(n) / n)[:len(x)]
    return np.convolve(c1, np.ones(n) / n)[:len(x)]


def worst_sine(fmin=20.0 * (1 - 100e-6), fmax=2000.0):
    fs = FS_TEST; n = int(round(fs * W))
    worst = (0.0, 0.0)
    freqs = np.concatenate([np.linspace(fmin, 60.0, 81), np.geomspace(60.0, fmax, 30)])
    for f in freqs:
        t = np.arange(int(fs * (3 * W + 3 / f))) / fs
        for ph in np.linspace(0, np.pi, 24, endpoint=False):
            d = np.max(np.abs(cic2(np.sin(2 * np.pi * f * t + ph), n)))
            if d > worst[0]:
                worst = (d, f)
    return worst


def main():
    out = [__doc__]
    ws, wf = worst_sine()
    out.append(f'Worst |D| for a full-scale sine >= 20 Hz (any phase, onset): {ws:.3f} FS at {wf:.2f} Hz  '
               f'-> threshold {TH} FS, margin {100*(1-ws/TH):.0f} %')
    fs = FS_TEST; n = int(round(fs * W)); t = np.arange(int(fs * 0.4)) / fs
    sq = np.max(np.abs(cic2(np.sign(np.sin(2 * np.pi * 20.0 * (1 - 100e-6) * t + 1e-9)), n)))
    out.append(f'Full-scale 20 Hz square wave (onset): |D| max {sq:.3f} FS -> {"no trigger" if sq < TH else "TRIGGER"}')
    # half-scale sines etc. are strictly smaller (linear)
    out.append('\nDetection time for digital DC (step at t = 0) and DC energy at the jack with the output switch closed:')
    out.append('  (a) DC with content (not flat) -> CIC^2 path; worst leg swing at the MAXIMUM rail:')
    out.append('  DC (FS)  detect   exposure |  32 ohm bal   16 ohm bal   32 ohm SE   16 ohm SE   (mJ)')
    for dc in (1.0, 0.8, 0.6, 0.5, 0.4, 0.35, 0.31):
        d = cic2(np.full(int(fs * 0.3), dc), n)
        i = np.argmax(np.abs(d) >= TH)
        td = i / fs if abs(d[i]) >= TH else np.inf
        tx = td + 1e-3
        leg = dc * 2.19
        e = []
        for rl, bal in ((32.0, True), (16.0, True), (32.0, False), (16.0, False)):
            xl = leg_dc_max(leg, rl / 2 if bal else rl, VPOS_MAX)
            v = 2 * xl if bal else xl
            e.append(v * v / rl * tx)
        out.append(f'  {dc:5.2f}   {td*1e3:6.1f} ms {tx*1e3:6.1f} ms | ' + '   '.join(f'{x*1e3:9.1f}' for x in e))
    tx = 26e-3 + 1e-3
    e = []
    for rl, bal in ((32.0, True), (16.0, True), (32.0, False), (16.0, False)):
        xl = leg_dc_max(2.19, rl / 2 if bal else rl, VPOS_MAX); v = 2 * xl if bal else xl
        e.append(v * v / rl * tx)
    out.append(f'  (b) pure digital DC (flat), any level >= 0.02 FS: detect 26 ms, exposure {tx*1e3:.0f} ms | '
               + '   '.join(f'{x*1e3:9.1f}' for x in e) + '  (at 1 FS)')
    out.append('  Below 0.30 FS the guard does not act: 0.30 FS digital DC = 0.66 V per leg -> the hardware leg windows '
               '(0.28-0.32 V) remove it in <= 0.27 s and firmware T2 in <= 0.57 s (p03, p06).')
    out.append('\nPhysical limit: a full-scale 20 Hz square wave is identical to full-scale DC for 25 ms; no rule can '
               'remove full-scale DC faster than ~30 ms without muting such content. Full-scale digital DC into a '
               '32 ohm balanced load stays at ~15 mJ (flat DC) to ~23 mJ (DC with content), above or at the 15 mJ the owner set for hardware failures; '
               'the hardware leg windows alone would give the same order (p03: 41.9 ms).')
    out.append('\nFirmware details: runs on decoded samples before the SPI link (all rates, 16/24/32-bit normalised to FS); '
               'running sums in 64-bit integers (exact, no drift); N = fs/20; evaluated every sample block (<= 1 ms); '
               'windows start empty at stream start (worst case: a DC present from the first sample is caught after '
               f'{W*np.sqrt(2*TH)*1e3:.0f} ms at 1 FS); unit tests: FS sines 19.998-2000 Hz x 24 phases never trigger; '
               'DC 0.31-1.0 FS triggers within the table times; 20 Hz square does not trigger.')
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))


if __name__ == '__main__':
    main()
