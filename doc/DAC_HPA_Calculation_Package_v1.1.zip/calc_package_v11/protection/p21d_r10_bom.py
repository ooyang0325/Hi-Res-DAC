#!/usr/bin/env python3
"""p21d_r10_bom - R10 F-1 (e): BOM rows and netlist rows of the history-robust protection (protection stream files).
RELEASE generator, self-contained and idempotent: it reads the CURRENT protection/bom_rows.csv and netlist.csv (no backup
inputs), removes the retired leg-window parts and any earlier copy of the R10 parts, and writes the R10 rows; formats kept.
Retired (leg windows, replaced by the LPW stage): U601, U602, R601-R604, C601-C604, R607-R610, R649-R652, C612-C615.
New: U611/U612 TLV1704AIPWR (OR stages, existing line), U613-U620 TLV3402IDGKR (LPW stages), R926-R951, C639-C666, Q627
(designators continue after the existing ones).  R951 (10 k, successor hand-over 26 Sep): in series with the Q627 collector, so the
OR self-test gives a DEFINED positive test threshold V_OR+ = 0.086-0.141 V instead of Q627's VCE(sat) (~15-50 mV), which an idle
leg's offset plus comparator errors (<= 20 mV) could exceed (spurious positive OR firing in test mode = false self-test pass/fail).
"""
import csv, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
BOMF, NETF = os.path.join(HERE, 'bom_rows.csv'), os.path.join(HERE, 'netlist.csv')
RETIRED = ({'U601', 'U602'} | {f'R{i}' for i in range(601, 605)} | {f'C{i}' for i in range(601, 605)} |
           {f'R{i}' for i in range(607, 611)} | {f'R{i}' for i in range(649, 653)} | {f'C{i}' for i in range(612, 616)})
NEW = ({f'U{i}' for i in range(611, 623)} | {f'R{i}' for i in range(926, 952)} | {f'C{i}' for i in range(639, 667)} | {'Q627'})
# (U621/U622 were used by an earlier draft of this generator; they are cleared and stay unused)


def expand(refs):
    return [t.strip() for t in refs.split(',') if t.strip()]


# ---------------------------------------------------------------- BOM
rows = list(csv.DictReader(open(BOMF, encoding='utf-8-sig')))
fields = list(rows[0].keys())
newrows = []
for r in rows:
    refs = [x for x in expand(r['refs']) if x not in RETIRED and x not in NEW]
    if not refs:
        continue                                        # line only held retired parts (R601-R604, R607, R608, C601-C604)
    r = dict(r)
    r['refs'] = ', '.join(refs); r['qty'] = str(len(refs))
    newrows.append(r)
rows = newrows


def line_of(ref):
    for r in rows:
        if ref in expand(r['refs']):
            return r
    raise KeyError(ref)


def add_to(ref_in_line, add):
    r = line_of(ref_in_line)
    refs = expand(r['refs']) + [a for a in add if a not in expand(r['refs'])]
    r['refs'] = ', '.join(refs); r['qty'] = str(len(refs))


r = line_of('U603')
r['desc'] = ('Comparator, quad, micropower, rail-to-rail input, open-collector output, on VPOS/VNEG: U603 I/V common-mode windows; '
             'U606 (R3 X-6) 1V3-good, MCLK-alive, 3V3A-good repeater, E-2 H-OK; U609/U610 (R9 E-3) pair-difference detectors L/R '
             '(2 level + 2 timer channels each; R10: their timers and timer comparators also serve the OR and LPW stages); '
             'U611/U612 (R10 F-1) per-leg over-range (OR) stages L/R (tap > V_OR+ / tap < V_OR- per leg; outputs sink the E-3 NPN-reset bases). '
             'R10: U601/U602 retired (replaced by the LPW and OR stages)')
add_to('U603', ['U611', 'U612'])                                                                    # TLV1704AIPWR C181596
r['unit_price_usd'] = '1.5567'     # 6 per board x 5 + attrition = 31 pcs -> LCSC 30+ tier (integration/parts 26 Sep; 1.2502 was the 1,000+ tier)
add_to('R666', ['R930', 'R931', 'R932', 'R933', 'R938', 'R940'])                                     # 1.00 M 1 % 0402 C26083
add_to('R660', ['R926', 'R927', 'R928', 'R929'])                                                     # 330 k 1 % 0402 C25778
add_to('C629', ['C639', 'C640', 'C641', 'C642'])                                                     # 1 nF C0G 0402
add_to('R646', ['R939', 'R950'])                                                                    # 100 k 1 % 0402 C25741
add_to('R688', ['R935', 'R936', 'R937'])                                                            # 470 k 1 % 0402 C25790
add_to('C626', [f'C{i}' for i in range(655, 667)])                                                  # 100 nF 0402 decoupling (U611/U612 V+/V-, U613-U620)
line_of('C629')['desc'] = ('1 nF C0G: 1V3-good input filter (C629, tau 10 us with R670); R10 F-1: C639-C642 OR tap filters '
                           '(tau 0.33 ms with R926-R929 330 k)')
line_of('C626')['desc'] = ('Decoupling 100 nF: C618/C619 U603 V+/V-, C622 U604 supply; C623 U607 VCC (3V3D), C626/C627 U606 V+/V-, C628 U605 VCC '
                           '(3V3M) (R3); C630 U608 VCC (3V3D), C635-C638 U609/U610 V+/V- (R9); R10 F-1: C655-C658 U611/U612 V+/V-, '
                           'C659-C666 U613-U620 VCC-GND (VPOS-VNEG). (C612-C615 retired with U601/U602)')
line_of('R666')['desc'] = ('1.00 MOhm 1 %: MCLK pump bleed (R666), MCLK-alive threshold divider top (R668, VE: was 866 k 0.1 %); R10 F-1: '
                           'R930-R933 LPW taps from LEG_xx, R938 V_LL+ divider top (3V3A), R940 V_LL- divider top (VNEG)')
line_of('R688')['desc'] = ('470 kOhm: U605 output readback to MCU PA12 / PB9 (a mis-driven pin cannot mask the gate); R10 F-1: R935 V_OR+ '
                           'divider bottom, R936/R937 V_OR- divider (R937 returned to N6_ORTEST)')
line_of('R660')['desc'] = ('330 kOhm: CM threshold offset from VPOS into CMTH_LO (permit off when 3V3A is absent); R690 N6_TRIP pull-up to 3V3D, '
                           'R694 N6_HREF divider bottom (R9 E-2); R916-R919 E-3 NPN base pull-ups from VPOS (R9 check); R10 F-1: R926-R929 OR taps from LEG_xx')
_d = line_of('R646')['desc']
line_of('R646')['desc'] = (_d.replace('comparator input series (R649-R652), ', '').rstrip('; ') +
                           ('' if 'R939' in _d else '; R10 F-1: R939 V_LL+ divider bottom, R950 Q627 base (OR self-test)'))
add_to('Q623', ['Q627'])                                                                            # MMBT3904 row Q623-Q627
_q = line_of('Q623')                        # hand-over: onsemi source with a VCE(sat) datasheet row (parts 26 Sep; indep-check point)
_q.update(desc='NPN: Q623-Q626 E-3 timer reset switches (C = timer node, E = GND, B = level/OR/LPW outputs; R9 check E-24: no clamp diode, no R_D); '
               'Q627 OR self-test switch (collector via R951 on N6_VORP)',
          rating_tolerance='40 V, 200 mA; VCE(sat) <= 0.2 V at 10 mA / 1 mA, <= 0.3 V at 50 mA / 5 mA; ICEX, IBL <= 50 nA; hFE >= 40 at 0.1 mA [DS onsemi MMBT3904LT1/D Rev. 15]',
          mpn='onsemi MMBT3904LT1G', lcsc='C81464', jlcpcb_class='Extended',
          jlcpcb_stock_or_sourcing='C81464, Extended, LCSC 1,690,900 (24 Sep 2026), US$ 0.0167; MSL 1, Economic + Standard PCBA (parts, 26 Sep)',
          unit_price_usd='0.0167', datasheet_url='https://www.onsemi.com/pdf/datasheet/mmbt3904lt1-d.pdf',
          note='CASE 318 STYLE 6: 1 B, 2 E, 3 C (same land). The reset level at IC ~35 uA / forced beta ~3.5 extends the 10 mA / 1 mA row [ASSUMP A-46]')
# R11 (delta_r10_final Part B, 26 Sep 2026): text-only fixes of rows carried over from earlier generators; netlist and keys unchanged
line_of('C631')['desc'] = 'E-3 timer capacitor C_T: 220 nF, ±2 % required; T_P 19.50–23.37 ms incl. 1 µA leakage'
line_of('R657')['desc'] = '10.0 kOhm 0.1 %: CM threshold chain top/bottom (R657, R659); R670 1V3 series into U606 ch1 (R3)'
base = dict((k, '') for k in fields)
def mk(**kw):
    d = dict(base); d.update(block='6 Protection and control', fit='Yes', leadless='No', tht_pins_per_part='0'); d.update(kw)
    return d
rows += [
    mk(refs=', '.join(f'U{i}' for i in range(613, 621)), qty='8',
       desc='Comparator, dual, nanopower, open-drain, 2.5-16 V, on VPOS/VNEG (R10 F-1): U613-U620 low-level persistence (LPW) stages '
            'LP+, LP-, LN+, LN-, RP+, RP-, RN+, RN- (ch1 level -> own timer node, ch2 timer > 0 V -> E-3 NPN-reset base)',
       value='TLV3402', package='VSSOP-8 (DGK), 3.0 x 3.0 mm, 0.65 mm pitch',
       rating_tolerance='2.5-16 V; VIO <= 4.4 mV, IIB <= 1.5 nA, VOL <= 0.30 V at 50 uA, ICC <= 0.95 uA/ch (full range); tpd 300 us typ, no max',
       mpn='TI TLV3402IDGKR', lcsc='C140314', jlcpcb_class='Extended',
       jlcpcb_stock_or_sourcing='JLCPCB 153 (152 available) / LCSC 152 (parts, 26 Sep 07:54); need 40 + attrition -> buy now into the JLCPCB part library (about 152 in stock); MSL 1; same die/datasheet as U605 TLV3402IDR (C91242)',
       smt_pins_per_part='8', unit_price_usd='1.3642', datasheet_url='https://www.ti.com/lit/ds/symlink/tlv3402.pdf',
       note='R10 F-1: new part type (package variant of U605). Pinout 1 OUT1, 2 IN1-, 3 IN1+, 4 GND(=VNEG), 5 IN2+, 6 IN2-, 7 OUT2, 8 VCC(=VPOS) (DGK = D pin map; gate G-3 checks the TI DGK drawing). Price JLCPCB 30+ (parts).'),
    mk(refs='R934', qty='1', desc='OR stage V_OR+ divider top (3V3A)', value='360 kOhm', package='0402', rating_tolerance='1 %, 100 ppm/K, 1/16 W',
       mpn='UNI-ROYAL 0402WGF3603TCE', lcsc='C45956', jlcpcb_class='Extended',
       jlcpcb_stock_or_sourcing='JLCPCB Extended, 23,019 in stock / 21,995 available, Economic + Standard PCBA (JLCPCB part page, Jun 2026 copy; parts 26 Sep) - re-check in the JLCPCB BOM tool at order',
       smt_pins_per_part='2', unit_price_usd='0.0010', datasheet_url='', note='R10 F-1'),
    mk(refs='R951', qty='1', desc='OR self-test: series resistor in the Q627 collector (defined positive test threshold V_OR+ 0.086-0.141 V)',
       value='10 kOhm', package='0402', rating_tolerance='1 %, 100 ppm/K, 1/16 W', mpn='UNI-ROYAL 0402WGF1002TCE', lcsc='C25744', jlcpcb_class='Basic',
       jlcpcb_stock_or_sourcing='same global line as R103/R104, R201 ff., R305 (C25744, Basic)', smt_pins_per_part='2', unit_price_usd='0.0005',
       datasheet_url='', note='R10 F-1 (successor hand-over 26 Sep): no current in normal operation (Q627 off)'),
    mk(refs='R941', qty='1', desc='LPW stage V_LL- divider bottom (VNEG x 88.7/1088.7)', value='88.7 kOhm', package='0402', rating_tolerance='1 %, 100 ppm/K, 1/16 W',
       mpn='UNI-ROYAL 0402WGF8872TCE', lcsc='C25922', jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC 121,600 (parts, 26 Sep)',
       smt_pins_per_part='2', unit_price_usd='0.0006', datasheet_url='', note='R10 F-1'),
    mk(refs=', '.join(f'R{i}' for i in range(942, 950)), qty='8', desc='LPW timer charging resistors R_T2 (VPOS -> timer node)', value='910 kOhm',
       package='0402', rating_tolerance='1 %, 100 ppm/K, 1/16 W', mpn='UNI-ROYAL 0402WGF9103TCE', lcsc='C25800', jlcpcb_class='Extended',
       jlcpcb_stock_or_sourcing='31,544 available (parts, 26 Sep)', smt_pins_per_part='2', unit_price_usd='0.0035', datasheet_url='', note='R10 F-1'),
    mk(refs=', '.join(f'C{i}' for i in range(643, 647)), qty='4', desc='LPW tap filter capacitors (tau 3.3 ms with 1.00 M)', value='3.3 nF',
       package='0603', rating_tolerance='C0G, 5 %, 50 V', mpn='FH 0603CG332J500NT', lcsc='C190576', jlcpcb_class='Extended',
       jlcpcb_stock_or_sourcing='LCSC 6,740 (25 Sep); JLCPCB Extended, MSL 1, Economic + Standard PCBA (parts, 26 Sep); LCSC-stocked fallback chosen over the unlisted 0402 C0G 50 V',
       smt_pins_per_part='2', unit_price_usd='0.0243', datasheet_url='', note='R10 F-1 (0603 per parts, Z4 +10 mm2); same C0G 5 % as modelled'),
    mk(refs=', '.join(f'C{i}' for i in range(647, 655)), qty='8', desc='LPW timer capacitors C_T2 (timer node -> GND)', value='100 nF',
       package='1206', rating_tolerance='C0G/NP0, 5 %, 50 V (no DC-bias or ageing loss)',
       mpn='FH 1206CG104J500NT', lcsc='C46348', jlcpcb_class='Extended',
       jlcpcb_stock_or_sourcing='LCSC 11,730 / JLCPCB 14,418 (parts, 26 Sep); LCSC-stocked fallback chosen over the unlisted 0805 C0G 50 V (no global sourcing)',
       smt_pins_per_part='2', unit_price_usd='0.3296', datasheet_url='', note='R10 F-1: C0G needed for the T_P2 window (X7R too wide); 1206 per parts (Z4 +23 mm2)'),
]
# R11 guard: no current row may carry a ninth-round protection figure, the leg-window wording or the retired R609/R610
_R9 = re.compile(r'\b23\.23?\s*ms|\b19\.5\s*[-–]\s*23\.2\b|\b5\.8\s*%|\b8\.1\s*%|\b27\.5\b|\b14\.43\b|\b13\.9\s*mJ|'
                 r'\b20\.0\s*[-–]\s*22\.2\b|\b22\.1\s*ms|leg[- ]?window|\bR6(?:09|10)\b', re.I)
_bad = [(r['refs'], k, _R9.search(v).group(0)) for r in rows for k, v in r.items() if isinstance(v, str) and _R9.search(v)]
assert not _bad, _bad
with open(BOMF, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)

# ---------------------------------------------------------------- netlist
nl = list(csv.DictReader(open(NETF, encoding='utf-8-sig')))
nfields = list(nl[0].keys())
nl = [r for r in nl if r['refdes'] not in RETIRED and r['refdes'] not in NEW]
def pins(ref, spec, note=''):
    for i, (pn, name, net) in enumerate(spec):
        nl.append(dict(refdes=ref, pin=str(pn), pin_name=name, net=net, note=note if i == 0 else ''))
def tlv(ref, in1m, in1p, out1, in2p, in2m, out2, note):
    pins(ref, [(1, 'OUT1', out1), (2, 'IN1-', in1m), (3, 'IN1+', in1p), (4, 'GND', 'VNEG'), (5, 'IN2+', in2p), (6, 'IN2-', in2m),
               (7, 'OUT2', out2), (8, 'VCC', 'VPOS')], note)
legs = [('LP', 'L', 'LEG_LP'), ('LN', 'L', 'LEG_LN'), ('RP', 'R', 'LEG_RP'), ('RN', 'R', 'LEG_RN')]
# OR stages (TLV1704 quads, LM339 pinout): U611 = L legs, U612 = R legs.  Open collector sinks while IN+ < IN-.
def q1704(ref, ch, note):
    # ch: list of 4 tuples (in_minus, in_plus, out) for channels 1..4
    (a_m, a_p, a_o), (b_m, b_p, b_o), (c_m, c_p, c_o), (d_m, d_p, d_o) = ch
    pins(ref, [(1, '2OUT', b_o), (2, '1OUT', a_o), (3, 'V+', 'VPOS'), (4, '1IN-', a_m), (5, '1IN+', a_p), (6, '2IN-', b_m), (7, '2IN+', b_p),
               (8, '3IN-', c_m), (9, '3IN+', c_p), (10, '4IN-', d_m), (11, '4IN+', d_p), (12, 'V-', 'VNEG'), (13, '4OUT', d_o), (14, '3OUT', c_o)], note)
for k, ch in enumerate(('L', 'R')):
    tp_, tn_ = f'N6_OR{ch}P', f'N6_OR{ch}N'
    q1704(f'U{611+k}', [(tp_, 'N6_VORP', f'N6_OLP_{ch}'),      # ch1: LEG_{ch}P > V_OR+ -> c+ base
                        ('N6_VORN', tp_, f'N6_OLN_{ch}'),      # ch2: LEG_{ch}P < V_OR- -> c- base
                        (tn_, 'N6_VORP', f'N6_OLN_{ch}'),      # ch3: LEG_{ch}N > V_OR+ -> c- base
                        ('N6_VORN', tn_, f'N6_OLP_{ch}')],     # ch4: LEG_{ch}N < V_OR- -> c+ base
          f'R10 OR stage {ch}: ch1 {ch}P > V_OR+ and ch4 {ch}N < V_OR- sink N6_OLP_{ch}; ch2 {ch}P < V_OR- and ch3 {ch}N > V_OR+ sink N6_OLN_{ch}')
for k, (leg, ch, net) in enumerate(legs):
    tap = f'N6_OR{leg}'
    pins(f'R{926+k}', [(1, '1', net), (2, '2', tap)], f'OR tap 330 k from {net}')
    pins(f'C{639+k}', [(1, '1', tap), (2, '2', 'GND')], 'OR tap 1 nF C0G (tau 0.33 ms)')
    lw = f'N6_LW{leg}'
    pins(f'R{930+k}', [(1, '1', net), (2, '2', lw)], f'LPW tap 1.00 M from {net}')
    pins(f'C{643+k}', [(1, '1', lw), (2, '2', 'GND')], 'LPW tap 3.3 nF C0G')
# LPW stages: per leg and polarity one TLV3402 (ch1 level -> timer node, ch2 timer > 0 V -> E-3 base)
u = 613; rt = 942; ct = 647
for leg, ch, net in legs:
    lw = f'N6_LW{leg}'
    for pol in ('P', 'N'):
        tn = f'N6_TW{leg}{pol}'
        if pol == 'P':
            in1p, in1m = lw, 'N6_VLLP'
        else:
            in1p, in1m = 'N6_VLLN', lw
        positive_pair = (leg.endswith('P') and pol == 'P') or (leg.endswith('N') and pol == 'N')
        dest = f'N6_OLP_{ch}' if positive_pair else f'N6_OLN_{ch}'
        tlv(f'U{u}', in1m, in1p, tn, 'GND', tn, dest,
            f'R10 LPW {leg}{"+" if pol=="P" else "-"}: ch1 releases timer {tn} while the tap is beyond V_LL (else sinks it to VNEG); ch2 sinks {dest} while the timer > 0 V')
        pins(f'R{rt}', [(1, '1', 'VPOS'), (2, '2', tn)], 'LPW timer R_T2 910 k')
        pins(f'C{ct}', [(1, '1', tn), (2, '2', 'GND')], 'LPW timer C_T2 100 nF C0G 0805')
        u += 1; rt += 1; ct += 1
pins('R934', [(1, '1', '3V3A'), (2, '2', 'N6_VORP')], 'V_OR+ top 360 k')
pins('R935', [(1, '1', 'N6_VORP'), (2, '2', 'GND')], 'V_OR+ bottom 470 k')
pins('R936', [(1, '1', 'VNEG'), (2, '2', 'N6_VORN')], 'V_OR- top 470 k')
pins('R937', [(1, '1', 'N6_VORN'), (2, '2', 'N6_ORTEST')], 'V_OR- bottom 470 k, returned to the OR test line (0 V normal)')
pins('R938', [(1, '1', '3V3A'), (2, '2', 'N6_VLLP')], 'V_LL+ top 1.00 M')
pins('R939', [(1, '1', 'N6_VLLP'), (2, '2', 'GND')], 'V_LL+ bottom 100 k')
pins('R940', [(1, '1', 'VNEG'), (2, '2', 'N6_VLLN')], 'V_LL- top 1.00 M')
pins('R941', [(1, '1', 'N6_VLLN'), (2, '2', 'GND')], 'V_LL- bottom 88.7 k')
pins('Q627', [(1, 'B', 'N6_ORTB'), (2, 'E', 'GND'), (3, 'C', 'N6_ORQC')], 'OR self-test: test line high -> V_OR+ pulled to 0.086-0.141 V through R951')
pins('R951', [(1, '1', 'N6_VORP'), (2, '2', 'N6_ORQC')], 'OR self-test: 10 k in series with the Q627 collector (defined positive test threshold)')
pins('R950', [(1, '1', 'N6_ORTEST'), (2, '2', 'N6_ORTB')], 'Q627 base 100 k; N6_ORTEST = MCU/CPLD test output (digital assigns the pin, push-pull, default low)')
pins('C655', [(1, '1', 'VPOS'), (2, '2', 'GND')], 'U611 V+ decoupling')
pins('C656', [(1, '1', 'VNEG'), (2, '2', 'GND')], 'U611 V- decoupling')
pins('C657', [(1, '1', 'VPOS'), (2, '2', 'GND')], 'U612 V+ decoupling')
pins('C658', [(1, '1', 'VNEG'), (2, '2', 'GND')], 'U612 V- decoupling')
for k in range(8):
    pins(f'C{659+k}', [(1, '1', 'VPOS'), (2, '2', 'VNEG')], f'U{613+k} VCC-GND (VPOS-VNEG) decoupling 100 nF')
with open(NETF, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=nfields); w.writeheader(); w.writerows(nl)
msg = (f'p21d: BOM {len(rows)} lines ({sum(int(r["qty"]) for r in rows)} parts), netlist {len(nl)} pin rows; retired {len(RETIRED)} parts, '
       f'new 65 parts (U611-U620, R926-R951, C639-C666, Q627)')
open(__file__.replace('.py', '_out.txt'), 'w').write(__doc__ + '\n' + msg + '\n')
print(msg)
