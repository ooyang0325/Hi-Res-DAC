#!/usr/bin/env python3
"""p14 - VE round (25 Sep 2026) BOM/netlist edits for the protection stream (brief_ve.md).  Reads bom_rows_r3.csv.bak /
netlist_r3.csv.bak (round-3 state) and writes bom_rows.csv / netlist.csv.
  VE-P1 K601-K604 TLP3545A(TP1,F): owner-fitted (O-4 allows DIP-SMD photorelays), bought at DigiKey.
  VE-P2 R641/R642: Vishay PATT0402 (global) -> YAGEO RT0402BRD0724R9L, LCSC C852667 (same 24.9 ohm 0.1 % 25 ppm; p05 unchanged).
  VE-P3 U605 TLV3402IDR: LCSC C91242 confirmed (evidence update, price 0.68 at 10+).
  VE-P4 U601-U603/U606 TLV1704AIPWR: LCSC C181596 (61 pcs Jul 2026) -> order from LCSC stock when >= 25 at order time.
  VE-P5 R668 866 k 0.1 % (global) -> 1.00 M 1 % (C26083, Basic); R669 100 k 0.1 % -> 100 k 1 % (Basic line); p10 re-run.
  VE-P6 D610 BAS70,215 (LCSC C109295 out of stock) -> BAS70-04,215 (C389351, same die, one diode used; pins identical) -> one part type fewer.
  Evidence notes: R688/R689 C25790 (Extended); R679/R686 22 M C407703 LCSC out of stock; U607 C545626 LCSC out of stock."""
import csv
rows = list(csv.DictReader(open('bom_rows_r3.csv.bak', newline='', encoding='utf-8-sig')))
fields = list(rows[0].keys())
def line(prefix):
    for r in rows:
        if r['refs'].split(',')[0].strip() == prefix:
            return r
    raise KeyError(prefix)
def set_refs(r, refs):
    r['refs'] = ', '.join(refs); r['qty'] = str(len(refs))
# VE-P1
r = line('K601')
r['jlcpcb_class'] = 'owner-fitted (not placed by JLCPCB)'
r['lcsc'] = 'none'
r['jlcpcb_stock_or_sourcing'] = ('Owner purchase: DigiKey 264-TLP3545A(TP1FCT-ND, 28,529 in stock, US$ 3.684 at 10+ / 3.518 at 25+ (18 Sep 2026); '
                                 'Mouser 757-TLP3545ATP1F 15,326; MSL 1')
r['unit_price_usd'] = '3.684'
r['note'] = ('owner-fitted (hand-soldered, not placed by JLCPCB) - VE O-4: DIP-SMD photorelay, 2.54 mm pitch gull wing; lands with toes '
             'extended >= 0.3 mm and >= 1.5 mm iron clearance; fitted after the rail/MCU/DAC bring-up and before the protection tests. '
             + r['note'])
# VE-P2
r = line('R641')
r.update(mpn='YAGEO RT0402BRD0724R9L', lcsc='C852667', jlcpcb_class='Extended',
         jlcpcb_stock_or_sourcing='LCSC 19,000 (LCSC page 23 Sep 2026), US$ 0.034', unit_price_usd='0.0343',
         datasheet_url='https://www.lcsc.com/product-detail/C852667.html',
         note='VE: replaces Vishay PATT0402E24R9BGT1 (global sourcing, US$ 0.70); same 24.9 ohm 0.1 % 25 ppm thin film -> p05 LED window unchanged')
# VE-P3
r = line('U605')
r.update(lcsc='C91242', jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC 745 (LCSC page Mar 2026; recheck at order); DigiKey 1,323',
         unit_price_usd='0.6771', note='VE: LCSC stock confirmed (was TBC, US$ 1.20 estimate)')
# VE-P4
r = line('U601')
r['jlcpcb_stock_or_sourcing'] = ('LCSC C181596 61 pcs (LCSC page 7 Jul 2026), US$ 1.25 -> order from LCSC stock if >= 25 at order time, '
                                 'else JLCPCB global sourcing; DigiKey 6,948 (25 Sep 2026); MSL 2-260C-1 year')
r['unit_price_usd'] = '1.2502'
# VE-P5
r866 = line('R668'); rows.remove(r866)
r = line('R666')
set_refs(r, ['R666', 'R668'])
r.update(desc='1.00 MOhm 1 %: MCLK pump bleed (R666), MCLK-alive threshold divider top (R668, VE: was 866 k 0.1 %)', value='1.00 MOhm',
         lcsc='C26083', jlcpcb_class='Basic', jlcpcb_stock_or_sourcing='JLCPCB 2,055,430 (20 Sep 2026), PCBA Economic and Standard',
         unit_price_usd='0.0026', datasheet_url='https://jlcpcb.com/partdetail/0402WGF1004TCE/C26083')
r100p = line('R653')
refs = [x.strip() for x in r100p['refs'].split(',') if x.strip() != 'R669']; set_refs(r100p, refs)
r100p['desc'] = r100p['desc'].replace('R669/R673 VPOS reference dividers bottom (R3)', 'R673 1V3 reference divider bottom (R3)')
r1 = line('R646')
refs = [x.strip() for x in r1['refs'].split(',')] + ['R669']; set_refs(r1, refs)
r1['desc'] = r1['desc'] + '; R669 MCLK-alive threshold divider bottom (VE: was 0.1 %)'
# VE-P6 and evidence notes
rd = line('D609'); rows.remove(line('D610'))
set_refs(rd, ['D609', 'D610'])
rd.update(desc='Dual Schottky, series (BAS70-04): D609 MCLK pump clamp + rectifier; D610 1V3-good test injection (diode 1 only: A1 pin 1, K1 pin 3; pin 2 NC)',
          lcsc='C389351', jlcpcb_class='Extended (TBC)', jlcpcb_stock_or_sourcing='LCSC 36,430 (LCSC page 9 Sep 2026), US$ 0.096 at 10+',
          unit_price_usd='0.0962', datasheet_url='https://www.lcsc.com/product-detail/C389351.html',
          note='VE: D610 moved from BAS70,215 (LCSC C109295 out of stock) to the same BAS70-04,215 part (same die, VF <= 410 mV at 1 mA; netlist pins unchanged)')
r = line('R688')
r.update(lcsc='C25790', jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC 452,700 (2 Sep 2026); PCBA Economic and Standard', unit_price_usd='0.0033')
r = line('R679')
r.update(lcsc='C407703', jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC OUT OF STOCK (Jun 2026 page) -> JLCPCB global sourcing, or any in-stock 22 MOhm <= 5 % 0402/0603',
         note='VE: tolerance uncritical (5 % moves the U605 release threshold by <= 2 mV; margin 66 mV) - parts stream to pick an in-stock 22 MOhm; 10 MOhm (C26082) is also out of stock')
r = line('U607')
r.update(lcsc='C545626', jlcpcb_class='Extended', jlcpcb_stock_or_sourcing='LCSC OUT OF STOCK (Jul 2026 page) -> JLCPCB global sourcing (as costed); an SC-70-5 AUP1G17 from another maker needs the VT+/VT-, CI and Ioff check first')
w = csv.DictWriter(open('bom_rows.csv', 'w', newline='', encoding='utf-8'), fieldnames=fields); w.writeheader(); w.writerows(rows)
nl = list(csv.DictReader(open('netlist_r3.csv.bak', newline='', encoding='utf-8-sig')))
nf = list(nl[0].keys())
for x in nl:
    if x['refdes'] == 'R668' and x['pin'] == '1':
        x['note'] = 'MCLK threshold top 1.00 M 1 % (VE; was 866 k 0.1 %)'
    if x['refdes'] == 'R669' and x['pin'] == '1':
        x['note'] = 'MCLK threshold bottom 100 k 1 % (VE; was 0.1 %)'
    if x['refdes'] == 'D610':
        x['pin_name'] = {'1': 'A1', '2': 'K2', '3': 'K1/A2'}[x['pin']]
        if x['pin'] == '1':
            x['note'] = 'BAS70-04 (VE), diode 1 only: 1V3-good test injection'
    if x['refdes'] in ('K601', 'K602', 'K603', 'K604') and x['pin'] == '1':
        x['note'] = 'owner-fitted (hand-soldered, not placed by JLCPCB); ' + x['note']
w = csv.DictWriter(open('netlist.csv', 'w', newline='', encoding='utf-8'), fieldnames=nf); w.writeheader(); w.writerows(nl)
print(f'BOM lines {len(rows)}, netlist rows {len(nl)}')
