#!/usr/bin/env python3
"""p05 - Output-switch drive for 4 x Toshiba TLP3545A(TP1,F) (decision D-1), hardware permit H, MCLK_EN gate,
readback DC_PERMIT_N: LED currents, headroom, supply currents, switch-open times, minimum off-time, unplug
dropout, stresses and the block-6 load on VPOS/VNEG.  numpy only.

Round-2 change: the TLP3545A LED VF is 1.80 V max at 10 mA (AQV251G: 1.5 V at 5 mA).  With two LEDs per
string at their 0 C maximum only ~0.59 V is left at 5V_SYS = 4.30 V, but the round-1 MMBT3904 VBE limiter needs
VBE (0.54-0.71 V) + VCE >= 0.3 V.  It is replaced by a low-dropout op-amp current sink (sense voltage 0.14-0.16 V).

Circuit (block 6):
  String L: 5V_SYS -> K601 LED (1->2) -> N6_SL_A -> K602 LED (1->2) -> N6_SL_C -> Q612 C (MMBT3904);
            Q612 E = N6_EL -> R641 (R_S) -> N6_EM.  U604A (OPA2333): +IN = N6_IREF, -IN = N6_EL,
            OUT = N6_OAL -> R643 (R_B) -> Q612 B (N6_BL).   I_LED = (V_IREF - VOS - V_FET) / R_S.
  String R: K603, K604, Q614, R642, R644, U604B (nets N6_SR_A, N6_SR_C, N6_ER, N6_OAR, N6_BR).
  N6_IREF = RELAY_EN x R663 / (R662 + R663).  U604 V+ = 3V3D (on whenever the DAC domain is on), C622 at the pin.
  N6_EM -> Q616 (AO3400A, gate N2_MCLK_OE via R645 1 k) -> N6_M2 -> Q617 (AO3400A, gate N6_H) -> GND.
  N2_MCLK_OE = U206 (74LVC1G11, 3V3D) output = MCLK_EN AND AVCC_EN AND MCLK_PERMIT, the X201 run signal (D-19),
  R235 100 k pull-down (digital stream).
  RELAY_EN pull-down R646 100 k.  N6_H: R647 100 k to VPOS, C617 1 uF to GND, 12 TLV1704 open-collector
  outputs.  Readback Q618 (2N7002): G = N6_H, D = DC_PERMIT_N (R648 100 k to 3V3M), S = GND.
The LEDs conduct only if RELAY_EN (reference) AND the MCLK run signal (Q616) AND H (Q617: rails up, no leg DC, I/V common mode
normal, 3V3A present) are all true.  RELAY_EN low -> V_IREF = 0 and the zero-drift op-amp leaves <= 1.2 uA (VOS/R_S),
below the TLP3545A guaranteed-off current (IFC >= 10 uA); Q616 or Q617 off -> their off-state leakage only.
(An intermediate version fed U604 from RELAY_EN through 220 ohm + 100 nF; rejected: C622 would hold the RELAY_EN node
up for ms after an MCU reset, defeating R646.)
"""
import numpy as np
from pcommon import *

# ---------------- datasheet numbers ([DS] unless labelled) ------------------------------------------
VOH_DROP = 0.40              # CH32V307 GPIO: VOH >= VDD - 0.4 V at |IOH| <= 8 mA [DS, via digital stream]; bound for any lower current
OPA_VOS = 10e-6 + 0.05e-6 * (T_LOCAL_MAX - 25) + 5e-6 * (5.0 - 2.6)   # OPA2333 SBOS351E 6.6: VOS 25 C + drift + PSRR (VS 2.6-5 V)
OPA_IQ = 28e-6               # per amplifier, -40..125 C [DS]
OPA_SR = 0.16e6              # V/s [DS-typ]
OPA_TON = 100e-6             # turn-on time, VS = 5 V [DS-typ]
OPA_SWING = 0.070            # V from rail at RL 10 k, -40..125 C [DS]
OPA_ISC = 5e-3               # short-circuit current [DS-typ]
OPA_VS_ABS = 7.0
HFE_MIN_25 = 70              # MMBT3904 hFE min at IC 1 mA (100 at 10 mA), VCE 1 V [DS]
HFE_COLD = 0.7               # [ASSUMP] hFE factor at 0 C
VCE_ACTIVE = 0.30            # design rule: VCE(sat) <= 0.2 V at IC 10 mA / IB 1 mA [DS] -> keep >= 0.3 V
VCESAT = 0.20
VBE_ON_MAX = 0.85            # MMBT3904 VBE(sat) max 0.85 V at 10 mA / 1 mA [DS] (bound for the active VBE at <= 7 mA)
AO_VTH = (0.65, 1.45)        # AO3400A VGS(th) at 250 uA [DS AOS rev 3]
AO_RDS_2V5 = 0.048           # ohm at VGS 2.5 V [DS]
AO_RDS_HOT = 1.3             # [ASSUMP] RDS(on) factor at 60 C (typical curve only)
AO_CISS = 1.0e-9             # [ASSUMP] bound at low VDS (630 pF typ at 15 V [DS-typ])
AO_IGSS = 100e-9             # at +-12 V [DS]
AO_IDSS_55 = 5e-6            # VDS 30 V, TJ 55 C [DS]; lower at VDS <= 0.2 V
N7002_VTH = (1.0, 2.5)       # JSCJ 2N7002 VGS(th) at 250 uA [DS]
N7002_IGSS = 100e-9          # [ASSUMP bound]
TLV_OUT_LEAK = 70e-9         # TLV1704 output leakage: 70 nA listed, typ/max column not certain, 25 C only [DS SBOS589D 7.6]
IQ_CH_MAX = 100e-6           # TLV1704 IQ per channel, -40..125 C [DS]
TLV_SINK = 4e-3              # TLV1704 output within 0.9 V of V- at IO <= 4 mA [DS 7.6] -> sinks >= 4 mA while above that
TLV_VOL0 = 0.60              # output swing from V- at IO = 0 [DS 7.6]
N_COMP = 12
H_REQ = 3.0                  # H needed when permitted: Q618 VGS(th) max 2.5 V + 0.5 V; Q617 RDS(on) spec at 2.5 V

# ---------------- component values -------------------------------------------------------------------
R_S = 24.9                   # R641/R642, 0.1 % 25 ppm thin film (Yageo RT0402BRD0724R9L)
R_S_TOL = 0.001 + 25e-6 * 40
R_TOP, R_BOT = 100e3, 5.1e3  # R662, R663, 0.1 % 25 ppm (existing BOM lines C852472, C852856)
R_DIV_TOL = 0.001 + 25e-6 * 40
R_B = 4.7e3                  # R643/R644 (op-amp output -> base)
C_SUP = 100e-9               # C622, U604 decoupling on 3V3D
OPA_IB = 1e-9                # [ASSUMP] input bias bound over temperature (200 pA max at 25 C [DS])
C_EN_NODE = 10e-12           # [ASSUMP] RELAY_EN pin + trace capacitance
R_PD_EN, R_PU_DP, R_GMC, R235 = 100e3, 100e3, 1e3, 100e3   # R235: N2_MCLK_OE pull-down (digital, D-19)
V_OE_HI = 3.1               # [ASSUMP] U206 VOH at 3V3D >= 3.2 V and a 1 k / 1 nF gate load (digital: VOH >= 3.10 V)
R_H, C_H = 100e3, 1.0e-6     # R647 1 %, C617 Samsung CL10A105KB8NNNC 1 uF 50 V X5R 0603 +-10 %
C_H_LO = 0.85 * 0.85         # tolerance/temperature [BRIEF] x DC bias <= 4 V on a 50 V part [ASSUMP]
C_H_HI = 1.10
# H fall on a trip: one comparator sinks >= 4 mA; C617 +10 %; from VPOS max to 0.2 V below the lowest AO3400A VGS(th).
T_H_FALL = C_H * C_H_HI * (VPOS_MAX - (AO_VTH[0] - 0.2)) / TLV_SINK

# LED model used only where a curve would be needed (unplug decay) [ASSUMP]: VF(I) = VF10 + n VT ln(I/10 mA) + Rs (I - 10 mA)
LED_N, LED_RS = 2.0, 3.0


def vf_led(i, vf10, t):
    vt = 8.617e-5 * (t + 273.15)
    return vf10 + LED_N * vt * np.log(i / 10e-3) + LED_RS * (i - 10e-3)


def k_div(worst):
    """Reference divider ratio; worst = -1 lowest, +1 highest."""
    rt = R_TOP * (1 - worst * R_DIV_TOL); rb = R_BOT * (1 + worst * R_DIV_TOL)
    return rb / (rt + rb)


def sink():
    """Worst-case LED string current (collector current) per string."""
    v_en_min, v_en_max = V3V3_MIN - VOH_DROP, V3V3_MAX
    vref_min, vref_max = v_en_min * k_div(-1), v_en_max * k_div(+1)
    ie_max = (vref_max + OPA_VOS) / (R_S * (1 - R_S_TOL))
    v_fet = 2 * AO_RDS_2V5 * AO_RDS_HOT * 2 * ie_max            # Q616 + Q617 carry both strings
    beta = HFE_MIN_25 * HFE_COLD
    ie_min = (vref_min - OPA_VOS - v_fet) / (R_S * (1 + R_S_TOL))
    ic_min = ie_min * beta / (beta + 1)
    return dict(v_en=(v_en_min, v_en_max), vref=(vref_min, vref_max), ie_max=ie_max, ic_max=ie_max, ic_min=ic_min,
                v_fet=v_fet, beta=beta, v_el_max=vref_max + OPA_VOS, v_el_min=vref_min - OPA_VOS)


def main():
    out = [__doc__]
    s = sink()
    vf_cold = SW_VF_MAX_COLD
    vf_hot_min = SW_VF_MIN_10 + SW_VF_TC * (T_LOCAL_MAX - 25) - (LED_N * 8.617e-5 * (T_LOCAL_MAX + 273.15) * np.log(2)
                                                                   + LED_RS * 5e-3)
    out.append('TLP3545A(TP1,F) data used [DS Toshiba datasheet EN 2023-05-24, Ta = 25 C]: VF 1.50/1.64/1.80 V at 10 mA; '
               'IFT <= 3 mA (typ 0.3); IFC >= 0.01 mA (off once IF <= 10 uA); RON <= 60 mOhm at IF 5 mA; tON <= 5 ms / '
               'tOFF <= 0.5 ms at IF 5 mA (3 / 0.5 ms at 10 mA); IF abs 30 mA (-0.3 mA/K > 25 C), VR 6 V, PD 50 mW '
               '(-0.5 mW/K); recommended IF 5-25 mA.')
    out.append(f'  VF bound for IF <= 10 mA at 0 C: {vf_cold:.3f} V (1.80 V max + {-SW_VF_TC*1e3:.1f} mV/K x 25 K [ASSUMP]); '
               f'2 LEDs {2*vf_cold:.3f} V -> {V5SYS_MIN - 2*vf_cold:.3f} V left at 5V_SYS = {V5SYS_MIN:.2f} V')
    out.append(f'  round-1 MMBT3904 VBE limiter would need VBE 0.54-0.71 V + VCE 0.3 V = 0.84-1.01 V -> fails by '
               f'{0.836 - (V5SYS_MIN - 2*vf_cold):.2f}-{1.007 - (V5SYS_MIN - 2*vf_cold):.2f} V: topology changed')

    # ---------------- current sink ----------------------------------------------------------------
    out.append(f'\nLow-dropout sink: V_IREF = RELAY_EN x R663/(R662+R663) = {R_BOT/1e3:.1f} k/({R_TOP/1e3:.0f} k + {R_BOT/1e3:.1f} k) '
               f'(0.1 %); RELAY_EN {s["v_en"][0]:.3f}-{s["v_en"][1]:.3f} V (3V3M +-2 %, VOH >= VDD - 0.4 V [DS]) -> '
               f'V_IREF {s["vref"][0]*1e3:.1f}-{s["vref"][1]*1e3:.1f} mV; OPA2333 VOS <= {OPA_VOS*1e6:.0f} uV incl. drift/PSRR [DS]; '
               f'R_S = R641/R642 {R_S} ohm 0.1 % 25 ppm; Q616+Q617 drop <= {s["v_fet"]*1e3:.2f} mV; hFE >= {s["beta"]:.0f} at 0 C')
    ok_min = s['ic_min'] >= 5.0e-3
    out.append(f'  LED current per string: {s["ic_min"]*1e3:.3f} ... {s["ic_max"]*1e3:.3f} mA  (requirement D-1: >= 5.0 mA at '
               f'every corner -> {"MET" if ok_min else "NOT MET"}, margin {100*(s["ic_min"]/5e-3-1):.1f} %); independent of '
               '5V_SYS and VF while Q612 is active')
    vce_min = V5SYS_MIN - 2 * vf_cold - s['v_el_max']
    out.append(f'  Headroom at 5V_SYS = {V5SYS_MIN} V, 0 C, VF max: Q612 VCE >= {vce_min:.3f} V (>= {VCE_ACTIVE} V active-region '
               f'rule: margin {vce_min - VCE_ACTIVE:+.3f} V; VCE(sat) {VCESAT} V: {vce_min - VCESAT:+.3f} V)')
    m_act, m_sat = (vce_min - VCE_ACTIVE) / 2, (vce_min - VCESAT) / 2
    out.append(f'  VF margin: each LED may exceed its {vf_cold:.3f} V bound by {m_act*1e3:.0f} mV (active rule) / {m_sat*1e3:.0f} mV '
               f'(VCE(sat)) before IF leaves regulation, i.e. a VF tempco down to {(SW_VF_TC - m_act/25)*1e3:.1f} mV/K is tolerated; '
               '[MEAS] VF at 5-6.6 mA and 0 C on samples. For comparison, the round-1 limiter (100 ohm, saturated) would give '
               f'{(V5SYS_MIN - 2*vf_cold - 0.1 - 0.02)/100*1e3:.2f} mA here (zero margin)')
    v_drop_hi = 2 * vf_cold + s['v_el_max'] + VCE_ACTIVE
    v_drop_ty = 2 * vf_led(5.5e-3, SW_VF_TYP_10, 25.0) + 0.15 + 0.15
    out.append(f'  Regulation holds (IF >= 5.0 mA) down to 5V_SYS = {v_drop_hi:.2f} V worst (0 C, VF max), ~{v_drop_ty:.2f} V '
               'typical (25 C, VF typ) [CALC/ASSUMP LED model]; below that IF falls gradually (Q612 saturates)')

    # ---------------- supply currents ---------------------------------------------------------------
    ib_max = s['ie_max'] / (s['beta'] + 1)
    i_div = s['v_en'][1] / ((R_TOP + R_BOT) * (1 - R_DIV_TOL))
    i_en = i_div + s['v_en'][1] / (R_PD_EN * 0.99)
    i_dp = V3V3_MAX / (R_PU_DP * 0.99)
    i_5v = 2 * s['ic_max']
    i_3v3 = i_en + i_dp
    i_3v3d = 2 * OPA_IQ + 2 * ib_max
    out.append(f'\nSupply while RELAY_EN is high (any 5V_SYS {V5SYS_MIN}-{V5SYS_CLAMP} V, the sink does not depend on it): '
               f'5V_SYS {2*s["ic_min"]*1e3:.2f} ... {i_5v*1e3:.2f} mA (two strings); 3V3M {i_3v3*1e3:.3f} mA (RELAY_EN pin '
               f'{i_en*1e3:.3f} mA = divider {i_div*1e6:.0f} uA + R646 {s["v_en"][1]/(R_PD_EN*0.99)*1e6:.0f} uA; DC_PERMIT_N pull-up '
               f'{i_dp*1e6:.0f} uA); 3V3D {i_3v3d*1e3:.3f} mA (U604 IQ {2*OPA_IQ*1e6:.0f} uA + base drive {2*ib_max*1e6:.0f} uA; '
               f'IQ only, {2*OPA_IQ*1e6:.0f} uA, while RELAY_EN is low and 3V3D is up)')
    out.append(f'  => USB load of the output switch <= {(i_5v + i_3v3 + i_3v3d)*1e3:.2f} mA (D-1 budget 14.3 + 1.02 = 15.32 mA -> '
               f'{"inside" if i_5v + i_3v3 + i_3v3d <= 15.32e-3 else "CHECK"}); 0 mA on 5V_SYS/3V3M with RELAY_EN low '
               '(unconfigured, suspend, programming mode, MCU in reset); U604 is off whenever 3V3D is off (suspend)')
    out.append(f'  RELAY_EN pin: DC {i_en*1e6:.0f} uA (<< 8 mA VOH point); no capacitance on the net -> after an MCU reset R646 pulls '
               f'it to 0 V in ~{(R_PD_EN*(R_TOP+R_BOT)/(R_PD_EN+R_TOP+R_BOT))*C_EN_NODE*5e6:.1f} us')

    # ---------------- LED and part stresses ---------------------------------------------------------
    if_abs60 = SW_IF_ABS - SW_IF_DERATE * (T_LOCAL_MAX - 25)
    pd_abs60 = SW_PD_ABS - SW_PD_DERATE * (T_LOCAL_MAX - 25)
    out.append(f'\nLED: IF <= {s["ic_max"]*1e3:.2f} mA vs abs max {if_abs60*1e3:.1f} mA at {T_LOCAL_MAX:.0f} C (x{if_abs60/s["ic_max"]:.1f}); '
               f'recommended 5-25 mA: {"yes" if s["ic_min"] >= 5e-3 else "no"}; PD <= {s["ic_max"]*vf_cold*1e3:.1f} mW vs '
               f'{pd_abs60*1e3:.1f} mW; reverse voltage ~0 V in every state (6 V TLP3545A, 5 V AQV251GA)')
    p_q = (V5SYS_CLAMP - 2 * vf_hot_min - s['v_el_min']) * s['ic_max']
    out.append(f'  Q612/Q614 at 5V_SYS {V5SYS_CLAMP} V, VF min hot {vf_hot_min:.3f} V: VCE <= {V5SYS_CLAMP - 2*vf_hot_min - s["v_el_min"]:.2f} V, '
               f'P <= {p_q*1e3:.1f} mW (200 mW at 25 C, ~144 mW at 60 C); VCE <= {V5SYS_CLAMP:.2f} V when off (40 V)')
    out.append(f'  R641/R642: {s["ie_max"]**2*R_S*1e3:.2f} mW (50 mW Vishay PATT0402 / 62.5 mW Yageo RT0402); Q616/Q617: ID <= {2*s["ie_max"]*1e3:.1f} mA, '
               f'VDS <= {V5SYS_CLAMP} V off (30 V), P <= {(2*s["ie_max"])**2*AO_RDS_2V5*AO_RDS_HOT*1e6:.0f} uW; Q617 VGS '
               f'-{VNEG_MAX:.2f}...+{VPOS_MAX:.2f} V (+-12 V)')
    ib_sat = (V3V3_MAX - OPA_SWING - 0.6 - s['v_el_min']) / R_B
    out.append(f'  U604 (3V3D): V+ <= {V3V3_MAX} V (abs {OPA_VS_ABS} V); +IN <= {s["vref"][1]*1e3:.0f} mV, -IN 0...V+ (N6_EL follows the base '
               f'when Q616/Q617 are off); output current <= {ib_sat*1e3:.2f} mA even with Q612 saturated or a string open '
               f'(ISC {OPA_ISC*1e3:.0f} mA)')

    # ---------------- loop stability (estimate) ----------------------------------------------------------
    gm = s['ic_max'] / 0.0257
    k_f = gm * R_S / (1 + gm * R_S)
    c_in = 4e-12 + gm / (2 * np.pi * 300e6) / (1 + gm * R_S)     # MMBT3904 Cobo <= 4 pF, fT >= 300 MHz [DS]
    f_b = 1 / (2 * np.pi * R_B * c_in)
    f_c = k_f * 350e3
    ph_b = np.degrees(np.arctan(f_c / f_b))
    out.append(f'  Loop (estimate): U604 GBW 350 kHz [DS-typ] x follower gain {k_f:.2f} -> crossover ~{f_c/1e3:.0f} kHz; base pole '
               f'R643 x (Cmu + Cpi/(1 + gm R_S)) = {R_B/1e3:.1f} k x {c_in*1e12:.0f} pF -> {f_b/1e6:.2f} MHz (-{ph_b:.0f} deg); with the '
               f'op-amp\'s own unity-gain margin (>= 55 deg at light load [ASSUMP]) PM >= {55-ph_b:.0f} deg. Bring-up: LED-current '
               'step response; fallback R643/R644 4.7 k -> 1 k (value change only, base pole x4.7)')

    # ---------------- off state -----------------------------------------------------------------------
    i_res = (OPA_VOS + OPA_IB * R_TOP * R_BOT / (R_TOP + R_BOT)) / (R_S * (1 - R_S_TOL))
    out.append(f'\nOff state: RELAY_EN low -> V_IREF = 0; U604 (on 3V3D) holds N6_EL at <= VOS + IB x 4.85 k = '
               f'{(OPA_VOS + OPA_IB*R_TOP*R_BOT/(R_TOP+R_BOT))*1e6:.0f} uV -> IF <= {i_res*1e6:.2f} uA; Q616 or Q617 off -> IF <= IDSS <= '
               f'{AO_IDSS_55*1e6:.0f} uA (30 V, 55 C spec; VDS here <= 0.2 V); both < IFC min {SW_IFC_MIN*1e6:.0f} uA -> every '
               'TLP3545A is guaranteed off [DS]. 3V3D off -> U604 unpowered -> no drive at all.')

    # ---------------- permit node H -------------------------------------------------------------------
    i_leak = N_COMP * TLV_OUT_LEAK + AO_IGSS + N7002_IGSS
    h_hi_min = VPOS_MIN - i_leak * R_H * 1.01
    i_ok = (VPOS_MIN - H_REQ) / (R_H * 1.01)
    lk_ok = (i_ok - AO_IGSS - N7002_IGSS) / N_COMP
    out.append(f'\nPermit node H: R647 {R_H/1e3:.0f} k to VPOS, C617 {C_H*1e6:.1f} uF 50 V X5R (round-1 edit adopted: was 470 k / '
               f'220 nF); leakage {i_leak*1e6:.2f} uA -> H(high) >= {h_hi_min:.2f} V; H stays >= {H_REQ} V up to {i_ok*1e6:.2f} uA '
               f'total = {lk_ok*1e9:.0f} nA per comparator output ({lk_ok/TLV_OUT_LEAK:.1f} x the listed 70 nA; 470 k allowed only '
               f'1.7 x). Excess leakage can only keep the switch open (fail-safe).')
    out.append(f'  Trip: one comparator sinks >= 4 mA -> H from {VPOS_MAX} V to {AO_VTH[0]-0.2:.2f} V in <= {T_H_FALL*1e3:.3f} ms '
               f'(470 k/220 nF: 0.216 ms)')
    t_open_h = T_H_FALL + SW_TOFF_DESIGN
    tau_lo = R_H * 0.99 * C_H * C_H_LO
    tau_hi = R_H * 1.01 * C_H * C_H_HI
    h_low_hi = -VNEG_MIN + TLV_VOL0
    h_low_lo = -VNEG_MAX + 0.01
    t_off_min = tau_lo * np.log((VPOS_MAX - h_low_hi) / (VPOS_MAX - AO_VTH[0]))
    t_617_max = tau_hi * np.log((h_hi_min - h_low_lo) / (h_hi_min - AO_VTH[1]))
    t_618_min = tau_lo * np.log((VPOS_MAX - h_low_hi) / (VPOS_MAX - N7002_VTH[0]))
    t_618_max = tau_hi * np.log((h_hi_min - h_low_lo) / (h_hi_min - N7002_VTH[1]))
    lead = tau_hi * np.log((h_hi_min - N7002_VTH[0]) / (h_hi_min - AO_VTH[1]))
    out.append(f'  After the last trip condition clears (H from {h_low_lo:.2f}...{h_low_hi:.2f} V, tau {tau_lo*1e3:.0f}...{tau_hi*1e3:.0f} ms): '
               f'Q617 conducts again after {t_off_min*1e3:.0f} ... {t_617_max*1e3:.0f} ms (= minimum switch-off time, no chatter, '
               f'no latch); DC_PERMIT_N reads "permitted" after {t_618_min*1e3:.0f} ... {t_618_max*1e3:.0f} ms')
    out.append(f'  Readback vs permit thresholds overlap (Q618 1.0-2.5 V, Q617 0.65-1.45 V): on a trip the readback lags Q617 by '
               f'<= {(1.0 - 0.45) / (TLV_SINK / (C_H * C_H_HI)) * 1e3:.2f} ms; on recovery it may lead Q617 by <= {lead*1e3:.0f} ms -> '
               'the pre-close rule "DC_PERMIT_N low >= 50 ms" always finds Q617 on')

    # ---------------- switch-open times -----------------------------------------------------------------
    vb_max = s['v_el_max'] + VBE_ON_MAX + ib_max * R_B
    t_slew = (vb_max - 0.40) / OPA_SR
    t_en = t_slew + SW_TOFF_DESIGN
    t_gmc = R_GMC * AO_CISS * np.log(V_OE_HI / (AO_VTH[0] - 0.2))
    t_gmc_z = (R_GMC + R235) * AO_CISS * np.log(3.4 / (AO_VTH[0] - 0.2))
    out.append('\nSwitch-open time (LED current interrupted + TLP3545A tOFF; tOFF <= 0.5 ms at 25 C [DS], 1.0 ms design over '
               '0-60 C [ASSUMP x2]):')
    out.append(f'  RELAY_EN falls: V_IREF -> 0 at once, U604 output slews {vb_max:.2f} -> 0.40 V in <= {t_slew*1e6:.1f} us '
               f'(0.16 V/us) -> open <= {t_en*1e3:.3f} ms ({(t_slew + SW_TOFF_MAX_25)*1e3:.3f} ms with the 25 C tOFF)')
    out.append(f'  MCLK run signal N2_MCLK_OE falls (D-19: MCLK_EN, AVCC_EN or MCLK_PERMIT low; U206 push-pull): Q616 gate '
               f'{R_GMC/1e3:.0f} k x {AO_CISS*1e9:.1f} nF -> off in {t_gmc*1e6:.1f} us -> open <= {(t_gmc + SW_TOFF_DESIGN)*1e3:.3f} ms '
               '(the same edge stops X201 in <= 200 ns [DS Kyocera]); U206 unpowered (3V3D off, R235 100 k): '
               f'{t_gmc_z*1e6:.0f} us -> <= {(t_gmc_z + SW_TOFF_DESIGN)*1e3:.3f} ms, and U604 has lost its supply as well')
    out.append(f'  H falls (hardware trip): {T_H_FALL*1e3:.3f} ms + tOFF -> open <= {t_open_h*1e3:.2f} ms after the comparator output '
               f'switches (round 1: 1.22 ms)')
    t_rst = (R_PD_EN * (R_TOP + R_BOT) / (R_PD_EN + R_TOP + R_BOT)) * C_EN_NODE * 5 + t_slew
    out.append(f'  MCU reset / IWDG (RELAY_EN high-Z): R646 pulls RELAY_EN low in ~{(t_rst - t_slew)*1e6:.1f} us, then as above -> '
               f'open <= {(t_rst + SW_TOFF_DESIGN)*1e3:.3f} ms after the pin is released')
    t_up = vb_max / OPA_SR
    t_on = t_up + SW_TON_MAX
    out.append(f'  Turn-on after the last condition: U604 output slews up <= {t_up*1e6:.0f} us + tON {SW_TON_MAX*1e3:.0f} ms '
               f'[DS, IF >= 5 mA, 25 C] = {t_on*1e3:.2f} ms; design {SW_TON_DESIGN*1e3:.0f} ms over temperature [ASSUMP x2] -> '
               'firmware waits 10 ms after RELAY_EN high before the volume ramp. U604 start-up glitches at 3V3D power-up are '
               'blocked by Q616 (N2_MCLK_OE low) and Q617 (H low: DAC in reset)')

    # ---------------- unplug ------------------------------------------------------------------------------
    c5 = (3.1e-6 + 4.7e-6) * 1.10
    i_min_load = 0.100
    dvdt = i_min_load / c5
    t_bo = (V5SYS_CLAMP - 3.77) / dvdt
    t_fw = t_bo + 11.3e-6 + 20e-6 + t_slew
    vf10_lo = SW_VF_MIN_10 + SW_VF_TC * (T_LOCAL_MAX - 25)
    v_off = 2 * vf_led(SW_IFC_MIN, vf10_lo, T_LOCAL_MAX)
    t_hw = (V5SYS_CLAMP - v_off) / dvdt
    out.append(f'\nUnplug (VBUS lost at the receptacle): 5V_SYS falls at >= {dvdt*1e-3:.1f} V/ms (>= {i_min_load*1e3:.0f} mA board load '
               f'[ASSUMP] from <= {c5*1e6:.1f} uF: 5V_SYS 3.1 uF + C102 4.7 uF through U102, +10 %, no DC-bias loss [power report])')
    out.append(f'  sink regulation (IF >= 5 mA) lost below 5V_SYS {v_drop_hi:.2f} V (worst) / ~{v_drop_ty:.2f} V (typ); IF < IFT typ '
               f'0.3 mA below ~{2*vf_led(0.3e-3, SW_VF_TYP_10, 25.0):.2f} V (typ); IF <= IFC 10 uA (guaranteed off) below '
               f'{v_off:.2f} V [ASSUMP LED model n = {LED_N}, Rs = {LED_RS} ohm]')
    out.append(f'  firmware path: VBUS_SENSE watchdog 3.77-4.23 V [power c09] reached <= {t_bo*1e3:.3f} ms, + ADC 11.3 us + ISR 20 us '
               f'[ASSUMP] -> RELAY_EN low -> switch open <= {(t_fw + SW_TOFF_DESIGN)*1e3:.2f} ms after VBUS loss '
               f'({(t_fw + SW_TOFF_MAX_25)*1e3:.2f} ms with the 25 C tOFF)')
    out.append(f'  hardware alone (no firmware): LEDs below 10 uA <= {t_hw*1e3:.3f} ms -> open <= {(t_hw + SW_TOFF_DESIGN)*1e3:.2f} ms. '
               'The rails collapse within tens of us to ms [power], so the unplug pop stays the analog stream\'s measured target.')

    # ---------------- block-6 load on the charge-pump rails ---------------------------------------------
    iq = 3 * 4 * IQ_CH_MAX
    i_thp = VPOS_MAX / ((121e3 + 10e3) * 0.999)
    i_thn = VNEG_MAX / ((115e3 + 10e3) * 0.999)
    i_r660 = (VPOS_MAX - 0.07) / (330e3 * 0.99)
    i_h = (VPOS_MAX + VNEG_MAX) / (R_H * 0.99)
    ip_ok, in_ok = iq + i_thp + i_r660 + N_COMP * TLV_OUT_LEAK, iq + i_thn
    out.append(f'\nBlock-6 load on VPOS / VNEG (TLV1704 IQ {IQ_CH_MAX*1e6:.0f} uA/ch max x 12, flowing V+ -> V-): permitted (normal '
               f'operation) I+ <= {ip_ok*1e3:.3f} mA, I- <= {in_ok*1e3:.3f} mA (D-9 1.26 / 1.25 mA: inside); tripped (H pulled to V-, '
               f'switch open, no headphone current) I+ <= {(ip_ok + i_h)*1e3:.3f} mA, I- <= {(in_ok + i_h)*1e3:.3f} mA (R647 '
               f'{i_h*1e6:.1f} uA; 470 k: 16.9 uA); typical IQ 55 uA/ch -> ~0.7 mA')
    out.append(f'  C617: sees -{VNEG_MAX:.2f}...+{VPOS_MAX:.2f} V (50 V part); discharge by a comparator <= '
               f'{0.5*C_H*C_H_HI*(VPOS_MAX+VNEG_MAX)**2*1e6:.0f} uJ per trip at <= 20 mA (short-circuit sink, continuous allowed)')
    open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
    print('\n'.join(out))
    return dict(i_min=s['ic_min'], i_max=s['ic_max'], i_usb=i_5v + i_3v3 + i_3v3d, i_5v=i_5v, i_3v3=i_3v3, i_3v3d=i_3v3d,
                t_rem=t_open_h,
                t_en=t_en, t_h_fall=T_H_FALL, t_off_min=t_off_min, t_618_max=t_618_max, t_617_max=t_617_max,
                vce_min=vce_min, i_plus=(ip_ok, ip_ok + i_h), i_minus=(in_ok, in_ok + i_h))


if __name__ == '__main__':
    main()
