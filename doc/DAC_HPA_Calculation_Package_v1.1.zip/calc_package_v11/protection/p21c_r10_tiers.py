#!/usr/bin/env python3
"""p21c_r10_tiers - R10 F-1 (c): firmware tiers T1/T2/T3 below the hardware floor, from ANY reachable state.  RELEASE calculation.
Self-contained (constants copied from p06 round-3 final, protection R3.17 / DZ-1; floor from p21_r10_f1).

Estimator (firmware, unchanged): per leg reading and per pair difference, CIC^2 = two cascaded running means of W over the
10 kHz readings, evaluated every 1 ms; action RELAY_EN low -> switch open <= 1.01 ms.  The CIC^2 is an FIR filter: its memory
is exactly 2 W; the DC-sense network (1 pole, tau <= 12.86 ms) adds an exponentially decaying memory.  Worst reachable
pre-fault states (decisions_r10 F-1 a): (i) CIC^2 output just inside the opposite threshold (sub-threshold DC of the other
sign, or a recent near-trip), with the network settled there; (ii) full-scale content >= 20 Hz up to the fault onset (worst
frequency and phase: the partially flushed window keeps an opposing residue); (iii) both combined.  Reading errors oppose the
new fault (gain 1 - 2.5 %, offset -e).  Energies = DC power x removal for every DC below the hardware floor.
"""
import numpy as np
import p21_r10_f1 as M
from pcommon import A_CAL_DRIFT

out = [__doc__]; P = out.append
FS = 10e3; DT = 1 / FS
TAU_MAX = 12.86e-3                      # p06: R_TH 2.486 k x 1.001 x 4.7 uF x 1.10
E_LEG, E_PAIR, EPS = 60.30e-3, 65.51e-3, 0.025
TIERS = [('T1', 0.100, 0.90, 0.90), ('T2', 0.300, 0.24, 0.23), ('T3', 1.200, 0.110, 0.120)]
T_ACT_FW = 1e-3 + 1.01e-3               # 1 ms evaluation period + RELAY_EN -> switch open
FLOOR_LEG, FLOOR_PAIR = M.REQ_FLOOR_LEG, M.REQ_FLOOR_PAIR      # requirement floor (p21 c2), above the leaky LPW level maximum


def cic2(x, W):
    k = int(round(W * FS)); c = np.cumsum(np.concatenate([[0.0], x]))
    m1 = (c[k:] - c[:-k]) / k
    m1 = np.concatenate([np.full(k - 1, m1[0]), m1])
    c2 = np.cumsum(np.concatenate([[0.0], m1]))
    m2 = (c2[k:] - c2[:-k]) / k
    return np.concatenate([np.full(k - 1, m2[0]), m2])


def net(u, tau, y0=None):
    """1-pole network, exact discrete recursion y[n] = a y[n-1] + (1-a) u[n], evaluated in blocks with cumulative sums"""
    a = np.exp(-DT / tau); y = np.empty_like(u); s = u[0] if y0 is None else y0; L = 2000
    for b0 in range(0, len(u), L):
        ub = u[b0:b0 + L]; n = np.arange(1, len(ub) + 1)
        w = a ** (-n)
        yb = a ** n * (s + (1 - a) * np.cumsum(ub * w))
        y[b0:b0 + L] = yb; s = yb[-1]
    return y


def responses(pre, W, tau=TAU_MAX):
    """linear decomposition: CIC^2(net(pre then 0)) and the unit step response of the post-fault value"""
    n_post = int((2 * W + 12 * tau + 0.05) * FS)
    u0 = np.concatenate([pre, np.zeros(n_post)])
    y0 = cic2(net(u0, tau), W)[len(pre):]
    u1 = np.concatenate([np.zeros(len(pre)), np.ones(n_post)])
    y1 = cic2(net(u1, tau, 0.0), W)[len(pre):]
    return y0[::10], y1[::10]


def trip_times(y0, y1, posts, thr):
    """vectorised over post-fault reading values"""
    Y = y0[None, :] + np.asarray(posts)[:, None] * y1[None, :]
    hit = Y >= thr
    idx = np.argmax(hit, axis=1)
    t = idx * 10 * DT + T_ACT_FW
    t[~hit[np.arange(len(posts)), idx]] = np.inf
    return t


P(f'\nHardware floor from p21: {FLOOR_LEG:.3f} V (leg) / {FLOOR_PAIR:.3f} V (pair).  Network tau max {TAU_MAX*1e3:.2f} ms.')
P('Pre-state (i) steady: reading at -threshold; (ii) FS content (leg 2.325 V, pair 4.65 V) 20-60 Hz, 8 phases; (iii) (i)+(ii) with the '
  'content scaled so the CIC^2 stays inside -threshold; (iv) (hand-over, indep-check) steady -s (0 / 0.5 / 0.999 thr), an optional '
  'LPW-limited excursion just inside the OR / E-3 levels (leg 1.95 V, pair 2.00 V) and a burst at -amplitude for 5 / 10 / 19.4 ms '
  '(< T_P min: no hardware trip), ending 0 / 0.1 W / 0.3 W before the onset; kept only if no negative tier trips during it.')


def reachable(pre, kind):
    L = int((2 * max(t[1] for t in TIERS) + 0.2) * FS)
    if len(pre) < L:                                   # extend the steady part so the longest window is defined
        pre = np.concatenate([np.full(L - len(pre), pre[0]), pre])
    for _n, _W, _tl, _tp in TIERS:
        if cic2(net(pre, TAU_MAX), _W).min() <= -(_tl if kind == 'leg' else _tp):
            return False
    return True
XS = np.linspace(0.05, 3.0, 2951)


def tier_levels(amp_leg, amp_pair, show=True):
  res = {}
  for name, W, thl, thp in TIERS:
    for kind, thr, e, amp in (('leg', thl, E_LEG, amp_leg), ('pair', thp, E_PAIR, amp_pair)):
        k = int(round(W * FS)); npre = int((2 * W + 12 * TAU_MAX) * FS)
        posts = XS * (1 - EPS) - e
        tworst = np.zeros(len(XS))
        y0, y1 = responses(np.full(npre, -thr * 0.999), W)
        tworst = np.maximum(tworst, trip_times(y0, y1, posts, thr))
        tt = np.arange(npre) * DT
        for f in (20.0, 25.0, 33.3, 40.0, 60.0):
            for ph in np.linspace(0, 2 * np.pi, 8, endpoint=False):
                c = amp * np.sin(2 * np.pi * f * (tt - tt[-1]) + ph)
                y0, y1 = responses(c, W)
                tworst = np.maximum(tworst, trip_times(y0, y1, posts, thr))
                cc = cic2(net(c, TAU_MAX), W)
                room = -thr * 0.999 - cc[-2 * k:].min()
                if room < 0:
                    y0, y1 = responses(c + room, W)
                    tworst = np.maximum(tworst, trip_times(y0, y1, posts, thr))
        exc = 1.95 if kind == 'leg' else 2.00
        for s_ in (0.0, 0.5, 0.999):
            for d in (0.005, 0.010, 0.0194):
                for ext in (0.0, 0.070 - d):
                    for g in (0.0, 0.1 * W, 0.3 * W):
                        pre = np.full(npre, -thr * s_)
                        nb, ng, ne = int(round(d * FS)), int(round(g * FS)), int(round(ext * FS))
                        end = npre - ng
                        pre[end - nb:end] = -amp
                        if ne:
                            pre[end - nb - ne:end - nb] = -min(amp, exc)
                        if not reachable(pre, kind):
                            continue
                        y0, y1 = responses(pre, W)
                        tworst = np.maximum(tworst, trip_times(y0, y1, posts, thr))
        dead_rest = {'T1': 0.208, 'T2': 0.574, 'T3': 2.246}[name]
        ok = np.nonzero(tworst <= dead_rest * 1.05)[0]
        vg = XS[ok[0]] if len(ok) else np.inf
        # must be monotone above vg
        if len(ok) and not np.all(tworst[ok[0]:] <= dead_rest * 1.05):
            vg = XS[np.nonzero(tworst > dead_rest * 1.05)[0][-1] + 1]
        res[(name, kind)] = (vg, dead_rest * 1.05, tworst)
        if show:
            P(f'  {name} {kind:4s}: over the swept histories removed <= {dead_rest*1.05*1e3:6.0f} ms for DC >= {vg:.3f} V '
              f'(rest-state p06: {dead_rest*1e3:.0f} ms for {"0.995/1.000" if name=="T1" else ("0.311/0.306" if name=="T2" else "0.176/0.192")} V)')
  return res


res = tier_levels(A_CAL_DRIFT, 2 * A_CAL_DRIFT)

P('\nEnergy below the hardware floor, firmware only, worst state (DC power x removal, removal = fastest tier that guarantees the level):')
for kind, floor, rls in (('leg (single leg, SE)', FLOOR_LEG, (16.0, 32.0)), ('pair (balanced +-x)', FLOOR_PAIR, (16.0, 32.0))):
    kk = 'leg' if kind.startswith('leg') else 'pair'
    for rl in rls:
        worst = (0, 0, 0)
        for v in np.linspace(0.20, floor, 60):
            ts = [res[(n, kk)][1] for n, _, _, _ in TIERS if v >= res[(n, kk)][0]]
            if not ts:
                continue
            t = min(ts); e_ = v * v / rl * t
            if e_ > worst[0]:
                worst = (e_, v, t)
        lim = 30e-3 if rl == 16.0 else 15e-3
        P(f'  {kind:22s} {rl:.0f} ohm: worst {worst[0]*1e3:5.1f} mJ at {worst[1]:.3f} V (removal {worst[2]*1e3:.0f} ms), limit '
          f'{lim*1e3:.0f} mJ, margin {100*(1-worst[0]/lim):.0f} %')
g3l, g3p = res[('T3', 'leg')][0], res[('T3', 'pair')][0]
P('  History set: FINITE (pre-states i-iv above), not a universal bound; a history outside it can delay a trip slightly (independent check: '
  '+9 ms at 0.176 V, +1 ms at T2) - the deadlines are stated for the swept set; the owner rule keeps a margin of > 0.6 s.')
P(f'  owner rule (DC >= 0.2 V removed within 3 s): T3 over the swept histories {g3l:.3f} V (leg) / {g3p:.3f} V (pair) within '
  f'{res[("T3","leg")][1]:.2f} s -> {"met" if max(g3l, g3p) <= 0.2 else "NOT met"}; below that the owner-accepted residual (< 0.2 V).')
# F-2 class variant: content pre-state bounded by the rails instead of the calibrated level (no calibration input, R-07)
rv = tier_levels(M.VPOS_MAX, M.VPOS_MAX + M.VNEG_MAX, show=False)
P(f'  Variant (evidence class, no calibration input): content pre-state bounded by the rails (leg {M.VPOS_MAX:.3f} V, pair '
  f'{M.VPOS_MAX + M.VNEG_MAX:.3f} V): ' + ', '.join(f'{n} >= {rv[(n, "leg")][0]:.3f} / {rv[(n, "pair")][0]:.3f} V' for n, _, _, _ in TIERS) +
  f' (same deadlines); owner rule {"met" if max(rv[("T3", "leg")][0], rv[("T3", "pair")][0]) <= 0.2 else "NOT met"}.')
ev = {}
for kk, floor in (('leg', FLOOR_LEG), ('pair', FLOOR_PAIR)):
    for rl in (16.0, 32.0):
        w_ = 0.0
        for v in np.linspace(0.20, floor, 60):
            ts = [rv[(n, kk)][1] for n, _, _, _ in TIERS if v >= rv[(n, kk)][0]]
            if ts:
                w_ = max(w_, v * v / rl * min(ts))
        ev[(kk, rl)] = w_
P(f'    variant energies below the floor: leg {ev[("leg", 16.0)]*1e3:.1f} / {ev[("leg", 32.0)]*1e3:.1f} mJ, pair {ev[("pair", 16.0)]*1e3:.1f} / '
  f'{ev[("pair", 32.0)]*1e3:.1f} mJ at 16 / 32 ohm (limits 30 / 15 mJ); residual below T3 <= {rv[("T3", "pair")][0]**2/16*1e3:.2f} mW into 16 ohm')
P('Conclusion: the firmware tiers need no change for history robustness (FIR memory 2 W; the worst history raises the guaranteed levels '
  'by a few mV only). The v1.0 statement that T1 is the backup of the leg windows is replaced: T1-T3 back up the LPW/OR/E-3 stages.')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
