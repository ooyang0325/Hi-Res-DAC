#!/usr/bin/env python3
"""p21_r10_f1 - R10 F-1 (decisions_r10 F-1 a/b/c/e, F-3 share): history-robust hardware DC protection.  RELEASE calculation.
Self-contained: reads only pcommon.py (RAIL_* sets, content levels, part data); numpy only.  Writes p21_r10_f1_out.txt.

(a) reachable pre-fault states, (b) hardware-only sweeps from ANY reachable state, starting just above every trip level,
with the real switch-opening delay, for the v1.0 design (reproducing both orchestrator counterexamples) and for the R10
design; (c) the R10 design numbers, floor, and firmware hand-over; (e) loads per rail and the new-part list.

R10 design (block 6), per leg xx in {LP, LN, RP, RN}:
  OR  (over-range) : LEG_xx -> 330 k -> N6_ORxx (1 nF C0G) -> two TLV1704 channels (fast: no release lag at square edges):
                     tap > V_OR+ and tap < V_OR-; U611 = L legs, U612 = R legs.
                     Open-drain outputs SINK the E-3 NPN-reset base of the "natural" pair direction (LP+ and LN- -> c+ base,
                     LP- and LN+ -> c- base), so the existing E-3 timer (T_P 19.5-23.4 ms) and its TLV1704 timer
                     comparator on N6_H do the persistence and the strong H pull.  V_OR+ = 3V3A x 470/(360+470),
                     V_OR- = VNEG x 470/(470+470) (divider returned to the OR test line, 0 V in normal operation).
  LPW (low-level persistence window, replaces the RC leg windows): LEG_xx -> 1.00 M -> N6_LWxx (3.3 nF C0G) -> per polarity
                     one TLV3402 = level channel (released while tap beyond V_LL, else it SINKS the timer node to VNEG)
                     + timer channel (timer node = level output, 910 k from VPOS, 100 nF C0G to GND; threshold GND;
                     sinks the E-3 base of the natural direction when the timer passes 0 V).
  Removed: U601/U602 leg windows (TLV1704) with R601-R604, C601-C604, R607-R610, R649-R652, C612-C615.
Labels: [DS] datasheet limit, [DS-typ] typical, [CALC] computed here, [ASSUMP] assumption, [E] estimate class.
"""
import numpy as np
from pcommon import (RAIL_REL, RAIL_FB, RAIL_DESIGN, V3A_RANGE, A_CAL, A_CAL_TRIM, A_CAL_DRIFT, A_DEF_MODEL,
                     A_DEF_BOUND, ISC_BOUND, HEADROOM_NOLOAD, ROUT_SWING)

out = [__doc__]
P = out.append

# ============================================================== part data
TOL01 = 0.001 + 25e-6 * 40          # 0.1 % thin film + 25 ppm/K x 40 K
TOL1 = 0.01 + 100e-6 * 40           # 1 % thick film + 100 ppm/K x 40 K
V17_OS, V17_IB, V17_TPD, V17_IQ = 5.5e-3, 20e-9, 5e-6, 100e-6      # TLV1704 [DS SBOS589D 7.6]; tpd bound [ASSUMP 10 x typ]
V34_OS, V34_IB, V34_ICC = 4.4e-3, 1.5e-9, 0.95e-6                 # TLV3402 full range [DS SBOS160 7.7]
V34_VOL50 = 0.30                                                  # V at 50 uA, full range [DS]
V34_TPD = 0.9e-3                                                  # [ASSUMP] 3 x the 300 us typical (2 mV overdrive), no max published
ICEX_3904 = 50e-9                                                 # MMBT3904 ICEX [DS]
T_OFF = 1.0e-3                                                    # TLP3545A tOFF design value 0-60 C [ASSUMP 2 x DS 25 C max]
VPOS_MIN, VPOS_MAX = RAIL_DESIGN['VPOS']
VNEG_MIN, VNEG_MAX = RAIL_DESIGN['VNEG']
T_HFALL = 1.0e-6 * 1.10 * (VPOS_MAX - 0.45) / 4e-3               # C617 1 uF +10 % from VPOS max to 0.45 V at >= 4 mA (p05 model)
T_ACT = V17_TPD + T_HFALL + T_OFF                                 # E-3 timer comparator -> H -> Q617 off -> photorelay open
A_PRE = A_CAL_DRIFT                                               # worst content excursion per leg (calibrated + G drift) [E, analog F-5]


def div(v, rtop, rbot, t):
    """divider output range for supply range v=(lo,hi), resistor tolerance t"""
    klo = rbot * (1 - t) / (rbot * (1 - t) + rtop * (1 + t))
    khi = rbot * (1 + t) / (rbot * (1 + t) + rtop * (1 - t))
    return v[0] * klo, v[1] * khi


# ============================================================== E-3 (unchanged hardware, re-evaluated with the design rails, v0 >= 0)
RA, RB = 487e3, 1.00e6
g = RB / (RA + RB); rth = RA * RB / (RA + RB)
err = (2 * V17_OS + 2 * V17_IB * rth) / g
VL = (VPOS_MIN * RA * (1 - TOL01) / (RB * (1 + TOL01)) - err, VPOS_MAX * RA * (1 + TOL01) / (RB * (1 - TOL01)) + err)
RT, CT, KT_TOP, KT_BOT = 110e3, 220e-9, 69.8e3, 100e3
kt = [KT_BOT * (1 - TOL01) / (KT_BOT * (1 - TOL01) + KT_TOP * (1 + TOL01)), KT_BOT * (1 + TOL01) / (KT_BOT * (1 + TOL01) + KT_TOP * (1 - TOL01))]
tp = []
for vp in (VPOS_MIN, VPOS_MAX):
    for k in kt:
        for c in (CT * 0.98 * 0.995, CT * 1.02 * 1.005):
            for r in (RT * (1 - TOL01), RT * (1 + TOL01)):
                for v0 in (0.0, 0.20):                 # timer start 0 ... 0.20 V: Q623-Q626 VCE(sat) at IC <= 40 uA, IB ~10 uA [ASSUMP, register A-46:
                                                       # no datasheet row at this point; Ebers-Moll <= ~0.11 V; see the sensitivity below]
                    for vos in (-V17_OS, V17_OS):
                        for il in (-V17_IB, V17_IB + 1e-6):   # E-24 leakage basis <= 1 uA per node [E]
                            vinf = vp - il * r
                            tp.append(r * c * np.log((vinf - v0) / (vinf - (k * vp + vos))))
TP = (min(tp), max(tp))
P('\n=== 0. Inputs')
P(f'Rails [pcommon RAIL_*]: VPOS released {RAIL_REL["VPOS"][0]:.3f}-{RAIL_REL["VPOS"][1]:.3f} V, R501 fallback '
  f'{RAIL_FB["VPOS"][0]:.3f}-{RAIL_FB["VPOS"][1]:.3f} V; |VNEG| {VNEG_MIN:.3f}-{VNEG_MAX:.3f} V; 3V3A {V3A_RANGE[0]}-{V3A_RANGE[1]} V. '
  f'Design envelope VPOS {VPOS_MIN:.3f}-{VPOS_MAX:.3f} V (every rail-dependent number below uses it).')
P(f'Content per leg [E, analog F-5]: calibrated {A_CAL} V, +0.15 dB {A_CAL_TRIM} V, with the G-bounded 3V3A drift {A_CAL_DRIFT} V '
  f'(= worst pre-fault excursion A_PRE); -4.5 dB uncalibrated default {A_DEF_MODEL} V (model) / {A_DEF_BOUND} V (3.66 V basis).')
P(f'Switch-opening allowance after an E-3 timer comparator switches: {T_ACT*1e3:.3f} ms (TLV1704 5 us + H fall {T_HFALL*1e3:.3f} ms '
  f'at VPOS {VPOS_MAX} V + tOFF 1.0 ms) [CALC/ASSUMP]; the E-2 latch path is faster and not credited.')
P(f'E-3 (unchanged): V_L = {VL[0]:.3f} ... {VL[1]:.3f} V on the pair difference; T_P = {TP[0]*1e3:.2f} ... {TP[1]*1e3:.2f} ms '
  f'(timer start 0 ... 0.20 V [ASSUMP A-46: reset VCE(sat) at IC <= 40 uA], <= 1 uA leakage [ASSUMP A-33]) [CALC]')

# ---- sensitivity (indep-check 26 Sep): E-3 reset level.  Q623-Q627 are now onsemi MMBT3904LT1G (C81464): VCE(sat) <= 0.2 V at
# 10 mA / 1 mA and <= 0.3 V at 50 mA / 5 mA [DS]; the JSCJ C20526 used before gave only the 0.30 V row.  Operating point:
# IC ~35 uA (R_T 110 k), IB ~10 uA (R916-R919 330 k), forced beta ~3.5 -> Ebers-Moll <= ~0.11 V (beta_R >= 0.1) [E].
def _tp_min(v0):
    r, c = RT * (1 - TOL01), CT * 0.98 * 0.995
    vp = VPOS_MIN; vinf = vp + V17_IB * r
    return r * c * np.log((vinf - v0) / (vinf - (kt[0] * vp - V17_OS)))
_f20 = 20.0 * (1 - 1e-4)
def _t_above(a):
    return (np.pi - 2 * np.arcsin(min(1.0, VL[0] / (2 * a)))) / (2 * np.pi * _f20)
_tp3 = _tp_min(0.30)
P(f'  Sensitivity, E-3 reset level: with VCE(sat) <= 0.30 V (the 50 mA / 5 mA row) T_P min = {_tp3*1e3:.2f} ms '
  f'(0.20 V: {_tp_min(0.20)*1e3:.2f} ms) -> 20 Hz sine margins ' +
  ' / '.join(f'{100*(1-_t_above(a)/_tp3):.1f} %' for a in (A_CAL, A_CAL_TRIM, A_CAL_DRIFT)) +
  f' at {A_CAL} / {A_CAL_TRIM} / {A_CAL_DRIFT} V, ' + ' / '.join(f'{100*(1-_t_above(a)/_tp3):.1f} %' for a in (A_DEF_MODEL, A_DEF_BOUND)) +
  f' at the -4.5 dB default; FS squares may mute up to {1/(2*_tp3):.1f} Hz. The design value 0.20 V (T_P min {TP[0]*1e3:.2f} ms) is the 10 mA / 1 mA '
  f'row of the fitted onsemi MMBT3904LT1G (C81464), extended to IC ~35 uA at forced beta ~3.5 [ASSUMP A-46; Ebers-Moll <= ~0.11 V] (class E).')

# ============================================================== (a) reachable pre-fault states
P('\n=== (a) Reachable pre-fault states (decisions_r10 F-1 a) used as sweep starting points')
P('  * v1.0 leg-window filter node: anywhere strictly inside its trip levels, either polarity (sub-threshold DC, content, near-trips):')
P('    worst start for a positive fault = -0.320 V (the highest negative trip), and symmetric.')
P(f'  * R10 prefilter taps (tau 0.33 / 3.3 ms): anywhere inside the content range, worst start -A_PRE = -{A_PRE} V for a positive fault;')
P('    a sustained DC beyond +-V_LL is not a stable state (the LPW stage removes it), so no worse start exists.')
P('  * LPW timer: anywhere from VNEG + VOL (full reset) to just below 0 V; worst = full reset at VNEG_MAX with VOL 0.')
P('  * E-3 timer: anywhere 0 V ... V_T (incomplete reset included); worst = 0 V (bound added in R10; p18 used 0.02 V).')
P('  * CM-window node (tau 0.55 ms): anywhere inside its window; worst start at the opposite threshold adds <= 0.16 ms '
  '(inside the 3 tau of p04 T_CM_FIX) -> CM results unchanged.')
P('  * Firmware CIC^2 windows and DC-sense networks: see p21c_r10_tiers.py (FIR estimator, memory <= 2 W).')
P('  * Partner-leg content during a single-leg fault: any content up to A_PRE, any frequency, phase, burst or reversal '
  '(E-3 is therefore not credited for single-leg faults).')

# ============================================================== (b) v1.0 design from reachable states (reproduces facts 2 and 3)
R1, C1 = 115e3, 2.2e-6
TAU_LW = (R1 * (1 - TOL1) * 1.79e-6, R1 * (1 + TOL1) * 2.42e-6)      # p03 aged-C corners
def lw_trip(vr, rtop, rbot):                                           # p03 threshold model with the design rails
    node = 2 * V17_IB * R1 + V17_IB * 100e3
    rthd = rtop * rbot / (rtop + rbot)
    lo, hi = div(vr, rtop, rbot, TOL01)
    return lo - V17_OS - node - 4 * V17_IB * rthd, hi + V17_OS + node + 4 * V17_IB * rthd
LWP = lw_trip(RAIL_DESIGN['VPOS'], 121e3, 10e3)
LWN = lw_trip(RAIL_DESIGN['VNEG'], 115e3, 10e3)
LW_MAX = max(LWP[1], LWN[1])
T_LW_EXTRA = 0.98e-3 + T_OFF
def t_lw(x, v0, vt=None):
    vt = LW_MAX if vt is None else vt
    return TAU_LW[1] * np.log((x - v0) / (x - vt)) + T_LW_EXTRA if x > vt else np.inf


def leg_max(x, r_leg, rail):
    v_sw = (rail - HEADROOM_NOLOAD) / (1.0 + ROUT_SWING / r_leg)     # typical swing model (p03/p18) [E]
    return min(x, v_sw, ISC_BOUND * r_leg)


P('\n=== (b1) v1.0 design (leg windows + E-3), hardware only, from reachable states')
P(f'  leg windows: tau {TAU_LW[0]*1e3:.1f}-{TAU_LW[1]*1e3:.1f} ms, trip +{LWP[0]:.3f}...+{LWP[1]:.3f} / -{LWN[0]:.3f}...-{LWN[1]:.3f} V '
  f'(design rails), + {T_LW_EXTRA*1e3:.2f} ms H/switch')
P('  Fact 2 reproduction (orchestrator simplified model: tau 282.2 ms, trip 0.320 V, 1.98 ms):')
tau_o = 282.2e-3
def t_o(x, v0):
    return tau_o * np.log((x - v0) / (x - 0.320)) + 1.98e-3
for lab, v0 in (('after one 20 Hz negative half-cycle 1.5 V pk (filter -81 mV)', -0.081), ('pre-charged to -0.320 V', -0.320)):
    t = t_o(0.97, v0)
    P(f'    x = 0.97 V/leg {lab:58s}: {t*1e3:6.1f} ms -> 16 ohm bal {(1.94**2)/16*t*1e3:5.1f} mJ, 32 ohm bal {(1.94**2)/32*t*1e3:5.1f} mJ')
for k in (1.005, 1.01):
    x = k * 0.320; t = t_o(x, 0.0)
    P(f'    from rest, x = {k} x trip: {t*1e3:7.1f} ms -> 16 ohm bal {(2*x)**2/16*t*1e3:5.1f} mJ')
P('  Fact 3 reproduction (single leg at the rail, partner FS content >= 50 Hz resets E-3 every cycle; leg windows only):')
for vr in (RAIL_REL['VPOS'][0], RAIL_REL['VPOS'][1], RAIL_FB['VPOS'][1]):
    for v0, lab in ((0.0, 'rest'), (-0.081, '20 Hz half-cycle'), (-0.320, 'pre-charged -0.32 V')):
        t = t_o(vr, v0)
        P(f'    stuck {vr:.3f} V, {lab:20s}: {t*1e3:5.1f} ms -> 16 ohm SE {vr**2/16*t*1e3:5.1f} mJ, 32 ohm SE {vr**2/32*t*1e3:5.1f} mJ')
# worst sweeps of the v1.0 design with the package model (design rails)
def old_bal(x, rl):
    xl = leg_max(x, rl / 2, VPOS_MAX)
    t = t_lw(xl, -LW_MAX)
    if 2 * xl > VL[1]:
        t = min(t, TP[1] + T_ACT)
    return (2 * xl) ** 2 / rl * t, xl, t
P('  v1.0 package model from the worst state (filters at the opposite trip), sweep from just above the leg-window trip:')
for rl, lim in ((16.0, 30e-3), (32.0, 15e-3)):
    xs = np.concatenate([LW_MAX * (1 + np.logspace(-6, -1, 40)), np.linspace(LW_MAX * 1.1, 3.0, 800)])
    w = max((old_bal(x, rl) for x in xs), key=lambda r: r[0])
    P(f'    balanced {rl:.0f} ohm: worst {w[0]*1e3:7.1f} mJ at {w[1]:.3f} V/leg ({w[2]*1e3:.0f} ms) vs {lim*1e3:.0f} mJ '
      f'-> {"FAIL" if w[0] > lim else "ok"}   (from rest just above the trip the energy diverges logarithmically)')

# ============================================================== (c) R10 design numbers
P('\n=== (c1) R10 design: stage thresholds and timers [CALC]')
# OR references
vorp = div(V3A_RANGE, 360e3, 470e3, TOL1)
R_ORT = 330e3                    # OR tap resistor (TLV1704 IB x R_ORT enters the threshold)
e_orp_lo = V17_OS + 4 * V17_IB * (360e3 * 470e3 / 830e3) + 2 * V17_IB * R_ORT + ICEX_3904 * (360e3 * 470e3 / 830e3)
e_orp_hi = V17_OS + 4 * V17_IB * (360e3 * 470e3 / 830e3) + 2 * V17_IB * R_ORT
VORP = (vorp[0] - e_orp_lo, vorp[1] + e_orp_hi)
vorn = div(RAIL_DESIGN['VNEG'], 470e3, 470e3, TOL1)
e_orn = V17_OS + 4 * V17_IB * 235e3 + 2 * V17_IB * R_ORT + 0.5 * 0.010     # + test-line low level <= 10 mV at <= 5 uA [ASSUMP]
VORN = (vorn[0] - e_orn, vorn[1] + e_orn)
vllp = div(V3A_RANGE, 1.00e6, 100e3, TOL1)
e_ll = V34_OS + 4 * V34_IB * 91e3 + 2 * V34_IB * 1e6
VLLP = (vllp[0] - e_ll, vllp[1] + e_ll)
vlln = div(RAIL_DESIGN['VNEG'], 1.00e6, 88.7e3, TOL1)
VLLN = (vlln[0] - e_ll, vlln[1] + e_ll)
VOR_MAX = max(VORP[1], VORN[1]); VOR_MIN = min(VORP[0], VORN[0])
VLL_MAX = max(VLLP[1], VLLN[1]); VLL_MIN = min(VLLP[0], VLLN[0])
TAU_OR = (R_ORT * (1 - TOL1) * 1e-9 * 0.95, R_ORT * (1 + TOL1) * 1e-9 * 1.05)
TAU_LP = (1e6 * (1 - TOL1) * 3.3e-9 * 0.95, 1e6 * (1 + TOL1) * 3.3e-9 * 1.05)
# LPW timer: T0 = VNEG + VOL -> charge toward VPOS through R_T2; threshold 0 V +- VOS; leakage <= 0.1 uA [E]
RT2, CT2 = 910e3, 100e-9     # R10: 910 k + C0G so that a polarity reversal of FS content >= 20 Hz (a 50 ms lobe) never trips (p21b)
CT2_LO, CT2_HI = 0.948, 1.052     # C0G 0805 50 V: +-5 % tol, +-30 ppm/K x 40 K, no DC-bias or ageing loss [DS class 1]
I_LK2 = 0.1e-6
tp2 = []
for vp in (VPOS_MIN, VPOS_MAX):
    for vn in (VNEG_MIN, VNEG_MAX):
        for vol in (0.0, V34_VOL50):
            for r in (RT2 * (1 - TOL1), RT2 * (1 + TOL1)):
                for c in (CT2 * CT2_LO, CT2 * CT2_HI):
                    for vos in (-V34_OS, V34_OS):
                        for il in (-V34_IB, I_LK2):
                            vinf = vp - il * r
                            t0 = -vn + vol
                            tp2.append(r * c * np.log((vinf - t0) / (vinf - vos)))
TP2 = (min(tp2), max(tp2))
i_rst = (VPOS_MAX + VNEG_MAX) / (RT2 * (1 - TOL1))
t_rst = CT2 * CT2_HI * (VNEG_MAX + 0.0) / (50e-6 - i_rst)
P(f'  OR thresholds: V_OR+ = 3V3A x 470/(360+470) = {VORP[0]:.3f} ... {VORP[1]:.3f} V; V_OR- = -{VORN[0]:.3f} ... -{VORN[1]:.3f} V '
  f'(1 % R, TLV1704 VOS/IB incl. IB x 330 k tap, Q627 ICEX); taps tau {TAU_OR[0]*1e3:.3f}-{TAU_OR[1]*1e3:.3f} ms')
P(f'  LPW thresholds: V_LL+ = 3V3A x 100/1100 = {VLLP[0]:.3f} ... {VLLP[1]:.3f} V; V_LL- = -{VLLN[0]:.3f} ... -{VLLN[1]:.3f} V '
  f'(VNEG x 88.7/1088.7); taps tau {TAU_LP[0]*1e3:.2f}-{TAU_LP[1]*1e3:.2f} ms')
P(f'  LPW timer (910 k 1 %, 100 nF C0G x {CT2_LO}-{CT2_HI}, start VNEG+VOL, threshold 0 V): T_P2 = {TP2[0]*1e3:.1f} ... {TP2[1]*1e3:.1f} ms; '
  f'reset: level output sinks <= {i_rst*1e6:.1f} uA from R_T2 (VOL spec at 50 uA holds), full reset of C_T2 <= {t_rst*1e3:.1f} ms')
P(f'  -> combined LPW + E-3 persistence before any trip: {(TP2[0]+TP[0])*1e3:.1f} ... {(TP2[1]+TP[1])*1e3:.1f} ms '
  f'(content has to hold a leg beyond +-V_LL that long)')
P(f'  Transparency of OR to balanced content: V_OR min {VOR_MIN:.3f} V > V_L max / 2 = {VL[1]/2:.3f} V (ratio {VOR_MIN/(VL[1]/2):.2f}) '
  '-> for balanced content an OR condition implies the E-3 level condition of the same timer (no new run time).')
P(f'  OR uses the fast TLV1704 (<= 5 us): its release at a square edge adds no run time (a TLV3402 would add up to 0.9 ms and move the '
  'FS-square boundary from 25.6 to 26.8 Hz, p21b). HF content vs the slow TLV3402 of the LPW stage: LPW taps pass content '
  f'above V_LL min only below {1/(2*np.pi*TAU_LP[0])*np.sqrt((A_PRE/VLL_MIN)**2-1):.0f} Hz (half period >= '
  f'{0.5/(1/(2*np.pi*TAU_LP[0])*np.sqrt((A_PRE/VLL_MIN)**2-1))*1e3:.2f} ms)')


def t_or(x, vt):
    """OR path from the worst state: tap from -A_PRE to vt, comparator, E-3 timer, H/switch."""
    return TAU_OR[1] * np.log((x + A_PRE) / (x - vt)) + V17_TPD + TP[1] + T_ACT if x > vt else np.inf


def t_lpw(x, vt):
    return TAU_LP[1] * np.log((x + A_PRE) / (x - vt)) + V34_TPD + TP2[1] + V34_TPD + TP[1] + T_ACT if x > vt else np.inf


def t_single(x, pol):
    vor = VORP[1] if pol > 0 else VORN[1]
    vll = VLLP[1] if pol > 0 else VLLN[1]
    return min(t_or(x, vor), t_lpw(x, vll))


def t_bal(x):
    tt = min(t_or(x, VOR_MAX), t_lpw(x, VLL_MAX))
    if 2 * x > VL[1]:
        tt = min(tt, TP[1] + T_ACT)
    return tt


P('\n=== (b2) R10 design, hardware only, from the worst reachable state; sweeps start just above every trip level')
res = {}
for rl, lim in ((16.0, 30e-3), (32.0, 15e-3)):
    xs = np.unique(np.concatenate([VLL_MAX * (1 + np.logspace(-9, -0.5, 60)), np.linspace(VLL_MAX * 1.2, 3.2, 2000),
                                   VL[1] / 2 * (1 + np.logspace(-6, -1, 20)), VL[1] / 2 * (1 - np.logspace(-6, -1, 20)),
                                   VOR_MAX * (1 + np.logspace(-6, -1, 20)), VOR_MAX * (1 - np.logspace(-6, -1, 20))]))
    wb = (0, 0, 0)
    for x in xs:
        xl = leg_max(x, rl / 2, VPOS_MAX)
        if xl <= VLL_MAX:
            continue
        t = t_bal(xl); e = (2 * xl) ** 2 / rl * t
        if e > wb[0]:
            wb = (e, xl, t)
    res[('bal', rl)] = wb
    P(f'  balanced +-x {rl:.0f} ohm (every x from {VLL_MAX*(1+1e-9):.4f} V/leg up to the swing limit {leg_max(9, rl/2, VPOS_MAX):.3f} V): '
      f'worst {wb[0]*1e3:5.2f} mJ at {wb[1]:.3f} V/leg, removal {wb[2]*1e3:.1f} ms -> limit {lim*1e3:.0f} mJ, margin {100*(1-wb[0]/lim):.1f} %')
    for pol, rng in ((1, (VPOS_MIN, VPOS_MAX)), (-1, (VNEG_MIN, VNEG_MAX))):
        ws = (0, 0, 0)
        vll = VLLP[1] if pol > 0 else VLLN[1]
        for x in np.unique(np.concatenate([vll * (1 + np.logspace(-9, -0.5, 60)), np.linspace(vll * 1.2, rng[1], 3000)])):
            t = t_single(x, pol); e = x * x / rl * t
            if e > ws[0]:
                ws = (e, x, t)
        res[('se', rl, pol)] = ws
        P(f'  single leg {"+" if pol>0 else "-"} (SE load, any partner content; every x from just above V_LL to the rail {rng[1]:.3f} V) '
          f'{rl:.0f} ohm: worst {ws[0]*1e3:5.2f} mJ at {ws[1]:.3f} V ({ws[2]*1e3:.1f} ms), margin {100*(1-ws[0]/lim):.1f} %')
    for lab, vr, pol in (('VPOS released max', RAIL_REL['VPOS'][1], 1), ('VPOS R501 fallback max', RAIL_FB['VPOS'][1], 1),
                         ('VPOS released min', RAIL_REL['VPOS'][0], 1), ('VNEG max', VNEG_MAX, -1), ('VNEG min', VNEG_MIN, -1)):
        t = t_single(vr, pol)
        vd_bal = min(vr, ISC_BOUND * rl)
        P(f'    rail-stuck {lab:24s} {vr:.3f} V: removal {t*1e3:5.2f} ms -> SE {vr*vr/rl*t*1e3:5.2f} mJ, balanced one-leg-stuck '
          f'{vd_bal*vd_bal/rl*t*1e3:5.2f} mJ (limit {lim*1e3:.0f})')
P('  Near-threshold behaviour: the LPW removal time grows only through the 3.3 ms prefilter (logarithmic); at x = V_LL(1+1e-9)')
x = VLL_MAX * (1 + 1e-9)
P(f'    removal {t_lpw(x, VLL_MAX)*1e3:.1f} ms -> balanced 16 ohm {(2*x)**2/16*t_lpw(x, VLL_MAX)*1e3:.2f} mJ: bounded; below V_LL max = floor.')
P('  Time requirement (single leg, any partner content, worst state):')
for x, lim in ((1.0, 0.250), (2.0, 0.100)):
    for pol in (1, -1):
        t = t_single(x, pol)
        P(f'    DC {"+" if pol>0 else "-"}{x:.1f} V: removed <= {t*1e3:6.1f} ms (limit {lim*1e3:.0f} ms, margin {100*(1-t/lim):.0f} %)')
P('  Counterexamples of decisions_r10 under the R10 design (worst state, hardware only):')
for x in (0.97, 0.99):
    t = t_bal(x)
    P(f'    fact 2: balanced +-{x:.2f} V/leg after any history: {t*1e3:5.1f} ms -> 16 ohm {(2*x)**2/16*t*1e3:5.2f} mJ, 32 ohm {(2*x)**2/32*t*1e3:5.2f} mJ '
      f'(was 32.4-46 mJ / 16.2-23 mJ)')
for vr in (3.789, 3.915, 4.049):
    t = t_single(vr, 1)
    P(f'    fact 3: stuck {vr:.3f} V, partner FS content >= 50 Hz, any filter history: {t*1e3:5.2f} ms -> 16 ohm SE {vr*vr/16*t*1e3:5.2f} mJ, '
      f'32 ohm SE {vr*vr/32*t*1e3:5.2f} mJ (was 44.6-46.2 / 22.3-23.1 mJ)')
xr = leg_max(9, 16, RAIL_REL['VPOS'][1])
P(f'  32 ohm balanced at the RELEASED swing limit ({xr:.3f} V/leg, VPOS {RAIL_REL["VPOS"][1]} V): {(2*xr)**2/32*(TP[1]+T_ACT)*1e3:.2f} mJ '
  f'(margin {100*(1-(2*xr)**2/32*(TP[1]+T_ACT)/15e-3):.1f} %); the 0.8 % case above needs the R501 fallback fitted.')
x = 2.230
P(f'  Information (not the decided sweep, class E issue): without the typical-swing credit a frozen full-scale code '
  f'({x} V/leg, 32 ohm balanced) would give {(2*x)**2/32*(TP[1]+T_ACT)*1e3:.1f} mJ through E-3 (unchanged by R10; the swing model caps it at '
  f'{leg_max(9, 16, VPOS_MAX):.3f} V/leg). Physics: a frozen FS code equals half a FS 20 Hz square for 25 ms.')

# ============================================================== (b3) variant without the calibrated content level (F-2 class)
P('\n=== (b3) Variant for the evidence class: pre-fault taps bounded by the rail (A_PRE = VPOS max) instead of the calibrated content')
P('  level, so these rows need no calibration input (R-07); every other input as in (b2)')
_a_pre = A_PRE
A_PRE = VPOS_MAX
for x, lim in ((2.0, 0.100), (1.0, 0.250)):
    t = max(t_single(x, 1), t_single(x, -1))
    P(f'    DC +-{x:.1f} V removed <= {t*1e3:6.1f} ms (limit {lim*1e3:.0f} ms)')
for vr in (RAIL_REL['VPOS'][1], RAIL_FB['VPOS'][1]):
    t = t_single(vr, 1)
    P(f'    rail-stuck {vr:.3f} V: removal {t*1e3:5.2f} ms -> SE 16 ohm {vr*vr/16*t*1e3:5.2f} mJ, 32 ohm {vr*vr/32*t*1e3:5.2f} mJ')
wb3 = (0, 0, 0)
for x in np.unique(np.concatenate([VLL_MAX * (1 + np.logspace(-9, -0.5, 60)), np.linspace(VLL_MAX * 1.2, 3.2, 2000),
                                   VL[1] / 2 * (1 + np.logspace(-6, -1, 20)), VL[1] / 2 * (1 - np.logspace(-6, -1, 20))])):
    xl = leg_max(x, 8.0, VPOS_MAX)
    if xl > VLL_MAX:
        t = t_bal(xl); e = (2 * xl) ** 2 / 16 * t
        if e > wb3[0]:
            wb3 = (e, xl, t)
P(f'    balanced 16 ohm worst {wb3[0]*1e3:5.2f} mJ at {wb3[1]:.3f} V/leg ({wb3[2]*1e3:.1f} ms); 32 ohm balanced unchanged (E-3 path, no tap)')
A_PRE = _a_pre

# ============================================================== floor and hand-over to the firmware
# R10 hand-over (indep-check 26 Sep): the requirement floor must lie ABOVE the highest possible LPW level with an explicit clearance
# (a floor equal to the comparator maximum has a logarithmically unbounded delay just above it, and rounding 0.3240127 V down to
# 0.324 V would include a case that never trips).  The floor also covers the tap surface-leakage allowance.
I_SURF = 10e-9          # [ASSUMP] tap-node surface leakage allowance (parts stress THIN row, cleaned board); enters through the 1.00 M tap
VLL_MAX_LK = VLL_MAX + I_SURF * 1e6
REQ_FLOOR_LEG, REQ_FLOOR_PAIR = 0.34, 0.68        # requirement floor (Spec v1.1 wording), class E
assert REQ_FLOOR_LEG >= VLL_MAX_LK + 1e-3 and REQ_FLOOR_PAIR >= 2 * VLL_MAX_LK + 2e-3
P('\n=== (c2) Level floor (stated in the requirement) and firmware hand-over')
P(f'  LPW level maximum {VLL_MAX:.5f} V per leg / {2*VLL_MAX:.5f} V pair (IIB only); with {I_SURF*1e9:.0f} nA surface leakage on the 1.00 M tap '
  f'{VLL_MAX_LK:.5f} / {2*VLL_MAX_LK:.5f} V (level range {VLL_MIN-I_SURF*1e6:.3f} ... {VLL_MAX_LK:.3f} V; OR taps {I_SURF*330e3*1e3:.1f} mV).')
P(f'  Requirement floor (rounded UP with clearance, class E): hardware-only guarantees for |leg DC| >= {REQ_FLOOR_LEG:.2f} V and '
  f'|pair| >= {REQ_FLOOR_PAIR:.2f} V (clearance {1e3*(REQ_FLOOR_LEG-VLL_MAX_LK):.1f} mV over the leaky level maximum).')
_ap = A_PRE; A_PRE = VPOS_MAX                        # rail-bounded tap start (b3) for the at-floor bound
t_fl = t_lpw(REQ_FLOOR_LEG, VLL_MAX_LK)
A_PRE = _ap
P(f'  Bounded delay AT the floor (rail-bounded start, leaky level): {t_fl*1e3:.1f} ms -> balanced 16 / 32 ohm {REQ_FLOOR_PAIR**2/16*t_fl*1e3:.2f} / '
  f'{REQ_FLOOR_PAIR**2/32*t_fl*1e3:.2f} mJ, SE 16 ohm {REQ_FLOOR_LEG**2/16*t_fl*1e3:.2f} mJ; every level above the floor is faster, and the worst '
  f'energies above it are those of (b2)/(b3) (at 1.008 V/leg and at the rail).')
P('  Below the floor: firmware tiers T2/T3 (p21c_r10_tiers.py, FIR estimator; deadlines over the swept, finite history set of p21c):')
for rl in (16.0, 32.0):
    P(f'    pair just below the floor {REQ_FLOOR_PAIR:.2f} V, T2 <= 0.603 s: {REQ_FLOOR_PAIR**2/rl*0.603*1e3:.1f} mJ at {rl:.0f} ohm; single leg '
      f'just below T2 (0.311 V), T3 <= 2.358 s: {0.311**2/rl*2.358*1e3:.1f} mJ (limits 30/15 mJ)')

# ============================================================== (e) loads per rail
P('\n=== (e1) Loads per rail (maxima) [CALC]')
n34 = 16
i_ic = n34 * V34_ICC + 8 * V17_IQ              # 16 TLV3402 (LPW) + 8 TLV1704 (OR) channels
i_tim = 8 * (VPOS_MAX + VNEG_MAX) / (RT2 * (1 - TOL1))
i_vorn = VNEG_MAX / (940e3 * (1 - TOL1)); i_vlln = VNEG_MAX / (1088.7e3 * (1 - TOL1))
i_vorp = V3A_RANGE[1] / (830e3 * (1 - TOL1)); i_vllp = V3A_RANGE[1] / (1100e3 * (1 - TOL1))
rem_ic = 8 * V17_IQ
rem_dp = VPOS_MAX / (131e3 * (1 - TOL01)); rem_dn = VNEG_MAX / (125e3 * (1 - TOL01))
dIp = i_ic + i_tim - rem_ic - rem_dp
dIn = i_ic + i_tim + i_vorn + i_vlln - rem_ic - rem_dn
P(f'  added: 16 TLV3402 + 8 TLV1704 channels {i_ic*1e6:.1f} uA (VPOS->VNEG); 8 LPW timers held in reset {i_tim*1e6:.1f} uA (VPOS->VNEG); '
  f'V_OR- divider {i_vorn*1e6:.1f} uA and V_LL- divider {i_vlln*1e6:.1f} uA (GND->VNEG); 3V3A dividers {(i_vorp+i_vllp)*1e6:.1f} uA')
P(f'  removed: U601/U602 8 x 100 uA (VPOS->VNEG), VTH dividers {rem_dp*1e6:.1f} uA (VPOS) / {rem_dn*1e6:.1f} uA (VNEG)')
P(f'  net: VPOS {dIp*1e3:+.3f} mA, VNEG {dIn*1e3:+.3f} mA, 3V3A {(i_vorp+i_vllp)*1e3:+.4f} mA; at 5V_ANA ~ I+ + 1.03 I- = '
  f'{(dIp + 1.03*dIn)*1e3:+.2f} mA (the net at 5V_ANA is inside the conservative block-6 budget bound 2.738 / 2.566 mA; released Default need '
  f'178.961 mA, margin +1.090 mA - power/analog R10 final); '
  'test line: pin at 0 V sources <= 4 uA into the V_OR- divider (GND current, no 3V3 load)')
P(f'  block 6 totals (R9 check 2.66 / 2.48 mA): I+ <= {2.66 + dIp*1e3:.2f} mA, I- <= {2.48 + dIn*1e3:.2f} mA')

# ============================================================== v1.0 comparison for the reversal waveform of p21b (d2)
dt_ = 20e-6; t_ = np.arange(0, 0.6, dt_); f_ = 20.0 * (1 - 1e-4)
s3 = A_PRE * np.sin(2 * np.pi * f_ * t_) * (t_ < 0.1) - A_PRE * np.sin(2 * np.pi * f_ * (t_ - 0.1)) * (t_ >= 0.1)
a_ = np.exp(-dt_ / TAU_LW[0]); y_ = 0.0; ymax = 0.0
for v in s3:
    y_ = v + (y_ - v) * a_; ymax = max(ymax, abs(y_))
P(f'\n=== v1.0 comparison: FS 20 Hz sine with a polarity reversal at a zero crossing (two same-sign half-cycles, p21b d2): the old RC '
  f'leg-window node reaches {ymax:.3f} V at the fastest corner vs the lowest trip {min(LWP[0], LWN[0]):.3f} V -> the v1.0 windows '
  f'{"also muted it" if ymax >= min(LWP[0], LWN[0]) else "did not mute it"}')

# ============================================================== F-4 latch condition with the design rails
P('\n=== F-4 E-2 latch condition (implemented timing, p18 model with the design rails)')
for lab, vp in (('released', RAIL_REL['VPOS']), ('R501 fallback', (RAIL_REL['VPOS'][0], RAIL_FB['VPOS'][1]))):
    href = (vp[0] * 330e3 * 0.986 / (330e3 * 0.986 + 100e3 * 1.014) - V17_OS, vp[1] * 330e3 * 1.014 / (330e3 * 1.014 + 100e3 * 0.986) + V17_OS)
    t_clr = (vp[1] - href[0]) * 1.1e-6 / 4e-3 + 330e3 * 60e-12 * 3 + 1e3 * 1e-9 * 3
    P(f'  {lab:14s}: HREF {href[0]:.3f} ... {href[1]:.3f} V; any trip that pulls N6_H below HREF clears ARM <= {t_clr*1e3:.3f} ms after the comparator '
      f'switches (H from {vp[1]:.3f} V to HREF at >= 4 mA into 1.1 uF + 330 k x 60 pF + 1 k x 1 nF); an H dip that stays above HREF does not '
      f'clear the latch and cannot open the switch (Q617 gate >= {href[0]:.2f} V > 2.5 V RDS(on) point)')

# ============================================================== summary for the report
P('\n=== Summary')
P(f'  worst energies from any reachable state: balanced 16 ohm {res[("bal",16.0)][0]*1e3:.1f} mJ, 32 ohm {res[("bal",32.0)][0]*1e3:.1f} mJ; '
  f'single leg / rail-stuck SE 16 ohm {max(res[("se",16.0,1)][0],res[("se",16.0,-1)][0])*1e3:.1f} mJ, 32 ohm '
  f'{max(res[("se",32.0,1)][0],res[("se",32.0,-1)][0])*1e3:.1f} mJ; requirement floor {REQ_FLOOR_LEG:.3f} V per leg / {REQ_FLOOR_PAIR:.3f} V pair '
  f'(LPW level max {VLL_MAX:.5f} V, {VLL_MAX_LK:.5f} V with 10 nA)')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
