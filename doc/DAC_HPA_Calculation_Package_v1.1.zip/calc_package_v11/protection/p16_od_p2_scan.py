#!/usr/bin/env python3
"""p16 - OD-1: scan of the CIC^2 path (P2) window W and threshold TH so that the digital-DC envelope (DC d + worst 20 Hz
content c = 1 - d) meets 15/30 mJ with margin, while full-scale sines >= 20 Hz and full-scale squares above the P1 mute
limit (22.7 Hz) never trigger P2.  numpy only; worst residual over frequency/phase with onset (as p07)."""
import numpy as np
import p15_od_guard as p15          # re-uses power(), hardware and tier models (runs p15 once)
FS = 12000.0                         # decimated evaluation rate (CIC^2 of 50 ms windows is insensitive to it)


def cic2(x, n):
    c1 = np.convolve(x, np.ones(n) / n)[:len(x)]
    return np.convolve(c1, np.ones(n) / n)[:len(x)]


def worst(W, kind, fmin, fmax=200.0):
    n = int(round(FS * W)); w = 0.0; fw = 0
    for f in np.concatenate([np.linspace(fmin, 40.0, 41), np.geomspace(40.0, fmax, 12)]):
        t = np.arange(int(FS * (3 * W + 3 / f))) / FS
        for ph in np.linspace(0, np.pi if kind == 'sine' else 2 * np.pi, 16, endpoint=False):
            s = np.sin(2 * np.pi * f * t + ph)
            x = s if kind == 'sine' else np.sign(s + 1e-12)
            d = np.max(np.abs(cic2(x, n)))
            if d > w:
                w, fw = d, f
    return w, fw


out = [__doc__]
res = []
for W in (0.050, 0.045, 0.040):
    rs, fs_ = worst(W, 'sine', 20.0 * (1 - 1e-4))
    rq, fq = worst(W, 'square', 1 / (2 * p15.T_P) + 0.05)
    for TH in (0.30, 0.25, 0.22, 0.20):
        p15.W, p15.TH = W, TH
        worst_e = {}
        for (rl, bal) in ((32.0, True), (16.0, True)):
            m = (0.0, 0.0)
            for d in np.linspace(0.05, 1.0, 191):
                if 2 * d * p15.FS_LEG < 0.192:
                    continue
                c = 1 - d
                if d - c >= p15.L:
                    tg = p15.T_P + p15.T_DEC + p15.T_ACT
                else:
                    need = (TH + rs * c) / d
                    if need >= 1:
                        tg = np.inf
                    else:
                        tt = np.linspace(0, 2 * W, 20001)
                        tg = float(tt[np.argmax(p15.cic2_step(tt) >= need)]) + p15.T_DEC + p15.T_ACT
                tr = min(tg, p15.t_hw(d, c), p15.t_fw(d))
                e = p15.power(d, rl, bal) * tr
                if e > m[0]:
                    m = (e, d)
            worst_e[(rl, bal)] = m
        ok = rs < 0.8 * TH and rq < 0.8 * TH
        res.append((W, TH, rs, rq, worst_e[(32.0, True)], worst_e[(16.0, True)], ok))
        out.append(f'W {W*1e3:.0f} ms TH {TH:.2f}: sine>=20 Hz |D| {rs:.3f} ({fs_:.1f} Hz), square>22.7 Hz |D| {rq:.3f} ({fq:.1f} Hz) '
                   f'-> {"no false trigger (>= 20 % margin)" if ok else "margin < 20 %"} | envelope 32 ohm bal {worst_e[(32.0, True)][0]*1e3:.1f} mJ '
                   f'(d {worst_e[(32.0, True)][1]:.2f}), 16 ohm bal {worst_e[(16.0, True)][0]*1e3:.1f} mJ (d {worst_e[(16.0, True)][1]:.2f})')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
