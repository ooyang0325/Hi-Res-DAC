#!/usr/bin/env python3
"""p16b - OD-1: add a slow low-threshold CIC^2 path P4 (2 x W4 boxcars, |D| >= TH4) to P1 (22 ms / 0.30 FS) and
P2 (2 x 50 ms, TH2 0.25 FS); false-trigger check (FS sines >= 20 Hz, FS squares above the P1 limit) and the
digital-DC envelope (DC d + worst 20 Hz content c = 1 - d)."""
import numpy as np
import p15_od_guard as p15
from p16_od_p2_scan import worst, cic2
out = [__doc__]
W2, TH2 = 0.050, 0.25
rs2, _ = worst(W2, 'sine', 20.0 * (1 - 1e-4)); rq2, _ = worst(W2, 'square', 1 / (2 * p15.T_P) + 0.05)


def tdet(W, TH, d, resid):
    need = (TH + resid) / d
    if need >= 1:
        return np.inf
    tt = np.linspace(0, 2 * W, 20001)
    s = np.where(tt <= W, tt * tt / (2 * W * W), 1 - (2 * W - tt) ** 2 / (2 * W * W))
    return float(tt[np.argmax(s >= need)])


for W4 in (0.100, 0.150):
    rs4, fs4 = worst(W4, 'sine', 20.0 * (1 - 1e-4)); rq4, fq4 = worst(W4, 'square', 1 / (2 * p15.T_P) + 0.05)
    for TH4 in (0.10, 0.12, 0.15):
        env = {}
        for (rl, bal) in ((32.0, True), (16.0, True), (32.0, False), (16.0, False)):
            m = (0.0, 0.0, 0.0, '')
            for d in np.linspace(0.045, 1.0, 192):
                if 2 * d * p15.FS_LEG < 0.192:
                    continue
                for lab, c in (('small', 0.002), ('max', 1 - d)):
                    if d - c >= p15.L:
                        tg = p15.T_P
                    else:
                        tg = min(tdet(W2, TH2, d, rs2 * c), tdet(W4, TH4, d, rs4 * c))
                    tg += p15.T_DEC + p15.T_ACT
                    tr = min(tg, p15.t_hw(d, c), p15.t_fw(d))
                    e = p15.power(d, rl, bal) * tr
                    if e > m[0]:
                        m = (e, d, tr, lab)
            env[(rl, bal)] = m
        out.append(f'P4 W {W4*1e3:.0f} ms TH {TH4:.2f}: sine>=20 Hz |D| {rs4:.3f} ({fs4:.1f} Hz, margin {100*(1-rs4/TH4):.0f} %), square>22.7 Hz '
                   f'|D| {rq4:.3f} ({fq4:.1f} Hz, margin {100*(1-rq4/TH4):.0f} %) | envelope ' +
                   ', '.join(f'{rl:.0f} ohm {"bal" if bal else "SE"} {v[0]*1e3:.1f} mJ (d {v[1]:.2f}, {v[2]*1e3:.0f} ms, {v[3]})'
                             for (rl, bal), v in env.items()))
out.append(f'(P2: W 50 ms TH {TH2}: sine {rs2:.3f}, square {rq2:.3f})')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
