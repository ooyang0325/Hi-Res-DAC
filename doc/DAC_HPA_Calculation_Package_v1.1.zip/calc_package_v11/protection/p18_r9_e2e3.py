#!/usr/bin/env python3
"""p18 - R9 E-3 pair-difference level-persistence detector (closes L-11) and E-2 re-arm latch: numbers.
E-3 per audio channel c (one TLV1704 per channel, on VPOS/VNEG, outputs on N6_H):
  level c+:  IN+ = A = LEG_cP x Rb/(Ra+Rb) (Rb to GND),  IN- = B = LEG_cN x Rb/(Ra+Rb) + VPOS x Ra/(Ra+Rb) (Rb to VPOS)
             -> output high-Z (condition true) when LEG_cP - LEG_cN > VPOS x Ra/Rb = V_L;  level c- mirrored.
  timer:     level output (inputs swapped: sinks only while the condition is TRUE) drives the base of an NPN reset switch
             (MMBT3904, C = T, E = GND, base pull-up 330 k to VPOS): condition false -> NPN on -> T held at VCE(sat);
             condition true -> base pulled toward VNEG -> NPN off -> T charges via R_T 110 k into C_T 220 nF PPS 2 %;
             timer comparator IN- = T, IN+ = V_T = 0.5889 x VPOS -> N6_H low when T > V_T. No clamp diode, no R_D.
  Ra 487 k / Rb 1.00 M (0.1 %, 0603 RT0603BRD), R_T 110 k (0.1 % 0402), C_T 220 nF PPS film 2 %, V_T divider 69.8 k / 100 k (0.1 % 0402).
E-2: 74LVC1G74 on 3V3D: CP = RELAY_EN, D = RD_N = N6_CLR_N (H OK), Q = N6_ARM -> Q622 AO3400A in series with Q617.
     N6_CLR_N: 100 k to 3V3D, pulled low by Q621 2N7002 whose gate N6_TRIP (330 k to 3V3D) is released by U606 ch4 only
     while H > N6_HREF = VPOS x 330/430 (2.9...3.1 V)."""
import numpy as np
import p03_detector as d3
from pcommon import VPOS_MIN, VPOS_NOM, VPOS_MAX, VNEG_MAX, A_FS, leg_dc_max
from p17_r9_e3 import t_old, power
out = [__doc__]; P = out.append
TOL01 = 0.001 + 25e-6 * 40
RA, RB, RT, CT, KT_TOP, KT_BOT = 487e3, 1.00e6, 110e3, 220e-9, 69.8e3, 100e3   # R9 check (E-24): NPN reset, R_T 110 k, C_T 220 nF PPS 2 %, V_T 69.8 k/100 k
I_LEAK_MAX = 1.0e-6        # E-24 design basis: total leakage per timer node (NPN ICBO, C_T, PCB) [E]
VCE_SAT = (0.02, 0.20)     # MMBT3904 reset level at IC <= 40 uA, IB ~10 uA (forced beta ~4) [DS VCE(sat) <= 0.2 V at 10 mA/1 mA; bound]
VOS, IB = 5.5e-3, 20e-9
g = RB / (RA + RB)
rth = RA * RB / (RA + RB)
err = (2 * VOS + 2 * IB * rth) / g          # both comparator inputs, referred to the pair difference
vl = [VPOS_MIN * RA * (1 - TOL01) / (RB * (1 + TOL01)) - err, VPOS_MAX * RA * (1 + TOL01) / (RB * (1 - TOL01)) + err]
P(f'\nLevel threshold on the pair difference: V_L = VPOS x Ra/Rb = {VPOS_NOM*RA/RB:.3f} V nominal, worst {vl[0]:.3f} ... {vl[1]:.3f} V '
  f'(VPOS 3.789-4.014 V, 0.1 % resistors, VOS and IB x {rth/1e3:.0f} k)')
kt = [KT_BOT * (1 - TOL01) / (KT_BOT * (1 - TOL01) + KT_TOP * (1 + TOL01)), KT_BOT * (1 + TOL01) / (KT_BOT * (1 + TOL01) + KT_TOP * (1 - TOL01))]
ct = [CT * 0.98 * 0.995, CT * 1.02 * 1.005]   # R9 parts E-21: Panasonic ECH-U1H223GX5 PPS film +-2 %, TC bound +-0.5 % over 0-60 C (was C0G)
rt = [RT * (1 - TOL01), RT * (1 + TOL01)]
vf = [0.10, 0.40]                            # Schottky clamp VF at <= 0.4 mA over 0-60 C [ASSUMP bound]
tmin, tmax = 1e9, 0
tmax_noleak = 0
for vp in (VPOS_MIN, VPOS_MAX):
    for k in kt:
        for c in ct:
            for r in rt:
                for v0 in VCE_SAT:
                    for vos in (-VOS, VOS):
                        for il in (-IB, IB + I_LEAK_MAX):
                            vt = k * vp + vos
                            vinf = vp - il * r          # leakage + comparator IB drawn from the timer node
                            t = r * c * np.log((vinf - v0) / (vinf - vt))
                            tmin, tmax = min(tmin, t), max(tmax, t)
                            if il < IB + 1e-9:
                                tmax_noleak = max(tmax_noleak, t)
P(f'Timer (NPN reset to VCE(sat) 0.02-0.20 V, charge toward VPOS, threshold {KT_BOT/(KT_TOP+KT_BOT):.4f} x VPOS): T_P = {tmin*1e3:.2f} ... {tmax*1e3:.2f} ms '
  f'(with <= 1 uA leakage per node; {tmax_noleak*1e3:.2f} ms without) (PPS 2 % + 0.5 % TC, 0.1 % R, VOS, IB)')
t_sine = (np.pi - 2 * np.arcsin(vl[0] / (2 * A_FS))) / (2 * np.pi * 20.0 * (1 - 1e-4))
P(f'FS sine >= 20 Hz: pair difference 2 x {A_FS:.3f} V pk stays beyond the lowest V_L for {t_sine*1e3:.2f} ms per half cycle < T_P min '
  f'{tmin*1e3:.2f} ms -> never trips (margin {100*(1-t_sine/tmin):.1f} %); timer reset between half cycles: gap '
  f'{(2*np.arcsin(vl[1]/(2*A_FS)))/(2*np.pi*20)*1e3:.1f} ms vs NPN discharge of C_T (>= 0.4 mA) <= 1.5 ms')
P(f'FS squares: plateau >= T_P -> mute for f <= {1/(2*tmax):.1f} Hz on every unit, may mute up to {1/(2*tmin):.1f} Hz (OD-1 firmware limit 22.7 Hz)')
# energies: frozen differential DC 2x (balanced) or single-leg DC x (SE, other leg healthy): detected when D > V_L max
t_act = 5e-6 + d3.T_EXTRA                  # comparator + H fall + tOFF
rows = []
for rl, bal in ((16.0, True), (32.0, True), (16.0, False), (32.0, False)):
    wm = (0.0, 0.0, 0.0, '')
    for x in np.linspace(0.34, 4.1, 377):
        p, xl = power(x, rl, bal)
        if xl < 0.34:
            continue
        d = 2 * xl if bal else xl
        tn = tmax + t_act if d > vl[1] else np.inf
        to = t_old(xl)
        t = min(tn, to)
        e = p * t
        if e > wm[0]:
            wm = (e, xl, t, 'new detector' if tn <= to else 'old windows')
    lim = 30e-3 if rl == 16.0 else 15e-3
    rows.append((rl, bal, wm))
    P(f'  {rl:.0f} ohm {"balanced" if bal else "SE      "}: worst {wm[0]*1e3:5.1f} mJ at {wm[1]:.2f} V/leg ({wm[3]}, {wm[2]*1e3:.1f} ms) '
      f'-> limit {lim*1e3:.0f} mJ, margin {100*(1-wm[0]/lim):.0f} %')
for x in (1.51, 2.02, 2.14):
    P(f'  frozen code +-{x:.2f} V/leg: removed in <= {(tmax+t_act)*1e3:.1f} ms (was {t_old(x)*1e3:.1f} ms, leg windows only)')
# E-2 numbers
href = [VPOS_MIN * 330e3 * 0.986 / (330e3 * 0.986 + 100e3 * 1.014) - VOS, VPOS_MAX * 330e3 * 1.014 / (330e3 * 1.014 + 100e3 * 0.986) + VOS]
P(f'\nE-2: H-OK reference N6_HREF = VPOS x 330/430 = {href[0]:.3f} ... {href[1]:.3f} V (1 % R, VOS); H permitted >= 3.68 V (p05) -> margin '
  f'{3.68-href[1]:.2f} V; any H dip below {href[0]:.2f}...{href[1]:.2f} V clears ARM (Q617 needs <= 2.5 V for its RDS(on) spec, so every '
  'dip that can touch Q617 disarms)')
t_clr = (VPOS_MAX - href[0]) * 1.1e-6 / 4e-3 + 330e3 * 60e-12 * 3 + 1e3 * 1e-9 * 3
P(f'  trip -> ARM cleared -> Q622 off <= {t_clr*1e3:.2f} ms after the comparator switches (H 4.014 V -> HREF at 4 mA into 1.1 uF, then 330 k x 60 pF '
  'and 1 k x 1 nF) - earlier than Q617 (0.98 ms); not credited in the energy tables')
tau_h = 100e3 * 1.01 * 1e-6 * 1.10
t_rec = tau_h * np.log((3.68 - 2.5) / (3.68 - href[1]))
P(f'  re-arm: after DC_PERMIT_N reads low, H may need up to {t_rec*1e3:.0f} ms more to pass HREF -> firmware waits for DC_PERMIT_N low >= 150 ms, '
  'then RELAY_EN low -> high (fresh edge) and checks N6_ARM on PB0 (retry after 20 ms if not armed)')
P('  hung MCU with RELAY_EN static high: no edge -> ARM stays cleared after any trip, of any depth, until the IWDG reset; power-up: H low '
  '(or U606 unpowered) -> N6_TRIP high -> CLR low -> ARM = 0; 3V3D off -> U608 off -> Q622 off')
open(__file__.replace('.py', '_out.txt'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out[1:]))
