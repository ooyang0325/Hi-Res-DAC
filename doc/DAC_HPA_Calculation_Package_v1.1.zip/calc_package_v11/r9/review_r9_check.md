# Independent R9 design check

Source set and five checks are those in `brief_r9_review.md`. Design files were read only. Numbers below were independently recalculated with small Python snippets.

## Confirmed findings

### R9-CHK-01 — High — E-3 timer clamp diode has the wrong topology

`D611`/`D612` are BOM MPN **Nexperia BAS70-05,215**, but the merged netlist requires a **dual common-anode** device: pin 3 (`A`) to `GND`, pins 1/2 (`K1/K2`) to `N6_TLP_*` / `N6_TLN_*`. The local parts audit identifies BAS70-05 as common cathode, pins 1/2 = A1/A2 and pin 3 = common K; BAS70-06 is the corresponding common-anode variant. With BAS70-05 fitted, each timer node is an anode and GND is the common cathode, so it is clamped near **+VF** while charging instead of near **−VF** while resetting. `U609/U610` timer inputs (pins 8/10) therefore cannot reach `N6_VT ≈ 0.8492·VPOS = 3.21–3.42 V`; even the BOM's 0.410 V maximum forward clamp is 2.80 V below the lowest threshold. The E-3 outputs on pins 14/13 never assert `N6_H`. The claimed 20.00–22.24 ms trip, 13.9/27.5 mJ limits, and closure of L-11 do not exist as built.

Evidence: `D611` pins 1/2/3 = `K1/K2/A` on `N6_TLP_L/N6_TLN_L/GND`; `D612` likewise for R; BOM MPN BAS70-05,215; `parts/stress_table.csv` row “D611, D612” gives physical pins `1 a1, 2 a2, 3 common k`; `U609/U610` pins 8/10 are timer inputs and pins 14/13 pull `N6_H`.

### R9-CHK-02 — High — E-2 is not single-fault fail-safe

The new latch can be bypassed by one ordinary open/short, contrary to the requested single-fault check. Examples:

- `R690` open leaves `N6_TRIP` without its asserted-high path, and `Q621` open prevents `N6_CLR_N` from being pulled low; either fault can leave `U608` armed. After `N6_H` recovers, `Q617` can re-close with `RELAY_EN` still high.
- `Q622` drain-source short bypasses the latch outright.
- `R692` open while armed isolates the `Q622` gate. There is no gate-source pull-down, so stored gate charge can leave Q622 on after `U608.Q` clears.

Thus a single fault can restore the exact shallow-trip/hung-MCU automatic re-close that E-2 was added to prevent. Also, `U608.Q` is Ioff/high-impedance—not guaranteed low—when `3V3D` is off; without a Q622 gate pull-down, the statement “3V3D off → Q622 off” is not true by itself (the separate Q616 path normally keeps the overall switch open).

Evidence: `R690` = sole pull-up `3V3D→N6_TRIP`; `Q621` = sole pull-down of `N6_CLR_N`; `R692` = sole connection `U608.Q→Q622.G`; Q622 pins 3/2 are in series between `Q617.S` (`N6_M3`) and GND.

### R9-CHK-03 — Medium — E-3 timing/energy is not a guaranteed worst case

The 20.00–22.24 ms calculation includes timer-input bias but omits leakage of the released level-comparator output and reverse leakage of the clamp diode. Each timer has only about `(VPOS−VT)/R920 ≈ 1.2 µA` charging current at threshold. The local parts data gives BAS70 leakage up to 0.1 µA at 25 °C, and TLV1704 output leakage up to 70 nA at 25 °C; neither has a used 50–60 °C maximum. Adding just 0.17 µA raises the independently calculated slow time from 22.24 to about 23.8 ms and the 32 Ω balanced case from 13.86 to about 14.76 mJ, leaving only 1.6%; 0.5 µA gives about 27.65 ms and 16.96 mJ. The evidence register labels 13.9 mJ as class G, but it is not bounded over temperature. Re-select the corrected common-anode clamp for guaranteed leakage and rerun the timer/energy corners.

Evidence: `R920–R923 = 487 kΩ`, `C631–C634 = 22 nF`, `U609/U610` output leakage 70 nA (datasheet table 7.6), parts stress row for D611/D612 gives `IR ≤ 0.1 µA at 50 V` without a hot bound.

### R9-CHK-04 — Medium — the layout source still specifies the superseded suspend circuit

`parts/layout_package.md` §6/Z1 still routes `U101.5` to **5V_SYS** and specifies `Q507 = AO3400A` with `R537 = 1 MΩ`, omitting `R538`. The merged R9 netlist/BOM instead require `U101.5 → 3V3M` and `Q507 = MMBT3904`, `R537 = R538 = 100 kΩ`. Following the layout source would restore the D+→dead-5V_SYS back-feed in suspend and/or prevent the NPN version of Q507 from turning on. R9-D2/E-16 is therefore not consistently released.

Evidence: `parts/layout_package.md` Z1; `U101.5`, `Q507.1/.2/.3`, `R537`, `R538` in `integration/netlist_merged.csv`; corresponding merged-BOM rows.

### R9-CHK-05 — Low — final PCB manufacturing row still contradicts R9 decisions

The merged BOM `PCB` row still specifies an **80 × 60 mm board with epoxy-filled/capped exposed-pad vias**, while E-19 and the current layout package require **100 × 80 mm** and **unfilled, L4-tented** thermal vias. Therefore R9-A6 and R9-A minor 2 are not consistently fixed in all release-source files.

Evidence: `integration/bom_merged.csv`, ref `PCB`; compare `parts/layout_package.md` §§1/5/6 and `design_v10_summary.md` §(p).

### R9-CHK-06 — Low — the specified shortest E-2 test pulse is not guaranteed to clear the latch

The bring-up plan requires 50 µs and 0.3 ms comparator-generated trips to leave `PB0` low. With `C617 = 1 µF +10%` and the guaranteed 4 mA TLV1704 sink, H needs about **0.25–0.31 ms just to cross HREF**, before the `N6_TRIP`/`Q621` delay. Thus 50 µs cannot, and 0.3 ms does not cover all corners, when injected through PB8/a comparator. A direct low-impedance pull on `N6_H` is a different test. Use at least the independently derived 0.373 ms bound plus margin.

Evidence: `C617`, `U606.10/.11/.13`, `R690`, `Q621`; `protection/report.md` E-2 bring-up list.

## Independent calculations / checks

- E-2 intended values reproduce: `HREF = 2.8833…3.1059 V`; clear path `≤ 0.373 ms` using 1.1 µF, 4 mA, 330 kΩ·60 pF and 1 kΩ·1 nF terms. The nominal latch truth table is correct and clear dominates clock.
- E-3 intended values reproduce: `VL = 1.8020…1.9985 V`, `VT = 3.210…3.416 V`, `TP = 19.996…22.236 ms`; a 20 Hz full-scale sine is above the lowest threshold for 18.376 ms (8.10% nominal margin). Intended energies reproduce as 27.52 mJ (16 Ω balanced, old windows) and 13.86 mJ (32 Ω balanced, new detector). These intended results are defeated by R9-CHK-01.
- E-3 taps are only on `LEG_LP/LN/RP/RN`, not `JACK_*`; two 1.487 MΩ paths give 743.5 kΩ AC loading per leg.
- E-16 arithmetic reproduces `S6 = 2.275515 mA`, margin 224.5 µA. `U502` pin map and 2.7–30 V operating/32 V absolute ratings cover the modeled 17.08 V clamp peak. `Q507` B/E/C = pins 1/2/3 and its 100 kΩ/100 kΩ network gives default-on at MCU reset; calculated U102 EN is 3.19 V at the stated 0.55 µA hot-leakage assumption. No 3V3M→5V_SYS DC back-feed path was found with D103 deleted.
- Independent CSV audit: 1,297 netlist rows, 480 netlisted references, 234 nets, no duplicate `(ref,pin)`, no conflicting pin assignment, no non-NC single-pin net, no duplicate BOM designator, and no package pin-count mismatch. The 38 `NC` rows are explicitly isolated.
- New-part pin maps: U608 = 1 CP, 2 D, 3 `/Q`, 4 GND, 5 Q, 6 `/RD`, 7 `/SD`, 8 VCC; U609/U610 match the TLV1704 PW table; U502 = 1 IN, 2 GND, 3 EN, 4 NC, 5 OUT; Q507 = B/E/C and Q621/Q622 = G/S/D on pins 1/2/3. D611/D612 are the exception in R9-CHK-01.

## R9 review disposition check

Every R9-A…R9-D item has a row in `design_v10_summary.md` §(p). The substantive dispositions for R9-B1/B2 are invalidated by R9-CHK-02/R9-CHK-01 (and the E-3 guarantee by R9-CHK-03). R9-D2/E-16 is inconsistent with the layout source (R9-CHK-04), and R9-A6/A-minor-2 remain contradicted by the merged BOM (R9-CHK-05). The remaining findings are fixed, explicitly accepted, or documented with a measurement/gate/fallback.

| Review items | Independent status |
|---|---|
| A1, A2, A4, A5, A7, A8, A10; A minor 1; B4, B5c/d; C2; D3/D4 | Confirmed in the merged BOM/netlist or current calculations/documented qualification. |
| A3, A9, A minor 3; B3/B5a; C1/C3/layout notes; D1/D2 and post-layout items | Written disposition exists; retained measurement/assumption/gate conditions are explicit. E-16 has the conflicting layout instruction in R9-CHK-04. |
| B1 | Nominal logic works, but single-fault and short-pulse claims fail: R9-CHK-02 and R9-CHK-06. |
| B2 / D5 | Not fixed in the released parts/netlist because of D611/D612: R9-CHK-01; its guaranteed energy evidence also has R9-CHK-03. |

## Finding count

**High: 2 · Medium: 2 · Low: 2**
