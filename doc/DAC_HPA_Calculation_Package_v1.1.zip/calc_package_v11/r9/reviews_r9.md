# Ninth review round (R9-A … R9-D) of Spec v0.9 / Notes v0.8 / Parts List v0.7 — received 25 Sep 2026 16:51 UTC (verbatim digest)

## R9-A (full read + independent netlist walk)
Verdict: schematic-ready after four Value-cell corrections; layout package complete, routing correctly gated on G-1…G-4 (which depend on the two owner orders — the critical path).
Verified: 208 nets / 1,163 pins, no floating pins, no single-pin nets except 52 TPs, 40 NCs; Ioff/open-drain domain crossings; VREF 1.670 V; rails +3.852/−3.721 V; windows ±0.294–0.298 V; untrimmed 1.886 Vrms → −1.70 dB trim; −0.067 dB at 20 kHz; 2 V/1 V removal ≈ 44/98 ms (τ 253 ms); H recovery 6–35 ms toward the FET threshold (inside the stated 53–135 ms full-recovery band); LED 6.4 mA with ≥ 1.3 V headroom at 4.31 V; 20 Hz square from rest 0.248 V vs 0.276 V lowest trip; permit fail-safe in every traced path; 48 self-checks consistent.
A1 (Medium, fix before capture): four stale Value cells — R108 reads 86.6 k (MPN 0402WGF1003 = 100 k), R109 300 k (MPN = 470 k), R535 68.1 k (MPN = 100 k), R536 30.1 k (MPN = 47 k). Add a "Value decodes from MPN" check for every UNI-ROYAL / YAGEO code.
A2: U503 TPS2596 OVCSEL (pin 8) open — confirm in the datasheet what open selects; if not defined, tie to GND or IN.
A3: DAC GPIO2 carries "lock and minimum-volume flag" — one function per GPIO; keep GPIO2 = lock (OD-2 interrupt); read the minimum-volume flag from reg 64 over I²C within the 5.31 ms deadline.
A4: 1V3 discharge claim — U303 EN tied to 3V3D, so for ≈ 90 µs after AUD_EN falls it still regulates 1.3 V into R530 (4.7 Ω, ≈ 0.28 A) until 3V3D < ≈ 1.7 V; DVDD ≤ DVCC holds; "≤ 0.134 ms" and "a regulator never fights its discharge" not literally true; documentation only (< 0.1 mJ).
A5: close open item 6 (C442/C443 reverse bias during LM27762 start-up) by calculation before capture.
A6: density ≈ 2,500 mm² of ≈ 4,000 mm² usable — try the floor plan immediately; decide what gives (≤ 80 × 60 mm or "no components on L4").
A7: silkscreen — 1.0 mm designators for ≈ 430 items won't fit; pin-1/polarity marks and net names on silk, designators in the assembly drawing.
A8: brown-out threshold vs 4.40 V corner — effective margin ≈ 0.17 V; add to the thin-margins table.
A9: MCLK-alive tap — R665 1 k with ≈ 3 pF gives ≈ 1.8 Vpp at the Schmitt input; make 330 Ω the default (input capacitance 1.1 pF keeps the load inside 15 pF).
A10: family-clock mux switch — assert the CPLD soft reset (or register-domain engine reset) across the mux switch.
Minor: R660 330 k 1 % (C25778) vs Spec §9.1 "330 k 0.1 % no LCSC listing" (R677/R684) — clarify; Notes Table 16 "filled thermal vias" for U301 contradicts the cost patch; name a drop-in alternate for U605 TLV3402 (same SOIC-8 pinout).

## R9-B
Verdict: schematic capture proceed; schematic freeze hold; placement provisional; routing hold (G-1…G-4); manufacturing hold.
B1 (High): node H does not guarantee a 53 ms minimum off-time after every trip — recovery depends on how far C617 was discharged; from H = 0.45 V toward 3.852 V (100 k/1 µF): 0.65 V in 6.1 ms, 1.05 V in 19.4 ms, 1.45 V in 34.8 ms (AO3400A VGS(th) range). With a hung MCU still asserting RELAY_EN, re-energising before the watchdog reset is not excluded. Enforce a minimum off-time independent of the depth of discharge; test short comparator pulses with RELAY_EN held high.
B2 (High): the balanced-fault energy requirement (30/15 mJ) conflicts with L-11 (±1.51 V 69.1 ms 16 Ω → 39.4 mJ; ±2.02 V 50.7 ms 32 Ω → 25.9 mJ; also the CPLD frozen word at 352.8/384 kHz if capture fails). Narrow the requirement to an approved fault-coverage matrix or change the protection; one unambiguous acceptance criterion.
B3 (Medium): several "worst-case" bounds are assumptions (TLP3545A timing 2× 25 °C maxima; TLV3402 delay 3× typical; PMEG2010AEH VF tempco; BAT54 leakage estimate exceeds its allowance by ≈ 2 µA against a 3.5 µA suspend margin). Distinguish guaranteed / estimated / qualified; supply reproducible calculations (the package lacks the models, scripts and results behind the 1,944-corner hold-up, stability sweeps, stream-guard proofs) and a qualification plan.
B4 (Medium): a 25 °C offset screen does not establish the 0–50 °C guarantee (DAC mismatch drift unpublished) — bound it, qualify over temperature, or state the guarantee as conditional.
B5: routing blocked by G-1…G-4; reconcile: Notes §3.3 still says U301 filled thermal vias; C617 described as 50 V but CL10A105KB8NNNC/C15849 is "the 25 V part" (reviewer claim — verify); R681 sourcing note min/multiple 100 vs purchase qty 7 with no order multiple, checks don't catch it.
Verified: 366 fitted incl. 7 owner-fitted; 1,064 SMT joints; BOM/netlist agreement; no external links/errors; cost US$ 758.82 / NTD 24,077.51.

## R9-C
Verdict: layout-ready with conditions; start capture now, not routing (G-1…G-4 hard).
C1: power-down order not fully specified for every exit (suspend row names an order but never lists it; brown-out drops AVCC_EN and AUD_EN together) — write one explicit order (RELAY_EN low → AVCC_EN low → AUD_EN low → ANA_EN low) and use it everywhere.
C2: "The 1.3 V rail discharge is not guaranteed at a reset" — discharge FETs driven from the enables, U303 EN tied to 3V3D; if the MCU resets while 3V3D is up the 1V3 rail has no discharge path (reviewer claim — verify against the netlist).
C3: suspend margin 3.5 µA on the unpublished MCU Stop current (L-1) — measure on the first board.
Layout notes: MCLK trace ≤ 10 mm; USB pair 90 Ω; ESD within 3–5 mm of the connector; guard the 22 MΩ / 4.7 MΩ nodes (1 nA → 22 mV); R509 hand-fitted, eFuse stays off without it — mark on silkscreen; owner-fitted parts excluded from the JLCPCB BOM. Accepted: L-11 (owner accepted), L-5, L-4. Cost quoted as US$ 525.20 = NTD 16,665 (reviewer figure).

## R9-D
Verdict: begin capture GO conditionally; schematic freeze NO-GO; routing NO-GO; fabrication NO-GO.
D1: G-1…G-4 open; jack pin numbers provisional — can change schematic pin numbering and footprints.
D2: USB suspend not guaranteed — 2.4965 mA vs 2.500 mA (3.5 µA), MCU Stop max unpublished, BAT54 leakage at 50 °C uncharacterised (≈ 12 µA estimate vs 10 µA budget); no hardware fallback. Use qualified lower-leakage clamps or redesign for ≈ 0.1–0.2 mA suspend margin.
D3: 0–50 °C offset not guaranteed by a 25 °C screen (margins 0.77/1.55 mV; DAC matching/drift unpublished) — screen at temperature, fit the 0.05 % network by default, add trim/servo, or weaken the temperature guarantee.
D4: Default-mode current and power have no robust simultaneous margin (USB 490.80 mA vs 500; eFuse min 177.9 vs 176.97 mA need; MCU/CPLD maxima assumed) — provide margin or make the Default power figures characterisation targets.
D5: protection requirement vs L-11 conflict — formally exclude with owner acceptance or add an independent detection mechanism; cannot claim "every requirement is met" and keep L-11.
Post-layout risks: D411/D412 VF/leakage typical; TLP3545A timing and THD uncharacterised (measure THD+N at LEG vs JACK); U101/U501/U302 up to 5.55 V (L-10); 20 Hz hardware-window false-trip margin ≈ 6.2 %; J101 pin-in-paste/reflow confirmation.
