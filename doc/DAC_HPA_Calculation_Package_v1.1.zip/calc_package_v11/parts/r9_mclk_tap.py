"""R9 E-11 support (parts/layout): MCLK load added by the MCLK-alive tap R665 -> U607 input, 80 MHz.
Series R with the downstream capacitance C (U607 CI + trace) appears at XI as C_eff = C / (1 + (w R C)^2) (parallel-equivalent
at the MCLK fundamental) plus the pad/stub before R665 (<= 0.3 pF, layout rule). Digital MCLK load without the tap 13.1 pF
(protection p10); Kyocera KC2520K rated load 15 pF. U607 CI 1.1 pF typ (no maximum published) [ASSUMP x1.5 = 1.65 pF as a bound];
trace 0.12 pF/mm (50-ohm-class microstrip on 0.2 mm prepreg) [CALC]. Writes r9_mclk_tap_out.txt."""
import math
f = 80e6; w = 2 * math.pi * f
base, stub, limit = 13.1, 0.3, 15.0
out = ['R9 E-11: MCLK load with the R665 tap (80 MHz). C = U607 CI + trace; C_eff = C/(1+(wRC)^2) + 0.3 pF stub; total = 13.1 pF + C_eff (limit 15 pF)', '',
       f"{'R665':>6} {'CI pF':>6} {'trace mm':>8} {'C pF':>6} {'C_eff pF':>9} {'total pF':>9} {'margin pF':>9}  amplitude at U607 (1st harmonic, % of XI)"]
for R in (330.0, 1000.0):
    for ci in (1.1, 1.65):
        for tr in (1, 2, 3, 5):
            C = (ci + 0.12 * tr) * 1e-12
            x = w * R * C
            ceff = C / (1 + x * x) * 1e12 + stub
            tot = base + ceff
            amp = 100 / math.sqrt(1 + x * x)
            out.append(f'{R:>6.0f} {ci:>6.2f} {tr:>8d} {C*1e12:>6.2f} {ceff:>9.2f} {tot:>9.2f} {limit - tot:>+9.2f}  {amp:5.0f} %')
out += ['', 'Reading: 330 ohm keeps the MCLK load <= 15 pF only with the TYPICAL U607 CI (1.1 pF) and a R665 -> U607 trace <= 3 mm',
        '(14.78 pF, +0.22 pF); with a 1.5 x CI bound (1.65 pF, no maximum is published) it is 15.03-15.37 pF (-0.03 ... -0.37 pF) for 1-5 mm.',
        '1 k keeps 14.29-14.39 pF (>= +0.61 pF) in every case, but the fundamental at the Schmitt input is only 66-85 % of the XI swing',
        '(330 ohm: 94-98 %). E-11 "X201 load <= 15 pF" with 330 ohm therefore rests on CI <= ~1.4 pF [ASSUMP] and the <= 3 mm layout rule',
        '(layout_package.md, no via); protection/digital decide E-11 with this table.']
open('r9_mclk_tap_out.txt', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print('\n'.join(out))
