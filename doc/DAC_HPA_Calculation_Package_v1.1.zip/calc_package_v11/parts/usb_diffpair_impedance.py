"""90-ohm USB 2.0 HS differential pair geometry for the JLCPCB 4-layer stack-ups.

Method 1: 2-D electrostatic finite-difference field solver (node grid, finite-volume
          permittivity, matrix-free Jacobi-preconditioned CG). Capacitance from the
          stored energy (C = 2W/V^2 per conductor pair excitation); Z from C and C0
          (all dielectrics replaced by air): Z = 1/(c0*sqrt(C*C0)).  Includes the
          JLCPCB solder-mask model (C1 = 1.2 mil over substrate, C2 = 0.6 mil over
          trace, C3 = 1.2 mil between traces, Er 3.8).
Method 2: closed-form cross-check (Hammerstad-Jensen single microstrip with thickness
          correction; Wadell/IPC-2141 edge-coupled approximation), bare (no mask).

Stack-up data: JLCPCB "Controlled Impedance PCB Layer Stackup" page
https://jlcpcb.com/impedance (JLC04161H-7628: L1 Cu 0.035 mm, 7628 prepreg 0.2104 mm
Er 4.4, L2 Cu 0.0152 mm, core 1.065 mm Er 4.6; JLC04161H-3313: 3313 prepreg 0.0994 mm
Er 4.1; solder mask C1 1.2 mil, C2 0.6 mil, C3 1.2 mil, Er 3.8).
Outer copper 1 oz finished = 0.035 mm (JLCPCB). Traces modelled rectangular.
"""
import numpy as np, math, json, sys, time

C0 = 299792458.0
EPS0 = 8.8541878128e-12
MIL = 0.0254  # mm


def _axis(breaks, lo, hi, fine, growth=1.25, maxstep=None):
    """Non-uniform 1-D grid containing every breakpoint exactly (conductor edges, dielectric
    interfaces); spacing <= 'fine' between breakpoints, geometric growth towards lo/hi."""
    b = sorted(set(round(v, 9) for v in breaks))
    pts = [b[0]]
    for a, c in zip(b[:-1], b[1:]):
        n = max(1, int(math.ceil((c - a)/fine - 1e-9)))
        pts += [a + (c - a)*k/n for k in range(1, n + 1)]
    left, right = [pts[0]], [pts[-1]]
    step = fine
    while left[-1] > lo + 1e-12:
        step = min(step*growth, maxstep or 1e9); left.append(max(lo, left[-1] - step))
    step = fine
    while right[-1] < hi - 1e-12:
        step = min(step*growth, maxstep or 1e9); right.append(min(hi, right[-1] + step))
    return np.array(sorted(set(round(v, 9) for v in left[1:] + pts + right[1:])))


def solve_cs(W, S, h, er, t=0.035, mask=True, er_mask=3.8, c1=1.2*MIL, c2=0.6*MIL,
             dx=0.005, mode='odd', single=False, extent=25.0, tol=1e-10):
    """Per-unit-length capacitance of trace 1 (F/m) with dielectric (C) and in air (C0).
    Geometry in mm; y = 0 is the reference plane (L2, Dirichlet 0 V); outer boundaries
    (sides, top) are zero-flux (Neumann) at 'extent' x h away.  Non-uniform rectilinear
    finite-volume grid, step dx around the conductors."""
    halfw = (W/2) if single else (W + S/2)
    L = extent*h + halfw
    cen = [0.0] if single else [-(W + S)/2, (W + S)/2]
    xb = [-halfw - 3*h, halfw + 3*h]
    for c in cen:
        xb += [c - W/2, c + W/2, c - W/2 - c2, c + W/2 + c2]
    x = _axis(xb, -L, L, dx, maxstep=h)
    yb = [0.0, h, h + t, h + c1, h + t + c2, h + t + c2 + 3*dx]
    y = _axis(yb, 0.0, extent*h, dx, maxstep=h)
    nx, ny = len(x), len(y)
    X, Y = np.meshgrid(x, y, indexing='ij')
    ytr0, ytr1 = h, h + t
    eps_ = 1e-9
    if single:
        centers = [0.0]
    else:
        centers = [-(W + S)/2, (W + S)/2]
    trs = [(np.abs(X - c) <= W/2 + eps_) & (Y >= ytr0 - eps_) & (Y <= ytr1 + eps_) for c in centers]
    xc_ = 0.5*(x[:-1] + x[1:]); yc_ = 0.5*(y[:-1] + y[1:])
    XC, YC = np.meshgrid(xc_, yc_, indexing='ij')
    def eps_map(with_diel):
        e = np.ones((nx-1, ny-1))
        if not with_diel:
            return e
        e[YC < h] = er
        if mask:
            m = (YC >= h) & (YC < h + c1)
            trc = np.zeros_like(m)
            for c in centers:
                trc |= (np.abs(XC - c) < W/2) & (YC >= h) & (YC < h + t)
                m |= (np.abs(XC - c) < W/2 + c2) & (YC >= h) & (YC < h + t + c2)
            m &= ~trc
            e[m] = er_mask
        return e
    hx = np.diff(x); hy = np.diff(y)
    fixed = np.zeros((nx, ny), bool)
    fixed[:, 0] = True
    for tr in trs:
        fixed |= tr
    V = np.zeros((nx, ny))
    V[trs[0]] = 1.0
    if not single:
        V[trs[1]] = -1.0 if mode == 'odd' else 1.0
    res = {}
    for with_diel in (True, False):
        e = eps_map(with_diel)
        # x-edge (i,j)-(i+1,j): flux width = half of cells j-1 and j in y
        ex = np.zeros((nx-1, ny))
        ex[:, 1:] += 0.5*e*hy[None, :]
        ex[:, :-1] += 0.5*e*hy[None, :]
        ex /= hx[:, None]
        ey = np.zeros((nx, ny-1))
        ey[1:, :] += 0.5*e*hx[:, None]
        ey[:-1, :] += 0.5*e*hx[:, None]
        ey /= hy[None, :]
        diag = np.zeros((nx, ny))
        diag[:-1, :] += ex; diag[1:, :] += ex
        diag[:, :-1] += ey; diag[:, 1:] += ey
        free = ~fixed
        def Aop(u):
            out = diag*u
            out[:-1, :] -= ex*u[1:, :]
            out[1:, :] -= ex*u[:-1, :]
            out[:, :-1] -= ey*u[:, 1:]
            out[:, 1:] -= ey*u[:, :-1]
            return out
        Vf = np.where(fixed, V, 0.0)
        b = -Aop(Vf); b[fixed] = 0.0
        u = np.zeros_like(V)
        r = b.copy(); Minv = np.where(free, 1.0/diag, 0.0)
        z = Minv*r; p = z.copy(); rz = np.sum(r*z); b2 = math.sqrt(np.sum(b*b))
        for it in range(50000):
            Ap = Aop(p); Ap[fixed] = 0.0
            alpha = rz/np.sum(p*Ap)
            u += alpha*p; r -= alpha*Ap
            if math.sqrt(np.sum(r*r)) < tol*b2:
                break
            z = Minv*r; rz_new = np.sum(r*z); p = z + (rz_new/rz)*p; rz = rz_new
        phi = u + Vf
        Wtot = EPS0*0.5*(np.sum(ex*(phi[1:, :] - phi[:-1, :])**2) + np.sum(ey*(phi[:, 1:] - phi[:, :-1])**2))
        Cval = 2*Wtot if single else Wtot
        res['C' if with_diel else 'C0'] = Cval
        res['iters_' + ('d' if with_diel else 'a')] = it
    res['nodes'] = nx*ny
    res['Z'] = 1.0/(C0*math.sqrt(res['C']*res['C0']))
    res['eeff'] = res['C']/res['C0']
    return res


def z_pair(W, S, h, er, odd_only=False, **kw):
    o = solve_cs(W, S, h, er, mode='odd', **kw)
    if odd_only:
        return dict(Zodd=o['Z'], Zdiff=2*o['Z'], eeff_odd=o['eeff'])
    e = solve_cs(W, S, h, er, mode='even', **kw)
    return dict(Zodd=o['Z'], Zeven=e['Z'], Zdiff=2*o['Z'], Zcm=e['Z']/2, eeff_odd=o['eeff'], eeff_even=e['eeff'])


def hj_microstrip(W, h, er, t=0.035):
    """Hammerstad-Jensen microstrip with thickness correction (bare, no mask)."""
    u = W/h
    if t > 0:
        du1 = t/h/math.pi*math.log(1 + 4*math.e/(t/h*(1/math.tanh(math.sqrt(6.517*u)))**2))
        dur = 0.5*(1 + 1/math.cosh(math.sqrt(er - 1)))*du1
        u1, ur = u + du1, u + dur
    else:
        u1 = ur = u
    def z0air(uu):
        f = 6 + (2*math.pi - 6)*math.exp(-(30.666/uu)**0.7528)
        return 60*math.log(f/uu + math.sqrt(1 + 4/uu**2))
    def eeff(uu):
        a = 1 + math.log((uu**4 + (uu/52)**2)/(uu**4 + 0.432))/49 + math.log(1 + (uu/18.1)**3)/18.7
        b = 0.564*((er - 0.9)/(er + 3))**0.053
        return (er + 1)/2 + (er - 1)/2*(1 + 10/uu)**(-a*b)
    ee = eeff(ur)*(z0air(u1)/z0air(ur))**2
    return z0air(ur)/math.sqrt(ee), ee


def ipc_diff(W, S, h, er, t=0.035):
    z0, _ = hj_microstrip(W, h, er, t)
    return 2*z0*(1 - 0.48*math.exp(-0.96*S/h))


def find_W(target, S, h, er, lo=0.06, hi=0.40, **kw):
    for _ in range(18):
        mid = 0.5*(lo + hi)
        z = z_pair(mid, S, h, er, odd_only=True, **kw)['Zdiff']
        if z > target:
            lo = mid
        else:
            hi = mid
        if hi - lo < 0.0015:
            break
    return 0.5*(lo + hi)


if __name__ == '__main__':
    t0 = time.time()
    out = {}
    lines = []
    def log(s):
        print(s, flush=True); lines.append(s)
    log('USB 90-ohm differential pair, JLCPCB 4-layer stack-ups (L1 over L2 GND), 1 oz outer (t = 0.035 mm)')
    log('Solver: 2-D FD/FV electrostatic, non-uniform grid, Neumann outer boundary at 25 h, energy-based C')
    log('\n[validation] single microstrip, no mask: FD solver vs Hammerstad-Jensen (HJ)')
    for W in (0.20, 0.38):
        fd = solve_cs(W, 0, 0.2104, 4.4, single=True, mask=False, dx=0.005)
        hj = hj_microstrip(W, 0.2104, 4.4)
        log(f'  W={W:.3f} mm h=0.2104 Er=4.4: FD Z0={fd["Z"]:.2f} ohm (eeff {fd["eeff"]:.3f}); HJ Z0={hj[0]:.2f} ohm (eeff {hj[1]:.3f}); diff {100*(fd["Z"]/hj[0]-1):+.1f} %')
    stacks = [('JLC04161H-7628', 0.2104, 4.4, (0.127, 0.15, 0.20)), ('JLC04161H-3313', 0.0994, 4.1, (0.127,))]
    for name, h, er, Ss in stacks:
        log(f'\n== {name}: h={h} mm, Er={er}, solder mask Er 3.8 (C1 1.2 mil, C2 0.6 mil) ==')
        res = []
        for S in Ss:
            Wm = find_W(90.0, S, h, er, dx=0.005)
            Wr = round(Wm/0.005)*0.005
            zm = z_pair(Wr, S, h, er, dx=0.005)
            zb = z_pair(Wr, S, h, er, dx=0.005, mask=False, odd_only=True)
            ipc = ipc_diff(Wr, S, h, er)
            log(f'  S={S:.3f} mm -> W(90 ohm, dx 7.5 um search)={Wm:.4f} mm; W={Wr:.3f} mm: Zdiff={zm["Zdiff"]:.1f} ohm with mask '
                f'({zb["Zdiff"]:.1f} bare; closed-form IPC-2141/HJ bare {ipc:.1f}); Zodd={zm["Zodd"]:.1f}, Zcm={zm["Zcm"]:.1f} ohm')
            res.append(dict(S=S, W90=Wm, W=Wr, Zdiff_mask=zm['Zdiff'], Zdiff_bare=zb['Zdiff'], Zcm=zm['Zcm'], ipc=ipc))
        out[name] = res
    name, h, er = 'JLC04161H-7628', 0.2104, 4.4
    pick = [r for r in out[name] if abs(r['S'] - 0.15) < 1e-9][0]
    W, S = pick['W'], 0.15
    log(f'\n[chosen] {name}: W={W} mm, S={S} mm (centre pitch {W+S:.2f} mm)')
    log('  grid convergence (odd mode, with mask):')
    conv = []
    for dx in (0.01, 0.005, 0.0025):
        z = z_pair(W, S, h, er, dx=dx, odd_only=True)['Zdiff']; conv.append(z)
        log(f'    dx={dx*1000:.1f} um: Zdiff={z:.2f} ohm')
    zext = conv[2] - (conv[1] - conv[2])  # first-order Richardson estimate
    log(f'    extrapolated (dx->0, first-order) ~{zext:.1f} ohm')
    base = z_pair(W, S, h, er, dx=0.005)
    log(f'  nominal (dx 5 um): Zdiff={base["Zdiff"]:.1f} ohm, Zodd={base["Zodd"]:.1f}, Zeven={base["Zeven"]:.1f}, Zcm={base["Zcm"]:.1f} ohm, eeff_odd={base["eeff_odd"]:.3f}')
    corners = []
    for dW in (-0.02, 0.02):
        for dh in (-0.1, 0.1):
            for der in (-0.2, 0.2):
                z = z_pair(W + dW, S - dW, h*(1 + dh), er + der, dx=0.0075, odd_only=True)['Zdiff']
                corners.append(dict(dW=dW, dh=dh, der=der, Zdiff=z))
    zs = [c['Zdiff'] for c in corners]
    log(f'  fabrication corners (W +/-0.02 mm with gap -/+0.02 mm, h +/-10 %, Er +/-0.2; dx 7.5 um): Zdiff {min(zs):.1f} ... {max(zs):.1f} ohm')
    log('  USB 2.0 HS: 90 ohm +/-15 % (76.5-103.5 ohm) differential; JLCPCB impedance-control tolerance +/-10 %')
    nomask = z_pair(W, S, h, er, mask=False, dx=0.005, odd_only=True)['Zdiff']
    log(f'  sensitivity: no solder mask over the pair -> Zdiff {nomask:.1f} ohm (keep the pair under mask)')
    log('\n[single-ended Z0 on L1 over L2, 7628, with mask] (routing reference)')
    se = {}
    for Ws in (0.127, 0.15, 0.20, 0.25, 0.30, 0.36):
        r = solve_cs(Ws, 0, h, er, single=True, dx=0.005)
        se[str(Ws)] = r['Z']
        log(f'  W={Ws:.3f} mm: Z0={r["Z"]:.1f} ohm, eeff={r["eeff"]:.3f}, delay {math.sqrt(r["eeff"])/C0*1e9:.2f} ps/mm')
    out['chosen'] = dict(stack=name, W=W, S=S, convergence=conv, extrapolated=zext, **base,
                         corners=corners, corners_min=min(zs), corners_max=max(zs), nomask=nomask)
    out['single_ended_7628'] = se
    log(f'\nrun time {time.time()-t0:.0f} s')
    json.dump(out, open('usb_impedance_out.json', 'w'), indent=1)
    open('usb_impedance_out.txt', 'w').write('\n'.join(lines) + '\n')
