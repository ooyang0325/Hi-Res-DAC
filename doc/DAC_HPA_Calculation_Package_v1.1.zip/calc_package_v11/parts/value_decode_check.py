import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""R9 E-1 cross-check (parts): does the Value field decode from the MPN? UNI-ROYAL 0402WGF/0603WAF (4-digit E96 code),
YAGEO RT/RC (e.g. 07100KL, 072M2L, 0724R9L), SAE 1RC0402F4704, KOA RN73...4811, Samsung CL05C820J / FH 0402CG820J (3-digit pF).
Writes value_decode_out.txt; mismatches are listed for the owning stream."""
import csv, os, re
BASE = _PKG_ROOT + ''
def ohms(v):
    v = v.replace('Ohm', '').replace('ohm', '').replace('Ω', '').replace(' ', '').replace('k', 'K').upper()
    m = re.match(r'([\d.]+)([KMR]?)', v)
    if not m:
        return None
    x = float(m.group(1)); return x * {'K': 1e3, 'M': 1e6, 'R': 1, '': 1}[m.group(2)]
def dec_mpn(mpn):
    m = re.search(r'(?:0402|0603)W[GA][FD](\d{3})(\d)T', mpn)             # UNI-ROYAL 4-digit code
    if m: return int(m.group(1)) * 10 ** int(m.group(2)), 'R'
    m = re.search(r'TC0[1-9](?:05|10|15|25|50)[BCDF](\d{3})([0-6JKLM])T', mpn)   # UNI-ROYAL TC thin film (R9: TC0225B3322TCC)
    if m:
        e = m.group(2); e = int(e) if e.isdigit() else {'J': -1, 'K': -2, 'L': -3, 'M': -4}[e]
        return int(m.group(1)) * 10.0 ** e, 'R'
    m = re.search(r'1RC0[46]0[23]F(\d{3})(\d)', mpn)                       # SAE
    if m: return int(m.group(1)) * 10 ** int(m.group(2)), 'R'
    m = re.search(r'RN73\w*?TTD(\d{3})(\d)', mpn)                          # KOA
    if m: return int(m.group(1)) * 10 ** int(m.group(2)), 'R'
    m = re.search(r'R[TC]0[46]0[23]\w{3,4}?07([\d]+)([KMR])([\d]*)L', mpn)   # YAGEO RT/RC
    if m:
        a, u, b = m.group(1), m.group(2), m.group(3)
        return float(a + ('.' + b if b else '')) * {'K': 1e3, 'M': 1e6, 'R': 1}[u], 'R'
    m = re.search(r'CL0[5-9]C(\d{2})(\d)[JFGK]', mpn) or re.search(r'(?:0402|0603|0805|1206)CG(\d{2})(\d)[JFGK]', mpn)   # C0G caps, pF (R10: FH 0603/1206 too)
    if m: return int(m.group(1)) * 10 ** int(m.group(2)) * 1e-12, 'C'
    return None, None
def farads(v):
    v = v.replace(' ', '').replace('µ', 'u')
    m = re.match(r'([\d.]+)(pF|nF|uF)', v)
    return float(m.group(1)) * {'pF': 1e-12, 'nF': 1e-9, 'uF': 1e-6}[m.group(2)] if m else None
out, bad, n = [], [], 0
for s in ['power', 'protection', 'analog', 'digital']:
    for r in csv.DictReader(open(os.path.join(BASE, s, 'bom_rows.csv'), encoding='utf-8-sig')):
        mpn, val = r.get('mpn', ''), r.get('value', '')
        d, kind = dec_mpn(mpn)
        if d is None:
            continue
        v = ohms(val) if kind == 'R' else farads(val)
        n += 1
        if v is None or abs(v - d) > 1e-6 * max(d, 1e-15) * 1e3:
            bad.append(f"  {s:<10} {r['refs'][:26]:<26} value '{val}' vs MPN {mpn} -> {d:g}")
ALT_RE = re.compile(r'\b(TC0[1-9]\d{2}[BCDF]\d{3}[0-6JKLM]T\w{2}|R[TC]0[46]0[23]\w{3,4}?07\d+[KMR]\d*L|0[46]0[23]W[GA][FD]\d{4}T\w{2})\b')
alt, alt_bad = 0, []
for s in ['power', 'protection', 'analog', 'digital']:          # approved alternates named in the other fields (R9)
    for r in csv.DictReader(open(os.path.join(BASE, s, 'bom_rows.csv'), encoding='utf-8-sig')):
        mpn, val = r.get('mpn', ''), r.get('value', '')
        text = ' '.join(str(x) for k, x in r.items() if k not in ('mpn', 'value') and x)
        for tok in set(ALT_RE.findall(text)) - {mpn}:
            if re.search(r'\d(?:WGF|WAF)', tok) and 'Ohm' not in val and 'ohm' not in val.lower():
                continue
            d, kind = dec_mpn(tok)
            v = ohms(val) if kind == 'R' else None
            if d is None or v is None:
                continue
            alt += 1
            if abs(v - d) > 1e-3 * d:
                alt_bad.append(f"  (alternate, info) {s:<10} {r['refs'][:26]:<26} value '{val}' vs {tok} -> {d:g}")
out.append(f'R9 E-1 value-decode cross-check: {n} lines decoded, {len(bad)} mismatch(es)')
out += bad
out.append(f'approved alternates named in the BOM text: {alt} decoded, {len(alt_bad)} not matching the line value (info only - a text may name the part it replaced)')
out += alt_bad
open('value_decode_out.txt', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print('\n'.join(out))
