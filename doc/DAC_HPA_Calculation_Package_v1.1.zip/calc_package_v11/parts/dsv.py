"""Compact viewer for fetched datasheet text (saved web_fetch output).
usage: python3 dsv.py FILE START END [WIDTH]      -> joined lines START..END (non-empty lines numbering)
       python3 dsv.py FILE -g REGEX [CTX] [MAXHITS] -> hits with CTX following lines, joined
"""
import sys, re, textwrap
f = sys.argv[1]
lines = [re.sub(r'\s+', ' ', l).strip() for l in open(f, encoding='utf-8', errors='replace')]
lines = [l for l in lines if l]
if sys.argv[2] == '-g':
    rx = re.compile(sys.argv[3], re.I)
    ctx = int(sys.argv[4]) if len(sys.argv) > 4 else 3
    mx = int(sys.argv[5]) if len(sys.argv) > 5 else 30
    n = 0; last = -1
    for i, l in enumerate(lines):
        if rx.search(l) and i > last:
            seg = ' | '.join(x[:300] for x in lines[i:i + ctx + 1])
            print(f'[{i}] ' + seg)
            last = i + ctx; n += 1
            if n >= mx: break
else:
    a, b = int(sys.argv[2]), int(sys.argv[3])
    w = int(sys.argv[4]) if len(sys.argv) > 4 else 250
    txt = ' | '.join(lines[a:b])
    print('\n'.join(textwrap.wrap(txt, w)))
