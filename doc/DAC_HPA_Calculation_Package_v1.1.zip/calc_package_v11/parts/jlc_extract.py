"""Extract compact part facts (class, MSL, stock, price, update date) from a saved web_search JSON result.
usage: python3 jlc_extract.py FILE [FILTER_REGEX]
"""
import json, re, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
flt = re.compile(sys.argv[2], re.I) if len(sys.argv) > 2 else None
def walk(items):
    for w in items:
        if not isinstance(w, dict):
            continue
        sub = w.get('Data', {}).get('WebPages') if isinstance(w.get('Data'), dict) else None
        if sub:
            yield from walk(sub)
        elif 'Url' in w:
            yield w
seen = set()
for w in walk(d.get('WebPages', [])):
    url = w['Url']
    if url in seen:
        continue
    seen.add(url)
    s = ' '.join(w.get('Snippets', []))
    if flt and not (flt.search(url) or flt.search(s)):
        continue
    facts = []
    for rx in [r'\b(Basic|Extended|Preferred)\b(?= Manufacturer)', r'MSL Level (MSL ?\w+)', r'Available Order Qty: ?[\d,]+',
               r'In-Stock: ?[\d,]+', r'In Stock: ?[\d,]+', r'Full Reel: \d+ \$[\d.]+', r'Package [^ ]+( \([^)]*\))?',
               r'Description .{0,160}?(?= EasyEDA| ROHS)']:
        m = re.search(rx, s)
        if m:
            facts.append(m.group(0))
    print(url, '|', w.get('UpdatedAt', ''), '|', ' ; '.join(facts))
