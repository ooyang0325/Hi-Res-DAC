"""Copper sizing for the layout package: IPC-2221 trace width vs current, sheet resistance,
via resistance, shared-ground budget for the unbalanced crosstalk target.
Stack-up JLC04161H-7628: outer 1 oz finished (0.035 mm), inner 0.5 oz (0.0152 mm) [JLCPCB impedance page]."""
import math
RHO = 1.72e-8          # ohm m, copper at 20 degC
ALPHA = 0.0039         # /K
T_OUT, T_IN = 35e-6, 15.2e-6
MIL = 25.4e-6

def ipc2221_width(i, dt=10.0, outer=True, t=None):
    k = 0.048 if outer else 0.024
    area_mil2 = (i/(k*dt**0.44))**(1/0.725)
    t = t or (T_OUT if outer else T_IN)
    return area_mil2/(t/MIL)*MIL*1e3   # mm

def sheet_r(t, temp=50.0):
    return RHO*(1 + ALPHA*(temp - 20))/t   # ohm/sq

def via_r(drill=0.3e-3, plating=20e-6, length=1.6e-3, temp=50.0):
    area = math.pi*((drill/2 + plating)**2 - (drill/2)**2)
    return RHO*(1 + ALPHA*(temp - 20))*length/area

lines = []
def log(s):
    print(s); lines.append(s)
log('IPC-2221 width for a 10 degC rise (outer 1 oz / inner 0.5 oz):')
for i in (0.1, 0.25, 0.5, 0.8, 1.0):
    log(f'  {i:4.2f} A: outer {ipc2221_width(i):.2f} mm, inner {ipc2221_width(i, outer=False):.2f} mm')
ro, ri = sheet_r(T_OUT), sheet_r(T_IN)
log(f'sheet resistance at 50 degC: outer {1e3*ro:.2f} mOhm/sq, inner {1e3*ri:.2f} mOhm/sq')
rv = via_r()
log(f'via 0.3 mm drill, 20 um plating, 1.6 mm: {1e3*rv:.2f} mOhm each; 4 in parallel {1e3*rv/4:.2f} mOhm')
# 5V_SYS path: 30 mm of 1.0 mm outer trace at 0.8 A
r = ro*30/1.0
log(f'5V_SYS 30 mm x 1.0 mm outer: {1e3*r:.1f} mOhm -> {1e3*r*0.8:.1f} mV at 0.8 A')
# leg trace 20 mm x 0.5 mm
r = ro*20/0.5
log(f'leg trace 20 mm x 0.5 mm outer: {1e3*r:.1f} mOhm (Zout budget 0.5 Ohm)')
# shared ground budget: crosstalk -75 dB at 32 ohm -> Rshared <= 32 * 10^(-75/20)
rsh = 32*10**(-75/20)
log(f'unbalanced crosstalk -75 dB at 32 Ohm -> shared return <= {1e3*rsh:.1f} mOhm')
r_sleeve = ro*10/3.0 + rv/4
log(f'sleeve return 10 mm x 3 mm outer + 4 vias: {1e3*r_sleeve:.2f} mOhm (shared part must stay << {1e3*rsh:.1f} mOhm)')
open('copper_calc_out.txt', 'w').write('\n'.join(lines) + '\n')
