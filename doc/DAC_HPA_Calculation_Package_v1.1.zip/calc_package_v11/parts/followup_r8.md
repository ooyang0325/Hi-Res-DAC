# Parts stream — R8 integration follow-up (items A–G), 24 Sep 2026

Labels: [DS] datasheet min/max · [DS-typ] typical only · [DS-listing] distributor/maker parametric page (not the datasheet PDF) · [CALC] computed here · [ASSUMP] assumption · [MEAS] must be measured. Stock figures carry the date of the page that was read; recheck at order. "JLCPCB PCBA type" is quoted only where the JLCPCB part page was read.

---

## A. Solid-state output switch (photorelay) to replace K601

Requirement: ≥ 20 V, ≥ 0.3 A, RON max ≤ 0.10 Ω at 25 °C, IFon/IFT max ≤ 3 mA, tOFF max ≤ 1 ms, tON max ≤ 5 ms, SMD, reflow ≥ 255 °C; two 1-Form-A channels (LEG_LP→JACK_LP, LEG_RP→JACK_RP).

| Item | **Toshiba TLP3545A(TP1,F)** | **Panasonic AQV251GA** (AQV251GAX/GAZ = tape) | Panasonic AQV252GA | Toshiba TLP3547 |
|---|---|---|---|---|
| Load voltage | 60 V [DS page] | 30 V (peak AC) [DS] | 60 V [DS] | 60 V [DS] |
| Continuous load current | 4.0 A [DS page] | 3.5 A (A connection) [DS] | 2.5 A (A) [DS] | 5 A (A) [DS] |
| RON max, 25 °C | **0.06 Ω** (IF 5 mA, ION 3 A, t < 1 s) [DS page] | **0.08 Ω** (A conn., IF 5 mA, IL max, < 1 s) [DS]; typ 0.035 Ω | 0.12 Ω (A) [DS] ✗ | 0.05 Ω (A) [DS] |
| RON at 85 °C | curve not read; ≈ ×1.5 → ≈ 0.09 Ω [ASSUMP, typical MOSFET] | curve "RON vs ambient temperature" exists (0–0.2 Ω scale), values not extracted; ≈ ×1.5 → ≈ 0.12 Ω [ASSUMP] | — | — |
| LED trigger/operate current max | **3 mA** (at ION = 1 A) [DS page] | **3 mA** (typ 0.55 mA, IL 100 mA) [DS]; turn-off current min 0.2 mA | 3 mA [DS] | 5.0 mA [DS] ✗ |
| Drive current for guaranteed RON | 5 mA (RON test condition) | 5 mA (RON test condition); recommended IF 5–30 mA [DS] | 5 mA | — |
| LED VF max | 1.64 V [DS-listing, DigiKey "Voltage–Input"] | 1.5 V at 5 mA (typ 1.14 V) [DS] | 1.5 V [DS] | — |
| tON max / tOFF max | 5 ms / **0.5 ms** [DS page] | 5.0 ms / **0.5 ms** (typ 1.1 / 0.1 ms; IF 5 mA, IL 100 mA, 10 V) [DS] | 5.0 / 0.5 ms [DS] | — |
| Off-state leakage max | not read [not verified] | **1 µA** (IF = 0, VL = max) [DS] | 1 µA [DS] | — |
| Output capacitance COFF | **640 pF typ** [DS page] | not in the extracted text [not verified] | — | 850 pF [DS-listing] |
| I/O capacitance | — | 0.8 pF typ, 1.5 pF max [DS] | — | — |
| Operating temperature | −40…110 °C [DS page] | −40…85 °C [DS] | −40…85 °C | — |
| Topology | output "AC, DC" (MOSFET pair, 1-Form-A) [DS-listing]; A-connection pin numbers to be taken from the Toshiba drawing [not verified] | DIP-6: A connection = two MOSFETs in anti-series (common source) between output pins 4–6, AC/DC; B/C = DC connections [DS] | as AQV251G | DIP-8 |
| Package | DIP-6 SMD lead form (6-SMD, 7.62 mm) [DS page/DigiKey] | 6-SMD gull wing (7.62 mm) [DS] | 6-SMD | 8-SMD |
| Stock | DigiKey **28,529** (18 Sep 2026); LCSC: not found | LCSC **C424130: 1** (May 2026); DigiKey 337 (AQV251GA, 21 Sep 2026) / 1,024 (AQV251GAX, Jun 2026) | — | DigiKey (24-week lead time) |
| Verdict | **meets all numeric requirements**; global sourcing | **meets** (RON 0.08 Ω max); 30 V rating ≥ 20 V | fails RON | fails IFT |

Not checked in this pass (time): Toshiba TLP3553A and TLP3543, Omron G3VM low-RON types, IXYS/Littelfuse CPC1709/CPC1706, other LCSC-stocked ≤ 0.1 Ω photorelays. Reflow limits of both recommended parts were not read (Panasonic/Toshiba SMD photorelays are normally 260 °C-rated [ASSUMP]).

**Recommendation A:** Toshiba **TLP3545A(TP1,F)** × 2 (primary; RON 0.06 Ω max, 60 V, tOFF 0.5 ms max, DigiKey stock → JLCPCB global sourcing), Panasonic **AQV251GA** × 2 as second source (same 6-SMD 7.62 mm class of land pattern — confirm pin 4/5/6 assignment on both drawings before sharing one footprint).
* LED drive: RON is guaranteed only at IF = 5 mA, so drive **≥ 5 mA per LED** (not the 3 mA trigger value). Both LEDs in series from 5V_SYS with a current sink of 5–6 mA gives ≈ 5–6 mA total (2 × 1.64 V = 3.3 V ≤ 4.33 V available at VBUS 4.40 V) [CALC]; from 3V3 each LED needs its own resistor (≈ 10–12 mA total).
* Effect on the budget: replaces the ≈ 45 mA relay coil with ≈ 5–6 mA (series LEDs) → **≈ −39 mA** [CALC].
* Output impedance adds ≤ 0.06 Ω (0.08 Ω AQV251GA) at 25 °C, ≈ 0.09–0.12 Ω hot [ASSUMP] — inside the 0.5 Ω target. Switch linearity (THD) is not specified by either maker → **[MEAS]** THD+N at 16/32 Ω with the switch in circuit (drop at 150 mA peak ≤ 9 mV, far below any body-diode conduction).
* tOFF 0.5 ms max replaces the relay's 3–5 ms release, no contact bounce, no dry-switching limit; normally-open → opens on loss of LED current (fail-safe like the relay).

---

## B. Low-power mechanical DPDT signal relay (alternative)

TE Axicom IM coil table (datasheet 108-98001 Rev M, figures at +23 °C, no pre-energisation) [DS]:

| TE part | Coil | Rated V | Operate (must-operate) V | Release V | Coil R (±10 %) | Power | Verdict vs ≤ 70 mW & ≤ 80 % |
|---|---|---|---|---|---|---|---|
| IM21GR | ultra-high sensitive, monostable | 3 | **3.00 (100 %)** | 0.30 | 180 Ω | 50 mW | power ✓, must-operate ✗ |
| IM22GR | ultra-high sensitive | 4.5 | **4.50 (100 %)** | 0.45 | 405 Ω | 50 mW | ✗ (100 %) |
| IM23GR | ultra-high sensitive | 5 | 5.00 (100 %) | 0.50 | 500 Ω | 50 mW | ✗ |
| IM11GR | sensitive | 3 | 2.40 (80 %) | 0.30 | 91 Ω | 100 mW | must-operate ✓, power ✗ |
| IM12GR | sensitive | 4.5 | 3.60 (80 %) | 0.45 | 194 Ω | 100 mW | ✓ %, ✗ power |
| IM02GR / IM03GR | standard | 4.5 / 5 | 3.38 / 3.75 (75 %) | 0.45 / 0.50 | 145 / 178 Ω | 140 mW | ✗ power |

Common IM data [DS]: 2 Form C, contacts PdRu + Au covered (twin), initial contact resistance < 50 mΩ at 10 mA/30 mV, minimum switching voltage 100 µV; operate time typ 1 ms / max 3 ms; **release time max 3 ms without diode, 5 ms with a parallel diode**; bounce max 5 ms; ambient −40…85 °C; thermal resistance < 150 K/W; SMT versions MSL 3; reflow per IEC 61760-1. Max coil voltage is given only as a graph (U/Unom vs ambient) — value not extracted [not verified]. Stock: IM22GR Mouser 1,673 (19 Sep 2026, 31-week lead time); LCSC/JLCPCB not checked.

Temperature correction (pick-up ∝ coil resistance, +0.393 %/K) [CALC]: IM12GR (4.5 V, 80 %) needs 3.98 V at a 50 °C coil and 4.19 V if still +15 K self-heated vs 4.33 V on 5V_SYS at VBUS 4.40 V (+0.14 V); worst coil current at 5.5 V, 0 °C, −10 %: 34.6 mA. IM11GR (3 V) from 3V3D (3.234 V min): 2.80 V needed hot → +0.43 V; worst current at 3.366 V: 45 mA (matches the power stream's ≈ 45 mA).

Not verified in this pass: Panasonic TX-S/TXS2SA and TQ2 high-sensitivity types, Omron G6K-2F-Y 3 V/4.5 V (standard G6K is 100 mW, must-operate 80 %: DigiKey "must operate 4 V" for 5 V), Kemet EC2/EE2, Hongfa HFD3/HFD4.

**Recommendation B:** no monostable DPDT with ≤ 70 mW **and** ≤ 80 % must-operate was found — TE's 50 mW types need 100 % of nominal to operate at 23 °C. The best mechanical option found is the 100 mW sensitive class (≈ 35–45 mA worst case). Use the photorelay (A) instead.

---

## C. X201 replacement, 80.000 MHz, 3.3 V CMOS, current max ≤ 15 mA

| Item | **TXC 7X-80.000MBE-T** (crystal XO) | **SiTime SiT8008BI-xx-33S/E-80.000000** (MEMS) | Kyocera KC3225K80.0000C1GE00 | NDK NZ2520SD 80 MHz | Epson SG-210STF | SCTF SX3M80 (today) |
|---|---|---|---|---|---|---|
| Frequency range | 1–133 MHz [DS] | 1–110 MHz [DS] | 80 MHz part | 1.5–80 MHz [DS] | 1.2–**75** MHz [DS] ✗ | 80 MHz |
| Supply current max | **15 mA** (75–133 MHz, 15 pF) [DS]; 10 mA ≤ 75 MHz | **4.5 mA** at 20 MHz, no load [DS]; 80 MHz value not specified (+C·V·f ≈ 4 mA with 15 pF [CALC]) | 18 mA [DS-listing] ✗ | 1.8–8.5 mA (+25 °C) [DS] | 3.0 mA (60–75 MHz) [DS] | 40 mA [DS-listing] ✗ |
| Jitter | RMS phase jitter **1 ps max** (12 kHz–20 MHz, > 40 MHz) [DS] | RMS phase jitter **0.9 ps max** (0.5 typ), RMS period jitter 3 ps max, f = 75 MHz [DS] | not read | phase noise −136 dBc/Hz @1 kHz, −154 @100 kHz typ at 80 MHz [DS-typ] | not in brief sheet | — |
| Stability | ±50 ppm −40…85 °C (code E) [DS] | ±20/25/50 ppm | ±50 ppm −40…85 °C | ±50 ppm −40…85 °C | ±50 ppm | ±20/±30 ppm |
| Duty | 45–55 % [DS] | 45–55 % [DS] | — | 45–55 % [DS] | 45–55 % [DS] | 45–55 % |
| Pin 1 | OE: high/open = enabled, low = output disabled [DS] | OE (I_OD 4.2 mA max) or ST (standby 4.3 µA max) by part number [DS] | Standby (power down), 5 µA [DS-listing] | Stand-by (3-state), 10 µA [DS] | ST: oscillation stop, 2.7 µA [DS] | OE |
| Start-up | 5 ms max [DS] | 5 ms max [DS] | — | 4 ms max | 3 ms max | — |
| Package | 3.2 × 2.5 mm [DS] | 3.2 × 2.5 / 2.5 × 2.0 [DS] | 3.2 × 2.5 | 2.5 × 2.0 | 2.5 × 2.0 | 3.2 × 2.5 |
| Reflow | 260 ± 10 °C peak, 10 s [DS] | — | — | IR reflow [DS] | — | — |
| Availability | LCSC shows only the 1.8 V variant 7X-80.000M**D**E-T (C2452421); DigiKey 7X-80.000MBB-T (−10…70 °C) not stocked, 19-week lead time | DigiKey programs SiT8008 on demand (global sourcing); some SiT8008 numbers at LCSC | DigiKey 5,342, Mouser 1,960 | datasheet sits in NDK's "discontinued" folder ✗ | 80 MHz not available | LCSC 2,463 |
| Verdict | **meets** (15 mA = limit, not ≤ 10 mA); stock risk | **meets**, ≤ 10 mA likely [ASSUMP]; MEMS close-in phase noise worse than crystal (not quantified) | fails current | discontinued | fails frequency | fails current |

**Recommendation C:** **TXC 7X-80.000MBE-T** (crystal; 15 mA max, 1 ps max jitter, same 3.2 × 2.5 pinout 1 OE / 2 GND / 3 OUT / 4 VDD as X201) through JLCPCB global sourcing; order early. Fallback without layout change: **SiT8008BI-…-33S-80.000000** (ST = standby, 4.3 µA) — lower current, but MEMS; confirm DAC performance [MEAS] (J-test / DNR). Budget effect vs SX3M80: −25 mA (TXC) or ≈ −30 mA (SiT8008) [CALC/ASSUMP].

---

## D. Family oscillators X202 49.152 MHz / X203 45.1584 MHz

**NDK NZ2520SDA confirmed** (NDK PDF 2012E_NZ2520SDA_e and NDK product page) [DS]:
* 20–50 MHz (PDF) / 20–54 MHz (product page); 1.8–3.3 V (3.3 V spec number **NSC5083D**, +3.3 ± 0.33 V); ±50 ppm overall, −40…85 °C; abs max VCC −0.6…+6.0 V; MSL 1 (JEDEC J-STD-020).
* **Current max during operation 15 mA, during standby 35 µA — both specified at +25 °C only** (no over-temperature maxima) [DATA-GAP].
* Pin map: #1 STAND-BY, #2 GND, #3 OUTPUT, #4 VCC. #1 high (≥ 0.7 VCC) or open → output on; low (≤ 0.3 VCC) → output high impedance.
* The NDK text says only "high impedance"; the oscillator-stop is inferred from the 35 µA standby maximum and from DigiKey's function field "Standby (Power Down)" (disable current 35 µA max) [inferred].
* Start-up 4 ms max; symmetry **40–60 %** (acceptable: the CPLD divides by ≥ 2); tr/tf 6 ns max; load 15 pF max; phase jitter 43 fs typ (12 kHz–20 MHz, 49.152 MHz, 3.3 V) [DS-typ].
* Availability: NSC5083D-49.152M — LCSC **C17466132 out of stock** (Oct 2025 page), JLCPCB page: Extended, **Economic and Standard**, MSL 1; DigiKey **3,438** (9 Sep 2026). NSC5083D-45.158M — DigiKey **3,166** (Sep 2026); lead time 24 weeks. → JLCPCB global sourcing.

**SCTF SX3M fallback, pin 1:** DigiKey lists SX3M49.152M20F30TNN with function "Enable/Disable" (not "Standby/Power Down") and no disable current; the SCTF 2CM/3CM sheets describe pin 1 only as enable/disable (Notes 3.3). No oscillator-stop is documented → treat as **output disable with the oscillator running** [ASSUMP]: both family oscillators then draw full current, 2 × 20 mA max [DS-listing].

**Second source with a true stand-by pin:**
* SiTime **SiT8008BI-xx-33S-49.152000 / -45.158400** (MEMS, programmable, ST option): standby 4.3 µA max, Idd 4.5 mA max (20 MHz, no load), duty 45–55 %, start-up 5 ms [DS]; DigiKey-programmed → global sourcing. MEMS phase-noise trade-off as in C.
* Epson **SG-210STF** (crystal, same 2.5 × 2.0 pin map #1 ST̄/#2 GND/#3 OUT/#4 VCC): ST low = **oscillation stop**, output Hi-Z, 2.7 µA max; 2.6 mA max at 40–60 MHz, 45–55 % [DS]. But 45.1584/49.152 MHz are not among its 20 standard frequencies (special order) → not a stocked source.

**Recommendation D:** keep NDK NSC5083D (NZ2520SDA) as chosen; second source SiT8008 with the ST option. Do not rely on the SX3M for the budget. Budget: one running 15 mA + one 35 µA [DS at 25 °C] vs 2 × 20 mA for SX3M.

---

## E. CH32V307 and AGRV2K/AG32 electrical data

CH32V307 (English datasheet CH32V20x_30xDS0, via the per-page mirror github.com/ch32-riscv-ug/ch32-device-data-preview, pages 58–65):

| Parameter | Value | Label |
|---|---|---|
| VDD when USB is used | 3.0–3.6 V (2.4–3.6 V without USB/ETH) | [DS Table 4-2] |
| TJ (suffix 6) | −40…105 °C; TA −40…85 °C | [DS] |
| Run, 144 MHz, external clock | **22.4 mA** all peripherals enabled / 12.4 mA disabled | [DS-typ Table 4-6] |
| Run, 144 MHz, HSI | 22.1 / 12.2 mA | [DS-typ] |
| Run, 72 / 48 MHz (ext. clock) | 11.5/6.5 · 8.0/4.6 mA | [DS-typ] |
| Sleep, 144 MHz | 13.7 / 3.8 mA | [DS-typ Table 4-7] |
| Stop | 110 µA (regulator run) / 30 µA (regulator low-power, RAM low-power) | [DS-typ Table 4-8] |
| Standby | 1.0–2.5 µA (by RAM retention) | [DS-typ] |
| VBAT (LSE + RTC) | 1.8 µA | [DS-typ] |
| USBHS PHY current | **not given** (only the CH32V317 Ethernet PHY has a table, 4-9) | — |

All CH32V307 current figures are "measured parameters" at normal temperature, 3.3 V, with no maxima, so no guaranteed MCU run or suspend current can be taken from the datasheet → keep the budget placeholder and close it by [MEAS]. The Chinese datasheet (wch.cn / openwch) was not obtained in this pass.

AGRV2K / AG32: the AGM AG32 datasheet (AG32_DATASHEET_202303, 108 pages) has §5.1 Absolute maximum ratings, §5.2 Recommended DC characteristics and §5.3 Power consumption at pp. 61–62, but the readable text ends before §5 (tool limit) → **not obtained**. The AGRV2K CPLD datasheet (Rev 3.0) has no electrical tables (TJ −40…85 °C only).

---

## F. 1V3 regulator for DVDD (60 mA, 1.3 V ± 5 %, input 3V3D)

**TI TLV758P (TLV75801PDBVR, SOT-23-5 DBV), adjustable** — datasheet SBVS351D [DS]:

| Parameter | Value |
|---|---|
| Pin-out (DBV) | 1 IN, 2 GND, 3 EN, 4 FB, 5 OUT (Figure 4-2) |
| Abs max | VIN, VEN −0.3…6.5 V; VFB −0.3…2 V; VOUT ≤ VIN + 0.3 V; TJ −40…150 °C |
| ROC | VIN 1.5–6.0 V; VOUT 0.55–5.5 V; IOUT 0–500 mA; COUT ≥ 0.47 µF derated, ≤ 220 µF; TJ −40…125 °C |
| VFB / accuracy | 0.55 V; ±0.7 % (25 °C), **±1 % (TJ −40…85 °C)**, ±1.5 % (−40…125 °C) |
| IFB | 0.1 µA max |
| Dropout, 500 mA, 1.2 ≤ VOUT < 1.5 V | 285 typ / **400 mV max** (−40…125 °C) |
| Ground current | 25 µA typ, 31 µA max (25 °C); **35 µA max** over temperature; shutdown 1 µA max |
| Enable | VEN(HI) ≥ 1.0 V, VEN(LO) ≤ 0.3 V; UVLO rising 1.21–1.47 V |
| **Active output discharge** | pull-down 95 Ω (VIN 6 V) [DS; min/max not read] |
| Thermal | RθJA 176.9 °C/W (DBV) |
| Availability | LCSC **C2877852** (stock not read); szlcsc TLV75801PDBVT 245; DigiKey TLV75801PDBVR 0 (24 Sep 2026) |

Design [CALC]: R1 = 15.0 kΩ (OUT–FB), R2 = 11.0 kΩ (FB–GND), both 0.1 % → VOUT = 0.55 × (1 + 15/11) = 1.300 V. Worst case ±1 % VFB + 0.2 % ratio + IFB × R1 (1.5 mV) → **1.283–1.317 V**, inside ESS 1.235–1.365 V with ≥ 48 mV margin. Dropout: 3.234 − 1.317 = 1.92 V ≫ 0.4 V. Pd = (3.366 − 1.283) × 0.060 = 125 mW → TJ = 50 + 0.125 × 176.9 = **72 °C**. The discharge pull-down gives a defined 1V3 collapse (power stream: DVDD ≤ DVCC ordering).

Also seen: TI TPS7A20 (fixed-output, ±1.5 % max over load/line/temperature, 140 mV max dropout at 300 mA, active discharge, −40…125 °C TJ [DS-listing]) — a 1.3 V fixed option was **not confirmed**. TLV755P (fixed, ±1 % at 85 °C) — 1.3 V option not confirmed.

**Recommendation F:** TLV75801PDBVR + 15.0 kΩ/11.0 kΩ 0.1 % divider; replaces ME6216A13 (25 °C-only data). Buy early (stock uncertain).

---

## G. J101 USB-C receptacle and CC ESD

| Item | **GCT USB4105-GF-A** | **TI TPD2E2U06DRLR** (CC1/CC2) |
|---|---|---|
| LCSC / stock | **C3020560**, 1,236 (Jul 2026); DigiKey 127,933 (24 Sep 2026) | **C1972959**; JLCPCB page: MSL 1, 4,257 available (Apr 2025); DigiKey 87,628 |
| Ratings | **48 V DC, 5 A** (240 W), 16 contacts (USB 2.0), −40…85 °C, 20,000 mating cycles [DS-listing/GCT page] | VRWM **5.5 V**, VBR min 6.5 V, VC 12.4 V typ at Ipp, 5.5 A 8/20 µs, 85 W, IEC ±25 kV contact [DS-listing] |
| Mounting | SMT contacts + **through-hole shell stakes** (0.95 mm; 0.60/1.20 mm variants) [GCT] | SOT-553-5 |
| Drawing | "View Product Drawing / Product Spec" on gct.co/connector/usb4105 (readable PDF) | TI datasheet |
| Soldering | **peak 255 °C (−0/+5 °C), 5 s max** [GCT spec] | — |

Notes: JLCPCB Economic PCBA reflows at a fixed 255 ± 5 °C, so the USB4105 sits exactly at its limit (THIN). Ask JLCPCB whether the peak and time can be held (their profile time above 255 °C may exceed 5 s), or use Standard PCBA (240 ± 5 °C). The through-hole shell stakes are soldered as a THT step (Economic PCBA supports THT). TPD2E2U06: VRWM 5.5 V just meets "≥ 5.5 V"; its capacitance is low (low-capacitance family, value not read) — far below the 100 pF limit. HRO / SHOU HAN alternatives were not re-checked.

**Recommendation G:** J101 = **GCT USB4105-GF-A (C3020560)**, confirming the reflow profile with JLCPCB; CC ESD = **TPD2E2U06DRLR (C1972959)** at J101.

---

## Budget effect of the recommendations (for the power stream) [CALC/ASSUMP]

| Change | Before | After | Δ (max) |
|---|---|---|---|
| K601 → 2 × photorelay, LEDs in series at 5–6 mA | ≈ 45 mA (3 V coil on 3V3D) | ≈ 6 mA | ≈ −39 mA |
| X201 SX3M80 → TXC 7X-80.000MBE-T | 40 mA | 15 mA | −25 mA |
| X202/X203 SX3M (both running) → NDK NZ2520SDA with stand-by | 2 × 20 mA | 15 mA + 0.035 mA | −25 mA |
| **Total** | | | **≈ −89 mA** → 323 mA − 89 mA ≈ **234 mA** vs the 247 mA limit, if the rest of the power stream's budget is unchanged |

The NDK and CH32V307 figures are 25 °C values (NDK) or typicals (WCH), so the ≈ 13 mA margin still rests on [MEAS].

## Not verified (plainly)

Photorelay reflow limits, TLP3545A off-state leakage/VF from the PDF, RON-vs-temperature numbers, AQV251G output capacitance; TLP3553A/TLP3543/G3VM/CPC17xx; Panasonic/Omron/Kemet/Hongfa low-power relays; SiT8008 current at 80 MHz; TXC 7X-80.000MBE-T stock; CH32V307 maxima and USBHS PHY current; AG32/AGRV2K absolute maxima and currents; TLV75801PDBVR LCSC stock; TPD2E2U06 capacitance/leakage; USB4105 land pattern (drawing not opened).

---
---

# Follow-up 2 (R8 integration, 24 Sep 2026)

Same labels as above. Stock figures carry the date of the page read. New files: `pcba_class_scan.py` → `pcba_class_table.csv` + `pcba_class_scan_out.txt` (item 5); datasheet texts `ds/tps2596_SLVSET8A.txt`, `ds/photomos_techinfo.txt`; search copies in `web/`.

**Corrections to Follow-up 1:** (i) TLP3545A LED VF: 1.64 V is the *typical* value; the datasheet maximum is **1.80 V at 10 mA**. (ii) The DigiKey "28,529" for TLP3545A(TP1,F) is uncertain (see 1). (iii) The DigiKey 1,024 pcs were AQV251GA (tube); AQV251GAX (tape) is "not normally stocked" at DigiKey. (iv) Photorelay reflow limits are now known — the Panasonic part is **below** the Economic PCBA reflow temperature.

## 1. Photorelays TLP3545A(TP1,F) and AQV251GA / AQV251GAX

Sources: Toshiba TLP3545A datasheet EN 2023-05 (https://toshiba.semicon-storage.com/info/TLP3545A_datasheet_en_20230526.pdf?did=60318&prodName=TLP3545A) and JA edition for the pin table (…/TLP3545A_datasheet_ja_20230526.pdf?did=60319); Toshiba DIP6(LF1) package page (https://toshiba.semicon-storage.com/ap-en/semiconductor/design-development/package/detail.DIP6%28LF1%29.html); Panasonic AQV251GA spec page (https://industry.panasonic.com/global/en/products/control/relay/photomos/number/aqv251ga); Panasonic HE 1 Form A datasheet ASCTB144E (mirror https://pdf.datasheet.live/b4d380cc/panasonic.co.jp/AQV252G.pdf); Panasonic *PhotoMOS Technical Information* (https://mediap.industry.panasonic.eu/assets/custom-upload/Components/Relays/PhotoMOS/technical_information_photomos_en.pdf).

| Item | **Toshiba TLP3545A(TP1,F)** | **Panasonic AQV251GA (tube 50) / AQV251GAX (tape 1,000)** |
|---|---|---|
| Package | DIP6, lead form LF1 (SMD gull wing), Toshiba code 11-7A801S; W × L × H **7.12 × 10.0 × 3.65 mm**; TP1 = 16 mm tape, 1,500/reel [DS, package page] | DIP6 surface-mount terminal; body 6.4 × 8.8 mm, height ≈ 3.4–3.9 mm [tech info drawing] |
| Pin assignment | **1 anode, 2 cathode, 3 N.C., 4 drain, 5 source, 6 drain** [DS-JA §6 端子配置図] | **1 LED +, 2 LED −, 3 "cannot be used, it is in the internal circuit"** (leave unconnected), **4 / 6 load (A connection, AC/DC)**, 5 common source (B/C connections only) [tech info, wiring table AQV21/22/23/25 (DIP)] |
| Output topology | Two MOSFETs, A connection between 4 and 6 through the common source at 5 (B = one side, 4 A; C = both sides in parallel, 8 A) [DS §8, §13] | Two MOSFETs anti-series (common source, pin 5) between 4 and 6 [DS] |
| Recommended land pattern | Reference land pattern (JEITA ET-7501 Level 3) is published only as a figure + CAD download on the package page — numbers not machine-readable here [not verified] | Pads **1.5 × 1.9 mm, pitch 2.54 mm, 8.3 mm between pad-row centres** (inner pad edges 6.4 mm = body width, outer 10.2 mm) [tech info figure values; the dimension-line assignment is my reading] |
| Common footprint | Toshiba lead-tip span 10.0 mm lies inside the Panasonic pad outer edge (10.2 mm) → one 1.5 × 1.9 mm / 8.3 mm footprint is expected to take both [CALC — confirm against the Toshiba figure before release] | |
| Reflow | Tsol **260 °C (10 s)**; reflow once or twice; all mountings within 2 weeks; Pb-free profile given as a figure (package-surface temperature) [DS §8, §17]; MSL 1 [DigiKey] | IR reflow: preheat 150–180 °C 60–120 s, ≥ 230 °C **≤ 30 s**, peak **≤ 250 °C** (≤ 245 °C for SON/VSSOP) [tech info §14]; DIP is not in the moisture-sensitive list (VSSOP/SON/SSOP/SOP are) [tech info §18] |
| JLCPCB Economic (255 ± 5 °C, fixed) | OK (≤ 260 °C) | **FAIL** — the fixed peak exceeds the maker limit |
| JLCPCB Standard (240 ± 5 °C) | OK | Peak OK; the ≤ 30 s above 230 °C must be confirmed on JLCPCB's profile |
| LED VF | IF 10 mA: **1.50 / 1.64 / 1.80 V** min/typ/max (25 °C); 5 mA: not tabulated (curve only) [DS §12] | IF 5 mA: **1.14 typ / 1.5 max V** (no min); 1.32 V typ at 50 mA; 10 mA: not tabulated (graph ≈ 1.2 V, rough) [DS] |
| LED abs max | IF **30 mA**, −0.3 mA/°C above 25 °C (→ 22.5 mA at 50 °C [CALC]); **VR 6 V**; PD 50 mW; Tj 125 °C; IR ≤ 10 µA at 5 V [DS] | IF **50 mA**; **VR 5 V**; IFP 1 A; Pin 75 mW; Tj 125 °C [spec page] |
| Recommended IF | **5 min / 10 typ / 25 max mA** [DS §9] | 5–10 mA (datasheet), 5–30 mA (spec page) [DS] |
| Trigger / release | IFT 0.3 typ / 3 mA max (ION = 1 A); IFC ≥ 0.01 mA [DS] | IFon 0.55 typ / 3 mA max; IFoff 0.2 min / 0.45 typ mA [DS] |
| RON 25 °C (A conn.) | 35 typ / **60 max mΩ** (ION 3 A, IF 5 mA, t < 1 s) [DS] | 35 typ / **80 max mΩ** (IF 5 mA, IL max, ≤ 1 s) [DS] |
| RON vs temperature | curve only (§16.1) — factor not extractable [not verified] | curve "On resistance vs ambient temperature" (4–6, IF 5 mA) — factor not extractable [not verified] |
| Design allowance [ASSUMP, typical DMOS] | ×1.2 at 50 °C → 72 mΩ; ×1.5 at 85 °C → 90 mΩ | ×1.2 → 96 mΩ; ×1.5 → 120 mΩ (> 0.10 Ω at 85 °C) |
| COFF / CON | COFF **640 pF typ** (0 V, 1 MHz); CON not given [DS] | graph "Output capacitance vs applied voltage" only; value not extracted |
| Off-state leakage | IOFF 0.01 µA typ at 60 V; the max column is not legible in either datasheet extraction [not verified] | ILeak **1 µA max** at VL = 30 V (bounds 4–8 V); graph 10⁻¹²–10⁻⁴ A vs 0–60 V [DS] |
| I/O capacitance | CS **0.8 pF typ** [DS] | Ciso **0.8 typ / 1.5 max pF** [DS] |
| tON / tOFF vs IF | IF 5 mA: 1.2 typ / **5 max ms**; 0.1 typ / **0.5 max ms**. IF 10 mA: 0.5 typ / **3 max ms**; 0.1 / 0.5 ms (RL 200 Ω, VDD 20 V) [DS §15] | IF 5 mA: 1.1 typ / **5.0 max ms**; 0.1 typ / **0.5 max ms** (IL 100 mA, VL 10 V); vs IF only as graphs (0–50 mA) [DS] |
| Output rating | 60 V; 4 A (A), −40 mA/°C above 25 °C → 3.0 A at 50 °C [CALC]; PO 700 mW; Topr −40…110 °C (recommended −40…85 °C) | 30 V (recommended ≤ 24 V); 3.5 A (A); Ipeak 6 A; Pout 600 mW; −40…85 °C |
| Stock (authorized) | **Mouser 15,326** (3 Aug 2026; 15,284 on 17 Aug), factory lead 24 weeks. DigiKey page (18 Sep 2026) prints "In-Stock 28,529" next to the tube alternate "TLP3545A(F" — the through-hole form — while Octopart (5 Aug 2026) listed DigiKey TP1 cut tape 1,056: treat the DigiKey SMD quantity as uncertain. TTI/Avnet/Arrow 0 | **Mouser AQV251GAX 982** (8 Jul 2026, 20-week lead); DigiKey AQV251GAX "not normally stocked", AQV251GA tube 1,024 (Jun 2026) → 337 (21 Sep 2026); LCSC C424130: 1 pc (May 2026). Panasonic PCN "Unification of Dimensional Tolerances" (Dec 2025): use the current drawing |
| JLCPCB | not pre-listed. The Toshiba TLP3547(TP1,F(O) is a listed JLCPCB Global Sourcing part (C5252985), so the TLP3545A should be sourceable the same way by MPN [not verified] | not pre-listed |

Design notes [CALC/ASSUMP]:
* Two LEDs in series at 10 mA: 2 × 1.80 V = 3.60 V (+≈ 0.05 V each at 0 °C, −2 mV/K assumed) → ≈ 0.63 V left for a current sink at 5V_SYS = 4.33 V (VBUS 4.40 V). At 5–8 mA VF is lower. Drive with a **current sink set to 6–8 mA** (≥ the 5 mA recommended minimum and the RON test condition; tON ≤ 5 ms), not a plain resistor.
* The protection BOM now has **four** photorelays (K601–K604): as two series strings the LED current is 2 × 6–8 mA ≈ 12–16 mA, not the ≈ 6 mA used in the Follow-up 1 budget (see budget note).
* Pin 3: no copper connection (Panasonic: internal node). Pin 5: unconnected in the A connection. Keep LED reverse voltage ≤ 5 V (the lower rating) in every power state. Keep a single reflow pass (Toshiba allows two).

**Recommendation 1:** TLP3545A(TP1,F) is the only one of the two that fits Economic PCBA (maker limit 260 °C vs 255 ± 5 °C). AQV251GA(X) is usable **only with Standard PCBA** (240 ± 5 °C) after JLCPCB confirms ≤ 30 s above 230 °C. The protection BOM still lists AQV251GAX × 4 → change it to TLP3545A(TP1,F), or adopt Standard PCBA (item 5). One shared 1.5 × 1.9 mm / 8.3 mm footprint for both, checked against the Toshiba figure.

## 2. X201 TXC 7X-80.000MBE-T

Sources: TXC 7X datasheet (https://txccrystal.com/images/pdf/7x.pdf) and Rev 1.04-a "tight stability" edition (LCSC-hosted https://wmsc.lcsc.com/wmsc/upload/file/pdf/v2/lcsc/2304140030_TXC-Corp-7X-80-000MDE-T_C2452421.pdf); DigiKey https://www.digikey.com/en/products/detail/txc-corporation/7X-80-000MBE-T/7906431; JLCPCB https://jlcpcb.com/partdetail/TXCCorp-7X_80_000MBET/C2452419.

| Item | Value |
|---|---|
| Ordering code | **7X-80.000MBE-T** = 7X series, 80.000 MHz, **B = 3.3 V**, **E = ±50 ppm, −40…+85 °C** (includes 25 °C tolerance, first-year aging, temperature, supply and load), T = tape & reel [DS Rev 1.04-a table: A ±25 ppm −10…70 °C, D ±25 ppm −40…85 °C, E ±50 ppm −40…85 °C]. DigiKey attributes agree (3.3 V, ±50 ppm, −40…85 °C) |
| Supply / current | 3.3 V ± 10 %; **IDD 15 mA max for 75–133 MHz** (10 mA max 1–75 MHz), CL 15 pF [DS]. DigiKey lists "Current – Supply (Max) 20 mA" — conflicts with both datasheet editions [DS-listing] |
| Pin 1 | **Output enable (tri-state), active high**: enabled when pin 1 ≥ 70 % VDD **or open**; output high-Z when ≤ 30 % VDD [DS note 2]. Not a stand-by — the datasheet does not say the oscillator stops |
| Disabled current | not specified (DigiKey "Current – Supply (Disable) (Max): –") |
| Start-up / duty | **5 ms max**; **45–55 %** [DS] |
| Output drive | CMOS, CL ≤ 15 pF, VOH ≥ 0.9 VDD, VOL ≤ 0.1 VDD, **tr/tf ≤ 8 ns (10–90 %)** [DS] |
| Jitter / aging | RMS phase jitter **1 ps max** (12 kHz–20 MHz above 40 MHz); aging ±3 ppm first year [DS] |
| Reflow / MSL | profile peak 260 ± 10 °C, 10 s [DS]; MSL 1 [DigiKey] |
| **Availability** | DigiKey: "available for purchase but **not normally stocked**", manufacturer quote required, standard package 3,000 (pages 30 Sep 2025, 13 Apr 2026). Mouser: no MBE listing; the sister 7X-80.000MBA-T is "Non-Stocked", factory pack 3,000 (5 Aug 2026). 7X-80.000MBD-T: "no longer available at DigiKey". LCSC/JLCPCB C2452419: page exists with no price or stock (cached 2023) and a "Discontinued – no longer manufactured" legend (possibly template text). Only non-authorized brokers show stock (951–5,133). → **availability FAIL for a small build** |

Notes: the 8 ns tr/tf limit covers the whole 1–133 MHz range; at 80 MHz (12.5 ns period, 5.6 ns minimum half-period at 45 %) a part at the limit would not reach full swing → **[MEAS]** XI at U301 through R203. Pin 1 driven by U206 (then 74LVC1G08; now **74LVC1G11GW-Q100H, SOT363-2, 6 pins** — X-10/B-16; rail-to-rail) meets the 70 %/30 % thresholds; R227 10 k defines MCLK while high-Z.

Stocked alternatives checked (none fully compliant):

| Part | Finding |
|---|---|
| Abracon ASEM1-80.000MHZ-LC-T (MEMS, 3.2 × 2.5, 3.3 V, ±50 ppm) | DigiKey **1,012** (13 Sep 2026), Mouser 248; IDD **15 mA max**, pin 1 = stand-by (power-down, **1 µA max**, same high/open = run sense) [DS-listing]; jitter/phase noise not verified — MEMS, so not recommended for the DAC MCLK without [MEAS] |
| Abracon ASE-80.000MHZ-L-R-T (quartz) | 20 mA max; not stocked (1,000 MOQ, 16 weeks) |
| ECS-3225MV | 40 mA max above 66 MHz; 80 MHz not a developed frequency [DS] |
| Epson SG-310SCN 80 MHz | obsolete; Epson's substitute SG-8018CE 80.0000M-TJHSA0 (programmable PLL) DigiKey 0 |
| Kyocera KC3225Z | programmable "short LT" (PLL) type; no 80 MHz stock found |
| Diodes FK3.3V (non-PLL, < 1 ps RMS, stand-by mode) | 80 MHz orderable code and stock not found [not verified] |
| NDK NZ2520SDA | 20–54 MHz only |

**Recommendation 2:** the TXC meets the electrical spec but cannot be bought in small quantity. Choose one: (a) request it now through JLCPCB Global Sourcing or a DigiKey manufacturer quote (3,000-piece MOQ, lead time unknown — budget allows it, schedule may not); (b) keep **SCTF SX3M80.000B20F30TNN** (40 mA max; DigiKey 72,000, LCSC 2,503) and lose the −25 mA; (c) ASEM1 (15 mA max, stocked) only after an MCLK jitter/THD+N measurement. Keep the 3.2 × 2.5 mm 4-pad footprint with pin 1 = enable (high/open = run) — all candidates fit it.

## 3. TPS2596x current limiter

Sources: TI TPS2596 datasheet SLVSET8A (https://www.ti.com/lit/ds/symlink/tps2596.pdf), product page (https://www.ti.com/product/TPS2596), TPS25961 page (https://www.ti.com/product/TPS25961); LCSC/JLCPCB/DigiKey pages linked below.

| Item | **TPS2596 family: TPS259620 / 21 / 30 / 31** | TPS25961 (separate part) |
|---|---|---|
| Package | **HSOIC-8 PowerPAD (DDA) only**, 4.91 × 3.9 mm; no DRV/DDF variant exists [TI ordering table] | WSON-6 2 × 2 mm (DRV) only |
| Variants | **…20**: OV clamp 3.8/5.7/13.8 V (pin-selectable), thermal shutdown **latch-off**; **…21**: OV clamp, **auto-retry** (95 ms); **…30**: adjustable OVLO, latch-off; **…31**: adjustable OVLO, auto-retry [DS Device Comparison]. "TPS25962x/TPS25963x" are these sub-families, not separate parts | one variant, auto-retry; OVP 5.98 V typ fixed or adjustable |
| Pinout (DDA) | 1 GND · 2 dVdt · 3 EN/UVLO · 4 IN · 5 OUT · 6 FLT (open drain, active low) · 7 ILM (RILM to GND; its voltage monitors the load current) · 8 OVLO (…3x divider) / OVCSEL (…2x: GND → 3.8 V, 400 kΩ → 5.7 V, open → 13.8 V) · EP = GND [DS §6] | not read |
| Current limit | ±10.4 % max over 0.125–2 A. RILM 3.83 kΩ → **0.224 / 0.247 / 0.269 A**; 7.87 kΩ → 0.113 / 0.125 / 0.139 A (TA −40…80 °C); 909 Ω → 0.949 / 1.005 / 1.051 A (min/typ/max, VDS 0.5 V, TJ −40…125 °C) [DS §7.5] | ±20 % typ across range, ±18 % max at 1.45 A, 25 °C [TI page] — not precise |
| IQ / shutdown | 193 typ / **259 max µA** (…3x), 206 / 266 µA (…2x); ISD ≤ 1.132 µA [DS] | 130 µA typ |
| RON | 89 mΩ typ; VIN < 4 V row: 97 / 99.8 mΩ at 25 °C, 125.4 mΩ max at −40…85 °C (column assignment as extracted) [DS] | 106 mΩ typ |
| OV clamp (…2x, 400 kΩ) | threshold 5.54 / 5.69 / 5.83 V; output clamped to **5.28 / 5.45 / 5.61 V** (10 mA) → stays below the LM27762 5.8 V abs max (report P-H5) [DS/CALC]; 5 µs typ response | — |
| Other | VIN 2.7–19 V (21 V abs max); UVP rising 2.46–2.58 V; RθJA 52.7 °C/W; **MSL 2-260 °C-1 year** [DS/TI] | MSL 1 |
| LCSC / JLCPCB | **TPS259621DDAR C2155774**: LCSC 371 (10 Jul 2026); JLCPCB **Extended, "Economic and Standard"**, 656 available (17 Sep 2026). **TPS259631DDAR C2155778**: LCSC **3,600** (27 Jun 2026); JLCPCB page not read. …20/…30: not checked | C5571272: LCSC **15** (6 Aug 2026); JLCPCB Extended, Economic and Standard |
| DigiKey | TPS259621DDAR 1,377 (17 Sep 2026); TPS259631DDAR 2,576 (23 Sep 2026); 9-week lead | **0** (5 Sep 2026) |

**Recommendation 3:** use the TPS2596 family (DDA). For 5V_ANA: **TPS259621DDAR** with ROVCSEL = 400 kΩ if the 5.7 V clamp should also guard the LM27762 (P-H5), or **TPS259631DDAR** (adjustable OVLO cut-off, best LCSC stock). Latch-off (…20/…30) only if the power stream wants a latched fault (EN toggle clears it). Not the TPS25961 (stock 15/0, ±20 % limit). Pad: SOIC-8 + exposed pad to GND with vias.

## 4. TLV75801PDBVR (1V3)

| Source | Status |
|---|---|
| LCSC C2877852 | **113,390 in stock** (24 Sep 2026, https://www.lcsc.com/product-detail/C2877852.html) |
| JLCPCB C2877852 | Extended, **"Economic and Standard"**, MSL 1 (https://jlcpcb.com/partdetail/TLV75801PDBVR/C2877852); stock figure not rendered in the fetched page (JLCPCB draws on LCSC stock [ASSUMP]) |
| DigiKey | 0 (24 Sep 2026), 16-week lead |
| Mouser | 454 (22 Sep 2026), 16-week lead |

**Recommendation 4:** availability is good at LCSC/JLCPCB — keep TLV75801PDBVR ("P" = active output discharge; 15.0 k / 11.0 k 0.1 % → 1.283–1.317 V, Follow-up 1 F). No alternative needed.

## 5. PCBA class decision input

JLCPCB capability table (read 24 Sep 2026, https://jlcpcb.com/capabilities/pcb-assembly-capabilities): **Economic** — single side, 2/4/6 layers, 0.8–1.6 mm, single PCB 10 × 10–470 × 500 mm, 2–50 pcs, finish/colour limited, mouse-bite panels only, standard stack-up only, rails and fiducials not necessary, min package 0402, min IC pin spacing **0.4 mm**, reflow **255 ± 5 °C (not adjustable)**, no SPI, AOI yes, X-ray for BGA/QFN/LGA, 1–3 days. **Standard** — single/double side, 1–32 layers, any thickness, single PCB **≥ 70 × 70 mm** (panel 70 × 70–250 × 250), 2–80,000 pcs, any finish, V-cut allowed, any stack-up, **rails and fiducials necessary**, min package 0201, min pin spacing **0.35 mm**, reflow **240 ± 5 °C**, SPI + AOI + X-ray, ≥ 4 days. THT (wave soldering) is offered in both.

Scan of all stream BOMs (power 54, protection 23, analog 26, digital 25 lines) plus the 7 R8 decisions/candidates not yet in them — full table in `pcba_class_table.csv`:

| Category | Parts |
|---|---|
| **Standard-only** | **none** — every JLCPCB page read says "Economic and Standard" (USB4105-GF-A C3020560, TPS259621DDAR, TLV75801PDBVR, TPS25961DRVR, phase-1 pages). The only Standard-only part met so far (Omron G6K) is no longer used |
| **Reflow limit ≤ 255 °C** | **AQV251GA(X)** — protection BOM K601–K604 and the second source: peak ≤ 250 °C → **Economic FAIL**, Standard OK (confirm ≤ 30 s above 230 °C). **GCT USB4105-GF-A** (J101): 255 °C (−0/+5), 5 s max → Economic **at limit**, Standard OK. Not read (assumed 260 °C J-STD-020): J702 HRO PJ-332A-6A, LEDs D705/D706, U202 AGRV2KQ32, U201 CH32V307, X201 SX3M80, D701–D704 |
| **Global sourcing** (no usable LCSC stock) | TLP3545A(TP1,F) (decided); AQV251GA(X) (protection BOM); **TXC 7X-80.000MBE-T** (decided — not obtainable, §2); NDK NZ2520SDA × 2 (X202/X203); OPA2210IDR × 2 (U403/U404); TLV1704AIPWR × 3 (U601–U603, LCSC 61); YAGEO thin film RT0402BRD07121KL, RT0402BRD07115KL, RT0402BRD075K1L (× 5), RT0603WRB071K33L (× 7), RT0603WRB07665RL (× 8), RT0603WRB072KL (× 7) — the analog stream lists in-stock RT0603BRD alternates —, RT0603BRD07698RL (LCSC 120), RT0603BRD07205KL (LCSC 900) |
| Reserve now (thin LCSC/JLCPCB stock) | ES9018K2M (724), CH32V307RCT6 (193 / 364), AGRV2KQ32 (980), J701 (JLCPCB 21 / LCSC 724), KEMET C0603C821J5GACTU (880), GRM1885C1H182JA01D (750–1,900), RT0603BRD079K76L (≈ 1,860) |
| **At an Economic capability limit** | U202 AGRV2KQ32 QFN-32 4 × 4 mm at **0.4 mm pitch = Economic minimum** (Standard 0.35 mm); USB4105 reflow window; J702 and USB4105 flagged "assembly difficulty high"; J701 THT (wave soldering, both classes) and J703 (THT, DNF); ten leadless parts (U102, U501, U504, U301, U401/U402, U202, X201–X203) with no SPI in Economic; ENIG not guaranteed in Economic (finish options limited) |
| Within Economic | 80 × 60 mm; 4-layer JLC04161H-7628 (standard stack-up); 1.6 mm; top side only; smallest package 0402 |

Side check closed: D701–D704 GOODWORK LESD5D5.0CT1G (C41399463) — LCSC **13,650** (24 Sep 2026), SOD-523, bidirectional, VRWM 5 V, VC 16 V, IR 1 µA [DS-listing].

Consequences for this board:

| Aspect | Economic | Standard (whole board) |
|---|---|---|
| Reflow | 255 ± 5 °C fixed → **AQV251GA(X) not allowed**, USB4105 at its limit, 260 °C parts at the J-STD-020 ceiling | 240 ± 5 °C → every part with a known limit is inside it, with 5–20 °C margin |
| Fine pitch / leadless | CPLD at the 0.4 mm minimum; no solder-paste inspection | 0.35 mm minimum; SPI + AOI; X-ray on QFN/LGA in both |
| Board / panel | 80 × 60 mm single board OK; mouse bites only | must be ≥ 70 × 70 mm → **5 mm rails on both 80 mm edges → 80 × 70 mm** (already in `layout_package.md` §11; connectors overhang only the short edges); V-cut allowed |
| Rails / fiducials | optional | mandatory — 3 board fiducials + rail fiducials/tooling holes already planned (§11) |
| Surface finish / stack-up | limited option list (ENIG may not be offered) | no limit (ENIG assured); any stack-up (not needed) |
| Sides | one | one or two (stay top-only: one reflow pass — TLP3545A max 2, ES9018K2M 3, NDK 3) |
| Time / quantity / fees | 1–3 days, 2–50 pcs, lower setup fee | ≥ 4 days, 2–80,000 pcs, higher setup fee (not a constraint) |
| Global-sourced / MSL parts | handled per part at BOM matching [not verified for Economic] | same process; MSL 2/3 parts (TPS2596, CH32V307) baked by JLCPCB [ASSUMP] |

**Recommendation 5: JLCPCB Standard PCBA, top side only, for the whole board.** It removes the one hard failure (AQV251GA peak 250 °C < 255 ± 5 °C), gives margin on the USB4105 reflow window and the 0.4 mm CPLD, adds SPI for the ten leadless parts, and secures ENIG; the rails and fiducials it needs are already in the layout plan, and cost/lead time are not constraints.

Layout-package changes to apply once the class is decided (not yet made in `layout_package.md`): §1 assembly line → Standard PCBA, top side, 80 × 70 mm with rails, reflow 240 ± 5 °C; §12 items 2/4 → Standard profile, add the AQV251GA ≤ 30 s above 230 °C check; Z6 → two (or four) DIP6 SMD photorelays with the shared 1.5 × 1.9 mm / 8.3 mm footprint and the LED current sink instead of relay K601; Z1 → USB4105-GF-A footprint from the GCT drawing.

## Budget note for the power stream [CALC]

Follow-up 1's ≈ 234 mA (vs 247 mA) assumed X201 = 15 mA and ≈ 6 mA for two photorelay LEDs in one string.
* X201: if the TXC cannot be bought and SX3M80 stays → **+25 mA → ≈ 259 mA (fails)**; if the TXC is bought but the DigiKey 20 mA listing is right → ≈ 239 mA.
* Photorelays: four parts as two strings at 6–8 mA → ≈ 12–16 mA → +6…+10 mA → ≈ 240–244 mA (margin 3–7 mA).
* TPS2596: IQ ≤ 0.27 mA (negligible).

## Not verified (Follow-up 2, plainly)

TLP3545A: IOFF maximum, VF at 5 mA, RON-vs-temperature factor, land-pattern numbers (figure only), DigiKey SMD stock, JLCPCB global-sourcing acceptance. AQV251GA: COFF value, VF at 10 mA, RON-vs-temperature factor, JLCPCB's time above 230 °C at 240 °C peak. TXC: disabled current, real MOQ/lead time via JLCPCB, 15 vs 20 mA discrepancy, meaning of the LCSC "discontinued" legend. ASEM1 jitter; a Diodes FK 80 MHz orderable code and its stock. TPS259631DDAR JLCPCB page; TPS259620/630 stock; TPS25961 pinout. JLCPCB displayed stock for TLV75801PDBVR. Reflow limits of J702 (HRO PJ-332A-6A), the KENTO LEDs, AGRV2KQ32, CH32V307, SCTF SX3M and LESD5D5.0CT1G. Whether each global-sourced part is accepted in an Economic order.

---
---

# Follow-up 3 (R8 round 2, 25 Sep 2026)

Scope: (1) X201 per D-3, (2) verification of the new/changed parts, (3) PCBA = JLCPCB Standard, top side (D-14) → `layout_package.md` rewritten, (4) `stress_table.csv` update, (5) PCBA class table + ordering plan. Same labels as above. Every URL read, with its page date, is listed in `web/fu3_sources.txt`. Stock figures carry the page date; recheck at order.

## 1. X201 — Epson SG-210STF 75.0000M (D-3): **not procurable → replaced by the Kyocera KC2520K80 (adopted in D-3 revised, 25 Sep 05:32)**

**Ordering code.** Epson renamed its codes: the old "SG-210STF 75.0000ML3" (tape, 250/reel) is the current "SG-210STF 75.000000MHz L", Epson product number **X1G004171008112**; siblings 75.0000ML (strip, X1G004171008101) and 75.0000ML0 (tape 1,000, X1G004171008114). Code letters: T = 1.8–3.3 V typ supply; **L = ±50 × 10⁻⁶, −40…+85 °C** (J = ±25 ppm −40…85 °C, Y = ±50 ppm −40…105 °C). For 60 MHz < fo ≤ 75 MHz the supply range is 1.71–3.63 V at T_use ≤ 85 °C [DS Epson brief/full data sheet].

**Datasheet maxima** (Epson SG2016/3225/5032/7050CAN & SG-210STF brief sheet © 2025 and full data sheet 2025/6/18):

| Parameter | Value |
|---|---|
| ICC, 3.3 V ± 10 %, 60 < fo ≤ 75 MHz, no load | **3.0 mA max** |
| Stand-by (ST = GND) | **2.7 µA max** (3.3 V) — oscillation stops, output Hi-Z |
| Output disable time t_stp_st (ST H→L) / enable time t_sta_st | **100 ns max / 3 ms max** |
| Start-up (t = 0 at 90 % VCC) | 3 ms max |
| Symmetry (50 % VCC, ≤ 15 pF) | 45–55 % |
| tr / tf (20–80 % VCC, 15 pF, 3.3 V) | 3.0 ns max each |
| VOH / VOL | ≥ 90 % VCC at −4 mA / ≤ 10 % VCC at 4 mA; load ≤ 15 pF |
| ST thresholds | VIH ≥ 80 % VCC, VIL ≤ 20 % VCC; ST must not exceed VCC |
| Frequency ageing | ±3 ppm first year (+25 °C) |
| Phase noise / jitter | typical only: phase jitter 0.16 ps (12 kHz–20 MHz) at 72 MHz, 3.3 V [DS-typ]; D-3's −145 dBc/Hz at 1 kHz, −158 at 100 kHz (48 MHz) [DS-typ] |

**Availability.** DigiKey: all three 75 MHz codes are "**Obsolete and no longer manufactured**" (PCN Obsolescence/EOL "Multiple Devices" 25 Jun 2020; design change 4 Nov 2019; pages 25 Jun–7 Jul 2026). Mouser: lifecycle Obsolete, "restricted availability" (18 May / 15 Aug 2026). LCSC C17388398 (75.0000ML): out of stock (Mar 2025 page). The current Epson full data sheet lists **20 standard frequencies from 4 to 72 MHz** with product numbers — **no 75 MHz code**; other frequencies are special orders ("please contact us"), MOQ/lead time unknown. The only stock seen is a Japanese online lot (Coastaff, "SG-210STF 75.000000MHz L (X1G004171008112)", 150 pcs, MOQ 1, page date unknown, shipping date 17 Apr 2026) — not a channel JLCPCB global sourcing uses; consignment of an EOL lot is not recommended. **72 MHz** (a standard SG-210STF/SG3225CAN/SG2016CAN frequency) fails the ESS rule: 72 / 0.384 = 187.5 < 192 [CALC]. → **SG-210STF 75 MHz fails "procurable in small quantity"**.

**Best stocked alternatives** (crystal-based CMOS SPXO, 73.8–80 MHz, ≤ 10 mA, 45–55 %, pin 1 OE/ST, 2520 or 3225):

| | **1. Kyocera KC2520K80.0000C1GE00** (recommended) | **2. NDK NSC5338D-80M** (= NZ2520SH-80.000M-NSC5004D) |
|---|---|---|
| Type / size | quartz SPXO, K series "Version E", 2.5 × 2.0 × 0.8 mm | quartz SPXO NZ2520SH, 2.5 × 2.0 × 0.9 mm, AEC-Q100/Q200 |
| Frequency / stability | 80.000 MHz, ±50 ppm −40…+85 °C (code G) | 80.000 MHz, ±50 ppm −40…+105 °C |
| Supply | 1.6–3.63 V (3.3 V code: 2.8–3.63 V), 4.0 V abs | 3.3 V ± 0.33 V, 4.0 V abs |
| **Current max** | **8.0 mA at 62.5–80 MHz, 3.3 V, at maximum load (15 pF) and over the operating temperature range** [DS: "all electrical characteristics are defined at the maximum load and operating temperature range"] | **9.0 mA** (70–80 MHz, 3.3 V) at **+25 °C only**, load not stated [DS] → [DATA-GAP] |
| Stand-by | 5 µA max; pin 1 open/H = active, L = High Z **and no oscillation** | 20 µA max (+25 °C); L = high impedance ("Standby (Power Down)") |
| Pin map | #1 E/D (INH), #2 GND, #3 OUT, #4 VCC (= SG-210STF) | #1 STAND-BY, #2 GND, #3 OUTPUT, #4 VCC |
| INH thresholds / timing | VIH ≥ 70 % VCC, VIL ≤ 30 % VCC; **t_dis ≤ 200 ns**; t_ena ≤ 3 ms; start-up ≤ 3 ms | VIH ≥ 0.7 VCC, VIL ≤ 0.3 VCC; disable time not given; start-up ≤ 4 ms |
| Symmetry / edges / load | 45–55 %; tr/tf ≤ 4.5 ns (10–90 %, 3.3 V); VOH ≥ 90 %, VOL ≤ 10 % VCC at 8 mA; ≤ 15 pF | 45–55 %; tr/tf ≤ 5 ns (10–90 %); VOH/VOL 0.9/0.1 VCC; ≤ 15 pF |
| Jitter / phase noise | phase jitter **1.0 ps max** (12 kHz–20 MHz), 1σ 5 ps, p-p 50 ps; phase noise −89/−119/−143/−157/−160/−162 dBc/Hz at 10 Hz…1 MHz, listed at 25 MHz [DS] | family: 90 fs typ at 125 MHz [DS-typ]; 80 MHz AEC sibling END5302A: −156/−157/−158 dBc/Hz at 100 kHz/1 MHz/10 MHz [DS-typ, 2.55 V] |
| MSL / reflow | MSL 1 [DigiKey]; reflow limit not read [ASSUMP 260 °C] | MSL 1; IR reflow lead-free [NDK] |
| Stock | DigiKey **2,964** (5 Aug 2026); Mouser **1,375** + 4,000 due 10 Nov + 6,000 due 30 Dec 2026 (18 Sep 2026); LCSC C1988889 "not available" → **JLCPCB global sourcing**; factory lead 32 weeks | DigiKey **974** (Jul 2026); factory lead 24 weeks → global sourcing |

Rejected on the way: Kyocera KC3225K80 (18 mA [DS-listing]); Kyocera K "Version N" low-phase-noise (14–24 mA at 62.5–80 MHz); NDK NSC5004A-80M (1.8 V only); NDK NZ2520SHA-80M-END5302A (±100 ppm, current given at 2.55 V only; DigiKey 119); ECS-2520S (≤ 55 MHz); TXC 7X-80.000MBE-T (3,000 MOQ, Follow-up 2); SCTF SX3M80 (40 mA, excluded by D-3); Epson SG-8018 (PLL); Epson SG2016CAN/SG3225CAN at 75 MHz (not standard); SiTime/Abracon MEMS (not crystal-based).

Why the Kyocera: the only candidate whose current maximum is guaranteed **loaded and over temperature**, with an oscillation-stop INH and a specified **disable time (200 ns)** that closes the digital stream's `mclk_gate_race` assumption (margin ≥ 4.8 µs for t_dis); largest stock. Its 25 MHz phase-noise listing scaled by 20·log(80/25) = 10 dB gives ≈ −133 dBc/Hz at 1 kHz at 80 MHz [ASSUMP]; integrating −133 dBc/Hz flat over 100 Hz–20 kHz gives ≈ 0.09 ps RMS → jitter-limited SNR ≈ 159 dB for a 20 kHz tone; with the 1.0 ps maximum (12 kHz–20 MHz) the bound is **138 dB** [CALC], both far above DNR ≥ 115 dB — [MEAS] DNR/THD+N at bring-up (J-test).

The digital stream's round-2 BOM (25 Sep 05:19) still carries the Epson with a "PROCUREMENT RISK" note and asks parts/orchestrator to decide; its alternative (TXC 7X-80.000MBE-T) is not procurable either (3,000-piece factory order, Follow-up 2). **Recommendation: X201 = Kyocera KC2520K80.0000C1GE00, second source NDK NSC5338D-80M, both on the unchanged combined land.**

**Consequences (digital/power, messages sent 25 Sep):** MCLK back to **80.000 MHz**: 80 / 0.384 = 208.3 > 192 (+8.5 %); period 12.5 ns; high/low ≥ 5.63 ns at 45:55 (ESS needs ≥ 4.5 ns per D-3); soft start 4096 × 2^(10+1) / 80 MHz = **104.9 ms** (soft_start_time 10); DPLL ratio at 80 MHz. X201 budget: **8.0 mA + R227 0.17 mA = 8.2 mA** (D-3 placeholder 6.5 mA, +1.7 mA on 3V3D); with the NDK second source allow 12.4 mA [ASSUMP 9 mA + C·V²·f 3.2 mA if the 9 mA is unloaded] — D-3 revised sets **12.7 mA**. U206 (74LVC1G11, 3V3D) meets the 70 %/30 % INH thresholds. Land: the combined 2520/3225 land of D-3 is kept (`layout_package.md` §14); paste only on the 2520 area.

## 2. Verification of the new/changed parts

| Part | Package / pins [DS] | Key maxima vs worst case | Reflow vs Standard PCBA (240 ± 5 °C) / MSL | Stock / JLCPCB | Verdict |
|---|---|---|---|---|---|
| **Toshiba TLP3545A(TP1,F)** K601–K604 | **TP1 = lead form LF1 "for surface mount", tape & reel 1,500** (DS §19 ordering table; package 11-7A801S, 7.12 × 10.0 × 3.65 mm). Pins: 1 anode, 2 cathode, **3 N.C.**, 4 drain, **5 source (common)**, 6 drain. The isolation test treats pins 1-2-3 and 4-5-6 as the two terminals → pin 3 belongs to the input side: **solder pad, no trace**; pin 5: **solder pad, no trace** (A connection 4–6) | VOFF 60 V vs ≤ 7.70 V; ION 4 A (3.0 A at 50 °C) vs ≤ 0.3 A; PO 700 mW (525 mW at 50 °C) vs 8 mW; LED IF 30 mA abs (22.5 mA at 50 °C) vs ≤ 7.14 mA; LED PD 50 mW vs 12.9 mW; VR 6 V vs 0 V; RON ≤ 60 mΩ (IF 5 mA, 25 °C); tON ≤ 5 ms (5 mA)/3 ms (10 mA); tOFF ≤ 0.5 ms; IFT ≤ 3 mA; VF 1.50/1.64/1.80 V at 10 mA; IOFF 0.01 µA typ at 60 V (max not legible); COFF 640 pF typ | Tsol **260 °C, 10 s**; reflow once or twice, all passes within 2 weeks → OK (one top-side pass); MSL 1 [DigiKey] | DigiKey **28,529 on the TP1 (SMD) page** (18 Sep 2026; the Follow-up 2 doubt is resolved — the tube TLP3545A(F is a separate listing, 322); Mouser 15,284 (Aug); not in the JLCPCB library → global sourcing | **OK**. The round-1 VBE limiter would drop out with the VF maximum (IF ≈ 5.0 mA, zero margin — flagged to protection); protection's round-2 p05 (05:17) replaces it by a low-dropout **OPA2333 (U604) sink**: IF 5.315–6.599 mA (+6.3 % over 5.0 mA), independent of 5V_SYS down to 4.17 V → closed |
| **TI TPS259621DDAR** U503 | HSOIC-8 PowerPAD (DDA) 4.91 × 3.9 mm: 1 GND, 2 dVdt, 3 EN/UVLO, 4 IN, 5 OUT, 6 FLT, 7 ILM, 8 OVCSEL (left open per power c11: isolated pad), EP = GND | IN 21 V abs vs 5.55 V; EN/FLT 7 V abs vs 3.37 V; RON 131 mΩ max → 31 mW at 0.483 A → TJ 52 °C; into a short ≤ 2.7 W until OTP (157 °C typ), auto-retry 95 ms; RθJA 52.7 °C/W only with the EP soldered (119.8 without) | MSL **2-260C-1 year**, Sn finish [TI] → OK; X-ray the EP | JLCPCB C2155774 Extended, **Economic and Standard**, 656 available (17 Sep 2026); DigiKey 1,377; LCSC 828 (Apr) | **OK** — land: TI DDA pattern, ≥ 5 thermal vias (layout §7/§14) |
| **TI TMUX1101** U505 | **TMUX1101DBVR (SOT-23-5, C1852057)** — package confirmed by power c11 (25 Sep 05:14): 1 D → R510, 2 S → GND, 3 GND, 4 SEL → ILIM_HI, 5 VDD → 3V3M + C515 100 nF | VDD 1.08–5.5 V (6 V abs) vs 3V3M 3.37 V; VS/VD ≤ VDD + 0.5 V vs ILM node ≤ ≈ 0.6 V (TPS2596 off when 3V3M is absent); IDC 120 mA (85 °C) vs 0.4 mA; RON ≤ 9.5 Ω (3.3 V, 85 °C); IS(OFF) ≤ 0.3 nA (85 °C); SEL fail-safe | MSL **1-260C-UNLIM** [TI] | JLCPCB Economic and Standard, MSL 1 (Apr 2026, stock not shown); DigiKey 2,865, Mouser 9,098 (Sep 2026) | **OK** |
| **TI TLV75801PDBVR** U303 | SOT-23-5 (DBV): 1 IN, 2 GND, 3 EN, 4 FB, 5 OUT; active discharge ("P") | VIN 6.0 V ROC vs 3.37 V; VOUT 1.283–1.317 V vs ESS 1.235–1.365 V (+48 mV); Pd 125 mW → TJ 72 °C; COUT: C310 2.2 µF 16 V at 1.3 V ≈ 1.70 µF ≥ 0.47 µF [CALC] | MSL **1-260C-UNLIM** | LCSC 113,390 (24 Sep 2026); JLCPCB Economic and Standard | **OK** |
| **TI TPD2E2U06DRLR** U103 | SOT-5X3 (DRL) 1.6 × 1.2 mm: **1 NC, 2 NC, 3 IO1, 4 GND, 5 IO2** (NC may float or go to GND) | VRWM 5.5 V (IIO < 10 µA), VBR ≥ 6.5 V vs CC ≤ 2.2 V normal, 5.50 V only if a cable shorts CC to VBUS; CL 1.5 typ/1.9 max pF vs the 200–600 pF cReceiver window; IPP 5.5 A (8/20), 85 W; IEC ±25 kV contact | MSL **1-260C-UNLIM** | JLCPCB 4,257 (Apr 2025); DigiKey 87,628 | **OK** (fault case at VRWM → THIN note only) |
| **GCT USB4105-GF-A** J101 | 16-contact USB 2.0 receptacle, SMT tails + **4 through-hole shell stakes (GF-A: 0.95 mm)** + locating pegs; contact names A1…B12 on the GCT drawing | 48 V DC; VBUS 5.00 A, GND 6.25 A, B5 1.25 A, others 0.25 A; 40 mΩ max initial; 20,000 cycles; −40…85 °C | **Peak 255 °C (−0/+5), 5 s max.** JLCPCB lists it as **"SMT Assembly"**, PCBA type "Economic and Standard", difficulty "High", MSL 1 | LCSC C3020560 **out of stock** (14 Sep 2026) → global sourcing (DigiKey 127,933, 24 Sep 2026) | **OK / THIN** (see below) |
| **LESD5D5.0CT1G** D701–D704 (GOODWORK C41399463) | SOD-523, **bidirectional** (non-polar) | VRWM 5 V vs ±3.92 V jack swing (+1.09 V); VBR ≥ 6 V (DigiKey); VC 16 V at 7 A (10/1000 µs), 100 W; IR 1 µA; C 12 pF. LRC original (C383211): bidirectional, VBR 7.8 V, VC 18.6 V at 9.4 A (8/20 µs), 150 W, 15 pF | GOODWORK not stated; LRC MSL 3 | LCSC 13,650 (25 Sep 2026); JLCPCB Economic and Standard | **OK** — no replacement needed; the GOODWORK PDF table is an image (values from the LCSC/DigiKey/JLCPCB listings) |
| **TI TLV1704AIPWR** U601–U603 | TSSOP-14 (PW), LM339 pinout: 1 2OUT, 2 1OUT, 3 V+, 4 1IN−, 5 1IN+, 6 2IN−, 7 2IN+, 8 3IN−, 9 3IN+, 10 4IN−, 11 4IN+, 12 V−, 13 4OUT, 14 3OUT (matches the protection netlist) | VS 36 V ROC/40 V abs vs 7.70 V; inputs (V−)−0.5…(V+)+0.5 V, ±10 mA; RRI (V−…V+); open collector to 36 V above V−; VOS ±2.5 mV (25 °C)/±5.5 mV; IB 15/20 nA; IQ 75 µA/ch (25 °C), **100 µA/ch (−40…125 °C)** → 1.20 mA per rail for three packages | MSL **2-260C-1 year** (TI addendum 20 Aug 2026) | LCSC 61 (24 Sep 2026) → **global sourcing**: DigiKey **6,948** (23 Sep 2026), TLV1704AQPWRQ1 5,658 | **OK** (AVAIL: buy now, low risk) |
| **TI OPA2333AIDR** U604 (new in protection round 2) | SOIC-8, standard dual pinout (confirm in the protection netlist) | VS 1.8–5.5 V, 7 V abs vs V+ ≤ 3.366 V (from RELAY_EN via R664); RRIO; inputs ≤ 164 mV / 0…V+; output ≤ 0.54 mA vs 5 mA [JLC listing, protection p05]; TI datasheet not read by the parts stream | MSL 1 (JLCPCB) | JLCPCB C38732 Extended, Economic and Standard (stock not shown) | **OK** (stock to confirm at order) |
| **Nexperia BAT54S,215** D405–D408 (C47546) | SOT23: **1 A1, 2 K2, 3 K1;A2** [DS v.6 Table 2] | VR 30 V; IF 200 mA; IFRM 300 mA; IFSM 600 mA; Ptot 250 mW (200 mW at 50 °C), Rth(j-a) 500 K/W; VF ≤ 240/320/400/500/800 mV at 0.1/1/10/30/100 mA; IR ≤ 2 µA at 25 V, 25 °C only; Cd ≤ 10 pF | MSL 1 (JLCPCB) | JLCPCB **230,448** (21 Aug 2026), Economic and Standard; LCSC 382,980 | **OK**; leakage at ≈ 1.7 V/50 °C remains [DATA-GAP] (analog, D-17) |
| **TI OPA2210IDR** U403/U404 | SOIC-8 (TI SBOS924H Table 5-2) | (Follow-up 1/report) | MSL 2-260C-1 year | **LCSC 16** (25 Sep 2026); DigiKey 0 (1,626 due 14 Dec, 874 due 21 Dec 2026); Mouser 0 (9,922 due 23 Nov 2026); TI store behind login (1–99 US$4.158; tube OPA2210ID option) | **AVAIL → buy now**: 12 (D-8; 10 needed + 2 spare) of the 16 LCSC pieces into the JLCPCB library — taking all 16 costs little and adds spares |
| **Leg resistors 0.05 %/10 ppm** R401–R416, R438–R445 (YAGEO RT0603WRB07…) | 0603 thin film, 0.1 W, 75 V | (analog) | 260 °C | **1.33 k and 665 Ω: no small-quantity source found** — RT0603WRB071K33L / 665RL "not kept in stock" (DigiKey MOQ 5,000, 20 weeks); Susumu RG1608N-1331/-6650-W-T1 (22 weeks, MOQ 1,000); Panasonic ERA-3ARW1331V (non-stocked, 33–41 weeks). **2.00 k: available** — Panasonic ERA-3ARW202V (0.05 %, ±10 ppm, DigiKey 1,259), Susumu RG1608N-202-W-T1 (16,746) | **FAIL (availability)** for 1.33 k/665 Ω → analog stream: switch those to the approved RT0603BRD 0.1 %/25 ppm alternates (C861196, C861514; in stock) or retune to stocked 0.05 % values (message sent) |
| **0.1 % 0402 thin film out of stock at LCSC** | RT0402BRD07121KL (R607), RT0402BRD07115KL (R608), RT0402BRD075K1L (R628–R631, R639) | power ≤ 1 mW | 260 °C | DigiKey **25,651** (121 k, re-read 25 Sep 2026), 19,542 (115 k), 25,165 (5.1 k) [protection BOM] → global sourcing. In stock at LCSC: 10.0 k C190095, 16.9 k C852560 (6,250), 100 k C852472, 6.8 k RP0402BRD076K8L C33900832 (7,070). Power's round-2 0.1 % 25 ppm 0603 values (BOM 25 Sep 05:36): R509 **Susumu RG1608P-4751-B-T5 4.75 k** (0.1 %, ±25 ppm; power BOM 05:53 — the 4.64 k C861444 applied only to the withdrawn Epson budget; no LCSC line → global sourcing, DigiKey 114,162), R510 RT0603BRD073K83L 3.83 k (C861384, 5,950), R533 RT0603BRD0715KL 15.0 k (C326733, 209,580), R534 RT0603BRD0711KL 11.0 k (C728581, 2,260) — all stocked at LCSC. Protection R641/R642 Vishay PATT0402E24R9BGT1 (24.9 Ω 0.1 % 25 ppm, no LCSC source, DigiKey 3,285 Feb 2026) → global sourcing | **AVAIL (OK)** |

**What JLCPCB Standard PCBA does with the USB4105-GF-A.** The part is in JLCPCB's library as "SMT Assembly" (not "wave soldering"), so it is placed on the SMT line and **reflowed once with the whole top side at the Standard profile, 240 ± 5 °C (peak ≤ 245 °C, i.e. 10 °C below the connector's lowest permitted peak of 255 °C)**; the four 0.95 mm shell stakes do not protrude through the 1.6 mm board, so they cannot be wave-soldered — they are soldered in the same reflow by paste printed over the plated stake holes (pin-in-paste), which the layout must provide (paste on the stake pads). JLCPCB's FAQ says only parts marked "wave soldering" are soldered by hand (THT fee), which does not apply here. Not published by JLCPCB: the dwell time near peak and whether they add a manual touch-up on the stakes → order remark (THIN in `stress_table.csv`). The Standard profile removes the Economic-PCBA conflict (255 ± 5 °C fixed = at the connector limit).

## 3. PCBA (Standard, top side) — consequences for the layout

`layout_package.md` is rewritten (self-contained): stack-up and 90 Ω geometry (unchanged, JLC04161H-7628, W 0.235/S 0.15 mm), placement with the new parts (four TLP3545A between the jacks; TPS2596 PowerPAD with ≥ 5 thermal vias; TLV1704 × 3 in the protection zone with all filter nodes ≥ 10 mm from MCLK/BCLK; TMUX1101 + R509/R510 at the ILM pin; USB4105 + TPD2E2U06 at the connector; X201 Kyocera on the combined 2520/3225 land south of the DAC XI with R203/R227 and U206 beside it), routing rules (USB pair, MCLK ≤ 10 mm guarded, DAC→I/V ≤ 5 mm, jack returns ≥ 4 vias, L/R separation, ESD at the jack contacts), thermal zoning (DAC TA ≤ 70 °C, CPLD TJ ≤ 85 °C, ≥ 15 mm from heat sources), the test-point list (TP701–TP745 incl. N6_H = TP724, DC_PERMIT_N = TP722, RELAY_EN = TP718, N6_CML = TP733, N6_CMR = TP734), fiducials (3 global + local at U202/U201), rails (2 × 5 mm V-cut → 80 × 70 mm panel), X-ray and MSL lists, DFA checks and the pre-layout checklist. No Standard-PCBA blocker remains (`pcba_class_scan_out.txt`: 0 parts with a peak limit < 245 °C or pitch < 0.35 mm).

## 4. Stress table (`stress_table.csv`, `stress_calc.py` → `stress_calc_out.txt`)

168 rows: **106 current** (OK 85, THIN 10, AVAIL 7, DATA-GAP 3, **FAIL 1**) and 62 superseded/resolved rows kept with a `status` column ("superseded: …" / "resolved: …"). Operating conditions of round 2: VPOS 3.789–3.915 V, |VNEG| 3.661–3.781 V (D-6), 5V_SYS ≤ 5.55 V (TPS25200 clamp) and ≥ 4.30 V (D-1).

| Verdict | Items |
|---|---|
| **FAIL** (resolved 05:43, §9) | 0.05 %/10 ppm leg resistors 1.33 k and 665 Ω: not procurable in small quantity (§2) → analog retuned to stocked 1.30 k / 680 Ω |
| THIN | USB4105 reflow dwell (profile to confirm); TPD2E2U06 at VRWM only in the CC-to-VBUS cable fault; U101/U501/U302 VIN above ROC only while the TPS25200 clamps (≤ 5.55 V; abs limits 6.0/5.8/6.0 V); X201 budget 8.2 mA vs the 6.5 mA placeholder; C601–C604 (−19/+10 %) and C608–C611/C616 (−31/+10 %) ranges without the ageing term used by protection; U202 TJ ≈ 56 °C + local rise; U301 TA ≤ 70 °C (zoning) |
| AVAIL | OPA2210 (buy now), TLV1704 (global), X201 Kyocera (global), 0402 0.1 % (global), R641/R642 PATT0402 (global), U202, U301 |
| DATA-GAP | BAT54S leakage at ≈ 1.7 V/50 °C; NDK NZ2520SH (second-source X201) and NZ2520SDA currents at +25 °C only |
| Resolved | TLP3545A LED current at 4.30 V (protection's OPA2333 sink, +6.3 %); PB4 FT over-voltage (R532 → PB4 ≤ 4.50 V at 5.55 V); J101 5 V rating (USB4105 48 V); LP5907 CIN/COUT (2.2 µF: ≥ 1.25/1.43 µF effective); OPA2210/OPA1622 IQ now taken over temperature (load table); U202 0.4 mm pitch (Standard PCBA minimum 0.35 mm); relay pick-up/coil issues (photorelays) |

## 5. PCBA class table (`pcba_class_scan.py` → `pcba_class_table.csv`, `pcba_class_scan_out.txt`)

Re-run on the latest stream BOMs (files of 25 Sep 05:33–05:36 UTC: all four streams at round 2) plus the decision lines no stream BOM carries (only the optional X201 second source NDK NSC5338D-80M). The scan flags stream lines that a decision replaced (STALE): **0** in the final run — power, protection, analog and digital now carry USB4105/TPD2E2U06/TLV75801/TPS259621/TMUX1101, TLP3545A, BAT54S,215 and the Kyocera X201. **No Standard-PCBA blocker** (no part limit below the 245 °C peak, finest pitch 0.4 mm ≥ 0.35 mm). Flags: REFLOW 1 (USB4105 dwell to confirm), PITCH 1 (U202 0.4 mm, fine for Standard), THT 3 (J701 wave; USB4105 stakes pin-in-paste; J703 DNF), GLOBAL 17, LONG-LEAD 6, NO-SOURCE 2 (the 1.33 k and 665 Ω 0.05 % leg resistors), MSL ≥ 2: 7, LEADLESS 10 (X-ray). Global-sourcing lines: TLP3545A × 4, Kyocera KC2520K80, NDK NZ2520SDA × 2, TLV1704 × 3, USB4105, Vishay PATT0402E24R9BGT1 × 2, RT0603WRB legs (1.33 k/665 Ω not obtainable), RT0402BRD 121 k/115 k/5.1 k, RT0603BRD 205 k/698 Ω (thin LCSC stock), OPA2210 (LCSC 16 = the whole supply until Nov/Dec 2026).

## 6. Ordering plan (5 boards) — what to buy now

| Buy now | Qty | Where | Why |
|---|---|---|---|
| OPA2210IDR | 12 (D-8; all 16 if you want spares) | LCSC C1849415 (16 in stock) into the JLCPCB library; backup TI.com | distributors empty until Nov/Dec 2026, no fallback |
| Kyocera KC2520K80.0000C1GE00 (X201) | 20 | JLCPCB global sourcing (DigiKey/Mouser) | replaces the EOL Epson; 32-week factory lead |
| NDK NSC5338D-80M (X201 second source) | 5 | DigiKey (consign or global sourcing) | bring-up comparison / fallback on the same land |
| NDK NZ2520SDA 49.152 / 45.1584 MHz (NSC5083D) | 10 + 10 | JLCPCB global sourcing | no LCSC stock, 24-week lead |
| Toshiba TLP3545A(TP1,F) | 25 | JLCPCB global sourcing (DigiKey 28,529) | not in the JLCPCB library |
| TI TLV1704AIPWR | 20 | JLCPCB global sourcing (DigiKey 6,948) | LCSC 61 |
| Vishay PATT0402E24R9BGT1 (R641/R642, protection round 2) | 20 | JLCPCB global sourcing (DigiKey 3,285, Feb 2026 page) | no LCSC source, 15-week factory lead |
| GCT USB4105-GF-A | 10 | JLCPCB global sourcing (DigiKey 127,933) | LCSC out of stock |
| ES9018K2M, CH32V307RCT6, AGRV2KQ32, G-Switch J701 | 8 each | LCSC / JLCPCB library | single source, thin stock (724 / 364 / 980 / JLCPCB 21) |
| RT0603BRD07205KL (R503), RT0603BRD07698RL (R423–R426) | 20 / 30 | LCSC | thin LCSC stock (900 / 120) |
| **Leg resistors** (analog round 2) | 60 × 1.30 k, 60 × 680 Ω, 60 × 2.00 k (8 of each per board; analog: ≥ 48 each) | JLCPCB global sourcing: Susumu RG1608N-132/-681/-202-W-T1 (DigiKey 157 / 783 / 16,746) + Panasonic ERA-3ARW132V (661) / ERA-3ARW202V (1,259) | 1.30 k stock is thin — order first |
| At the PCBA order | | RT0402BRD 121 k/115 k/5.1 k (global), KEMET 820 pF, Murata 1.8 nF, TPS259621DDAR, TMUX1101DBVR, TLV75801PDBVR + R533/R534 (R534 LCSC 2,260), TPD2E2U06DRLR, OPA2333AIDR (U604) | stocked |

## 7. Interface requests (sent to the running streams on 25 Sep 2026)

* **Digital:** the round-2 BOM (05:34) already carries **X201 = Kyocera KC2520K80.0000C1GE00 (C1988889, global sourcing)**; remaining: soft-start/DPLL numbers at 80 MHz, t_dis 200 ns [DS] in `mclk_gate_race`, 8.2 mA in the digital current table; TP724 = N6_H (protection request), the N2_MCLK_OE pad → TP735.
* **Power:** 3V3D X201 line 8.2 mA (12.7 mA with the NDK second source, D-3 revised). The round-2 BOM (05:36: USB4105, TPD2E2U06, TLV75801 + R533/R534, TPS259621, TMUX1101DBVR, R509 4.75 k Susumu RG1608P-4751-B-T5 (05:53, DigiKey 114,162 → global sourcing), R510 3.83 k, R532) is checked — stock OK (R534 LCSC 2,260 and R503 900: buy with the order).
* **Protection:** the round-2 BOM (05:33: TLP3545A(TP1,F), U604 OPA2333AIDR C38732 LCSC 5,082, R641/R642 Vishay PATT0402E24R9BGT1 by global sourcing, pins 3/5 = NC) is checked; IF ≥ 5.0 mA at 4.30 V is shown by p05 round 2 (+6.3 %); still open: add the ageing term to the C601–C604 and C608–C611 ranges.
* **Analog:** leg-resistor availability (1.33 k/665 Ω 0.05 % not procurable; decide alternates); D701–D704 confirmed bidirectional; buy OPA2210 from LCSC now; D-2 jack nets.

## 8. Not verified (plainly)

* Epson SG-210STF 75 MHz special-order MOQ/lead time (Epson not contacted); the Coastaff lot's date and authenticity.
* Kyocera KC2520K: reflow limit (assumed 260 °C J-STD-020); whether the Mouser-hosted K-series data sheet copy is the latest revision (numbers agree with DigiKey's 8 mA / 5 µA attributes); phase noise at 80 MHz (only the 25 MHz listing exists).
* NDK NSC5338D-80M: load condition and temperature dependence of the 9 mA; close-in phase noise at 80 MHz; disable time.
* TLP3545A: land-pattern numbers (Toshiba CAD file not machine-readable — overlay check in the pre-layout checklist), IOFF maximum, VF at 5 mA and its temperature coefficient.
* USB4105: JLCPCB's Standard-profile dwell near peak and its handling of the stake holes (pin-in-paste is inferred from the "SMT Assembly" classification); GCT footprint dimensions (drawing not opened).
* GOODWORK LESD5D5.0CT1G PDF values (image-only; listings used); the stock figures of the power 0.1 % resistors and of protection's U604/R641/R642 come from their BOM lines (R641/R642 DigiKey 3,285 on a Feb 2026 page — recheck); the OPA2333 datasheet itself (protection figures used); JLCPCB stock of global-sourced parts at order time; the land-pattern numbers of the combined X201 land are derived from maker pitches [ASSUMP] and must be checked against both drawings.

## 9. Update 05:45 — D-3 revised, D-19 and the analog leg retune

* **X201 adopted (D-3 revised):** Kyocera KC2520K80.0000C1GE00 at 80.000 MHz is now the layout part (`layout_package.md` §0/§6/§14 updated), the stress rows are current (supply row now OK against the 8.2 mA budget line; reflow "260 °C × 2" taken from the D-3 revised text), and the PCBA/ordering tables carry it (buy 20 now). **C217 = 10 nF** at the X201 VCC pad (digital BOM: Samsung CL05B103KB5NNNC, C15195) — added to the layout and the stress table. NDK NSC5338D-80M stays a conditional second source with the D-3 budget of **12.7 mA** and bring-up checks (disable time, edges). TXC 7X withdrawn, SX3M80 not approved. The combined 2520/3225 land is unchanged.
* **D-19 check (U206 output now also drives the output-switch permit):** N2_MCLK_OE carries X201 pin 1, R235 100 k, MCU PB1 (readback) and R645 1 k → Q616 gate. DC load ≈ 35 µA ≤ 100 µA → U206 VOH ≥ VCC − 0.1 V ≥ 3.13 V vs the X201 threshold 0.7 × VCC ≤ 2.36 V; the gate edge current through R645 is ≤ 3.4 mA for ≈ 1 µs vs ±50 mA abs max and VOH ≥ 2.2 V even at −12 mA [DS Nexperia 74LVC1G11 Table 7] → **OK** (stress row "U206 (D-19)"). Layout: R645 and R235 sit at the U206 output pad; the R645 → Q616 run (≈ 30–40 mm) goes on L3/L4, ≥ 2 mm from clocks and analog nodes (§10 routing row). Applied in the protection netlist of 05:55 (R645 pin 1 = N2_MCLK_OE); integration check clean (only the retired AMP_EN/DOM_DIS absent).
* **Leg resistors resolved:** the analog BOM of 05:43 replaces the unobtainable 1.33 k/665 Ω 0.05 % parts by Susumu **RG1608N-132-W-T1 (1.30 k)** and **RG1608N-681-W-T1 (680 Ω)** (0.05 %, ±10 ppm; DigiKey 157 + Panasonic ERA-3ARW132V 661, and 783), with RG1608N-202-W-T1 (2.00 k, 16,746) + ERA-3ARW202V; LCSC 0.1 %/25 ppm fallbacks C705738 / C861519 / C728588. Availability FAIL → AVAIL (buy now; the 1.30 k stock is the thinnest).
* **Protection round 2 (05:51–05:55):** U604 OPA2333 now on 3V3D (R664 retired, C622 at pin 8), R641/R642 alt. Yageo RT0402BRD0724R9L; power (05:53): R509 = Susumu RG1608P-4751-B-T5 4.75 k (DigiKey 114,162, global sourcing). OPA2210 output swing for protection's reset-state CM question: (V−)+0.2…(V+)−0.2 V at RL 10 k (also −40…125 °C), (V−)+0.6…(V+)−0.6 V at 600 Ω (25 °C) [DS SBOS924H] → ≥ 3.19 V at VPOS min for loads ≥ 600 Ω (sent to protection/analog).
* **Analog confirmation (R2.14, 05:56):** leg T network retuned to stocked 0.05 %/10 ppm E24 values (1.30 k / 680 Ω / 2.00 k, 8 of each per board), offset 6.24/12.48 mV unchanged, phase margin 51.3°/59.9° re-verified, same 0603 footprints, LCSC 0.1 % fallbacks C705738 / C861519 / C728588; D701–D704 GOODWORK C41399463 with **LRC C383211 as approved alternate** (order by C number); OPA2210 buy 12 (D-8) from the 16 at LCSC. All carried into the stress row, the ordering plan and `layout_package.md` §14.
* **OPA2210 reset-state swing (analog R2.15, 05:59):** load ≈ 830 Ω (3.29–4.07 mA sourced per output), so the 600 Ω row applies: (V+) − 0.6 V = 3.189 V at VPOS min, 25 °C only [DS]; the needed reset-state output is 2.907–3.369 V, so CM(reset) ≥ 2.907 V in every corner (protection uses 2.907 V, still ≥ 0.756 V above CMTH_HI 2.151 V) and the upper corner may soft-clip harmlessly → stress row "U403, U404 (DAC reset state)" OK.
* **Protection p04 re-run (06:44):** CM band 1.512–1.816 V, no-false-trip margins 264/210 mV, reset-state CM ≥ 2.91 V, no threshold/BOM change. The band depends on Rf (R423–R426 698 Ω), the VREF divider (R431/R432) and the leg resistors → these lines are marked **value-locked** in the ordering plan: any sourcing substitute must keep the value and ≤ 0.1 %/25 ppm, and protection is told. Power (06:40): TLV75801 output 1.272–1.325 V incl. line/load (+37 mV to the ESS window, stress rows updated); [note withdrawn by decisions_r9 E-27: the NDK X201 second source needs no R509 change — R509 stays 4.75 k, S3 497.92 mA with the NDK]. Integration check: no issues.
* **Tables re-run** on the BOM files of 05:56–06:45: `stress_table.csv` 172 rows, **109 current: OK 89, THIN 9, AVAIL 8, DATA-GAP 3, FAIL 0**; `pcba_class_scan_out.txt`: STALE 0, NO-SOURCE 0, no Standard-PCBA blocker; ordering plan updated (leg resistors now "buy now" with the new MPNs).


---

# Review round (R8 round 3, `integration/decisions_r8c.md`), 25 Sep 2026 08:30–09:30 UTC

Scope: (1) layout-side fixes independent of the other streams; (2) verification of every part the streams added (BOM/netlists: power 08:57, protection 09:02, analog 09:04, digital 09:10), stress/PCBA tables, ordering plan and layout placement. Progress log: `fix_progress.md`.

## R3.1 Layout-side fixes (item 1) — done
* X201/X202/X203 on **plain 2520 lands**; the combined 2520/3225 land and the SCTF 3225 fallback are gone from `layout_package.md` (§0, §6 Z3, §13, §14, §15). The Kyocera K-series land numbers are only in a drawing that no text copy renders → transferred from the drawing and confirmed at gate G-3 (no assumed numbers in the package).
* **U206 = 74LVC1G11GW-Q100H, SOT363-2, 6 pins** everywhere (1 A, 2 GND, 3 B = N2_AVCC_EN_G, 4 Y, 5 VCC, 6 C).
* **LED polarity** (D705 KT-0805G, D706 KT-0603R): pad 1 = K per the digital netlist; the KENTO drawings are image-only in every copy (LCSC, eeworld, sheetsdata), so maker-text confirmation was **not possible** → physical DMM check at gate G-4 + silkscreen K bar.
* **Formal release gates** §15a: G-1 J101 map, G-2 J701/J702 map (plug in/out, switch-contact check, hole sizes), G-3 1:1 overlay, G-4 polarity, G-5 netlist/BOM freeze, G-6 order release; routing only after G-1…G-4, order only after G-5/G-6. MH1–MH4 / FID1–FID7 designators (B-18).

## R3.2 New parts — verification (datasheet maxima, package/pinout vs netlist, stock, Standard PCBA, reflow/MSL)

| Refs (stream) | Part | Result |
|---|---|---|
| D102 (power) | Littelfuse SMDJ12A, SMC | VRWM 12 V / VBR 13.3–14.7 V / VC 19.9 V @ 150.8 A, 3 kW; U102 IN ≤ 17.0 V (power c16) vs 20 V abs → OK; IR only at 25 °C (≤ 2 µA @ 12 V) → ≤ 8 µA at 5.5 V/50 °C [ASSUMP]; MSL 1, 260 °C class → Standard OK; **JLCPCB C224063** (115 on a Sep 2025 page, "fixture needed"), LCSC 0, DigiKey 5,498 → **AVAIL, buy 10 now**; pin 1 = cathode band → VBUS |
| D103–D105 (power) | Nexperia BAT54,215 | pinout 1 A / 2 NC / 3 K matches; VR 30 V vs ≤ 5.55 V; **C85084** JLCPCB Extended, 202,689 → stocked. **Leakage at 5.5 V/50 °C not specified** (2 µA max at 25 V/25 °C only): my estimate ≈ 12 µA for the three vs power's 10 µA bound → **DATA-GAP, [MEAS]** (suspend S6 already fails on placeholders, L-1) |
| C104, C103, C516, R508, R535, R536 (power) | 100 nF X7R / 100 pF C0G / 10 k / 68.1 k / 30.1 k | OK; missing LCSC codes found: **R535 C11537, R536 C29402** (both Extended, in stock) |
| D411/D412 (analog) | Nexperia PMEG2010AEH,115, SOD123F | VF max 220/290/430 mV @ 10 mA/100 mA/1 A, 25 °C only; at 30 mA/0 °C ≈ 0.29 V [CALC + ASSUMP tempco] vs the 0.30 V model → **THIN** (CM margin 0.283 V not VF-critical); IR 50 µA @ 5 V max → ≈ 0.28 mA at 50 °C (< 1 mA modelled) OK; **LCSC C110921 11,165** (JLCPCB own stock 0 → pre-order); not the JSMSEMI "-JSM" SOD-123 part |
| C442/C443 (analog) | KEMET T520D227M006ATE015 | 3.9 V on 6.3 V (62 %) OK; ESR 15 mΩ; DCL ≤ 138.6 µA (0.1 CV, 25 °C) → power budget item; **MSL 3**, H 2.8 ± 0.3 mm; LCSC C3018564 (53, Nov 2025 page), DigiKey 9,494, 27-week lead → **AVAIL, buy 15 now**; polarity at G-4 |
| C439/C440, R305, C441/R446/R447 DNF, R417–R420 bead alt. (analog) | 2.2 µF / 10 k / DNF / BLM15PX330SN1D | OK; BLM15PX DigiKey 0 until 2 Oct → alternate only |
| U403/U404 on VPOS_IV (analog) | OPA2210 | swing limit 2.889 V < reset target 2.907–3.369 V → saturates (harmless); reset-state CM minimum becomes 2.889 V (still 0.74 V above CMTH_HI 2.151 V) |
| U208 (digital) | Nexperia 74LVC3G34DC,125, VSSOP-8 | pinout matches; Ioff ±2 µA covers the 3V3D-off case; **C548774** LCSC 1,604 (DigiKey/Mouser 0) → **AVAIL, buy 10 now** |
| Q207, R236–R241, C224 (digital) | AO3400A / 0402 passives | OK (Basic); R241 DNF |
| U605 (protection) | TI TLV3402IDR, SOIC-8 | pinout matches; 3V3M ≥ 3.23 V vs 2.7 V min; inputs ≤ 2.7 V (CM to VCC + 5 V); MSL 1; **LCSC C91242 745**; **TI part page: "for new designs, we recommend considering an alternate"** → lifecycle flag, **buy 10 now** (TLV7042 named as a candidate for a later redesign, not evaluated) |
| U606 (protection) | TLV1704AIPWR (4th per board) | OK; **+0.40 mA per rail on VPOS/VNEG** (4 × 100 µA) → D-9 budget line must grow; pin 13 keeps its pad; buy 25 (LCSC 61 covers it) |
| U607 (protection) | Nexperia 74AUP1G17GW,125, SOT353-1 | pinout 1 NC/2 A/3 GND/4 Y/5 VCC matches; 3V3D ≤ 3.37 V vs 3.6 V; **3V3D +3.36 mA** at 80 MHz (protection p10, CPD ASSUMP) — power c17 still carries a 1 mA placeholder on 3V3M; **toggling at the Kyocera 4.5 ns maximum edge not provable** (protection p10; fails safe = "dead"/switch open) → [MEAS]; **LCSC C545626 out of stock**, DigiKey 66,948 → global sourcing, buy 10 now |
| R665 tap (protection) | 1 k at U301 XI | MCLK load 13.1 + 1.29 = 14.4 pF of 15 pF → **THIN**; the 0.3 pF pad/stub share is a layout rule (pad on the XI trace ≤ 1.5 mm from pin 7, stub ≤ 0.5 mm, no via) |
| D609 / D610 (protection) | BAS70-04,215 / BAS70,215 | pinouts match; ratings ≫ use; D609 **C389351** (36,430); **D610 BAS70,215: LCSC 0, JLCPCB 9** → propose **BAS70-04,215 as a drop-in** (pin 1 → 3 is the same diode, pin 2 floats on the NC pad) or global sourcing |
| Q619/Q620, C624/C625/C629, R666–R689, R601–R604 115 k (protection) | AO3400A / C0G / 0402 | ratings OK; **22 M 0402WGF2205TCE (C407703) out of stock**; RT0402BRD07866KL/953KL/330KL/071ML: no LCSC listing found → global sourcing; RT0402BRD07237KL **C852654** (7,520); 82 pF / 1 nF C0G and 115 k / 2.2 M / 4.7 M / 470 k / 2.2 k / 1 M LCSC codes not verified by parts; **high-impedance nodes (22 M/4.7 M/1 M) → THIN board-leakage row**: layout clearances + JLCPCB cleaning remark + [MEAS] at 50 °C/humidity |

Stress table (`stress_calc.py` → `stress_table.csv`): **206 rows, 138 current: OK 107, AVAIL 15, THIN 12, DATA-GAP 4, FAIL 0.** PCBA scan (`pcba_class_scan.py` → `pcba_class_table.csv`): **167 lines; STALE 0, NO-SOURCE 0, Standard-PCBA blockers 0**; GLOBAL 27, LONG-LEAD 8. No new leadless part; finest new pitch 0.5 mm (U208).

## R3.3 Ordering plan — additions (5 boards; full list in `pcba_class_scan_out.txt`)
Buy **now**: TLV1704AIPWR 25 (4/board incl. U606, LCSC 61), U208 74LVC3G34DC 10 (LCSC), D102 SMDJ12A 10 (JLCPCB C224063 or DigiKey), C442/C443 T520D 15 (LCSC 53 or DigiKey), D411/D412 PMEG2010AEH 15 (LCSC), U605 TLV3402IDR 10 (LCSC 745; lifecycle note), U607 74AUP1G17GW 10 (DigiKey), RT0402 866 k/953 k/330 k/1 M 0.1 % 50 total (global sourcing), 22 M 1 % 20 (global sourcing or RC0402FR-0722ML after protection confirms), D610 BAS70 10 only if BAS70-04 is not accepted. At PCBA order: BAT54 (D103–D105), BAS70-04 (D609), R535/R536, the Basic passives. Not now: BLM15PX330SN1D (alternate).

## R3.4 Layout package status
`layout_package.md` updated: §0 round-3 row; §6 placement for every new part (D102 ≤ 5 mm from J101; supervisor U605 + Q619/Q620 near U206 with 3V3A Kelvin taps at the DAC; MCLK tap R665 on the XI trace ≤ 1.5 mm from pin 7; U607/C624/D609/C625/R666 group ≤ 8 mm; U606 beside U603; U208 ≤ 5 mm from U202 pins 9–11; Q207 ≤ 3 mm from RESETB; D411/D412/C442/C443 outside the DAC → I/V corridor; D103–D105 ≤ 3 mm); §8 grounding; §10 routing rows; §11 TP719 re-used (N2_AVCC_EN_G) + TP746–TP753; §13 DFA (MSL 3 polymer bake, NC pads kept, cleaning remark); §14 footprints/pinouts; §15/§15a/§16 lists. Integration check 09:15: only 2 checker-table items (RAIL_EN deleted, ANA_SENSE new interface net).

## R3.5 For the other streams (not messaged; for the orchestrator)
Power: 3V3D +3.36 mA (U607) and VPOS/VNEG +0.40 mA/rail (U606) + C442/C443 DCL; Schottky leakage bound 10 µA is an extrapolation. Protection: D610 BAS70-04 drop-in; 22 M out of stock; four RT0402 values without LCSC stock; TLV3402 lifecycle note; netlist notes "no copper" on NC pins must mean "no trace". Integration: interface table of `check_design.py` (RAIL_EN, ANA_SENSE).

## R3.6 Not verified (plainly)
KENTO LED polarity from maker text (image-only); Kyocera/NDK 2520 land dimensions (drawing only); SMDJ12A/BAT54/PMEG2010AEH/T520 leakage at 50 °C (maker gives 25 °C only); Littelfuse and KEMET reflow profiles not re-read (260 °C class assumed from the series documents); current JLCPCB stock of C224063, C3018564 (pages from 2025); LCSC codes of several protection 1 % resistors and the 82 pF/1 nF C0G parts; 74AUP1G17 CPD and CI maxima (typical only); TLV3402 lifecycle beyond the TI page note.

## R3.7 Update 09:30 — analog R3.12 (C442/C443) and the analog open items
* **C442/C443 = KEMET T495D227K010ATE100** (220 µF ±10 %, 10 V, MnO2 surge-robust, ESR 100 mΩ, D 7343-31, 3.10 mm max), **alternate Kyocera AVX TPSD227K010R0100** (same ratings, D case 3.10 mm max): 3.9 V = 39 % of rated (inside the 50 % MnO2 practice); reverse voltage bounded by the D411/D412 drop (≤ ≈ 0.26 V at 0 °C = 2.6 % of rated) during ramps; **MSL 1** (DigiKey for both; Bürklin "series MSL 1") → the polymer bake remark is gone; same D-case land (no footprint change). **Stock:** KEMET DigiKey 3,860 (3 Sep 2026, 24-week lead), Bürklin 600, LCSC C212677 out of stock; AVX DigiKey 1,534 (25 Sep 2026, 13-week lead) → **buy 15 now** via JLCPCB global sourcing, either maker (AVAIL).
* **DCL rule:** 0.01 CV = **22 µA at 10 V, 25 °C, 5 min** (KEMET listing value 22 µA) — confirmed. The ×10 at +85 °C (×12.5 at +125 °C) is the KEMET/AVX MnO2 convention; the T495 PDF itself was too large for the tool, so this multiplier is **not re-read from the T495 document**. Upper bound at 50 °C without any voltage credit: ×2.6 (log interpolation) → **≤ 57 µA per capacitor**, < 0.5 % of the I/V load.
* **PMEG2010AEH corners** (maker: 25 °C maxima only): VF max 220 mV at 10 mA, 253 mV at 30 mA (log interpolation of 220/290 mV, conservative); tempco −1.5…−1.8 mV/K [CALC, diode equation, typical] → **0 °C: 258–265 mV (10 mA), 291–298 mV (30 mA); 50 °C: 175–182 mV (10 mA), 208–216 mV (30 mA)**. The 0.30 V model value holds with only 2–9 mV at 30 mA/0 °C (THIN) and ≥ 35 mV at 10 mA. **IR at 50 °C:** 50 µA max at 5 V/25 °C × 2^(25/10…25/8) = **0.28–0.44 mA** (≤ 1 mA modelled, OK). [MEAS] VPOS − VPOS_IV at 0 °C and IR at 3.9 V/50 °C on one board.
* **BLM15PX330SN1D** (R417–R420 alternate): 0402, 33 Ω ±25 % at 100 MHz, 3 A, DCR ≤ 22 mΩ, −55…125 °C; **LCSC C160974 22,900 (Mar 2026)**, DigiKey 0 until 2 Oct 2026 → procurable; alternate only, not ordered now.
* Tables re-run: stress 210 rows / 139 current (OK 109, AVAIL 14, THIN 12, DATA-GAP 4, FAIL 0); PCBA scan 167 lines, STALE 0, NO-SOURCE 0, Standard blockers 0.
