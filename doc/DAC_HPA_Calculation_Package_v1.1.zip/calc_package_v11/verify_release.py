#!/usr/bin/env python3
"""verify_release.py - one-command release verification of the calculation package (decisions_r10 F-3).

Run from the package root (the folder that holds INDEX.md):

    python3 verify_release.py              every release calculation (about 20 min on a slow disk)
    python3 verify_release.py --only I1 C17 P18      selected checks (dependencies are added automatically)
    python3 verify_release.py --list       list the checks and exit
    python3 verify_release.py --show-keys  no run: key results found in the shipped outputs vs the document references

What it does
  1. Copies the package (without _verify/) to _verify/run/, so the shipped outputs are never overwritten.
  2. Runs every release calculation there, in dependency order, with the inputs shipped in the package
     (no path outside the package is read; datasheet PDFs are not needed).
  3. Compares
     (a) every file a calculation writes with the shipped file of the same path (line endings and trailing blanks
         normalised, numbers equal within 1 ppm, declared volatile lines such as run times dropped; a written file that
         the package does not ship is a failure), and every captured stdout with its shipped output file;
     (b) the key results with the reference values stated in the documents (design summary, evidence register).
  4. Prints a pass/fail table and writes _verify/verify_release_report.txt and _verify/verify_release_result.json.

Exit status: 0 = every check passes; 1 = any mismatch, error or unshipped output; 2 = everything present passes but a
declared release calculation is not in the package yet (PENDING).
Historical generators (INDEX.md, second list) are not run: they are kept for traceability only.
Needs Python 3.8+ and numpy. Scripts run one at a time (never in parallel); a script that fails at start with
'ModuleNotFoundError' is retried once (a filesystem glitch seen during R10; the retry is noted in the report).
"""
import json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(ROOT, '_verify')
RUN = os.path.join(WORK, 'run')
PKG_VERSION = 'v1.1 (R10)'


def S(cwd, script, *args, capture=None):
    """one step: run `python3 script args` in cwd (package-relative); capture = shipped file that holds its stdout."""
    return dict(cwd=cwd, script=script, args=list(args), capture=capture)


def K(label, path, pattern, expected, tol=0.0):
    """key result: first regex group in `path` (package-relative; 'stdout:<step script>' for a captured stdout).
    expected: number (|got - expected| <= tol), string (exact) or None (the pattern must NOT occur: stale value)."""
    return dict(label=label, path=path, pattern=pattern, expected=expected, tol=tol)


I, PR, PW, AN, DG, PA = 'integration', 'protection', 'power', 'analog', 'digital', 'parts'
CHECKS = [
    # ------------------------------------------------------------------ integration
    dict(id='I1', stream=I, title='Netlist/BOM check incl. the value-from-MPN decode (check_design)',
         steps=[S('.', 'integration/check_design.py', 'power', 'protection', 'analog', 'digital')],
         keys=[K('parts', 'integration/check_result.json', r'"parts": (\d+)', 474), K('nets', 'integration/check_result.json', r'"nets": (\d+)', 247),
               K('pins', 'integration/check_result.json', r'"pins": (\d+)', 1393),
               K('issues', 'integration/check_result.json', r'"summary": \{.*?"issues": (\{\})', '{}'),
               K('value-decoded lines', 'integration/check_result.json', r'"lines": (\d+)', 118)]),
    dict(id='I2', stream=I, title='Value-decode self-test (tests/test_value_decode.py)', steps=[S('integration/tests', 'test_value_decode.py')],
         keys=[K('self-test', 'stdout:test_value_decode.py', r'(PASS)', 'PASS')]),
    dict(id='I3', stream=I, title='BOM/netlist reconciliation: merged BOM + netlist and cross-checks (build_package)',
         steps=[S('integration', 'build_package.py')], needs=['I1'],
         keys=[K('pin rows', 'integration/build_package_out.txt', r'pin rows (\d+)', 1445), K('nets', 'integration/build_package_out.txt', r'\| nets (\d+)', 247),
               K('BOM lines', 'integration/build_package_out.txt', r'BOM: lines (\d+)', 179), K('refs', 'integration/build_package_out.txt', r'\| refs (\d+)', 474),
               K('fitted parts', 'integration/build_package_out.txt', r'fitted parts (\d+)', 462), K('DNF', 'integration/build_package_out.txt', r'DNF (\d+)', 9),
               K('unique MPNs', 'integration/build_package_out.txt', r'\(MPN\) (\d+)', 115),
               K('SMT joints', 'integration/build_package_out.txt', r'SMT joints per board (\d+)', 1339),
               K('THT joints', 'integration/build_package_out.txt', r'THT joints per board (\d+)', 18),
               K('BOM refs not in netlist', 'integration/build_package_out.txt', r'BOM refs not in netlist: (\S+)', 'none'),
               K('netlist refs not in BOM', 'integration/build_package_out.txt', r'netlist refs not in BOM[^:]*: (\S+)', 'none'),
               K('pin-count mismatches', 'integration/build_package_out.txt', r'pin-count mismatches BOM vs netlist: (\S+)', 'none'),
               K('duplicate designators', 'integration/build_package_out.txt', r'duplicate designators: (\S+)', 'none'),
               K('retired designators reused', 'integration/build_package_out.txt', r'retired designators reused: (\S+)', 'none'),
               K('no unresolved sourcing placeholder in the merged BOM', 'integration/bom_merged.csv', r'(TBC \(parts\))', None),
               K('no superseded Default-need text in the merged BOM (final 178.96 mA / +1.09 mA)', 'integration/bom_merged.csv', r'(178\.8\d mA|\+1\.2\d mA)', None)]),
    dict(id='I3b', stream=I, title='Independent BOM <-> netlist reconciliation of the merged files (this script)', internal='reconcile', needs=['I3'],
         keys=[]),
    dict(id='I4', stream=I, title='Change lists vs v0.6, vs the v0.9 set and vs the v1.0 release (build_changes)', steps=[S('integration', 'build_changes.py')], needs=['I3'],
         keys=[K('every vs-v1.0 row carries an R10 reason', 'stdout:build_changes.py', r'rows without an R10 reason: (\S+)', 'none')]),
    dict(id='I5', stream=I, title='Cost report (cost_calc) - an estimate until the supplier orders and the JLCPCB quote exist',
         steps=[S('integration', 'cost_calc.py')], needs=['I3'],
         keys=[K('order total US$', 'integration/cost_report.md', r'Total per 5-board order[^|]*\|\s*\*\*([\d,.]+)\*\*', 949.43, 0.005),
               K('order total NTD', 'integration/cost_report.md', r'Total per 5-board order[^|]*\|[^|]*\|\s*\*\*([\d,]+)\*\*', 30125, 0.5),
               K('per board US$', 'integration/cost_report.md', r'Equivalent per assembled board[^|]*\|\s*\*\*([\d,.]+)\*\*', 189.89, 0.005),
               K('F-6 estimate wording', 'integration/cost_report.md', r'(estimate until the supplier orders and the JLCPCB quote exist)',
                 'estimate until the supplier orders and the JLCPCB quote exist')]),
    dict(id='I6', stream=I, title='Evidence register: classes derived from the recorded inputs, strict guards (build_evidence_register --strict)',
         steps=[S('integration', 'build_evidence_register.py', '--strict')],
         keys=[K('register rows', 'stdout:build_evidence_register.py', r'evidence_register.csv: (\d+) rows', 120),
               K('class counts', 'stdout:build_evidence_register.py', r"rows; class (\{[^}]*\})", "{'-': 5, 'E': 80, 'G': 13, 'Q': 22}"),   # R11: R-70 G -> open process item (SE-8)
               K('open Q obligations', 'stdout:build_evidence_register.py', r'open qualification obligations: (\d+)', 22),
               K('stream lists pending', 'stdout:build_evidence_register.py', r'pending: (\S+)', 'none')]),
    # ------------------------------------------------------------------ protection
    dict(id='P02', stream=PR, title='Plug/adapter isolation cases (p02)', steps=[S('protection', 'p02_connection_cases.py')], keys=[]),
    dict(id='P04', stream=PR, title='I/V common-mode window (p04)', steps=[S('protection', 'p04_cm_monitor.py')], keys=[]),
    dict(id='P05', stream=PR, title='Photorelay drive, node H, switch times (p05)', steps=[S('protection', 'p05_switch_drive.py')], keys=[]),
    dict(id='P06', stream=PR, title='DC-sense networks and firmware tiers T1-T3 (p06)', steps=[S('protection', 'p06_dcsense_tiers.py')], keys=[]),
    dict(id='P07', stream=PR, title='Stream-guard proofs (p07, p15 OD-1, p16, p16b)',
         steps=[S('protection', 'p07_stream_guard.py'), S('protection', 'p15_od_guard.py'), S('protection', 'p16_od_p2_scan.py'),
                S('protection', 'p16b_od_p4_scan.py')], keys=[]),
    dict(id='P09', stream=PR, title='ADC2 sampling of the sense channels (p09)', steps=[S('protection', 'p09_adc_sampling.py')], keys=[]),
    dict(id='P10', stream=PR, title='DAC-supply / MCLK supervisor, boot self-test windows (p10)', steps=[S('protection', 'p10_supervisor.py')], keys=[]),
    # R10 F-1 (r10-protection-2, 07:42 / 07:54): the release successor of p18 (p18 and the leg-window scripts p03 / p11 / p17 are historical)
    dict(id='P21', stream=PR, title='R10 F-1 history-robust hardware protection: OR / LPW detectors + E-3 from every state, energies, content boundary, tiers, BOM rows, 32 ohm frozen-FS study (p21, p21b, p21c, p21d, p22)',
         slow=True, steps=[S('protection', 'p21_r10_f1.py'), S('protection', 'p21b_r10_content.py'), S('protection', 'p21c_r10_tiers.py'),
                           S('protection', 'p21d_r10_bom.py'), S('protection', 'p22_r10_fs32.py')],
         keys=[
               K('T_P min ms', 'protection/p21_r10_f1_out.txt', 'T_P = ([\\d.]+) \\.\\.\\.', 19.5, 0.005),
               K('T_P max ms', 'protection/p21_r10_f1_out.txt', 'T_P = [\\d.]+ \\.\\.\\. ([\\d.]+) ms', 23.37, 0.005),
               K('T_P2 max ms (LPW)', 'protection/p21_r10_f1_out.txt', 'T_P2 = [\\d.]+ \\.\\.\\. ([\\d.]+) ms', 68.5, 0.005),
               K('balanced +-x 16 ohm worst mJ (R-23)', 'protection/p21_r10_f1_out.txt', 'balanced \\+-x 16 ohm .*?worst ([\\d.]+) mJ', 25.7, 0.005),
               K('balanced +-x 32 ohm worst mJ (R-23)', 'protection/p21_r10_f1_out.txt', 'balanced \\+-x 32 ohm .*?worst ([\\d.]+) mJ', 14.87, 0.005),
               K('32 ohm at the released swing limit mJ', 'protection/p21_r10_f1_out.txt', 'RELEASED swing limit .*?: ([\\d.]+) mJ', 13.67, 0.005),
               K('single leg rail-stuck 16 ohm worst mJ (R-22)', 'protection/p21_r10_f1_out.txt', 'single leg \\+ .*? 16 ohm: worst ([\\d.]+) mJ', 26.4, 0.005),
               K('DC +1.0 V removed ms (R-21)', 'protection/p21_r10_f1_out.txt', 'DC \\+1\\.0 V: removed <=\\s+([\\d.]+) ms', 101.3, 0.005),
               K('DC +2.0 V removed ms (R-20)', 'protection/p21_r10_f1_out.txt', 'DC \\+2\\.0 V: removed <=\\s+([\\d.]+) ms', 27.1, 0.005),
               K('requirement level floor V per leg (R-74, rounded up over 0.33401 V)', 'protection/p21_r10_f1_out.txt', 'floor ([\\d.]+) V per leg', 0.34, 0.0005),
               K('F-1 net VPOS load mA', 'protection/p21_r10_f1_out.txt', 'net: VPOS ([+\\-\\d.]+) mA', 0.054, 0.005),
               K('DC +-1.0 V removed ms, rail-bounded b3 (R-21)', 'protection/p21_r10_f1_out.txt', 'DC \\+-1\\.0 V removed <=\\s+([\\d.]+) ms', 102.7, 0.005),
               K('20 Hz sine margin % at 2.325 V (R-26)', 'protection/p21b_r10_content_out.txt', 'calibrated \\+ G drift 2\\.325 V\\s+: pair .*?margin ([\\d.]+) %', 4.3, 0.005),
               K('20 Hz sine margin % at the -4.5 dB default', 'protection/p21b_r10_content_out.txt', '-4\\.5 dB default, model 1\\.828 V\\s+: pair .*?margin ([\\d.]+) %', 13.9, 0.005),
               K('FS square mutes certainly <= Hz', 'protection/p21b_r10_content_out.txt', 'certain <= ([\\d.]+) Hz, possible', 21.4, 0.005),
               K('FS square may mute up to Hz', 'protection/p21b_r10_content_out.txt', 'FS square 2\\.325 V\\s+: may mute up to ([\\d.]+) Hz', 25.6, 0.005),
               K('boot self-test, all channels every boot s (R-57)', 'protection/p21b_r10_content_out.txt', 'all channels every boot ([\\d.]+) s', 3.68, 0.005),
               K('boot self-test, rotating within 4 boots s', 'protection/p21b_r10_content_out.txt', 'within 4 boots\\) ([\\d.]+) s', 2.96, 0.005),
               K('tier T3 pair removal s (R-24)', 'protection/p21c_r10_tiers_out.txt', '\\(pair\\) within ([\\d.]+) s', 2.36, 0.005),
               K('below-floor pair energy 16 ohm mJ at the 0.68 V floor (R-24)', 'protection/p21c_r10_tiers_out.txt', 'pair \\(balanced \\+-x\\)\\s+16 ohm: worst\\s+([\\d.]+) mJ', 17.4, 0.005),
               K('protection BOM parts', 'protection/p21d_r10_bom_out.txt', 'BOM \\d+ lines \\((\\d+) parts\\)', 210, 0.005),
               K('32 ohm frozen-FS physics floor mJ (A-45)', 'protection/p22_r10_fs32_out.txt', 'physics floor ([\\d.]+) mJ', 14.55, 0.005),
               K('Default-mode frozen-code worst mJ (U503 cap, A-45)', 'protection/p22_r10_fs32_out.txt', r'worst over frozen codes .*?: ([\d.]+) mJ', 11.10, 0.005),
               K('TOTAL terminal energy 32 ohm balanced one-leg-stuck at 4.049 V, ISC credit (R-22 definition item) mJ', 'protection/p22_r10_fs32_out.txt', 'stuck 4\\.049 V, removal [\\d.]+ ms, 32 ohm: .*?\\(([\\d.]+) mJ with the partner-leg current limit', 24.08, 0.005),
               K('TOTAL 16 ohm balanced one-leg-stuck, High, no ISC credit, U503 cap (R-22) mJ', 'protection/p22_r10_fs32_out.txt', 'balanced 16 ohm, one leg stuck at 4\\.049 V, FS partner content, NO partner current-limit credit, U503 cap .*?worst TOTAL ([\\d.]+) mJ', 23.85, 0.005),
               K('no false trip in the content runs', 'protection/p21b_r10_content_out.txt', '(trip: YES)', None),
               K('every case inside its limit', 'protection/p21b_r10_content_out.txt', '(NOT INSIDE)', None)]),
    # ------------------------------------------------------------------ power
    dict(id='C22', stream=PW, title='E-16 suspend power cut: TPS70933, Q507, attach regions, S6 (c22)', steps=[S('power/calc', 'c22_e16_suspend_cut.py')],
         keys=[K('S6 mA', 'power/calc/c22_e16_suspend_cut.out.txt', r'S6 = ([\d.]+) mA', 2.2755, 0.00005),
               K('attach region A uC', 'power/calc/c22_e16_suspend_cut.out.txt', r'-> ([\d.]+) uC \(\d+ % margin\)', 29.6, 0.05),
               K('attach region B uC', 'power/calc/c22_e16_suspend_cut.out.txt', r'= ([\d.]+) uC \(60 % margin\)', 20.1, 0.05),
               K('3V3M min V', 'power/calc/c22_e16_suspend_cut.out.txt', r'3V3M static ([\d.]+) \.\.', 3.207, 0.0005)]),
    dict(id='C03', stream=PW, title='Round-2 USB inventory feeding c17 (c03)', steps=[S('power/calc', 'c03_usb_budget_ilim.py')], keys=[]),
    dict(id='C16', stream=PW, title='Round-3 review fixes: attach, C104, VBUS kick, ANA_SENSE, X-1 start (c16; reads c17_basis.json)', slow=True,
         steps=[S('power/calc', 'c16_r3_review_fixes.py')], needs=['C17'],
         keys=[K('no round-2 High limit 390.4 mA', 'power/calc/c16_r3_review_fixes.out.txt', r'(390\.4)', None),
               K('runs on the c17 basis', 'power/calc/c16_r3_review_fixes.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)')]),
    dict(id='C17', stream=PW, title='USB states S1-S6 and the U503 limits; writes c17_basis.json, the one input set of the power consumers (c17)',
         steps=[S('power/calc', 'c17_budget_r3.py')], needs=['C22', 'C03'],
         keys=[K('S1 mA', 'power/calc/c17_budget_r3.out.txt', r'S1\s+([\d.]+) mA', 82.40, 0.005),
               K('S2 mA', 'power/calc/c17_budget_r3.out.txt', r'S2\s+([\d.]+) mA', 344.39, 0.005),
               K('S3 mA', 'power/calc/c17_budget_r3.out.txt', r'S3\s+([\d.]+) mA', 493.46, 0.005),
               K('S3f mA', 'power/calc/c17_budget_r3.out.txt', r'S3f\s+([\d.]+) mA', 359.72, 0.005),
               K('S4 mA', 'power/calc/c17_budget_r3.out.txt', r'S4\s+([\d.]+) mA', 760.77, 0.005),
               K('S5 mA', 'power/calc/c17_budget_r3.out.txt', r'S5\s+([\d.]+) mA', 352.53, 0.005),
               K('Default IOS min mA', 'power/calc/c17_budget_r3.out.txt', r'R509 = 4\.75 k.*?IOS ([\d.]+)/', 180.05, 0.05),
               K('Default need mA (A-35)', 'power/calc/c17_budget_r3.out.txt', r'Default need[^0-9]{0,40}([\d.]+) mA', 178.96, 0.005),
               K('IOS min - need mA (A-35)', 'power/calc/c17_budget_r3.out.txt', r'IOS min - need = \+([\d.]+) mA', 1.09, 0.005)]),
    dict(id='C21', stream=PW, title='R9 power checks (c21): E-5, E-8, brown-out margin, E-6 Default numbers', steps=[S('power/calc', 'c21_r9_checks.py')],
         needs=['C17'],
         keys=[K('no stale R509 4.81 k', 'power/calc/c21_r9_checks.out.txt', r'(4\.81 ?k)', None),
               K('no stale 490.80 mA', 'power/calc/c21_r9_checks.out.txt', r'(490\.80)', None),
               K('no stale 177.9 mA', 'power/calc/c21_r9_checks.out.txt', r'(177\.9 ?mA)', None)]),
    dict(id='C02', stream=PW, title='Attach inrush regions (c02)', steps=[S('power/calc', 'c02_attach_inrush.py')], keys=[]),
    dict(id='C20', stream=PW, title='VE checks: U102 IOS with R108 100 k, R109 470 k, ANA_SENSE (c20)', steps=[S('power/calc', 'c20_ve_checks.py')],
         needs=['C17'], keys=[]),
    dict(id='C18', stream=PW, title='Rail start-up with the X-8 reservoirs (c18: four appended runs, as power generates it)', slow=True, needs=['C17'],
         clear=['power/calc/c18_x8_rail_start.out.txt'],
         steps=[S('power/calc', 'c18_x8_rail_start.py', '10', 'reduced'), S('power/calc', 'c18_x8_rail_start.py', '470', 'reduced'),
                S('power/calc', 'c18_x8_rail_start.py', '10', 'timing'), S('power/calc', 'c18_x8_rail_start.py', '470', 'timing')],
         keys=[K('runs on the c17 basis', 'power/calc/c18_x8_rail_start.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)')]),
    dict(id='C06', stream=PW, title='Discharge times (c06)', steps=[S('power/calc', 'c06_discharge.py')], keys=[]),
    dict(id='C11', stream=PW, title='U503 TPS2596 limits (c11; reads c17_basis.json)', steps=[S('power/calc', 'c11_u503_tps2596.py')], needs=['C17'],
         keys=[K('runs on the c17 basis', 'power/calc/c11_u503_tps2596.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)')]),
    dict(id='C04', stream=PW, title='Regulator margins, thermal, VBUS sense, LM27762 envelopes (c04, c10, c09, c15)',
         steps=[S('power/calc', 'c04_regulators.py'), S('power/calc', 'c10_thermal.py'), S('power/calc', 'c09_vbus_sense.py'),
                S('power/calc', 'c15_lm27762_headroom.py')], needs=['A1', 'C17'],   # c15 reads analog/out/headroom_table.csv; all read c17_basis.json
         keys=[K('c04 on the c17 basis', 'power/calc/c04_regulators.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)'), K('c10 on the c17 basis', 'power/calc/c10_thermal.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)'),
               K('c15 on the c17 basis', 'power/calc/c15_lm27762_headroom.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)')]),
    dict(id='C14', stream=PW, title='Hard-unplug rail ordering, brown-out before the MCU reset (c14)', slow=True,
         steps=[S('power/calc', 'c14_unplug_order.py')], needs=['C17'],
         keys=[K('no round-2 High limit 390.4 mA', 'power/calc/c14_unplug_order.out.txt', r'(390\.4)', None),
               K('runs on the c17 basis', 'power/calc/c14_unplug_order.out.txt', r'(BASIS: R10 final \(c17_basis\.json\))', 'BASIS: R10 final (c17_basis.json)')]),
    # ------------------------------------------------------------------ analog
    dict(id='A1', stream=AN, title='Analog budget and offset: levels, swing, E-4 offset split, Default need (analog_budget, r2_power, r9_fixes)',
         steps=[S('analog/scripts', 'analog_budget.py'), S('analog/scripts', 'r2_power.py'), S('analog/scripts', 'r9_fixes.py')],
         keys=[K('offset G unbalanced mV (fitted mixed network)', 'analog/out/analog_budget.txt', r'FITTED mixed:.*?GUARANTEED \(published terms, 0-50 C\) ([\d.]+) /', 5.61, 0.005),
               K('offset G balanced mV', 'analog/out/analog_budget.txt', r'FITTED mixed:.*?GUARANTEED \(published terms, 0-50 C\) [\d.]+ / ([\d.]+) mV', 11.21, 0.005),
               K('offset E unbalanced mV (with DAC terms)', 'analog/out/analog_budget.txt', r'FITTED mixed:.*?unbalanced worst case ([\d.]+) mV', 7.73, 0.005),
               K('offset E balanced mV', 'analog/out/analog_budget.txt', r'FITTED mixed:.*?balanced worst case ([\d.]+) mV \(two', 15.47, 0.005),
               K('5V_ANA quiescent mA (F-1)', 'analog/out/r2_power.txt', r'PGOOD pull-up [\d.]+ mA = ([\d.]+) mA', 73.65, 0.005),
               K('Default need without ANA_SENSE (analog, F-1) mA', 'analog/out/r9_fixes.txt', r'need with DS maxima[^:]*: ([\d.]+) mA', 178.92, 0.005),
               K('C442/C443 reverse bias at 0 C V', 'analog/out/r9_fixes.txt', r'T\s+0 C: BAT54 VF at [\d.]+ mA <= ([\d.]+) V', 0.469, 0.0005)]),
    dict(id='A2', stream=AN, title='Hold-up at every hard unplug (unplug_model_r3)', slow=True, steps=[S('analog/scripts', 'unplug_model_r3.py')], keys=[]),
    dict(id='A3', stream=AN, title='OPA1622 model calibration and validation (calibrate_opa1622, validate_opa1622)', slow=True,
         steps=[S('analog/scripts', 'calibrate_opa1622.py'), S('analog/scripts', 'validate_opa1622.py')], keys=[]),
    dict(id='A4', stream=AN, title='Leg stability with the output switch (stability_switch)', slow=True, steps=[S('analog/scripts', 'stability_switch.py')],
         needs=['A3'], keys=[K('worst PM switch closed deg', 'analog/out/stability_switch.txt', r'SUMMARY SWITCH CLOSED: worst PM ([\d.]+) deg', 51.3, 0.05)]),
    dict(id='A5', stream=AN, title='I/V stability with the CM-summing load (stability_iv)', slow=True, steps=[S('analog/scripts', 'stability_iv.py')],
         keys=[K('worst PM I/V deg (released case with the CM-summing load; register A-38)', 'analog/out/stability_iv.txt',
                 r'worst over 1080 corners: PM ([\d.]+) deg', 67.5, 0.05)]),
    dict(id='A7', stream=AN, title='R10 analog: F-5 leg peaks (uncalibrated / -4.5 dB / calibrated), post-calibration drift, F-2 class sensitivities (r10_fixes)',
         steps=[S('analog/scripts', 'r10_fixes.py')], needs=['A1'],
         keys=[K('-4.5 dB default word dB', 'analog/out/r10_fixes.txt', r'0x4C3EA838 = (-?[\d.]+) dB', -4.5, 0.00005),
               K('Default need incl. ANA_SENSE mA (A-35)', 'analog/out/r10_fixes.txt', r'ANA_SENSE [\d.]+ = ([\d.]+) mA vs IOS min', 178.961, 0.0005),
               K('Default margin mA (A-35)', 'analog/out/r10_fixes.txt', r'IOS min [\d.]+ mA -> margin \+([\d.]+) mA', 1.0899, 0.00005)]),
    dict(id='A6', stream=AN, title='Pop bounds, DAC-pin safety, switch THD/Zout, round-3 fixes (dac_timing_pop, dac_pin_safety, r2_switch, p01, r3_fixes)',
         steps=[S('analog/scripts', 'dac_timing_pop.py'), S('analog/scripts', 'dac_pin_safety.py'), S('analog/scripts', 'r2_switch.py'),
                S('protection', 'p01_switch_choice.py'), S('analog/scripts', 'r3_fixes.py')], needs=['A1'], keys=[]),
    # ------------------------------------------------------------------ digital (stdout = the shipped *_output.txt)
    dict(id='D1', stream=DG, title='Clock timing: I2S setup/hold, link, MCLK/FSR (clock_timing)',
         steps=[S('digital', 'clock_timing.py', capture='digital/clock_timing_output.txt')],
         keys=[K('I2S setup margin ns', 'stdout:clock_timing.py', r'setup margin ([\d.]+) ns', 14.0, 0.05),
               K('I2S hold margin ns', 'stdout:clock_timing.py', r'hold margin ([\d.]+) ns', 16.1, 0.05),
               K('MCLK/FSR worst', 'stdout:clock_timing.py', r'nominal, ([\d.]+) worst', 208.31, 0.005)]),
    dict(id='D2', stream=DG, title='Firmware sequences, ADC settings, currents, levels, MCLK gate race, USB feedback',
         steps=[S('digital', 'firmware_sequences.py', capture='digital/firmware_sequences_output.txt'),
                S('digital', 'adc_settings.py', capture='digital/adc_settings_output.txt'),
                S('digital', 'currents.py', capture='digital/currents_output.txt'),
                S('digital', 'levels_and_pullups.py', capture='digital/levels_and_pullups_output.txt'),
                S('digital', 'mclk_gate_race.py', capture='digital/mclk_gate_race_output.txt'),
                S('digital', 'usb_feedback.py', capture='digital/usb_feedback_output.txt')],
         keys=[K('F-5 calibration-rule section', 'stdout:firmware_sequences.py', r'(R10 F-5 \(R10-B\): CALIBRATION RULE)', 'R10 F-5 (R10-B): CALIBRATION RULE'),
               K('F-5 default master trim', 'stdout:firmware_sequences.py', r'(0x4C3EA838)', '0x4C3EA838')]),
    # ------------------------------------------------------------------ parts
    dict(id='T1', stream=PA, title='Component stress table (stress_calc)', steps=[S('parts', 'stress_calc.py')], keys=[]),
    dict(id='T2', stream=PA, title='PCBA class / ordering plan, placement density, value decode (parts)',
         steps=[S('parts', 'pcba_class_scan.py'), S('parts', 'placement_density.py'), S('parts', 'value_decode_check.py')], keys=[]),
    dict(id='T3', stream=PA, title='USB 90 ohm pair geometry (usb_diffpair_impedance)', steps=[S('parts', 'usb_diffpair_impedance.py')], keys=[]),
]
BYID = {c['id']: c for c in CHECKS}
SKIP = {'__pycache__'}
# text that legitimately changes on every run (file dates of the copied inputs, run times): (pattern, replacement);
# replacement None drops the line. Applied to both sides before the comparison.
DATE = r'\b\d{1,2} [A-Z][a-z]{2} \d{2}:\d{2} UTC\b'
VOLATILE = {'parts/pcba_class_scan_out.txt': [(r'^Stream BOM file dates:', None), (DATE, '<file date>')],
            'parts/pcba_class_table.csv': [(DATE, '<file date>')],
            'parts/usb_impedance_out.txt': [(r'^run time \d+ s$', None)]}


def norm(b, path=''):
    t = b.decode('utf-8', 'replace').replace('\r\n', '\n').replace('\r', '\n')
    out = []
    for x in t.split('\n'):
        for pat, rep in VOLATILE.get(path, []):
            if rep is None and re.search(pat, x):
                x = None
                break
            if rep is not None:
                x = re.sub(pat, rep, x)
        if x is not None:
            out.append(x.rstrip())
    return '\n'.join(out).rstrip('\n')


def scan(top):
    out = {}
    for dp, dn, fn in os.walk(os.path.join(RUN, top)):
        dn[:] = [d for d in dn if d not in SKIP]
        for f in fn:
            p = os.path.join(dp, f)
            st = os.stat(p)
            out[os.path.relpath(p, RUN).replace(os.sep, '/')] = (st.st_size, st.st_mtime_ns)
    return out


NUM = re.compile(r'[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')
REL_TOL = 1e-6          # numbers equal within 1 ppm (last-digit float noise, e.g. JSON dumps of full-precision floats)


def line_eq(x, y):
    if x == y:
        return True
    if NUM.split(x) != NUM.split(y):
        return False
    for a, b in zip(NUM.findall(x), NUM.findall(y)):
        fa, fb = float(a), float(b)
        if abs(fa - fb) > max(1e-12, REL_TOL * max(abs(fa), abs(fb))):
            return False
    return True


def text_eq(a, b):
    la, lb = a.split('\n'), b.split('\n')
    return len(la) == len(lb) and all(line_eq(x, y) for x, y in zip(la, lb))


def first_diff(a, b):
    la, lb = a.split('\n'), b.split('\n')
    n = sum(1 for x, y in zip(la, lb) if not line_eq(x, y)) + abs(len(la) - len(lb))
    for i, (x, y) in enumerate(zip(la + [''] * max(0, len(lb) - len(la)), lb + [''] * max(0, len(la) - len(lb)))):
        if not line_eq(x, y):
            return n, i + 1, x[:160], y[:160]
    return n, 0, '', ''


def reconcile():
    """I3b: every fitted component of the merged BOM is in the merged netlist with its pin count, and vice versa."""
    import csv
    sys.path.insert(0, os.path.join(RUN, 'integration'))
    msgs = []
    bom = list(csv.DictReader(open(os.path.join(RUN, 'integration', 'bom_merged.csv'), encoding='utf-8')))
    net = list(csv.DictReader(open(os.path.join(RUN, 'integration', 'netlist_merged.csv'), encoding='utf-8')))
    import importlib
    expand = importlib.import_module('build_package').expand       # the designator-range parser of the merge (no side effects)
    pins = {}
    for r in net:
        pins.setdefault(r['refdes'], set()).add(r['pin'])
    want, fitted = {}, set()
    for r in bom:                             # every component line, fitted or DNF (a DNF part keeps its footprint in the netlist)
        if r['refs'] in ('PCB', 'MH, FID') or r['mpn'].lower().startswith('no part'):
            continue
        n = int(float(r['smt_pins_per_part'] or 0)) + int(float(r['tht_pins_per_part'] or 0))
        for d in expand(r['refs']):
            want[d] = n
            if r['fit'].startswith('Yes'):
                fitted.add(d)
    tp = {d for d in pins if d.startswith('TP') and d not in want}
    miss = sorted(d for d in want if d not in pins)
    extra = sorted(d for d in pins if d not in want and d not in tp)
    badn = sorted(d for d, n in want.items() if d in pins and n and len(pins[d]) != n)
    if miss:
        msgs.append(f'BOM refs without netlist pins: {miss[:12]}')
    if extra:
        msgs.append(f'netlist refs without a BOM line (TP pads excluded): {extra[:12]}')
    if badn:
        msgs.append(f'pin count BOM != netlist: {[(d, want[d], len(pins[d])) for d in badn[:8]]}')
    info = (f'{len(want)} BOM component refs ({len(fitted)} fitted incl. copper-pad refs, {len(want) - len(fitted)} DNF), {len(net)} pin rows, '
            f'{len(pins)} netlisted refs ({len(tp)} TP pads)')
    return (not msgs), info, msgs


def getval(key, stdouts):
    if key['path'].startswith('stdout:'):
        text = stdouts.get(key['path'][7:])
        if text is None:
            return None, 'stdout not captured'
    else:
        p = os.path.join(RUN, key['path'])
        if not os.path.exists(p):
            return None, 'file missing'
        text = open(p, encoding='utf-8', errors='replace').read()
    m = re.search(key['pattern'], text, re.S)
    return (m.group(1) if m else None), text


def check_key(key, stdouts):
    got, _ = getval(key, stdouts)
    exp = key['expected']
    if exp is None:
        return got is None, f'{key["label"]}: ' + ('absent (ok)' if got is None else f'FOUND stale "{got}"')
    if got is None:
        return False, f'{key["label"]}: pattern not found (expected {exp})'
    if isinstance(exp, (int, float)):
        try:
            g = float(got.replace(',', ''))
        except ValueError:
            return False, f'{key["label"]}: not a number "{got}" (expected {exp})'
        ok = abs(g - exp) <= key['tol'] + 1e-12
        return ok, f'{key["label"]}: {got} vs reference {exp}' + ('' if ok else f' (tol {key["tol"]})')
    return got == exp, f'{key["label"]}: "{got}" vs reference "{exp}"'


def run_check(c, stdouts):
    res = dict(id=c['id'], stream=c['stream'], title=c['title'], status='PASS', steps=[], outputs=[], keys=[], notes=[])
    if c.get('pending'):
        res['status'] = 'PENDING'
        res['notes'].append(c['pending'])
        return res
    if c.get('internal') == 'reconcile':
        ok, info, msgs = reconcile()
        res['notes'].append(info)
        res['keys'] = [(ok, m) for m in msgs] or [(True, 'BOM and netlist reconcile: ' + info)]
        res['status'] = 'PASS' if ok else 'FAIL'
        return res
    tops = set()
    for st in c['steps']:
        top = st['script'].split('/')[0] if st['cwd'] == '.' else st['cwd'].split('/')[0]
        tops.add(top)
    before = {}
    for t in sorted(tops):
        before.update(scan(t))
    for rel in c.get('clear', []):          # outputs that the steps append to: start from an empty file, as the stream does
        fp = os.path.join(RUN, rel)
        if os.path.exists(fp):
            os.remove(fp)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0', MPLBACKEND='Agg')
    for st in c['steps']:
        spath = os.path.join(RUN, st['cwd'], st['script'])
        if not os.path.exists(spath):
            res['steps'].append((st['script'], 'missing', 0.0))
            res['status'] = 'FAIL'
            continue
        t0 = time.time()
        for attempt in (1, 2):              # one retry for the start-up import glitch seen on this filesystem (fails before any output)
            try:
                r = subprocess.run([sys.executable, st['script'], *st['args']], cwd=os.path.join(RUN, st['cwd']), capture_output=True,
                                   text=True, timeout=1800, env=env)
                rc, so, se = r.returncode, r.stdout, r.stderr
            except subprocess.TimeoutExpired:
                rc, so, se = 'timeout', '', ''
            if rc != 0 and attempt == 1 and re.search(r'ModuleNotFoundError: No module named', se):
                res['notes'].append(f'{st["script"]}: import glitch at start ({se.strip().splitlines()[-1][:80]}), retried once')
                time.sleep(2)
                continue
            break
        dt = time.time() - t0
        stdouts[st['script'].split('/')[-1]] = so
        res['steps'].append((' '.join([st['script'], *st['args']]), rc, round(dt, 1)))
        if rc != 0:
            res['status'] = 'FAIL'
            res['notes'].append(f'{st["script"]}: exit {rc}: ' + ' | '.join(se.strip().splitlines()[-3:]))
            continue
        if st['capture']:
            a, b = norm(open(os.path.join(ROOT, st['capture']), 'rb').read()), norm(so.encode('utf-8'))
            if text_eq(a, b):
                res['outputs'].append((st['capture'] + ' (stdout)', True, 'identical to the shipped file'))
            else:
                n, ln, x, y = first_diff(a, b)
                res['outputs'].append((st['capture'] + ' (stdout)', False, f'{n} lines differ; first at line {ln}: shipped "{x}" | fresh "{y}"'))
                res['status'] = 'FAIL'
    after = {}
    for t in sorted(tops):
        after.update(scan(t))
    written = sorted(p for p in after if before.get(p) != after[p])        # compared once, after every step of the check
    for p in written:
        shipped = os.path.join(ROOT, p)
        if not os.path.exists(shipped):
            res['outputs'].append((p, False, 'written but not shipped in the package'))
            res['status'] = 'FAIL'
            continue
        a, b = norm(open(shipped, 'rb').read(), p), norm(open(os.path.join(RUN, p), 'rb').read(), p)
        if text_eq(a, b):
            res['outputs'].append((p, True, 'identical to the shipped file' if a == b else 'equal to the shipped file within 1 ppm'))
        else:
            n, ln, x, y = first_diff(a, b)
            res['outputs'].append((p, False, f'{n} lines differ from the shipped file; first at line {ln}: shipped "{x}" | fresh "{y}"'))
            res['status'] = 'FAIL'
    missing_after = [rel for rel in c.get('clear', []) if not os.path.exists(os.path.join(RUN, rel))]
    for rel in missing_after:
        res['outputs'].append((rel, False, 'cleared before the run and not regenerated'))
        res['status'] = 'FAIL'
    for k in c['keys']:
        ok, msg = check_key(k, stdouts)
        res['keys'].append((ok, msg))
        if not ok:
            res['status'] = 'FAIL'
    return res


def order(ids):
    seen, out = set(), []

    def add(i):
        if i in seen:
            return
        seen.add(i)
        for d in BYID[i].get('needs', []):
            add(d)
        out.append(i)
    for i in ids:
        add(i)
    return out


stdouts_shipped = {}


def main(argv):
    if '--list' in argv:
        for c in CHECKS:
            steps = ', '.join(f'{s["cwd"]}/{s["script"]}' for s in c.get('steps', [])) or c.get('internal') or c.get('pending')
            print(f'{c["id"]:5s} {c["stream"]:11s} {c["title"]}' + (' (slow)' if c.get('slow') else '') + f'\n      {steps}')
        return 0
    if '--show-keys' in argv:                 # no run: the value of every key result in the SHIPPED outputs vs its document reference
        for c in CHECKS:
            for st in c.get('steps', []):
                if st['capture']:
                    stdouts_shipped[st['script'].split('/')[-1]] = open(os.path.join(ROOT, st['capture']), encoding='utf-8', errors='replace').read()
        global RUN
        RUN = ROOT
        for c in CHECKS:
            for k in c.get('keys', []):
                ok, msg = check_key(k, stdouts_shipped)
                print(f'{c["id"]:5s} {"ok " if ok else "DIFF"} {msg}')
        return 0
    ids = [c['id'] for c in CHECKS]
    if '--only' in argv:
        sel = [a for a in argv[argv.index('--only') + 1:] if not a.startswith('--')]
        bad = [a for a in sel if a not in BYID]
        if bad:
            print('unknown check id(s):', bad)
            return 1
        ids = sel
    ids = order(ids)
    t0 = time.time()
    if os.path.isdir(RUN):
        shutil.rmtree(RUN, ignore_errors=True)
    os.makedirs(WORK, exist_ok=True)
    shutil.copytree(ROOT, RUN, ignore=lambda d, names: [n for n in names if (os.path.abspath(d) == ROOT and n == '_verify') or n in SKIP])
    print(f'verify_release {PKG_VERSION}: package copied to _verify/run ({time.time() - t0:.0f} s); {len(ids)} checks', flush=True)
    stdouts, results = {}, []
    for i in ids:
        r = run_check(BYID[i], stdouts)
        results.append(r)
        t = sum(s[2] for s in r['steps'])
        print(f'  {r["id"]:5s} {r["status"]:7s} {t:7.1f} s  {r["title"][:90]}', flush=True)
    # ---- report
    L = [f'# verify_release {PKG_VERSION} - {time.strftime("%Y-%m-%d %H:%M:%S")} - {len(results)} checks in {time.time() - t0:.0f} s', '',
         '| Check | Stream | Calculation | Steps (exit, s) | Outputs identical | Key results | Result |', '|---|---|---|---|---|---|---|']
    for r in results:
        steps = '; '.join(f'{s[0]} ({s[1]}, {s[2]})' for s in r['steps']) or '-'
        oi = f'{sum(1 for o in r["outputs"] if o[1])}/{len(r["outputs"])}' if r['outputs'] else '-'
        ki = f'{sum(1 for k in r["keys"] if k[0])}/{len(r["keys"])}' if r['keys'] else '-'
        L.append(f'| {r["id"]} | {r["stream"]} | {r["title"]} | {steps} | {oi} | {ki} | **{r["status"]}** |')
    L += ['', '## Details (mismatches, failures, pending items)', '']
    for r in results:
        bad = [o for o in r['outputs'] if not o[1]] + [(None, k[0], k[1]) for k in r['keys'] if not k[0]]
        if r['status'] != 'PASS' or bad:
            L.append(f'- **{r["id"]} {r["status"]}**: ' + '; '.join(r['notes'] + [f'{o[0]}: {o[2]}' if o[0] else o[2] for o in bad]))
    L += ['', '## Key results checked against the documents', '']
    for r in results:
        for ok, msg in r['keys']:
            L.append(f'- {r["id"]} {"ok " if ok else "MISMATCH"} {msg}')
    npass = sum(1 for r in results if r['status'] == 'PASS')
    nfail = sum(1 for r in results if r['status'] == 'FAIL')
    npend = sum(1 for r in results if r['status'] == 'PENDING')
    verdict = 'FAIL' if nfail else ('PENDING' if npend else 'PASS')
    L += ['', f'**Verdict: {verdict}** - pass {npass}, fail {nfail}, pending {npend} of {len(results)}']
    open(os.path.join(WORK, 'verify_release_report.txt'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    json.dump(dict(version=PKG_VERSION, verdict=verdict, results=results), open(os.path.join(WORK, 'verify_release_result.json'), 'w'), indent=1)
    print()
    print(f'{"check":6s}{"result":9s}{"outputs":10s}{"keys":8s}calculation')
    for r in results:
        oi = f'{sum(1 for o in r["outputs"] if o[1])}/{len(r["outputs"])}' if r['outputs'] else '-'
        ki = f'{sum(1 for k in r["keys"] if k[0])}/{len(r["keys"])}' if r['keys'] else '-'
        print(f'{r["id"]:6s}{r["status"]:9s}{oi:10s}{ki:8s}{r["title"][:80]}')
    print()
    for line in L[L.index('## Details (mismatches, failures, pending items)') + 2:]:
        if line.startswith('- **'):
            print(line[:600])
    print(f'\nVERDICT {verdict}: pass {npass}, fail {nfail}, pending {npend} of {len(results)} '
          f'(report _verify/verify_release_report.txt)')
    return 1 if nfail else (2 if npend else 0)


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
