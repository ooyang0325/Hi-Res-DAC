# Calculation package v1.1 — USB DAC + balanced headphone amplifier (R10 final with the R11 update, 26 Sep 2026)

Reproducible calculations behind the design documents (decisions_r9 E-15, decisions_r10 F-3). Every path below is relative to this folder; run the commands from this folder with Python 3.8+ and numpy.

**R11 update (26 Sep 2026):** the schematic-capture review and the maker drawings supplied by the owner (J701 owner-approved 12-pad map, confirmed by the G-Switch drawing, pads 11/12 = mounting tabs; J702 contact map from the HRO PJ-332A drawing: 1 sleeve / 2 ring 2 GND, 3 ring 1 JACK_RP, 4 tip JACK_LP, 5/6 break contacts no net; G-2 confirms both on two samples; J101 / J702 plated-termination soldering open with JLCPCB, owner fallback), the corrected connector and protection BOM texts and stress rows with the parts T1 / T2 re-runs, and the register and summary corrections of the independent summary check. This package supersedes the earlier v1.1 build of 26 Sep 2026 10:43.

## Release verification — one command

```
python3 verify_release.py
```

It copies the package to `_verify/run/` (the shipped files are never overwritten), runs every release calculation of list 1 in dependency order with the inputs shipped here, compares every file a calculation writes with the shipped file of the same path (line endings normalised; an output the package does not ship is a failure) and the key results with the values stated in the documents, prints a pass/fail table and writes `_verify/verify_release_report.txt`. Exit status 0 = all pass, 1 = any mismatch or error, 2 = a declared release calculation is still pending. `python3 verify_release.py --list` lists the checks, `--only <id> ...` runs selected ones (with their dependencies). A full run takes about 20 minutes on a slow disk.

**Not included (external sources):** datasheet PDFs and their text extracts, web caches and quote files (`ds/*.txt`, `web/`, `sources/`). Scripts that digitise datasheet figures are historical generators (list 2); their derived data (`analog/ds/*.json`) is shipped, so every release calculation runs without the PDFs.

## 1. Release calculations (verified by `python3 verify_release.py`)

| Claim | Script(s) | Output(s) | Single run (from the package root) | Check |
|---|---|---|---|---|
| Netlist/BOM consistency incl. the value-decodes-from-MPN check (E-1) and its self-test | `integration/check_design.py; integration/tests/test_value_decode.py` | `integration/check_result.json` | `python3 integration/check_design.py power protection analog digital` | I1, I2 |
| BOM/netlist reconciliation: merged BOM and netlist, cross-checks (counts in build_package_out.txt; incl. the 52 TP pads); independent re-check in verify_release | `integration/build_package.py` | `integration/bom_merged.csv; netlist_merged.csv; nets_summary.csv; build_package_out.txt; _diff_raw.json` | `cd integration && python3 build_package.py` | I3, I3b |
| Change lists vs Parts List v0.6, vs the v0.9 set and vs the v1.0 release (baselines shipped in integration/baselines/) | `integration/build_changes.py` | `integration/bom_changes_vs_v06.csv; bom_changes_vs_v09.csv; bom_changes_vs_v10.csv` | `cd integration && python3 build_changes.py` | I4 |
| Cost report: an estimate until the supplier orders and the JLCPCB quote exist (F-6) | `integration/cost_calc.py` | `integration/cost_report.md` | `cd integration && python3 cost_calc.py` | I5 |
| Evidence register: classes derived from the recorded inputs (F-2 propagation; Q rows = open qualification obligations) | `integration/build_evidence_register.py` | `integration/traceability.csv; integration/evidence_register.csv` | `cd integration && python3 build_evidence_register.py` | I6 |
| Plug/adapter isolation 24/24 cases (four-leg switch) | `protection/p02_connection_cases.py` | `protection/p02_connection_cases_out.txt` | `cd protection && python3 p02_connection_cases.py` | P02 |
| I/V common-mode window (band, margins, stuck-pin coverage, CM-path energies) | `protection/p04_cm_monitor.py` | `protection/p04_cm_monitor_out.txt` | `cd protection && python3 p04_cm_monitor.py` | P04 |
| Photorelay drive, permit node H, switch open/close times | `protection/p05_switch_drive.py` | `protection/p05_switch_drive_out.txt` | `cd protection && python3 p05_switch_drive.py` | P05 |
| DC-sense networks, firmware tiers T1-T3, combined energy envelope | `protection/p06_dcsense_tiers.py` | `protection/p06_dcsense_tiers_out.txt` | `cd protection && python3 p06_dcsense_tiers.py` | P06 |
| Stream-guard proofs (round-3 rule, OD-1 rules P1-P4; 13.8 / 25.3 mJ; no-false-trigger boundary) | `protection/p07_stream_guard.py; p15_od_guard.py; p16_od_p2_scan.py; p16b_od_p4_scan.py` | `protection/p07_stream_guard_out.txt; p15_od_guard_out.txt; p16_od_p2_scan_out.txt; p16b_od_p4_scan_out.txt` | `cd protection && python3 p15_od_guard.py` | P07 |
| ADC2 sampling (settling, charge sharing) of the sense channels | `protection/p09_adc_sampling.py` | `protection/p09_adc_sampling_out.txt` | `cd protection && python3 p09_adc_sampling.py` | P09 |
| DAC-supply / MCLK supervisor, frozen-code removal, boot self-test windows | `protection/p10_supervisor.py` | `protection/p10_supervisor_out.txt` | `cd protection && python3 p10_supervisor.py` | P10 |
| R10 F-1 history-robust hardware protection: OR (U611/U612) and LPW (U613-U620) detectors + E-3, removal and energies from every reachable state, content boundary (sines >= 20 Hz, squares 21.4 / 25.6 Hz, LPW offsets with the 10 nA allowance), firmware tiers over the swept (finite) history set, hardware level floor 0.34 V per leg / 0.68 V pair, protection BOM/netlist rows, 32 ohm frozen-FS option study | `protection/p21_r10_f1.py; p21b_r10_content.py; p21c_r10_tiers.py; p21d_r10_bom.py; p22_r10_fs32.py` | `protection/p21_r10_f1_out.txt; p21b_r10_content_out.txt; p21c_r10_tiers_out.txt; p21d_r10_bom_out.txt; p22_r10_fs32_out.txt; bom_rows.csv; netlist.csv` | `cd protection && python3 p21_r10_f1.py && python3 p21b_r10_content.py && python3 p21c_r10_tiers.py && python3 p21d_r10_bom.py && python3 p22_r10_fs32.py` | P21 |
| E-16 suspend power cut: TPS70933, Q507, attach A 29.6 / B 20.1 uC, S6 2.2755 mA | `power/calc/c22_e16_suspend_cut.py` | `power/calc/c22_e16_suspend_cut.out.txt; c22_results.json` | `cd power/calc && python3 c22_e16_suspend_cut.py` | C22 |
| USB states S1-S6 and the U503 limits (R509 4.75 k: IOS 180.05 / 201.3 / 222.6 mA vs the Default need, register A-35); c17_basis.json = the one input set read by c04, c09, c10, c11, c14, c15, c16, c18 (run c03 -> c17 -> consumers) | `power/calc/c17_budget_r3.py; c03_usb_budget_ilim.py; c16_r3_review_fixes.py` | `power/calc/c17_budget_r3.out.txt; c17_results.json; c17_basis.json; c03_usb_budget_ilim.out.txt; c03_results.json; c16_r3_review_fixes.out.txt; c16_results.json` | `cd power/calc && python3 c03_usb_budget_ilim.py && python3 c17_budget_r3.py && python3 c16_r3_review_fixes.py` | C17, C03, C16 |
| R9 power checks (c21): E-5 suspend inventory, E-8 reverse bias, brown-out margin, E-6 Default numbers (R509 4.75 k) | `power/calc/c21_r9_checks.py` | `power/calc/c21_r9_checks.out.txt; c21_results.json` | `cd power/calc && python3 c21_r9_checks.py` | C21 |
| Attach inrush regions (USB-IF #45), C104 delay | `power/calc/c02_attach_inrush.py` | `power/calc/c02_attach_inrush.out.txt` | `cd power/calc && python3 c02_attach_inrush.py` | C02 |
| VBUS hard-short kick with D102, U102 IOS with R108 100 k, EN delay with R109 470 k, ANA_SENSE divider | `power/calc/c20_ve_checks.py` | `power/calc/c20_ve_checks.out.txt` | `cd power/calc && python3 c20_ve_checks.py` | C20 |
| Rail start-up with the X-8 reservoirs (T_START 40 ms); four appended runs (10 / 470 nF, reduced + timing) | `power/calc/c18_x8_rail_start.py` | `power/calc/c18_x8_rail_start.out.txt; c18_10nF.json; c18_470nF.json; c18_10nF_timing.json; c18_470nF_timing.json` | `cd power/calc && rm -f c18_x8_rail_start.out.txt && for a in "10 reduced" "470 reduced" "10 timing" "470 timing"; do python3 c18_x8_rail_start.py $a; done` | C18 |
| Discharge times (3V3A 0.385 ms, 3V3D 0.63 ms, 1V3 0.134 ms) | `power/calc/c06_discharge.py` | `power/calc/c06_discharge.out.txt` | `cd power/calc && python3 c06_discharge.py` | C06 |
| U503 TPS2596 limits (reads the c17 basis) | `power/calc/c11_u503_tps2596.py` | `power/calc/c11_u503_tps2596.out.txt` | `cd power/calc && python3 c17_budget_r3.py && python3 c11_u503_tps2596.py` | C11 |
| Regulator margins, thermal table, VBUS sense band, LM27762 envelopes | `power/calc/c04_regulators.py; c10_thermal.py; c09_vbus_sense.py; c15_lm27762_headroom.py` | `power/calc/c04_regulators.out.txt; c10_thermal.out.txt; c09_vbus_sense.out.txt; c15_lm27762_headroom.out.txt` | `cd power/calc && python3 c10_thermal.py` | C04 |
| Hard-unplug rail ordering, brown-out action before the MCU reset (288 corners) | `power/calc/c14_unplug_order.py` | `power/calc/c14_unplug_order.out.txt` | `cd power/calc && python3 c14_unplug_order.py` | C14 |
| Analog budget and offset: levels, swing, reset state, E-4 offset split (5.61 / 11.21 mV G; 7.73 / 15.47 mV with DAC terms), power tables, Default need | `analog/scripts/analog_budget.py; r2_power.py; r9_fixes.py` | `analog/out/analog_budget.txt; offset_budget.csv; r2_power.txt; power_table.csv; headroom_table.csv; r9_fixes.txt` | `cd analog/scripts && python3 analog_budget.py && python3 r2_power.py && python3 r9_fixes.py` | A1 |
| Hold-up at every hard unplug: I/V supply outlives 3V3A in 1,944 corners (X-8; 176 uF case) | `analog/scripts/unplug_model_r3.py` | `analog/out/unplug_model_r3.txt` | `cd analog/scripts && python3 unplug_model_r3.py` | A2 |
| OPA1622 macro-model calibration to the datasheet curves (typical-curve model: evidence class E) | `analog/scripts/calibrate_opa1622.py; validate_opa1622.py` | `analog/out/calibrate_opa1622.txt; validate_opa1622.txt; analog/ds/opa1622_calibrated.json` | `cd analog/scripts && python3 calibrate_opa1622.py` | A3 |
| Leg stability with the output switch (37 load cases x 4 models; PM >= 51.3 deg; model-based: E) | `analog/scripts/stability_switch.py` | `analog/out/stability_switch.txt` | `cd analog/scripts && python3 stability_switch.py` | A4 |
| I/V stability with the CM-summing load (1,080 corners; reconstructed OPA2210 shapes: E) | `analog/scripts/stability_iv.py` | `analog/out/stability_iv.txt` | `cd analog/scripts && python3 stability_iv.py` | A5 |
| R10 analog: F-5 leg peaks at 0 dBFS (uncalibrated, -4.5 dB default, calibrated), post-calibration drift, F-2 class sensitivities (RNEG needs, IQ/CP margins) | `analog/scripts/r10_fixes.py` | `analog/out/r10_fixes.txt` | `cd analog/scripts && python3 r10_fixes.py` | A7 |
| Pop bounds, DAC-pin safety, switch THD/Zout/crosstalk, round-3 fixes | `analog/scripts/dac_timing_pop.py; dac_pin_safety.py; r2_switch.py; r3_fixes.py; protection/p01_switch_choice.py` | `analog/out/dac_timing_pop.txt; dac_pin_safety.txt; r2_switch.txt; r3_fixes.txt; protection/p01_switch_choice_out.txt` | `cd analog/scripts && python3 dac_timing_pop.py` | A6 |
| Clock timing (I2S setup/hold 14.0 / 16.1 ns, link timing with U208, MCLK/FSR, jitter) | `digital/clock_timing.py` | `digital/clock_timing_output.txt` | `cd digital && python3 clock_timing.py > clock_timing_output.txt` | D1 |
| Firmware sequences (suspend level <= 8.75 ms, TSIGATT <= 23.9 ms, power-down order, E-2 re-arm), ADC settings, currents, levels, MCLK gate race, USB feedback | `digital/firmware_sequences.py; adc_settings.py; currents.py; levels_and_pullups.py; mclk_gate_race.py; usb_feedback.py` | `digital/firmware_sequences_output.txt; adc_settings_output.txt; currents_output.txt; levels_and_pullups_output.txt; mclk_gate_race_output.txt; usb_feedback_output.txt` | `cd digital && python3 firmware_sequences.py > firmware_sequences_output.txt` | D2 |
| Component stress table (FAIL 0) | `parts/stress_calc.py` | `parts/stress_table.csv; parts/stress_calc_out.txt` | `cd parts && python3 stress_calc.py` | T1 |
| PCBA class / ordering plan, placement density, value decode (parts; reads the stream BOMs) | `parts/pcba_class_scan.py; placement_density.py; value_decode_check.py` | `parts/pcba_class_scan_out.txt; pcba_class_table.csv; placement_density_out.txt; value_decode_out.txt` | `cd parts && python3 pcba_class_scan.py` | T2 |
| USB 90 ohm differential pair geometry (field solver on the nominal stack-up: E) | `parts/usb_diffpair_impedance.py` | `parts/usb_impedance_out.txt; usb_impedance_out.json` | `cd parts && python3 usb_diffpair_impedance.py` | T3 |

## 2. Historical generators (kept for traceability; not verified, not guaranteed to re-run)

| Generator(s) | Why historical |
|---|---|
| `protection/p19_r9_bom.py` | R9 generator of the E-2/E-3 BOM/netlist rows (R665 check, self-test windows): reads bom_rows_ve.csv.bak and netlist_ve.csv.bak (pre-R9 stream files, not shipped); the R10 rows come from p21d (P21), checked by I1/I3; outputs p19_r9_bom_out.txt, p19_r9_e11_out.txt and p20_r9_selftest_out.txt (its generator p20 was never shipped) kept |
| `analog/scripts/stability_legs.py; stability_legs_T.py; stability_legs_T2.py; stability_legs_lead.py; stability_final.py` | round-1 selection sweeps (relay placeholder path, T network, lead capacitor); superseded by stability_switch.py / stability_iv.py (A4/A5); outputs analog/out/stability_legs*.txt, stability_final.txt kept |
| `analog/scripts/digitize_opa1622.py; digitize_opa1622_b.py; pdf_dump_region.py` | read the OPA1622 datasheet PDF (external, not shipped); their derived data analog/ds/*.json is shipped and feeds A3 |
| `analog/scripts/unplug_model.py; unplug_model_r2.py; dac_timing_pop_r1.py` | earlier rounds, superseded by unplug_model_r3.py (A2) and dac_timing_pop.py (A6) |
| `analog/scripts/gen_netlist_bom.py; power/calc/gen_bom_netlist.py; gen_sch_part.py; digital/gen_netlist_bom.py; protection/p08_bom_netlist.py; p12_r3_bom_netlist.py; p14_ve_bom.py` | stream BOM/netlist generators of earlier rounds; the released bom_rows.csv / netlist.csv carry later text-only corrections and are the release inputs (checked by I1/I3) |
| `protection/p03_detector.py; p11_x9_filter.py` | the retired leg windows (R601-R604 / C601-C604 removed in R10 F-1): their zero-state sweeps are what R10-A1 invalidated; outputs kept |
| `protection/p17_r9_e3.py; p17b_r9_e3_2pole.py; p18_r9_e2e3.py` | R9 generators: the E-2 / E-3 hardware is unchanged, but the p18 energies and T_P 23.23 ms are superseded by p21 (T_P 23.37 ms with the design rails and a 0 V start); p17/p17b (filter-type windows rejected) kept for the R9 rationale; outputs kept |
| `protection/p03b_threshold_scan.py` | round-1 threshold scan (basis of the window choice); it imports the current p03/pcommon constants, so a re-run no longer reproduces its shipped output p03b_threshold_scan_out.txt (kept); the released windows are verified by P03 |
| `parts/ve_cost_model.py` | VE-round cost model on the stream BOMs of 25 Sep 11:06 (output ve_cost_model_out.txt, ve_lines.csv kept); superseded by integration/cost_calc.py (I5) |
| `integration/tests/scan_parts_list_values.py` | reads the Parts List workbook (docs, not shipped) |
| `integration/build_calc_package.py` | builds this package from the project tree (not runnable inside the package) |
| `analog/scripts/stress_table.py`; `digital/pin_tables.py`; `digital/stress_table.py`; `parts/copper_calc.py`; `parts/dsv.py`; `parts/jlc_extract.py`; `parts/r9_mclk_tap.py`; `power/calc/c01_ovp_hotplug.py`; `power/calc/c05_fb501_damping.py`; `power/calc/c07_relay_coil.py`; `power/calc/c08_suspend.py`; `power/calc/c12_u303_tlv758p.py`; `power/calc/c13_j101_cc_pb4.py`; `power/calc/c19_3v3a_c440.py`; `protection/p13_r501_fallback_check.py` | other scripts not named in list 1 (earlier-round calculations, or R10 scripts not yet assigned to a release claim): kept for traceability, not verified |

Shared modules imported by the release calculations: `protection/pcommon.py`, `power/calc/pw_common.py`, `analog/scripts/r2_common.py`, `analog/scripts/mna.py`, `analog/scripts/mna_v.py`, `analog/scripts/models_v.py`, `analog/scripts/opamp_models.py`. `r9/` and `r10/` hold the review digests and decisions of those rounds (the orchestrator reproductions in `r10/` are inputs of this round, not release calculations).

## Folder map

| Folder | Content |
|---|---|
| `verify_release.py` | the release-verification command (this folder) |
| `power/` | power stream report, BOM/netlist, `calc/` scripts `cNN_*.py` with `.out.txt` / `*_results.json` |
| `protection/` | protection report, BOM/netlist, scripts `pNN_*.py` with `*_out.txt` |
| `analog/` | analog report, BOM/netlist, `scripts/` (models, sweeps) with `out/`, derived curve data `ds/*.json` |
| `digital/` | digital report, BOM/netlist, scripts with `*_output.txt` (their stdout) |
| `parts/` | parts report, layout package, stress and PCBA tables, cost/placement scripts |
| `integration/` | checker, merge/cost/evidence scripts, merged BOM/netlist, traceability, evidence register, summaries, decisions; `tests/` E-1 self-tests; `baselines/` merged BOMs of the v0.9 and v1.0 sets (change-list inputs) |
| `current/` | Parts List v0.6 CSV (input of the change list) |
| `r9/`, `r10/` | review digests and decisions of R9 and R10 (inputs of those rounds) |

## Index check

Every script and output named in list 1 is present in the package.
