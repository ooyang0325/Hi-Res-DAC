#!/usr/bin/env python3
"""Component stress for digital-stream parts at worst operating conditions (50 C ambient, 3V3 rails +3 %).
Run: python3 stress_table.py > stress_table_output.txt
R8 round 2: X201 Kyocera KC2520K80 80 MHz (D-3 revised), U206 74LVC1G11, R233/R234/R235 added, C217 10 nF.
"""
V = 3.3 * 1.03          # 3.40 V worst rail [ASSUMP power-stream LDO +3 %]
TA = 50.0

rows = []


def res(ref, r, v_or_i, mode, rating_w=0.0625, note=""):
    if mode == "V":            # full voltage across the resistor (static or fault)
        p = v_or_i ** 2 / r
    elif mode == "Vduty":      # square wave, 50 % duty, full swing across R
        p = v_or_i ** 2 / r * 0.5
    else:                      # current
        p = v_or_i ** 2 * r
    rows.append((ref, f"{r:g} ohm 0402", f"{p*1e3:.3f} mW", f"{rating_w*1e3:.1f} mW", f"{p/rating_w*100:.1f} %", note))


# resistors (0402 1/16 W, UNI-ROYAL 0402WGF, rated at 70 C: 50 C ambient is inside the full-rating region)
res("R201", 10e3, 0.0, "V", note="NRST high: 0 V across")
res("R202, R232", 10e3, 0.0, "V", note="BOOT0/BOOT1 low")
res("R212, R213, R218", 10e3, V, "V", note="enable driven high (static)")
res("R216, R217", 10e3, V, "Vduty", note="active oscillator, 50 % duty")
res("R227", 10e3, V, "Vduty", note="80 MHz MCLK, 50 % duty")
res("R233", 4.7e3, 3.35, "V", note="FAULT only: PA8 high with 3V3D off (normal 32 uA -> 5 uW)")
res("R234", 10e3, 3.35, "V", note="PB14 high (MCLK_PERMIT)")
res("R235", 100e3, V, "V", note="U206 Y high (new)")
res("R231", 10e3, V, "V", note="only while CPLD_NRST is held low (fault/reset)")
res("R207, R208", 4.7e3, V, "V", note="bus line held low (worst, static)")
res("R228-R230", 330, V, "V", note="FAULT only: MCU pin driven against the CPLD output")
# 33R series terminations: charge current of the load capacitance, P = C V^2 f x R/(R+Rdrv) (upper bound: C V^2 f)
for ref, c, f in (("R203 (MCLK 80 MHz, 13.1 pF)", 13.1e-12, 80e6), ("R204 (BCLK 24.6 MHz, 7 pF)", 7e-12, 24.576e6),
                  ("R210/R211/R215 (49 MHz, 10 pF)", 10e-12, 49.152e6), ("R224 (SCK 36 MHz, 8 pF)", 8e-12, 36e6)):
    p = c * V ** 2 * f
    rows.append((ref, "33 ohm 0402", f"<= {p*1e3:.3f} mW", "62.5 mW", f"{p/0.0625*100:.1f} %", "upper bound C*V^2*f"))
res("R701", 1e3, 0.8e-3, "I", note="LED 0.8 mA max")
res("R702", 2.2e3, 0.73e-3, "I", note="LED 0.73 mA max")

print(f"{'ref':34s} {'part':14s} {'stress':>12s} {'rating':>9s} {'ratio':>7s}  note")
for r in rows:
    print(f"{r[0]:34s} {r[1]:14s} {r[2]:>12s} {r[3]:>9s} {r[4]:>7s}  {r[5]}")

print()
print("Capacitors (DC voltage / rating)")
for ref, v_rated, diel in (("C203-C210, C212-C215, C218, C219, C222, C223 100 nF", 16, "X7R"), ("C217 10 nF", 50, "X7R"), ("C201, C202 33 pF", 50, "C0G"),
                           ("C220, C221 1 uF", 50, "X5R"), ("C211 2.2 uF", 6.3, "X5R")):
    print(f"   {ref:52s} {V:.2f} V / {v_rated} V = {V/v_rated*100:4.1f} %  ({diel})")
print("   C211 0402 6.3 V X5R keeps ~50 % of 2.2 uF at 3.3 V (Samsung DC-bias curve class) - bulk role only.")

print()
print("ICs and oscillators (supply vs abs max, junction temperature)")
ic = [("U201 CH32V307", 4.0, 0.080 * V, 50.0, 85, "VDD/VIO abs max 4.0 V [DS Tab 4-1]; TA max 85 C; theta_JA LQFP64 ~50 C/W [ASSUMP]"),
      ("U202 AGRV2KQ32", 3.63, 0.040 * V, 45.0, 85, "AGM gives 3.3 V only; 3.63 V = +10 % [ASSUMP]; TJ max 85 C [DS]; theta_JA QFN32 ~45 C/W [ASSUMP]"),
      ("X201 Kyocera KC2520K80", 3.63, 0.0082 * V, None, 85, "abs max 4.0 V; 1.6-3.63 V, -40..+85 C [DS]; reflow 260 C x2 max"),
      ("X202/X203 NDK NZ2520SDA", 6.0, 0.015 * V, None, 85, "abs max 6.0 V [DS]; spec NSC5083D 3.3 V +-0.33 V"),
      ("U205 74LVC1G157/U206 74LVC1G11", 6.5, 0.005 * V, None, 125, "abs max 6.5 V; inputs 5.5 V tolerant, IOFF [DS]")]
for name, vmax, p, theta, tmax, note in ic:
    tj = f"TJ ~{TA + p*theta:.0f} C" if theta else "-"
    print(f"   {name:24s} V {V:.2f}/{vmax:.2f} V  P {p*1e3:5.0f} mW  {tj:10s} (limit {tmax} C)  {note}")
    assert V <= vmax
print()
print("Ferrite FB202: 40 mA budget / 200 mA rating = 20 %; drop 40 mA x 0.45 ohm = 18 mV [CALC]")
print("MCU pins: worst static source/sink per pin 0.8 mA (LED), PB14 0.34 mA, PA8 0.71 mA (fault) << 25 mA [DS Tab 4-1]; total VDD current 80 mA < 150 mA.")
print("RAILS_OK_N pin (PB4, FT): with R522 10 k + R532 470 k (D-8) and 5V_ANA_F <= 5.55 V the pin stays 3.22..4.76 V high")
print("  (<= 5.0 V VIH max, 5.5 V abs max) and <= VOL + 30 mV low (levels script section 1).")
