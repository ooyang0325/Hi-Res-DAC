#!/usr/bin/env python3
"""Timing numbers behind the merged firmware sequences (report section 8A).

Inputs and their sources:
  switch (photorelay) tON <= 5 ms at IF 5 mA, tOFF <= 0.5 ms [DS Toshiba TLP3545A s.15, 25 C]; design over 0-60 C: tON 10 ms,
    switch open <= 1.01 ms after RELAY_EN low incl. the driver [protection/report.md R2.4]
  X201 Kyocera KC2520K80.0000C1GE00 80 MHz (D-3 revised): t_sta, t_ena <= 2 ms [DS spec] (3 ms catalogue/D-3), t_dis <= 200 ns;
    conditional 2nd source NDK NSC5338D-80M: start-up <= 4 ms [parts FU-3]
  NDK NZ2520SDA start-up <= 4 ms [DS]; SiT8008 start-up/resume <= 5 ms [DS]
  WCH CH32V307: HSI accuracy +-2.2 % over temperature (Tab 4-14), LSI 25..60 kHz (Tab 4-15), PLL lock <= 200 us
    (Tab 4-16), HSE start-up <= 4 ms (Tab 4-12), Stop wake-up 76.7 us typ with the LP regulator (Tab 4-19)
  power stream: SOF-loss rule 1.0 ms; ANA_EN -> RAIL_EN >= 5 ms; RAILS_OK_N valid >= 20 ms after RAIL_EN;
    AVCC_EN -> AUD_EN >= 1 ms; discharge 3V3A <= 0.35 ms, 3V3D <= 0.525 ms, 1V3 <= 0.21 ms; suspend <= 10 ms
  analog stream: MCLK >= 2 ms after 1V3; RESETB >= 1 ms after supplies + MCLK stable; soft start x 1.2 (104.9 ms at 80 MHz
    -> 125.8 ms, clock_timing.py 5);
    mute-ramp timeout 1.5 x ramp; lock timeout 1.5 x 16384/fs + 10 ms; +10 ms after lock;
    power-down ramp-to-ground step (analog R2, COFF coupling): reg 14 = 0x03 (soft_start 0, soft_start_time 3) after the switch
    is open, wait 1.1 ms, then MCLK stop and RESETB low; brown-out ISR: RELAY_EN and AVCC_EN low together, no wait
  protection stream: pre-close checks need DC_PERMIT_N low and valid DC readings for >= 50 ms and V3A_MON in window
    >= 150 ms; DC_PERMIT_N reads 'permitted' <= 205 ms after the CM window clears (end of the DAC soft start, taken at the
    analog x1.2 allowance because ESS does not fix the ramp start), CM/clock-fault timeout 300 ms after it [protection R2.7]; IWDG <= 100 ms;
    DC_PERMIT_N rising -> RELAY_EN low <= 50 us; retry 2 s; 3 trips in 10 s -> lock-out; overload ceiling -3 dB steps
Run: python3 firmware_sequences.py > firmware_sequences_output.txt
"""
import math

T_SW_ON = 10.0e-3                      # volume ramp after RELAY_EN high: TLP3545A tON 5 ms x2 over 0-60 C [protection R2.4]
T_SW_OFF_DS = 0.5e-3
T_SW_OFF_BOUND = 1.01e-3
T_SW_OFF_WAIT = 1.1e-3
assert T_SW_OFF_WAIT >= T_SW_OFF_BOUND >= T_SW_OFF_DS

print("1. Firmware constants")
print(f"   switch: wait {T_SW_ON*1e3:.1f} ms after RELAY_EN high before the volume ramp (tON max); wait "
      f"{T_SW_OFF_WAIT*1e3:.1f} ms after RELAY_EN low before any analog-state change (>= protection bound "
      f"{T_SW_OFF_BOUND*1e3:.2f} ms; photorelay tOFF alone {T_SW_OFF_DS*1e3:.1f} ms)")
hsi_acc = 0.022
t_low = 5e-3 / (1 - hsi_acc)
print(f"   low-clock phase after reset: >= 5 ms real time timed on HSI (+-2.2 %) -> program {math.ceil(t_low*1e4)/10:.1f} ms")
lsi_min, lsi_max, presc = 25e3, 60e3, 4
reload = 239                                   # round 3: RLR 239 -> (RLR+1) x 4 = 960 LSI cycles (aligned with protection R3.9)
t_iwdg_min, t_iwdg_max = (reload + 1) * presc / lsi_max, (reload + 1) * presc / lsi_min
T_PERMIT_RECOVER_MIN = 53e-3                   # protection: H can re-close >= 53 ms after a trip clears (states #6)
print(f"   IWDG: prescaler /{presc}, RLR {reload} ({(reload+1)*presc} LSI cycles, (RLR+1) convention; RLR x presc would give 956) -> timeout {t_iwdg_min*1e3:.1f} .. {t_iwdg_max*1e3:.1f} ms "
      f"(LSI 25-60 kHz [DS Tab 4-15]); refresh from the main loop every <= 5 ms, only when all tasks report alive")
print(f"   hung MCU: reset <= {t_iwdg_max*1e3:.1f} ms + switch open <= {T_SW_OFF_BOUND*1e3:.2f} ms = {(t_iwdg_max+T_SW_OFF_BOUND)*1e3:.1f} ms "
      f"< {T_PERMIT_RECOVER_MIN*1e3:.0f} ms (earliest hardware re-close) -> margin {(T_PERMIT_RECOVER_MIN-t_iwdg_max-T_SW_OFF_BOUND)*1e3:.1f} ms")
assert t_iwdg_max <= 0.040 and t_iwdg_max + T_SW_OFF_BOUND < T_PERMIT_RECOVER_MIN
# DX-2 (orchestrator, 25 Sep 2026): <= 40 ms whenever RELAY_EN may be high or any switched domain is on; in suspend (RELAY_EN low,
# all switched domains off, MCU in Stop) the IWDG is lengthened to <= 1.6 s with a periodic RTC-alarm wake that refreshes it.
PRESC_S, RELOAD_S = 16, 2499                    # suspend IWDG: (RLR+1) x 16 = 40,000 LSI cycles
RTC_TICK = 30_000                               # RTC PRL = 29,999 (permanent; the RTC is only the wake timer); ALR += 1 per wake
ti_s_min, ti_s_max = PRESC_S * (RELOAD_S + 1) / lsi_max, PRESC_S * (RELOAD_S + 1) / lsi_min
t_wk_min, t_wk_max = RTC_TICK / lsi_max, RTC_TICK / lsi_min
print(f"   suspend IWDG (DX-2): /{PRESC_S}, RLR {RELOAD_S} -> {PRESC_S*(RELOAD_S+1)} LSI cycles = {ti_s_min:.3f} .. {ti_s_max:.3f} s (<= 1.6 s); RTC-alarm")
print(f"   wake every {RTC_TICK} LSI cycles = {t_wk_min:.2f} .. {t_wk_max:.2f} s (same LSI as the IWDG -> margin {PRESC_S*(RELOAD_S+1)-RTC_TICK} cycles ="
      f" {(PRESC_S*(RELOAD_S+1)-RTC_TICK)/lsi_max:.2f} .. {(PRESC_S*(RELOAD_S+1)-RTC_TICK)/lsi_min:.2f} s, no tolerance stack).")
print("   (A 0.67-1.6 s wake cannot sit inside a <= 1.6 s timeout on the same LSI: the wake is set to 75 % of the timeout.)")
assert ti_s_max <= 1.6 + 1e-12 and RTC_TICK < PRESC_S * (RELOAD_S + 1)
print("   order: entry - after PC10/PC11 low, write the suspend PR/RLR during the 0.53 ms discharge wait (PVU/RVU <= 5 LSI cycles")
print("   = 0.2 ms, inside the wait), then ANA_EN low, refresh (long timeout starts), Stop -> the suspend bound is unchanged;")
print("   exit - first action after the Stop exit: write /4, RLR 239, wait PVU/RVU (<= 0.2 ms), refresh -> 16.0 .. 38.4 ms BEFORE any")
print("   domain (ANA_EN) is enabled; every run state (attach, configured, programming) uses the short timeout.")
T_STR_X201 = 3e-3                      # Kyocera t_sta/t_ena <= 2 ms [DS spec], 3 ms [catalogue, D-3]
T_MCLK_SETTLE = 6e-3                   # firmware wait after the enable edge: NDK 4 ms x 1.5 (Kyocera 3 ms x 2)
T_RESETB = T_MCLK_SETTLE + 1e-3        # ESS: RESETB >= 1 ms after MCLK stable -> 7 ms after MCLK_EN/MCLK_PERMIT
F_MCLK = 80e6                          # firmware build constant (D-3 revised)
t_x201 = T_MCLK_SETTLE
print(f"   X201: MCLK stable <= {T_STR_X201*1e3:.0f} ms (Kyocera; 2 ms spec) / 4 ms (NDK) after INH high -> firmware waits "
      f"{T_MCLK_SETTLE*1e3:.0f} ms, RESETB high >= {T_RESETB*1e3:.0f} ms after MCLK_EN/MCLK_PERMIT")
print("   X201 stop: MCLK_PERMIT low -> U206 <= 4.9 ns -> Kyocera stand-by <= 200 ns [DS]; PB1 readback must read 0 within 10 us;")
print("   the same U206 output gates the output switch (Q616 via R645, D-19)")
print(f"   F_MCLK = {F_MCLK/1e6:.0f} MHz build constant: soft-start wait {1.2*4096*2**11/F_MCLK*1e3:.1f} ms, DPLL table at 80 MHz; the first lock")
print("   checks FSR x 2^32 / DPLL_NUM within +-0.1 % of F_MCLK")
t_osc = 10e-3
print(f"   family oscillator: enable -> use >= {t_osc*1e3:.0f} ms (NDK 4 ms x 2.5; SiT8008 5 ms x 2)")

print()
print("2. Suspend / bus reset / disconnect timeline from the last SOF (USB 2.0 7.1.7.6: suspend current <= 10 ms)")
spi_word = 32 / 9e6                          # one REG_WRITE (16-bit header + 16-bit data) at 9 MHz
i2c_w = 30 / 100e3                           # ES9018K2M single register write at 100 kHz ~ 30 bit times
i2c_burst2 = 30 / 100e3                      # R9 E-10: reg 7 = 0x83 (mute) only; reg 8 = 0x12 permanent (GPIO2 = lock, GPIO1 = min volume)
T_RAMP_GND = 4096 * 2 ** (3 + 1) / F_MCLK    # reg 14 = 0x03: soft_start 0, soft_start_time 3 -> ramp to ground [DS reg 14]
assert abs(T_RAMP_GND - 0.8192e-3) < 1e-6
T_RAMP_WAIT = 1.1e-3                         # >= 0.819 ms ramp + margin (analog R2)
VOL_RATE = 0                                 # fastest: 0.0078125 x fs / 2^(vol_rate-5) dB/s [DS reg 6] = 0.25 x fs dB/s; kept at init


def mute_time(fs, att_db=0.0):
    """ESS soft mute from the present attenuation to -inf: (127.5 - att) dB + one 0.5 dB step at 0.25 fs dB/s."""
    return (127.5 - att_db + 0.5) / (0.0078125 * fs / 2 ** (VOL_RATE - 5))


T_DET = 1.02e-3                              # SOF-loss timer 1.0 ms (D-16) + ISR 20 us [ASSUMP]
T_FLAG = 2 * 39 / 100e3                      # R9 E-10: min-volume flag read over I2C (reg 65 bit 0 = GPIO1 pin), back-to-back 0.39 ms reads -> <= 2 reads
T_CPLD_FADE = 1.0e-3                         # RTL requirement (round 3): FADE command -> linear 1 ms ramp to digital zero
T_DAC_PIPE = 1.0e-3                          # ESS filter/pipeline delay bound [ASSUMP: ~40 samples at 44.1 kHz]
post = [("RELAY_EN low; wait T_SW_OFF_WAIT (switch open <= 1.01 ms)", T_SW_OFF_WAIT),
        ("I2C reg 14 = 0x03 (ramp to ground; NACK -> retry once, then continue and log)", i2c_w),
        ("wait for the ramp (1.1 ms); MCLK still running", T_RAMP_WAIT),
        ("MCLK_PERMIT low (X201 stopped <= 0.2 us, Q616 off), PB1 = 0; SPI CLOCK_CTRL = 0, I2S_CTRL = 0", 1e-6 + 2 * spi_word),
        ("PA8 HIGH (Q207 on -> DAC reset); N2_LINK_*_MCU low (before AUD_EN, states #17)", 0.2e-6),
        ("PC10 (AUD_EN) + PC11 (AVCC_EN) low in one GPIOC write; wait 3V3D discharge bound 0.53 ms", 0.53e-3),
        ("ANA_EN low (X-1: rails stop with 5V_ANA_F), ILIM_HI low, LEDs off", 1e-6),
        ("enter Stop (USBHS PHY suspended) [ASSUMP 0.1 ms]", 0.1e-3)]
t_post = sum(d for _, d in post)
T_3V3A_DIS = 0.35e-3                          # 3V3A EN-derived discharge bound (power)
post_fb = [("RELAY_EN low; wait T_SW_OFF_WAIT", T_SW_OFF_WAIT), ("reg 14 = 0x03 write, NACK", i2c_w), ("retry, NACK", i2c_w),
           ("fallback (analog): MCLK_PERMIT low + CLOCK_CTRL/I2S_CTRL = 0 (MCLK off)", 1e-6 + 2 * spi_word),
           ("PC11 AVCC_EN low -> U605B pulls AUD_EN low at 3V3A < ~3.1 V (X-6): 3V3D/1V3 decay in parallel; wait 3V3A < 0.1 V "
            "(V3A_MON, bound 0.35 ms + margin)", 0.5e-3),
           ("PA8 HIGH (RESETB low), link pins low, PC10 low; wait the rest of the 3V3D bound (0.53 ms, counted in full)", 0.53e-3),
           ("ANA_EN low, ILIM_HI low, LEDs off", 1e-6), ("enter Stop", 0.1e-3)]
t_post_fb = sum(d for _, d in post_fb)
assert t_post_fb <= t_post, "fallback path must not lengthen the suspend timeline"
MARGIN = 1.5e-3
T_MUTE_DEADLINE = 5.31e-3 - (T_DET + i2c_burst2)   # DX-1: deadline anchored at 5.31 ms after the last SOF (unchanged by E-10)
print(f"   {T_DET*1e3:6.3f} ms  SOF-loss timer (1.0 ms, D-16) + ISR; SPI FADE command to the CPLD (RTL: 1 ms linear ramp to zero)")
print(f"   {(T_DET+i2c_burst2)*1e3:6.3f} ms  I2C: reg 7 = 0x83 (soft mute, vol_rate 0 kept since init); reg 8 = 0x12 stays (GPIO2 = lock, GPIO1 = min vol)")
print(f"            poll reg 65 bit 0 (GPIO1 = minimum volume) back-to-back over I2C (<= {T_FLAG*1e3:.2f} ms detection), bounded by the deadline 5.31 ms after the last SOF")
print(f"   then the round-2 power-down order ({t_post*1e3:.2f} ms):")
for n, d in post:
    print(f"            +{d*1e3:5.3f} ms  {n}")
print(f"   mute ramp (vol_rate 0 = 0.25 x fs dB/s) from 0 dB attenuation, and the resulting suspend-current time:")
print(f"   {'fs':>7} {'ramp':>8} {'status by':>10} {'suspend at':>10} {'margin':>7}  att. needed for status  level at deadline")
rows_s = []
for fs in (44_100, 48_000, 88_200, 96_000, 176_400, 192_000, 352_800, 384_000):
    tr = mute_time(fs)
    t_wait = min(tr, T_MUTE_DEADLINE)
    t_s = min(T_DET + i2c_burst2 + tr + T_FLAG, 5.31e-3) + t_post   # flag path or the SOF-anchored deadline, whichever first
    att_need = max(0.0, 128.0 - 0.25 * fs * T_MUTE_DEADLINE)
    lvl = -min(128.0, 0.25 * fs * T_MUTE_DEADLINE)
    rows_s.append((fs, tr, t_s))
    print(f"   {fs:7d} {tr*1e3:6.2f} ms {'status' if tr <= T_MUTE_DEADLINE else 'deadline':>10} {t_s*1e3:8.2f} ms {(10e-3-t_s)*1e3:5.2f} ms"
          f"  >= {att_need:5.1f} dB             {lvl:6.1f} dB (DAC ramp alone)")
    assert t_s <= 10e-3 - MARGIN + 1e-9
t_susp = max(r[2] for r in rows_s)
t_zero = T_DET + spi_word + T_CPLD_FADE + T_DAC_PIPE
print(f"   -> suspend current reached <= {t_susp*1e3:.2f} ms after the last SOF at every fs and volume; margin >= {(10e-3-t_susp)*1e3:.2f} ms [CALC]")
print(f"   The binding order alone (wait for the status with no deadline) needs {(T_DET+i2c_burst2+mute_time(44_100)+T_FLAG+t_post)*1e3:.1f} ms at 44.1 kHz")
print(f"   and 0 dB attenuation (> 10 ms): at fs <= 96 kHz the status can come after the deadline. The CPLD FADE makes the")
print(f"   deadline pop-free: digital zero at the DAC output <= {t_zero*1e3:.2f} ms after the last SOF (< deadline "
      f"{(T_DET+i2c_burst2+T_MUTE_DEADLINE)*1e3:.2f} ms), so the switch opens on the muted/zero-code output at every fs.")
assert t_zero < T_DET + i2c_burst2 + T_MUTE_DEADLINE
print(f"   (FIFO content at SOF loss, 11.61 ms max at 44.1 kHz, is faded by the CPLD, not truncated.)")
print(f"   I2C double failure (reg 14 NACK twice): analog fallback order MCLK off -> AVCC_EN low -> 3V3A < 0.1 V -> PA8 high ->")
print(f"   PC10 low takes {t_post_fb*1e3:.2f} ms after the status (normal path {t_post*1e3:.2f} ms) -> the suspend bound is unchanged.")
print(f"   Logged I2C-fault path, NOT a controlled transition: with X-6, U605B collapses DVCC/DVDD 75-240 us after AVCC_EN low")
print(f"   (3V3A still ~3.1 V); analog worst case 11.9 mV (22 % mismatch) / 1.9 mV (3 %) at 300 ohm vs 12.9 / 2.1 mV PA8-first -> order kept.")
print(f"   Hung-at-suspend: IWDG resets <= {t_iwdg_max*1e3:.1f} ms after the last refresh -> switch open, ENs to pull-downs; the")
print(f"   <= 10 ms deadline itself is firmware-only (states #21 residual).")

print()
print("3. Power-up after SET_CONFIGURATION (t = 0), relay open until the pre-close checks pass")
T_RAILS_GOOD = 18.8e-3         # power c18 (DY-2): rails good <= 18.8 ms after ANA_EN with C514 10 nF
T_START = 40e-3                # DY-2: start-up window - RAILS_OK_N and ANA_SENSE judged, AVCC_EN allowed, only after ANA_EN = 1 for 40 ms
ANA_TH_PIN = 4.0 * 47 / 147     # power VE: R535/R536 100 k/47 k -> 1.279 V at 5V_ANA_F = 4.0 V (1587 counts) - Default mode
ANA_TH_CODE = round(ANA_TH_PIN / 3.3 * 4096)
ANA_TH_HI_PIN = 3.90 * 47 / 147 # R10 (power c21 R10 addendum, E-16 topology): High mode (ILIM_HI = 1) 3.90 V -> band top 4.133 V vs
ANA_TH_HI_CODE = round(ANA_TH_HI_PIN / 3.3 * 4096)   # 5V_ANA_F min 4.241 V at VBUS 4.40 V incl. J101 drop -> margin +108 mV (4.00 V: -3 / +5 mV)
print(f"   start-up window T_START = {T_START*1e3:.0f} ms (DY-2): rails good <= {T_RAILS_GOOD*1e3:.1f} ms (power c18), I/V rails final <= +1 ms (analog)")
print(f"   -> margin {(T_START-T_RAILS_GOOD-1e-3)*1e3:.1f} ms. ANA_SENSE fault threshold {ANA_TH_PIN:.3f} V at the pin (5V_ANA_F 4.0 V, power divider) = ADC")
print(f"   code < {ANA_TH_CODE} at VDDA 3.30 V (VDDA = 3V3M +-1.5 % moves the 5V_ANA_F equivalent by +-1.5 %: 3.94..4.06 V) [CALC]")
print(f"   R10 (power c21 R10 addendum, band with ADC 11 LSB + 1 uA PA0 leakage [ASSUMP] + TPS70933 VDDA: 3.704..4.236 V): in HIGH mode")
print(f"   (ILIM_HI = 1) the threshold is 3.90 V = {ANA_TH_HI_PIN:.3f} V = code < {ANA_TH_HI_CODE} (band top 4.133 V vs 5V_ANA_F min 4.241 V at VBUS 4.40 V")
print("   incl. the J101 drop, 4.257 V without: margin +108 / +124 mV, power model with the E-16 topology; with 4.00 V the margin was -3 mV")
print("   in power's first model and would be only +5 mV in the E-16 model). Default keeps 4.00 V (+71 mV). The threshold")
print("   switches with ILIM_HI (both change only with the switch open or in the downgrade sequence); a real supply fault still reads ~0 V.")
assert T_START >= T_RAILS_GOOD + 1e-3 and T_START >= 20e-3
T_CFG_TYP, T_CFG_MAX = 10e-3, 100e-3        # CPLD configuration: not published -> typical placeholder / ID-poll timeout
i2c = (5 * 29 + 56) / 100e3                  # 5 single-byte writes + one 4-byte master-trim burst at 100 kHz
for label, t_cfg in (("CPLD config 10 ms [ASSUMP]", T_CFG_TYP), ("CPLD config 100 ms (timeout)", T_CFG_MAX)):
    ev = {}
    ev["ANA_EN"] = 0.0
    ev["rails good valid (X-1: RAILS_OK_N valid with ANA_EN = 1 >= T_START)"] = ev["ANA_EN"] + T_START
    ev["AVCC_EN"] = ev["rails good valid (X-1: RAILS_OK_N valid with ANA_EN = 1 >= T_START)"]
    ev["AUD_EN"] = ev["AVCC_EN"] + 1e-3        # PC10 high; U605B releases AUD_EN only once 3V3A is good (X-6)
    ev["CPLD ID ok"] = ev["AUD_EN"] + t_cfg
    ev["family osc on"] = ev["CPLD ID ok"]
    ev["MCLK_PERMIT, MCLK_EN"] = max(ev["CPLD ID ok"], ev["AUD_EN"] + 3e-3)
    ev["MCLK self-test (PB1 = 0 with PERMIT low, 1 with PERMIT high)"] = ev["MCLK_PERMIT, MCLK_EN"]
    ev["RESETB high"] = ev["MCLK_PERMIT, MCLK_EN"] + T_RESETB
    ev["I2C init done"] = ev["RESETB high"] + i2c
    ev["I2S_RUN (osc settled)"] = max(ev["I2C init done"], ev["family osc on"] + t_osc)
    ev["soft-start end, taken at the analog x1.2 allowance (104.9 ms x 1.2 after I2C init)"] = ev["I2C init done"] + 1.2 * 4096 * 2 ** 11 / F_MCLK
    ev["DC_PERMIT_N low (<= 205 ms after the soft-start end; CM/clock fault at 300 ms)"] = ev["soft-start end, taken at the analog x1.2 allowance (104.9 ms x 1.2 after I2C init)"] + 205e-3
    ev["pre-close checks (DC_PERMIT_N low >= 150 ms after a trip - R9 E-2 re-arm; the soft-start CM trip counts)"] = ev["DC_PERMIT_N low (<= 205 ms after the soft-start end; CM/clock fault at 300 ms)"] + 150e-3
    ev["V3A_MON in window >= 150 ms"] = ev["AVCC_EN"] + 0.2e-3 + 150e-3
    ev["RELAY_EN high (fresh low->high edge; PB0 = armed within 1 ms)"] = max(ev["pre-close checks (DC_PERMIT_N low >= 150 ms after a trip - R9 E-2 re-arm; the soft-start CM trip counts)"], ev["V3A_MON in window >= 150 ms"])
    print(f"   {label}:")
    for k, v in sorted(ev.items(), key=lambda kv: kv[1]):
        print(f"      {v*1e3:7.1f} ms  {k}")
    for fs in (44_100, 48_000, 384_000):
        lock = ev["I2S_RUN (osc settled)"] + 16384 / fs + 10e-3
        unmute = max(ev["RELAY_EN high (fresh low->high edge; PB0 = armed within 1 ms)"] + T_SW_ON, lock)
        print(f"      fs {fs:6d}: lock + 10 ms at {lock*1e3:6.1f} ms -> unmute (volume ramp starts) at {unmute*1e3:6.1f} ms")

print()
print("4. Rate / family change - round 3: with the output switch OPEN (states #9: mute -> RELAY_EN low -> change/relock ->")
print("   pre-close checks -> close -> ramp); the table below is the mute/lock part, the switch-open total follows it")


def ramp(fs):
    return 127.5 / (0.0078125 * fs / 2 ** (2 - 5))    # vol_rate = 2 (default) [DS p.6]


print(f"   {'old fs':>7} {'new fs':>7} {'mute ramp':>10} {'timeout':>8} {'lock':>8} {'timeout':>8} {'total':>8}")
worst = 0
for old, new, fam in ((48_000, 44_100, True), (44_100, 48_000, True), (384_000, 44_100, True), (44_100, 88_200, False),
                      (192_000, 384_000, False), (352_800, 384_000, True)):
    t_m = ramp(old)
    t_lock = 16384 / new
    total = t_m + 0.1e-3 + (t_osc if fam else 0) + 0.1e-3 + t_lock + 10e-3 + ramp(new)
    worst = max(worst, total)
    print(f"   {old:7d} {new:7d} {t_m*1e3:8.1f} ms {1.5*t_m*1e3:6.1f} ms {t_lock*1e3:6.1f} ms "
          f"{(1.5*t_lock+10e-3)*1e3:6.1f} ms {total*1e3:6.1f} ms{'  (family change)' if fam else ''}")
print(f"   -> worst case {worst*1e3:.0f} ms with the default vol_rate 2 (round-2 table, kept for reference)")
worst_open = 0
for old, new, fam in ((48_000, 44_100, True), (44_100, 48_000, True), (384_000, 44_100, True), (44_100, 88_200, False),
                      (192_000, 384_000, False), (352_800, 384_000, True)):
    t_tot = (1.5 * mute_time(old) + T_FLAG + T_SW_OFF_WAIT + 0.1e-3 + (t_osc if fam else 0) + 0.1e-3 + 1.5 * 16384 / new + 10e-3
             + 205e-3 + 150e-3 + T_SW_ON + mute_time(new))   # R9 E-2: >= 150 ms DC_PERMIT_N low if a trip occurred (conservative: always)
    worst_open = max(worst_open, t_tot)
print(f"   switch-open sequence (mute timeout 1.5 x ramp at vol_rate 0, 1.1 ms open, osc 10 ms, lock timeout 1.5 x 16384/fs + 10 ms,")
print(f"   DC_PERMIT_N re-grant <= 205 ms + 50 ms pre-close, close, 10 ms, unmute ramp): worst {worst_open*1e3:.0f} ms [CALC]; MCLK is never touched")

print()
print("4a. Attach: D+ pull-up within TSIGATT <= 100 ms of VBUS valid (USB 2.0 7.1.7.3); t = 0 at plug-in (VBUS valid)")
T_5VSYS = 0.0            # R9 E-16: U502 TPS70933 is fed from VBUS -> the MCU no longer waits for U102 (5V_SYS up <= 55.3 ms runs in parallel)
T_LDO = 1.15e-3          # power: TPS7A20 (U502) start-up to 3V3M
T_NRST = 10e3 * 1.01 * 100e-9 * 1.1 * math.log(1 / (1 - 0.7))   # R201 10 k x C212 100 nF (+10 %) to VIH 0.7 VDD [ASSUMP VIH]
T_POR = 10e-3            # CH32V307 POR/reset temporization + flash-to-zero-wait-SRAM load at boot [ASSUMP <= 10 ms, as power c20 b; not in the retrieved DS text]
T_FW = [("low-clock phase on HSI (attach current rule, power I3c)", 5.2e-3), ("HSE start-up <= 4 ms [DS Tab 4-12]", 4e-3),
        ("PLL lock <= 0.2 ms [DS]", 0.2e-3), ("USBHS PHY PLL [ASSUMP]", 1e-3), ("USB core init, D+ pull-up enabled [ASSUMP]", 1e-3)]
t = T_5VSYS + T_LDO + max(T_NRST, 0) + T_POR
print(f"   {T_5VSYS*1e3:6.2f} ms  VBUS valid; U502 (TPS70933, on VBUS since E-16) starts at once; 5V_SYS (U102) comes up <= 55.3 ms later, in parallel")
print(f"   {(T_5VSYS+T_LDO)*1e3:6.2f} ms  3V3M up (LDO start-up 1.15 ms [ASSUMP, as the TPS7A20 figure])")
print(f"   {t*1e3:6.2f} ms  MCU out of reset: NRST RC {T_NRST*1e3:.2f} ms (R201/C212, VIH 0.7 VDD) + POR/boot load {T_POR*1e3:.0f} ms [ASSUMP]")
for n, d in T_FW:
    t += d
    print(f"   {t*1e3:6.2f} ms  {n}")
T_SIGATT = t
TSIGATT_MAX = 100e-3
print(f"   -> D+ pull-up (attach signalled) <= {T_SIGATT*1e3:.1f} ms after VBUS valid; TSIGATT 100 ms -> margin {(TSIGATT_MAX-T_SIGATT)*1e3:.1f} ms [CALC on ASSUMP]")
print("      The CC classification (100 ms stable window) and ADC start run in parallel and do not delay the pull-up; High mode waits for them.")
print("      E-16: the U102 switch-on delay (<= 55.3 ms) no longer affects TSIGATT; it only delays the audio power-up (5V_SYS good first).")
assert T_SIGATT < TSIGATT_MAX

print()
print("5. Resume from suspend (host resume; remote wake-up not used)")
t_wake = 76.7e-6 + 4e-3 + 200e-6 + 1e-3
print(f"   Stop exit 76.7 us [DS-typ] + HSE <= 4 ms [DS] + PLL <= 0.2 ms [DS] + USBHS PHY PLL <= 1 ms [ASSUMP] = "
      f"{t_wake*1e3:.2f} ms before the USB core is clocked")
print("   USB: host drives resume >= 20 ms and the device must respond 10 ms after it ends [USB 2.0, values not re-read]")
print(f"   -> margin >= {30-t_wake*1e3:.1f} ms; the audio power-up (section 3) runs after the bus is active again")

print()
print("6. MCU reset / IWDG (hardware only; firmware absent)")
for t_, e in ((0.0, "NRST low, PDR, or IWDG expiry: every GPIO becomes a floating input"),
              (0.19e-6, "MCLK_PERMIT < 0.8 V via R234 -> U206 Y low (4.9 ns)"),
              (0.39e-6, "X201 stand-by, oscillation stopped (Kyocera t_dis <= 200 ns) -> XI < 0.4 V after <= 0.28 us more (R227); Q616 off ~1.3 us"),
              (24.7e-6, "earliest 3V3A discharge start (AVCC_EN via R303 -> Q502/Q503)"),
              (0.53e-3, "3V3D < 0.1 V (AUD_EN -> R508 10k), 1V3 first; ANA_EN falls to R513 (X-1: rails stop with 5V_ANA_F); PA8 floats -> R240 -> Q207 on -> DAC reset (tens of us)"),
              (1.01e-3, "output switch open (RELAY_EN -> R646; LED strings off)")):
    print(f"   {t_*1e3:8.4f} ms  {e}")
print("   after reset: >= 5.2 ms on HSI at low clock (attach current), IWDG restarted, USB re-enumerates, full power-up from S1")

print()
print("7. Brown-out / unplug")
print("   AWD ADC1 IN1 < 1587 codes (5V_SYS 4.00 V, band 3.77..4.23 V): a 5.0 -> 3.5 V step is flagged 0.35 ms later (C103 tau 0.32 ms)")
print("   ISR (highest priority, analog R2; R9 power c14 b): RELAY_EN (PA11, GPIOA) then AVCC_EN + AUD_EN (PC11 + PC10, one GPIOC write) low back-to-back (< 0.1 us")
print("   apart; different ports), no 1.1 ms wait -> X201 stops <= 0.2 us later via U206 input B (and Q616 off, D-19), 3V3A discharges")
print("   <= 0.35 ms (DAC-pin clamp exposure <= 0.62 ms instead of <= 4.9 ms); then MCLK_PERMIT/MCLK_EN low, RESETB low, AUD_EN low,")
print("   rails low after 0.53 ms if 3V3M still holds.  Exception by analog request: AVCC changes while the switch may still be")
print("   closed for <= 1.01 ms (unplug pop stays a [MEAS] target); RESETB is still never pulled low before the switch is open.")
print("   hard unplug: 5V_SYS collapses in tens of us -> photorelay LEDs drop out (switch open <= 1 ms), 3V3M falls below the MCU")
print("   PDR -> section 6 applies (X201 stopped by R234).  Unplug pop is the analog stream's [MEAS] target (<= 20 mV).")

print()
print("8. Programming mode (D-15; round 3: only AFTER SET_CONFIGURATION with 500 mA granted, states #20)")
steps = [("ILIM_HI low (Default), RELAY_EN low, MCLK_PERMIT low, DAC_RESETB low, link pins low", 0.0),
         ("SET_CONFIGURATION received (500 mA granted); until then the 3V3M-only state (<= 100 mA)", 0.0),
         ("ANA_EN", 0.0), ("rails good valid (RAILS_OK_N low with ANA_EN = 1 >= T_START = 40 ms; ANA_SENSE >= 1.279 V)", T_START),
         ("AVCC_EN", T_START), ("PC10 -> AUD_EN (>= 1 ms after AVCC_EN; U605B gate)", T_START + 1e-3),
         ("CPLD_NRST released; J202 JTAG may program the CPLD", T_START + 1e-3)]
for n, t_ in steps:
    print(f"   {t_*1e3:6.1f} ms  {n}")
print("   MCLK stays off in hardware (MCLK_PERMIT low -> U206 Y low regardless of CPLD ISP pull-ups); RESETB low (DAC in reset);")
print("   switch open twice over (RELAY_EN low and Q616 off via N2_MCLK_OE, D-19); DC_PERMIT_N reads high (DAC in reset -> CM")
print("   window tripped) - expected here, not a fault; red LED blinks; exit only by MCU reset.")

print()
print("9. Fault timing (protection 8-10, merged)")
print("   DC_PERMIT_N rising (EXTI3, highest priority): RELAY_EN low <= 50 us; switch open <= 1.01 ms after RELAY_EN (<= 1.22 ms")
print("   after a comparator trip in hardware); then 1.1 ms -> MCLK off -> shutdown order; retry after 2 s through the full")
print("   pre-close checks; 3 DC/CM trips within 10 s -> locked until USB replug (red LED).  Controlled/fault power-down with the")
print("   rails up uses the section-2 order from RELAY_EN low on (incl. the reg 14 = 0x03 ramp); if the rails already collapsed,")
print("   AVCC_EN low at once.")
print("   Tiers every 1.000 ms (20 new samples per channel at 20.000 kHz, averaged in pairs to the protection's 10 kHz stream):")
print("   T1 100 ms / T2 300 ms / T3 1.2 s windows = 1000 / 3000 / 12000 pair-averages (2000 / 6000 / 24000 raw samples).")
TIERS = {"T1": (0.900, 0.900, 100e-3), "T2": (0.240, 0.230, 300e-3), "T3": (0.110, 0.120, 1.2)}   # (leg V, pair V, window)
PRECLOSE = (0.070, 0.090)             # |leg|, |pair| 50 ms average (protection R3.9, unchanged by R3.17)
REFUSE = (0.129, 0.155)               # closure guaranteed refused above (protection R3.17 after DZ-1; was 0.126/0.152)
assert TIERS["T3"][1] == 0.120        # protection R3.17: pair 0.118 -> 0.120 V (no-trip level vs the 20 mV offset spec)
for k, (lg, pr, w) in TIERS.items():
    print(f"   {k}: leg {lg:.3f} V / pair {pr:.3f} V, window {w*1e3:.0f} ms")
print(f"   pre-close |leg| <= {PRECLOSE[0]:.3f} V, |pair| <= {PRECLOSE[1]:.3f} V (50 ms average); closure guaranteed refused above "
      f"{REFUSE[0]*1e3:.0f} mV leg / {REFUSE[1]*1e3:.0f} mV pair (protection R3.17, includes the DZ-1 330 R)")
assert PRECLOSE[0] < REFUSE[0] and PRECLOSE[1] < REFUSE[1]
print("   R10 F-1 (protection p21c, 08:37 incl. short opposite-polarity bursts): tiers T1-T3 UNCHANGED (thresholds, windows, deadlines) -")
print("   history-robust from any reachable state (FIR estimator); guaranteed levels leg / pair: T1 >= 1.001 / 1.015 V within 218 ms,")
print("   T2 >= 0.313 / 0.312 V within 603 ms, T3 >= 0.178 / 0.195 V within 2.36 s (rail-bounded variant 1.007 / 1.027, 0.316 / 0.316,")
print("   0.179 / 0.197 V) -> the owner rule (>= 0.2 V removed within 3 s) holds. Hardware floor |leg| >= 0.34 V, |pair| >= 0.68 V (rounded up")
print("   with clearance; LPW level max 0.32401 V, 0.33401 V with a 10 nA leakage allowance). Below it T2/T3 keep the pair <= 17.4 / 8.7 mJ")
print("   and the leg <= 14.5 / 7.3 mJ at 16 / 32 ohm. No firmware change is needed for history robustness.")
print("   RAILS_OK_N high (valid) or ANA_FAULT_N low with ANA_EN high: RELAY_EN low, controlled shutdown, ceiling -3 dB per event")
print("   down to -12 dB, retry >= 1 s; counts toward the 3-strike limit only at -12 dB.")
print()
print(f"Summary: suspend at {t_susp*1e3:.2f} ms; worst rate/family change (switch open) {worst_open*1e3:.0f} ms; IWDG {t_iwdg_min*1e3:.0f}-"
      f"{t_iwdg_max*1e3:.0f} ms. All firmware-sequence assertions passed.")

print()
print("10. Suspend budget: average current of the periodic Stop wake (IWDG refresh), for the power stream's suspend budget")
T_WAKEUP = 0.2e-3          # Stop exit incl. regulator + HSI start: 76.7 us typ [DS Tab 4-19]; no max published -> 0.2 ms [ASSUMP]
T_CODE = 30e-6             # ISR: IWDG reload, clear EXTI17/ALRF, CNF=1, ALR += 1, CNF=0, check USB resume flags [ASSUMP at HSI 8 MHz]
N_RTOFF = 3                # wait RTOFF = 1 after the ALR write: <= 3 RTCCLK periods [ASSUMP: STM32F1-compatible RTC, V3x RM not retrieved]
I_RUN_HSI = 10e-3          # MCU at HSI 8 MHz [ASSUMP, L-1 style conservative; WCH current tables not retrieved]
I_STOP = 1.9e-3            # L-1 conservative Stop current (already in the budget)


def wake_avg(tick):
    return max((I_RUN_HSI - I_STOP) * (T_WAKEUP + T_CODE + N_RTOFF / f) / (tick / f) for f in (lsi_min, 40e3, lsi_max))


worst_i = wake_avg(RTC_TICK)
for f_lsi in (lsi_min, 40e3, lsi_max):
    t_act = T_WAKEUP + T_CODE + N_RTOFF / f_lsi
    print(f"   LSI {f_lsi/1e3:4.0f} kHz: active {t_act*1e6:5.0f} us every {RTC_TICK/f_lsi:5.2f} s -> "
          f"+{(I_RUN_HSI-I_STOP)*t_act/(RTC_TICK/f_lsi)*1e6:5.2f} uA average above Stop")
print(f"   -> adopted (DX-2): add <= {worst_i*1e6:.1f} uA [CALC on ASSUMP] to the S6 suspend budget; superseded <= 30 ms scheme "
      f"(720-cycle wake): {wake_avg(720)*1e6:.0f} uA")
print("      USB 2.0 treats the suspend limit as an average (averaging window not re-read here); measure in production (L-1).")
assert worst_i < 10e-6
print()
print("11. Type-C current advertisement (states #11). Source of the thresholds: USB Type-C Cable and Connector Specification")
print("    Release 2.0 (Aug 2019), table 'Voltage on Sink CC Pins (Multiple Source Current Advertisements)' as reproduced in")
print("    ST AN5225 Table 7 (ST cites Type-C R2.0 as its reference [22]); Rd 5.1 k +-10 % needed to detect the capability")
print("    (AN5225 Table 6). Release 2.5 (Apr 2026) was not opened (zip-only download).")
SPEC = {"vRa": (-0.25, 0.15, 0.2), "vRd-USB": (0.25, 0.61, 0.66), "vRd-1.5": (0.70, 1.16, 1.23), "vRd-3.0": (1.31, 2.04, None)}
for k, (lo, hi, th) in SPEC.items():
    print(f"    {k:8s} {lo:5.2f} .. {hi:4.2f} V" + (f", threshold to the next class {th:.2f} V" if th else ""))
ERR_CC = 0.043             # CC measurement error bound, adc_settings.py section 6 [CALC]
g_up = min(0.66 - 0.61, 1.23 - 1.16)      # a lower class can never read as a higher one (safety direction)
g_dn = min(0.70 - 0.66, 1.31 - 1.23)
print(f"    upward guard {g_up*1e3:.0f} mV > error {ERR_CC*1e3:.0f} mV: a Default source never reads as >= 1.5 A [CALC]; downward guard")
print(f"    {g_dn*1e3:.0f} mV: a 1.5 A source exactly at vRd-1.5 min (0.70 V) may read Default at the worst error -> no High (safe side)")
assert g_up > ERR_CC
T_SINKADJ = 60e-3          # tSinkAdj max [Type-C spec value from memory, NOT re-read]
T_DEB = 10e-3              # 10 consecutive 1-ms CC averages below 0.66 V
t_dn = T_DEB + 1e-3 + i2c_w + 1.5 * mute_time(44_100) + 0.1e-3
print(f"    live downgrade (High -> Default): debounce {T_DEB*1e3:.0f} ms -> soft mute (vol_rate 0, timeout {1.5*mute_time(44_100)*1e3:.1f} ms at")
print(f"    44.1 kHz) -> ILIM_HI low -> 5 ms settle -> Default volume ceiling -> unmute; load reduced <= {t_dn*1e3:.1f} ms < tSinkAdj "
      f"{T_SINKADJ*1e3:.0f} ms")
assert t_dn < T_SINKADJ
print(f"    hung firmware with ILIM_HI high: IWDG <= {t_iwdg_max*1e3:.1f} ms -> R511 -> Default (< tSinkAdj) [HW backstop]")

print()
print("12. Boot self-test at every attach, before the first switch closure (switches open; criteria: protection R3.9; R10 F-1: p21b e2)")
print("    0) U206/R234 (digital): PB14 floating input (R234 holds it low) -> PB1 = 0; PB14 high with MCLK_EN = 0 -> PB1 = 0;")
print("       MCLK_EN = 1 -> PB1 = 1 (X201 runs); each readback within 10 us.")
print("    a') DELETED in R10 (the RC leg windows are removed, protection F-1); the R10 F-5 default-amplitude finding on a' is moot.")
print("    f) LPW stages (R10 F-1): CPLD test word +0.30 FS on L, then -0.30 FS, then the same on R (LP+/LN- and LP-/LN+ pairs), ANY gain")
print("       state incl. the -4.5 dB default (leg 0.417..0.698 V, pair <= 1.40 V < E-3 V_L min): DC_PERMIT_N high 72.4-99.8 ms after the DC")
print("       reaches the legs (+ DAC <= 1 ms) -> pass 65-110 ms (protection 07:09: LPW timer 910 k / 100 nF C0G; was 51.4-84.6 / 45-100 ms).")
print("    g) OR stages (R10 F-1): N6_ORTEST = PC15 high, 1 ms settle (CONFIRMED, protection p21b e2 07:37: no C on the threshold nodes, tau")
print("       <= 11.9 us, within 1 mV after <= 90 us; R951 10 k in the Q627 collector -> V_OR+ = 0.086-0.141 V, V_OR- -> -0.29..-0.15 V;")
print("       test-word margins 186 / 41 mV, idle-leg margins 66 / 128 mV), then +0.25 FS on L, -0.25 FS on L, then R (leg 0.347..0.581 V)")
print("       -> DC_PERMIT_N high 19.5-24.9 ms (+ DAC <= 1 ms)")
print("       -> pass 18-32 ms; N6_ORTEST low IN the DC_PERMIT_N EXTI handler together with the word clear (<= 50 us after the edge), or at")
print("       the 32 ms timeout (fail); after PC15 low the nodes settle with tau <= 10.3 us (no extra wait). LPW is slower (>= 71 ms) and E-3")
print("       silent (pair <= 1.16 V), so an OR failure shows as a late trip.")
print("    e) E-3: +-0.55 FS on calibrated units (protection-2 08:27, was 0.50 FS: margin +43 -> +250 mV), +-0.85 FS at the -4.5 dB default;")
print("       on L, then R (c+ and c- separately) -> 19.5-24.2 ms (+ DAC <= 1 ms), pass 18-26 ms (unchanged). Calibrated leg 1.133-1.279 V, OR")
print("       silent (1.279 V < V_OR min 1.762 V); default leg 1.133-1.554 V over the model (OR may co-fire only at the 3.66 V basis, 1.853 V,")
print("       which only masks). 0.50 FS is NOT an isolation amplitude at the default (lowest-gain pair 1.39 V < V_L; indep-check 07:57) - the")
print("       firmware selects the word from G.mode.")
print("       f/g/e: the test word is written x s_c on an MCU-scaled channel (section 20), so each leg sees a calibrated-unit voltage.")
print("    b) MCLK alive (permit present >= 50 ms): PB14 low -> PB1 low <= 10 us and DC_PERMIT_N high 0.06-1.25 ms (pass <= 2.0 ms);")
print("       PB14 high -> DC_PERMIT_N low 64-208 ms (pass <= 250 ms).")
print("    c) 1V3 good: PB8 (N6_V13_TEST, open drain) low 5 ms -> DC_PERMIT_N high within 0.87 ms (pass <= 2.0 ms); release ->")
print("       low 61-205 ms (pass <= 250 ms).")
print("    d) 3V3A good: before AVCC_EN, PA12 and PB9 read high; >= 2 ms after V3A_MON >= 3.20 V both read low. Optional (protection):")
print("       with 3V3A off, PC10 high for 1 ms must leave the I2C lines low (Q620 holds 3V3D off). U606 ch3 and Q619: production test.")
# R9 follow-up (orchestrator): self-test <= 3 s. The digital DC is cleared IN the DC_PERMIT_N EXTI handler (held only until the trip);
# (0) U206/PB1 and (d) 3V3A-good run inside the power-up (0 s); the E-2 clear path (PB0 low) is read at every trip (0 s).
R_REC = 0.209                                   # protection p20: DAC removal <= 1 ms + release <= 3 ms + H recovery <= 205 ms
T_F_MAX, T_G_MAX, T_E_MAX, T_BC = 0.110, 0.032, 0.026, 0.002 + 0.250    # pass maxima (f 65-110, g 18-32, e 18-26 ms); b, c


def t_selftest(n_or, r_rec=R_REC):
    """4 LPW runs + n_or OR runs + 4 E-3 runs, each followed by the recovery R, + b and c (pass limits)."""
    return 4 * T_F_MAX + n_or * T_G_MAX + 4 * T_E_MAX + (8 + n_or) * r_rec + 2 * T_BC


t_st_all, t_st_rot = t_selftest(4), t_selftest(1)
print("    Timing (R10 F-1, protection pass limits; DC cleared at the trip; (0), (d) and the PB0 clear-path checks in parallel):")
print(f"       every channel PAIR plus the shared paths, every boot: 4 x 110 (f) + 4 x 32 (g) + 4 x 26 (e) + 12 x R + 2 x 252 (b, c) = {t_st_all:.2f} s  <- IMPLEMENTED")
print(f"       (protection's sizing; was 2.84 s in R9; exceeds the R9 orchestrator target <= 3 s by {t_st_all-3.0:.2f} s)")
print(f"       option: one OR direction per boot, rotating LP+/LN-, LP-/LN+, RP+/RN-, RP-/RN+ (all four pairs within 4 boots): {t_st_rot:.2f} s <= 3 s")
print("       -> owner decision, presented by protection (protection recommends testing every pair at every boot). The rotation needs a persistent index: flash boot-counter page (append-only")
print("       half-words, one program per boot in the HSI phase, erase once per 2048 boots deferred to an idle period with the domains off)")
print("       = 4 KB flash + ~0.2 KB code; the RTC backup registers are lost at unplug (VBAT from 3V3M), so they cannot carry it.")
print(f"    R <= {R_REC*1e3:.0f} ms after every trip (protection p20; the new LPW timers reset <= 9.6 ms, inside it); PB0 low after every trip")
assert abs(t_st_all - 3.684) < 0.001 and abs(t_st_rot - 2.961) < 0.001 and t_st_rot <= 3.0   # protection 07:09: 3.68 / 2.96 s
print(f"    owner-visible: the first audio after an attach starts about {t_st_all:.1f} s + the 0.54 s power-up later (tests run after SET_CONFIGURATION, in")
print("    parallel with the host's own start-up; later closures do not repeat them). Firmware cost: CPU < 0.1 % (timer + EXTI), RAM < 64 B")
print("    (state, pass/fail per run, rotation index), no ADC or I2C load.")
print("    N6_ORTEST (PC15, R10 F-1): LOW in every state except (g); every pre-close check also verifies PC15 ODR = 0; a stuck-high line makes")
print("    every OR channel fire at |leg| >= 0.30 V (fail-safe: trips, no masking); IWDG/reset -> Hi-Z -> test off.")
print("    after every self-test trip PB0 (N6_ARM_MCU) must read low (E-2 clear path), and the re-arm sequence (section 18) precedes the first closure")
print("    Any failure -> no RELAY_EN, red LED, log.")
V_L_MAX = 2.016                                  # E-3 pair level maximum (protection p21: V_L max / 2 = 1.008 V)
leg_cal_min = 1.55 * math.sqrt(2) * 10 ** (-(0.10 + 0.081) / 20) * (1 - 0.0392 - 0.0015)   # P-4 low end, smaller leg, G drift down
leg_def_min = 2.333 * 0x4C3EA838 / 2 ** 31       # lowest-gain unit at the default (analog r10_fixes F-5)
X_E_CAL, X_E_DEF = 0.55, 0.85                    # E-3 test words (protection-2 08:27)
DRIFT_DN = 1 - 0.0392 - 0.0015                   # G drift down (3V3A window, TCR), applied to both states as protection does
e_cal = 2 * X_E_CAL * leg_cal_min - V_L_MAX
e_def = 2 * X_E_DEF * leg_def_min * DRIFT_DN - V_L_MAX
print(f"    E-3 word check: calibrated {X_E_CAL:.2f} FS -> lowest pair {2*X_E_CAL*leg_cal_min:.3f} V (P-4 low end, smaller leg, G drift down) vs V_L"
      f" max {V_L_MAX:.3f} V: {e_cal*1e3:+.0f} mV; default {X_E_DEF:.2f} FS -> {2*X_E_DEF*leg_def_min*DRIFT_DN:.3f} V: {e_def*1e3:+.0f} mV [CALC];")
print(f"    OR silent at the calibrated ceiling + drift: {X_E_CAL*2.325:.3f} V < 1.762 V; LPW slower (>= 71 ms)")
assert e_cal > 0.2 and e_def > 0.2 and X_E_CAL * 2.325 < 1.762
print("    COVERAGE (indep-check 07:57): a balanced word arms two parallel paths on the same summing node (+L: LP+ positive with LN- negative;")
print("    -L: the converse), so each (f)/(g) run proves AT LEAST ONE of the two channels - an open channel is masked by its mate. The")
print("    self-test gives PAIRWISE coverage for LPW/OR (every channel pair plus the shared paths), not per-channel coverage: a single dead")
print("    channel or a one-sided reference fault is masked by its mate. Per-channel coverage comes only from protection's production per-leg")
print("    injection (protection-2 08:20). DECISION (protection-2 08:27): (A) pairwise coverage stated as a limitation (0 parts; a latent dead")
print("    channel still leaves the independent firmware tiers for single-leg faults: T1 >= 1.001 V within 218 ms, T3 within 2.36 s). Presented to")
t_b = t_selftest(8) ; t_c = t_b + 4 * (T_F_MAX + R_REC)
print(f"    the owner: (B) per-channel OR - split N6_ORTEST into T+ (PC15 -> Q627) and T- (a CPLD IO -> R937 return, external pull-down), +1 RTL")
print(f"    bit, 8 OR runs -> {t_b:.2f} s; (C) + per-channel LPW (second CPLD line, ~4-6 parts, 8 LPW runs) -> {t_c:.2f} s. No firmware/RTL change unless chosen.")
assert abs(t_c - 5.924) < 0.01

print()
print("13. Stream guards - OD-1 rule (DZ-11, protection p15), identical in the USB-side guard (decoded PCM, per microframe) and the")
print("    post-CPLD guard (I2S2 capture PB12/13/15, 32-bit frames, circular DMA, 0.5 ms half-blocks); per channel, every rate")
L_P1, T_P1 = 0.30, 22.0e-3
print(f"    P1 (new) level persistence: every sample of the last {T_P1*1e3:.1f} ms >= +{L_P1} FS, or every sample <= -{L_P1} FS (run counter")
print("       reset by any sample inside +-L or a sign change); implemented per block: block min/max (shared with P3) extend the run when")
print("       the whole block qualifies, otherwise a backward scan from the block end gives the exact trailing run (sample-exact rule)")
print("    P2 CIC2 (two cascaded 50 ms boxcars) |D| >= 0.25 FS (protection final: was 0.30); P3 flat: range <= 1e-3 FS over 26 ms and")
print("       |mean| >= 0.02 FS (unchanged); P4 (new) CIC2 (two cascaded 150 ms boxcars, N = 0.15 x fs) |D| >= 0.15 FS")
print("    P2/P4 implementation: per-sample block sums shared with P1/P3; boxcars as running sums of 0.5 ms block values (50 ms = 100,")
print("       150 ms = 300 blocks; stage 1 exact, stage 2 sampled per block -> <= 0.5 ms timing difference, inside the 1 ms latency);")
ram = (100 + 300) * 2 * 2 * 4
print(f"       RAM {ram/1024:.1f} KB per guard ({2*ram/1024:.1f} KB for both; 32-bit means) [CALC]; CPU per block negligible (P4 adds no per-sample work)")
print("    action: USB-side -> zero the pair with a 1 ms ramp + log (release |D| < 0.05 FS for 1 s); post-CPLD -> RELAY_EN low")
print("       (switch open <= 1.008 ms) + zero + log, re-close only through the pre-close sequence (strike counted)")
BLK_PC, BLK_USB = 0.5e-3, 125e-6
t_dec_pc = BLK_PC + 0.1e-3
t_dec_usb = BLK_USB + 0.1e-3
print(f"    decision latency (protection limit <= 1 ms): post-CPLD <= {t_dec_pc*1e3:.2f} ms (0.5 ms block + 0.1 ms), USB-side <= {t_dec_usb*1e3:.3f} ms")
assert t_dec_pc <= 1e-3 and t_dec_usb <= 1e-3
for fs in (44_100, 384_000):
    print(f"    fs {fs:6d}: P1 trips {T_P1*1e3:.0f} ms + <= {t_dec_pc*1e3:.1f} ms after a >= 0.30 FS one-sided run starts; P3 26 ms; P2 <= 100 ms; P4 <= 300 ms (+ latency)")
print("    (USB-side: the CPLD FIFO latency delays both the DC and the zeroing equally -> DAC-output exposure = T_P + T_DEC + T_ACT)")
for fs in (44_100, 48_000, 384_000):
    print(f"    N = ceil(0.022 x fs) = {math.ceil(0.022*fs)} samples at {fs} Hz")
t_exp = T_P1 + t_dec_pc + 1.008e-3
print(f"    exposure P1 = {T_P1*1e3:.1f} + {t_dec_pc*1e3:.2f} + 1.008 (switch open; >= the 1 ms zero ramp) = {t_exp*1e3:.2f} ms <= 24 ms (protection energy basis)")
assert t_exp <= 24e-3
CYC_BASE, CYC_P1_TYP, CYC_P1_WORST = 15, 3, 10     # per stereo frame [ASSUMP ~1 IPC]: P2 sums + P3 min/max; P1 typical / worst (second pass)
f_cpu = 144e6
for fs in (192_000, 384_000):
    typ = fs * (CYC_BASE + CYC_P1_TYP) / f_cpu
    wst = fs * (CYC_BASE + CYC_P1_WORST) / f_cpu
    print(f"    CPU at {fs/1e3:.0f} kHz: {typ*100:.1f} % typical / {wst*100:.1f} % worst per guard -> both guards {2*typ*100:.1f} % / {2*wst*100:.1f} % of 144 MHz;"
          f" capture DMA {fs*4/1e6:.3f} M half-words/s")
    assert 2 * wst < 0.20
print("    384/352.8 kHz post-CPLD capture needs the I2S2 slave at 24.576/22.579 MHz BCLK (bring-up [MEAS], recorded; R-5 residual if not)")
L1 = L_P1
import math as _m
f_sine = (_m.pi - 2 * _m.asin(L1)) / (2 * _m.pi * T_P1)
print(f"    content boundary (protection p15): full-scale sine never triggers P1 above {f_sine:.2f} Hz (20 Hz run {(_m.pi-2*_m.asin(L1))/(2*_m.pi*20)*1e3:.2f} ms < 22 ms);")
print(f"    a full-scale (>= 0.30 FS) square wave below {1/(2*T_P1):.1f} Hz, or one-sided DC-offset content >= 0.30 FS held 22 ms, mutes (owner-accepted, DZ-11)")

print()
print("14. OD-2 (DZ-12): DAC plausibility check (firmware only; DAC_LOCK = U301 GPIO2 on PC9, already wired)")
T_SWO = 1.008e-3          # switch open after RELAY_EN low (protection R3)
BIT = 1 / 100e3           # I2C bit time, 100 kHz standard mode (DZ-2)
t_rd2 = (1 + 9 + 9 + 1 + 9 + 2 * 9 + 1) * BIT     # reg 64-65 burst read (S, addr W, reg, Sr, addr R, 2 bytes, P)
t_rd1 = (1 + 9 + 9 + 1 + 9 + 9 + 1) * BIT         # single-register read (reg 14 sentinel)
t_cfg = (1 + 9 + 9 + 1 + 9 + 21 * 9 + 1) * BIT    # reg 0-20 burst read-back
t_dpll = (1 + 9 + 9 + 1 + 9 + 4 * 9 + 1) * BIT    # reg 66-69 DPLL ratio
T_A, T_B = 10e-3, 100e-3
t_abort = 0.1e-3          # a priority write (mute/fault/suspend) aborts a poll at the next byte boundary
t_poll_a = t_rd2 + t_cfg  # every 10 ms: reg 64-65 status + the full reg 0-20 read-back (reg 14 = 0xAA sentinel inside it)
load = (t_poll_a / T_A) + t_dpll / T_B
print(f"   Poll A every {T_A*1e3:.0f} ms ({t_poll_a*1e3:.2f} ms): reg 64-65 burst ({t_rd2*1e3:.2f} ms): lock_status = 1, automute_status = 0 (automute")
print(f"      disabled: reg 4 = 0x00), chip_id = 4, GPIO2 pin (reg 65 bit 1) = PC9 = lock; + reg 0-20 read-back vs the shadow copy ({t_cfg*1e3:.2f} ms)")
print("      incl. the reg 14 = 0xAA sentinel (reset default 0x8A) -> a DAC reset or any register corruption is seen at the next poll")
print(f"   Poll B every {T_B*1e3:.0f} ms: DPLL ratio reg 66-69 ({t_dpll*1e3:.2f} ms) within +-0.1 % of FSR x 2^32 / 80 MHz; DPLL_NUM bit-identical")
print("      over 5 reads = advisory log only [MEAS at bring-up]")
print(f"   I2C bus load {load*100:.1f} % at 100 kHz; host volume writes queue behind a poll (<= {t_poll_a*1e3:.2f} ms); priority writes abort a")
print(f"   poll <= {t_abort*1e3:.1f} ms (suspend deadline anchored to the last SOF, DX-1 numbers unchanged); CPU < 0.5 % (interrupt-driven);")
print("   the analog noise floor with polling active is a bring-up [MEAS] (fallback: poll period 20 ms -> detection times x ~2)")
det = {
    "(a) DPLL lock lost -> GPIO2 falling on PC9 (EXTI9, priority 2; 20 us confirm re-read)": 30e-6,
    "(b) poll A: lock_status 0 / automute 1 / chip_id / GPIO2 != PC9 / any reg 0-20 mismatch incl. reset (confirm re-read)": T_A + 2 * t_poll_a + t_abort,
    "(c) poll A: DAC I2C NACK (one retry)": T_A + 2 * t_poll_a + t_abort,
    "(c') bus stuck low (1 ms timeout, then 9-clock recovery)": T_A + 2 * t_poll_a + t_abort + 1e-3,
    "(d) poll B: DPLL ratio out of range (confirm re-read)": T_B + 2 * t_dpll + t_abort,
}
for k, v in det.items():
    print(f"   {k}: RELAY_EN low <= {v*1e3:7.2f} ms -> switch open <= {(v+T_SWO)*1e3:7.2f} ms")
assert det["(a) DPLL lock lost -> GPIO2 falling on PC9 (EXTI9, priority 2; 20 us confirm re-read)"] + T_SWO <= 1.05e-3
print("   masked: start-up until the first closure, rate/family changes (lock loss expected) and suspend (clocks stop); R9 E-10: GPIO2 =")
print("   lock permanently (reg 8 = 0x12, GPIO1 = min-volume flag read via reg 65 bit 0); action: RELAY_EN low, log, I2C 9-clock recovery, PA8 high >= 1 ms, full DAC re-init, lock, pre-close")
print("   checks, re-close; counts as a strike (3 in 10 s -> locked until replug).")
print("   self-test at every start (switch open, after the first lock): reg 8 = 0x72 (GPIO2 low) -> PC9 = 0, reg 65 b1 = 0, EXTI9 flag set;")
print("   reg 8 = 0xF2 (high) -> PC9 = 1; reg 8 = 0x12 -> PC9 = reg 64 b0 = 1, and reg 65 b0 = 1 while muted (GPIO1 min-volume path); 3 writes + 3 reads = "
      f"{(3*30*BIT + 3*t_rd2)*1e3:.1f} ms. Residual (documented limitation): a DAC-core hang that keeps lock = 1 and answers I2C")
print("   with correct registers - covered only by the leg windows (protection).")


print()
print("15. R9 E-9: CANONICAL POWER-DOWN ORDER (one table for every exit; digital owns it, power/analog confirm their rows)")
STEPS = [("S1", "mute: CPLD FADE (1 ms to zero) + DAC soft mute (reg 7 = 0x83, vol_rate 0); wait min-volume (reg 65 b0) or deadline"),
         ("S2", "RELAY_EN low; wait 1.1 ms (switch open <= 1.008 ms)"),
         ("S3", "DAC ramp to ground: reg 14 = 0x03 (NACK -> retry once); wait 1.1 ms (MCLK running)"),
         ("S4", "MCLK off: MCLK_PERMIT (PB14) low -> X201 stand-by, Q616 off; SPI CLOCK_CTRL = 0, I2S_CTRL = 0"),
         ("S5", "DAC reset: PA8 high (Q207 on); link pins N2_LINK_*_MCU low; I2C pins released (not driven)"),
         ("S6", "domains: PC11 AVCC_EN and PC10 AUD_EN low in ONE GPIOC write; wait >= 0.53 ms (3V3A < 0.1 V <= 0.472 ms with C440; C441 fitted -> wait >= 0.75 ms);"),
         ("  ", "   3V3D < 0.1 V <= 0.63 ms (covered by the >= 1 ms re-enable rule); DVDD <= DVCC throughout (U303 regulates ~90 us, then UVLO, Q506 ends); U605B/Q620 force AUD_EN low <= 1.04 ms after 3V3A < 3.006 V anyway"),
         ("S7", "ANA_EN low (5V_ANA_F collapses -> LM27762 stops at UVLO; I/V rails held by D411/D412 reservoirs until 3V3A < 0.3 V)"),
         ("S8", "ILIM_HI low, LEDs off"),
         ("S9", "suspend only (E-16): S7 + 0.1 ms (ANA_EN, AVCC_EN, AUD_EN all low) -> PC14 = N5_U102_OFF high = U102 off (tOFF <= 0.3 ms; VBUS_SENSE ignored);"),
         ("  ", "   IWDG long (DX-2), ADC/TIM4/PVD/VREFINT off, USBHS PHY suspend, Stop"),
         ("R0", "resume / any wake to run (E-16): IWDG short -> clocks/USB (3V3M from U502 TPS70933 on VBUS) -> PC14 low (U102 on) -> 5V_SYS good"),
         ("  ", "   (VBUS_SENSE >= 4.0 V for 5 ms, timeout 60 ms - power) -> arm the brown-out AWD -> only then any domain (B)")]
for k, v in STEPS:
    print(f"   {k}  {v}")
EXITS = [("host stop (alt 0 / stream end)", "S1 (no deadline; timeout 1.5 x ramp) -> S2; domains stay up (configured idle); a later power-down continues S3-S8"),
         ("suspend (SOF loss 1 ms)", "S1 (deadline 5.31 ms after the last SOF) -> S2 ... S8 -> S9 (U102 off); suspend current at U102 off, see section 19"),
         ("resume / bus reset in suspend", "R0 first (U102 on, 5V_SYS good, AWD armed), then power-up B; USB answers on 3V3M before 5V_SYS is up"),
         ("rate / family change", "S1 (timeout 1.5 x ramp) -> S2; no power-down; I2S_RUN = 0 -> [family: E-12 engine reset around the U205 switch] -> relock -> pre-close -> close -> ramp"),
         ("fault shutdown (DC_PERMIT_N, tiers, OD-1 post-CPLD, OD-2, overload)", "S2 FIRST (no mute wait) with S1 in parallel -> DC/CM/OD-2: domains stay up for retry (re-init per policy); overload/supply fault: S3 -> ... -> S7"),
         ("brown-out (AWD, 5V_SYS < 4.00 V)", "RELAY_EN (GPIOA) then AVCC_EN + AUD_EN (one GPIOC write) back-to-back, no wait (power c14 case b) -> S4 -> S5 after >= 1.01 ms -> ANA_EN low after >= 0.53 ms"),
         ("hard unplug", "hardware-defined: LED strings drop out (switch open <= 1 ms) -> MCU PDR -> MCU-reset row"),
         ("I2C double fault (reg 14 NACK twice)", "S1, S2, S3 fails -> S4 -> AVCC_EN low -> wait 3V3A < 0.1 V (0.5 ms) -> S5 -> AUD_EN low -> S7 (logged fault path, not controlled)"),
         ("MCU reset / IWDG", "hardware-defined: RELAY_EN -> R646 (switch open <= 1.01 ms); PB14 -> R234 (X201 stop <= 0.39 us); PA8 -> R240 -> Q207 (DAC reset);"),
         ("", "   ENs -> R303/R508/R513 (discharges on: Q502 -> N5_DIS_A -> Q503 for 3V3A; Q504 -> N5_DIS_D -> Q505/Q506 for 3V3D/1V3); ILIM_HI -> R511 (Default)"),
         ("programming mode exit", "only by MCU reset -> MCU-reset row")]
for k, v in EXITS:
    print(f"   {k:62s} {v}")

print("   analog (R9): S1/S2 no step, S3 0.126 mV, S6 0.23 / 1.46 mV (3 / 22 % mismatch), S7 negligible at 300 ohm -> every controlled exit")
print("   <= 1.46 mV. Condition [MEAS]: S4/S5 are step-free only if the ESS ramp ends in the reset (ground) state (not published): with the")
print("   switch open, leg DC before/after PA8 high must differ < 10 mV at bring-up; otherwise move S5 after S6 (firmware only).")
print("   MCU reset/IWDG row: a click up to the reset-state leg voltage (0.05-0.34 V) can pass before the switch opens (L-4, owner fault case).")

print()
print("16. R9 E-12: family switch with a CPLD engine reset around the U205 mux change (switch already open, see section 4)")
FAM = ["I2S_RUN = 0 (SPI register domain, LINK_SCK clock)", "new oscillator on (OSC48_EN or OSC44_EN), wait >= 10 ms (NDK start-up 4 ms)",
       "ENGINE_RST = 1 (new RTL register bit: asynchronous assert into the FAM_CLK domain - I2S engine, divider, FIFO read side)",
       "switch U205 (OSC44_EN selects S); any runt FAM_CLK pulse now hits only reset flip-flops", "old oscillator to stand-by",
       "wait >= 2 us (>= 90 FAM_CLK cycles)", "ENGINE_RST = 0 (2-FF synchroniser: synchronous release in the new FAM_CLK)",
       "FIFO flush/prime, divider/format registers kept (register domain untouched), I2S_RUN = 1 -> relock -> pre-close -> close -> ramp"]
for i, t in enumerate(FAM, 1):
    print(f"   {i}. {t}")
print("   fallback without the new bit: CPLD_NRST (PC5) low >= 1 ms around the switch + full register rewrite (existing error path, ~0.2 ms SPI)")

print()
print("17. R9 E-5 (digital part): suspend pin/peripheral states - digital adds 0 A beyond the MCU Stop planning value (1.9 mA, L-1) + wake")
PINS = [("PA8 high (R240 0 A), PB14/PC10-12/PA11/PA15 low (pull-downs 0 A)", 0.0), ("link pins low -> U208 Ioff (3V3D off) 0 A", 0.0),
        ("PB10/PB11 I2C released (10 k to dead 3V3D; never driven high)", 0.0), ("PB8 Hi-Z; PA12/PB9 inputs at the U605 output (3V3M) 0 A", 0.0),
        ("PC14 per E-16 (section 19); PC15 N6_ORTEST low (rails off: 0 A); PB0 input (N6_ARM_MCU); PA0/PC0-PC4 analog", 0.0), ("ADC1/ADC2 ADON = 0, TIM4 off, PVD off, VREFINT/TS off before Stop", 0.0),
        ("IWDG/RTC wake (DX-2)", I_WAKE if 'I_WAKE' in dir() else 4.54e-6)]
for n, i in PINS:
    print(f"   {n:78s} {i*1e6:5.1f} uA")
print("   -> no further firmware saving exists; the >= 0.2 mA margin (E-5) must come from power/protection loads (VBUS divider,")
print("      clamps, U605 dividers) - see adc_settings section 9 for the VBUS divider options and their ADC/brown-out limits.")

print()
print("18. R9 E-2: firmware re-arm of the hardware latch (protection U608 74LVC1G74 on 3V3D; readback PB0 = N6_ARM_MCU via R695 100 k)")
REARM = ["after ANY trip (DC_PERMIT_N went high since the last closure, incl. the soft-start CM trip and every self-test trip): RELAY_EN low",
         "wait DC_PERMIT_N low CONTINUOUSLY >= 150 ms (protection: H may need <= 80 ms after DC_PERMIT_N low to pass HREF 3.11 V; replaces the pre-close 50 ms), then the full pre-close checks (R3.2 B.6, OD-2 status, lock, R10 F-5 reg 15-20 read-back = G.M, section 20); RELAY_EN has been low >= 1 ms (latch needs ns)",
         "RELAY_EN low -> high (a fresh edge clocks the latch; RELAY_EN held high can never re-arm it)",
         "read PB0 high within 1 ms (armed); otherwise RELAY_EN low, retry after 20 ms, max 3 tries, then fault (red LED, log, no audio)",
         "self-test: after each self-test trip (f, g, e, b, c - section 12) PB0 must read low (latch cleared) -> tests the clear path at every attach; the R10 LPW timers reset <= 9.6 ms, inside the 150 ms",
         "IWDG hang with RELAY_EN static high: any trip clears the latch -> the switch stays open until the reset (<= 38.4 ms) and a new edge"]
for i, t in enumerate(REARM, 1):
    print(f"   {i}. {t}")
print("   power-up: RELAY_EN high moves by +100 ms (DC_PERMIT_N low 150 ms instead of 50 ms, section 3); rate/family worst includes it (section 4)")

print()
print("19. R9 E-16 (owner): suspend power cut - U102 off in Stop (MCU on the new VBUS-fed low-IQ LDO for 3V3M, power)")
T_S7 = 5.31e-3 + T_SW_OFF_WAIT + i2c_w + T_RAMP_WAIT + 1e-6 + 2 * spi_word + 0.2e-6 + 0.53e-3   # S7 (ANA_EN low) on the deadline path
T_DOM_OFF = 0.1e-3    # power (R9 E-16): U102 off 0.1 ms after ANA_EN low (U503 off ~12 us typ, margin); nothing has to decay first
T_U102_OFF = 0.3e-3   # power: U102 tOFF <= 0.3 ms -> USB current at the suspend level
t_u102_off = T_S7 + 1e-6 + T_DOM_OFF
t_stop = t_u102_off + 0.1e-3
print(f"   S7 ANA_EN low at {T_S7*1e3:.2f} ms after the last SOF (deadline path); S9 at S7 + 0.1 ms (power); PC14 = N5_U102_OFF high")
print(f"   at {t_u102_off*1e3:.2f} ms; U102 tOFF <= 0.3 ms -> USB current at the suspend level <= {(t_u102_off+T_U102_OFF)*1e3:.2f} ms (limit 10 ms, margin {(10e-3-t_u102_off-T_U102_OFF)*1e3:.2f} ms); Stop at {t_stop*1e3:.2f} ms")
print("   5V_SYS then falls ~12 mV/ms (<= 43 uA on 3.6 uF), U503 keeps VIN > VOUT; later reversal clamped by D105 <= 0.24 V (X-4 holds, power)")
assert t_u102_off + T_U102_OFF <= 9.9e-3
print("   rules: U102 off only after every domain is off; while U102 is commanded off (and until 5V_SYS is good after resume) VBUS_SENSE")
print("   reads ~0 and is IGNORED - the brown-out AWD is disarmed and no unplug/brown-out action is taken; a real unplug removes VBUS")
print("   from U502 -> MCU PDR -> reset (hardware-defined row). PC14 high draws <= 3.34 uA into R537 1 M (3V3M 3.207-3.343 V, power).")
T_U102_ON = 55.3e-3   # U102 turn-on after EN release: R109/C104 RC (power c20 b), EN node discharged by the NMOS in suspend
t_r0 = 5.28e-3 + T_U102_ON + 5e-3
print(f"   resume: Stop exit + HSE + PLL + PHY 5.28 ms (USB answers on 3V3M, TRSMRCY 10 ms met without 5V_SYS); PC14 low -> U102 on")
print(f"   <= {T_U102_ON*1e3:.1f} ms (R109 x C104 + tON 7.3 ms) -> 5V_SYS good (VBUS_SENSE >= 4.0 V for 5 ms; timeout 60 ms -> fault, USB-only, red LED)")
print(f"   -> AWD armed -> power-up B starts <= {t_r0*1e3:.1f} ms after the wake (audio restarts ~0.55 s later, section 3)")
print("   attach: U102 default on (PC14 floats at reset -> R537); firmware drives PC14 low at GPIO init; programming mode: low. The MCU")
print("   boots on 3V3M (VBUS) before U102 is on, so VBUS_SENSE = 0 during early boot is IGNORED: the AWD is armed only after 5V_SYS good")
print("   (VBUS_SENSE >= 4.0 V for 5 ms, timeout 60 ms after reset -> fault, stay USB-only, report). The D+ pull-up does NOT wait for it.")
print("   brown-out (power R9): the AWD trip is ratiometric to VDDA = 3V3M; U502 TPS70933 dropout <= 650 mV at 50 mA -> the 4.00 V trip is")
print("   guaranteed while the 3V3M load <= 50 mA (MCU typ 22 mA); on the 80 mA planning value 3V3M may leave regulation below VBUS ~4.25 V")
print("   and the trip is then not guaranteed. The unplug stays compliant without firmware (X-8). Qualification [MEAS]: 3V3M load <= 50 mA in")
print("   S3 at bring-up. VREFINT cross-check NOT adopted: the 9-slot scan leaves 9.5 us idle per 50 us, a VREFINT conversion needs >= 17 us")
print("   sampling (~21 us) [ASSUMP STM32F1-class; WCH value not retrieved] -> it would drop one protection scan per read (exact 20 kHz /")
print("   20-scan DMA blocks break; T3 itself is time-based). ADOPTED instead (firmware only, no ADC time): PVD on VDD = 3V3M at its highest")
print("   level (>= 2.9 V [ASSUMP level table]) -> EXTI16 -> the same brown-out ISR. It fires when U502 leaves regulation (dropout), i.e. at")
print("   5V_SYS ~3.5-3.9 V instead of 4.00 V, so a brown-out is always handled before the MCU loses regulation. The AWD stays exact while")
print("   3V3M regulates. PVD off in Stop (suspend checklist).")

print()
print("20. R10 F-5 (R10-B): CALIBRATION RULE - flash record, default -4.5 dB, gain ceiling, production test, cost")
# Level inputs: analog out/r10_fixes.txt F-5 (r10-analog, 26 Sep 04:58; class E: ESS full scale 0.924 x AVCC is a TYP value, Rs +-11 %
# at 25 C only): highest-gain unit 3.069 V pk/leg untrimmed, lowest-gain 2.333 V; supply-bounded source (bound b, E) 3.322 V; drift of the
# calibrated level over 0-50 C: 3V3A ratiometric <= +4.08 % (LP5907 window, G) + Rf/leg TCR 0.150 % (G) -> 2.325 V pk/leg. Detector constants for
# the content check: E-3 persistence detector V_L min 1.80 V (pair), T min 19.5 ms (R10-B / protection p17-p18) [protection owns].
# ESS ES9018K2M DS v3.7: reg 17-20 master trim = ONE signed 32-bit value for both channels, <= 0x7FFFFFFF, RESET DEFAULT 0x7FFFFFFF
# (0 dB = untrimmed); reg 15/16 volume per channel 0..-127.5 dB in 0.5 dB steps (attenuation only) [DS].
# WCH CH32V307 EVT FLASH_Program note: erased flash reads 0xE339E339 (not 0xFF); standard erase page 4 KB; flash erase/program and
# user/config-word reads above 120 MHz need HCLK/2 (flash clock <= 60 MHz) [WCH EVT main.c note].
Q31 = 2 ** 31
UPK_LO, UPK_HI, UPK_B = 2.333, 3.069, 3.322   # untrimmed 0 dBFS peak per leg: lowest / highest-gain unit (E), supply bound b (E)
UPK_P = 3.66                       # protection pcommon A_FS_UNTRIM: conservative E bound (supply-bounded source, Rs >= 651 ohm); the
                                   # I/V swing gives NO cap (3.07 V exceeds the guaranteed linear range but not the typical swing) [analog A.1]
U_LO, U_HI = UPK_LO / math.sqrt(2), UPK_HI / math.sqrt(2)   # Vrms per leg (1.650 / 2.170)
DRIFT = 1.0408 * 1.0015            # post-calibration level drift 0-50 C: 3V3A window (G) x Rf/leg TCR (G) [analog r10_fixes]
L_CAL = 1.55                       # calibrated level per leg, Vrms (spec, +-0.1 dB)
CAL_ACC_DB, INSTR_DB = 0.10, 0.05  # production acceptance +-0.10 dB; instrument uncertainty <= 0.05 dB -> true <= +0.15 dB
A_FS = L_CAL * math.sqrt(2) * 10 ** (0.15 / 20)   # calibrated full-scale peak per leg incl. +0.15 dB = the CEILING at calibration
                                   # (protection pcommon A_FS = 2.19 x 10^(0.15/20) = 2.228 V, rounded base; analog 2.230 V)
M_DEF = 0x4C3EA838                 # -4.5 dB default master trim (analog R2.16 / digital C-7)
assert M_DEF == math.floor(Q31 * 10 ** (-4.5 / 20))
g_def_db = 20 * math.log10(M_DEF / Q31)
print(f"   default master trim 0x{M_DEF:08X} = floor(2^31 x 10^(-4.5/20)) -> {g_def_db:.9f} dB (rounded DOWN, never above -4.5 dB)")
print("   ESS reset default 0x7FFFFFFF = 0 dB = UNTRIMMED: after every RESETB (power-up, resume, OD-2 re-init, rate/family re-init)")
print("   the firmware rewrites reg 17-20 from the checked gain state BEFORE any closure (pre-close read-back below).")

# ---- level table and the 20 Hz content check (protection confirms the margins)
V_L_E3, T_E3_MIN, F_LO = 1.80, 19.5e-3, 20.0
def t_above(a_pair, v_l=V_L_E3, f=F_LO):
    return 0.0 if a_pair <= v_l else (math.pi - 2 * math.asin(v_l / a_pair)) / (2 * math.pi * f)
a_lim_pair = V_L_E3 / math.sin((math.pi - T_E3_MIN * 2 * math.pi * F_LO) / 2)
lev = [("calibrated nominal (1.55 Vrms)", L_CAL),
       ("calibrated CEILING = protection A_FS (+0.10 dB acceptance +0.05 dB instrument)", A_FS / math.sqrt(2)),
       ("ceiling + G-bounded drift 0-50 C (3V3A +4.08 %, TCR 0.15 %; ESS tempco E extra)", A_FS * DRIFT / math.sqrt(2)),
       ("-4.5 dB default, highest-gain unit (no valid record)", U_HI * M_DEF / Q31),
       ("-4.5 dB default, supply-bounded ESS source (analog bound b, E)", UPK_B / math.sqrt(2) * M_DEF / Q31),
       ("-4.5 dB default, protection's conservative 3.66 V/leg untrimmed bound (E)", UPK_P / math.sqrt(2) * M_DEF / Q31),
       ("-4.5 dB default, lowest-gain unit", U_LO * M_DEF / Q31),
       ("UNTRIMMED highest-gain unit (ESS reset 0x7FFFFFFF) - never allowed with the switch closed", U_HI),
       ("20 Hz no-trip limit of E-3 (time above V_L = T min 19.5 ms)", a_lim_pair / 2 / math.sqrt(2))]
print(f"   {'state (1 kHz / 20 Hz full-scale sine)':88s} {'Vrms/leg':>8} {'Vpk/leg':>8} {'Vpk pair':>8} {'20 Hz >1.80 V':>13} {'margin':>8}")
for n, vr in lev:
    pk = vr * math.sqrt(2)
    print(f"   {n:88s} {vr:8.3f} {pk:8.3f} {2*pk:8.3f} {t_above(2*pk)*1e3:10.2f} ms {20*math.log10(a_lim_pair/(2*pk)):+7.2f} dB")
t_def_hi = t_above(2 * U_HI * M_DEF / Q31 * math.sqrt(2))
t_untr = t_above(2 * U_HI * math.sqrt(2))
assert t_def_hi < T_E3_MIN < t_untr and t_above(2 * A_FS * DRIFT) < T_E3_MIN and t_above(2 * UPK_B * M_DEF / Q31) < T_E3_MIN
assert UPK_P * M_DEF / Q31 < L_CAL * math.sqrt(2)          # even the 3.66 V bound at the default stays below the calibrated peak
print(f"   -> the 20 Hz full-scale sine stays below the E-3 minimum persistence at the ceiling ({t_above(2*A_FS)*1e3:.2f} ms; {t_above(2*A_FS*DRIFT)*1e3:.2f} ms with drift) and at the default")
print(f"      ({t_def_hi*1e3:.2f} ms), and trips only untrimmed ({t_untr*1e3:.2f} ms > 19.5 ms) = R10-B. Relative to 1.55 Vrms the default is")
print(f"      {20*math.log10(U_LO*M_DEF/Q31/L_CAL):.2f} .. {20*math.log10(U_HI*M_DEF/Q31/L_CAL):.2f} dB (NOT -4.5 dB: the default is -4.5 dB re the UNTRIMMED level).")
print("      Analog r10_fixes F-5 agrees (16.81 / 18.39 / 18.67 / 20.26 ms). Protection gives the detector margins (E-3 and any F-1 detector).")

# ---- calibration record (flash)
REC_ADDR, REC_PAGE = 0x08077000, 4096
MAGIC, REC_VER, REC_LEN = 0x314C4143, 1, 48     # "CAL1" little-endian; REC_LEN = the CRC-protected part
VER_KEY = 0x5A5A5A5A                            # VERIFIED word (+48) = crc32 ^ VER_KEY, programmed by 'CALOK' after P-4 passes
T_LO_DB = 20 * math.log10(L_CAL * math.sqrt(2) / UPK_P) - CAL_ACC_DB   # most attenuation: 3.66 V-bound unit (-4.45 dB) - 0.10 dB
T_HI_DB = -0.10                    # top (analog 05:06): rejects 0x7FFFFFFF and anything within 0.10 dB of FS, keeps 0.44 dB of room
                                   # for an ESS full scale below TYP (lowest-gain model unit needs -0.54 dB); wrong in-range records are
                                   # caught by the firmware-gated P-4 (VERIFIED word), not by the range
T_LO = math.ceil(Q31 * 10 ** (T_LO_DB / 20))
T_HI = math.floor(Q31 * 10 ** (T_HI_DB / 20))
print()
print(f"   CALIBRATION RECORD: one 4 KB page at 0x{REC_ADDR:08X} (last page of the 480 KB CodeFlash = non-zero-wait area for every")
print("   R0WAIT option byte split [DS 2.5.2]; linker/IAP never erase it). 52 bytes, little-endian, 13 words (48 B CRC-protected + VERIFIED):")
REC_FIELDS = [(0, 4, "magic 0x314C4143 ('CAL1')"), (4, 2, "version = 1 (firmware accepts only versions it knows)"),
              (6, 2, "length = 48"), (8, 12, "MCU 96-bit unique ID (ESIG) at calibration - binds the record to this chip"),
              (20, 4, "trim_L: Q31 code, gain that sets L to 1.55 Vrms/leg at 0 dBFS (computed from the larger leg)"),
              (24, 4, "trim_R: Q31 code, same for R"),
              (28, 8, "vmeas[4] u16 0.1 mVrms, rounded UP by the tool: LP, LN, RP, RN at 1 kHz 0 dBFS, default trim (P-5 reference)"),
              (36, 8, "dcbase[4] i16 0.1 mV: leg DC baselines for the advisory pre-close check (R3.2 B.6 'stored factory baseline')"),
              (44, 4, "crc32: CRC-32/MPEG-2 (poly 0x04C11DB7, init 0xFFFFFFFF, no reflection, no final XOR) over words 0-10,"),
              (48, 4, "VERIFIED = crc32 XOR 0x5A5A5A5A, programmed (no erase) by 'CALOK' only after the P-4 re-measurement passed")]
for off, sz, d in REC_FIELDS:
    print(f"      +{off:2d} {sz:2d} B  {d}")
print("               (the crc32 is fed as 32-bit words = the CH32V307 CRC unit's native mode [ASSUMP STM32F1-compatible; software fallback identical])")
assert sum(sz for _, sz, _ in REC_FIELDS) == REC_LEN + 4


def crc_words(words, init=0xFFFFFFFF):
    c = init
    for w in words:
        c ^= w & 0xFFFFFFFF
        for _ in range(32):
            c = ((c << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if c & 0x80000000 else (c << 1) & 0xFFFFFFFF
    return c


def crc_bytes(bs, init=0xFFFFFFFF):
    c = init
    for b in bs:
        c ^= b << 24
        for _ in range(8):
            c = ((c << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if c & 0x80000000 else (c << 1) & 0xFFFFFFFF
    return c


assert crc_bytes(b"123456789") == 0x0376E6E7 and crc_words([0x12345678]) == 0xDF8A8A2B   # published check values
print("      CRC self-check: CRC-32/MPEG-2('123456789') = 0x0376E6E7 (catalogue check value); word 0x12345678 -> 0xDF8A8A2B (STM32-type unit)")
print(f"   range check: trim_L and trim_R in [0x{T_LO:08X}, 0x{T_HI:08X}] = [{T_LO_DB:.2f}, {T_HI_DB:.2f}] dB. Analog need -2.92 .. -0.54 dB (E).")
print(f"   UPPER end -0.10 dB (analog 05:06): refuses 0x7FFFFFFF (the ESS reset value = untrimmed) and anything within 0.10 dB of full scale,")
print("   and keeps 0.44 dB of room for an ESS full scale below TYP (the lowest-gain model unit needs -0.54 dB): a unit is refused only if")
print(f"   its untrimmed level is < {L_CAL*10**(0.10/20):.3f} Vrms (it could not reach 1.55 Vrms with 0.10 dB to spare). LOWER end = protection's conservative 3.66 V/leg bound (-4.45 dB) - {CAL_ACC_DB:.2f} dB: a garbage filter only (more attenuation")
print("   is always safe); a unit far above the TYP model can still be calibrated. NO range can catch a wrong in-range record (-0.5 dB on a")
print("   high-gain unit would be 2.4 dB hot): that is closed by the VERIFIED word - a record becomes active only after the mandatory P-4")
print("   re-measurement passed and 'CALOK' programmed crc32 ^ 0x5A5A5A5A.")


def mk_record(uid, t_l, t_r, vm, dcb, ver=REC_VER, magic=MAGIC, length=REC_LEN, verified=True):
    w = [magic, (length << 16) | ver, uid[0], uid[1], uid[2], t_l, t_r,
         (vm[1] << 16) | vm[0], (vm[3] << 16) | vm[2],
         ((dcb[1] & 0xFFFF) << 16) | (dcb[0] & 0xFFFF), ((dcb[3] & 0xFFFF) << 16) | (dcb[2] & 0xFFFF)]
    c = crc_words(w)
    return w + [c, (c ^ VER_KEY) if verified else 0xE339E339]   # unverified: the word is still erased


def validate(words, uid):
    """Boot/attach validation, in this order; any failure -> DEFAULT with the reason code."""
    if words[0] != MAGIC:
        return "NO_RECORD"                 # erased (0xE339E339), never written, or foreign data
    if (words[1] & 0xFFFF) != REC_VER or (words[1] >> 16) != REC_LEN:
        return "VERSION"
    if crc_words(words[:11]) != words[11]:
        return "CRC"
    if tuple(words[2:5]) != tuple(uid):
        return "UID"
    for t in (words[5], words[6]):
        if not (T_LO <= t <= T_HI):
            return "RANGE"
    if words[12] != words[11] ^ VER_KEY:
        return "UNVERIFIED"                # written but P-4 not confirmed (or interrupted 'CALOK')
    return "OK"


UID = (0x5A3C0F11, 0x0B20D7E4, 0x7731C2A9)     # example chip
vm_ex = (11803, 11761, 11622, 11650)           # example unit at the default trim, 0.1 mVrms (ceil)
t_ex = [(M_DEF * 15_500) // max(vm_ex[2 * c], vm_ex[2 * c + 1]) for c in (0, 1)]
rec = mk_record(UID, t_ex[0], t_ex[1], vm_ex, (12, -8, 5, -3))
print(f"   test vector (example chip UID {UID[0]:08X}-{UID[1]:08X}-{UID[2]:08X}, vmeas {vm_ex} x 0.1 mV): trim_L 0x{t_ex[0]:08X}"
      f" ({20*math.log10(t_ex[0]/Q31):.3f} dB), trim_R 0x{t_ex[1]:08X} ({20*math.log10(t_ex[1]/Q31):.3f} dB), crc32 0x{rec[11]:08X}")
print("      words: " + " ".join(f"{w:08X}" for w in rec))
rec_other = mk_record(UID, t_ex[0] - 1000, t_ex[1], vm_ex, (0, 0, 0, 0))
cases = [("valid record, verified", rec, "OK"),
         ("valid record, NOT verified (P-4 not confirmed)", rec[:12] + [0xE339E339], "UNVERIFIED"),
         ("VERIFIED word of another record", rec[:12] + [rec_other[12]], "UNVERIFIED"),
         ("erased page (CH32V307 reads 0xE339E339)", [0xE339E339] * 13, "NO_RECORD"),
         ("all 0xFFFFFFFF (other erase convention)", [0xFFFFFFFF] * 13, "NO_RECORD"),
         ("all zero", [0] * 13, "NO_RECORD"),
         ("one CRC bit flipped", rec[:11] + [rec[11] ^ 0x00010000, rec[12]], "CRC"),
         ("one trim bit flipped (CRC not updated)", rec[:5] + [rec[5] ^ 0x00000400] + rec[6:], "CRC"),
         ("record of another chip (UID differs, CRC valid)", mk_record((1, 2, 3), t_ex[0], t_ex[1], vm_ex, (0, 0, 0, 0)), "UID"),
         ("trim_L = T_HI + 1 (CRC valid)", mk_record(UID, T_HI + 1, t_ex[1], vm_ex, (0, 0, 0, 0)), "RANGE"),
         ("trim_R = T_LO - 1 (CRC valid)", mk_record(UID, t_ex[0], T_LO - 1, vm_ex, (0, 0, 0, 0)), "RANGE"),
         ("trim = 0x7FFFFFFF (0 dB, CRC valid)", mk_record(UID, 0x7FFFFFFF, t_ex[1], vm_ex, (0, 0, 0, 0)), "RANGE"),
         ("trim = 0x40000000 (-6.02 dB, CRC valid)", mk_record(UID, 0x40000000, t_ex[1], vm_ex, (0, 0, 0, 0)), "RANGE"),
         ("version 2 (future format)", mk_record(UID, t_ex[0], t_ex[1], vm_ex, (0, 0, 0, 0), ver=2), "VERSION")]
print("   validation truth table (boot at every attach; also the production P-6 cases):")
for n, w, exp in cases:
    got = validate(w, UID)
    assert got == exp, (n, got, exp)
    print(f"      {n:52s} -> {'CALIBRATED' if got == 'OK' else 'DEFAULT -4.5 dB, reason ' + got}")
print()
print("   BOOT / EVERY ATTACH (the MCU runs from VBUS, so every attach is a cold boot; an unplug is PDR -> reset):")
BOOT = ["in the >= 5.2 ms HSI low-clock phase (8 MHz, below the WCH 120 MHz flash-read note): read the 52 B record, validate",
        "(magic, version/length, CRC, UID, range, VERIFIED) -> gain state G = {mode CAL|DEFAULT, reason, M, s_L, s_R, scaled channel,",
        "post-CPLD OD-1 thresholds per channel, CPLD self-test DC per channel}; G is kept with a CRC-32 and checked before every use",
        "DEFAULT (NO_RECORD / VERSION / CRC / UID / RANGE / UNVERIFIED): M = 0x4C3EA838 on both channels, no scaling, log 'CAL DEFAULT <reason>'",
        "(USART1 + RAM event log), red LED double-flash (2 x 100 ms, 150 ms apart) every 3 s while in DEFAULT (a steady-red fault or",
        "the programming-mode slow blink takes precedence); nothing leaves DEFAULT except a valid AND verified record + reset; the one",
        "exception is the production session 'CALTRY' (J201 USART + key, only with a valid-but-unverified record, RAM flag, ends at any",
        "reset) that applies the record so that P-4 can measure it",
        "every DAC init (power-up B, resume R0->B, OD-2 re-init, fault retry, rate/family re-init): check G's CRC (fail -> DEFAULT +",
        "log 'CAL RAM FAULT', stays DEFAULT until the next reset), write reg 15/16 (muted state) and reg 17-20 = G.M through the one",
        "trim-writer function (writes only G.M; G.M <= max(trim_L, trim_R) or = 0x4C3EA838 is asserted when G is built)",
        "PRE-CLOSE (new condition, every closure; OD-2 is masked until the first closure): I2C burst read reg 15-20 -> reg 17-20 == G.M",
        "(CRC-checked G, independent of the register shadow) and reg 15/16 == shadow; else no RELAY_EN, log 'DAC TRIM MISMATCH',",
        "DAC re-init (PA8 reset + full init). An interrupted record write (unplug) leaves magic/CRC invalid -> DEFAULT (safe)"]
for i, s_ in enumerate(BOOT):
    print(f"      {s_}")

# ---- gain ceiling: realisation and worst-case rounding
BP_DB = 0.04                                    # bit-perfect window (analog C: 0.04 dB + P/N 0.041 dB = 0.081 dB <= 0.1 dB)
R_BP = math.floor(Q31 * 10 ** (-BP_DB / 20))    # channels within 0.04 dB -> no MCU scaling


def realise(t_l, t_r):
    """Return (M, s_L, s_R) with s = None meaning 'bypass' (bit-perfect)."""
    t_min, t_max = min(t_l, t_r), max(t_l, t_r)
    if t_min * Q31 >= t_max * R_BP:              # |imbalance| <= 0.04 dB: common trim = the smaller code, no scaling
        return t_min, None, None
    s = (t_min * Q31) // t_max                   # floor -> the scaled channel never exceeds its own trim
    return (t_max, s, None) if t_l < t_r else (t_max, None, s)


def eff(M, s):
    return M if s is None else (M * s) // Q31    # effective Q31 gain of a channel (floor)


def mulhsu_scale(x, s):
    """MCU sample scale: y = mulhsu(x, 2s) + (x < 0) -> |y| <= |x| s / 2^31 (magnitude never increases), 3 RV32 instructions."""
    return ((x * (2 * s)) >> 32) + (1 if x < 0 else 0)


import random
rnd = random.Random(20260926)
worst_bal, n_chk, n_bp = 0.0, 0, 0
pairs = [(T_LO, T_LO), (T_HI, T_HI), (T_LO, T_HI), (T_HI, T_LO), (T_HI, T_HI - 1)]
pairs += [(rnd.randint(T_LO, T_HI), rnd.randint(T_LO, T_HI)) for _ in range(20000)]
for tl in range(T_HI - 3000, T_HI + 1, 97):      # dense near the bit-perfect boundary
    pairs.append((tl, math.floor(tl * R_BP / Q31)))
    pairs.append((tl, math.floor(tl * R_BP / Q31) - 1))
for t_l, t_r in pairs:
    M, s_l, s_r = realise(t_l, t_r)
    e_l, e_r = eff(M, s_l), eff(M, s_r)
    assert M <= 0x7FFFFFFF and e_l <= t_l and e_r <= t_r, (t_l, t_r)
    assert (s_l is None or s_l < Q31) and (s_r is None or s_r < Q31) and (s_l is None or s_r is None)
    n_bp += (s_l is None and s_r is None)
    worst_bal = max(worst_bal, 20 * math.log10(t_l / e_l), 20 * math.log10(t_r / e_r))
    n_chk += 1
xs = [-Q31, -Q31 + 1, -2, -1, 0, 1, 2, Q31 - 2, Q31 - 1] + [rnd.randint(-Q31, Q31 - 1) for _ in range(20000)]
ss = [math.floor(Q31 * T_LO / T_HI), R_BP - 1, (Q31 * 3) // 4, Q31 - 1] + [rnd.randint(math.floor(Q31 * T_LO / T_HI), R_BP - 1) for _ in range(200)]
worst_loss = 0
for s in ss:
    for x in xs[:9] + xs[9 + (s % 50) * 400: 9 + (s % 50) * 400 + 400]:
        y = mulhsu_scale(x, s)
        assert abs(y) * Q31 <= abs(x) * s and -Q31 < y < Q31 and (y == 0 or (y > 0) == (x > 0)), (x, s, y)
        worst_loss = max(worst_loss, abs(x) * s / Q31 - abs(y))
print()
print("   GAIN CEILING - arithmetic (per channel c; U_c = untrimmed Vrms/leg at 0 dBFS, x = sample in FS):")
print("      V_c = U_c x x x (s_c/2^31, or 1 when bypassed) x (M/2^31) x 10^(-0.5 v_c / 20)      M = ESS reg 20..17, v_c = ESS reg 15/16")
print("      record: t_c = floor(M_DEF x 15,500 / max(vmeas_c+, vmeas_c-)) with vmeas in 0.1 mVrms rounded UP (integer; the firmware")
print("      computes it from vmeas - trims are never accepted as free numbers)")
print(f"      realisation: |20 log(t_L/t_R)| <= {BP_DB:.2f} dB -> M = min(t), no scaling (stream bit-perfect); else M = max(t) and the other")
print(f"      channel s = floor(2^31 t_min / t_max) in the MCU (USB-side guard pass, before the link DMA); only one channel is ever scaled")
print(f"      volume: v_c = max(v_host, v_overload, v_TypeC, v_E21) in 0.5 dB steps; v_host = clamp(ceil(-h / 128), 0, 255) for the UAC2")
print("      Feature Unit value h (1/256 dB); descriptor RANGE MIN -127.5 dB, MAX 0 dB, RES 0.5 dB; h > 0 is clamped to 0 dB")
h_all = range(-32768, 32768)
for h in h_all:
    v = min(255, max(0, math.ceil(-h / 128)))
    assert v >= 0 and (h < -32640 or 0.5 * v * 256 >= -h - 1e-9)
print(f"      checked: {n_chk} trim pairs (edges, random, dense at the {BP_DB:.2f} dB boundary) -> effective code <= t_c on both channels, M <= 0x7FFFFFFF,")
print(f"      s < 2^31; worst shortfall below a channel's own trim {worst_bal:.4f} dB (<= {BP_DB:.2f} dB window + floor; + P/N leg mismatch 0.041 dB G")
print(f"      -> smaller leg >= -{BP_DB+0.041:.3f} dB, inside -0.10 dB); {len(h_all)} host volume codes ->")
print(f"      attenuation >= requested, never < 0 dB; sample scale over {len(ss)} scales x edge/random samples incl. -2^31: |y| <= |x| s/2^31,")
print(f"      worst loss {worst_loss:.3f} LSB (2^-31 FS), no overflow")
print("   WORST-CASE ROUNDING (direction 'up' = louder): vmeas ceil: down <= 0.1 mV (<= 0.0009 dB); t_c floor: down < 1 LSB (6e-10 rel.);")
print("      s floor: down < 1 LSB; sample mulhsu + sign fix: down <= 1 LSB (2^-31 FS); volume ceil: down 0 .. 0.5 dB; default code: down")
print("      6.5e-9 dB -> the digital chain has NO upward")
print("      rounding term. ESS internal rounding of the master-trim product is not published [DS]: <= 2^-24 relative (5e-7 dB) for any")
print("      >= 24-bit internal coefficient [ASSUMP]; it is inside the measured P-4 level. Upward terms left are analog, not firmware:")
print(f"      instrument <= 0.05 dB (in A_FS = {A_FS:.3f} V/leg) and drift after calibration <= +4.23 % (3V3A window + TCR, G; analog) ->")
print(f"      {A_FS*DRIFT:.3f} V/leg over 0-50 C (protection has 2.325 V); ESS tempco unpublished (E). The firmware cannot trim the drift out:")
print("      3V3A is only read against 3V3M (VDDA), itself a +-1.5 % regulator, so a ratio correction would not be a bound.")
print("   HENCE: max V_c = U_c x t_c / 2^31 = the calibrated level of channel c (valid record) or U_c x 0x4C3EA838 / 2^31 (DEFAULT);")
print("      volume, trim and sample scaling can only attenuate below it.")
print("   OD-1 interaction: the USB-side guard sees x (before scaling) -> thresholds unchanged. The post-CPLD guard sees x s_c on a scaled")
print("      channel -> its P1-P4 thresholds for that channel = floor(threshold x s_c) (constants in G; never less sensitive in analog terms).")
print("      The CPLD self-test DC (bypasses the MCU) is scaled by s_c the same way, so every leg sees a calibrated-unit voltage.")
print("   OD-2 interaction: poll A (10 ms) already reads back reg 0-20 incl. 15-20 against the shadow -> adds a compare of reg 17-20 with")
print("      G.M (CRC-checked, independent of the shadow): any wrong trim opens the switch <= 16.45 ms (poll A row b). A DAC reset (reg 17-20")
print("      -> 0x7FFFFFFF) also drops the DPLL lock -> EXTI9 -> switch open <= 1.04 ms, before the ESS can relock (reset-default stop_div")
print("      2730 FSR edges = 7.1 ms at 384 kHz, 62 ms at 44.1 kHz) [ASSUMP: no audio output before lock] -> untrimmed audio never reaches a")
print("      closed switch (a hardware trip during such a DAC fault is an acceptable fault response). No change to the 27.4 % I2C load.")
print("   bit-perfect test mode (R8-B10, report 9.1): MCU scaling bypassed AND M = min(t_L, t_R) (never above on either channel; balance")
print("      deviates by the unit's imbalance only during the test), mode logged.")

# ---- production test
print()
print("   PRODUCTION STEPS (J201 USART1 via WCH-LinkE; test PC plays 1 kHz 0 dBFS, 48 kHz / 24-bit, host volume 0 dB; UNLOADED legs, true-RMS")
print("   DMM/analyser >= 10 kohm, <= +-0.05 dB at 1 kHz, each jack contact to GND (analog B.2: unloaded is the maximum, so the ceiling holds")
print("   for every load; a 300 ohm pair reading would hide a leg above 1.55 Vrms); switch closed through the normal pre-close sequence):")
PROD = [("P-1", "first boot after programming (no record): LED double-flash, log 'CAL DEFAULT NO_RECORD', status 'CAL?' -> DEFAULT;"
                " status also shows reg 17-20 read back = 0x4C3EA838; measure LP, LN, RP, RN at the default (analog: every unit linear,"
                f" +0.283 V I/V margin; at 0 dB a worst-swing unit clips by 0.33 V): pass window = the firmware range [{L_CAL*M_DEF/T_HI:.3f}, {L_CAL*M_DEF/T_LO:.3f}] Vrms;"
                " 0.972..1.308 expected (TYP model +-0.1 dB), above 1.308 = ESS full scale above TYP (logged for analog, class E);"
                " the value is vmeas (0.1 mV, rounded up)"),
        ("P-2", "'CALW vmeas[4] dcbase[4]': firmware (idle: alt 0 >= 1 s, RELAY_EN low) runs S2-S8 (domains off), IWDG long (DX-2"
                " condition met), HCLK/2 (WCH note), computes t_c from vmeas, range-checks, builds the record with its UID + CRC, erases the"
                " page, programs 24 half-words (VERIFIED left erased), reads back and compares all 48 B, restores clocks/IWDG, software reset"
                " -> boot: DEFAULT, reason UNVERIFIED (still double-flash)"),
        ("P-3", "record present and valid: 'CAL?' -> record OK (version 1, CRC, UID = chip, range, trims = the P-2 values), UNVERIFIED"),
        ("P-4", "MANDATORY and firmware-gated post-trim check: 'CALTRY' applies the record for this session (normal DAC re-init + pre-close"
                " read-back, reg 17-20 = G.M) -> re-measure every leg unloaded: 1.55 Vrms +-0.10 dB (1.532..1.568; design worst for a smaller"
                " leg -0.081 dB = 0.04 window + 0.041 P/N, analog G); balance |L-R| <= 0.10 dB (design worst 0.081 dB unloaded, 0.125 dB with"
                " RON under load, <= 0.3 dB); per leg V_cal/V_def = E_c/M_DEF +-0.05 dB. PASS -> 'CALOK' programs VERIFIED (2 half-words, no"
                " erase, same safe conditions as P-2), reset -> 'CAL?' CALIBRATED, verified, reg 17-20 read back = G.M, no double-flash."
                " FAIL -> 'CALE', the board stays at DEFAULT (never ships with an unverified or wrong record)"),
        ("P-5", "erased-record test: 'CALE' (erase page, reset) -> DEFAULT NO_RECORD, double-flash, log; each leg = its P-1 value +-0.05 dB"
                " (= -4.5 dB re untrimmed; <= 1.290 Vrms +0.1 dB), and host volume +6 dB requests still read 0 dB (clamp)"),
        ("P-6", "negative records (first board and every firmware release; all 5 boards if time): 'CALT crc|uid|range|ver' writes a copy"
                " of the record with one defect (the command can only create INVALID records) -> reset -> DEFAULT with that reason, LED,"
                " log, one leg = P-1 value +-0.05 dB"),
        ("P-7", "restore: 'CALW' with the P-1 values -> P-3, P-4 ('CALTRY', re-measure, 'CALOK') again; archive UID, vmeas, trims, CRC"
                " per board (5 boards)"),
        ("P-8", "qualification (analog suggestion): log the 1 kHz 0 dBFS level per leg at the E-4 soaks (0-5 / 25 / 50 C); expected"
                " << +4.08 % re 25 C (G bound); a larger drift goes to analog/protection (ceiling 2.325 V/leg)")]
for k, d in PROD:
    print(f"      {k}: {d}")
print("      flash wear: ~6 erase cycles per board in production (endurance not in the retrieved DS text; >= 1k assumed [ASSUMP]); 'CALOK'")
print("      programs one erased word once (no erase). An interrupted 'CALW' or 'CALOK' leaves the record invalid or UNVERIFIED -> DEFAULT (safe).")
print("      A full-chip erase (e.g. WCH-LinkUtility 'erase all' or the BOOT0 ISP) deletes the record -> DEFAULT, flagged (safe); recalibrate.")

# ---- cost
print()
T_BOOT_CRC = 44 * 8 * 6 / 8e6                    # bitwise software CRC at HSI 8 MHz, ~6 cycles per bit [ASSUMP]; HW unit ~15 us
t_pre = (1 + 9 + 9 + 1 + 9 + 6 * 9 + 1) * BIT    # reg 15-20 burst read at 100 kHz
CYC_SCALE_TYP, CYC_SCALE_WST = 5, 8               # load, mulhsu, srli, add, store [ASSUMP ~1 IPC] / slow multiplier allowance
cpu_typ = 384_000 * CYC_SCALE_TYP / f_cpu
cpu_wst = 384_000 * CYC_SCALE_WST / f_cpu
RAM_G = 4 + 4 + 4 + 4 + 4 + 2 * 5 * 4 + 2 * 4 * 4 + 4    # mode/reason, M, M_CEIL, s, flags (incl. CALTRY session), post-CPLD thresholds, self-test DC, CRC
RAM_ALL = RAM_G + 52 + 64                                  # + record image (command buffer) + USART command line
print("   COST:")
print(f"      CPU: boot validation <= {T_BOOT_CRC*1e3:.2f} ms inside the existing 5.2 ms HSI phase (TSIGATT unchanged, <= 23.9 ms); G check")
print(f"      ~0.2 us per use; per-channel scaling only on an imbalanced unit (> 0.05 dB): {cpu_typ*100:.1f} % typical / {cpu_wst*100:.1f} % worst of")
print(f"      144 MHz at 384 kHz (one channel; half at 192 kHz), fused into the USB-side OD-1 pass -> OD-1 total {2*0.0667*100:.1f} % -> {(2*0.0667+cpu_wst)*100:.1f} % worst")
print(f"      I2C / timing: pre-close read-back {t_pre*1e3:.2f} ms per closure, inside the >= 150 ms DC_PERMIT_N-low wait -> first closure")
print("      540.8 ms and rate/family worst 972 ms unchanged; OD-2 poll A unchanged (reg 15-20 already inside reg 0-20; +1 compare)")
print(f"      Flash: 1 page 4 KB (record 52 B) + ~2.5 KB code (validation, HW-CRC driver, CALW/CALTRY/CALOK/CALE/CALT/CAL? handler, gain state) [ASSUMP]")
print(f"      RAM: gain state G {RAM_G} B + record image 52 B + command line 64 B = {RAM_ALL} B (of 64 KB); no new buffers")
print("      Pins: none (USART1 PA9/PA10 on J201 already exist; LEDs PC6/PC7 already exist). Current: red double-flash duty 0.117 x")
print("      0.73 mA = 0.085 mA average, inside the both-LEDs-on budget; LEDs off in suspend (S8).")
assert t_pre < 150e-3 and T_BOOT_CRC < 5.2e-3 and RAM_ALL < 1024

# ---- self-test amplitude check at the default (finding for protection)
print()
print("   SELF-TEST AT THE DEFAULT (finding sent to protection 04:52; RESOLVED by F-1: a' deleted, the new LPW test uses +-0.30 FS at any")
print("   gain, leg 0.417..0.698 V, pair <= 1.40 V < V_L; kept for the record): p20 scaled a' 0.39 -> 0.65 FS and e 0.5 -> 0.85 FS by the full")
print(f"   4.5 dB, but the default is only {-20*math.log10(U_HI*M_DEF/Q31/L_CAL):.2f} .. {-20*math.log10(U_LO*M_DEF/Q31/L_CAL):.2f} dB below 1.55 Vrms. Leg DC per FS at the default:")
vpf_lo, vpf_hi = U_LO * math.sqrt(2) * M_DEF / Q31, U_HI * math.sqrt(2) * M_DEF / Q31
for lab, x in (("a' 0.65 FS", 0.65), ("e  0.85 FS", 0.85)):
    print(f"      {lab}: leg {x*vpf_lo:.3f} .. {x*vpf_hi:.3f} V, pair {2*x*vpf_lo:.3f} .. {2*x*vpf_hi:.3f} V (E-3 V_L min {V_L_E3:.2f} V)")
print(f"      -> a' at 0.65 FS puts the pair above V_L on most units: E-3 trips (~20 ms) before the 70-140 ms a' window -> a' would FAIL")
print(f"         on uncalibrated boards; a' needs x <= {V_L_E3/2/vpf_hi:.3f} FS at the default ({V_L_E3/2/vpf_hi*vpf_lo:.2f}..0.90 V/leg over the unit spread). -> resolved (F-1).")
V_LL_MAX = 0.33401                               # LPW level max incl. the 10 nA leakage allowance (protection-2 08:25)
for lab, x, lo_ok, hi_ok in (("f  LPW 0.30 FS", 0.30, V_LL_MAX, V_L_E3 / 2), ("g  OR  0.25 FS", 0.25, 0.30, V_L_E3 / 2)):
    lo, hi = x * vpf_lo, x * A_FS * DRIFT          # lo_ok: LPW level max / OR test-mode level 0.30 V (protection p21)
    assert lo > lo_ok and 2 * hi < V_L_E3, lab
    print(f"      R10 {lab}: leg {lo:.3f} .. {hi:.3f} V over default-lowest .. ceiling+drift (> stage level, pair {2*hi:.2f} V < V_L 1.80 V)")

# ---- option B readiness (protection 07:42 FYI, owner undecided): calibrated FS -0.6 dB and default -5.1 dB
print()
M_DEF_B = math.floor(Q31 * 10 ** (-5.1 / 20))
L_CAL_B = L_CAL * 10 ** (-0.6 / 20)
T_LO_B = math.ceil(Q31 * 10 ** ((20 * math.log10(L_CAL_B * math.sqrt(2) / UPK_P) - CAL_ACC_DB) / 20))
print("   OPTION B READINESS (owner undecided; protection 07:42): if the owner lowers the calibrated full scale by 0.6 dB and the default to")
print(f"   -5.1 dB, only two firmware constants change: target {L_CAL_B:.4f} Vrms/leg ({L_CAL_B*math.sqrt(2):.3f} V pk; ceiling +0.15 dB"
      f" {L_CAL_B*math.sqrt(2)*10**(0.15/20):.3f} V, with drift {L_CAL_B*math.sqrt(2)*10**(0.15/20)*DRIFT:.3f} V)")
print(f"   and M_DEF = floor(2^31 x 10^(-5.1/20)) = 0x{M_DEF_B:08X} ({20*math.log10(M_DEF_B/Q31):.9f} dB). Everything else is derived: t_c formula")
print(f"   (target in 0.1 mV: {round(L_CAL_B*1e4)}), range [0x{T_LO_B:08X}, 0x{T_HI:08X}], P-1 window [{L_CAL_B*M_DEF_B/T_HI:.3f}, {L_CAL_B*M_DEF_B/T_LO_B:.3f}] Vrms,"
      f" P-4 window {L_CAL_B*10**(-0.1/20):.3f}..{L_CAL_B*10**(0.1/20):.3f} Vrms.")
print(f"   Default highest-gain unit {UPK_HI*M_DEF_B/Q31:.3f} V pk/leg (20 Hz: {t_above(2*UPK_HI*M_DEF_B/Q31)*1e3:.2f} ms); ceiling+drift"
      f" {t_above(2*L_CAL_B*math.sqrt(2)*10**(0.15/20)*DRIFT)*1e3:.2f} ms (all margins improve by 0.6 dB).")
print("   The record VERSION identifies the calibration basis (v1 = 1.55 Vrms target, vmeas taken at 0x4C3EA838). A basis-B firmware would")
print("   write version 2 and could accept a v1 record only by recomputing t_c from its stored vmeas with the lower target (always downward")
print("   = never above), or treat it as DEFAULT. No board is calibrated yet (build on HOLD), so in practice option B is a constant change.")
vpf_lo_b = UPK_LO * M_DEF_B / Q31
X_G_A, X_G_B = 0.25, 0.30                        # OR self-test word: basis A (current) / basis B (protection-2 07:55)
print(f"   Self-test words under B: at 0.25 FS the (g) margin at the lowest default gain would drop to {X_G_A*vpf_lo_b-0.30:+.3f} V (protection: 17 mV")
print(f"   on the negative side) -> protection-2 (07:55) re-derived: (f) KEEP 0.30 FS (leg {0.30*vpf_lo_b:.3f}-0.651 V, +65 mV over V_LL max,")
print(f"   72.5-100.8 ms inside 65-110 ms); (g) RAISE to {X_G_B:.2f} FS under B only (leg {X_G_B*vpf_lo_b:.3f}-0.651 V, margins 82 mV negative /")
print("   228 mV positive, 19.5-24.7 ms inside 18-32 ms, pair at the ceiling 1.302 V < V_L -> E-3 silent). Pass windows and totals")
print("   (3.68 / 2.96 s) unchanged. Basis constants in firmware: {target, M_DEF, OR test word} = A {1.55 Vrms, 0x4C3EA838, 0.25 FS} /")
print(f"   B {{{L_CAL_B:.4f} Vrms, 0x{M_DEF_B:08X}, {X_G_B:.2f} FS}}.")
assert M_DEF_B < M_DEF and T_LO_B < M_DEF_B < T_HI and 0.30 * vpf_lo_b > V_LL_MAX and X_G_B * vpf_lo_b > 0.30 + 0.08
assert 2 * X_G_B * L_CAL_B * math.sqrt(2) * 10 ** (0.15 / 20) * DRIFT < V_L_E3      # B ceiling pair stays below E-3 V_L
e_cal_b = 2 * X_E_CAL * leg_cal_min * 10 ** (-0.6 / 20) - V_L_MAX
e_def_b = 2 * X_E_DEF * UPK_LO * M_DEF_B / Q31 * DRIFT_DN - V_L_MAX
print(f"   (e) under B with the same words (0.55 / 0.85 FS): margins {e_cal_b*1e3:+.0f} / {e_def_b*1e3:+.0f} mV over V_L max (thinner by 0.6 dB, still positive)")
assert e_cal_b > 0 and e_def_b > 0
