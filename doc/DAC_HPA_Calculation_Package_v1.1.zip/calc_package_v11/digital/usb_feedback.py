#!/usr/bin/env python3
"""USB Audio Class 2.0 High-Speed explicit feedback values and endpoint sizes.

USB 2.0 §5.12.4.2 (quoted in sources/source_quotes.txt [S10]): for high-speed endpoints Ff is
the number of samples per 125 us microframe, unsigned 12.13 format left-aligned in four
bytes as 16.16; the four MSBs are zero; the three LSBs may extend the precision.

Rounding rule used for the nominal (start-up) value: round half up of fs/8000 * 2^16 to an
integer (all 16 fraction bits used).  The running value comes from the LRCLK count (see
section 3) and is never rounded to 13 bits.
Run: python3 usb_feedback.py > usb_feedback_output.txt
"""
from fractions import Fraction as F

RATES = [44_100, 48_000, 88_200, 96_000, 176_400, 192_000, 352_800, 384_000]


def nominal_ff(fs: int) -> int:
    exact = F(fs, 8000) * 65536
    return int(exact + F(1, 2))          # round half up (exact values here never tie)


print("1. Nominal feedback values (HS, 16.16 samples per microframe)")
print(f"{'fs':>7} {'samples/uframe':>15} {'exact x65536':>16} {'Ff (dec)':>9} {'Ff (hex)':>11} {'err ppm':>8}")
table = {}
for fs in RATES:
    exact = F(fs, 8000) * 65536
    ff = nominal_ff(fs)
    err_ppm = float((ff - exact) / exact) * 1e6
    table[fs] = ff
    print(f"{fs:7d} {float(F(fs, 8000)):15.4f} {float(exact):16.1f} {ff:9d} 0x{ff:08X} {err_ppm:8.3f}")
    assert ff >> 28 == 0, "four MSBs must be zero"
    assert abs(err_ppm) < 2.0

# Required assertions (R8-B1): 44.1 kHz = 0x00058333, 384 kHz = 0x00300000
assert table[44_100] == 0x00058333
assert table[384_000] == 0x00300000
assert table[48_000] == 0x00060000 and table[96_000] == 0x000C0000 and table[192_000] == 0x00180000
assert table[88_200] == 0x000B0666 and table[176_400] == 0x00160CCD and table[352_800] == 0x002C199A
# The v0.8 value 0x002C1999 equals floor(352.8 kHz) - i.e. 8x the 44.1 kHz value (the R8-B1 error)
assert 0x002C1999 == int(F(352_800, 8000) * 65536)
assert abs(0x002C1999 / table[44_100] - 8) < 1e-5
print("   v0.8 value 0x002C1999 = floor(352.8 kHz) = 8.000 x the correct 44.1 kHz value -> R8-B1 confirmed and fixed.")

print()
print("2. Isochronous OUT wMaxPacketSize (bInterval = 1 microframe) and feedback EP")
for sub, bits in ((2, 16), (4, 24), (4, 32)):
    worst = 0
    for fs in RATES:
        nmax = -(-fs // 8000) + 1          # ceil(fs/8000) + 1 extra frame for catch-up
        worst = max(worst, nmax * 2 * sub)
    print(f"   {bits:2d}-bit (bSubslotSize {sub}): wMaxPacketSize = {worst} bytes")
    assert worst <= 1024
print("   Feedback IN EP: bmAttributes 0x11 (iso, no sync, feedback usage), wMaxPacketSize 4, bInterval 4 (8 uframes = 1 ms)")

print()
print("3. Measured feedback: TIM3 counts LRCLK (ETR, PD2), latched in the SOF interrupt")
for K in (7, 10, 13):
    n_uf = 2 ** K
    res = F(65536, n_uf)                                 # LSB of 16.16 per count in the window
    for fs in (44_100, 384_000):
        rel = float(F(1, 1) / (F(fs, 8000) * n_uf))      # one LRCLK count relative to window total
        print(f"   window 2^{K:<2d} uframes ({n_uf*0.125:7.1f} ms), fs {fs:6d}: count ~{fs/8000*n_uf:9.0f}, "
              f"1 count = {int(res)} x 2^-16 samples/uframe = {rel*1e6:7.1f} ppm")
print("   Chosen: sliding window 2^10 uframes (128 ms), feedback = count << 6, updated every 8 uframes;")
print("   plus FIFO-centering term Kp*(target-level), clamped to +-1000 ppm of nominal.")
print("   The ~1 count quantisation dithers between adjacent values; the long-term mean is exact because")
print("   the LRCLK counter never loses edges (no accumulation of latch jitter).")

print()
print("4. FIFO depth and latency (CPLD 4 x M9K = 1024 x 32 bit = 512 stereo frames)")
for fs in (44_100, 96_000, 192_000, 384_000):
    print(f"   fs {fs:6d}: FIFO {512/fs*1e3:6.2f} ms; half-full target {256/fs*1e3:5.2f} ms; one uframe = {fs/8000:5.2f} frames")
assert 512 / 384_000 > 4 * 125e-6       # at least 4 microframes of headroom at the top rate

print()
print("Feedback table assertions passed.")
