#!/usr/bin/env python3
"""Digital stream R8 - clock plan, I2S/SPI/MCLK timing margins, DAC lock and ramp times.

Every number printed here is either a datasheet value (tagged DS in the source comment)
or computed from them (CALC).  Assertions stop the script if a requirement is missed.
Run: python3 clock_timing.py > clock_timing_output.txt
R8 round 2: X201 = Kyocera KC2520K80.0000C1GE00 80 MHz (D-3 revised); sections 4-5 rewritten (ratio, duty/edges at XI, DPLL, soft start).
"""
from fractions import Fraction as F
import math

print("=" * 78)
print("1. Family clocks, dividers and duty (no CPLD PLL)")
print("=" * 78)
FAM = {"48k": 49_152_000, "44k1": 45_158_400}          # X202 / X203 nominal [DS NDK NZ2520SDA list]
RATES = {"44k1": [44_100, 88_200, 176_400, 352_800],
         "48k": [48_000, 96_000, 192_000, 384_000]}
rows = []
for fam, fosc in FAM.items():
    for fs in RATES[fam]:
        bclk = 64 * fs                                    # 32-bit I2S, 64 BCLK per frame [DS ES9018K2M p.9]
        div = F(fosc, bclk)
        assert div.denominator == 1, "non-integer divider"
        d = int(div)
        assert d in (2, 4, 8, 16) and (d & (d - 1)) == 0
        # BCLK = toggle flip-flop with clock enable every d/2 FAM_CLK rising edges -> each half
        # period is exactly d/2 FAM_CLK periods, independent of the oscillator duty (40-60 %).
        t_fam = 1 / fosc
        t_high = t_low = (d // 2) * t_fam
        duty = t_high / (t_high + t_low)
        lr_div = d * 64
        rows.append((fam, fs, fosc, d, bclk, lr_div, duty, t_high))
        assert abs(duty - 0.5) < 1e-12
print(f"{'family':6} {'fs':>8} {'FAM_CLK':>11} {'div':>4} {'BCLK Hz':>11} {'FAM/LRCLK':>9} {'duty':>6} {'t_hi ns':>8}")
for r in rows:
    print(f"{r[0]:6} {r[1]:8d} {r[2]:11d} {r[3]:4d} {r[4]:11d} {r[5]:9d} {r[6]*100:5.1f}% {r[7]*1e9:8.3f}")

print()
print("ES9018K2M DATA_CLK limits [DS p.30]: tDCH, tDCL >= 4.5 ns, tDCY >= 10 ns, duty 45:55..55:45,")
print("  tDS >= 4.1 ns, tDH >= 2 ns to DATA_CLK rising edge.")
# Worst-case duty distortion budget at the DAC pin for the fastest BCLK (384 kHz, 24.576 MHz)
t_bclk_min = 1 / (64 * 384_000)
# CPLD output buffer spread TDO 1.421..2.140 ns [DS AGRV2K Tab 4-2]: rise vs fall asymmetry bounded by the spread
asym_cpld = (2.140 - 1.421) * 1e-9
# threshold/edge-rate asymmetry at the DAC input: 33 ohm + ~7 pF, tr ~1.2 ns; assume up to 1.0 ns [ASSUMP]
asym_edge = 1.0e-9
duty_err = (asym_cpld + asym_edge) / t_bclk_min
duty_min = 0.5 - duty_err / 2
print(f"  384 kHz: BCLK period {t_bclk_min*1e9:.3f} ns; asym budget {(asym_cpld+asym_edge)*1e9:.2f} ns "
      f"-> duty >= {duty_min*100:.1f} % (limit 45 %) [CALC]")
assert duty_min > 0.45
th = t_bclk_min * duty_min
print(f"  shortest BCLK phase {th*1e9:.2f} ns >= 4.5 ns [CALC]")
assert th > 4.5e-9

print()
print("SDATA/LRCLK launched on the FAM_CLK edge that makes BCLK fall (same register clock).")
# Output-to-output skew between BCLK and SDATA pins: TDO spread + routing mismatch [ASSUMP 1.5 ns]
skew = (2.140 - 1.421) * 1e-9 + 1.5e-9
for fam, fs, fosc, d, bclk, *_ in rows:
    half = 1 / (2 * bclk)
    setup = half - skew
    hold = half - skew
    assert setup > 4.1e-9 and hold > 2e-9
print(f"  worst case (384 kHz): setup margin {((t_bclk_min/2-skew)-4.1e-9)*1e9:.1f} ns, "
      f"hold margin {((t_bclk_min/2-skew)-2e-9)*1e9:.1f} ns (skew budget {skew*1e9:.2f} ns) [CALC]")

print()
print("=" * 78)
print("2. CPLD FAM_CLK domain timing (49.152 MHz worst)")
print("=" * 78)
t_fam = 1 / 49_152_000
# 4-bit divider counter + compare + enable: TCO + 3 LUT levels + 3 local/row hops + TSU [DS AGRV2K Tab 4-1/4-3]
path = 0.455 + 3 * 1.111 + 3 * 0.679 + 0.664
print(f"  FAM_CLK period {t_fam*1e9:.3f} ns; typical 3-LUT path {path:.2f} ns -> slack {t_fam*1e9-path:.1f} ns [CALC]")
print("  (clock-tree insertion/skew are not published by AGM; the Supra timing report is the sign-off) [MEAS]")
assert t_fam * 1e9 - path > 8

print()
print("=" * 78)
print("3. MCU -> CPLD SPI link (SPI1, mode 0)")
print("=" * 78)
PCLK2 = 72e6                      # APB2 chosen so that ADCCLK = PCLK2/6 = 12 MHz <= 14 MHz [DS Tab 4-41]
f_wr = PCLK2 / 2                  # prescaler /2
for fs, bits in ((384_000, 32), (352_800, 32), (192_000, 32), (44_100, 16)):
    frames_uf = fs / 8000
    nmax = math.ceil(frames_uf) + 1                  # host may send one extra frame per microframe
    bits_uf = nmax * 2 * 32 + 16                      # link always carries 32-bit words, + 16-bit header
    t_burst = bits_uf / f_wr
    util = bits_uf / (f_wr * 125e-6)
    print(f"  fs {fs:6d}: up to {nmax} frames/uframe -> {bits_uf} bits, burst {t_burst*1e6:5.1f} us of 125 us, "
          f"utilisation {util*100:4.1f} % [CALC]")
    assert util < 0.75
payload = 384_000 * 2 * 32
print(f"  nominal payload at 384 kHz/32-bit stereo {payload/1e6:.3f} Mbit/s = {payload/f_wr*100:.1f} % of {f_wr/1e6:.0f} MHz [CALC]")
t_ber = 1e10 / payload
print(f"  link BER test: 1e10 payload bits at 384 kHz take {t_ber:.0f} s = {t_ber/60:.1f} min;"
      f" 0 errors -> BER < {3/1e10:.0e} at 95 % confidence (rule of three) [CALC]")

print()
print("  MISO read-back timing (slave launches on SCK falling edge, master samples next rising edge):")
# delay from SCK edge at MCU pin to MISO valid at MCU pin
d_pcb = 2 * 0.3e-9                                 # 2 x ~5 cm trace [ASSUMP]
d_in = 1.308e-9                                    # TIN max [DS]
d_clk = 4.0e-9                                     # ALTCLKCTRL + global tree insertion [ASSUMP, not published]
d_reg = 0.455e-9 + 2 * 0.679e-9                    # TCO + 2 routing hops [DS]
d_out = 2.140e-9                                   # TDO max [DS]
t_su_mcu = 5.0e-9                                  # CH32V307 SPI master tsu(MI) not retrieved [ASSUMP]
d_buf = 4.1e-9                                     # U208 TI SN74LVC3G34 tpd max 3.3 V +-0.3 V, -40..85 C [DS TI SCES366L 6.6] (VE; Nexperia also 4.1)
loop = d_pcb + d_buf + d_in + d_clk + d_reg + d_out
for presc in (2, 4, 8):
    f = PCLK2 / presc
    margin = 1 / (2 * f) - loop - t_su_mcu
    print(f"    SCK {f/1e6:5.1f} MHz: half period {1/(2*f)*1e9:5.1f} ns, loop {loop*1e9:4.1f} ns, "
          f"tsu {t_su_mcu*1e9:.0f} ns -> margin {margin*1e9:+5.1f} ns")
print("  -> register reads use SPI1 prescaler /8 (9 MHz); the loop now includes U208 (4.1 ns max); no MISO data is used at 36 MHz. [CALC]")
assert 1 / (2 * PCLK2 / 8) - loop - t_su_mcu > 30e-9

print()
print("  3a. Write direction at 36 MHz through U208 (X-7: SCK, MOSI, FRAME buffered at the CPLD; mode 0, CPLD samples on SCK rising)")
# SCK and MOSI take identical paths (33R at the MCU, matched traces, two channels of one U208, <= 5 mm to the CPLD); only
# their SKEW matters. Nexperia gives no channel-to-channel skew -> bound it by tpd(max) - tpd(min) = 4.1 - 0.5 ns [DS].
T = 1 / f_wr
half_min = 0.45 * T                                 # MCU SCK duty 45..55 % [ASSUMP: CH32V307 SPI timing table not retrieved]
tv_mo = 5.0e-9                                      # MCU MOSI valid after the SCK falling edge [ASSUMP; STM32F1-class 3 ns]
th_mo = 0.0                                         # MOSI never changes before the falling edge [ASSUMP]
skew_buf = 4.1e-9 - 1.4e-9                          # U208 channel skew bound: TI tpd 1.4-4.1 ns [DS]; Nexperia alternate 0.5-4.1 ns -> 3.6 ns checked below
skew_pcb = 0.1e-9                                   # trace match +-15 mm [ASSUMP routing rule]
t_su_ff, t_h_ff = 1.0e-9, 0.5e-9                    # AGRV2K FF setup/hold [ASSUMP: not published]
d_data = d_in + 2 * 0.679e-9                        # pin -> capture FF D (TIN + 2 hops) [DS]
d_clk_min, d_clk_max = 1.0e-9, d_in + d_clk         # pin -> capture FF clock via ALTCLKCTRL/global [ASSUMP range]
su_pin = t_su_ff + d_data - d_clk_min               # setup needed at the pins
h_pin = t_h_ff + d_clk_max - d_in                   # hold needed at the pins (data path at least TIN)
m_su = half_min - tv_mo - skew_buf - skew_pcb - su_pin
m_h = half_min + th_mo - skew_buf - skew_pcb - h_pin
print(f"    half period (45 % duty) {half_min*1e9:.2f} ns; MOSI valid {tv_mo*1e9:.1f} ns; U208 skew bound {skew_buf*1e9:.1f} ns; "
      f"PCB {skew_pcb*1e9:.1f} ns; setup needed at the pins {su_pin*1e9:.2f} ns, hold {h_pin*1e9:.2f} ns")
print(f"    -> setup margin {m_su*1e9:+.2f} ns, hold margin {m_h*1e9:+.2f} ns at 36 MHz [CALC; worst-case skew bound, not typical]")
assert m_su > 0 and m_h > 0
m_su_nx = half_min - tv_mo - 3.6e-9 - skew_pcb - su_pin
print(f"    (approved alternate Nexperia 74LVC3G34DC, skew bound 3.6 ns: setup margin {m_su_nx*1e9:+.2f} ns - still positive)")
assert m_su_nx > 0
print(f"    the common U208 delay (<= 4.1 ns) shifts SCK and MOSI together; FRAME is set >= 100 ns before the first SCK edge and")
print(f"    cleared after the last (firmware), so its <= 4.1 ns delay is irrelevant. Fallback if the bring-up BER test fails: SPI1 /4")
print(f"    (18 MHz: setup margin {(0.45/(PCLK2/4) - tv_mo - skew_buf - skew_pcb - su_pin)*1e9:+.1f} ns; link utilisation doubles to <= 140 % -> not viable")
print(f"    at 384 kHz; then 32-bit words at 352.8/384 kHz need the CPLD to latch MOSI on the falling edge instead (RTL option).")

print()
print("=" * 78)
print("4. MCLK (X201 = Kyocera KC2520K80.0000C1GE00, 80.000 MHz, D-3 revised) - asynchronous mode")
print("=" * 78)
# Kyocera product specification TNY1T-H1-SEE01-04 rev 00, 5-Jun-25 [DS]: F_tol +-50 ppm (incl. initial, temperature,
# supply, load, 1-year aging, shock, vibration); ICC <= 8 mA loaded (2.8 < VCC <= 3.63 V); SYM 45..55 % @ 50 % VCC;
# Tr/Tf <= 4.5 ns (10..90 %, 2.8 < VCC <= 3.63 V); CL <= 15 pF; VIH >= 0.7 VCC, VIL <= 0.3 VCC; t_dis <= 200 ns;
# t_ena, t_sta <= 2 ms (catalogue/D-3: 3 ms); "all electrical characteristics defined on the maximum loaded condition".
# ESS ES9018K2M v3.7 [DS p.7, p.29, p.30]: MCLK > 192 x FSR (PCM normal mode); TMCH, TMCL >= 4.5 ns; TMCY >= 10 ns;
# duty 45:55..55:45; CCLK 10 pF (max column, fc 1 MHz); digital VIH >= DVCC/2 + 0.4 V, VIL <= 0.4 V.
F_MCLK = 80e6
PPM_MCLK = 50e-6 + 3e-6 * 9           # +-50 ppm (incl. 1-year aging) + 9 further years at 3 ppm/yr (pessimistic) [DS/ASSUMP]
PPM_FAM = 50e-6                       # NDK NZ2520SDA overall +-50 ppm [DS]
worst = F_MCLK * (1 - PPM_MCLK) / (384_000 * (1 + PPM_FAM))
assert worst > 192, "MCLK must exceed 192 x FSR [DS ES9018K2M p.7]"
print(f"  MCLK/FSR at 384 kHz = {F_MCLK/384_000:.2f} nominal, {worst:.2f} worst (MCLK -{PPM_MCLK*1e6:.0f} ppm, FSR "
      f"+{PPM_FAM*1e6:.0f} ppm) > 192: margin {(worst/192-1)*100:+.2f} % [CALC]")
t = 1 / F_MCLK
print(f"  cycle {t*1e9:.3f} ns >= 10 ns (TMCY) [CALC]")
assert t > 10e-9
for duty in (0.45, 0.55):
    print(f"  duty {duty*100:.0f} % at 50 % VCC: high {t*duty*1e9:.3f} ns, low {t*(1-duty)*1e9:.3f} ns (TMCH/TMCL >= 4.5 ns) [CALC]")
    assert min(t * duty, t * (1 - duty)) > 4.5e-9
print("  Kyocera symmetry 45..55 % equals the ESS 45:55 limit: no duty margin at 50 % VCC by datasheet; the pulse widths")
print("  (5.625 ns min) carry the margin (1.125 ns over 4.5 ns). Edge/threshold effects at XI are bounded next.")

print()
print("  Edge and threshold model at XI (exponential edges; worst corners) [CALC]")
C_XI = 10e-12                          # CCLK [DS p.29]
C_TRACE = 1.3e-12                      # R9 E-11 layout rule: X201 -> R203 -> XI <= 10 mm at <= 1.3 pF/cm [ASSUMP]
C_PADS = 0.5e-12                       # R203/R227/R703/XI/X201 pads [ASSUMP]
C_TAP = 2.4e-12                        # R9 E-11: R665 330 R tap, FULL count at the 74AUP1G17 CI bound 2.0 pF + pads (protection); no 'effective C' credit
C_LOAD = C_XI + C_TRACE + C_PADS + C_TAP
R203 = 33.0
tau_r = R203 * (C_XI + 1e-12 + C_TAP)   # R203 into XI + the XI-side stub + the R665 tap
d_diff = (1 - math.log(2)) * tau_r      # max rise/fall skew added by R203 at 50 % (RC delay between ln2*tau and tau)
VDD_MIN, DVCC_MAX = 3.3 * 0.97, 3.3 * 1.05
VIH = DVCC_MAX / 2 + 0.4               # 2.13 V [DS p.29]; XI thresholds assumed equal to the digital-input limits [ASSUMP]
VIL = 0.4
print(f"  load on X201: {C_LOAD*1e12:.1f} pF (XI {C_XI*1e12:.0f} + trace {C_TRACE*1e12:.1f} + pads {C_PADS*1e12:.1f} + R665 tap {C_TAP*1e12:.2f}) <= 15 pF [DS]")
assert C_LOAD <= 15e-12
CANDS = [("Kyocera KC2520K80.0000C1GE00 (X201, D-3 revised)", 80e6, 4.5e-9, (0.1, 0.9), "DS", True),
         ("NDK NSC5338D-80M (conditional 2nd source)", 80e6, 5.0e-9, (0.1, 0.9), "DS 25 C; 10-90 % assumed", False)]


def xi_wave(duty, T, tau, v=VDD_MIN):
    th, tl = duty * T, (1 - duty) * T
    a_, b_ = math.exp(-th / tau), math.exp(-tl / tau)
    vlo = v * (1 - a_) * b_ / (1 - a_ * b_)
    vhi = v - (v - vlo) * a_
    return vlo, vhi


for name, f, tedge, (lo_f, hi_f), tag, must in CANDS:
    T = 1 / f
    tau_osc = tedge / math.log((1 - lo_f) / (1 - hi_f))
    tau = tau_osc + tau_r
    ok_swing, sw = True, []
    for duty in (0.45, 0.55):
        vlo, vhi = xi_wave(duty, T, tau)
        sw.append(f"{vlo:.2f}..{vhi:.2f} V")
        ok_swing &= vlo < VIL and vhi > VIH
    pw50 = T * 0.45 - d_diff
    t_full = tedge / (hi_f - lo_f)          # linearised 0..100 % edge at the DS limit
    pw_hi = T * 0.45 - (VIH / VDD_MIN - 0.5) * 2 * t_full - d_diff
    pw_lo = T * 0.45 - (0.5 - VIL / VDD_MIN) * 2 * t_full - d_diff
    print(f"  {name}: {f/1e6:.0f} MHz, edge <= {tedge*1e9:.1f} ns ({lo_f*100:.0f}-{hi_f*100:.0f} %) [{tag}] -> tau at XI {tau*1e9:.2f} ns")
    print(f"     (a) swing at 45/55 % duty: {sw[0]} / {sw[1]} vs VIL {VIL} / VIH {VIH:.2f} V -> {'full logic levels' if ok_swing else 'NOT guaranteed [MEAS]'}")
    print(f"     (b) pulse width at 50 % VCC >= {pw50*1e9:.2f} ns vs 4.5 ns (margin {(pw50-4.5e-9)*1e9:.2f} ns); duty at XI "
          f"{(0.45 - d_diff*f)*100:.1f} % worst vs 45 % -> duty only by the part's 45..55 % (zero datasheet margin) [MEAS]")
    print(f"     (c) widths at VIH/VIL with DS-limit linear edges: {pw_hi*1e9:.2f} / {pw_lo*1e9:.2f} ns -> not guaranteed if ESS "
          f"measured there [MEAS], fallback R203 -> 0 R (BOM value)")
    if must:
        assert ok_swing and pw50 > 4.5e-9
print(f"  -> Kyocera: full swing and >= {t*0.45*1e9 - d_diff*1e9:.2f} ns pulses at 50 % from datasheet limits; R203 33 R kept "
      f"(adds <= {tau_r*1e9:.2f} ns tau, <= {d_diff*1e9:.2f} ns skew). Obsolete Epson SG-210STF 75 MHz and withdrawn TXC 7X (8 ns edges:")
print("     full swing not guaranteed at 80 MHz) are no longer candidates (D-3 revised). [CALC]")

print()
print("  Jitter (Kyocera): 1-sigma period jitter <= 5 ps, pk-pk <= 50 ps [DS product spec]; phase jitter 1.0 ps max (12 kHz-20 MHz)")
print("  per the K-series catalogue, not in the spec text -> [MEAS] (D-3); jitter-limited SNR of a full-scale tone:")
for sigma in (1e-12, 5e-12):
    for f in (1e3, 20e3):
        snr = -20 * math.log10(2 * math.pi * f * sigma)
        print(f"    sigma {sigma*1e12:4.1f} ps, {f/1e3:4.0f} kHz full-scale tone: {snr:6.1f} dB")
print("  -> not limiting for THD+N (-105 dB) or DR (115 dB(A)) even at the 5 ps period-jitter bound; ESS ASRC/DPLL rejects BCLK")
print("     jitter; J-test at bring-up. [CALC]")
print("  External DVDD still required (MCLK 80 MHz > 50 MHz and FSR up to 384 kHz > 192 kHz) [DS p.7].")

print()
print("  DPLL ratio check (regs 69..66, read LSB first): FSR = DPLL_NUM x F_MCLK / 2^32 [DS] ->")
print("  expected DPLL_NUM = FSR x 2^32 / 80 MHz; firmware accepts +-0.1 % (covers +-77 ppm MCLK and +-50 ppm FSR).")
print(f"  {'fs':>7} {'DPLL_NUM @80 MHz':>17} {'hex':>10} {'+-0.1 % window':>25}")
for fs in (44_100, 48_000, 88_200, 96_000, 176_400, 192_000, 352_800, 384_000):
    n80 = fs * 2 ** 32 / F_MCLK
    lo, hi = n80 * 0.999, n80 * 1.001
    print(f"  {fs:7d} {n80:17.0f} 0x{int(round(n80)):08X} {int(lo):>12d}..{int(hi):<12d}")
    assert n80 < 2 ** 32
print("  F_MCLK check at the first lock: FSR (TIM3 LRCLK_FB count) x 2^32 / DPLL_NUM within +-0.1 % of 80 MHz verifies the")
print("  fitted X201 (a wrong-frequency part, e.g. a 75/72 MHz Epson, is caught: -6.3 % / -10 %). [CALC]")

print()
print("=" * 78)
print("5. ES9018K2M lock, soft-start and mute timing [DS regs 6, 10, 14]")
print("=" * 78)
for fs in (44_100, 48_000, 88_200, 96_000, 176_400, 192_000, 352_800, 384_000):
    t0 = 16384 / fs              # stop_div = 0 (required > 96 kHz, and for Rev W)
    t5 = 2730 / fs               # stop_div = 5 (default)
    print(f"  fs {fs:6d}: DPLL lock edges 16384 -> {t0*1e3:6.1f} ms; 2730 -> {t5*1e3:5.1f} ms")
tss = 4096 * 2 ** (10 + 1) / F_MCLK
print(f"  soft start (reg14 soft_start_time = 10, default 0x8A and chosen 0xAA): 4096*2^11/80 MHz = {tss*1e3:.1f} ms; "
      f"x1.2 wait = {1.2*tss*1e3:.1f} ms")
assert abs(tss - 0.10486) < 1e-4
for fs in (44_100, 384_000):
    rate = 0.0078125 * fs / 2 ** (2 - 5)       # vol_rate = 2 (default), dB/s
    print(f"  volume/mute ramp at fs {fs}: {rate:.0f} dB/s -> 127.5 dB in {127.5/rate*1e3:.1f} ms")

print()
print("=" * 78)
print("6. Family change timeline (mux fitted, select = OSC44_EN; FAM_CLK domain held in reset)")
print("=" * 78)
t_mute = 127.5 / (0.0078125 * 44_100 / 2 ** (2 - 5))
steps = [("soft mute ramp (worst, 44.1 kHz)", t_mute), ("I2S_RUN=0 (outputs low, FAM_CLK domain in reset)", 0.1e-3),
         ("enable new osc; wait start-up max [DS NDK 4 ms] x2.5", 10e-3),
         ("switch (OSC44_EN edge), old osc to stand-by, release reset", 0.1e-3),
         ("DAC DPLL lock, worst 16384/44.1k", 16384 / 44_100), ("soft unmute", t_mute)]
tot = 0
for s, t in steps:
    tot += t
    print(f"  {s:48s} {t*1e3:7.1f} ms  (cum {tot*1e3:7.1f} ms)")
print(f"  total worst case {tot*1e3:.0f} ms [CALC]")

print()
print("All clock/timing assertions passed.")
