#!/usr/bin/env python3
"""Emit the MCU (64-pin) and CPLD (32-pin + EP) pin tables for report.md from netlist.csv, adding
pin type / FT / reset-default function from the WCH pin-definition table (sources/source_quotes.txt [S3]).
Run after gen_netlist_bom.py:  python3 pin_tables.py > pin_tables_output.txt
"""
import csv

FT = set("PA8 PA9 PA10 PA11 PA12 PA13 PA14 PA15 PB2 PB3 PB4 PB5 PB6 PB7 PB8 PB9 PB10 PB11 PB12 PB13 PB14 PB15 "
         "PC6 PC7 PC8 PC9 PC10 PC11 PC12 PD2".split())
ANALOG = set("PA0 PA1 PA2 PA3 PA4 PA5 PA6 PA7 PA11 PA12 PB0 PB1 PB8 PB9 PB10 PB11 PB12 PB13 PB14 PB15 "
             "PC0 PC1 PC2 PC3 PC4 PC5 PC14 PC15".split())
RESET_SPECIAL = {"PA13": "SWDIO (SDI)", "PA14": "SWCLK (SDI)", "PB2": "PB2/BOOT1"}

rows = list(csv.DictReader(open("netlist.csv")))
mcu = [r for r in rows if r["refdes"] == "U201"]
cpld = [r for r in rows if r["refdes"] == "U202"]

print("| Pin | Name | Type | FT | Reset-default function | Net | Configuration / note |")
print("|---|---|---|---|---|---|---|")
for r in mcu:
    base = r["pin_name"].split("-")[0].split("/")[0]
    if base.startswith("P") and base[1] in "ABCD":
        typ = "I/O/A" if base in ANALOG else "I/O"
        ft = "FT" if base in FT else "-"
        rst = RESET_SPECIAL.get(base, f"{base}: GPIO floating input")
    else:
        typ, ft, rst = ("P" if base.startswith("V") else "I"), "-", "supply/dedicated"
        if base in ("OSC_IN", "OSC_OUT"):
            typ, rst = "I/A" if base == "OSC_IN" else "O/A", "HSE oscillator pin"
        if base == "NRST":
            rst = "reset input"
        if base == "BOOT0":
            rst = "boot select (sampled at reset)"
    print(f"| {r['pin']} | {r['pin_name']} | {typ} | {ft} | {rst} | {r['net']} | {r['note']} |")

print()
print("| Pin | Name | Net | Note |")
print("|---|---|---|---|")
for r in cpld:
    print(f"| {r['pin']} | {r['pin_name']} | {r['net']} | {r['note']} |")
