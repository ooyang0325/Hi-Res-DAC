# Digital stream (brief §7.4) — R8 / Spec v0.9 / Notes v0.8 / Parts List v0.7

USB DAC + balanced headphone amplifier (owner Diego Yang). Scope: block 2 (CH32V307RCT6, Y201, AGRV2KQ32, X201–X203, clock logic, link, debug pads, I²C pull-ups, series terminations), LEDs D705/D706 + R701/R702, J703/R703, MCU/CPLD-side DAC control nets. Round 1: 24 Sep 2026; round 2: 25 Sep 2026; round 3 (top section, review fixes): 25 Sep 2026.

**Labels:** [DS] datasheet min/max (source in §15), [DS-typ] typical only, [CALC] computed in a saved script (§16), [ASSUMP] assumption, [MEAS] must be measured (the designed-in fallback is named). Source codes S1–S11 refer to `sources/source_quotes.txt`, which holds the verbatim quotes and URLs.

# R10 fixes — 26 Sep 2026

Binding inputs:
- `r10/decisions_r10.md`: F-5 (digital leads) and F-1 (firmware parts, on protection's request).
- `r10/reviews_r10.md`: R10-B.

Numbers come from `firmware_sequences_output.txt` §20 (F-5) and §12 (F-1) [CALC]; §3, §9, §17 and §18 were updated to match, as was `adc_settings` §3. **Netlist change: U201-4 PC15 = N6_ORTEST** (F-1a, protection's OR self-test line). With it, **no spare MCU pin remains** (49/49; 11 CPLD user IOs are still spare). The BOM is unchanged. Sources:
- ES9018K2M datasheet v3.7, reg 15–20. The master trim is **one** signed 32-bit value for both channels, ≤ 0x7FFFFFFF, and its **reset default is 0x7FFFFFFF = 0 dB, i.e. untrimmed**. Volume reg 15/16 are per channel, 0 … −127.5 dB in 0.5 dB steps, attenuation only [DS].
- WCH CH32V307 EVT `FLASH_Program` note: erased flash reads **0xE339E339**, not 0xFF. The standard erase page is 4 KB. Flash erase/program above 120 MHz needs HCLK/2 [WCH].

**Spec note for integration (F-5 wording):**
- The hardware detectors' content boundaries are guaranteed only at or below the calibrated full-scale level. That level is A_FS = 1.55 Vrms +0.15 dB per leg: +0.10 dB production acceptance plus 0.05 dB instrument allowance, the value protection already uses.
- A board without a valid calibration record runs at the −4.5 dB default (master trim 0x4C3EA838, 0.983–1.293 Vrms per leg).
- The firmware never sets a gain above the calibrated level.

| Item | Action | Result | Evidence |
|---|---|---|---|
| **F-5a** (R10-B) calibration record | A 52-byte record (48 B under the CRC + a VERIFIED word) in its own 4 KB flash page at **0x08077000**: the last page of the 480 KB CodeFlash, in the non-zero-wait area for every R0WAIT split [ASSUMP; DS 2.5.2]; the linker and IAP never erase it. Fields:<br>– magic `CAL1`, version 1, length 48;<br>– **MCU 96-bit UID** (binds the record to the chip);<br>– **trim_L and trim_R as Q31 codes**;<br>– vmeas[4]: the four legs measured at the default trim, in 0.1 mVrms rounded up;<br>– dcbase[4]: leg DC baselines, which gives the undefined "stored factory baseline" of the advisory pre-close check a home;<br>– **CRC-32/MPEG-2** over words 0–10, the CH32V307 CRC unit's native mode [ASSUMP: STM32F1-compatible unit; the software fallback is identical];<br>– **VERIFIED = crc32 XOR 0x5A5A5A5A**, programmed without an erase by `CALOK` only after the P-4 re-measurement passed.<br>The record is written only by the production command `CALW` over J201/USART1 (no USB write path exists). The firmware computes t_c = floor(0x4C3EA838 × 15,500 / larger-leg vmeas) itself; **trims are never accepted as free numbers**. The write runs only when the device is idle with RELAY_EN low: S2–S8 (domains off), IWDG long (the DX-2 condition is met), HCLK/2, erase, program, **read back all 48 B**, restore, software reset. The normal boot path then re-validates the record, which stays UNVERIFIED (DEFAULT) until P-4 passes. | CRC self-checks match the published values: 0x0376E6E7 for "123456789" and 0xDF8A8A2B for the word 0x12345678. A test vector (13 words, trims, CRC 0xD47C9D40, VERIFIED 0x8E26C71A) is printed for the production tool. Range check: **[0x4BC89DFE, 0x7E88E865] = −4.55 … −0.10 dB**. Analog's need is −2.92 … −0.54 dB (class E).<br>– **Upper end −0.10 dB** (analog 05:06, adopted): it refuses 0x7FFFFFFF (the untrimmed reset value) and anything within 0.10 dB of full scale. It still leaves 0.44 dB of room for an ESS full scale below TYP; only a unit below 1.568 Vrms untrimmed is refused. The earlier −0.44 dB top cost yield and gained no safety.<br>– **Lower end (garbage filter only; more attenuation is always safe):** protection's conservative 3.66 V/leg bound (−4.45 dB) − 0.10 dB, so a unit far above the TYP model can still be calibrated.<br>**No range can catch a wrong in-range record** (−0.5 dB on a high-gain unit is 2.4 dB hot). **That gap is closed by the VERIFIED word:** a record becomes active only after the mandatory P-4 re-measurement has passed. An interrupted write leaves magic or CRC invalid, so the board falls back to the default (safe). | fw §20 record table, test vector; ESS DS v3.7; WCH EVT note |
| **F-5b** boot and every attach | The MCU runs from VBUS, so **every attach is a cold boot**. In the ≥ 5.2 ms HSI phase (8 MHz, below the WCH flash-clock note), the firmware reads and validates the record: magic → version/length → CRC → UID → range. The result goes into a gain state G {mode, reason, M, s_L, s_R, post-CPLD OD-1 thresholds and CPLD self-test DC per channel}, held with its own CRC. **Missing record, bad version, bad CRC, foreign UID, out-of-range trim or UNVERIFIED record → DEFAULT:** 0x4C3EA838 on both channels, no sample scaling, log `CAL DEFAULT <reason>` (USART1 + RAM event log), and **red LED double-flash** (2 × 100 ms every 3 s; a steady-red fault or the programming-mode blink takes precedence). **Nothing but a valid and verified record plus a reset leaves DEFAULT.** The one exception is the production session `CALTRY`: J201 plus a key, only with a valid-but-unverified record, RAM-only, ending at any reset. It exists so that P-4 can measure the record. Every DAC init first checks G's CRC: resume, OD-2 re-init, fault retry and rate/family re-init all rewrite reg 17–20, because the ESS resets them to 0 dB. A G failure → DEFAULT + log `CAL RAM FAULT`. **New pre-close condition:** reg 15–20 read back, with **reg 17–20 == G.M**; otherwise no RELAY_EN, log, and DAC re-init. | Truth table, 14 cases, all as intended: valid and verified → CALIBRATED. Each of the following → DEFAULT with its reason: an unverified record, a VERIFIED word from another record, an erased page (0xE339E339), all-FF, all-0, a flipped CRC bit, a flipped trim bit, a foreign UID with a valid CRC, trim above T_HI or below T_LO, trim 0x7FFFFFFF, trim = default, version 2. The untrimmed 0 dB reset state can never meet a closed switch:<br>– at start-up, the read-back gates closure;<br>– during play, a DAC reset drops the lock → EXTI9 → switch open ≤ 1.04 ms, before the ESS can relock (stop_div 2730 edges ≥ 7.1 ms at 384 kHz) [ASSUMP: no output before lock];<br>– any wrong trim is caught by OD-2 poll A → switch open ≤ 16.45 ms. | fw §20 truth table, boot list |
| **F-5c** gain ceiling (arithmetic) | V_c = U_c · x · s_c/2³¹ · M/2³¹ · 10^(−0.5·v_c/20), where M = reg 20…17 and v_c = reg 15/16.<br>– **Realisation.** If the channels are within **0.04 dB** (analog C: plus the 0.041 dB P/N leg mismatch, G, the smaller leg is then ≥ −0.081 dB, inside −0.10 dB): M = min(t), no scaling, and the stream stays **bit-perfect**. Otherwise M = max(t), and the other channel is scaled in the MCU with s = floor(2³¹·t_min/t_max). Only one channel is ever scaled.<br>– **Sample scaling:** `mulhsu(x, 2s) + (x<0)`, 3 RV32 instructions, rounded toward zero.<br>– **Volume:** v = max(host, overload, Type-C, E-21 ceilings). The UAC2 Feature Unit RANGE is −127.5 … **0 dB**, 0.5 dB steps, and v_host = clamp(ceil(−h/128), 0, 255), so positive host requests read 0 dB.<br>– **Bit-perfect test mode:** scaling bypassed **and** M = min(t). | **Max V_c = U_c·t_c/2³¹**, the channel's calibrated level; in DEFAULT it is U_c·0x4C3EA838/2³¹. Checks: 20,067 trim pairs → effective code ≤ t_c on both channels; worst shortfall below a channel's own trim 0.040 dB. 65,536 host codes → attenuation ≥ requested, never below 0 dB. Samples incl. −2³¹ → \|y\| ≤ \|x\|·s/2³¹ with no overflow.<br>**Worst-case rounding, all downward:** vmeas ceil ≤ 0.0009 dB, t_c and s floors < 1 LSB (6·10⁻¹⁰), sample ≤ 1 LSB (2⁻³¹ FS), volume ceil 0–0.5 dB, default code −6.5·10⁻⁹ dB. The digital chain has **no upward term**. The ESS internal rounding is unpublished, ≤ 5·10⁻⁷ dB for a ≥ 24-bit coefficient [ASSUMP], and it is inside the measured P-4 level. Upward terms that remain are analog only: instrument ≤ 0.05 dB (inside A_FS 2.230 V/leg) and **post-calibration drift ≤ +4.23 %** (3V3A window + TCR, G) → **2.325 V/leg over 0–50 °C** (analog; protection has it); the ESS tempco is unpublished (E). Firmware cannot trim the drift out, because 3V3A is read only against 3V3M, which is itself ±1.5 %. | fw §20 checks |
| **F-5d** production test | Setup: J201 USART, 1 kHz 0 dBFS from the PC. Measure **unloaded, each jack contact to GND**, with a true-RMS instrument ≥ 10 kΩ and ≤ ±0.05 dB at 1 kHz (analog B.2: unloaded is the maximum, so the ceiling holds for every load).<br>– **P-1:** no record → DEFAULT, LED, log, with reg 17–20 read back = 0x4C3EA838. Measure each leg at the default (analog: every unit linear, whereas at 0 dB a worst-swing unit clips by 0.33 V). Pass window 0.934–1.559 Vrms, identical to the firmware range (0.972–1.308 expected from the TYP model). The reading is vmeas.<br>– **P-2:** `CALW` (write, read-back, reset) → DEFAULT, reason UNVERIFIED.<br>– **P-3:** record present and valid (`CAL?`: v1, CRC, UID, range, trims), still unverified.<br>– **P-4, mandatory and firmware-gated:** `CALTRY` applies the record for the session, with the normal re-init and pre-close read-back. Re-measure every leg unloaded: 1.55 Vrms ± 0.10 dB (design worst for a smaller leg −0.081 dB); balance ≤ 0.10 dB (design worst 0.081 dB unloaded, 0.125 dB with RON under load, ≤ 0.3 dB); V_cal/V_def = E_c/M_DEF ± 0.05 dB. **PASS** → `CALOK` programs VERIFIED → reset → `CAL?` CALIBRATED, reg 17–20 = G.M, no double-flash. **FAIL** → `CALE`, and the board stays at DEFAULT.<br>– **P-5: erased record (`CALE`) → DEFAULT, and each leg equals its P-1 value ± 0.05 dB**; a +6 dB host request is still clamped to 0 dB.<br>– **P-6:** `CALT crc/uid/range/ver` (this command can only create invalid records) → DEFAULT with that reason.<br>– **P-7:** restore (`CALW`, `CALTRY`, re-measure, `CALOK`) and repeat P-3/P-4, then archive the per-board data.<br>– **P-8** (qualification, analog's suggestion): log the 1 kHz level per leg at the E-4 soaks (0–5 / 25 / 50 °C); expected ≪ +4.08 %. | This proves on every board that the stored trims are applied and that an erased record really gives the −4.5 dB level: P-5 = P-1 within 0.05 dB, and ≤ 1.293 Vrms + 0.1 dB. About 6 erase cycles per board (endurance not in the retrieved DS [ASSUMP ≥ 1k]); `CALOK` is a program-only step. An interrupted `CALW` or `CALOK` leaves the board at DEFAULT (safe). A full-chip erase leaves the board at DEFAULT, flagged (safe); recalibrate. | fw §20 P-1…P-7 |
| **F-5e** cost and OD-1/OD-2 interaction | – **CPU:** boot validation ≤ 0.26 ms inside the existing HSI phase (TSIGATT unchanged at ≤ 23.9 ms). Scaling only on units imbalanced by > 0.05 dB: 1.3 % typical / **2.1 % worst at 384 kHz**, fused into the USB-side OD-1 pass (OD-1 13.3 % → 15.5 % worst).<br>– **Flash:** one 4 KB page (52 B used) + ~2.5 KB code [ASSUMP].<br>– **RAM:** 212 B.<br>– **Pins:** none (USART1 and LEDs already exist).<br>– **LED:** +0.085 mA average, inside the both-LEDs-on budget; off in suspend.<br>– **OD-1:** the USB-side guard sees pre-scale samples (thresholds unchanged). The post-CPLD guard uses floor(threshold·s_c) on a scaled channel, and the CPLD self-test DC is scaled the same way.<br>– **OD-2:** poll A already reads back reg 0–20 → +1 compare of reg 17–20 with G.M, no bus load change (27.4 %). The pre-close read-back is 0.84 ms per closure, inside the 150 ms DC_PERMIT_N wait. | First closure stays at 540.8 ms, the rate/family worst at 972 ms and the suspend bound at 8.75 ms. The analog meaning of every OD-1 threshold is unchanged on a scaled channel. In DEFAULT, FS maps to 0.983–1.293 Vrms, so the guards act earlier (conservative). | fw §20 cost; §13, §14 |
| **F-5f** levels and margins | **Analog confirmed at 04:58** (`analog/out/r10_fixes.txt` F-5, class E: the ESS full scale is a TYP value). Highest-gain unit: untrimmed **3.069 V pk/leg / 6.138 V pair**; −4.5 dB default **1.828 V / 3.656 V**; supply bound (b) at the default 1.979 V. Lowest-gain unit: 2.333 → 1.390 V. 20 Hz FS sine, time above V_L 1.80 V:<br>– calibrated 18.27 ms;<br>– ceiling 18.39 ms;<br>– ceiling + drift 18.67 ms;<br>– **default 16.81 ms** (bound b 17.49 ms);<br>– **untrimmed 20.26 ms > 19.5 ms, trips** (= R10-B).<br>Analog (A.1): protection's 3.66 V/leg is a conservative E bound (supply-bounded source, Rs ≥ 651 Ω), fine for a no-false-trip check. It is not a swing limit, and **the swing gives no cap**: 3.07 V exceeds the guaranteed linear range but not the typical swing. At the default, the 3.66 V bound gives 2.180 V/leg (4.360 V pair, 18.23 ms), still below the calibrated 2.192 V (asserted). | Level margins to the E-3 20 Hz limit: +1.52 dB at the ceiling, **+1.16 dB with drift, +3.25 dB at the default** (+2.56 dB bound b), −1.25 dB untrimmed. **The default is −4.5 dB re the untrimmed level, i.e. only −1.58 … −3.96 dB re 1.55 Vrms**, and even the 3.66 V bound at the default stays below the calibrated peak (asserted). Analog's recommendations 1 (measure at −4.5 dB) and 3 (switch open until the trim is written and read back) were already in the rule; 2 is adopted in a narrower form (see F-5a); 4 is adopted as P-8. Post-calibration drift is **not bounded** by published data (no ESS Rs tempco). The published terms give ±0.36 dB (G) → 2.325 V/leg, with the ESS tempco on top (E); P-8 measures it (Q). **Protection (06:20):** the content boundary holds only at or below the calibrated level including drift (2.325 V/leg). Margins at the −4.5 dB default are **13.9 % (model) / 6.6 % (3.66 V basis)**; calibrated incl. drift **4.3 %**. Untrimmed 0 dBFS trips E-3, so the record check and default rule are **required**, as adopted. | fw §20 level table; analog r10_fixes F-5 |
| **F-5g** finding: self-test amplitudes at the default (**resolved by F-1: a′ deleted**) | Protection p20 scaled a′ from 0.39 to 0.65 FS and e from 0.5 to 0.85 FS by the full 4.5 dB. At 0.65 FS the uncalibrated legs sit at 0.903–1.188 V, so the **pairs are 1.81–2.38 V > V_L 1.80 V**. E-3 then trips in about 20 ms, before the 70–140 ms a′ window, so **a′ would fail on uncalibrated boards**. At 0.85 FS the e pairs are 2.36–3.11 V (fine). | At the default, a′ needs x ≤ 0.492 FS and a window covering 0.68–0.90 V/leg (unit spread). **Sent to protection; it re-derives these together with its F-1 self-test changes.** §12 is marked. | fw §12, §20 |
| **Power R10 item** (F-2 walk, row R-54): ANA_SENSE supply-fault threshold | Power's corrected band for the 4.00 V threshold is 3.704–4.236 V (ADC 11 LSB, 1 µA PA0 leakage [ASSUMP], TPS70933 VDDA). In **High mode at VBUS 4.40 V with the J101 drop**, the 5V_ANA_F minimum of 4.233 V sat **−3 mV** below the band top, so a **false supply fault** was possible with every error at its worst sign. Power's later model with the E-16 topology gives 4.241 V, which is only +5 mV: still too thin. **Adopted power's firmware-only option:** **High mode (ILIM_HI = 1): 3.90 V = 1.247 V = code < 1548.** Default keeps 4.00 V = code < 1587 (+71 mV, E-16 model). The threshold switches together with ILIM_HI (switch open, or in the downgrade sequence). | High-mode margin **+108 mV** (band top 4.133 V vs 4.241 V; +124 mV without the J101 drop; power c21 R10 addendum with the E-16 topology). I chose this over "accept as L-3", because L-3 limits the rated power, and a false fault (dropout, −3 dB ceiling steps) would be a malfunction. Nothing is lost: X-5 is a gross supply-fault detector (a real fault reads about 0 V), and rail regulation is watched by RAILS_OK_N and the headroom-event rule. ADC settling residual at 3.90 V: 31 mV at 5V_ANA_F, reading high (benign for false trips). | fw §3; adc §3; power c21 R10 addendum |
| **F-5h** option B readiness (protection-2 07:42 FYI; owner undecided) | Owner option B would lower the calibrated full scale by 0.6 dB and the default to −5.1 dB. The firmware then changes **two constants**: target 1.4465 Vrms/leg and M_DEF = **0x4727DEE6** (−5.100000002 dB, floor). Everything else is derived: range [0x46B9B59C, 0x7E88E865], P-1 window 0.813–1.455 Vrms, P-4 1.430–1.463 Vrms. The record **version identifies the calibration basis** (v1 = 1.55 Vrms at 0x4C3EA838). A basis-B firmware writes v2 and accepts a v1 record only by recomputing t_c from vmeas with the lower target (downward only), or treats it as DEFAULT. | Every level margin improves by 0.6 dB: default 16.16 ms, ceiling + drift 18.19 ms at 20 Hz. The self-test word margins would shrink by 0.6 dB, so **protection-2 re-derived them (07:55):** (f) stays at 0.30 FS (+65 mV); **(g) rises from 0.25 to 0.30 FS under B only** (margins 82 / 228 mV, 19.5–24.7 ms). The pass windows and totals are unchanged. Basis constants: {target, M_DEF, OR word} = A {1.55 Vrms, 0x4C3EA838, 0.25 FS} / B {1.4465 Vrms, 0x4727DEE6, 0.30 FS}. No board is calibrated yet (build on HOLD), so in practice B is a constant change. | fw §20 (option B block) |
| **F-1a** (protection request 06:20) new MCU pin | **PC15 (U201-4) = N6_ORTEST**, the over-range (OR) self-test line, protection-owned. It is the **last spare MCU pin**: PC14 has been N5_U102_OFF since R9 E-16, so **49 of 49 GPIO are now used**. A CPLD spare IO was not chosen, because the MCU pin was free. A CPLD IO is weakly pulled up during configuration (the test line would go high at power-up unless an external pull-down overrides it), and it is valid only while 3V3D is up. A −0.5 V pull into an unpowered CPLD pin would flow from GND and cannot back-power 3V3D. Pin behaviour:<br>– push-pull, **LOW in every state except the boot OR test (g)**, high ≤ 32 ms per run;<br>– driven low in the DC_PERMIT_N EXTI at the trip (≤ 50 µs), and every pre-close check verifies PC15 output = 0;<br>– RTC-domain pin with a static load ≤ 34 µA (R950 100 k to the Q627 base + the V_OR− divider); no series resistor needed. | **Hi-Z / reset:** protection's divider pulls the pin to about −0.5 V through 470 k. The pin clamp takes ≤ 8 µA of negative injection. **Accepted:**<br>– it is ≪ the ±5 mA per-pin injection limit [ASSUMP: STM32F1-class; the WCH absolute-maximum table was not retrieved];<br>– it occurs only while VNEG is up and before GPIO init, when no ADC conversion runs (negative injection can disturb ADC accuracy);<br>– at attach the rails are still off, and GPIO init drives PC15 low within the first milliseconds.<br>**Fail-safe:** a stuck-high line makes every OR channel fire at \|leg\| ≥ 0.30 V (trips, never masking), and a reset makes the pin Hi-Z, which switches the test off. In suspend the rails are off, so 0 A; the pin at 0 V sources ≤ 4 µA from GND, with no 3V3M load. **Netlist:** `gen_netlist_bom.py` re-run; only this row changed, the BOM is unchanged, and pin_tables is regenerated. Cross-stream check (a temporary copy writing into digital/): **473 parts / 246 nets / 1,386 pins, 0 issues**. | netlist U201-4; fw §12, §17 |
| **F-1b** boot self-test (replaces a′) | – **a′ deleted:** the RC leg windows are removed. The F-5g finding is therefore moot, and F-1 resolves it: (f) uses ±0.30 FS at any gain.<br>– **(f) LPW:** ±0.30 FS on L then R, both signs, **any gain incl. the −4.5 dB default** (leg 0.417–0.698 V, pair ≤ 1.40 V < V_L) → trip 72.4–99.8 ms, **pass 65–110 ms** (protection 07:09: LPW timer 910 k / 100 nF C0G; was 51.4–84.6 / 45–100 ms).<br>– **(g) OR:** PC15 high with a **1 ms settle, confirmed by protection-2** (no capacitor on the threshold nodes, τ ≤ 11.9 µs, within 1 mV after ≤ 90 µs; R951 10 k now defines V_OR+ = 0.086–0.141 V; test-word margins 186 / 41 mV), then ±0.25 FS on L then R (leg 0.347–0.581 V) → 19.5–24.9 ms, **pass 18–32 ms**; PC15 low at the trip.<br>– **(e) E-3:** **±0.55 FS on calibrated units** (protection-2 08:27, was 0.50 FS) and ±0.85 FS at the default; 19.5–24.2 ms, pass 18–26 ms (unchanged).<br>Every test word is scaled by s_c on an MCU-scaled channel (F-5). Recovery R ≤ 209 ms and PB0 low after every trip, as before.<br>**Coverage, stated plainly (indep-check 07:57):** a balanced word arms two parallel paths on the same summing node (+L: LP+ positive with LN− negative; −L: the converse). Each (f)/(g) run therefore proves at least one of the two, and **an open channel is masked by its mate: pairwise, not per-channel, coverage.** The boot self-test covers **every channel pair, plus the shared paths**; a single dead channel or a one-sided reference fault is masked by its mate. **Per-channel coverage comes only from protection's production per-leg injection** (protection-2 08:20). **Decision (protection-2 08:27): (A) state pairwise coverage as a limitation** (0 parts). A latent dead channel still leaves the independent firmware tiers for single-leg faults: T1 ≥ 1.001 V within 218 ms, T3 within 2.36 s. **Presented to the owner, with digital's data:**<br>– **(B) per-channel OR:** split N6_ORTEST into T+ (PC15 → Q627) and T− (a CPLD spare IO → R937 return, with an external pull-down against the configuration pull-up); +1 RTL bit (reset 0); 8 OR runs → **4.65 s**.<br>– **(C) also per-channel LPW:** a second CPLD line, about 4–6 parts, 8 LPW runs → **5.92 s**.<br>There is no firmware or RTL change unless the owner chooses B or C.<br>**(e) word check:** 0.50 FS isolates E-3 only at calibrated gain (the indep-check confirms that p21b's 0.695 V row is wrong for the default, where the firmware takes 0.85 FS from G.mode). At 0.50 FS the worst calibrated pair was 2.059 V vs V_L max 2.016 V, only +43 mV. **Digital's 0.55 FS was adopted by protection-2 (08:27):** worst pair 2.265 V (**+249 mV**); default 0.85 FS 2.266 V (**+250 mV**, drift-down applied as protection does). The OR stays silent at the calibrated ceiling + drift (1.279 V < 1.762 V). Under option B the same words keep +98 / +99 mV (asserted). | **3.68 s implemented** (protection's sizing: 4 × 110 + 4 × 32 + 4 × 26 ms + 12 × R + 2 × 252 ms). This **exceeds the R9 orchestrator target of ≤ 3 s by 0.68 s**. Option: one OR direction per boot, rotating, **2.96 s ≤ 3 s**; it needs a persistent index in a flash boot-counter page (4 KB + about 0.2 KB code; one half-word program per boot in the HSI phase), because the RTC backup registers are lost at unplug (VBAT = 3V3M). This is an **owner decision, presented by protection**, which recommends testing every pair at every boot. First audio after an attach comes about 3.7 s + 0.54 s later. Cost: CPU < 0.1 %, RAM < 64 B, no ADC or I²C load. Checks: the (f) and (g) amplitudes exceed the stage levels at the lowest default gain, and stay below V_L at the ceiling plus drift (asserted). | fw §12, §20; protection p21b (e2) |
| **F-1c** firmware DC tiers | Protection p21c: **no change** (thresholds, windows and deadlines). T1–T3 are already history-robust from any reachable state, now including short opposite-polarity bursts (indep-check; 08:37). Guaranteed levels, leg / pair: **T1 ≥ 1.001 / 1.015 V within 218 ms, T2 ≥ 0.313 / 0.312 V within 603 ms, T3 ≥ 0.178 / 0.195 V within 2.36 s**; rail-bounded variant 1.007 / 1.027, 0.316 / 0.316, 0.179 / 0.197 V. The owner rule (≥ 0.2 V within 3 s) holds. **Hardware floor |leg| ≥ 0.34 V, |pair| ≥ 0.68 V** (protection-2 08:25, rounded up with clearance; the LPW level max is 0.32401 V, or 0.33401 V with a 10 nA leakage allowance). Below it, T2/T3 keep the pair ≤ 17.4 / 8.7 mJ and the leg ≤ 14.5 / 7.3 mJ at 16 / 32 Ω (p21c re-run). Pre-close checks and the E-2 re-arm (DC_PERMIT_N low ≥ 150 ms) are unchanged; the new timers reset in ≤ 9.6 ms (910 k / 100 nF C0G). | No firmware time, CPU, RAM or pin change for the tiers. | fw §9, §18; protection p21c |

- **Assumptions added:**
  - the record page address (the non-zero-wait area exists on the 256 K + 64 K part, DS 2.5.2);
  - the CRC unit is STM32F1-compatible;
  - flash endurance ≥ 1k;
  - ESS internal trim rounding is ≤ 2⁻²⁴;
  - no ESS output before relock after a reset.
- **Owner-visible:**
  - the boot self-test grows from 2.84 to 3.68 s (or 2.96 s with the rotating OR option), so the first audio after an attach comes about 4.2 s after enumeration. It covers every channel pair; per-channel coverage is a production test;
  - uncalibrated boards blink a red double-flash and play at 0.983–1.293 Vrms per leg;
  - calibration needs the WCH-LinkE UART on J201 and a DMM;
  - it is lost after a full-chip erase, and the board is then safe at the default.
- **Firmware list changes for the integrated summary (f):**
  - **B / self-test (F-1):** a′ deleted; (f) LPW ±0.30 FS (65–110 ms); (g) OR with PC15 = N6_ORTEST high, ±0.25 FS (18–32 ms); (e) E-3 unchanged; **3.68 s** (2.96 s with the rotating OR option, owner decision); pre-close also checks PC15 = 0;
  - **B / X-5:** supply fault = ANA_SENSE < 1587 counts (4.00 V) in Default, **< 1548 (3.90 V) in High mode**;
  - **B:** master trim = G.M, from a valid and verified record or the −4.5 dB default with LED and log;
  - **pre-close:** add the reg 15–20 read-back = G.M;
  - **C:** OD-2 poll A also compares reg 17–20 with G.M; the UAC2 volume maximum is 0 dB;
  - **production:** P-1…P-7.

# R9 fixes — 25 Sep 2026

Binding: `r9/decisions_r9.md` E-1…E-15 (digital: E-2 firmware re-arm, E-9 lead, E-10, E-11 with protection, E-12, E-5 firmware items) and `r9/reviews_r9.md`. Numbers: `firmware_sequences_output.txt` §2, §13–§17 and `adc_settings_output.txt` §9 [CALC]. Digital netlist changes: **U201-26 PB0 = N6_ARM_MCU** (E-2) and **U201-3 PC14 = N5_U102_OFF** (E-16). No digital part or value changed. U301 GPIO1 stays unconnected and is used only through I²C.

| Item | Action | Result | Evidence |
|---|---|---|---|
| **E-10** (R9-A3) GPIO2 = lock only | GPIO2 = DPLL lock **permanently**. **reg 8 = 0x12** from init: gpio2_cfg 1 = lock, gpio1_cfg 2 = minimum volume on the unconnected GPIO1 (pin 24). **The ES9018K2M reg 64 has no minimum-volume bit** (reg 64 = revision, chip_id, automute_status, lock_status [DS]), so the flag is read as **reg 65 bit 0 (GPIO1 pin status)** over I²C, back-to-back 0.39 ms reads. | Suspend ≤ **8.45 ms** after the last SOF (margin 1.55 ms), with the deadline 5.31 ms after the last SOF unchanged (DX-1). Rate/family change worst 872 ms. The OD-2 EXTI no longer needs masking for GPIO reconfiguration. The self-test uses 0x72/0xF2/0x12 and checks reg 65 b0 = 1 while muted. **[MEAS] at bring-up:** reg 65 reflects an *output*-configured GPIO1 (the ESS text describes reg 65 for input mode). If it does not, the wait uses the computed ramp time (128 dB / (0.25 fs) × 1.1) under the same deadline, so the suspend bound still holds. | fw §2, §4, §14; ESS DS reg 8/64/65 |
| **E-11** (R9-A9) R665 330 Ω | X201 load recomputed with the **full** tap count at the 74AUP1G17 CI bound (2.4 pF incl. pads, no effective-C credit). The old 13.1 pF excluded the tap; XI 10 pF is the ESS maximum. | **With the layout rule "X201 → R203 → XI ≤ 10 mm, R665 at the XI pin, R665 → U607 ≤ 3 mm", the load is 14.2 pF ≤ 15 pF** (XI 10 + trace 1.3 + pads 0.5 + tap 2.4; margin 0.8 pF). XI pulse widths stay ≥ 5.49 ns against 4.5 ns (margin 0.99 ns). Without the rule (20 mm) it would be 15.5 pF, so **the rule is mandatory for 330 Ω.** **Protection ADOPTED R665 = 330 Ω with this rule.** The U607 swing holds at the Kyocera 4.5 ns edges (+141 mV to VT+max at 2.4 pF, +260 mV typical; −380 mV with 1 k), and MCLK-alive detection is unchanged (a static input reads dead ≤ 0.452 ms). Protection owns R665. | clock_timing §4 (re-run) |
| **E-12** (R9-A10) engine reset across U205 | New RTL bit **ENGINE_RST** in the SPI register domain. It is asserted asynchronously into the FAM_CLK domain (I²S engine, divider, FIFO read side) before the mux switch, and released through a 2-FF synchroniser ≥ 2 µs after it. Register settings are kept. Fallback without the RTL bit: CPLD_NRST (PC5) ≥ 1 ms around the switch plus a full register rewrite. | Any runt FAM_CLK pulse at the U205 switch hits only flip-flops held in reset. The switch is already open (section 4), and the time added is < 0.1 ms. | fw §16 |
| **E-9** (R9-C1, lead) canonical power-down order | One table with steps S1–S8: mute → RELAY_EN low + 1.1 ms → reg 14 ramp + 1.1 ms → MCLK off → PA8 high + link pins low → **AVCC_EN and AUD_EN low in one GPIOC write**, wait ≥ 0.53 ms → ANA_EN low → ILIM_HI/LEDs (and Stop in suspend). Power's corrections are in:
  - discharge bounds: 3V3A < 0.1 V ≤ 0.472 ms with C440 (if C441 is fitted the wait becomes ≥ 0.75 ms); 3V3D < 0.1 V ≤ 0.63 ms, covered by the ≥ 1 ms re-enable rule;
  - "DVDD ≤ DVCC throughout" replaces "DVDD first": U303 regulates for about 90 µs, then reaches UVLO, and Q506 finishes;
  - **brown-out ISR: RELAY_EN (GPIOA), then AVCC_EN + AUD_EN in one GPIOC write**, no wait (power c14 case b; this replaces R2.5 H.1's RELAY_EN + AVCC_EN only);
  - MCU-reset row: Q502 → N5_DIS_A → Q503 added (3V3A discharge). Each exit is mapped: host stop, suspend, rate/family, fault, brown-out, unplug, I²C double fault, MCU reset/IWDG (hardware-defined) and programming-mode exit (by reset). | AVCC_EN and AUD_EN are commanded together, and U605B/Q620 force AUD_EN low ≤ 1.04 ms after 3V3A < 3.006 V in any case. So the order is hardware-enforced where it matters, and every document can cite this one table. **Power confirmed its rows (with the corrections above). Analog confirmed S1–S7:** at 300 Ω, S1/S2 give no step, S3 0.126 mV, S6 0.23 / 1.46 mV (3 / 22 % mismatch), and S7 is negligible, so **every controlled exit is ≤ 1.46 mV**. One condition, a bring-up [MEAS]: S4/S5 are step-free only if the ESS ramp ends in the reset (ground) state, which ESS does not publish. With the switch open, leg DC before and after PA8 high must differ by < 10 mV; if not, S5 moves after S6 (firmware only). The MCU-reset row can pass a click up to the reset-state leg voltage (0.05–0.34 V) before the switch opens. That is L-4, listed by analog as a fault case for the owner. The suspend bound is unchanged at 8.45 ms (8.67 ms if C441 is fitted). | fw §15 |
| **E-2** (R9-B1) firmware re-arm | Protection's latch is U608 74LVC1G74 on 3V3D; any trip clears it, and only a RELAY_EN rising edge sets it. **PB0 is netted as N6_ARM_MCU** (input, no pull; readback through R695 100 k; high = armed). Firmware after ANY trip, including the soft-start CM trip and every self-test trip: RELAY_EN low (≥ 1 ms; the latch needs only ns) → **DC_PERMIT_N low continuously ≥ 150 ms** (H may need ≤ 80 ms after DC_PERMIT_N goes low to pass HREF 3.11 V; this replaces the pre-close 50 ms) → full pre-close checks → a fresh RELAY_EN low → high edge → **PB0 high within 1 ms**. Otherwise RELAY_EN low and retry after 20 ms, at most 3 tries, then fault. After each self-test trip PB0 must read low, which tests the clear path. | A static-high RELAY_EN (hung MCU) can never re-arm the latch. **Power-up close moves from 440.8 to 540.8 ms, and the worst rate/family change from 872 to 972 ms** (150 ms instead of 50 ms, applied conservatively). MCU GPIO: 47 used; the spares are PC14 and PC15, which can take power's option (a) gate if chosen. Protection runs the bring-up test (trip pulses with RELAY_EN held high → the switch stays open). Protection confirmed: only PB0 is needed; E-3 adds no ADC tap or readback net (its outputs drive N6_H and show on DC_PERMIT_N), and the boot self-test (e) checks it. | fw §3, §4, §18; netlist U201-26 |
| **E-16** (owner: suspend power cut) | **PC14 (pin 3) = N5_U102_OFF** (power: Q507 MMBT3904 NPN base via R537 100 k, R538 100 k base–emitter; AO3400A version superseded), push-pull. High = U102 off; low or floating (reset) = U102 on. U502 is now a TPS70933 on VBUS, so 3V3M no longer depends on U102. PB0 is used by E-2, so PC15 is the only spare. **Suspend: S1…S8, then S9: U102 off at S7 + 0.1 ms (power: nothing has to decay first) → Stop.** After that, 5V_SYS falls about 12 mV/ms and U503 keeps VIN > VOUT; any later reversal is clamped by D105 at ≤ 0.24 V (X-4). **Resume (R0), before any domain:** IWDG short → clocks/USB on 3V3M → PC14 low → 5V_SYS good (VBUS_SENSE ≥ 4.0 V for 5 ms, **timeout 60 ms** → fault, USB-only) → arm the AWD → power-up B. **While U102 is commanded off, VBUS_SENSE (~0 V) is ignored:** the AWD is disarmed and there is no unplug action. A real unplug takes VBUS from U502, so the MCU goes through PDR → reset. | **Attach:** the MCU boots on 3V3M (VBUS) before U102 is on, so VBUS_SENSE = 0 in early boot is ignored. The AWD is armed only after 5V_SYS good (≥ 4.0 V for 5 ms, 60 ms timeout), and the D+ pull-up does not wait for it. **TSIGATT improves to ≤ 23.9 ms** (was 79.2 ms; limit 100 ms), because the MCU no longer waits for U102. **USB current reaches the suspend level ≤ 8.75 ms after the last SOF** (S7 8.35 ms + 0.1 ms + U102 tOFF ≤ 0.3 ms; limit 10 ms, margin 1.25 ms). Stop is entered at 8.55 ms. Resume: USB answers on 3V3M in 5.28 ms; U102 is on ≤ 55.3 ms after release; B starts ≤ 65.6 ms after the wake. Suspend share: +3.34 µA (PC14 into R537). **Brown-out (power fact):** the 4.00 V trip is ratiometric to 3V3M and is guaranteed while the 3V3M load is ≤ 50 mA (MCU typical 22 mA). On the 80 mA planning value the TPS70933 can drop out below VBUS ≈ 4.25 V and the trip is then not guaranteed. The unplug stays compliant without firmware (X-8). Qualification [MEAS]: 3V3M ≤ 50 mA in S3. **The VREFINT cross-check is NOT adopted, because the ADC scan budget breaks:** the 9-slot scan leaves only 9.5 µs idle per 50 µs, and a VREFINT conversion needs ≥ 17 µs of sampling [ASSUMP, STM32F1-class; WCH value not retrieved]. Each read would drop one protection scan and break the exact 20 kHz / 20-scan DMA blocks; the T3 timing itself would hold. **Adopted instead (firmware only):** the PVD on 3V3M at its highest level (≥ 2.9 V [ASSUMP]) → EXTI16 → the same brown-out ISR. It fires when U502 drops out, i.e. at 5V_SYS ≈ 3.5–3.9 V instead of 4.00 V, so a brown-out is always handled while the MCU still regulates. The AWD stays exact while 3V3M regulates, and the PVD is off in Stop. 3V3M is 3.207–3.343 V, so the ADC counts scale with it (power c09). | fw §15 (S9, R0), §19; netlist U201-3; currents S6 |
| **E-5** (firmware items) suspend | Pin and peripheral states in Stop: PA8 high, pulls idle, link pins low (U208 Ioff), I²C released, PB8 Hi-Z, spares analog, ADC/TIM4/PVD/VREFINT off, PHY suspended. | **Digital adds 0 A beyond the 1.9 mA MCU planning value, plus 4.5 µA for the DX-2 wake.** No further firmware saving exists. VBUS divider options: power **rejected ×1.5**, because its c09 band leaves only about +2 mV at the 4.40 V / J101-drop corner. It did not choose the switched divider (FET, gate from PB0, saves about 37 µA, S6 2.472 mA), which still does not reach 0.2 mA. **Owner decision (from power): option (a) switched divider vs option (b) suspend power cut.** PB0 is kept free and not netted. | fw §17; adc §9 |

- Owner decisions: none needed from digital. E-16 (suspend power cut) is adopted by the owner and implemented on PC14. E-17 (Default-mode acceptance: production test S3 ≤ 480 mA, S1 ≤ 90 mA, R509 4.84 k on a failing board) is referenced; it has no digital change. E-10's reg 65 path and E-11's 10 mm MCLK rule are bring-up and layout items. The ENGINE_RST bit is an RTL requirement for the owner's CPLD code; its fallback needs no RTL.
- Firmware constants changed: reg 8 = 0x12 (was 0x10, with 0x20 during mute waits); the minimum-volume poll uses reg 65 bit 0.
- `check_design`: see the final line in fix_progress. The net name is N5_U102_OFF, as in power's netlist (Q507 gate, R537 1 M).

# OD-1/OD-2 (owner decisions) — 25 Sep 2026

Binding: `ve/brief_od.md`, decisions_r8c DZ-11 (OD-1 stricter stream check) and DZ-12 (OD-2 DAC lock-status check). Firmware only; no hardware change. Protection owns the OD-1 rule and all energies; digital implements both and gives the detection times. Numbers: `firmware_sequences_output.txt` §13 (guards) and §14 (OD-2) [CALC].

## OD-2 — DAC plausibility check (implemented)
- **(a) Lock interrupt.** DAC_LOCK (U301 GPIO2, reg 8 = 0x10 = DPLL lock status) on PC9 drives EXTI9 on the falling edge, at priority 2 (after DC_PERMIT_N) while streaming. A 20 µs confirm re-read of PC9 rejects glitches. RELAY_EN goes low ≤ 30 µs after the edge, so the **switch is open ≤ 1.04 ms** after GPIO2 falls. ESS does not publish its internal lock-loss latency.
- **(b)/(c) Poll A, every 10 ms** (2.67 ms): burst read of reg 64–65 plus the full reg 0–20 read-back against the firmware's shadow copy. Checks:
  - lock_status = 1;
  - automute_status = 0 (automute stays disabled, reg 4 = 0x00);
  - chip_id = 4;
  - GPIO2 pin level (reg 65 bit 1) = PC9 = lock, a cross-check of the pin and its trace;
  - every register in reg 0–20 matches the shadow copy, including the reg 14 = 0xAA sentinel (reset default 0x8A), so a DAC reset, brown-out or any register corruption shows up at the next poll.

  Any failure, including a NACK (one retry), leads to a confirm re-read. **Switch open ≤ 16.45 ms**; with the bus stuck low (1 ms timeout, then 9-clock recovery) ≤ 17.45 ms. The full read-back moved from 100 ms to 10 ms because a 106.8 ms mismatch detection would be slower than the leg windows (69 ms) and add nothing.
- **(d) Poll B, every 100 ms** (0.66 ms): the DPLL ratio (reg 66–69) within ±0.1 % of FSR × 2³²/80 MHz. A confirm re-read follows any failure. **Switch open ≤ 102.4 ms.** A DPLL_NUM that stays bit-identical over 5 reads is logged as an advisory only; bring-up data [MEAS] decides whether it becomes a trip.
- **Bus and CPU:**
  - I²C load is 27.4 % at 100 kHz. The analog noise floor with polling active is a bring-up [MEAS]; the fallback is a 20 ms poll period, which roughly doubles the times.
  - Host volume writes queue behind a poll (≤ 2.67 ms).
  - Priority writes (suspend mute, fault) abort a poll at the next byte boundary (≤ 0.1 ms). The DX-1 suspend numbers are unchanged, because the deadline is anchored to the last SOF.
  - CPU load is < 0.3 % (interrupt-driven).
- **Masking:** the check is masked from start-up until the first closure, during rate and family changes, and during suspend. In those phases GPIO2 is switched to the minimum-volume flag for the mute waits, and the switch is open or being opened.
- **Action:** RELAY_EN low, log, I²C 9-clock recovery, PA8 high ≥ 1 ms (DAC reset), full re-init, lock, pre-close checks, re-close. Each event counts as a strike (3 in 10 s → locked until replug).
- **Self-test at every start** (switch open, after the first lock; 2.3 ms): reg 8 = 0x70 (GPIO2 driven low) → PC9 = 0 and the EXTI9 flag is set. reg 8 = 0xF0 (driven high) → PC9 = 1. reg 8 = 0x10 → PC9 = reg 64 bit 0 = 1. Any failure → no RELAY_EN.
- **False-alarm risk (low):**
  - In normal streaming the CPLD keeps BCLK/LRCLK running from FAM_CLK (a FIFO underflow outputs zeros, not a clock stop), so the DPLL stays locked. Rate changes and stream stops are masked.
  - Glitches are filtered by the 20 µs confirm and by the NACK retry or re-read before any trip.
  - A false trip costs a dropout and a re-init of about 0.5–1 s. It is never unsafe.
- **Coverage:** DPLL unlock (a, b); DAC I²C dead or bus stuck (c); DAC reset, brown-out or register corruption (b); DPLL ratio wrong (d).
- **Energies (protection p15):**

  | Detected case | Switch open | 32 Ω balanced | 16 Ω balanced |
  |---|---|---|---|
  | Lock lost (EXTI) | ≤ 1.04 ms | 0.59 mJ | 0.59 mJ |
  | Poll, at protection's first-message time | 12.01 ms | 6.89 mJ | 6.94 mJ |
  | Poll, scaled to the final ≤ 17.45 ms [CALC, linear] | ≤ 17.45 ms | ≈ 10.0 mJ | ≈ 10.1 mJ |

  Limits are 15 / 30 mJ, so all cases are within them. Protection re-runs p15 with the final times.
- **Residual (documented limitation):** a DAC-core hang that keeps lock_status = 1 and still answers I²C with the correct registers. Only the leg windows cover it (protection: 39.6 / 25.9 mJ at 16 / 32 Ω). **Protection computes the energies for the detected cases from the times above.**

## OD-1 — stricter stream check (implemented; the rule is protection's, p15)
- **Rule, identical in both guards, per channel, every rate:**
  - **P1 (new):** every sample of the last **22.0 ms** (N = ceil(0.022 × fs): 971 samples at 44.1 kHz, 8448 at 384 kHz) is ≥ +0.30 FS, or every sample is ≤ −0.30 FS. The exposure is 22.0 + 0.60 + 1.008 = **23.6 ms ≤ 24 ms**, protection's energy basis. A run counter resets on any sample inside ±0.30 FS or a sign change. It is computed per block from the block min/max (shared with P3); when a block does not fully qualify, a backward scan gives the exact trailing run, so the rule is sample-exact.
  - **P2:** CIC² of two 50 ms means, **|D| ≥ 0.25 FS** (protection final; was 0.30).
  - **P3:** 26 ms flat, range ≤ 1e-3 FS and |mean| ≥ 0.02 FS (unchanged).
  - **P4 (new):** CIC² of two 150 ms means (N = 0.15 × fs), **|D| ≥ 0.15 FS**. P2 and P4 run as running sums of 0.5 ms block values: 100 and 300 blocks. Stage 1 is exact; stage 2 is sampled per block, a ≤ 0.5 ms difference inside the 1 ms latency. RAM is 6.2 KB per guard (12.5 KB for both). P4 adds no per-sample CPU work.
  - **Action:** the USB-side guard zeroes the pair with a 1 ms ramp and logs. The post-CPLD guard sets **RELAY_EN low** (switch open ≤ 1.008 ms), zeroes and logs; re-close only through the pre-close sequence, and it counts as a strike.
- **Decision latency** (protection limit ≤ 1 ms): post-CPLD ≤ 0.60 ms (0.5 ms DMA half-blocks, was 1 ms), USB side ≤ 0.225 ms (per microframe). The P1 trip therefore comes ≤ 22.6 ms after a one-sided ≥ 0.30 FS run starts at the guard input.
- **CPU load at 384 kHz:** 4.8 % typical / 6.7 % worst per guard, **9.6 % / 13.3 % for both** of 144 MHz [ASSUMP cycles per frame; P1 worst includes the backward scan]. At 192 kHz it is 4.8 % / 6.7 %. Capture DMA is 1.536 M half-words/s.
- **Content boundary** (protection p15):
  - A full-scale sine never triggers above 18.3 Hz; at 20 Hz the longest run is 20.15 ms < 22 ms, with any phase and onset.
  - **A square wave of ≥ 0.30 FS amplitude below 22.7 Hz, or one-sided content ≥ 0.30 FS held for 22 ms (e.g. a large DC offset), mutes. The owner accepted this (DZ-11).**
  - **With the final P2/P4:** content whose running mean reaches ≥ 0.25 FS over the 2 × 50 ms CIC², or ≥ 0.15 FS over the 2 × 150 ms CIC², also mutes, i.e. a sustained DC offset of ≥ 0.15 FS mutes within ≤ 0.3 s. Full-scale sines ≥ 20 Hz stay far below both thresholds (the 150 ms boxcar has a null at 20 Hz; ≤ 0.01 FS between nulls). Protection states the exact boundary in its p15/§10.
- **Energies** (protection final rule, worst over every DC level and content): **13.8 mJ at 32 Ω balanced (limit 15 mJ), 25.3 mJ at 16 Ω balanced (limit 30 mJ), 3.6 / 6.9 mJ single-ended.** The previous wide-content case (DC 0.2–0.65 FS plus a loud 20 Hz tone, 15.0/30.1 mJ) is closed by the P2 threshold change and P4.
- The 352.8/384 kHz post-CPLD capture still depends on the I2S2 slave at 24.6 MHz BCLK (bring-up [MEAS]; R-5 residual if not).

# VE (value engineering) — 25 Sep 2026

Binding input: `ve/brief_ve.md` (owner decisions O-1…O-4). Digital blocks only; the parts stream owns the fee model, the owner-fitted list and the final stock/class check. Prices are LCSC/distributor unit prices on 25 Sep 2026. Per-order figures are for the exact 5-board quantity (O-1). Attrition is left to the parts stream's rules.

| # | Candidate | Verdict | Saving per board / per 5-board order | Checks re-run |
|---|---|---|---|---|
| 1 | **U208 Nexperia 74LVC3G34DC,125 (C548774, US$ 0.7647) → TI SN74LVC3G34DCUR** (LCSC **C130024**, Extended, 550 in stock, US$ 0.2012 at 5+, min/multiple 5; MSL1-260 °C [TI]) | **Adopted** (drop-in, same VSSOP-8 land) | **US$ 0.56 / ≈ US$ 2.8** (depends on attrition; the LCSC multiple is 5) | Pinout identical to Nexperia: 1 1A, 2 3Y, 3 2A, 4 GND, 5 2Y, 6 3A, 7 1Y, 8 VCC [TI SCES366L pin table]. tpd 1.4–4.1 ns at 3.3 V ± 0.3 V, −40…85 °C [DS] against Nexperia's 0.5–4.1 ns, so the skew bound falls from 3.6 to 2.7 ns. 36 MHz link margins: **setup +2.03 ns, hold +5.20 ns** (were +1.13/+4.30); the Nexperia part stays an approved alternate at +1.13 ns. 9 MHz read loop +36.6 ns, unchanged (tpd max 4.1 ns). Ioff ±10 µA (Nexperia ±2 µA): no back-power with 3V3D off; source pins are low before AUD_EN falls anyway. ICC ≤ 10 µA (+6 µA on 3V3D in S2–S5, 0 in S6). `clock_timing`, `currents` and `gen_netlist_bom` re-run: U208 2.530 mA at 384 kHz. |
| 2 | X201 Kyocera KC2520K80 (global, US$ 1.39) → an LCSC-stocked 80 MHz part | **Rejected (kept)** | — | The D-3 search (parts Follow-up 3) found no LCSC 2520 80 MHz part with oscillation-stop stand-by, ≤ 8.2 mA and tr/tf ≤ 4.5 ns. SCTF SX3M80 draws 40 mA and is not approved; TXC 7X has output-disable only; Epson SG-210STF is end-of-life. |
| 3 | X202/X203 NDK NZ2520SDA (global, US$ 2.00 each) → Kyocera KC2520K49.1520C1GE00 / KC2520K45.1584C1GE00 (same family and land as X201; ≤ 6 mA loaded at 3.3 V, stand-by ≤ 5 µA, tr/tf ≤ 4.5 ns, t_sta ≤ 2 ms, ±50 ppm [Kyocera spec TNY1T-H1-SEE01-06]) | **Rejected: not procurable** | (would be about US$ 1.2 and −9 mA on 3V3D in S3) | Technically better than the NDK on every clock-timing check: ≤ 6 vs ≤ 15 mA running, 5 vs 35 µA stand-by. Its jitter (5 ps 1σ) is irrelevant because the ES9018K2M runs asynchronously from X201. But Octopart shows **no authorized distributor for 45.1584 MHz**, and 49.152 MHz only as a broker contact. Recommended as a future option if a distributor lists it. |
| 3b | X202/X203 → SiTime SiT8008BI 2520 "S" (stand-by) versions | **Rejected** | — | LCSC lists only other variants (2016/1.8 V, out of stock). SiTimeDirect costs US$ 3.54 at 1 piece, more than the NDK. |
| 3c | X202/X203 → SCTF SX3M49.152/45.1584 (LCSC stocked) | **Rejected** | — | Output-disable only (both run, +25 mA; the Default budget fails, D-4), and 3225 does not fit the 2520-only land (X-10). |
| 4 | U205 Nexperia 74LVC1G157GW (US$ 0.21) → TI SN74LVC1G3157DCKR (C38663, US$ 0.06) | **Rejected** | — | It is an SPDT analog switch, not a buffered logic mux. Con 17.3 pF plus the CPLD pin puts about 25 pF on the running NDK (limit 15 pF). |
| 5 | Owner-fitted digital parts (O-4) | **None qualify** | — | U201 is LQFP-64 at 0.5 mm pitch (< 0.65 mm). U202 is QFN. X201–X203 are 4-pad LGA (leadless). U208 is VSSOP at 0.5 mm. U205/U206 (SOT-363) and the LEDs would qualify but cost ≤ US$ 0.21, so owner fitting brings no benefit. |
| 6 | **Economic PCBA checks for the parts stream (O-2)** | **Information** | — | **U202 AGRV2KQ32 is QFN-32 at 0.40 mm pitch, exactly the Economic minimum ("at a process limit"),** and cannot be owner-fitted. I did not search for a leaded AGRV2K package, which would be a circuit change (RTL pin constraints). Known reflow ratings: TI U208 260 °C (MSL1); Kyocera X201 260 °C × 2; NDK X202/X203 265 °C (B-13). **Not verified here:** CH32V307RCT6 (MSL3), AGRV2KQ32, Nexperia U205/U206, YXC Y201, KENTO D705/D706, AO3400A (the parts stream's check). |

- **Total digital VE saving:** US$ 0.56 per board, about US$ 2.8 per 5-board order. Fitted digital parts cost falls from US$ 12.07 to **US$ 11.51** per board (`gen_netlist_bom_output.txt`). The number of Extended types is unchanged, because both U208 parts are Extended.
- Every limit still holds: link timing (better), Ioff/domain crossing (X-7), 3V3D budget (+6 µA, and power's S3 figure already used 2.52 mA dynamic for U208), and the suspend budget (0 A, 3V3D off).
- BOM/netlist: U208 row changed; the netlist changes only in its notes (same pins and nets). Backups: `*_r3_backup.*`.
- **Follow-ups from power's VE changes (11:10):**
  - (1) **ANA_SENSE divider now 100 k/47 k:** the firmware fault threshold is **1.279 V at PA0 = 1587 counts** at VDDA 3.30 V (5V_ANA_F 4.0 V), the same divider and code as VBUS_SENSE. The source is 32.0 kΩ (32.3 kΩ at +1 %) against the WCH limit of 43.5 kΩ at TS 41.5, so settling is OK. With C516 100 pF, the sample kick leaves a 2.7 % residual of ΔV at the end of the sample: 1.4 mV in operation, 9.1 mV at the threshold (28 mV at 5V_ANA_F, reads high). The node recovers fully before the next scan (14 τ) [CALC, `adc_settings_output.txt` §3]. Updated in the netlist note, the firmware constants and R3.2.
  - (2) **TSIGATT with U102 on 3.3–55 ms:** the D+ pull-up is enabled **≤ 79.2 ms after VBUS valid** (limit 100 ms, USB 2.0 7.1.7.3), a margin of 20.8 ms [CALC on ASSUMP]. The chain (`firmware_sequences` §4a):
    - 5V_SYS up ≤ 55.3 ms (power c20 b);
    - TPS7A20 1.15 ms;
    - NRST RC 1.34 ms;
    - CH32V307 POR/boot load ≤ 10 ms [ASSUMP, as power];
    - 5.2 ms low-clock phase;
    - HSE ≤ 4 ms and PLL ≤ 0.2 ms [DS];
    - USBHS PHY 1 ms and USB init 1 ms [ASSUMP].

    Firmware rule (R3.2 A): the D+ pull-up is enabled right after the USB init. The 100 ms CC classification window runs in parallel and gates only the High mode. **The largest U102 switch-on (5V_SYS-up) delay digital can accept is 71.1 ms**, keeping a 5 ms margin.


# R8 review fixes (round 3) — 25 Sep 2026

Binding inputs: `integration/decisions_r8c.md` X-1…X-10 plus its firmware rules and limitations L-1…L-7 (with `decisions_r8b.md` D-1…D-19). Review evidence: `review/review_states.md` #6, #9, #11, #17, #20, #21, #23, #26, #27, #31, #32 and `review/review_pins_b.md` B-05, B-09, B-16. This section replaces round-2 numbers where they differ. Round 2 (R2.x) and round 1 (§0–§16) below remain as the record. Where they conflict, this section wins. Labels are as before: [DS], [DS-typ], [CALC], [ASSUMP], [MEAS]. Progress log: `fix_progress.md`.

## R3.0 Changes (netlist/BOM regenerated by `gen_netlist_bom.py`; all checks pass)

| # | Change | Decision / finding |
|---|---|---|
| 1 | **U208 Nexperia 74LVC3G34DC,125** (LCSC C548774, VSSOP-8, SOT765-1; 1,604 in stock, US$ 0.7647). It runs on **3V3D** with **C224 100 nF** at pin 8 and sits next to U202. Pins [DS Rev 16 §6.1]: 1 1A = N2_LINK_SCK_BUF, 2 3Y = LINK_FRAME, 3 2A = N2_LINK_MOSI_BUF, 4 GND, 5 2Y = LINK_MOSI, 6 3A = N2_LINK_FRAME_MCU, 7 1Y = LINK_SCK, 8 VCC = 3V3D. IOFF is ±2 µA with VCC = 0 V, inputs tolerate 5.5 V, and tpd is 0.5–4.1 ns (3.0–3.6 V, −40…85 °C) [DS]. On the MCU side: PA5 = N2_LINK_SCK_MCU → R224 33 Ω → 1A; PA7 = N2_LINK_MOSI_MCU → R225 → 2A; PA4 = N2_LINK_FRAME_MCU → 3A. On the CPLD side, pins 9/10/11 are LINK_SCK/LINK_MOSI/LINK_FRAME. N2_SCK_CPLD and N2_MOSI_CPLD are retired | X-7, states #17 |
| 2 | **Q207 AO3400A** (C20917, Basic; same part as Q502–Q506, Q616 and Q617): pin 1 G = N2_RESET_DRV (MCU PA8), 2 S = GND, 3 D = DAC_RESETB. **R240 100 kΩ** from N2_RESET_DRV to 3V3M. **R233 retired.** DAC_RESETB is now open-drain, and the analog stream's R305 10 kΩ pull-up to DVCC is already in `analog/netlist.csv`. **Polarity: PA8 low = DAC released. PA8 high or floating (MCU reset) = DAC in reset** | X-7, states #17/#26 |
| 3 | **R236 10 kΩ** AVCC_EN → **N2_AVCC_EN_G** = U206 input B (pin 3). **R237 4.7 kΩ** PC10 = **N2_AUD_EN_MCU** → **AUD_EN**. U605A/U605B (protection) pull these nodes low while 3V3A is not good. Sink currents are 0.35 mA and 0.74 mA. With R508 10 kΩ (power), AUD_EN sits at 3.3 × 10/14.7 = 2.24 V min at PC10 VOH ≈ 3.3 V (power quotes ≥ 2.21 V), above TLV767 VEN(HI) 1.2 V and Q504 VGS(th) 1.45 V | X-6, states #15/#18/#27 |
| 4 | **PB8** freed by X-1 (RAIL_EN deleted, LM27762 EN± tied to VIN; RAIL_EN is a retired net, checked by an assert). It is now **N6_V13_TEST**, the protection's 1V3-good test injection (open drain, Hi-Z by default, through D610). **PA12 = N6_V3AG_A_MCU** and **PB9 = N6_V3AG_B_MCU** are U605 3V3A-good readbacks through R688/R689 470 kΩ (inputs, no pull). All three are protection requests | X-1, protection R3.9 |
| 5 | **PA0 = ANA_SENSE** (ADC_IN0) is appended as ADC2 slot 9 of 9. ADC1 converts IN1 in all 9 slots, so the VBUS_SENSE channel still never changes. The 9-slot scan takes 40.5 µs of the 50 µs TIM4 period, which keeps 20.000 kHz per channel (`adc_settings_output.txt`). Source ≤ 40 kΩ with C516 100 pF (power): WCH rule TS ≥ 41.5 cycles, met. The previous slot (RN ≈ 1.61 V) matches ANA_SENSE (≈ 1.62 V at 5 V) in operation. In a 5V_ANA_F collapse the sample-cap kick reads about 40 mV high at 5V_ANA_F scale, which is negligible against the 4.0 V fault threshold (1.279 V at the pin with power's VE divider) [CALC, estimate]. The source is now 32.0 kΩ (100 k/47 k), within the WCH limit of 43.5 kΩ at TS 41.5 (`adc_settings_output.txt`) | X-5, states #16 |
| 6 | **R238 10 kΩ** CPLD_JTMS → N2_V33_CPLD, and **R239 10 kΩ** CPLD_JTCK → GND, both at U202. N2_V33_CPLD is 3V3D after FB202, the CPLD's own VDD33, which is the X-10 "3V3D". The probes drive ≥ 4 mA, so they override 10 kΩ | X-10, states #31, B-05 |
| 7 | **J201 pin 1 = N2_J201_3V3** through **R241 0 Ω DNF** from 3V3M (C17168). Note: never connect the WCH-LinkE 3V3 lead | X-10, states #32 |
| 8 | **U206** is the 6-pin SOT363-2 part in every list: 1 A, 2 GND, 3 B, 4 Y, 5 VCC, 6 C (B-16). The report text below that says "SOT-353" is superseded. Parts stream: add U206 to `layout_package.md` §14 (interface request) | X-10, B-16 |
| 9 | **X201/X202/X203 use 2520-only lands** (BOM package text). The SCTF 3225 parts have no land and are not placeable | X-10, B-08 |
| 10 | **LED pad polarity: NOT confirmed.** The KENTO KT-0805G (C2297) and KT-0603R (C2286) drawings could not be retrieved: LCSC serves them only through a cookie-gated viewer, and this shell has no internet. The netlist keeps pad 1 = K (EasyEDA convention) and marks it unconfirmed. **B-09 stays open**: overlay the drawings and add a cathode bar on the silkscreen before layout | X-10, B-09 |
| 11 | **Designator outside the allocation:** **C224** (U208 decoupling) is in the digital C2xx range, and no other stream uses C2xx | — |

BOM (after the DZ changes in R3.6): 31 lines, 77 fitted refs (74 components + 3 pad groups), 3 DNF (J703, R703, R241), 262 SMT joints, US$ 12.07 fitted. Netlist: 276 pin rows, 75 parts, 83 nets. MCU GPIO: **46 used, 3 spare (PC14, PC15, PB0)**. PA0, PA12, PB8 and PB9 are now used. Netlist: 286 pin rows, 80 parts, 91 nets (after R3.6). Backups of the round-2 files: `*_r2_backup.*`.

## R3.1 Link timing with the buffer (`clock_timing_output.txt` §3/3a)
- **Writes at 36 MHz** (SPI mode 0, CPLD samples on SCK rising). SCK and MOSI take identical paths: 33 Ω, matched traces, two channels of one U208, then ≤ 5 mm to U202. Only their skew matters. Nexperia gives no channel-to-channel skew, so I bound it by the tpd range, 4.1 − 0.5 = 3.6 ns. With 45 % duty, MOSI valid 5 ns after the falling edge [ASSUMP], and CPLD setup/hold needs at the pins of 2.67/4.50 ns [DS TIN + ASSUMP FF/clock-tree], the margins are **setup +1.13 ns and hold +4.30 ns** [CALC, worst-case bound]. The common ≤ 4.1 ns delay moves SCK and MOSI together. FRAME changes ≥ 100 ns away from any SCK edge.
- **Reads at 9 MHz**: the loop now includes U208 (4.1 ns), and the margin falls from +40.7 to **+36.6 ns**. There is still no MISO data at 36 MHz.
- Bring-up [MEAS]: the 10¹⁰-bit link BER test (§9.2). The fallback is the RTL option to latch MOSI on the falling edge, because 18 MHz cannot carry 384 kHz.

## R3.2 Firmware requirements per state — replaces R2.5 where it differs
[HW] = hardware enforces or backs up the rule if firmware fails; [FW] = firmware only. Numbers are from `firmware_sequences_output.txt` [CALC].

As-built supervisor mapping (protection R3.15). The decision names are used in this section:
- "U605A" = U605 (TLV3402 on 3V3M) ch A + Q619 AO3400A on N2_AVCC_EN_G.
- "U605B" = U605 ch B + Q620 on AUD_EN.
- "U605C" (1V3 good) = U606 ch1.
- "U605D" (MCLK alive) = U606 ch2. U606 is a TLV1704 on VPOS/VNEG with its outputs on N6_H.
- U606 ch3 repeats 3V3A good onto N6_H.
- The sinks are FETs, so VOL ≤ 46 µV. IDSS ≤ 5 µA, which lowers AUD_EN high to ≥ 2.22 V.

**Always (every state)**
1. [HW] **Domain crossing:** U208 and U206 (IOFF) and Q207 (open drain) cannot drive the 3V3D/DVCC domain while it is off. The source pins can be high with 3V3D at 0 V and draw only ≤ ±2 µA IOFF. [FW] N2_LINK_*_MCU go low and PA8 goes high before PC10 falls (states #17).
2. [HW] **ESS order:** U605B holds AUD_EN low until 3V3A is good, and U605A holds U206 input B low (MCLK off, switch permit off) until 3V3A is good (X-6). **This is now hardware-backed** (states #27). [FW] Firmware still sequences AVCC_EN, then ≥ 1 ms, then PC10.
3. [HW, D-19] Any MCLK stop opens the switch through U206 Y → R645 → Q616. [FW] Keep RELAY_EN low ≥ 1.1 ms before any analog-state change, except in the brown-out ISR (R2.5 H.1, unchanged).
3a. [FW] (protection R3.9) The DC_PERMIT_N EXTI has the highest priority, and interrupts are never masked for > 1 ms. After any trip, RELAY_EN is **latched low** until the full pre-close sequence has passed; it then rises on a fresh edge. MCLK is never stopped for a rate or family change (permit recovery would add ≤ 205 ms).
4. [FW] **IWDG (DX-2):** **/4, RLR 239 → 960 LSI cycles (RLR + 1 convention, as protection R3.9) → 16.0–38.4 ms** (LSI 25–60 kHz [DS Tab 4-15]) whenever RELAY_EN may be high or any switched domain is on. That covers every run state: attach, configured, playing and programming. **Only in suspend** (RELAY_EN low, all switched domains off, MCU in Stop) is it lengthened to **/16, RLR 2499 → 40,000 LSI cycles = 0.667–1.600 s**. If WCH counts RLR × prescaler instead, both timeouts come out 0.4 % shorter, still inside the limits. The ≤ 40 ms maximum is met in every closed-switch state. A hung MCU is reset and the switch opens ≤ 39.4 ms, before the earliest hardware re-close at 53 ms (margin 13.6 ms, states #6). The main loop refreshes every ≤ 5 ms, and only when all tasks report alive.
5. [FW] **Overload rule (signal F8), one rule.** RAILS_OK_N is valid only after ANA_EN has been 1 for ≥ **T_START** (X-1: it was RAIL_EN). **T_START = 40 ms (DY-2):** power c18 gives rails good ≤ 18.8 ms after ANA_EN with C514 10 nF, and the I/V rails are final ≤ 1 ms later (analog), which leaves a 20.2 ms margin [CALC]. **Overload** = RAILS_OK_N high for ≥ 25 ms, or RAILS_OK_N high while ANA_FAULT_N is low, or **ANA_SENSE < 1.279 V at the pin for > 5 ms** after the start-up window. 1.279 V is 5V_ANA_F = 4.0 V with power's VE divider R535/R536 = 100 k/47 k, i.e. ADC code < 1587 at VDDA 3.30 V, the same divider and code as VBUS_SENSE. VDDA = 3V3M ±1.5 % moves the 5V_ANA_F equivalent to 3.94–4.06 V. **PGOOD dips < 25 ms with FLT (ANA_FAULT_N) high are headroom events: logged only, no action.** Overload → RELAY_EN low, then the controlled power-down (C.4 on), ceiling −3 dB per event, retry ≥ 1 s. The ANA_SENSE rule applies **in every state, including programming mode**, and ends with ANA_EN low (X-5).
6. [FW] vol_rate = 0 (reg 6 = 0x48) from init on. The ramp is 0.25 × fs dB/s [DS reg 6], so a full-range mute takes 11.6 ms at 44.1 kHz and 1.33 ms at 384 kHz.
7. [FW] **I²C ramp-to-ground (reg 14 = 0x03) at every power-down:** on NACK retry once. If both writes fail, take the **logged I²C-fault path. This is not a controlled transition, and the ≤ 5 mV pop target does not apply.** Order (analog): **MCLK off → PC11 (AVCC_EN) low → wait 3V3A < 0.1 V (V3A_MON; bound 0.35 ms, wait 0.5 ms) → PA8 high (RESETB low), link pins low → PC10 low**, then log. It takes 2.84 ms against 3.14 ms for the normal path, so the suspend bound is unchanged [CALC]. With X-6, U605B/Q620 force AUD_EN low once 3V3A < 3.006–3.125 V (release 3.052–3.168 V), ≤ 1.04 ms later (protection R3). DVCC/DVDD then collapse (analog: 75–240 µs after AVCC_EN low) while 3V3A may still be about 3.1 V. The timeline counts 0.53 ms after PC10 low either way. Analog's re-evaluated worst case (analog R3.6/R3.11, 25 Sep) is the reset step at VREF 3.10 V: **11.9 mV (22 % mismatch) / 1.9 mV (3 %) at 300 Ω**. The PA8-first order gives 12.9 / 2.1 mV, so this order is kept because it is never worse. The earlier 0.045 mV holds only if 3V3A decays first.

**A. Attach / enumeration (before SET_CONFIGURATION)**
1. [HW] Reset: ENs, RELAY_EN, ILIM_HI and MCLK_PERMIT float to their pull-downs (R508 10 k, R303, R513, R646, R511, R234). **PA8 floats → R240 → Q207 on → DAC in reset.** Switch open, X201 stopped, Default ILIM.
2. [FW] ≥ 5.2 ms on HSI at low clock. Then GPIO setup: PA8 **high**, link pins low, PB1 as floating input, PC13 pull-up. **PROG low is only latched here; it does not act before SET_CONFIGURATION** (J).
3. [FW] ADC: calibrate, then TIM4 20.000 kHz with the 9-slot dual scan (ANA_SENSE in slot 9) and AWD LTR 1587.
4. [FW] **Type-C classification** (states #11), on the CC with Rd, from 1-ms averages. Thresholds are 0.20 V (vRa), **0.66 V** (vRd-USB/vRd-1.5) and **1.23 V** (vRd-1.5/vRd-3.0). A reading > 2.3 V is invalid and treated as Default. The source ranges are vRd-USB 0.25–0.61 V, vRd-1.5 0.70–1.16 V and vRd-3.0 1.31–2.04 V, with Rd 5.1 kΩ ±10 % required. Source: **USB Type-C Cable and Connector Specification Release 2.0 (Aug 2019), table "Voltage on Sink CC Pins (Multiple Source Current Advertisements)"**, as reproduced in ST AN5225 Table 7, which cites R2.0 as its reference [22]. Rp and Rd come from AN5225 Tables 5/6. The USB-IF Release 2.5 (Apr 2026) is a zip-only download that I could not open here, so I could not check the table number in R2.5. The upward guard (50/70 mV) exceeds the 43 mV CC error, so a Default source can never read as ≥ 1.5 A [CALC]. A 1.5 A source exactly at 0.70 V may read as Default (safe side: no High mode). ILIM_HI stays low.
5. [FW] Enumerate UAC2 HS with one LED only. **The D+ pull-up is enabled right after the USB init, ≤ 79.2 ms after VBUS valid (TSIGATT 100 ms). It never waits for the CC classification.**

**B. Power-up after SET_CONFIGURATION** (`firmware_sequences` §3)
1. [FW] ILIM_HI goes high only if configured, a ≥ 1.5 A class has been stable ≥ 100 ms, and the switch is open or ANA_EN is low.
2. [FW] ANA_EN. The rails start with the TPS259621 dVdt ramp (X-1, power c11). Rails good means RAILS_OK_N low with ANA_EN = 1 for ≥ T_START = 40 ms (DY-2), ANA_FAULT_N high and ANA_SENSE ≥ 1.279 V (5V_ANA_F ≥ 4.0 V). AVCC_EN waits for this. Analog confirms (25 Sep) that N4_VPOS_IV/N4_VNEG_IV reach ≥ ±2.25 V within 0.5 ms after the main rails pass ±2.55 V, and their final value ≤ 1 ms after rails-good. T_START ≥ rails-good + 1 ms is therefore enough: 40 ms against ≤ 18.8 + 1 ms, so no extra wait is needed. RELAY_EN high comes at 440.8 ms (550.8 ms → 530.8 ms with the 100 ms CPLD timeout; `firmware_sequences` §3).
3. [FW] AVCC_EN, then ≥ 1 ms, then PC10 (hardware gate U605B). 3V3D rises only after 3V3A is good.
4. [FW] CPLD ID poll, family oscillator, then MCLK_EN/MCLK_PERMIT. **PA8 low (DAC released) ≥ 7 ms after the enable.** I²C init now includes **reg 6 = 0x48 (vol_rate 0)**. The rest is as R2.5 B.5–B.12.
5. [FW] **Boot self-test at every attach, before the first closure** (criteria: protection R3.9; `firmware_sequences` §12):
   - (0) U206/R234 via PB1: PB14 floating reads 0, MCLK_EN = 0 reads 0, all inputs high reads 1 (≤ 10 µs each).
   - **(a′) [R9, replaces (a)] old leg windows (protection p20):** digital DC ±0.39 FS per channel (0.869 V/leg, pair 1.74 V, below the E-3 V_L min 1.80 V). DC_PERMIT_N must go high 77–131 ms after the DC reaches the legs (pass 70–140 ms); at the −4.5 dB default trim use ±0.65 FS. **(e) [R9, new] E-3 detector:** +0.5 FS on L, then −0.5 FS (c+ and c− channels separately), then R. DC_PERMIT_N must go high 19.8–23.2 ms after (pass 18–26 ms); at the default trim use ±0.85 FS. Recovery after each run is ≤ 700 ms. Holding each DC for its full window would make the whole self-test ≤ 7.1 s. **R9 cut:** the digital DC is cleared inside the DC_PERMIT_N EXTI handler, so it is held only until the trip. (0), (d) and the PB0 clear-path reads run in parallel with the power-up and the trips. Total = 4 × 140 + 4 × 26 + 8 × R + 2 × 252 ms. With **R ≤ 209 ms** (protection p20: DAC removal ≤ 1 ms + comparator release ≤ 3 ms + H recovery ≤ 205 ms), **the whole self-test takes ≤ 2.84 s**, within the ≤ 3 s target. Protection's per-run bounds are a′ ≤ 209, e ≤ 207, b ≤ 208 and c ≤ 206 ms (H recovery from about VNEG ≤ 205 ms plus the stage delay). With these the sum is 2.75 s; the 2.84 s figure uses R = 209 ms and b/c = 252 ms throughout. Coverage is unchanged: every comparator channel and the clear path at every attach.
   - (a, R3, superseded by a′/e) Leg windows: digital DC +0.5 FS on L, then −0.5 FS, then the same on R (CPLD test register). With the stored calibration, DC_PERMIT_N must go 'not permitted' 58–97 ms after the DC reaches the legs (pass 45–120 ms) and return ≤ 599 ms after mute (pass ≤ 700 ms). **Without a calibration (−4.5 dB default master trim)** the windows are 109–187 ms (pass 95–210 ms) and back ≤ 453 ms (pass ≤ 550 ms). Add the DAC ramp time if a volume ramp is active; with vol_rate 0 that is ≤ 11.6 ms at 44.1 kHz. This takes ≤ 3.3 s.
   - (b) MCLK alive: PB14 low → PB1 low ≤ 10 µs and DC_PERMIT_N high 0.06–1.25 ms (pass ≤ 2.0 ms). PB14 high → DC_PERMIT_N low 64–208 ms (pass ≤ 250 ms).
   - (c) 1V3 good: **PB8 (N6_V13_TEST) low for 5 ms** → DC_PERMIT_N high ≤ 0.87 ms (pass ≤ 2.0 ms). Release → low 61–205 ms (pass ≤ 250 ms).
   - (d) 3V3A good: before AVCC_EN, **PA12 and PB9 read high**; ≥ 2 ms after V3A_MON ≥ 3.20 V both read low. Optional: with 3V3A off, PC10 high for 1 ms must leave the I²C lines low (Q620 holds 3V3D off).
   - U606 ch3 and Q619 are production-test items.
   - The whole test adds ≤ 3.81 s to the first start. Any failure means no RELAY_EN, red LED and an error over USB.
6. [FW] Pre-close checks: as R2.5 B.13 with **the protection's R3.9 limits: |leg| ≤ 0.070 V and |pair| ≤ 0.090 V (50 ms average)**. Closure is guaranteed refused for true DC > **129 mV per leg / 155 mV per pair** (protection R3.17, after DZ-1; was 126/152). Advisory: |reading − stored factory baseline| ≤ 25 mV, logged; three consecutive failures → refuse.
7. [FW] RELAY_EN high, then the volume ramp ≥ 10 ms later.

**C. Suspend / bus reset / host disconnect** (states #23, #21; `firmware_sequences` §2)
1. [FW] SOF-loss 1.0 ms, then **the SPI FADE command to the CPLD (new RTL requirement: linear 1 ms ramp of the output samples to digital zero, then hold zero)**. Then the I²C burst reg 7 = 0x83 (soft mute at vol_rate 0) + reg 8 = 0x20 (GPIO2 = minimum-volume flag) at 1.40 ms.
2. [FW] Wait for **GPIO2 (DAC_LOCK, PC9) = minimum volume**, bounded by a **deadline 3.91 ms after the mute write** (5.31 ms after the last SOF).
3. [FW] RELAY_EN low, then 1.1 ms; reg 14 = 0x03 (retry once) + 1.1 ms; MCLK_PERMIT low; CLOCK_CTRL/I2S_CTRL = 0; **PA8 high; link pins low**; PC10 + PC11 low, then 0.53 ms; ANA_EN, ILIM_HI and LEDs low. That totals 3.14 ms.
4. [FW] Stop with the RTC-alarm wake (below).
- **Result: suspend current is reached ≤ 8.50 ms after the last SOF at every fs and volume (margin ≥ 1.50 ms)** [CALC]. **Plainly: the binding order without a deadline does not meet 10 ms.** At 44.1 kHz and 0 dB attenuation the minimum-volume status arrives 11.6 ms after the mute write, and the total is 16.2 ms. The status comes before the deadline only at fs ≥ 176.4 kHz, or at 44.1/48/88.2/96 kHz with the volume already ≥ 84.9/81.1/41.8/34.1 dB down. At the deadline the DAC ramp alone has reached −43.1 dB (44.1 kHz). The CPLD FADE makes the deadline pop-free: the DAC input is digital zero ≤ 3.02 ms after the last SOF, before the 5.31 ms deadline, so the switch always opens on a zero-code output. The FIFO's buffered audio (≤ 11.61 ms) is faded, not truncated. **Accepted by the orchestrator as DX-1 (25 Sep 2026).**
- **Stop wake / IWDG — DX-2 (accepted 25 Sep 2026):** the RTC alarm (EXTI17, a Stop exit source [DS §2.5]) is clocked by **the same LSI as the IWDG**. PRL = 29,999 is permanent (the RTC is only the wake timer), so the wake comes every **30,000 LSI cycles = 0.50–1.20 s**, inside the suspend timeout of 40,000 cycles = 0.667–1.600 s. The margin is 10,000 cycles (0.17–0.40 s) with no tolerance stack. The DX-2 text says a 0.67–1.6 s wake, but that cannot sit inside a ≤ 1.6 s timeout on the same oscillator, so the wake is set to 75 % of the timeout. At each wake: IWDG reload, ALR += 1 (tracked in RAM), wait RTOFF, back to Stop. **Entry:** after PC10/PC11 low, write the suspend PR/RLR during the 0.53 ms discharge wait (PVU/RVU ≤ 5 LSI cycles), then ANA_EN low, refresh, Stop. The suspend bound of 8.50 ms is unchanged. **Exit:** the first action after the Stop exit is /4 with RLR 239, wait PVU/RVU (≤ 0.2 ms), refresh. Only then may any domain be enabled. **Average wake current ≤ 4.5 µA above Stop** [CALC on ASSUMP: 10 mA at HSI 8 MHz, 0.2 ms wake-up (76.7 µs typ [DS]), RTOFF ≤ 3 RTCCLK]. The superseded ≤ 30 ms scheme drew 189 µA. Power had already added the 189 µA figure to c17 S6. Protection R3.9 lists a different suspend option (wake ≤ 12 ms, or /32 × 625 only while RELAY_EN and ANA_EN are low). The orchestrator's DX-2 supersedes it, and its condition is the same one used here. **The paper S6 budget is then negative:** 2.683 / 2.589 mA (legacy / C-to-C) without power's 1 mA protection placeholder, against 2.5 mA. The orchestrator accepted the long suspend timeout as **DX-2** (above), replacing the 189 µA with 4.5 µA. Re-programming a running IWDG (key 0x5555, then PR/RLR, PVU/RVU) is standard for this watchdog type but was not read in the WCH V3x RM [ASSUMP]. A firmware hang during suspend is still cleared by the IWDG (≤ 38.4 ms). The 10 ms deadline itself remains firmware-only.

**D. Resume**: as R2.5 D (5.28 ms), then B.

**E/F. Rate and family changes — the switch is OPEN (production sequence, states #9)**
1. [FW] Soft mute (vol_rate 0), then wait for GPIO2 = minimum volume (timeout 1.5 × ramp). Then RELAY_EN low and 1.1 ms.
2. [FW] I2S_RUN = 0 and set the divider. For a family change: new oscillator on, ≥ 10 ms, switch the mux, old one to stand-by. MCLK_EN/MCLK_PERMIT stay high. FIFO prime, then I2S_RUN = 1.
3. [FW] Lock (1.5 × 16384/fs + 10 ms), LRCLK_FB and DPLL ±0.1 %, full pre-close checks (DC_PERMIT_N low ≥ 50 ms and so on), RELAY_EN high, then ≥ 10 ms, then the unmute ramp. **Worst case 871 ms** [CALC, `firmware_sequences` §4]. The option of keeping the switch closed is allowed only after documented measurements show ≤ 5 mV.

**G. Faults**: as R2.5 G, with the one overload rule (Always-5) and ANA_SENSE. **Tier constants (protection R3.17):** T1 0.900/0.900 V (100 ms), T2 0.240/0.230 V (300 ms), **T3 0.110/0.120 V (1.2 s)** (leg/pair; the T3 pair value was 0.118 V). With 0.118 V the pair no-trip level would sit only 0.1 mV above the 20 mV offset spec (`firmware_sequences` §9). A hardware trip never re-closes on its own before a hung MCU is reset (Always-4).

**H. Unplug / brown-out**: as R2.5 H. The ISR sets PA8 high (reset) only after RELAY_EN, as before, and never before the switch is open. Exception: MCU PDR, where R240 turns Q207 on (L-4).

**I. MCU reset / IWDG** [HW]: RELAY_EN floats to R646 and U206 Y → Q616, so the switch opens ≤ 1.01 ms. R234 stops X201 ≤ 0.39 µs. ENs go to their pull-downs. R511 selects Default ILIM. **R240 → Q207 → DAC reset** within tens of µs (AO3400A Ciss × 100 kΩ). As L-4 states, this is a fault transition and a click is possible.

**J. Programming mode** (states #20): **only after SET_CONFIGURATION (500 mA granted).** Until then the board stays in the 3V3M-only state (≤ 100 mA) and blinks the red LED slowly. It does not enter programming mode on a host that never configures it. Then ANA_EN → rails good (T_START) → AVCC_EN → ≥ 1 ms → PC10, and CPLD_NRST is released. MCLK_PERMIT is low, PA8 high (DAC in reset), RELAY_EN low. The ANA_SENSE supply-fault rule stays active (X-5). DC_PERMIT_N high is expected here. Exit is by reset only.

**K. Default ↔ High live changes** (states #11; `firmware_sequences` §11)
1. [FW] **Downgrade**: the CC reads < 0.66 V for 10 consecutive 1-ms averages. Then soft mute (≤ 17.4 ms timeout at 44.1 kHz), **ILIM_HI low**, 5 ms settle, Default volume ceiling, unmute. The load is reduced **≤ 28.8 ms after the change, within tSinkAdj 60 ms** (the tSinkAdj value is from memory and was not re-read in the specification). A class that disappears (< 0.2 V) takes the unplug path.
2. [HW backstop] A firmware hang with ILIM_HI high is cleared by the IWDG in ≤ 38.4 ms, then R511 selects Default, which is inside tSinkAdj. There is still no hardware AND between the CC class and ILIM_HI, so High mode stays firmware-gated (states #11 residual; a hardware gate would be a power/protection change).
3. [FW] **Upgrade** only with the switch open or ANA_EN low, after ≥ 100 ms stable ≥ 1.5 A.

## R3.3 Integration check and open items
- `check_design.py power protection analog digital` (25 Sep 2026, 09:25, other streams as saved at that time): 326 parts, 186 nets, 977 pins. There are **2 issue types, none caused by a digital fault**. (1) `single_pin_net` **RAIL_EN** (power R507-1 only) and `iface_unconnected` RAIL_EN: digital deleted PB8/RAIL_EN per X-1, and power still has to delete R506/R507. (2) `single_pin_net` **ANA_SENSE** (U201-14 only): power still has to add R535/R536 + C516 (X-5). No issue on N2_AVCC_EN_G, AUD_EN, DAC_RESETB, LINK_* or N2_* nets. U605 (protection) was not yet in the protection netlist at check time, so the open-collector ends of N2_AVCC_EN_G/AUD_EN were not checked. Re-run once all streams have saved. **Re-run at 09:0x (msg clock) after power saved X-1/X-5:** the RAIL_EN and ANA_SENSE connectivity issues are gone. Two flags remain, both from the checker's own interface list (`integration/check_design.py`, not a stream file). `cross_stream_non_iface` ANA_SENSE (digital + power): the net is named by X-5, so the checker list needs it added. `iface_absent` RAIL_EN: the net was deleted by X-1, so the list needs it removed. Neither is a digital design issue. The integration owner must update the list.
- Open items and what I could not verify:
  - LED polarity (B-09).
  - The Type-C R2.5 table number and tSinkAdj/tRpValueChange values (quoted from Type-C R2.0 via ST AN5225, or from memory).
  - The CH32V307 SPI tv(MO), duty cycle, run current at HSI and Stop wake-up maximum, all [ASSUMP]. The RTC RTOFF duration [ASSUMP; V3x RM not retrieved].
  - AGRV2K FF setup/hold and clock-tree delay [ASSUMP].
  - U208 channel skew is not published and is bounded conservatively.
  - The ESS behaviour of GPIO2 "minimum volume" timing [ASSUMP 50 µs].
  - The CPLD FADE is new RTL (owner) and needs verification [MEAS: suspend at 44.1 kHz with full-scale 20 Hz at both jacks, and a worst-phase check].
- Scripts not re-run in round 3 (their round-2 outputs are superseded where they touch these items): `currents.py` (deltas are in the interface requests below), `levels_and_pullups.py` §1b (the R233/R305 level case is replaced by Q207 open drain with R305 10 k to DVCC, so no current flows into U301-28 with DVCC off), `mclk_gate_race.py` and `stress_table.py` (U208 at 3.3 V: VCC and inputs within the 6.5 V abs max, output ≤ 5 mA DC, so stress is negligible [DS]). Current pin tables: `pin_tables_output.txt` (regenerated). The §4A.1/§5.3 tables further down are the round-1/2 record (B-17).
- Interface requests:
  - **Power**: in S6 replace the 189 µA wake with **4.5 µA (DX-2)**. In S2/S3/S3f/S5 the recomputed U208 current is **2.52 mA at 384 kHz** (0.37 mA at 44.1 kHz; CPD 14 pF + CL 6 pF, SCK 36 MHz + MOSI ≤ 18 MHz, 70 % burst duty), against the c17 placeholder of 1.667 mA (+0.86 mA). There is also a JTAG pull bound of ≤ 0.167 mA [ASSUMP]. Together that is about +1.02 mA against c17's S3 margin of +0.04 mA, so power must re-balance (its R509/R510 4.81 k sensitivity option). The currents above are from `currents_output.txt` (round 3, re-run).  Remove the R233 0.032 mA from 3V3M and add R240 33 µA (PA8 low while playing). U208 draws ≤ 4 µA static plus CPD on 3V3D (14 pF × 3.3² × 36 MHz ≈ 5.5 mW while bursting).
  - **Protection**: done. Its R3.9 criteria are adopted and PB8/PA12/PB9 are netted as requested. The R665 1 k tap on the MCLK net at the XI pin (≤ 1.29 pF) raises the X201 load to 14.4 pF (≤ 15 pF); `clock_timing` was re-run and the XI edge margins still pass.
  - **Parts**: U206 SOT363-2 and U208 SOT765-1 into `layout_package.md` §14, the 2520-only lands, and LED polarity.
  - **Owner (RTL)**: FADE register and a digital-DC test register.

## R3.6 Final changes (decisions_r8c DZ-1, DZ-2, DZ-6; 25 Sep 2026)
- **DZ-1: R242–R246, 330 Ω 1 % 0402** (C25104, on the 330 Ω BOM line with R228–R230), placed at the MCU pins:

  | Resistor | Node side | MCU pin | Pin-side net |
  |---|---|---|---|
  | R242 | DC_SENSE_LP | PC0 | N2_DCS_LP_PIN |
  | R243 | DC_SENSE_LN | PC1 | N2_DCS_LN_PIN |
  | R244 | DC_SENSE_RP | PC2 | N2_DCS_RP_PIN |
  | R245 | DC_SENSE_RN | PC3 | N2_DCS_RN_PIN |
  | R246 | V3A_MON | PC4 | N2_V3A_MON_PIN |

  - Purpose: they limit the clamp injection from the 4.7 µF protection nodes to ≤ 3.0 mA per pin while the MCU is unpowered (DZ-1).
  - **ADC settling at TS 41.5 cycles still holds** (`adc_settings_output.txt` §3). The pin sees ≤ 2.82 kΩ (node 2.49 k + 333 Ω), far inside the WCH limit of 43.5 kΩ.
  - The 4.7 µF stays on the node side, so each sample kick recharges through 330 Ω: τ = 17.3 ns, 1/4-LSB settling 168 ns ≪ the 3.46 µs sample time [CALC; pin C 5 pF and RADC 1 kΩ are ASSUMP].
  - The extra DC error is ≤ 0.42 mV per channel (1 µA leakage and the mean sampling current through 330 Ω). **Protection adds it to its sensing error budget** (DZ-1). The channel order, rate (20.000 kHz) and scan are unchanged.
- **DZ-2: R207/R208 4.7 kΩ → 10 kΩ** (moved to the 10 k BOM line). The 30–70 % rise time is **257 / 428 / 856 ns at 30 / 50 / 100 pF**, under the 1000 ns standard-mode limit at 100 kHz (`levels_and_pullups_output.txt` §3). Sink current is ≤ 0.34 mA. An ohmic extrapolation of the ESS VOL (0.2 V at 100 µA) gives ≤ 0.57 V against about 0.98 V MCU VIL, a 0.41 V margin; with 4.7 k it was 1.02 V. Firmware keeps an I²C ACK-error counter, and SDA VOL is a bring-up [MEAS]. Digital 3V3D worst static load drops from 1.42 to 0.67 mA (both lines low) (`currents_output.txt`: S2/S3 3V3D share 72.58 mA).
- **DZ-6: post-CPLD stream guard** (R-5 mitigation; `firmware_sequences` §13; add to R3.2 G):
  - **Input:** the I²S words the MCU already captures (PB12 WS, PB13 CK, PB15 SD via R228–R230; I2S2 slave receive, 32-bit frames, circular DMA, 1 ms half-blocks).
  - **Triggers:** the USB-side guard rules: CIC² of two 50 ms means ≥ 0.30 FS, or 26 ms flat (range ≤ 1e-3 FS and |mean| ≥ 0.02 FS) per channel. A stalled capture (no DMA progress for > 2 ms with I2S_RUN = 1) also triggers.
  - **Action:** CPLD FADE (DX-1) and DAC soft mute (vol_rate 0) at once. If the captured words are not zero 2 ms after the FADE (CPLD frozen): RELAY_EN low, CPLD_NRST, then the fault policy. Release is as the USB-side guard.
  - **Latency:** detection ≤ 27.1 ms (flat) / ≤ 101.1 ms (level): the rule window + 1 ms block + 0.1 ms. The DAC input is then zero ≤ 1.0 ms later (FADE), or after the DAC ramp of 11.6 / 2.7 / 1.3 ms at 44.1 / 192 / 384 kHz if the CPLD is frozen.
  - **CPU load at 384 kHz:** 5.76 M cycles/s = **4.0 %** of 144 MHz, plus one ISR per ms [ASSUMP 15 cycles per stereo frame]. DMA is 1.536 M half-word transfers/s. At 192 kHz it is 2.0 %.
  - **Plainly:** at 352.8/384 kHz the capture needs the I2S2 slave to follow a 22.6/24.6 MHz BCLK. That is not in the retrieved WCH text (round-1 open item, [MEAS]); it is expected to work up to 192 kHz. If the bring-up measurement fails, the R-5 CPLD-frozen-word residual remains at 352.8/384 kHz only. The DAC-core hang remains the R-5 residual at every rate (DZ-6).
- The `levels_and_pullups` §1b (R233) case is marked superseded in the script output.

# R8 follow-up (round 2) — 25 Sep 2026

Continues round 1 (§0–§16 below, which stay as the record). Binding inputs: `integration/decisions_r8b.md` D-1…D-19 (**D-3 revised 25 Sep 2026: X201 = Kyocera KC2520K80.0000C1GE00, 80.000 MHz; D-19: R645 fed from N2_MCLK_OE**). Every number in this section supersedes the round-1 number marked **[R2 ↑]** further down. Labels as in round 1: [DS], [DS-typ], [CALC], [ASSUMP], [MEAS], [PH].

## R2.0 Round-2 changes (all, including those already in the netlist before the interruption)

| # | Change | Files | Why |
|---|---|---|---|
| 1 | **X201 → Kyocera KC2520K80.0000C1GE00** (80.000 MHz, ±50 ppm, −40…85 °C), 2.5 × 2.0 mm on the combined 2520/3225 land; pad 1 INH (stand-by), 2 GND (case), 3 OUT, 4 VCC. Conditional second source NDK NSC5338D-80M. The first round-2 choice, Epson SG-210STF 75.0000M, turned out obsolete (R2.1.4); TXC 7X withdrawn; SCTF SX3M80 not approved | netlist, BOM, all clock scripts | D-3 revised |
| 2 | **U206 74LVC1G08 → 74LVC1G11** (Nexperia 74LVC1G11GW-Q100H, C548242): X201 INH = MCLK_EN ∧ AVCC_EN ∧ **MCLK_PERMIT**; MCLK_PERMIT = MCU **PB14** push-pull with **R234 10 k** pull-down at U206 | netlist, BOM (before the interruption) | a firmware-free MCLK stop that beats the 3V3A discharge at an MCU reset (R2.1.3) |
| 3 | **R233 4.7 k** in series at MCU PA8 → DAC_RESETB (R305 100 k at the DAC stays) | netlist, BOM (before) | analog request ≥ 3.3 k: ≤ 0.71 mA into U301-28 with 3V3D off; VIH margin 0.59 V (`levels_and_pullups` 1b) |
| 4 | **PA12 and PB9 freed** (DOM_DIS, AMP_EN retired) → analog inputs | netlist (before) | D-11 |
| 5 | **TP732** PROG pad (PC13) in BOM/netlist | BOM, netlist (before) | Notes 3.8 allocation (parts draft says TP737: reconcile) |
| 6 | **New: R235 100 k** (C25741) at U206 Y and **PB1 = N2_MCLK_OE readback** (floating input); **N2_MCLK_OE also feeds the protection's R645 → Q616 gate (D-19, accepted)** | netlist, BOM, levels 8, race 5 | every MCLK stop now opens the output switch in hardware; R235 defines the node (X201 INH, Q616 gate, PB1) while U206 is unpowered; PB1 gives a boot self-test of U206/R234 |
| 7 | **ADC redesign (D-13)**: dual regular-simultaneous mode through ADC1's DMA; TS 71.5 cycles on every channel at 12 MHz; **20.41 kHz per channel** | `adc_settings.*`, pin notes | ≥ 10 kHz required; ADC2 has no demonstrable DMA request (R2.3) |
| 8 | Currents recomputed per USB state incl. suspend and programming mode | `currents.*` | D-15, decision load table |
| 9 | Firmware requirements merged into one list per state, HW/FW marked; conflicts resolved; **F_MCLK = 80 MHz** constant | R2.5, R2.6, `firmware_sequences.*` | task 5, D-3 revised |
| 10 | X202/X203 NDK NZ2520SDA kept; SCTF SX3M49.152/45.1584 marked **non-compliant fallback** everywhere | BOM notes, currents 5 | D-4 |
| 11 | Pin notes updated for RELAY_EN, DC_PERMIT_N, ANA_FAULT_N, RAILS_OK_N (R532), ILIM_HI (U505), MCLK_EN / N2_MCLK_OE (R645, D-19), ADC channels | netlist, R2.7 | task 6 |
| 12 | **C217 100 nF → 10 nF** (C15195, Basic) HF bypass at the X201 VCC pad; MCLK settle wait 6 ms, RESETB ≥ 7 ms after the enable | BOM, netlist, `firmware_sequences` | Kyocera spec: "high frequency type capacitor 0.01 µF to the nearest position of oscillator"; the wait also covers the NDK (4 ms start-up × 1.5) |

Net BOM effect: 28 lines, 65 fitted refs (62 components + 3 pad groups), 2 DNF, 231 SMT joints, US$ 11.23 fitted (`gen_netlist_bom_output.txt`). MCU GPIO: 43 used, 6 spare (PC14, PC15, PA0, PB0, PA12, PB9).

## R2.1 X201 = Kyocera KC2520K80.0000C1GE00, 80.000 MHz (D-3 revised)

### R2.1.1 Datasheet verification
Source: Kyocera product specification TNY1T-H1-SEE01-04 rev 00, 5 Jun 2025 (ele.kyocera.com/assets/products/crystal-device/specification/KC2520K80.0000C1GE00_e.pdf) — "all electrical characteristics have defined on the maximum loaded and recommended operating conditions".

| Item (condition) | Value [DS] | Needed / result |
|---|---|---|
| Pads | 1 stand-by function, 2 case GND, 3 output, 4 VCC; 2.5 × 2.0 × 0.8 mm | same pin map as the combined land ✓ |
| Pad 1 INH | H or open → run; L → stand-by (oscillation stop), IST ≤ 5 µA; output level in stand-by not stated | R227 holds XI low either way ✓ |
| INH thresholds | VIH ≥ 0.7 VCC, VIL ≤ 0.3 VCC; VIN 0…VCC (abs −0.3…VCC + 0.3 V) | U206 VOH ≥ VCC − 0.1 V → margin **0.86–0.92 V** over 3V3D 3.20–3.40 V; VOL ≤ 0.1 V vs ≥ 0.96 V (`levels` 7) ✓; same rail, Y low during every 3V3D ramp ✓ |
| Output disable time t_dis | **≤ 200 ns** | closes the round-1 [MEAS] (R2.1.3) ✓ |
| Enable t_ena / start-up t_sta | ≤ 2 ms / ≤ 2 ms (catalogue and D-3: 3 ms) | firmware waits 6 ms, RESETB ≥ 7 ms after the enable (covers the NDK's 4 ms) |
| ICC (loaded, 2.8 < VCC ≤ 3.63 V) | ≤ 8 mA at CL ≤ 15 pF, over temperature | our load 13.1 pF (XI 10 pF [ESS DS] + 20 mm trace 2.6 pF + pads 0.5 pF [ASSUMP]) → **X201 + R227 = 8.17 mA ≤ 8.2 mA** budget ✓ |
| Symmetry | 45–55 % @ 50 % VCC | equals the ESS 45:55 limit (R2.1.2) |
| Tr/Tf (10–90 %, 2.8 < VCC ≤ 3.63 V) | ≤ 4.5 ns | full swing at XI (R2.1.2) ✓ |
| VOH / VOL | ≥ 90 % VCC / ≤ 10 % VCC at ∓4 mA | ✓ |
| Supply / abs max / temperature | 1.6–3.63 V; 4.0 V; −40…+85 °C | 3V3D ≤ 3.40 V ✓ |
| Frequency tolerance | ±50 ppm incl. initial, temperature, supply, load, 1-year aging, shock, vibration | ratio check below ✓ |
| Jitter | 1σ period ≤ 5 ps, pk-pk ≤ 50 ps; phase jitter row blank in the spec text (1.0 ps max 12 kHz–20 MHz in the Kyocera catalogue per parts FU-3) | not limiting even at 5 ps (124 dB at 20 kHz FS); phase jitter [MEAS] (D-3) |
| By-pass / reflow / MSL | 0.01 µF HF capacitor at the nearest position; 260 °C 10 s, twice max; MSL 1 | C217 = 10 nF at pad 4 ✓; Standard PCBA 240 ± 5 °C, one pass ✓ |
| Availability | DigiKey 2,964 (Aug 2026), Mouser 1,375 (+10,000 on order); LCSC C1988889 not stocked | JLCPCB global sourcing |

### R2.1.2 Clock timing (`clock_timing_output.txt` §4–5)
- MCLK/FSR at 384 kHz: **208.33** nominal, **208.31** worst (MCLK −77 ppm incl. 10-year aging, FSR +50 ppm) > 192 → **+8.49 %** [CALC, ESS DS p.7].
- Cycle 12.5 ns ≥ 10 ns; pulse widths at 50 % VCC ≥ 5.625 ns at 45:55; R203 × C_XI can add ≤ 0.11 ns rise/fall skew → **≥ 5.51 ns vs 4.5 ns** (margin 1.01 ns) [CALC].
- **Duty**: Kyocera 45–55 % equals the ESS 45:55 limit — **zero datasheet margin** (R203 could move it by ≤ 0.9 % only if rise and fall shapes differ) → **[MEAS]** duty and pulse widths at XI at 30/50/70 % VCCA; designed-in fallback **R203 → 0 Ω** (BOM value).
- Swing at XI with worst-case exponential edges (τ ≤ 2.41 ns incl. R203): **0.17…2.91 V** at 3V3D 3.20 V vs VIL 0.4 V / VIH 2.13 V → full logic levels every cycle [CALC]. Widths measured at VIH/VIL with datasheet-limit linear edges would be 3.6/1.3 ns (not guaranteed if ESS measured there) → covered by the same [MEAS]. **R203 33 Ω kept.** (The withdrawn TXC's 8 ns edges would not have guaranteed full swing.)
- **Soft start (reg 14 = 0xAA, soft_start_time 10): 4096 × 2¹¹ / 80 MHz = 104.9 ms**; firmware waits × 1.2 = **125.8 ms**.
- **DPLL ratio check** (firmware table, F_MCLK = 80 MHz): FSR = DPLL_NUM × F_MCLK / 2³² [ESS DS reg 66–69] → expected DPLL_NUM: 44.1 k **2 367 601 (0x00242071)**, 48 k 2 576 980 (0x00275254), 88.2 k 4 735 201, 96 k 5 153 961, 176.4 k 9 470 403, 192 k 10 307 922, 352.8 k 18 940 806, 384 k **20 615 843 (0x013A92A3)**; window ±0.1 %. FSR × 2³²/DPLL_NUM (FSR from TIM3) within ±0.1 % of 80 MHz also verifies the fitted X201 at the first lock.
- External DVDD still required (80 MHz > 50 MHz; FSR > 192 kHz) [ESS DS p.7].

### R2.1.3 Hardware stop at an MCU reset and the output-switch permit (`mclk_gate_race_output.txt`)
PB14 floats → R234 pulls MCLK_PERMIT below 0.8 V in 184 ns → U206 ≤ 4.9 ns → Kyocera stand-by ≤ 200 ns → **X201 stopped ≤ 0.39 µs**, all datasheet limits; earliest 3V3A 0.3 V drop 28.0 µs → **margin 27.6 µs** [CALC]; XI then < 0.4 V after ≤ 0.28 µs (R227). Round 1's 2-input gate could lose this race by up to 56 µs at the datasheet corners (section 1 of the script) — that is why the third input exists. Firmware error "AVCC_EN low while MCLK runs": gate + stop ≈ 0.21 µs vs ≥ 4.8 µs before 3V3A moves → hardware-backed. **R227 10 k stays**: the stand-by output level is not specified and ESS requires XI "stopped at logic low" [ESS DS p.7].
**D-19 (accepted)**: R645 is fed from N2_MCLK_OE, so every MCLK stop — CPLD MCLK_EN, MCU reset (R234), MCLK_PERMIT or AVCC_EN low, 3V3D collapse (R235) — also turns Q616 off (gate ≤ 1 nF behind R645: < 0.45 V 1.99 µs after Y falls) and opens the output switch ≤ 1.002 ms later (≤ 1.204 ms through R235 when U206 is unpowered; protection p05); the frozen-DAC-code exposure is ≤ ~1 ms for any stop the design commands. U206 static load: INH + R235 34 µA + Q616 gate leakage ≪ 100 µA (VOH ≥ VCC − 0.1 V); the 630 pF gate sits behind R645 1 k (≤ 3.3 mA transient).

### R2.1.4 History: why not the Epson SG-210STF 75.0000M (original D-3)
Verified electrically earlier in round 2 (t_stp_st ≤ 100 ns, 3.0 mA no load, 45–55 %), but DigiKey and Mouser list all 75 MHz codes (…ML3 X1G004171008112, …ML X1G004171008101, …ML0 X1G004171008114) as **obsolete** (Epson EOL notice 25 Jun 2020); Epson's current list stops at 72 MHz (fails 192 × 384 kHz); LCSC C17388398 out of stock; only a 150-piece broker lot was seen (parts Follow-up 3). Source quotes S12/S13.

### R2.1.5 Candidate comparison that led to D-3 revised (`clock_timing` §4, `mclk_gate_race` §2, `currents` §5)

| Item | **Kyocera KC2520K80.0000C1GE00 (X201)** | NDK NSC5338D-80M (conditional) | Epson SG-210STF 75 MHz (obsolete) | TXC 7X-80.000MBE-T (withdrawn) |
|---|---|---|---|---|
| Pin-1 low | stand-by, ≤ 5 µA | stand-by 20 µA | osc stop, Hi-Z | OE only, osc runs |
| Disable time → stop at MCU reset | 200 ns → 0.39 µs, margin 27.6 µs | not stated → [MEAS] ≤ 10 µs | 100 ns → 0.29 µs | not specified |
| XI swing / 50 % pulse | full / ≥ 5.51 ns | full (edge definition assumed) / ≥ 5.51 ns | full / ≥ 5.89 ns | not guaranteed (8 ns edges) |
| Current incl. R227 | **8.17 mA** | 12.7 mA [ASSUMP: 9 mA spec unloaded] | 6.44 mA | 15.2 mA |
| Start-up | 2 ms (3 ms catalogue) | 4 ms | 3 ms | 5 ms |

NDK conditions (D-3 revised): bring-up checks of the disable time (≤ 10 µs) and XI edges/swing, 12.7 mA budget.

## R2.2 X202/X203 (D-4)
Kept: NDK NZ2520SDA-49.152MHZ / -45.1584MHZ-NSC5083D, 20–54 MHz series, ≤ 15 mA operating / ≤ 35 µA stand-by (output Hi-Z, oscillator stopped) at 25 °C [DS], ≤ 4 ms start-up, ±50 ppm. DigiKey 3,438 (49.152) / 3,166 (45.1584, 24-week lead) via JLCPCB global sourcing. **SCTF SX3M49.152M20F30TNN (C2901591) / SX3M45.1584M20F30TNN (C2901589) are a non-compliant fallback**: output-disable only, both oscillators run, +24.96 mA on 3V3D → power c03 best Default IOS min 161.7 mA < 174.2 mA need → Default power targets not met. SiT8008 (ST option) stays the compliant second source (its 50–150 kΩ pin-1 pull-up against R212/R213 10 k gives ≤ 0.57 V < 0.3 VCC → stand-by holds).

## R2.3 ADC (D-13) — `adc_settings_output.txt` (final, aligned with protection R2.8 / R2.13-1)
**Architecture.** WCH's own dual-ADC example enables DMA on ADC1 only and reads ADC2 from the upper half of ADC1's 32-bit data register; no WCH source shows an ADC2 DMA request (STM32F1 heritage). So: **dual regular-simultaneous mode**, ADC1 master / ADC2 slave, SCAN = 1, 8 slots each, regular group **triggered by TIM4 CC4 at exactly 20.000 kHz** (144 MHz / 7200; internal compare event, no pin), **DMA1 channel 1, 32-bit circular** (ADC2 in [31:16], ADC1 in [15:0]). The ADCs run without CPU intervention between triggers ("continuous DMA scan" of D-13 in intent; the exact rate is the protection's request). ADC1 converts **VBUS_SENSE (IN1) in all 8 slots** — it never switches channel (R8-D6 rule kept). Simultaneous slots must stay aligned and TS is set per channel, so every channel uses one TS.

| Slot (ADC2) | Channel (pin) | Source impedance (worst) | WCH rule at 12 MHz |
|---|---|---|---|
| 1, 2 | CC1_ADC, CC2_ADC (PA2, PA3; IN2, IN3) | **12.3–15.3 kΩ** = R103/R104 10 k + Rd 5.1 k ∥ Rp (Rp 4.47 kΩ … ∞ = current-source or open CC) | TS ≥ 28.5 |
| 3 | V3A_MON (PC4, IN14) — dummy, discarded (protection's order) | 2.49 kΩ + 4.7 µF | TS ≥ 7.5 |
| 4 | V3A_MON — reference (reading = leg − ref) | 2.49 kΩ + 4.7 µF | TS ≥ 7.5 |
| 5–8 | DC_SENSE_LP/LN/RP/RN (PC0–PC3, IN10–13) | 2.49 kΩ (6.8 k ∥ 5.1 k ∥ 16.9 k) + 4.7 µF | TS ≥ 7.5 |
| ADC1, all 8 | VBUS_SENSE (PA1, IN1) | 32.3 kΩ (100 k ∥ 47 k) + C103 10 nF | TS ≥ 41.5 without C103 credit |

- **TS 41.5 cycles on every channel** (≥ every minimum; RAIN allowed 43.5 kΩ: CC ×2.9, VBUS ×1.35 even without C103, sense ×18) → slot 4.5 µs, 8-slot scan **36.0 µs per 50 µs** trigger period (72 % busy) → **20.000 kHz per channel** (×2 the requirement). The protection's per-channel 13.5 / 28.5 cycles would need ADC2 with its own DMA; firmware option only if the bring-up proves an ADC2 DMA request (no board change).
- DMA buffer 2 × 20 scans × 8 words (1280 B); half/complete interrupt every 20 scans = **1.000 ms** → the estimator runs every 1 ms on 20 samples per channel, averaged in pairs to the protection's 10 kHz stream (windows 1000 / 3000 / 12000 pair-averages for 100 ms / 300 ms / 1.2 s); the dummy word is discarded.
- **Sample-capacitor coupling** (CH32V307 user-forum note, elecfans: adjacent channels couple through the sample capacitor): the 4.7 µF node capacitor averages every charge withdrawal, so the reference node's DC shift is set by the charge per scan it gives to CADC after CC2 — **the dummy conversion draws that same charge from the same node and does not reduce it** (it only removes the per-sample step, ≤ 8 µV, already negligible). Result: ≤ 0.65 mV at the ref node = **1.79 mV on every leg reading, same sign, cancelling in pair differences** (model: CADC keeps the previous slot's voltage [ASSUMP]); bound for CADC at any level 3.59 mV per channel. Protection p09 assumes "the dummy makes the reference see ΔV = 0" and misses this term; with it, e_leg 51.0 → 52.8 mV (bound 58.2 mV) → guaranteed T3 leg level **0.169 V** (bound 0.174 V), T2 0.303 V, T1 0.987 V — the owner's < 0.2 V rule holds; pairs are unaffected. Leg-to-leg coupling (0.80 mV with 2 V between adjacent legs) agrees with p09. Alias term at 20 kHz 2.11 mV (protection keeps 4.22 mV at 10 kHz, conservative).
- **CC classification** (High mode only with a ≥ 1.5 A advertisement): error ≤ 43 mV; every Rp class sits ≥ 93 mV from the 0.66 V / 1.23 V thresholds (Type-C values from memory, not re-read); decide on 100 ms stable, re-check every 10 ms.
- **VBUS analog watchdog** (ADC1 IN1, single-channel AWD): 5V_SYS 4.00 V → pin 1.279 V → **LTR = 1587**, HTR = 4095; band 3.77–4.23 V (power c09); VBUS converted 8 × per scan (gap ≤ 18.5 µs); a 5.0 → 3.5 V step is flagged ≤ 0.35 ms later (C103 τ 0.32 ms dominates).
- Pins in analog mode; ADC calibration after every ADC power-up; readings valid for protection only while V3A_MON is in 1.526–1.691 V for ≥ 150 ms (protection §6). (First round-2 proposal — continuous 7-slot scan at TS 71.5, 20.41 kHz — is replaced.)

## R2.4 Currents (D-15) — `currents_output.txt`
3V3D max 3.333 V (TLV767 ±1 % [DS]), 3V3M max 3.35 V (TPS7A20 ±1.5 % [DS]); maxima; DAC DVCC/DVDD, analog, protection and power lines are the other streams'.

| Load | Value | Basis |
|---|---|---|
| CPLD AGRV2KQ32 | 40 mA | [ASSUMP] (decision file) |
| **X201 Kyocera + R227** | **8.17 mA** (8.0 mA max loaded at 15 pF, over temperature + R227 at 50 % duty) | [DS]+[CALC]; ≤ 8.2 mA budget (D-3 revised) |
| NDK running / other stand-by | 15 mA / 0.035 mA | [DS 25 °C] |
| U205 mux | 4.59 mA | CPD 18 pF [DS-typ] + 10 pF [ASSUMP] |
| U206 + R218/R212(213) + R216(217) + R235 + I²C 4.7 k both low + MCU internal pull-downs (moved here from 3V3M) | 2.84 mA | [CALC]/[ASSUMP 30 kΩ] |
| MCU CH32V307, 144 MHz, USBHS | 80 mA run / 1.9 mA suspend | [ASSUMP]/[PH] (WCH typicals only) |
| LEDs, R233, R234 | 0.76 / 0.71, 0.032, 0.338 mA | [CALC] |

| USB state (digital share) | 3V3M | 3V3D | Sum |
|---|---|---|---|
| S1 attached, not configured (one LED, PA8/PB14 low) | 80.76 | 0 | **80.76 mA** |
| S2/S3 configured idle / playing | 81.13 | 70.64 | **151.76 mA** |
| S3f family change ≤ 10 ms (both NDKs) | 81.13 | 85.94 | 167.06 mA |
| S5 programming mode (D-15: domains up to AUD_EN, RESETB low, MCLK off = X201 stand-by 5 µA, worst: both NDKs run under CPLD ISP pull-ups) | 81.58 | 76.49 | **158.07 mA** |
| S6 suspend | 1.90 | 0 | **1.90 mA** |

Round 1: 3V3D 102.5 → 70.6 mA (−31.9 mA). Conditional NDK X201: +4.49 mA (12.7 mA budget); SCTF family fallback: +24.96 mA (non-compliant).

## R2.5 Firmware requirements per state (merged: digital + protection §8–10 + analog §13–14 + power §6.5/§7/§10 I3)
[HW] = a hardware mechanism enforces or backs up the rule if firmware fails; [FW] = firmware only.

**Always (every state)**
1. [FW] Never set soft_start = 0 or soft_start_on_lock = 1, and never drive DAC_RESETB low, while the switch can be closed (RELAY_EN high or < 1.1 ms after it fell) (analog N5).
2. [FW] An EN that went low stays low ≥ 1 ms (power); MCU outputs facing 3V3D (LINK_*, DAC_RESETB, MCLK_PERMIT) are low whenever AUD_EN is low (ESS S4). AVCC_EN may be high before AUD_EN: U206 input B is IOFF-rated (≤ ±2 µA [DS]).
3. [HW, D-19] Any MCLK stop (MCLK_EN, AVCC_EN or MCLK_PERMIT low) drops U206 Y and opens the output switch through R645 → Q616 (≤ 1.002 ms; ≤ 1.204 ms via R235 if U206 is unpowered); firmware still keeps the order RELAY_EN low ≥ 1.1 ms before MCLK_PERMIT/AVCC_EN fall, so the switch never opens under signal — except the brown-out ISR (H.1, analog request).
4. [FW] RAILS_OK_N is valid only with ANA_EN = RAIL_EN = 1 for ≥ 20 ms after RAIL_EN; ANA_FAULT_N only with ANA_EN high for ≥ 5 ms [ASSUMP until the power stream confirms the TPS2596 FLT start-up behaviour].
5. [FW] SPI1: no MISO data at 36 MHz; register reads in separate 9 MHz transactions. IWDG /4, reload 625 (41.7–100 ms), refreshed only when all tasks report alive [HW backstop].

**A. Attach / enumeration (before SET_CONFIGURATION)**
1. [HW] Reset: all ENs, RELAY_EN, ILIM_HI, MCLK_PERMIT, DAC_RESETB float → R508/R303/R513/R506-R507, R646, R511, R234, R305 → domains off and discharged, switch open (RELAY_EN and Q616), X201 stopped, DAC in reset, Default ILIM.
2. [FW] ≥ 5 ms real time on HSI at low clock, PLL/USBHS off (program 5.2 ms) (power I3c).
3. [FW] GPIO setup per round-1 rules (b)–(e); PB1 floating input; PC13 pull-up; if PROG low → state J.
4. [FW] ADC: calibrate, start TIM4 (20.000 kHz) and the dual-simultaneous 8-slot DMA scan (R2.3), AWD LTR 1587.
5. [FW] CC classification; ILIM_HI low until configured and ≥ 1.5 A advertised; one LED only (digital share 80.76 mA).
6. [FW] Enumerate UAC2 HS.

**B. Power-up after SET_CONFIGURATION** (pre-close pass ≤ 425.8 ms, ≤ 515.8 ms with the 100 ms CPLD timeout; `firmware_sequences` §3)
1. [FW] ILIM_HI per CC (High only with ≥ 1.5 A), set only while ANA_EN is low or the switch is open.
2. [FW] ANA_EN → ≥ 5 ms → RAIL_EN (EN ≤ VIN).
3. [FW] Rails good (A-4 rule); ANA_FAULT_N high.
4. [FW] AVCC_EN (VCCA/AVCC first; I/V rails already up — analog S1/S6) → ≥ 1 ms → AUD_EN (DVCC after VCCA; 1V3 follows 3V3D → DVDD ≤ DVCC).
5. [FW] CPLD: poll ID 0xA6D2 at 9 MHz every 1 ms, 100 ms timeout → CPLD_NRST low 1 ms → retry → fault; rewrite all CPLD registers.
6. [FW] Family oscillator on (OSC48_EN or OSC44_EN).
7. [FW+HW] MCLK_EN = 1 (≥ 3 ms after AUD_EN, which is ≥ 2 ms after 1V3 if 1V3 regulates ≤ 1 ms after AUD_EN [ASSUMP: TLV767 + TLV75801P start-up, power to confirm]); self-test PB1 = 0 with PERMIT low; MCLK_PERMIT = 1 → PB1 = 1 (else fault: no MCLK and no switch permit).
8. [FW] DAC_RESETB high ≥ 7 ms after the enable (Kyocera enable ≤ 2 ms spec / 3 ms catalogue; conditional NDK 4 ms × 1.5 + 1 ms).
9. [FW] I²C (100 kHz, 9-clock recovery first): reg 7 = 0x83 (mute), reg 1 = 0x80, reg 10 = 0x00 (stop_div 0), reg 8 = 0x10 (GPIO2 lock), reg 14 = 0xAA (soft start 104.9 ms at 80 MHz), master trim from flash or the uncalibrated default −4.5 dB = 0x4C3EA838 (reg 20…17, R2.6 C-7, agreed with analog), volume.
10. [FW] Divider, FIFO prime, I2S_RUN = 1 after the family oscillator has run ≥ 10 ms.
11. [FW] Soft start ends 104.9 ms after the init (analog: no DC checks before × 1.2 = 125.8 ms); lock (reg 64 bit 0) within 1.5 × 16384/fs + 10 ms; DPLL ratio ±0.1 % against the 80 MHz table (R2.1.2), which also verifies the fitted X201.
12. [HW+FW] Permit H returns only after the CM window clears (end of the soft start) with 3V3A present and no leg DC; firmware **polls DC_PERMIT_N: low ≤ 205 ms after the soft-start end, else CM/clock fault at 300 ms** (protection R2.7). ESS does not fix when the ramp starts relative to the I²C writes, so the soft-start end is taken at the analog ×1.2 allowance (I²C init + 125.8 ms): DC_PERMIT_N low by init + 330.8 ms, fault at init + 425.8 ms.
13. [FW] Pre-close checks (protection §8.3 + digital): rails good; ANA_FAULT_N high; V3A_MON in window ≥ 150 ms; DC_PERMIT_N low ≥ 50 ms; ≥ 1020 valid samples with |leg| ≤ 0.10 V, |pair| ≤ 0.12 V; tiers armed and initialised; **MCLK_EN read back = 1, MCLK_PERMIT = 1, PB1 = 1**; DAC locked and soft-muted; no lock-out.
14. [FW] RELAY_EN high ([HW] closes only with N2_MCLK_OE high (Q616, D-19) and H (Q617)); volume ramp **≥ 10 ms** later (TLP3545A tON over temperature, protection R2.4) and ≥ 10 ms after lock.

**C. Suspend / bus reset / host disconnect** (suspend current ≤ 4.16 ms after the last SOF, margin 5.84 ms; `firmware_sequences` §2)
1. [FW] SOF-loss 1.0 ms → **RELAY_EN low at once** (no mute wait: no SOF = no data, FIFO outputs zeros) (D-16).
2. [FW] Wait 1.1 ms (switch open ≤ 1.01 ms) [HW-bounded by the photorelay].
3. [FW] I²C: ES9018K2M **reg 14 = 0x03** (soft_start 0, soft_start_time 3 → outputs ramp to ground in 0.819 ms at 80 MHz; analog R2, keeps the open-switch COFF coupling at 0.13 mV instead of 12.8 mV at 300 Ω); **wait 1.1 ms** with MCLK running. If the write is not ACKed within 0.5 ms, continue (switch already open).
4. [FW] MCLK_PERMIT low (X201 stopped ≤ 0.2 µs, Q616 off) → PB1 = 0; SPI CLOCK_CTRL = 0 (MCLK_EN, OSC48_EN, OSC44_EN), I2S_CTRL = 0.
5. [FW] DAC_RESETB low.
6. [FW] AUD_EN + AVCC_EN low in one GPIOC write ([HW] EN-derived discharges: 3V3A ≤ 0.35 ms, 3V3D ≤ 0.53 ms, 1V3 first).
7. [FW] After 0.53 ms: RAIL_EN, ANA_EN, ILIM_HI low, LEDs off, link pins low (I/V rails held until both discharges end — analog S6).
8. [FW] Stop mode, USBHS PHY suspended; ENs stay low ≥ 1 ms. The next init writes reg 14 = 0xAA again (reset restores 0x8A anyway).

**D. Resume**
1. [FW] Stop exit + HSE ≤ 4 ms + PLL ≤ 0.2 ms + PHY PLL ≤ 1 ms [ASSUMP] = 5.28 ms (≥ 30 ms available); answer the bus; then B from step 1 (CPLD reconfigures; all CPLD and DAC registers rewritten).

**E. Rate change within a family (switch closed)** (worst 265 ms)
1. [FW] reg 8 = 0x20 (GPIO2 = minimum volume); soft mute; wait GPIO2 high (timeout 1.5 × ramp, ≤ 69.4 ms).
2. [FW] I2S_RUN = 0; **MCLK_EN and MCLK_PERMIT stay high** (N2_MCLK_OE high → Q616 stays on; protection requirement); set divider, prime FIFO, I2S_RUN = 1; reg 8 = 0x10.
3. [FW] Lock within 1.5 × 16384/fs + 10 ms, +10 ms; LRCLK_FB ±0.1 % over 100 ms; DPLL ratio ±0.1 %; failure → stay muted, retry once, then fault. Clock Validity true only after lock.
4. [FW] Unmute. Option (no board change): RELAY_EN low around steps 2–3 with full pre-close checks if the [MEAS] of the DAC output during lock loss shows a pop.

**F. Family change** — as E, plus: enable the new NDK, wait ≥ 10 ms, switch (48→44.1: OSC44_EN also selects the mux; 44.1→48: clear OSC44_EN last), old one to stand-by ([HW] mux: no contention). Worst 480 ms; MCLK never touched.

**G. Faults**
1. [HW] Leg window, CM window or rail collapse → H low → switch open ≤ 1.22 ms; re-close only after 52–155 ms and only if RELAY_EN is high.
2. [FW] DC_PERMIT_N rising (EXTI3 both edges, top priority): RELAY_EN low ≤ 50 µs; freeze the last 0.5 s of readings; soft mute; class DC (a reading ≥ T2 level) or CM/clock.
3. [FW] Tiers every 1.000 ms on pair-averaged 10 kHz samples: T1 0.900/0.900 V (100 ms), T2 0.240/0.230 V (300 ms), T3 0.110/0.118 V **[R3 ↑: pair 0.120 V, R3.2 G]** (1.2 s), leg/pair, windows initialised at arming → RELAY_EN low, log.
4. [FW] Overload: RAILS_OK_N high (valid) or ANA_FAULT_N low (ANA_EN high) → RELAY_EN low, C.2–C.6, ceiling −3 dB per event to −12 dB, retry ≥ 1 s (strike counted only at −12 dB).
5. [FW] Stream guard before the link: CIC² of two 50 ms means ≥ 0.30 FS, or 26 ms flat (range ≤ 1e-3 FS, |mean| ≥ 0.02 FS) → zero the pair with a 1 ms ramp; release after |D| < 0.05 FS for 1 s; no RELAY_EN action.
6. [FW] Retry after 2 s through the full pre-close checks; 3 DC/CM trips in 10 s → locked until replug, red LED. A fault (or host-commanded) power-down with the rails up follows C.2–C.7 incl. the reg 14 = 0x03 ramp (host-commanded stops while playing soft-mute first); if the rails already collapsed, AVCC_EN low at once.
7. [FW] CPLD_IRQ (FIFO under/overflow): log; underflow outputs zeros.

**H. Unplug / brown-out**
1. [FW] AWD (5V_SYS < 4.00 V) ISR, top priority (analog R2): **RELAY_EN (PA11) and AVCC_EN (PC11) low in back-to-back writes** (< 0.1 µs apart — different GPIO ports), **no 1.1 ms wait**: X201 stops ≤ 0.2 µs later through U206 input B (Q616 off, D-19), 3V3A discharges ≤ 0.35 ms → DAC-pin clamp exposure ≤ 0.62 ms instead of ≤ 4.9 ms; then MCLK_PERMIT/MCLK_EN low, RESETB low, AUD_EN low, rails after 0.53 ms while 3V3M holds. The one deliberate exception to Always-3: AVCC changes while the switch may still be closed for ≤ 1.01 ms (unplug pop stays a [MEAS] target); RESETB still never goes low before the switch is open.
2. [HW] Hard unplug: photorelay LEDs drop out (switch open ≤ 1 ms); MCU PDR → I.1. Unplug pop stays the analog [MEAS] target.

**I. MCU reset / IWDG**
1. [HW] R646 (RELAY_EN) and U206 Y → Q616 (D-19) open the switch ≤ 1.002 ms; **R234 stops X201 ≤ 0.39 µs** (27.6 µs before 3V3A can move); ENs → pull-downs → domains off and discharged; R511 → Default ILIM; R305 → DAC reset.
2. [FW] After reset: A (low clock ≥ 5.2 ms, IWDG), log the reset cause, re-enumerate.

**J. Programming mode (D-15)**
1. [FW] PROG (PC13) low at reset; MCLK_PERMIT, DAC_RESETB, RELAY_EN, ILIM_HI low.
2. [FW] ANA_EN → ≥ 5 ms → RAIL_EN → rails good → AVCC_EN → ≥ 1 ms → AUD_EN; release CPLD_NRST; J202 programs the CPLD. Source ≤ 500 mA (charger/bench); digital share ≤ 158.1 mA.
3. [HW] MCLK off whatever the CPLD ISP pull-ups do (MCLK_PERMIT low → U206 Y low); DAC in reset; switch open three times over (RELAY_EN low, Q616 off via N2_MCLK_OE, H low from the CM window). **DC_PERMIT_N high is expected here — not a fault.** Exit only by reset.

## R2.6 Conflicts found and their resolution

| # | Conflict | Resolution |
|---|---|---|
| C-1 | Suspend trigger: protection §10.2 "RELAY_EN low at the suspend interrupt (3 ms)"; analog §13-3 "wait max release time 5 ms [PH]" | D-16: SOF-loss 1.0 ms, wait 1.1 ms (photorelay ≤ 1.01 ms) |
| C-2 | Analog §13-3: mute and wait GPIO2 before RELAY_EN (up to 69 ms) | skipped in suspend (stream already silent, 10 ms budget); kept for host-commanded stops while playing |
| C-3 | Power-down order: analog §13-3 (AVCC_EN → 3V3A < 0.3 V → rails → RESETB → AUD_EN), power §6.5 (AUD_EN + AVCC_EN together), round-1 digital (mute → MCLK_EN → 1 ms → AVCC_EN) | RELAY_EN → 1.1 ms → reg 14 = 0x03 ramp to ground (0.3 ms I²C + 1.1 ms, analog R2) → PERMIT/MCLK_EN → RESETB → AUD_EN + AVCC_EN → 0.53 ms → RAIL_EN/ANA_EN: meets analog S3–S7 (MCLK stops before VCCA, RESETB low before 3V3D, rails held until both discharges end) and power timing; suspend 4.16 ms |
| C-4 | Programming mode: power §7 (ANA_EN/RAIL_EN low) | D-15 (rails up to AUD_EN); power recomputes S5 |
| C-5 | RAILS_OK_N validity: protection "ANA_EN high ≥ 20 ms" vs power "ANA_EN = RAIL_EN = 1, ≥ 20 ms after RAIL_EN" | power's (stricter) |
| C-6 | U206's third input (and AVCC_EN) could stop MCLK with MCLK_EN high → Q616 stays on → frozen code on closed legs (protection's 35.8 mJ-at-16 Ω residual) — a gap created by the 3-input gate | **accepted, D-19**: protection feeds R645 from N2_MCLK_OE (U206 Y) → every MCLK stop opens the switch in hardware (Q616 gate < 0.45 V in 1.99 µs, switch ≤ 1.002 ms; ≤ 1.204 ms via R235 with U206 unpowered); R235 defines the node while U206 is unpowered; PB1 reads it back (boot self-test) |
| C-7 | Uncalibrated level: brief §4 "pre-calibration default −4.5 dB" vs analog §8 "−3.0 dB (0x5A9DF7AB)" | **closed**: −4.5 dB = master trim 0x4C3EA838 (reg 20…17 = 4C 3E A8 38), agreed by analog (R2.16, 25 Sep 06:10; uncalibrated level 0.985–1.290 Vrms per leg); the round-1 analog −3.0 dB (0x5A9DF7AB) is superseded |
| C-8 | ADC: protection "5 channels, ≥ 28.5 cyc at 14 MHz, 10 kHz"; round-1 digital 239.5 cyc, 6.8 kHz | D-13 with TS 71.5 at 12 MHz, 7 channels, 20.41 kHz, dual-simultaneous DMA; coupling/alias term to protection |
| C-9 | D-3 part (Epson SG-210STF 75 MHz) obsolete (R2.1.4) | **resolved, D-3 revised**: Kyocera KC2520K80.0000C1GE00, 80 MHz; NDK NSC5338D-80M conditional; TXC withdrawn; same land and netlist |
| C-10 | MCLK start: analog "MCLK_EN ≥ 2 ms after 1V3", power "AUD_EN → ≥ 2 ms → MCLK_EN", X201 enable ≤ 2 ms (spec) / 3 ms (catalogue), NDK 4 ms | enable ≥ 3 ms after AUD_EN; RESETB ≥ 7 ms after the enable (covers the conditional NDK) |
| C-11 | Protection §8.3 checks MCLK_EN only | adds MCLK_PERMIT = 1 and PB1 = 1 (PB1 is now the actual Q616 permit signal, D-19) |
| C-12 | Checker IFACE still lists AMP_EN and DOM_DIS | retired by D-11; checker list outdated (only "iface_absent" issues left) |
| C-13 | Protection R2.13-1: ADC2 per-channel TS 13.5 (sense) / 28.5 (CC), timer-triggered 20 kHz, 8 conversions | adopted: 20.000 kHz TIM4 trigger and the 8-conversion order; **one TS = 41.5 cycles** for all channels because dual simultaneous mode (ADC1 IN1 in every slot) needs aligned slots; per-channel TS only if ADC2 DMA is proven (firmware option) |
| C-14 | Protection p09: "the dummy makes the reference see ΔV = 0" | not so with 4.7 µF nodes — the DC term stays 1.79 mV on legs (bound 3.59 mV per channel); protection to add it: T3 0.169 V (bound 0.174 V) < 0.2 V |
| C-15 | Protection R2.7/R2.13-3 still use 75 MHz (soft start 111.9 ms, pre-close ≤ 411 ms) and R2.13-4 says "R645 unchanged" | D-3 revised: 104.9 ms; protection's 25 Sep 06:04 correction adopted with the soft-start end at the ×1.2 allowance → pre-close ≤ 425.8 ms (515.8 ms with the CPLD timeout); D-19 done on both sides (R645 pin 1 = N2_MCLK_OE) |
| C-16 | Volume ramp after RELAY_EN: 5 ms (round 1) vs 10 ms (protection R2.4) | 10 ms (TLP3545A tON × 2 over temperature) |
| C-17 | Analog R2 brown-out rule (RELAY_EN and AVCC_EN low together, no wait) vs Always-3 (switch open before any analog change) and C-3 | accepted as the single exception (limits DAC-pin clamp exposure to ≤ 0.62 ms); MCLK still stops first in hardware (U206 B), RESETB still after the switch opens; the two pins are on different ports → back-to-back writes |
| C-18 | D-16 "suspend current ≤ 2.76 ms after the last SOF (digital CALC)" vs the analog ramp-to-ground step (+1.40 ms) | **4.16 ms**, margin 5.84 ms to 10 ms; the analog list's leading "mute" is skipped in suspend (no SOF = no data); orchestrator to note the new number |

## R2.7 Pin map against the other streams (task 6)

| Signal / MCU pin | Other stream (their part) | Check |
|---|---|---|
| RELAY_EN / PA11 push-pull, floating at reset | protection **R662/R663** (LED-sink reference, 105.1 kΩ) + **R646 100 k pull-down** = 66 µA, no capacitor | ✓ in protection netlist; floats → R646 → switch open ≤ 1.010 ms; USBFS/USBD never enabled (PA11/PA12 are their pins); RELAY_EN high only with AUD_EN high (U604 is on 3V3D) |
| DC_PERMIT_N / PB3 (FT) input, no pull, **EXTI3 both edges** | protection Q618 drain + R648 100 k to 3V3M | ✓ |
| ANA_FAULT_N / PB5 (FT) input, no pull, EXTI5 | power: **TPS259621 FLT** (open drain) + R512 100 k to 3V3M (D-5) | ✓ in power netlist (U503 pin 6 FLT); FLT de-asserted while EN is low [TPS2596 DS] → validity rule A-4 |
| RAILS_OK_N / PB4 (FT) | power R522 10 k series + **R532 470 k** pin-side (D-8) | ✓ R532 in power netlist (at the PB4 pin); high 3.22–4.76 V (≤ 5.0 V VIH max), low ≤ VOL + 30 mV (`levels` 1) |
| ILIM_HI / PA15 (floating at reset) | power **U505 TMUX1101 SEL** (logic 1 = on = High limit; fail-safe to 5.5 V) + **R511** pull-down (D-5) | ✓ in power netlist (U505 pin 4 SEL, VDD 3V3M, R511); floating PA15 at reset → R511 → Default |
| MCLK_EN / CPLD pin 21 (8 mA, reset 0), R218 10 k | U206 input A only (protection tap moved, D-19) | ✓; CPLD holds MCLK_EN during rate/family changes |
| N2_MCLK_OE / U206 Y + R235 + PB1 readback; MCLK_PERMIT / PB14 + R234 | protection **R645 1 k → Q616 gate** (≤ 1 nF), **accepted D-19** | ✓ Y load R235 34 µA + gate leakage; ≤ 1 nF behind 1 k (≤ 3.3 mA transient); Q616 gate < 0.45 V 1.99 µs after Y falls, switch open ≤ 1.002 ms (≤ 1.204 ms via R235 if U206 is unpowered); ✓ protection netlist has R645 pin 1 on N2_MCLK_OE (25 Sep 05:55) |
| AVCC_EN PC11, AUD_EN PC10, ANA_EN PC12, RAIL_EN PB8 | power R303/U302/Q502, R508/U504/Q504, R513/U503, R507-R506 | ✓ (ANA_EN → TPS259621 EN/UVLO pending) |
| DAC_RESETB (PA8 via R233), DAC_LOCK PC9, I2C PB10/PB11, MCLK (R203) | analog U301-28 (R305), U301-23, U301-3/4, U301-7 | ✓ (analog U301-7 note reads Kyocera KC2520K80, 80.000 MHz, D-3 revised — re-checked 06:10) |
| VBUS_SENSE PA1; CC1/2_ADC PA2/PA3 | power R105/R106/C103; R103/R104 (+R101/R102, U103 at J101) | ✓ |
| DC_SENSE_LP…RN PC0–PC3; V3A_MON PC4 | protection R624–R635, R639/R640/R661, C608–C611/C616 | ✓ |

## R2.8 Integration check (`check_design.py power protection analog digital`, 25 Sep 2026, after the protection round-2 alignment)
309 parts, 177 nets, 936 pins; **issues: none** (the AMP_EN/DOM_DIS "iface_absent" entries of the earlier runs are gone). In the other streams' files and consistent with mine: R532 on RAILS_OK_N, U505 TMUX1101 SEL on ILIM_HI, TPS259621 FLT (U503 pin 6) on ANA_FAULT_N, protection R645 on **N2_MCLK_OE** (D-19; net = U206 Y, X201 INH, R235, PB1, R645), R662/R646 on RELAY_EN. The analog U301-7 note reads 80 MHz; the protection report carries 80 MHz and D-19 in its 05:53 addendum (its round-1 text, e.g. "Q616 gate MCLK_EN", is superseded there).

## R2.9 New numbers and superseded round-1 numbers

| Item | Round 1 (superseded) | Round 2 (final) |
|---|---|---|
| X201 | SCTF SX3M80, 80 MHz, 40 mA, OE, no disable time | **Kyocera KC2520K80.0000C1GE00, 80 MHz, 8.17 mA incl. R227, stand-by 5 µA, t_dis ≤ 200 ns** |
| MCLK/FSR at 384 kHz | 208.3 (+8.5 %) | 208.31 worst (+8.49 %) |
| MCLK min pulse at 50 % | 5.625 ns | 5.51 ns (incl. R203 skew) |
| INH/OE drive margin | 74LVC1G08 vs 0.7/0.3 VDD | 74LVC1G11 VOH ≥ VCC − 0.1 V vs 0.7 VCC: ≥ 0.86 V |
| Soft start (reg 14 = 0xAA) | 104.9 ms (126 ms wait) | 104.9 ms (125.8 ms wait), F_MCLK = 80 MHz |
| DPLL check | × 80 MHz / 2³² (no table) | table at 80 MHz, ±0.1 % (R2.1.2) |
| MCU-reset MCLK stop | gate ≤ 6 ns + X201 [MEAS] (and a lost race at the corners) | ≤ 0.39 µs [DS], margin 27.6 µs |
| MCLK stop → output switch | only via MCLK_EN (Q616) | every stop via N2_MCLK_OE → R645 → Q616 (D-19) |
| RESETB after MCLK enable | ≥ 1 ms after MCLK stable | ≥ 7 ms after the enable |
| ADC | ADC1 TS 55.5; ADC2 7 × 239.5, 147 µs, 6.8 kHz | dual-simultaneous DMA, TIM4-triggered 20.000 kHz, 8 conversions (protection order), TS 41.5 on all, 36 µs |
| VBUS AWD latency | ≤ 11.3 µs + ISR | 8 conversions per 50 µs (gap ≤ 18.5 µs); C103 τ 0.32 ms dominates |
| Volume ramp after RELAY_EN high | 5 ms | 10 ms |
| Suspend current reached (from the last SOF) | — (round 1: after the 3 ms suspend interrupt) | 4.16 ms incl. the reg 14 = 0x03 ramp step (margin 5.84 ms) |
| Permit before RELAY_EN | "H recovered ≤ 155 ms" | poll DC_PERMIT_N: ≤ 205 ms after the soft-start end (taken at init + 125.8 ms), fault at 300 ms; pre-close ≤ 425.8 ms (515.8 ms with the CPLD timeout) |
| 3V3D digital share | 102.5 mA | 70.6 mA (family change +15.3 mA) |
| 3V3M digital share | 82.1 mA (incl. IPD) | 81.13 mA (IPD moved to 3V3D) |
| Before configuration | 80.7 mA | 80.76 mA |
| Suspend (digital) | 1.9 mA [ASSUMP] | 1.9 mA [PH] unchanged |
| Programming mode | 184.6 mA (MCLK counted) | 158.1 mA (D-15, X201 stand-by) |
| U206 | 74LVC1G08, 2 inputs | 74LVC1G11, 3 inputs + R234, R235, PB1 readback, feeds R645 |
| C217 (X201 bypass) | 100 nF | 10 nF HF type at the pad |
| GPIO spare | PC14, PC15, PA0, PB0, PB1, PB14 | PC14, PC15, PA0, PB0, PA12, PB9 |

## R2.10 Interface requests (round 2)
**Orchestrator / parts**: (1) X201 = Kyocera KC2520K80.0000C1GE00 per D-3 revised — order through JLCPCB global sourcing (LCSC C1988889 not stocked); land unchanged (combined 2520/3225, pad 1 at the same corner); (2) confirm R235 = C25741, C217 = C15195 (10 nF 0402 X7R) and TP732 vs TP737; (3) test pad TP724 on N2_MCLK_OE (round-1 proposal) — it is now the Q616 permit signal as well.
**Protection** (answers to your R2.13): (1) D-19 ✓ — your netlist has R645 on N2_MCLK_OE; please update your R2.13-4/§3.4 text ("R645 unchanged", "gate MCLK_EN"); (2) ADC: adopted your 20 kHz timer-triggered 8-conversion order, but with one TS = 41.5 cycles (dual simultaneous mode, R2.6 C-13); estimator block = 1.000 ms / 20 samples per channel; (3) add the reference-coupling DC term (R2.3): 1.79 mV on legs (bound 3.59 mV per channel) — the dummy does not remove it; (4) MCLK is 80 MHz (D-3 revised): soft start 104.9 ms; your 06:04 correction adopted with the soft-start end at the ×1.2 allowance (ESS does not fix the ramp start) → DC_PERMIT_N low ≤ 375.8 ms, pre-close ≤ 425.8 ms (CPLD 10 ms) / 515.8 ms (100 ms); Q616 gate ≤ 1 nF → < 0.45 V in 1.99 µs; (5) volume ramp 10 ms after RELAY_EN, 1.1 ms after RELAY_EN low, DC_PERMIT_N polling with the 300 ms timeout, and "DC_PERMIT_N high expected in programming mode" are in R2.5; (6) pre-close additions: MCLK_PERMIT = 1 and PB1 = 1 (PB1 is the Q616 permit itself).
**Power**: (1) digital loads per R2.4 (X201 + R227 8.17 mA; IPD 0.56 mA now on 3V3D; R235 0.033 mA); (2) S5 programming mode now follows D-15 (rails up): digital share 158.1 mA worst; (3) R532, U505 SEL on ILIM_HI and TPS259621 FLT (pin 6) on ANA_FAULT_N are now in your netlist ✓ — please confirm the FLT behaviour during the dVdt start-up (firmware ignores ANA_FAULT_N for 5 ms after ANA_EN [ASSUMP] until you confirm); (4) round-1 request 4 (3V3D vs 3V3A during a hard unplug while MCLK runs) is still open; (5) confirm 1V3 (TLV75801P) is in regulation ≤ 1 ms after AUD_EN rises (MCLK enable timing, R2.5 B.7).
**Analog** (answers to your R2): (1) 80 MHz constants confirmed — soft start 104.9 ms, wait × 1.2 = 125.8 ms after the I²C init, FSR = DPLL_NUM × 80 MHz / 2³²; U301-7 note ✓ (80 MHz since your 05:50 regeneration — my earlier remark was stale); (2) your power-down step is in R2.5 C.3 (reg 14 = 0x03, 1.1 ms, then MCLK stop, RESETB, AUD_EN + AVCC_EN) and applies to suspend, faults with the rails up and host-commanded stops; your leading "mute" is skipped in suspend (no data), kept for host-commanded stops; suspend 4.16 ms; (3) brown-out ISR per your rule (H.1): PA11 and PC11 are on different ports → back-to-back writes < 0.1 µs apart; (4) never soft_start = 0 / soft_start_on_lock = 1 / RESETB low while the switch can be closed — Always-1 (the reg 14 = 0x03 write comes 1.1 ms after RELAY_EN falls); (5) C-7 closed: uncalibrated trim −4.5 dB = 0x4C3EA838, agreed (your R2.16); (6) MCLK load at XI 13.1 pF incl. trace.

## R2.11 Open items added in round 2 (measurements with designed-in fallbacks) and what I could not verify
| # | Item | Fallback (no board change) |
|---|---|---|
| R2-1 | MCLK duty/pulse widths at XI (Kyocera 45–55 % = ESS limit) [MEAS] | R203 → 0 Ω (BOM value) |
| R2-2 | Kyocera phase jitter (catalogue 1.0 ps max, not in the spec text) [MEAS: J-test, phase noise] | none needed for THD+N/DR (even 5 ps gives 124 dB at 20 kHz FS); NDK conditional second source |
| R2-3 | NDK NSC5338D-80M only if fitted: disable time ≤ 10 µs, XI edges/swing [MEAS] | Kyocera part; R203 → 0 Ω |
| R2-4 | ADC coupling term (CADC residual model) [MEAS: inject known CC voltages, read the ref shift] | timer-triggered 10 kHz scan (firmware) halves it |
| R2-5 | PB1 self-test timing and U206/R234 function at every boot [firmware test, logged] | fault → no MCLK, no switch permit, red LED |

**Not verified (plainly):** the CH32V307 RM DMA request table (ADC2 DMA absence is inferred from WCH's dual-ADC example and STM32F1 heritage, so the design avoids needing it); whether CH32V307 regular-simultaneous mode requires equal sampling times (equal TS chosen, so the question does not matter); CH32V307 standard-I/O VIH/VIL rows and internal pull resistance (30 kΩ assumed); the Kyocera stand-by output level and INH input current (not stated; R227 and the 100 µA drive rows cover them); the Kyocera phase-jitter maximum (catalogue value from parts FU-3); NDK NSC5338D-80M data (taken from parts FU-3); the USB Type-C Rp/threshold values (recalled, not re-read); TPS2596 FLT timing at start-up; the ESS XI input threshold and leakage (not specified); all MCU/CPLD currents remain [ASSUMP].

## R2.12 Files changed in round 2
`report.md` (this section; round-1 numbers marked [R2 ↑]); `bom_rows.csv`, `netlist.csv` (via `gen_netlist_bom.py`); `clock_timing.py/_output.txt` (§4–5 rewritten for 80 MHz); `mclk_gate_race.py/_output.txt`; `levels_and_pullups.py/_output.txt` (§6–8); `adc_settings.py/_output.txt` (new plan); `currents.py/_output.txt` (rewritten); `firmware_sequences.py/_output.txt` (§1–9); `stress_table.py/_output.txt`; `pin_tables_output.txt`; `sources/Epson_SG-210STF_X1G0041710027_fullDS_16MHz.txt` (history). Verbatim quotes for round 2: `sources/source_quotes.txt` S12–S18 (Epson sheets and obsolescence listings, WCH dual-ADC example, forum note on channel coupling, 74LVC1G11 pinning, TPS2596 FLT, TMUX1101 SEL, Kyocera spec).

---

# Round 1 report (24 Sep 2026) — numbers superseded in round 2 are marked [R2 ↑]

## 0. Summary of decisions

| # | Decision | Why (evidence) |
|---|---|---|
| D1 | **X202 = NDK NZ2520SDA 49.152 MHz, X203 = NDK NZ2520SDA 45.1584 MHz** (spec NSC5083D, 3.3 V), stand-by pin 1. The CPLD PLL is not used. | Both frequencies are NDK standard frequencies. Datasheet gives ≤ 15 mA operating, **≤ 35 µA stand-by with the output high-impedance and the oscillator stopped**, ≤ 4 ms start-up, 43 fs typical phase jitter [DS S7]. BCLK = FAM_CLK ÷ 2/4/8/16 from a toggle register, so the duty is exactly 50 % whatever the oscillator symmetry (40–60 %) [CALC]. |
| D2 | **Fit the 2:1 mux U205 (74LVC1G157). Delete the shared node (R214).** Select S = OSC44_EN. | This is a challenge to baseline §3.5. With the shared node, safety depended on unspecified oscillator disable timing and on the CPLD weak pull-up during configuration. AGM publishes no value for that pull-up (S5 only says "weakly pulled-up") and it has to be weaker than the enable pull-downs. With the mux, contention cannot happen in any state; the enables only save power. This closes v0.8 open items 8 and 9 and removes the DNF board variant. |
| D3 | **[R2 ↑]** (R2.1: X201 = Kyocera KC2520K80.0000C1GE00, 80 MHz, D-3 revised; U206 = 74LVC1G11 with MCLK_PERMIT; D-19) **X201 stays** (SCTF SX3M80.000B20F30TNN, 80 MHz, C5179978). Its **OE is now driven by U206 = MCLK_EN AND AVCC_EN** (74LVC1G08, IOFF). New R227 10 kΩ pull-down holds XI low while X201 is disabled. | R8-B3 needs a hardware MCLK stop that works without firmware or SPI. If the MCU resets or hangs (IWDG), AVCC_EN floats low, and MCLK then stops within ns–µs, long before 3V3A (VCCA) decays. ESS standby requires external MCLK "stopped at logic low level" [DS S11 p.7]; in v0.8 the XI pin floated. A 9 mA NDK 80 MHz alternative was rejected (Mouser lists it obsolete). The land pattern accepts a 2520 part as a no-respin upgrade. |
| D4 | **No MISO data at 36 MHz.** The MCU derives the CPLD FIFO level itself from words written minus 2 × LRCLK_FB counts (TIM3). Register reads run as separate transactions at SPI1 ÷8 = 9 MHz. | This closes R8-C minor. The read loop has −1.0 ns margin at 36 MHz, +12.9 ns at 18 MHz and +40.7 ns at 9 MHz [CALC with assumed tsu(MI)]. |
| D5 | USB feedback: 44.1 kHz = **0x00058333** (was 0x002C1999, wrong by 8×). The full table is in §7 and is generated with assertions. | Fixes R8-B1. |
| D6 | **R8-D7 is not a real risk on the CH32V307.** The part has no JTAG. At reset PA13/PA14 are SDI (SWDIO/SWCLK) and PA15/PB3/PB4 are plain GPIO [DS S3, SDK S4]. ILIM_HI stays on PA15, RAILS_OK_N stays on PB4 (FT). | See §5.2. |
| D7 | CPLD: poll an ID/ready register before any enable write. CPLD_NRST is driven by an MCU open-drain pin (PC5) plus a pull-up (§4A.2). | Closes R8-D4. AGM publishes no configuration time. |
| D8 | Bit-perfect plan: an on-board I²S capture (3 × 330 Ω taps into the MCU I2S2 slave receiver) plus an external capture on J703. Test patterns cover every rate and format. | Closes R8-B10 (§9). |
| D9 | **[R2 ↑]** (R2.3: dual-simultaneous DMA, TS 71.5 on all channels, 20.41 kHz) ADC: fADC = 12 MHz. VBUS_SENSE uses TS = 55.5 cycles (≤ 50 kΩ source). The ADC2 scan uses 239.5 cycles. | Closes R8-B4/D6 on the ADC side (§6). |
| D10 | Enable pull-downs R212/R213/R218: 2.2 kΩ → 10 kΩ. I²C pull-ups: 2.2 kΩ → 4.7 kΩ at 100 kHz. | The enable pull-downs are no longer safety-critical. At 10 kΩ they draw 0.34 mA each instead of 1.54 mA (R8-D2). ES9018K2M VOL is specified only at 100 µA [DS S11 p.29]. |

---

## 1. R8 findings in the digital scope — dispositions

| ID | Finding | Disposition | Status |
|---|---|---|---|
| R8-B1 | 44.1 kHz feedback 8× too large | Fixed: 0x00058333. All eight values come from `usb_feedback.py` with assertions. The old value equals floor(352.8 kHz) [CALC]. | Closed – design + calc |
| R8-B3 | MCLK not explicitly stopped at a fault; behaviour without SPI/MCU undefined | Firmware order (mute → MCLK_EN = 0 → 1 ms → AVCC_EN low) **plus** the U206 hardware gate (X201 OE = MCLK_EN AND AVCC_EN) and R227 holding XI low. MCU reset or hang → AVCC_EN pulled low → MCLK stops within gate tpd ≤ 6 ns [DS] plus the X201 disable time. SCTF gives no disable time; a typical XO needs < 1 µs [MEAS]. **[R2 ↑]** Kyocera t_dis ≤ 200 ns [DS]: stop ≤ 0.39 µs incl. R234/U206; every stop also opens the switch (D-19) (R2.1.3). 3V3A needs ≥ several 100 µs to decay (power stream). XI is scoped in the failed-output test and in the MCU-reset test (§9.3). | Closed – design; [MEAS] disable time |
| R8-B4 / R8-D6 | VBUS_SENSE 32 kΩ with 7.5-cycle sampling | **[R2 ↑]** TS 71.5 (R2.3); round 1: TS = 55.5 cycles at 12 MHz gives 50 kΩ allowed (43.5 kΩ at 41.5 cycles) [CALC from DS Tab 4-42 formula]. ADC1 stays single-channel continuous. No capacitor is required. Analog-watchdog latency ≤ 11.3 µs + ISR [CALC]; the < 5 µs target is dropped (brief §3.4). | Closed (divider values are power stream's) |
| R8-B10 | Lock + FFT does not prove bit-perfect | §9: I²S word capture compared with known patterns (walking ones, LFSR, extremes, L/R markers), 8 rates × 3 formats, on-board and on J703. | Closed – test plan |
| R8-C minor | FIFO-level readback on MISO at 36 MHz vs ≤ 18 MHz | D4: no MISO data at 36 MHz. The FIFO level is computed from TIM3 LRCLK counts. Register reads run at 9 MHz. | Closed |
| R8-D2 (digital part) | Enable/node pull-down current 3.0/3.3 mA | Now ≤ 1.02 mA with ≤ 3 enables high (0.68 mA steady) [CALC]. | Closed |
| R8-D4 | "Instant-on" needs a number; poll ID/ready | AGM gives no time (S5: "CFM automatically downloads … during power-on"). Rule (§4A.2): poll ID every 1 ms, 100 ms timeout, then one CPLD_NRST retry. Timing is [MEAS]; no function depends on it. | Closed – rule; [MEAS] time |
| R8-D7 | PA15/PB4 JTAG reset pull-ups | Not applicable to the CH32V307: SDI 2-wire only; PA15/PB3/PB4 are GPIO at reset [DS S3, S1 "Debug mode: 2-wire serial debug interface (SDI)"; SDK S4 has only `GPIO_Remap_SWJ_Disable`]. | Closed – verified (see §15 caveat) |
| R8-A8 | PGOOD → PB4 only because PB4 is FT | Kept on PB4 (FT, VIN max 5.5 V [DS S2 Tab 4-1]). **New finding:** the FT limit is 5.5 V, but 5V_ANA can exceed 5.5 V up to the OVP trip point. Request to the power stream (§13). | Open → power stream |
| R8-D1/B11/C2 (digital part) | DAC state during clock stop / reset | MCLK held low when stopped (R227). DAC RESETB/MCLK order is set by firmware (§8.4). Pop analysis stays with the analog stream. | Interface |

---

## 2. Top-down: requirements affected by this block

| Requirement (brief §4) | Digital contribution | Met? |
|---|---|---|
| PCM 44.1–384 kHz, 16/24/32 bit, exact integer ratios, 50:50 BCLK | FAM_CLK ÷ 2/4/8/16, all eight rates are exact integers, duty 50.0 % by construction, ≥ 47.9 % at the DAC pin worst case [CALC]. | Yes |
| UAC2 HS, Windows/macOS/Linux/Android | HS async iso OUT + 4-byte 16.16 feedback EP (Windows requires wMaxPacketSize 4 [S10]); descriptors in §7.2. | Design; host test [MEAS] |
| THD+N, DR | MCLK jitter is not limiting: 20 ps rms still gives 112 dB at 20 kHz FS [CALC]. BCLK jitter is rejected by the ESS DPLL. | Yes (J-test [MEAS]) |
| Protection works without firmware | MCLK stops in hardware on MCU reset (U206). The relay/permit path belongs to the protection stream. | Yes (digital part) |
| Pop ≤ 5 mV at rate/family change | Soft mute and lock sequence (§8.4). ES9018K2M `mute_on_lock` is recommended. | Analog stream owns the number |
| Before configuration ≤ 100 mA; suspend ≤ 2.5 mA | **[R2 ↑]** 80.76 mA / 1.9 mA (R2.4). Digital share: 80.7 mA before configuration, 1.9 mA suspend. **Both rest on the MCU [ASSUMP]** (§10). | Budget to power stream; [MEAS] |
| Thermal 50 °C | TJ: MCU ~64 °C, CPLD ~56 °C [CALC with assumed θJA]; all parts rated to 85 °C. | Yes |
| PCB/JLCPCB | All SMT, leaded except CPLD and oscillators; global sourcing for NDK X202/X203. **[R2 ↑]** X201 = Kyocera via global sourcing (R2.1.1). | Yes |

---

## 3. Architecture challenges and simplifications

1. **Mux instead of shared node (D2).** The shared node needs every oscillator output disabled (Hi-Z) whenever the other runs, in all CPLD states, including configuration with weak pull-ups of unknown strength. `levels_and_pullups.py` shows that a 10 kΩ pull-down only holds stand-by if the opposing pull-up is ≥ 23.3 kΩ. That cannot be verified, because AGM gives no value (S5). With the mux the question disappears. Removed: R214, the break-before-make **safety** requirement (the ≥ 1 ms gap), the DNF variant and v0.8 open items 8 and 9. Added: U205 (already in the BOM), C222. R215/R216/R217 change from DNF to fitted. A separate select line (extra CPLD pin + pull-down) was considered and dropped: S = OSC44_EN selects X203 exactly while it is enabled, which saves one part and one CPLD pin.
2. **Hardware MCLK gate (D3).** **[R2 ↑]** now a 3-input 74LVC1G11 with MCLK_PERMIT (PB14 + R234), R235 and the PB1 readback (R2.0, R2.1.3). One SOT-363 (6-pin SOT363-2, B-16) gate plus one capacitor makes MCLK safety independent of firmware, SPI and CPLD state. It covers the configuration pull-up case, a blank CPLD, MCU hang/reset and firmware ordering errors. An alternative was considered and rejected: powering X201 from 3V3A would also make back-power impossible, but it puts 40 mA of 80 MHz switching current on the DAC reference LDO.
3. **No PLL.** This removes the dual-frequency PLL-lock risk (R5/DG-11) and the VDDA33 filtering concern. VDDA33 stays powered, with 100 nF, because it is a supply pin (§4A.3).
4. **Synchronous-MCLK alternative considered and rejected.** Feeding the ES9018K2M from the family clock (MCLK = 128 × FSR, sync_mode) would remove X201. However, the MCLK would change at every family change, and ESS specifies its performance in asynchronous mode. X201 therefore stays.
5. **Second SPI lane removed.** Worst-case link utilisation is 70.0 % at 384 kHz with one catch-up frame [CALC]. PB12/PB13/PB15 now carry the I²S capture taps and PB14 is spare.
6. **Pull-down values raised** (D10). The FLT/FLT_CLR/ANA_FAULT latch pins are gone (brief §3.7). PB3, PA11 and PA12 are reused for DC_PERMIT_N, RELAY_EN and DOM_DIS. **[R2 ↑]** DOM_DIS retired (D-11): PA12 is spare.

---

## 4. Oscillators and clock plan

### 4.1 Parts

| Ref | Part | Key data | Default / control |
|---|---|---|---|
| X201 | **[R2 ↑]** superseded by Kyocera KC2520K80.0000C1GE00 (R2.1, D-3 revised). SCTF SX3M80.000B20F30TNN, 3225, LCSC C5179978 (stock 2,503) | 80 MHz CMOS, ±20 ppm tol / ±30 ppm stab, **40 mA max** (3C series band 80–160 MHz [DS S8, R14]), duty 45–55 %, tri-state pin 1. Phase noise and disable time: not specified. | OE = U206 Y = MCLK_EN AND AVCC_EN. Off by default: R218 holds A low, B low whenever AVCC_EN is low. XI low when off (R227). |
| X202 | NDK NZ2520SDA-49.152MHZ-NSC5083D, 2520 | 20–54 MHz series; ICC ≤ 15 mA (25 °C); IST ≤ 35 µA; VOL ≤ 0.1 VCC, VOH ≥ 0.9 VCC; tr/tf ≤ 6 ns; symmetry 40–60 %; start-up ≤ 4 ms; ±50 ppm overall; PN −158 dBc/Hz @1 kHz, −172 @100 kHz, jitter 43 fs [DS-typ] (NDKT02-00008_en) [S7]. Pin 1 H/open = run, L ≤ 0.3 VCC = output Hi-Z and oscillation stopped. | OSC48_EN (CPLD pin 2), R212 10 kΩ pull-down → stand-by by default. |
| X203 | NDK NZ2520SDA-45.1584MHZ-NSC5083D, 2520 | as X202 | OSC44_EN (CPLD pin 3), R213 10 kΩ pull-down; also U205 S. |
| U205 | Nexperia 74LVC1G157GW, SOT-363, LCSC C135822 | S=L → Y=I0, S=H → Y=I1; tpd I→Y 1.0–5.0 ns (3.0–3.6 V, −40…85 °C); IOFF [DS S9]. | I0 = X202 (default), I1 = X203. |
| U206 | **[R2 ↑]** 74LVC1G11GW-Q100H (C548242), 3 inputs (R2.0). Nexperia 74LVC1G08GW, SOT-353, LCSC C12512 | AND; inputs 5.5 V tolerant, IOFF partial power-down, tpd ≤ 6.0 ns (−40…125 °C), ICC ≤ 4 µA [DS S9]. | A = MCLK_EN (CPLD pin 21), B = AVCC_EN (MCU PC11). |

Sourcing: X202 is on DigiKey (644-NSC5083D-49.152M, 3,438 in stock on 24 Sep 2026 [S7]) via JLCPCB global sourcing. X203 distributor stock was **not verified**. Designed-in fallback: the X201/X202/X203 lands are a **combined 2520/3225 four-pad pattern**. All candidate parts share pin 1 = OE/ST, 2 = GND, 3 = OUT, 4 = VCC. So SCTF SX3M49.152M20F30TNN (C2901591, 20 mA) and SX3M45.1584M20F30TNN (C2901589, 20 mA) from LCSC stock can be fitted without a board change; power budget for that fallback: ≤ 40 mA for both family oscillators. **[R2 ↑]** D-4: this SCTF fallback is non-compliant (both run, +25 mA, Default power targets not met); the compliant second source is SiT8008 (ST). The same land lets X201 later take a 2520 80 MHz low-noise part.

### 4.2 Clock plan and ratios (`clock_timing_output.txt`)

| fs | FAM_CLK | ÷ | BCLK | FAM_CLK/LRCLK | duty | half period |
|---|---|---|---|---|---|---|
| 48 k / 96 k / 192 k / 384 k | 49.152 MHz (X202) | 16 / 8 / 4 / 2 | 3.072 / 6.144 / 12.288 / 24.576 MHz | 1024 / 512 / 256 / 128 | 50.0 % | 162.8 / 81.4 / 40.7 / 20.3 ns |
| 44.1 k / 88.2 k / 176.4 k / 352.8 k | 45.1584 MHz (X203) | 16 / 8 / 4 / 2 | 2.8224 / 5.6448 / 11.2896 / 22.5792 MHz | 1024 / 512 / 256 / 128 | 50.0 % | 177.2 / 88.6 / 44.3 / 22.1 ns |

- Divide chain: FAM_CLK (CPLD pin 1, IO_GB, global clock) drives a counter. BCLK is a **register** toggled with a clock enable every d/2 cycles, so each half period is exactly d/2 FAM_CLK periods. LRCLK, SDATA and LRCLK_FB are registers updated on the FAM_CLK edge on which BCLK falls. All four outputs come from same-clock output registers.
- ES9018K2M limits [DS S11 p.30]: tDCH/tDCL ≥ 4.5 ns, duty 45:55…55:45, tDS 4.1 ns, tDH 2 ns. Worst case at 384 kHz: the output-asymmetry budget is 1.72 ns → duty ≥ 47.9 % and the shortest phase is 19.5 ns. Assumed pin skew 2.22 ns (TDO spread 0.72 ns [DS S5 Tab 4-2] + 1.5 ns routing [ASSUMP]) → **setup margin 14.0 ns, hold margin 16.1 ns** [CALC].
- FIFO read side runs in the FAM_CLK domain (one 32-bit word per 32 BCLK). The fabric path at 49.152 MHz: a typical 3-LUT path of 6.5 ns leaves 13.9 ns slack [CALC from DS Tab 4-1/4-3]. Clock-tree insertion is not published; the Supra timing report is the sign-off [MEAS].
- **[R2 ↑]** Kyocera 80 MHz: 208.31 worst (+8.49 %), pulses ≥ 5.51 ns at 50 % incl. R203 skew, cycle 12.5 ns (R2.1.2). MCLK: 80 MHz/384 kHz = 208.3 > 192 (+8.5 %) at ±50 ppm. High/low ≥ 5.625 ns at 45:55 against ≥ 4.5 ns; cycle 12.5 ns ≥ 10 ns [CALC, DS p.30]. The X201 → R203 33 Ω → XI (CCLK ≤ 10 pF) time constant is 0.43 ns.
- DAC DPLL lock [DS reg 10]: 16 384 FSR edges (stop_div = 0, required > 96 kHz and for Rev W) take 371.5 ms at 44.1 kHz and 42.7 ms at 384 kHz. Firmware option: stop_div = 5 (2 730 edges, 61.9 ms at 44.1 kHz) for fs ≤ 96 kHz, only when reg 64 bit 5 = 1 (Rev V).

### 4.3 MCLK_EN default and control

- Power-on, blank CPLD or configuration: R218 holds U206 A low, unless an unknown CPLD pull-up overcomes the 10 kΩ. Even then, B = AVCC_EN is low until the MCU starts the DAC analog supply, so X201 is off. If A floats high during a configuration that happens after AVCC_EN (VCCA already up), MCLK may run briefly. That is harmless: XI cannot back-power VCCA while VCCA is powered, and RESETB is low.
- Normal: set MCLK_EN (CPLD reg 0x03 bit 2) only after DVDD is up and AVCC_EN is high. **Every shutdown**: soft mute → MCLK_EN = 0 → wait ≥ 1 ms → AVCC_EN low. **[R2 ↑]** order per R2.5 C / R2.6 C-3 (RELAY_EN first, 1.1 ms, MCLK_PERMIT + MCLK_EN, RESETB, AUD_EN + AVCC_EN). If SPI is unavailable, AVCC_EN low alone stops MCLK through U206.
- Unplug/brownout: X201 (3V3D) and VCCA (3V3A) both follow VBUS down through their LDOs. The power stream must confirm that 3V3D never exceeds 3V3A by > 0.3 V while MCLK runs (interface §13). The U206 gate covers any case where firmware drops AVCC_EN first.

### 4.4 Family change (mux fitted)

The FAM_CLK-domain logic uses asynchronous-assert / synchronous-release reset driven by `I2S_RUN`, so runt pulses at a switch cannot corrupt state.
1. DAC soft mute (reg 7 [1:0] = 11); wait for the ramp: 46.3 ms at 44.1 kHz, 5.3 ms at 384 kHz with vol_rate = 2 [CALC].
2. `I2S_RUN` = 0 (BCLK/LRCLK/SDATA held low, FIFO flushed).
3. Enable the new oscillator. 48→44.1: set OSC44_EN, which also switches the mux. 44.1→48: set OSC48_EN.
4. Wait ≥ 10 ms (2.5 × the 4 ms NDK start-up).
5. 48→44.1: clear OSC48_EN. 44.1→48: clear OSC44_EN (this switches the mux to X202 and puts X203 in stand-by).
6. Set the divider, prime the FIFO to half, `I2S_RUN` = 1.
7. Check: LRCLK_FB rate within ±0.1 % over a 100 ms window, DAC lock_status (reg 64 bit 0), DPLL ratio fs = DPLL_NUM × 80 MHz / 2³² within ±0.1 % (**[R2 ↑]** × 80 MHz, table R2.1.2) (regs 66–69) [DS]. If a check fails: stay muted, retry once, then report a fault.
8. Soft unmute. Worst case ≈ 474 ms [CALC]. MCLK is never touched.

---

## 4A. CPLD AGRV2KQ32 (U202)

### 4A.1 Pin plan (all 32 pins + EP; generated from `netlist.csv`)

The package is QFN-32 4 × 4 mm with 24 user I/O (AGM DS Rev 3.0 Table 5-4 [S5]). Only PIN_1 is IO_GB (global clock input; AGM: "全局时钟信号或 PLL 输入时钟要选 IO_GB 管脚" [S6]). The EP (2.7 mm, LCSC footprint QFN-32_L4.0-W4.0-P0.40-BL-EP2.7) goes to GND.

**Pin budget:** 13 of 24 I/O are used and 11 are spare. The spares are pins 5, 7, 8, 15, 22, 23, 26, 27, 28, 29 and 31; they are configured as inputs with weak pull-up.

| Pin | Name | Net | Note |
|---|---|---|---|
| 1 | IO_GB/PIN_1 | FAM_CLK | only dedicated global clock pin; I2S engine clock (no PLL) |
| 2 | IO/PIN_2 | OSC48_EN | X202 stand-by pin; R212 10k pull-down |
| 3 | IO/PIN_3 | OSC44_EN | X203 stand-by pin and U205 select S; R213 10k pull-down (default: X202 selected) |
| 4 | NRST | CPLD_NRST | soft reset, active low, internal pull-up [AGM guide]; R231, MCU PC5, J202-4 |
| 5 | IO/PIN_5 | NC | spare |
| 6 | VDDA33 | N2_V33_CPLD | PLL unused but supply pin stays powered; C213 100 nF |
| 7 | IO/PIN_7 | NC | spare |
| 8 | IO/PIN_8 | NC | spare |
| 9 | IO/PIN_9 | N2_SCK_CPLD | LINK SCK via R224; to global network through ALTCLKCTRL; weak pull-down |
| 10 | IO/PIN_10 | N2_MOSI_CPLD | via R225; weak pull-down |
| 11 | IO/PIN_11 | LINK_FRAME | weak pull-down |
| 12 | IO/PIN_12 | LINK_MISO | output, register read data |
| 13 | IO/PIN_13 | LRCLK_FB | copy of LRCLK (own output register) |
| 14 | IO/PIN_14 | CPLD_IRQ | FIFO under/overflow, sticky, cleared by register read |
| 15 | IO/PIN_15 | NC | spare |
| 16 | VDD33 | N2_V33_CPLD | C214 100 nF |
| 17 | GND | GND |  |
| 18 | IO/PIN_18 | N2_BCLK_SRC | BCLK output register -> R204 -> BCLK; R228 capture tap |
| 19 | IO/PIN_19 | N2_LRCLK_SRC | LRCLK output register -> R205 -> LRCLK; R229 tap |
| 20 | IO/PIN_20 | N2_SDATA_SRC | SDATA output register -> R206 -> SDATA; R230 tap |
| 21 | IO/PIN_21 | MCLK_EN | register bit, reset 0; U206 input A; R218 10k pull-down; protection tap R645 1k -> Q616 gate |
| 22 | IO/PIN_22 | NC | spare |
| 23 | IO/PIN_23 | NC | spare |
| 24 | JTMS | CPLD_JTMS | 2-wire Compact-JTAG; J202-3 |
| 25 | JTCK | CPLD_JTCK | 2-wire Compact-JTAG; J202-2 |
| 26 | IO/PIN_26 | NC | spare |
| 27 | IO/PIN_27 | NC | spare |
| 28 | IO/PIN_28 | NC | spare |
| 29 | IO/PIN_29 | NC | spare |
| 30 | GND | GND |  |
| 31 | IO/PIN_31 | NC | spare |
| 32 | VDD33 | N2_V33_CPLD | C215 100 nF |
| EP | EXPOSED_PAD | GND | 2.7 mm EP (LCSC footprint QFN-32_L4.0-W4.0-P0.40-BL-EP2.7) to GND |

### 4A.2 Configuration from internal flash; ready/ID rule (R8-D4)

- AGM [S5]: "When power is applied … the POR circuit monitors VDD33 and begins SRAM download"; "The CFM automatically downloads and configures the logic blocks … instant-on". **No time is published.**
- The logic image is 100 KB, ≤ 40 KB when compressed, according to AGM's AG32 logic-settings page (AG32 MCU+CPLD flow; applicability to the pure-CPLD boot is [ASSUMP]).
- I/O during ISP: "tri-stated and weakly pulled-up to VCCIO" [S5 §2.2]. The state during power-on download and the pull-up value are **not published**.
- The design does not depend on either (§3.1, §4.3).
- **Rule:** after AUD_EN (3V3D up per the power stream), the MCU reads ID (reg 0x00) at 9 MHz every 1 ms.
  - Nothing is written until ID = 0xA6D2 and VERSION is as expected.
  - Timeout 100 ms → CPLD_NRST low for 1 ms (MCU PC5 open-drain; NRST is AGM's active-low soft reset with internal pull-up [S6]) → poll again → second failure = fault (red LED, no MCLK/oscillator enable).
- After every CPLD_NRST or 3V3D cycle, all CPLD registers are rewritten.

### 4A.3 Supplies; VDDA33 with the PLL unused

- VDD33 (pins 16, 32) and VDDA33 (pin 6) are fed from 3V3D through FB202 (GZ1608D601TF, 200 mA). AGM: "3.3V 建议单独一路供电，需采用磁珠 … 隔离" [S6].
- C214/C215 100 nF sit at pins 16/32, and C213 100 nF at pin 6. C220 1 µF is the bulk capacitor after the bead.
- VDDA33 is **kept powered** although the PLL is unused. It is a supply pin and AGM gives no statement that it may be left unpowered.
- C216 is retired: the QFN-32 has 3 supply pins, not 4.

### 4A.4 Programming (Compact-JTAG)

- J202 pads: 1 3V3D sense only, 2 JTCK (pin 25), 3 JTMS (pin 24), 4 CPLD_NRST (pin 4), 5 GND.
- AGM [S6]: 2-wire Compact-JTAG (TCK/TMS) with **J-Link or the AGM Blaster / DAP-Link (CMSIS-DAP mode) only**. Supra "Query device ID" must return **0x40200001**.
- The CPLD is powered by the MCU programming mode (PROG strap), never by the probe.
- The internal 8 MHz RC oscillator (`PIN_OSC`) exists [S6] but is not used. It would need "Full chip erase before program" and calibration.

---

## 5. MCU CH32V307RCT6 (U201)

### 5.1 Clocks

HSE 8 MHz (Y201, YXC X50328MSB2GI, CL 20 pF, C201/C202 33 pF C0G → 2 × (20 − 3.5) pF). PLL → SYSCLK/HCLK 144 MHz. PCLK1 144 MHz (APB1 ≤ 144 MHz [DS S1 clock tree]; TIM3, I2C2, SPI2/I2S2). **PCLK2 = 72 MHz** so that SPI1 = PCLK2/2 = 36 MHz and ADCCLK = PCLK2/6 = 12 MHz ≤ 14 MHz [DS Tab 4-41]; with PCLK2 = 144 MHz the largest ADC prescaler (÷8) would give 18 MHz. The USBHS PHY PLL reference is HSE/2 = 4 MHz (WCH EVT practice; the RM text was not retrieved).

### 5.2 Reset defaults, JTAG question (R8-D7) and FT pins

- WCH datasheet pin definitions, "Main function (after reset)" (reproduced from the WCH DS by the ch32-riscv-ug mirror [S3]): **PA13 = SWDIO, PA14 = SWCLK, PA15 = PA15, PB3 = PB3, PB4 = PB4, PB2 = PB2/BOOT1**. The datasheet features list "Debug mode: 2-wire serial debug interface (SDI)" [S1]. WCH's own SPL has only `GPIO_Remap_SWJ_Disable 0x00300400` and none of the STM32 JTAG-DP/NJTRST remaps [S4]. For comparison, the related CH32V003 RM field, as summarised by a community page (kyoichisato.github.io, not a WCH document), is PCFR1 SWCFG[26:24] "0xx: SWD enabled, 100: SWD off (GPIO)" and has no JTAG state.
- **Conclusion: PA15, PB3 and PB4 are floating GPIO inputs at reset, with no pull-up.** ILIM_HI on PA15 is held low by R511 until firmware drives it. RAILS_OK_N on PB4 is not lifted. I **could not retrieve the V3x RM AFIO/GPIO chapter text** (reset value of PCFR1/CFGLR); this conclusion rests on the DS pin table and the SDK. Bring-up check: read AFIO_PCFR1 and measure PA15/PB4 with a 1 MΩ load during NRST low.
- **FT pins** (VIN ≤ 5.5 V [DS Tab 4-1]): PA8–PA15, PB2–PB15, PC6–PC12, PD2. PA0–PA7, PB0/PB1 and PC0–PC5 (analog) and PC13–PC15 are **not** FT (VIN ≤ VIO + 0.3 V).
- Injected current ≤ ±5 mA per pin, ≤ ±25 mA total; ≤ 25 mA source/sink per pin; ≤ 150 mA into VDD/VDDA/VIO [DS Tab 4-1].
- Supplies [DS S1 2.5.3]: VDD 2.4–3.6 V (includes the USB PHY), VIO ≤ VDD, VDDA = VIO. All are tied to 3V3M. VBAT is tied to 3V3M. The LQFP-64M has no VREF+ pin, so VREF+ = VDDA internally.

### 5.3 Pin map (all 64 pins; generated from `netlist.csv`)

GPIO rules (unit-tested GPIO table):
- (a) Every MCU **output facing the 3V3D domain** (LINK_SCK/MOSI/FRAME, DAC_RESETB) is low whenever AUD_EN is low. **[R2 ↑]** MCLK_PERMIT (PB14) added to this list.
- (b) Every MCU **input from the 3V3D domain** (LINK_MISO, LRCLK_FB, CPLD_IRQ, DAC_LOCK, capture pins) uses the internal **pull-down**, never a pull-up; a pull-up would back-power 3V3D. **[R2 ↑]** Exception: PB1 (N2_MCLK_OE) is a floating input because R235 defines it.
- (c) CPLD_NRST is open-drain only.
- (d) RAILS_OK_N, DC_PERMIT_N and ANA_FAULT_N are inputs without internal pulls.
- (e) Unused pins are set to analog input.

GPIO budget: 49 GPIO (51 minus OSC_IN/OUT), **[R2 ↑]** 43 used, 6 spare (PC14, PC15, PA0, PB0, PA12, PB9); PB14 = MCLK_PERMIT, PB1 = N2_MCLK_OE readback; DOM_DIS and AMP_EN retired (D-11). The table below is regenerated from the round-2 netlist.

| Pin | Name | Type | FT | Reset-default function | Net | Configuration / note |
|---|---|---|---|---|---|---|
| 1 | VBAT | P | - | supply/dedicated | 3V3M | no backup battery; tied to 3V3M, 100 nF C203 |
| 2 | PC13-TAMPER-RTC | I/O | - | PC13: GPIO floating input | PROG | input, internal pull-up; TP732 shorted to GND at reset = programming mode |
| 3 | PC14-OSC32_IN | I/O/A | - | PC14: GPIO floating input | NC | spare; firmware: analog input (lowest leakage) |
| 4 | PC15-OSC32_OUT | I/O/A | - | PC15: GPIO floating input | NC | spare; firmware: analog input |
| 5 | OSC_IN | I/A | - | HSE oscillator pin | N2_HSE_IN | Y201 8 MHz |
| 6 | OSC_OUT | O/A | - | HSE oscillator pin | N2_HSE_OUT | Y201 8 MHz |
| 7 | NRST | I | - | reset input | NRST | R201 10k pull-up, C212 100 nF, J201-4 |
| 8 | PC0 | I/O/A | - | PC0: GPIO floating input | DC_SENSE_LP | ADC2 IN10, TS 71.5 cyc, 20.41 kHz per channel (D-13); R_TH 2.49 k + 4.7 uF (protection) |
| 9 | PC1 | I/O/A | - | PC1: GPIO floating input | DC_SENSE_LN | ADC2 IN11 (as PC0) |
| 10 | PC2 | I/O/A | - | PC2: GPIO floating input | DC_SENSE_RP | ADC2 IN12 (as PC0) |
| 11 | PC3 | I/O/A | - | PC3: GPIO floating input | DC_SENSE_RN | ADC2 IN13 (as PC0) |
| 12 | VSSA | P | - | supply/dedicated | GND |  |
| 13 | VDDA | P | - | supply/dedicated | 3V3M | must equal VIO [DS 2.5.3]; C204 100 nF + C221 1 uF |
| 14 | PA0-WKUP | I/O/A | - | PA0: GPIO floating input | NC | spare (ADC_IN0); firmware: analog input |
| 15 | PA1 | I/O/A | - | PA1: GPIO floating input | VBUS_SENSE | ADC1 IN1 only (all 7 slots, dual regular-simultaneous master), TS 71.5 cyc, AWD LTR 1587 = 4.00 V; C103 10 nF (power) |
| 16 | PA2 | I/O/A | - | PA2: GPIO floating input | CC1_ADC | ADC2 IN2 (7-slot scan, TS 71.5 cyc, 20.41 kHz); source 12.3-15.3 k (R103 + Rd||Rp) |
| 17 | PA3 | I/O/A | - | PA3: GPIO floating input | CC2_ADC | ADC2 IN3 (as CC1) |
| 18 | VSS_4 | P | - | supply/dedicated | GND |  |
| 19 | VDD_4 | P | - | supply/dedicated | 3V3M | C205 + C206 100 nF (USB PHY supply side) |
| 20 | PA4 | I/O/A | - | PA4: GPIO floating input | LINK_FRAME | GPIO push-pull, active high; low whenever AUD_EN is low |
| 21 | PA5 | I/O/A | - | PA5: GPIO floating input | LINK_SCK | SPI1_SCK AF push-pull 36 MHz (writes) / 9 MHz (register reads); R224 33R |
| 22 | PA6 | I/O/A | - | PA6: GPIO floating input | LINK_MISO | SPI1_MISO input, internal pull-down |
| 23 | PA7 | I/O/A | - | PA7: GPIO floating input | LINK_MOSI | SPI1_MOSI AF push-pull; R225 33R |
| 24 | PC4 | I/O/A | - | PC4: GPIO floating input | V3A_MON | ADC2 IN14, first slot (reference: reading = leg - ref); R_TH 2.49 k + 4.7 uF (protection) |
| 25 | PC5 | I/O/A | - | PC5: GPIO floating input | CPLD_NRST | GPIO open-drain only (never push-pull high); R231 10k pull-up on the CPLD side |
| 26 | PB0 | I/O/A | - | PB0: GPIO floating input | NC | spare; firmware: analog input |
| 27 | PB1 | I/O/A | - | PB1: GPIO floating input | N2_MCLK_OE | floating input (R235 defines it): readback of X201 E/D for the boot self-test of U206/R234; never an output |
| 28 | PB2/BOOT1 | I/O | FT | PB2/BOOT1 | N2_BOOT1 | R232 10k pull-down: BOOT1 defined 0 (BOOT0 pad selects the system bootloader) |
| 29 | PB10 | I/O/A | FT | PB10: GPIO floating input | I2C_SCL | I2C2_SCL open-drain, 100 kHz; R207 4.7k to 3V3D |
| 30 | PB11 | I/O/A | FT | PB11: GPIO floating input | I2C_SDA | I2C2_SDA open-drain; R208 4.7k to 3V3D |
| 31 | VSS_1 | P | - | supply/dedicated | GND |  |
| 32 | VIO_1 | P | - | supply/dedicated | 3V3M | C207 100 nF; VIO <= VDD [DS 2.5.3] |
| 33 | PB12 | I/O/A | FT | PB12: GPIO floating input | N2_CAP_WS | I2S2_WS slave-receive input (on-board I2S capture), R229 |
| 34 | PB13 | I/O/A | FT | PB13: GPIO floating input | N2_CAP_CK | I2S2_CK slave input, R228 |
| 35 | PB14 | I/O/A | FT | PB14: GPIO floating input | N2_MCLK_PERMIT | GPIO push-pull (never SPI2 AF); U206 input C; R234 10k pull-down: MCLK stops <0.2 us after any MCU reset |
| 36 | PB15 | I/O/A | FT | PB15: GPIO floating input | N2_CAP_SD | I2S2_SD slave-receive input, R230 |
| 37 | PC6 | I/O | FT | PC6: GPIO floating input | LED_G | push-pull, active high, R701 |
| 38 | PC7 | I/O | FT | PC7: GPIO floating input | LED_R | push-pull, active high, R702 |
| 39 | PC8 | I/O | FT | PC8: GPIO floating input | CPLD_IRQ | input, internal pull-down, EXTI8 |
| 40 | PC9 | I/O | FT | PC9: GPIO floating input | DAC_LOCK | input, internal pull-down (DAC GPIO2 tri-stated in reset), EXTI9 |
| 41 | PA8 | I/O | FT | PA8: GPIO floating input | N2_RESETB_MCU | push-pull; low whenever AUD_EN is low; R233 4.7k at this pin -> DAC_RESETB (R305 100k pull-down at the DAC) |
| 42 | PA9 | I/O | FT | PA9: GPIO floating input | USART_TX | USART1_TX debug, J201-7 |
| 43 | PA10 | I/O | FT | PA10: GPIO floating input | USART_RX | USART1_RX debug, J201-8, input pull-up |
| 44 | PA11 | I/O/A | FT | PA11: GPIO floating input | RELAY_EN | push-pull; R643/R644 bases + R646 100k pull-down (protection); floats in reset -> switch open <= 1.01 ms; USBFS/USBD never enabled (PA11/PA12 are their pins) |
| 45 | PA12 | I/O/A | FT | PA12: GPIO floating input | NC | spare (DOM_DIS retired); firmware: analog input |
| 46 | PA13 | I/O | FT | SWDIO (SDI) | SWDIO | SDI data at reset [DS pin table 'Main function (after reset) SWDIO']; J201-2 |
| 47 | VSS_2 | P | - | supply/dedicated | GND |  |
| 48 | VDD_2 | P | - | supply/dedicated | 3V3M | C208 + C209 100 nF |
| 49 | PA14 | I/O | FT | SWCLK (SDI) | SWCLK | SDI clock at reset [DS]; J201-3 |
| 50 | PA15 | I/O | FT | PA15: GPIO floating input | ILIM_HI | push-pull -> U505 TMUX1101 SEL (fail-safe 5.5 V; 1 = High limit), R511 pull-down (power); floating GPIO at reset (no JTAG on CH32V307) |
| 51 | PC10 | I/O | FT | PC10: GPIO floating input | AUD_EN | push-pull |
| 52 | PC11 | I/O | FT | PC11: GPIO floating input | AVCC_EN | push-pull; also U206 input B (MCLK gate) |
| 53 | PC12 | I/O | FT | PC12: GPIO floating input | ANA_EN | push-pull |
| 54 | PD2 | I/O | FT | PD2: GPIO floating input | LRCLK_FB | TIM3_ETR (external clock mode 2), latched in the USB SOF ISR; internal pull-down |
| 55 | PB3 | I/O | FT | PB3: GPIO floating input | DC_PERMIT_N | input (FT), no internal pull, EXTI3 both edges, highest priority; Q618 drain + R648 100k to 3V3M (protection) |
| 56 | PB4 | I/O | FT | PB4: GPIO floating input | RAILS_OK_N | input, FT, no internal pull: R522 10k series + R532 470k pin-side pull-down (power, D-8) -> 3.22..4.76 V high; valid only with ANA_EN=RAIL_EN=1 >= 20 ms |
| 57 | PB5 | I/O | FT | PB5: GPIO floating input | ANA_FAULT_N | input (FT), no internal pull, EXTI5 falling: U503 TPS259621 FLT (open drain) + R512 100k to 3V3M (power); valid with ANA_EN high |
| 58 | PB6 | I/O | FT | PB6: GPIO floating input | USB_DN | USBHS_DM (90 ohm pair) |
| 59 | PB7 | I/O | FT | PB7: GPIO floating input | USB_DP | USBHS_DP (90 ohm pair) |
| 60 | BOOT0 | I | - | boot select (sampled at reset) | BOOT0 | R202 10k pull-down; J201-6 pad next to J201-1 (3V3M) for the bootloader bridge |
| 61 | PB8 | I/O/A | FT | PB8: GPIO floating input | RAIL_EN | push-pull |
| 62 | PB9 | I/O/A | FT | PB9: GPIO floating input | NC | spare (AMP_EN retired); firmware: analog input |
| 63 | VSS_3 | P | - | supply/dedicated | GND |  |
| 64 | VIO_3 | P | - | supply/dedicated | 3V3M | C210 100 nF |

### 5.4 Peripherals

- **SPI1 (link):** master, mode 0 (CPOL 0, CPHA 0), MSB first, 16-bit frames, DMA.
  - Audio writes run at ÷2 = 36 MHz: 70.0 % worst-case utilisation at 384 kHz with one extra frame, 87.6 µs burst per 125 µs microframe [CALC].
  - Register reads run as separate transactions at ÷8 = 9 MHz (margin +40.7 ns [CALC, tsu(MI) assumed 5 ns]).
  - The SPI must be disabled to change BR between transactions.
- **TIM3:** external clock mode 2 on ETR = PD2 (LRCLK_FB). 16-bit counter extended in software. Latched in the USBHS SOF interrupt every 125 µs. The TIM3 kernel clock is 144 MHz; STM32-type ETR sampling allows up to fCK/4 = 36 MHz [ASSUMP: V3x RM not retrieved], far above 384 kHz.
- **I2C2:** PB10/PB11, 100 kHz standard mode, 4.7 kΩ pull-ups to 3V3D. tr = 119–398 ns for 30–100 pF, against the 1000 ns limit [CALC]. The peripheral is disabled while 3V3D is off; nine-clock bus recovery after power-up.
- **USART1:** PA9/PA10 on J201 (debug log, 1 Mbaud).
- **I2S2 (capture, §9):** slave receive on PB12 (WS), PB13 (CK) and PB15 (SD) through R229/R228/R230 (330 Ω, τ = 3.0 ns [CALC]).
- **ADC:** §6.
- **Debug/boot:**
  - J201 pads: 3V3M sense, SWDIO, SWCLK, NRST, GND, BOOT0, USART_TX, USART_RX.
  - R201 10 kΩ + C212 100 nF on NRST; R202 10 kΩ BOOT0 pull-down.
  - **New R232 10 kΩ on PB2/BOOT1**, so that the BOOT0 recovery pad deterministically selects the system bootloader. This assumes the STM32-style BOOT0/BOOT1 table; the WCH RM text was not retrieved.
  - PROG = PC13 (internal pull-up, TP732 to GND at reset).

---

## 6. ADC (settings, sampling limits, latency) — **[R2 ↑]** superseded by R2.3 (D-13)

DS facts [S2]: fADC ≤ 14 MHz; RAIN ≤ 50 kΩ; RADC ≤ 1 kΩ; CADC 8 pF; tCONV = TS + 12.5 cycles; Table 4-42 RAIN max at 14 MHz (7.5 cycles → 5.9 kΩ … 41.5 → 37.2 kΩ, 55.5 → 50 kΩ). The formula RAIN = TS/(fADC·CADC·ln 2¹⁴) − RADC reproduces Table 4-42 to ±0.1 kΩ [CALC].

At fADC = 12 MHz, RAIN max: 7.5 cycles → 7.1 kΩ, 13.5 → 13.5 kΩ, 28.5 → 29.6 kΩ, 41.5 → 43.5 kΩ, ≥ 55.5 → 50 kΩ (absolute cap) [CALC].

| Channel | Pin / ADC | Source | Setting | Result |
|---|---|---|---|---|
| VBUS_SENSE | PA1 / ADC1 IN1 | 32.0 kΩ (100 k ∥ 47 k, power stream) | ADC1 continuous, single channel, **TS 55.5** (≥ 41.5 needed), analog watchdog | 5.67 µs per conversion; watchdog latency ≤ 11.3 µs + ISR [CALC] |
| CC1_ADC, CC2_ADC | PA2, PA3 / ADC2 | 10 k + 5.1 k ∥ 56 k = 14.7 kΩ | ADC2 scan, TS 239.5 (≥ 28.5 needed) | settled |
| DC_SENSE_LP/LN/RP/RN | PC0–PC3 / ADC2 IN10–13 | 4.7 kΩ + 2.2 µF | TS 239.5 | charge-share error 0.015 LSB → any TS works |
| V3A_MON | PC4 / ADC2 IN14 | 5 kΩ + 100 nF | TS 239.5 | charge share 0.33 LSB, so settling relies on TS (5 kΩ ≪ 50 kΩ) |

- ADC2 scan: 7 channels × 21.0 µs = 147 µs per scan. 1 kHz per channel uses 14.7 % of ADC2 [CALC].
- LSB = 0.806 mV (ratiometric to 3V3M).
- **DS error:** the offset of ±4 LSB (3.2 mV) is given as a single value with no maximum, so it must be calibrated out (auto-zero). DNL is ±3 LSB max (2.4 mV) and INL ±4 LSB max (3.2 mV) at fADC 14 MHz, RAIN < 10 kΩ, VDDA 3.3 V [DS Tab 4-43]. These numbers go to the protection stream.
- Sampling current 26 nA per channel at 1 kHz → 0.12 mV across 4.7 kΩ [CALC].

---

## 7. USB — feedback table and key descriptors (`usb_feedback_output.txt`)

### 7.1 Feedback (HS)

USB 2.0 §5.12.4.2 [S10]: unsigned 12.13 value in four bytes, aligned as 16.16, four MSBs zero, the lower three bits optional. Nominal values are round-half-up of fs/8000 × 2¹⁶.

| fs | samples/µframe | Ff | hex | error |
|---|---|---|---|---|
| 44 100 | 5.5125 | 361 267 | **0x00058333** | −0.55 ppm |
| 48 000 | 6 | 393 216 | 0x00060000 | 0 |
| 88 200 | 11.025 | 722 534 | 0x000B0666 | −0.55 ppm |
| 96 000 | 12 | 786 432 | 0x000C0000 | 0 |
| 176 400 | 22.05 | 1 445 069 | 0x00160CCD | +0.14 ppm |
| 192 000 | 24 | 1 572 864 | 0x00180000 | 0 |
| 352 800 | 44.1 | 2 890 138 | 0x002C199A | +0.14 ppm |
| 384 000 | 48 | 3 145 728 | **0x00300000** | 0 |

Assertions in the script: 44.1 k = 0x00058333, 384 k = 0x00300000, all four MSBs zero, and 0x002C1999 (v0.8) = floor(352.8 k) = 8.000 × the correct 44.1 k value.

**Running value.** TIM3 counts LRCLK. A sliding window of 2¹⁰ µframes (128 ms) gives Ff = count ≪ 6, updated every 8 µframes. One count is 177 ppm at 44.1 kHz and 20 ppm at 384 kHz [CALC]. The value dithers, but its mean is exact because no LRCLK edge is lost. A FIFO-centering term Kp × (target − level) is added, clamped to ±1000 ppm. The nominal value is used for 128 ms after a rate change.

### 7.2 Key descriptor fields

- **Device:** bcdUSB 0x0200; class EF/02/01 (IAD); bMaxPacketSize0 64; VID:PID 1209:0001 test only; iSerial from the 96-bit UID; device-qualifier and other-speed descriptors present.
- **Configuration:** bmAttributes 0x80 (bus-powered), bMaxPower 0xFA (500 mA; High mode relies on the Type-C advertisement).
- **IAD:** 2 interfaces, 01/00/20.
- **AC header:** bcdADC 0x0200.
- **Clock Source:** internal programmable, bmControls 0x07 (frequency R/W, validity R); CUR/RANGE list the 8 rates.
- **Topology:** IT 0x0101 (USB streaming, 2 ch, bmChannelConfig 0x3) → Feature Unit (master mute + volume R/W) → OT 0x0302 (headphones).
- **AS alternate settings:** alt 0 zero-bandwidth; alt 1 16-bit (subslot 2); alt 2 24-bit (subslot 4, bBitResolution 24); alt 3 32-bit (subslot 4). bmFormats PCM.
- **Iso OUT:** bmAttributes **0x05** (asynchronous), bInterval 1; wMaxPacketSize 196 / 392 / 392 bytes for alt 1/2/3 = (ceil(fs/8000) + 1) frames [CALC].
- **Feedback IN:** bmAttributes **0x11**, wMaxPacketSize **4**, bInterval 4 (8 µframes).
- **Rate changes:** SET_CUR on the clock frequency is acknowledged at once. The change runs while the interface is idle, and Clock Validity reports true only after lock (§4.4).

---

## 8. MCU ↔ CPLD link, CPLD logic and I²S

### 8.1 Link framing

- LINK_FRAME (PA4, active high, GPIO) brackets each transaction. The first 16-bit word is the header: [15:12] command (0x1 AUDIO, 0x2 REG_WRITE, 0x3 REG_READ, 0xF NOP), [11:0] word count or register address.
- **AUDIO:** the header is followed by N 32-bit words L, R, L, R … Each word is left-justified: 16/24-bit host samples are MSB-aligned and zero-padded; 32-bit samples pass unchanged.
- **Word order on the wire:** least-significant half-word first, MSB-first within each half-word. This lets DMA send the USB buffer (little-endian) directly; the CPLD stores {second, first}. The known-pattern test in §9 proves it.
- One AUDIO burst per USB microframe. The worst case is 49 frames = 3 152 bits = 87.6 µs at 36 MHz [CALC].
- **REG_WRITE:** header + 16-bit data (36 MHz allowed). **REG_READ:** header + 16 clocks, during which MISO carries the data. Read transactions are separate and run at ÷8 = 9 MHz (D4).

### 8.2 CPLD register map (proposed, SPI clock domain)

| Addr | Name | Content |
|---|---|---|
| 0x00 | ID (RO) | 0xA6D2 magic (read OK ⇒ configured) |
| 0x01 | VERSION (RO) | logic build number |
| 0x02 | STATUS (RO) | b0 I2S_RUNNING, b1 FIFO_UNDERFLOW (sticky), b2 FIFO_OVERFLOW (sticky), b3 FAM_CLK_PRESENT, b15:5 FIFO level snapshot (diagnostic only); reading clears the sticky bits and CPLD_IRQ |
| 0x03 | CLOCK_CTRL | b0 OSC48_EN, b1 OSC44_EN (= mux select), b2 MCLK_EN; reset 0 |
| 0x04 | I2S_CTRL | b0 I2S_RUN, b2:1 DIV (÷2/4/8/16), b3 I2S_TRISTATE (J703 external-source test), b4 FIFO_FLUSH; reset 0 |

### 8.3 CPLD logic requirements (owner's RTL)

- **SPI receiver** in the SCK domain. SCK enters on pin 9 → ALTCLKCTRL → global network (AGM guide [S6]). Weak pull-downs on SCK/MOSI/FRAME (`CFG_KEEP 2'b01` [S6]).
- **Dual-clock FIFO**, 1024 × 32 bit in 4 × M9K = 512 stereo frames (11.6 ms at 44.1 kHz, 1.33 ms at 384 kHz; half-full target 0.67 ms at 384 kHz [CALC]). Gray-coded pointers, **written in RTL**: community reports say Supra "Native" mode does not accept the Altera `dcfifo` IP [oshwhub comments, not an AGM document]. The 16-bit header gives the write-domain synchronisers SCK edges before data.
- **Underflow:** output zeros, set the sticky flag, raise CPLD_IRQ.
- **I²S engine** in the FAM_CLK domain with async-assert/sync-release reset from I2S_RUN; all outputs from registers; 8 mA drive (AGM default [S6]).
- **Unused pins:** inputs with weak pull-up.
- **Registers:** MCLK_EN, OSC48_EN and OSC44_EN reset to 0.

### 8.4 I²S to the ES9018K2M and DAC register plan (digital side)

32-bit I²S (Philips): left channel while LRCLK is low, MSB one BCLK after the LRCLK edge, 64 BCLK per frame [DS p.9]. Registers are written after every RESETB release, because reset clears them [DS p.7]:

| Reg | Value | Meaning |
|---|---|---|
| 1 | 0x80 | 32-bit, I²S, auto-select off, input I²S |
| 8 | 0x10 | GPIO2 = DPLL lock → DAC_LOCK (PC9), GPIO1 = automute status |
| 10 | 0x00 | slave, async, stop_div 0 (see §4.2 for the stop_div = 5 option) |
| 14 | **0xAA** (proposal) | soft_start = 1, mute_on_lock = 1 (auto-mute when lock is lost), soft_start_time 10 → 104.9 ms at 80 MHz [CALC] (**[R2 ↑]** unchanged at 80 MHz: 104.9 ms, wait 125.8 ms; analog adopted 0xAA) |

Proposal to the analog stream: the pop analysis owns the final reg 14 value.

- Status checks: reg 64 lock/automute/revision and regs 66–69 DPLL ratio (read LSB first).
- **Order:** DAC_RESETB is released ≥ 1 ms after all supplies and MCLK are stable [DS p.27]. At shutdown: soft mute → MCLK_EN = 0 → … (§4.3). **[R2 ↑]** RESETB ≥ 5 ms after the MCLK enable and ≥ 6 ms after AUD_EN; shutdown per R2.5 C.
- **Bit-perfect note:** any MCU fine gain (channel trim) makes the I²S stream not bit-perfect. Recommendation: no MCU trim if the analog channel balance (0.1 % parts) meets 0.3 dB. The bit-perfect test runs with trim = 1.0.

---

## 9. Verification plan (digital bring-up on the main board)

### 9.1 Bit-perfect (R8-B10)

- **Patterns** (host-generated WAV files, played through WASAPI exclusive / ALSA hw / CoreAudio integer mode):
  - walking ones and walking zeros, per channel;
  - 32-bit LFSR with known seed (L even, R odd sequence, so swaps and half-word order are visible);
  - extremes 0x7FFFFFFF / 0x80000000 / 0 / ±1 LSB;
  - a start/stop marker.
- **Matrix:** 8 rates × 3 formats (16/24/32-bit alt settings), ≥ 10 s each, plus rate and family changes in sequence.
- **Capture A (on-board, automated EOL):**
  - The MCU I2S2 slave receiver captures the CPLD output through R228–R230, using DMA to RAM. It computes CRC32 per 1 s block and compares it (i) with the CRC of the words it sent over the link (link + FIFO + I²S engine) and (ii) with the CRC of the expected pattern regenerated from the known seed (host → USB → firmware → I²S, end to end).
  - Result: pass/fail over USART/log.
  - Pass: 0 mismatches.
  - Expected to work up to 192 kHz (BCLK 12.288 MHz). The I2S2 slave CK limit is not in the retrieved DS text [MEAS]; 352.8/384 kHz use Capture B unless the measurement shows the MCU can follow 24.576 MHz.
- **Capture B (reference, all rates):** logic analyser ≥ 200 MS/s on J703 (BCLK, LRCLK, SDATA; the DAC-side nets). A Python decoder compares against the source file after alignment. Pass: every sample equal, including the first and last frames around a start/stop.
- **Rate checks:** LRCLK_FB count within ±0.1 %; DAC DPLL ratio (regs 66–69) within ±0.1 %; lock bit set.

### 9.2 Link and FIFO

- Run a 10¹⁰-bit pseudo-random stream through the link at 36 MHz (407 s ≈ 6.8 min at 384 kHz). Capture B, or Capture A at ≤ 192 kHz, must show 0 errors, which gives BER < 3 × 10⁻¹⁰ at 95 % confidence [CALC].
- Run REG_READ loops at 9 MHz (10⁶ reads).
- Force underflow/overflow and check that the flags and CPLD_IRQ assert.
- 8-hour soak at 384 kHz with the FIFO level logged: no drift beyond ±8 frames.
- Fallback: register reads at ÷16 (4.5 MHz), firmware only.

### 9.3 Clocks, MCLK gate, CPLD start

- Scope FAM_CLK at every family change. Check oscillator start-up ≤ 4 ms and that no clock edges reach the I²S outputs while I2S_RUN = 0.
- Measure BCLK duty at every rate (≥ 47.9 % expected).
- Run the J-test at 44.1/48/352.8/384 kHz.
- **MCLK gate test:**
  - With MCLK running, (a) pull NRST low, (b) let the IWDG expire, (c) set AVCC_EN low with MCLK_EN high, (d) **[R2 ↑]** set MCLK_PERMIT low; check PB1 follows.
  - Scope XI, N2_MCLK_OE and 3V3A.
  - Pass: XI static low before 3V3A < 3.0 V. Measure the X201 disable time (**[R2 ↑]** expected ≤ 0.39 µs from NRST incl. R234/U206; Kyocera t_dis ≤ 200 ns [DS]; also check Q616 turns off, D-19).
  - Repeat during the failed-output test.
- **CPLD configuration time:** measure from 3V3D at 3.0 V to the first valid ID read at 1 ms polling. Record the I/O levels on OSC48_EN, OSC44_EN and MCLK_EN during configuration. Fallback: none needed (ID polling, 100 ms timeout, NRST retry).
- **Reset-default check:** during NRST low, PA15/PB4 sit at < 0.1 V with a 1 MΩ load, and AFIO_PCFR1 reads the reset value.
- Currents on 3V3M and 3V3D in every state (replacing the [ASSUMP] values in §10).

---

## 10. Currents for the power budget — **[R2 ↑]** superseded by R2.4

| Load | Run (max) | Suspend | Basis |
|---|---|---|---|
| U201 CH32V307 @144 MHz, USBHS active | **80 mA** (typ 60) | **1.9 mA** (Stop, PHY suspended) | **[ASSUMP]**: the WCH DS ch.4 current tables could not be retrieved as text; v0.8 values kept. Bound: ≤ 150 mA total into VDD/VDDA/VIO [DS Tab 4-1] |
| U202 AGRV2KQ32 | **40 mA** | 0 (3V3D off) | **[ASSUMP]**: AGM publishes no supply current |
| X201 80 MHz | 40 mA | 0 | [DS] SCTF 3C band; disabled current not specified → counted |
| X202/X203 (one running, one in stand-by) | 15.0 + 0.035 mA | 0 | [DS] NDK (at 25 °C). **+15 mA for ≤ 10 ms during a family change** (both running) |
| U205 mux @49 MHz | 4.7 mA | 0 | [CALC] CPD 18 pF [DS-typ] + 10 pF load |
| U206 gate | 0.004 mA | 0 | [DS] |
| Pull-downs R212/R213/R218 (≤ 3 high) | 1.02 mA (0.68 steady) | 0 | [CALC] |
| R227 + R216/R217 | 0.34 mA | 0 | [CALC] |
| I²C pull-ups (both low, worst) | 1.45 mA | 0 | [CALC] |
| LEDs D705 + D706 | 0.80 + 0.73 mA | 0 (off) | [CALC] |
| **3V3D total (digital parts)** | **102.5 mA** | 0 | + DAC DVCC/DVDD (analog stream) |
| **3V3M total (digital parts)** | **82.1 mA** | **1.9 mA** | + D+ pull-up 0.2 mA (power stream line) |
| State totals (digital share) | attached-unconfigured **80.7 mA** (one LED); configured/playing **184.6 mA** | — | [CALC] |

Fallbacks, all firmware-only, if the [MEAS] values exceed the budget:
- lower SYSCLK before configuration (the USBHS PHY clock is independent);
- gate unused peripheral clocks;
- in suspend, all 3V3D-facing pins low and unused pins analog.
Wake-up from Stop (HSE restart, USBHS PLL): the DS table was not retrieved. The MCU wakes at the start of host resume signalling (≥ 20 ms, USB 2.0 TDRSMDN) and must answer within TRSMRCY = 10 ms after it, so ≥ 30 ms are available [USB 2.0 §7.1.7.7/§9.2.6.2, values from memory, not re-read in this session]. Measure the Stop wake-up time [MEAS].

---

## 11. Component stress (digital parts, 50 °C, rails 3.40 V) — `stress_table_output.txt`

| Part | Condition | Stress / rating |
|---|---|---|
| R212/R213/R218 10 k | enable high | 1.16 mW / 62.5 mW (1.8 %) |
| R216/R217, R227 10 k | 50 % clock | 0.58 mW (0.9 %) |
| R207/R208 4.7 k | line held low | 2.46 mW (3.9 %) |
| R228–R230 330 Ω | **fault only** (MCU pin driven against the CPLD) | 35.0 mW (56 %) |
| R203 33 Ω (**[R2 ↑]** 80 MHz, 13.1 pF) | C·V²·f bound | ≤ 12.1 mW (19 %) |
| R204–R206, R210/R211/R215, R224/R225 33 Ω | C·V²·f bound | ≤ 5.7 mW (≤ 9 %) |
| R701/R702 | LED current | 0.64 / 1.17 mW |
| 100 nF 16 V X7R / 33 pF 50 V C0G / 1 µF 50 V X5R | 3.40 V | 21 % / 7 % / 7 % |
| C211 2.2 µF 6.3 V X5R 0402 | 3.40 V | 54 % of rating; ~50 % of the capacitance remains under DC bias (bulk role) |
| U201 | 3.40 V / 4.0 V abs max; TJ ≈ 64 °C (θJA 50 °C/W [ASSUMP]) | limit TA 85 °C [DS] |
| U202 | 3.40 V (AGM gives 3.3 V only); TJ ≈ 56 °C (θJA 45 °C/W [ASSUMP]) | TJ 85 °C [DS S5] |
| X201 | **[R2 ↑]** Kyocera: 3.40 V vs 3.63 V operating, 4.0 V abs max; 28 mW | [DS] |
| X202/X203 | 3.40 / 6.0 V abs max; 2.97–3.63 V spec (NSC5083D) | [DS] |
| U205/U206 | 3.40 / 6.5 V | [DS] |
| FB202 | 40 mA / 200 mA; 18 mV drop | [CALC] |
| MCU pins | ≤ 0.8 mA static per pin (25 mA limit); PB4 ≤ 5.5 V only with the §13 request | [DS] |

---

## 12. Parts added / removed / changed (block 2 and 7, digital-owned)

| Change | Ref | Part (LCSC) |
|---|---|---|
| **Added** | U206 | **[R2 ↑]** Nexperia 74LVC1G11GW-Q100H (C548242); round 2 also added R233 4.7 k (C25900), R234 10 k (C25744), R235 100 k (C25741), TP732; C217 → 10 nF (C15195); X201 → Kyocera KC2520K80.0000C1GE00. Round 1: Nexperia 74LVC1G08GW,125 (**C12512**) |
| Added | C222, C223 | 100 nF 0402 X7R Samsung CL05B104KO5NNNC (C1525) |
| Added | R227, R231, R232 | 10 kΩ 0402 UNI-ROYAL 0402WGF1002TCE (C25744) |
| Added | R228–R230 | 330 Ω 0402 UNI-ROYAL 0402WGF3300TCE (**C25104**, parts stream to confirm) |
| **DNF → fitted** | U205, R215, R216, R217 | 74LVC1G157GW,125 (C135822); 33 Ω (C25105); 10 kΩ (C25744) |
| **Part changed** | X202 | YXC OT322524.576MJBA4SL (C2831388) → NDK NZ2520SDA-49.152MHZ-NSC5083D (global sourcing; DigiKey 644-NSC5083D-49.152M; JLCPCB record C9900006427) |
| Part changed | X203 | SCTF SX2M22.5792M20F30TNN (C5452663) → NDK NZ2520SDA-45.1584MHZ-NSC5083D (global sourcing); stock fallback SCTF SX3M45.1584M20F30TNN (**C2901589**) on the combined land |
| Value changed | R212, R213, R218 | 2.2 kΩ (C25879) → 10 kΩ (C25744) |
| Value changed | R207, R208 | 2.2 kΩ (C25879) → 4.7 kΩ UNI-ROYAL 0402WGF4701TCE (**C25900**, parts stream to confirm) |
| **Deleted / retired** | R214 | shared-node pull-down (no shared node) |
| Retired | C216 | the CPLD has 3 supply pins (6, 16, 32); C213–C215 cover them |
| Kept | U201, Y201, C201–C215, C217–C221, FB202, U202, X201, R201–R206, R210, R211, R224, R225, J201, J202, D705, D706, R701, R702, J703 (DNF), R703 (DNF) | as Parts List v0.6 (C216 retired, see above). **[R2 ↑]** X201 is no longer kept: Kyocera KC2520K80.0000C1GE00 (R2.1, D-3 revised) |

**[R2 ↑]** 27 lines, 65 fitted refs, 231 SMT joints, US$ 10.74 (R2.0). Round 1: BOM: 25 lines; 61 fitted refs (59 components + 2 pad groups), 2 DNF; 224 SMT joints; 10.81 US$ of fitted parts at sample-tier prices, with the NDK price estimated (`gen_netlist_bom_output.txt`). Leadless: U202, X201, X202, X203 (4, X-ray).

Signals removed from the MCU: FLT, FLT_CLR, ANA_FAULT (latch), SPI2 second-lane reservation. Signals added: RELAY_EN (PA11), DC_PERMIT_N (PB3), DOM_DIS (PA12), CPLD_NRST (PC5), I²S capture (PB12/13/15). **[R2 ↑]** DOM_DIS and AMP_EN retired (PA12, PB9 spare); MCLK_PERMIT (PB14) and N2_MCLK_OE readback (PB1) added.

---

## 13. Interface requests

**Power stream**
1. **[R2 ↑]** R2.4/R2.10 (3V3D 68.9 mA). 3V3D digital load ≤ 102.5 mA (+15 mA for ≤ 10 ms at a family change; +25 mA if the SCTF oscillator fallback is fitted), plus the DAC. 3V3M ≤ 82.1 mA run and 1.9 mA suspend (MCU values [ASSUMP]).
2. **[R2 ↑]** answered by D-8 (R532 470 k pin-side pull-down: 3.22–4.76 V). **RAILS_OK_N at PB4 must stay ≤ 5.5 V** (FT abs max [DS Tab 4-1]) at the highest 5V_ANA (OVP trip max). Example: a 100 kΩ pin-side pull-down with R522 10 kΩ gives 5.8 V → 5.27 V at the pin, and a 4.31 V high → 3.92 V [CALC].
3. **AVCC_EN** must be pulled low at the MCU-pin side (U206 input B, leakage ±1 µA) with ≤ 220 kΩ total when the MCU pin floats. v0.8's R307 10 k + R303 100 k (110 kΩ) is fine.
4. During unplug and brownout, 3V3D must not exceed 3V3A by more than 0.3 V while MCLK runs. Otherwise firmware drops AVCC_EN at the VBUS watchdog, which stops MCLK first.
5. VBUS_SENSE: source ≤ 50 kΩ for TS 55.5 (≤ 43.5 kΩ if TS 41.5 is preferred); no pin capacitor needed.
6. **[R2 ↑]** DOM_DIS retired (D-11), PA12 spare. DOM_DIS = PA12 (push-pull; its reset state is set by your network). PB0/PB1 are reserved for per-domain lines.
7. The CPLD configures at every 3V3D power-up. No sequencing constraint beyond the existing rule (MCU 3V3D-facing outputs low while AUD_EN is low).

**Protection stream**
- RELAY_EN = PA11: floats in reset; your pull-down holds the relay off.
- DC_PERMIT_N = PB3 (FT, EXTI3; your pull-up to 3V3M); ANA_FAULT_N = PB5.
- ADC facts from §6 for the error budget: offset not guaranteed (auto-zero), INL ±4 LSB max, DNL ±3 LSB max, 0.806 mV LSB, 239.5-cycle scan at 21 µs per channel (**[R2 ↑]** R2.3: TS 71.5, 20.41 kHz).
- DC-sense pins PC0–PC3, V3A_MON on PC4.

**Analog stream**
- DAC_RESETB = PA8; DAC_LOCK = PC9 (internal pull-down).
- I²C pull-ups are now 4.7 kΩ at 100 kHz.
- XI is held low by R227 when MCLK is stopped.
- Register proposal (§8.4, reg 14 = 0xAA with mute_on_lock).
- The family change never touches MCLK; the rate-change latency (DPLL lock, §4.2) feeds your pop and latency analysis.
- MCU channel trim breaks bit-perfection (§8.4).

**Parts / layout stream**
- Combined 2520/3225 land for X201/X202/X203 (pin 1 = OE/ST at the same corner).
- Place U205 and R215 next to CPLD pin 1, and X202/X203 + R210/R211 next to U205.
- Place X201 + R203 + R227 at the DAC XI (MCLK trace ≤ 20 mm) and U206 next to X201.
- Place R204–R206 and R228–R230 at CPLD pins 18–20, R224/R225 at the MCU.
- The CPLD EP (2.7 mm) goes to GND.
- Confirm C25104 and C25900, and the D705/D706 cathode pad numbering.
- TP reuse proposal: the deleted FLT/node-F pads become TP722 DC_PERMIT_N, TP723 ANA_FAULT_N and TP724 N2_MCLK_OE (proves the hardware MCLK gate).

---

## 14. Open items (measurements only; each has a designed-in fallback)

| # | Item | Fallback (no board change) |
|---|---|---|
| 1 | CH32V307 run, Stop and wake-up currents/times (DS tables not retrieved) [MEAS] | Firmware clock/peripheral reduction; Stop configuration |
| 2 | AGRV2KQ32 supply current (no AGM figure) [MEAS] | The 40 mA budget includes margin. The CPLD design can lower drive strength (2–30 mA settable [S6]) |
| 3 | CPLD configuration time and I/O state during power-on configuration [MEAS] | ID polling, 100 ms timeout, CPLD_NRST retry. Mux and MCLK gate make the I/O state harmless |
| 4 | **[R2 ↑]** Kyocera: t_dis ≤ 200 ns [DS]; phase jitter [MEAS] (R2-2); disable time [MEAS] only for the conditional NDK (R2-3). X201 disable time; X201 phase noise (not specified) [MEAS] | Firmware waits 1 ms between MCLK_EN = 0 and AVCC_EN low. The combined land accepts a 2520 low-noise 80 MHz part |
| 5 | X203 NDK stock at order time [procurement] | **[R2 ↑]** SiT8008 (ST) is the compliant second source; SCTF SX3M45.1584M20F30TNN (C2901589) is non-compliant (D-4) |
| 6 | I2S2 slave capture at 24.576 MHz BCLK [MEAS] | Capture B (J703 + logic analyser) for 352.8/384 kHz |
| 7 | MISO read timing at 9 MHz [MEAS by 10⁶ reads] | ÷16 = 4.5 MHz (firmware) |
| 8 | ES9018K2M SDA VOL at 0.7 mA [MEAS] | R207/R208 → 10 kΩ (BOM value only) |
| 9 | CPLD timing closure at 49.152 MHz and 36 MHz (Supra report) [MEAS] | 11 spare I/O; the logic is small. Pipeline the FIFO read (firmware/RTL) |

---

## 15. Sources and what I could not verify

**Sources used** (quotes in `sources/source_quotes.txt`):
- **S1** WCH CH32V303/305/307/317 Datasheet V3.9 (mirror of https://www.wch-ic.com/downloads/CH32V307DS0_PDF.html): §2.5.3 power supply scheme, §2.5.6 low-power modes, clock tree, features.
- **S2** WCH datasheet V3.5 Tables 4-1, 4-41, 4-42, 4-43, via the sheetsdata.com extraction (https://sheetsdata.com/parts/CH32V307).
- **S3** WCH pin definitions (reset-default functions, FT) as reproduced at https://github.com/ch32-riscv-ug/CH32V307.
- **S4** WCH SDK `ch32v30x_gpio.h` (https://github.com/openwch/ch32v307).
- **S5** AGM AGRV2K Datasheet Rev 3.0 (https://www.ag32mcu.com/wp-content/uploads/2026/02/AGRV2K_Rev_3_0.pdf): Table 5-4 pinout, §2.2 ISP I/O state, §3 POR, Tables 4-1..4-3.
- **S6** AGM AGRV2K application guide (https://www.agmcn.com/resources/agrv2k-guide/).
- **S7** NDK NZ2520SDA NDKT02-00008_en and catalog; DigiKey stock.
- **S8** SCTF 3C series page and LCSC pages C2901591, C2901589, C19268188.
- **S9** Nexperia 74LVC1G157 Rev.12, 74LVC1G08 Rev.16.1.
- **S10** USB 2.0 §5.12.4.2 text quoted in zephyrproject-rtos/zephyr #77212.
- **S11** ES9018K2M datasheet v3.7 (local).

**Not verified (stated plainly):**
- **WCH:**
  - The CH32V307 **current consumption tables** (run/sleep/Stop/Standby), **I/O static characteristics** (VIL/VIH, internal pull-up/down resistance, leakage), **SPI timing** (tsu(MI), tv) and **wake-up times**: only the first ~48 k characters of the datasheet were retrievable as text, and the sheetsdata extraction covers only Tables 4-1 and 4-41..43.
  - The **V3x RM AFIO_PCFR1/GPIO reset values** (text not retrievable). The R8-D7 conclusion rests on the DS pin table and the SDK.
- **AGM:**
  - AGRV2K **supply current**, **configuration time**, **I/O state and weak pull-up value during power-on configuration** (only the ISP state is documented), **abs max** and **clock-tree insertion delay**.
- **Oscillators:**
  - The SCTF 3C datasheet (disable time, disabled-state current, phase noise) (**[R2 ↑]** no longer relevant for X201).
  - DigiKey stock of NDK 45.1584 MHz.
- **Other:**
  - The JLCPCB class of U206 (assumed Extended).
  - LCSC numbers C25104 and C25900 (UNI-ROYAL series numbering; the parts stream should confirm).
  - The 74LVC1G08 TSSOP5 pin table: read from a flattened PDF text (B 1, A 2, GND 3, Y 4, VCC 5; parts stream to confirm against the drawing). **[R2 ↑]** U206 is now 74LVC1G11 GW SOT363-2: A 1, GND 2, B 3, Y 4, VCC 5, C 6 [DS Rev 13.1 Table 3, checked in round 2].

---

## 16. Files (folder `digital/`)

| File | Content |
|---|---|
| `report.md` | this report |
| `bom_rows.csv`, `netlist.csv` | BOM (25 lines) and netlist (245 pin rows: U201 64, U202 32 + EP, all parts) |
| `gen_netlist_bom.py` / `gen_netlist_bom_output.txt` | single-source netlist/BOM generator with checks (pin counts, net naming, BOM ↔ netlist) |
| `pin_tables.py` / `pin_tables_output.txt` | MCU/CPLD pin tables for this report |
| `clock_timing.py` / `clock_timing_output.txt` | dividers, duty, I²S setup/hold, CPLD path, SPI utilisation, MISO margins, MCLK, DPLL lock, ramps, family-change timeline |
| `usb_feedback.py` / `usb_feedback_output.txt` | feedback table with assertions, packet sizes, window resolution, FIFO depth |
| `adc_settings.py` / `adc_settings_output.txt` | RAIN formula check, TS per channel, conversion and scan times, errors |
| `currents.py` / `currents_output.txt` | current budget per rail and state |
| `levels_and_pullups.py` / `levels_and_pullups_output.txt` | FT limit, pull-down sizing, I²C, LEDs, capture tap, MCLK net, gate latency |
| `stress_table.py` / `stress_table_output.txt` | component stress |
| `sources/` | source quotes, datasheet text extracts (CH32V30x DS first 48 k, AF table, Nexperia texts), helper `search_dump_helper.py` |
