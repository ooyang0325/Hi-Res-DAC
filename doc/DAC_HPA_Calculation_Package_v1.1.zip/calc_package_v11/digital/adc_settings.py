#!/usr/bin/env python3
"""CH32V307 ADC plan (R8 round 2, decision D-13): sampling time vs source impedance, architecture, scan rate,
coupling/alias errors for the protection budget, CC classification margins, VBUS analog watchdog.

Datasheet facts (WCH CH32V303/305/307 DS, Tables 4-41..4-43 [S2]): fADC <= 14 MHz; RAIN <= 50 kOhm; RADC <= 1 kOhm;
CADC = 8 pF; tCONV = TS + 12.5 cycles; TS in {1.5, 7.5, 13.5, 28.5, 41.5, 55.5, 71.5, 239.5}; Table 4-42 = RAIN max at
14 MHz for 1/4-LSB settling.  Formula reproducing Table 4-42: RAIN_max = TS / (fADC * CADC * ln(2^(N+2))) - RADC, N = 12.
DMA: WCH's own dual-ADC example (EVT/EXAM/ADC/DualADC_RegSimul) enables DMA on ADC1 only and reads ADC2 from the upper
half of ADC1's 32-bit data register (DMA1 channel 1, word transfers); no WCH source shows an ADC2 DMA request (STM32F1
heritage: 'ADC2 has no DMA capability') -> the plan does not rely on one.
Other streams: protection 6 (R_TH 2.49 k, 4.7 uF, reading = leg - reference, g = 0.3655, a = 0.4874, alias term);
power 4.1/5.8 (R101/R102 5.1 k Rd, R103/R104 10 k, R105 100 k / R106 47 k, C103 10 nF, brown-out 4.00 V).
Round 2 final: timer-triggered 20.000 kHz, 8 conversions (protection order), dual simultaneous, TS 41.5 on all channels.
Run: python3 adc_settings.py > adc_settings_output.txt
"""
import math

CADC, RADC, N = 8e-12, 1e3, 12
TS_SET = [1.5, 7.5, 13.5, 28.5, 41.5, 55.5, 71.5, 239.5]
RAIN_ABS_MAX = 50e3
TABLE_14MHZ = {1.5: 0.4e3, 7.5: 5.9e3, 13.5: 11.4e3, 28.5: 25.2e3, 41.5: 37.2e3, 55.5: 50e3}


def rain_max(ts, fadc):
    return min(ts / (fadc * CADC * math.log(2 ** (N + 2))) - RADC, RAIN_ABS_MAX)


def par(*r):
    return 1 / sum(1 / x for x in r)


print("1. Formula vs DS Table 4-42 (fADC = 14 MHz)")
for ts, ref in TABLE_14MHZ.items():
    calc = ts / (14e6 * CADC * math.log(2 ** (N + 2))) - RADC
    print(f"   TS {ts:6.1f}: formula {calc/1e3:6.2f} kOhm, table {ref/1e3:5.1f} kOhm")
    assert abs(calc - ref) / ref < 0.03 or ts == 1.5 or (ts == 55.5 and calc > ref)

PCLK2 = 72e6
FADC = PCLK2 / 6                 # 12 MHz (SPI1 = PCLK2/2 = 36 MHz needs PCLK2 = 72 MHz; /6 is the smallest legal ADCPRE)
assert FADC <= 14e6
print()
print(f"2. RAIN max at fADC = PCLK2/6 = {FADC/1e6:.0f} MHz (cap 50 kOhm)")
for ts in TS_SET:
    print(f"   TS {ts:6.1f}: sample {ts/FADC*1e6:6.3f} us, slot {(ts+12.5)/FADC*1e6:6.3f} us, RAIN max {rain_max(ts, FADC)/1e3:5.1f} kOhm")

print()
print("3. Source impedance at each pin (worst case, resistor tolerances 1 % unless stated)")
r_vbus = par(100e3 * 1.01, 47e3 * 1.01)
r_sense_node = par(6.8e3 * 1.001, 5.1e3 * 1.001, 16.9e3 * 1.001)
R_PIN = 330 * 1.01                     # DZ-1: R242-R246 330 R 1 % at PC0-PC4 (injection limit, MCU unpowered)
r_sense = r_sense_node + R_PIN          # worst source seen by the pin (the 4.7 uF sits on the node side)
# CC: R103/R104 10 k in series; at the connector Rd 5.1 k (R101/R102) in parallel with the source's Rp.
# Rp (USB Type-C spec, values from the spec tables as remembered, not re-read here): Default 56 k +-20 % to 5 V /
# 36 k +-20 % to 3.3 V / 80 uA +-20 %; 1.5 A 22 k +-5 % / 12 k +-5 % / 180 uA +-8 %; 3.0 A 10 k +-5 % / 4.7 k +-5 % /
# 330 uA +-8 %; legacy A-to-C cable 56 k +-5 % to VBUS; the unused CC pin sees Rd only (current-source Rp = infinite).
rp_min = 4.7e3 * 0.95
r_cc_max = 10e3 * 1.01 + 5.1e3 * 1.01
r_cc_min = 10e3 * 0.99 + par(5.1e3 * 0.99, rp_min)
chans = [("VBUS_SENSE", "PA1", "ADC1 IN1", r_vbus, 100e-12), ("CC1_ADC", "PA2", "ADC2 IN2", r_cc_max, 0.0),
         ("CC2_ADC", "PA3", "ADC2 IN3", r_cc_max, 0.0), ("DC_SENSE_LP", "PC0", "ADC2 IN10", r_sense, 4.7e-6),
         ("DC_SENSE_LN", "PC1", "ADC2 IN11", r_sense, 4.7e-6), ("DC_SENSE_RP", "PC2", "ADC2 IN12", r_sense, 4.7e-6),
         ("DC_SENSE_RN", "PC3", "ADC2 IN13", r_sense, 4.7e-6), ("V3A_MON", "PC4", "ADC2 IN14", r_sense, 4.7e-6),
         ("ANA_SENSE", "PA0", "ADC2 IN0", par(100e3 * 1.01, 47e3 * 1.01), 100e-12)]   # power VE: R535/R536 100 k/47 k + C516 100 pF C0G
need = {}
for name, pin, ch, rs, cp in chans:
    ts_min = next(ts for ts in TS_SET if rs <= rain_max(ts, FADC))
    need[name] = ts_min
    if name == "VBUS_SENSE":
        cap = f", C103 {cp*1e12:.0f} pF at the pin (single channel: charge share ~0; {CADC/(cp+CADC)*3.3*1e3:.1f} mV only if multiplexed)"
    else:
        cap = (f", {cp*1e9:.0f} nF at the pin (charge share {CADC/(cp+CADC)*3.3*1e6:.1f} uV)" if cp >= 1e-9 else f", {cp*1e12:.0f} pF at the pin (full-swing share {CADC/(cp+CADC)*3.3*1e3:.0f} mV; neighbour RN ~ same voltage in operation)") if cp else ""
    print(f"   {name:12s} {pin} {ch:9s} R_src <= {rs/1e3:6.2f} kOhm -> WCH rule TS >= {ts_min} cycles{cap}")
print(f"   CC range: {r_cc_min/1e3:.2f} .. {r_cc_max/1e3:.2f} kOhm (R103/R104 10 k + Rd 5.1 k || Rp, Rp from 4.47 k to infinite)")
C_PIN = 5e-12                               # pin + pad + 330 R-to-pin trace [ASSUMP]
R_ADC_SW = 1e3                              # internal sampling switch [ASSUMP; WCH RADC not retrieved]
tau_pin = (R_PIN + R_ADC_SW) * (CADC + C_PIN)
t_settle = tau_pin * math.log(2 ** 14)
i_leak, dv_kick = 1e-6, 1.64
e_dc = i_leak * R_PIN + CADC * dv_kick * 20e3 * R_PIN
print(f"   DZ-1 330 R at PC0-PC4: the pin side is now {r_sense/1e3:.2f} kOhm worst (node {r_sense_node/1e3:.2f} k + {R_PIN:.0f} R); the 4.7 uF stays")
print(f"   on the node side, so the sample kick recharges through 330 R: tau {(R_PIN+R_ADC_SW)*(CADC+C_PIN)*1e9:.1f} ns, 1/4-LSB settling "
      f"{t_settle*1e9:.0f} ns << TS 41.5 = {41.5/FADC*1e6:.2f} us [CALC]")
print(f"   extra DC error per channel <= {e_dc*1e3:.2f} mV (leakage 1 uA x 330 R + mean sampling current 8 pF x 1.64 V x 20 kHz x 330 R)")
print(f"   -> protection adds it to its sensing error budget (DZ-1); clamp injection with the MCU unpowered <= 3.0 mA per pin (DZ-1)")
assert t_settle < 0.1 * 41.5 / FADC and r_sense < rain_max(41.5, FADC)
r_ana = par(100e3 * 1.01, 47e3 * 1.01)
tau_ana = r_ana * (100e-12 + CADC)
kick = CADC / (100e-12 + CADC)
dv_op, dv_th = 0.05, 1.61 - 1.279          # previous slot (RN node ~1.61 V) vs ANA_SENSE: in operation / at the 4.0 V threshold
res = kick * math.exp(-(41.5 / FADC) / tau_ana)
print(f"   ANA_SENSE (power VE 100 k/47 k): source {r_ana/1e3:.2f} kOhm <= WCH limit {rain_max(41.5, FADC)/1e3:.1f} kOhm at TS 41.5 [CALC];")
print(f"   with C516 100 pF the sample kick is {kick*100:.1f} % of dV, recovering with tau {tau_ana*1e6:.2f} us -> residual {res*100:.1f} % of dV at the end of TS")
print(f"   -> {res*dv_op*1e3:.1f} mV in operation, {res*dv_th*1e3:.1f} mV at the threshold (= {res*dv_th*147/47*1e3:.0f} mV at 5V_ANA_F, reads high); full recovery")
print(f"   before the next scan (50 us = {50e-6/tau_ana:.0f} tau). Threshold 1.279 V = code {round(4.0*47/147/3.3*4096)} (VBUS_SENSE uses the same divider and code).")
assert r_ana < rain_max(41.5, FADC) and res * dv_th * 147 / 47 < 0.05
dv_th_hi = 1.61 - 3.90 * 47 / 147                # R10: High-mode threshold 3.90 V (power c21 R10 addendum)
print(f"   R10: High mode (ILIM_HI = 1) uses 3.90 V = {3.90*47/147:.3f} V = code {round(3.90*47/147/3.3*4096)} (Default keeps 1587); residual at that threshold")
print(f"   {res*dv_th_hi*1e3:.1f} mV (= {res*dv_th_hi*147/47*1e3:.0f} mV at 5V_ANA_F, reads high) [CALC]")
assert res * dv_th_hi * 147 / 47 < 0.05

print()
print("4. Architecture and chosen settings (R8 round 2, aligned with protection R2.8 / R2.13-1)")
print("   ADC2 has no demonstrable DMA request -> dual regular-simultaneous mode: ADC1 = master, ADC2 = slave, one 9-slot")
print("   sequence each, SCAN = 1, CONT = 0, regular group triggered by TIM4 CC4 (internal compare event, pin not enabled) at")
print("   exactly 20.000 kHz (144 MHz / 7200); DMA1 channel 1, 32-bit circular (ADC2 result in [31:16], ADC1 in [15:0]).")
print("   ADC1 sequence: IN1 in all 9 slots (VBUS_SENSE only, the channel never changes -> R8-D6 rule kept).")
ORDER = ["CC1_ADC", "CC2_ADC", "V3A_MON (dummy, discarded)", "V3A_MON", "DC_SENSE_LP", "DC_SENSE_LN", "DC_SENSE_RP", "DC_SENSE_RN",
         "ANA_SENSE"]   # round 3 (X-5): ANA_SENSE appended as slot 9; ADC1 converts IN1 9 times (channel never changes)
print("   ADC2 sequence (protection's order): " + " -> ".join(ORDER))
print("   Simultaneous slots must stay aligned and TS is set per channel (IN1 has one TS) -> one TS for every channel; the")
print("   protection's per-channel 13.5 / 28.5 cycles would need ADC2 with its own DMA (firmware option if bring-up proves it).")
TS = 41.5
F_TRIG = 20e3
assert TS >= max(need.values())
slot = (TS + 12.5) / FADC
scan = len(ORDER) * slot
f_ch = F_TRIG
assert scan < 0.9 / F_TRIG
print(f"   TS = {TS} cycles for every channel: >= every WCH minimum (VBUS {need['VBUS_SENSE']} without C103 credit, CC "
      f"{need['CC1_ADC']}, sense {need['V3A_MON']}); RAIN allowed {rain_max(TS, FADC)/1e3:.1f} kOhm (CC 15.3 k x{rain_max(TS, FADC)/r_cc_max:.1f}, "
      f"VBUS 32.3 k x{rain_max(TS, FADC)/r_vbus:.2f} + C103, sense x{rain_max(TS, FADC)/r_sense:.0f})")
print(f"   slot {slot*1e6:.3f} us, 9-slot scan {scan*1e6:.2f} us per {1/F_TRIG*1e6:.0f} us trigger period (ADC busy {scan*F_TRIG*100:.0f} %) -> "
      f"{f_ch/1e3:.3f} kHz per channel (requirement >= 10 kHz: x{f_ch/10e3:.1f}) [CALC]")
print(f"   ADC1 converts VBUS_SENSE 9 times per scan (every {slot*1e6:.1f} us inside the burst, <= {(1/F_TRIG-scan+slot)*1e6:.1f} us gap); "
      f"analog watchdog on ADC1 IN1 (single-channel AWD).")
blk = 20
print(f"   DMA buffer 2 x {blk} scans x {len(ORDER)} words = {2*blk*len(ORDER)} x 32 bit ({2*blk*len(ORDER)*4} B); half/complete interrupt every {blk} scans = "
      f"{blk/F_TRIG*1e3:.3f} ms -> the protection estimator runs every 1.000 ms on 20 samples per channel (10 averaged pairs = its")
print("   10 kHz stream); the dummy V3A_MON word is discarded; windows defined in time (100 ms / 300 ms / 1.2 s).")
print(f"   DMA load {8*F_TRIG/1e3:.0f} k words/s (priority very high; SPI1 link DMA high); CPU: one ISR per 1.000 ms")
print("   (Round-2 first proposal: continuous 7-slot scan at TS 71.5, 20.41 kHz - replaced by this exact-rate trigger.)")
print("   Pins PA1, PA2, PA3, PC0..PC4 in analog-input mode (digital input buffer off); ADC calibration (RSTCAL, CAL,")
print("   Get_CalibrationValue) after every ADC power-up; ADC input buffer disabled, PGA x1 (as in WCH's examples).")

print()
print("5. Sample-capacitor coupling between consecutive slots (CH32V307 user-forum note, elecfans: adjacent channels couple through the sample capacitor)")
g, a = 0.3655, 0.4874
f = f_ch
k = r_sense * CADC * f
print(f"   model: CADC keeps the previous slot's voltage [ASSUMP]; charge per scan drawn from a node = CADC x (V_node - V_before);")
print(f"   the 4.7 uF node capacitor averages it, so the DC error at the node = average current x R_TH; k = R_TH x CADC x f = {k:.3e}")
v3a = (3.3 * 0.98, 3.3 * 1.02)
vref_node = (a * v3a[0], a * v3a[1])
dv_ref = max(vref_node[1] - 0.0, 2.04 - vref_node[0])          # CC2 between 0 V (open CC) and 2.04 V (vRd-3.0 max)
e_ref_node = dv_ref * k
e_ref_leg = e_ref_node / g
print(f"   V3A_MON after CC2 (0 .. 2.04 V), ref node {vref_node[0]:.2f}..{vref_node[1]:.2f} V, |dV| <= {dv_ref:.2f} V per scan:")
print(f"     without the dummy: the one V3A_MON conversion draws CADC x dV -> {e_ref_node*1e3:.2f} mV at the node")
print(f"     with the dummy:    the dummy draws the same CADC x dV from the same node, the real sample ~0 -> {e_ref_node*1e3:.2f} mV (unchanged)")
print(f"   -> {e_ref_leg*1e3:.2f} mV on every leg reading, same sign for all four legs, cancels in the pair differences; the dummy")
print("      only removes the per-sample charge-share step (<= 8 uV with 3.4 uF effective, already negligible).  Protection p09")
print("      ('the dummy makes the reference see dV = 0') misses this DC term -> add it to e_leg (R2.10 request).")
leg = 0.167
print(f"   legs follow the ref or another leg: dV = g x (leg difference); at the T3 level ({leg} V) {g*leg*k/g*1e6:.1f} uV at the leg "
      f"({k*100:.3f} % of the difference); with 2 V between adjacent legs 0.80 mV (protection p09 term, agrees)")
bound = 3.3 * k / g
print(f"   bound if CADC were left at any level 0..VDDA: {bound*1e3:.2f} mV per channel at the leg ({2*bound*1e3:.2f} mV on leg - ref) [CALC]")
alias10 = 2.228 / (2 * math.pi * 10e3 * 8.4e-3)
alias = 2.228 / (2 * math.pi * f * 8.4e-3)
print(f"   aliasing (full-scale 2.228 V pk content at k x fs, tau_min 8.4 ms): {alias10*1e3:.2f} mV at 10 kHz (protection keeps this, "
      f"conservative; pair averaging keeps the 20 kHz sampling nulls) -> {alias*1e3:.2f} mV at 20 kHz")
e_prot = 0.0510
den = (1 - 0.025) * 0.99
for lbl, e in (("model", e_prot + e_ref_leg), ("bound", e_prot + 2 * bound)):
    print(f"   protection e_leg 51.0 mV + ref coupling ({lbl}) = {e*1e3:.1f} mV -> T3 guaranteed leg level {(0.110+e)/den:.3f} V "
          f"(protection 0.167 V); T2 {(0.240+e)/den:.3f} V; T1 {(0.900+e)/den:.3f} V")
    assert (0.110 + e) / den < 0.2
print("   -> the owner's < 0.2 V rule holds in both cases; pairs are unaffected by the ref term.")

print()
print("6. CC classification (firmware: High mode only with a >= 1.5 A advertisement)")
rd = (5.1e3 * 0.99, 5.1e3 * 1.01)
cases = {
    "Default 56k+-20% to 4.75..5.5 V": (4.75 * rd[0] / (56e3 * 1.2 + rd[0]), 5.5 * rd[1] / (56e3 * 0.8 + rd[1])),
    "Default 36k+-20% to 3.3V+-5%": (3.135 * rd[0] / (36e3 * 1.2 + rd[0]), 3.465 * rd[1] / (36e3 * 0.8 + rd[1])),
    "Default 80uA+-20%": (64e-6 * rd[0], 96e-6 * rd[1]),
    "legacy cable 56k+-5% to VBUS 4.4..5.5 V": (4.4 * rd[0] / (56e3 * 1.05 + rd[0]), 5.5 * rd[1] / (56e3 * 0.95 + rd[1])),
    "1.5A 22k+-5% to 4.75..5.5 V": (4.75 * rd[0] / (22e3 * 1.05 + rd[0]), 5.5 * rd[1] / (22e3 * 0.95 + rd[1])),
    "1.5A 12k+-5% to 3.3V+-5%": (3.135 * rd[0] / (12e3 * 1.05 + rd[0]), 3.465 * rd[1] / (12e3 * 0.95 + rd[1])),
    "1.5A 180uA+-8%": (165.6e-6 * rd[0], 194.4e-6 * rd[1]),
    "3.0A 10k+-5% to 4.75..5.5 V": (4.75 * rd[0] / (10e3 * 1.05 + rd[0]), 5.5 * rd[1] / (10e3 * 0.95 + rd[1])),
    "3.0A 4.7k+-5% to 3.3V+-5%": (3.135 * rd[0] / (4.7e3 * 1.05 + rd[0]), 3.465 * rd[1] / (4.7e3 * 0.95 + rd[1])),
    "3.0A 330uA+-8%": (303.6e-6 * rd[0], 356.4e-6 * rd[1]),
}
TH1, TH2 = 0.66, 1.23          # vRd-USB/1.5 and vRd-1.5/3.0 thresholds: Type-C R2.0 sink CC table via ST AN5225 Table 7 (round 3)
err = 8 * 3.3 / 4096 + 1e-6 * 10e3 + 0.015 * 1.23 + 3.3 * r_cc_max * CADC * f   # ADC INL+offset, leakage x R103, VDDA, coupling
print(f"   measurement error <= {err*1e3:.0f} mV (8 LSB + 1 uA x 10 k + 1.5 % VDDA + coupling at 20 kHz); thresholds {TH1} V / {TH2} V")
print("   (thresholds and Rp values: USB Type-C R2.0 (Aug 2019) tables as reproduced in ST AN5225 Tables 5-7; R2.5 not opened)")
for nm, (lo, hi) in cases.items():
    cls = "USB" if hi < TH1 else ("1.5A" if lo > TH1 and hi < TH2 else ("3.0A" if lo > TH2 else "??"))
    m = min(abs(lo - TH1), abs(hi - TH1), abs(lo - TH2), abs(hi - TH2))
    print(f"   {nm:40s} CC {lo:5.3f}..{hi:5.3f} V -> {cls:4s} (closest threshold distance {m*1e3:4.0f} mV)")
    assert cls != "??" and m > err
print("   -> every Rp class is classified correctly with the worst errors; decide after a stable 100 ms (tCCDebounce class) window;")
print("      re-check every 10 ms while attached (a source may change Rp: switch back to Default ILIM within 60 ms).")

print()
print("7. VBUS_SENSE analog watchdog (ADC1, IN1, single-channel AWD)")
kdiv = 47 / 147
vth = 4.00
code = vth * kdiv / 3.3 * 4096
print(f"   brown-out threshold 4.00 V on 5V_SYS (power c09) -> pin {vth*kdiv:.4f} V -> LTR = {int(code)} (raw code at VDDA 3.30 V), HTR = 4095")
print("   band (power stream c09): 3.771..4.229 V incl. divider 1.4 %, VDDA 1.5 %, leakage, ADC error; no false trip at 4.301 V.")
tau_c103 = r_vbus * 100e-12   # X-10: C103 = 100 pF C0G
t_step = tau_c103 * math.log((5.0 - 3.5) / (4.0 - 3.5))
print(f"   latency: VBUS converted 9x per 50 us scan (gap <= {(1/F_TRIG-scan+slot)*1e6:.1f} us) plus C103 tau {tau_c103*1e6:.1f} us: a 5.0 -> 3.5 V step "
      f"trips after {t_step*1e6:.1f} us + <= 50 us scan; not a protection element (brief 3.4) -> RELAY_EN low + orderly power-down")
print(f"   single channel + C103: charge share ~0; even without C103 TS {TS} allows {rain_max(TS, FADC)/1e3:.0f} kOhm >= {r_vbus/1e3:.1f} kOhm")

print()
print("8. Accuracy facts handed to the protection stream (DS Tab 4-43 at fADC 14 MHz, RAIN < 10 kOhm, VDDA 3.3 V)")
lsb = 3.3 / 4096
print(f"   LSB {lsb*1e3:.3f} mV (VREF+ = VDDA = 3V3M on LQFP64); EO +-4 LSB (single value, no max) -> cancelled by leg - ref;")
print(f"   ED +-3 LSB max, EL +-4 LSB max; our sense nodes 2.49 kOhm and 12 MHz are inside the test condition; CC nodes are not")
print(f"   (15 kOhm) but only need +-{err*1e3:.0f} mV.  Pin leakage: standard I/O <= 1 uA (PC0..PC4, PA1..PA3) [DS Tab 4-22, round 1].")
print()
print("ADC assertions passed.")

print()
print("9. R9 E-5: VBUS_SENSE divider options (R105/R106 scaled by k from 100 k/47 k) - for the power stream's suspend margin")
I_LEAK = 1e-6            # PA1 standard-I/O input leakage max [DS Tab 4-22]
C103 = 100e-12           # X-10
ratio = 47 / 147
rth1 = par(100e3 * 1.01, 47e3 * 1.01)
print(f"   {'k':>4} {'R105/R106':>14} {'I at 5.25 V':>12} {'saving':>8} {'R_th':>9} {'leak err @5V_SYS':>17} {'AWD step lat.':>13}")
for k in (1.0, 1.5, 2.2, 4.7, 10.0):
    r1, r2 = 100e3 * k, 47e3 * k
    i = 5.25 / (r1 + r2)
    rth = par(r1 * 1.01, r2 * 1.01)
    err = I_LEAK * rth / ratio
    lat = rth * C103 * math.log(1.5 / 0.5) + 50e-6
    print(f"   {k:4.1f} {r1/1e3:6.0f}k/{r2/1e3:5.1f}k {i*1e6:9.1f} uA {(5.25/147e3 - i)*1e6:6.1f} uA {rth/1e3:7.1f} k {err*1e3:13.0f} mV {lat*1e6:10.0f} us")
print("   single channel (ADC1 IN1 in every slot) + C103: no sample-kick error at any k (dV ~ 0 between conversions); the WCH R_AIN table")
print("   does not apply. The limit is the 1 uA leakage max: k = 1.5 adds ~0.05 V to the brown-out band (A8 margin 0.17 V -> ~0.12 V),")
print("   k = 2.2 adds ~0.12 V (-> ~0.05 V, not acceptable). The divider can give <= ~12 uA (k 1.5) of the 0.2 mA E-5 target;")
print("   a switched divider (FET from 5V_SYS, gate from spare PB0, off in suspend) would save ~36 uA but is a circuit change - power's call.")
