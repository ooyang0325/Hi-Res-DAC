#!/usr/bin/env python3
"""MCLK stop versus 3V3A (VCCA) discharge at an MCU reset - why U206 gets a third input (MCLK_PERMIT).

Rule (analog S5, ESS p.4/p.7): XI may carry MCLK only while VCCA is up; XI is fed to the VCCA-powered
oscillator pad, so XI must not exceed VCCA by more than 0.3 V.  The power stream (R8) derives the 3V3A
discharge from AVCC_EN (Q502 inverter -> Q503 + R527 10 ohm).  At an MCU reset every MCU pin floats and
AVCC_EN decays slowly through R303 100 k into the Q502 gate, so the gate input B = AVCC_EN and the
discharge FET race each other.

Sources: Nexperia 74LVC1G08 / 74LVC1G11 static characteristics (VIL <= 0.8 V, VIH >= 2.0 V at
VCC 2.7-3.6 V, tpd <= 4.9 ns at 3.0-3.6 V, -40..85 C, CI 5 pF typ, input transition <= 10 ns/V recommended,
"Schmitt-trigger action at all inputs") [S9, S15]; AO3400A VGS(th) 0.65-1.45 V and the discharge network
from power/report.md 5.6 and power/calc/c06_discharge.out.txt; CH32V307 CIO 5 pF [DS Tab 4-22].
R8 round 2: X201 = Kyocera KC2520K80.0000C1GE00 (D-3 revised): output disable time t_dis <= 200 ns, oscillation stop in
stand-by, INH VIL <= 0.3 VCC [DS Kyocera spec TNY1T-H1-SEE01-04, 5-Jun-25].  Conditional second source NDK NSC5338D-80M:
disable time not stated ([MEAS] at bring-up).  D-19: protection R645 (-> Q616 gate) is fed from U206 Y (N2_MCLK_OE).
Run: python3 mclk_gate_race.py > mclk_gate_race_output.txt
"""
import math

V0 = 3.3                       # AVCC_EN high level before the reset (3V3M) [nominal]
VIL_LVC, VIH_LVC = 0.8, 2.0    # 74LVC1G08/1G11 guaranteed input levels at VCC 2.7-3.6 V [DS]
VTH_Q502 = (0.65, 1.45)        # AO3400A VGS(th) min/max [DS via power stream]
TPD_GATE = 4.9e-9              # 74LVC1G11 tpd max, 3.0-3.6 V, -40..85 C [DS]
T_DIS = 200e-9                 # Kyocera KC2520K80 t_dis max [DS]
R303 = 100e3                   # AVCC_EN pull-down (power stream)
C_EN = (0.3e-9, 1.0e-9)        # AVCC_EN node: Q502 gate + LP5907 EN + U206 + MCU pin [ASSUMP; power stream uses tau ~64 us]
R_DIS = 10.05                  # R527 10 ohm + Rds(on) [power stream]
C_3V3A = (3.5e-6, 6.71e-6)     # 3V3A node incl. AVCC_L/R: DC-bias/tolerance low bound [ASSUMP] .. power-stream upper bound
DV_ALLOWED = 0.3               # XI <= VCCA + 0.3 V
R_OUT_OSC, VF_CLAMP, R203 = 25.0, 0.5, 33.0   # X201 output resistance, pad-clamp forward drop [ASSUMP], series R [netlist]

print("1. Old gate (74LVC1G08, X201 E/D = MCLK_EN AND AVCC_EN) at an MCU reset - worst datasheet corner")
print("   AVCC_EN decays with tau = R303 x C_EN; Q502 turns off (3V3A discharge may start) when AVCC_EN < VGS(th);")
print("   the gate is only guaranteed to read LOW below VIL = 0.8 V.  Discharge-FET gate delay taken as 0 (lower bound).")
worst = None
for c_en in C_EN:
    tau = R303 * c_en
    t_q502 = tau * math.log(V0 / VTH_Q502[1])          # earliest discharge start
    t_gate = tau * math.log(V0 / VIL_LVC)              # latest guaranteed gate switch
    for c_a in C_3V3A:
        tau_a = R_DIS * c_a
        t_drop = tau_a * math.log(V0 / (V0 - DV_ALLOWED))
        window = t_gate - (t_q502 + t_drop)
        v_a = V0 * math.exp(-max(0.0, t_gate - t_q502) / tau_a)
        i_pk = max(0.0, (V0 - v_a - VF_CLAMP) / (R203 + R_OUT_OSC))
        print(f"   tau_EN {tau*1e6:5.1f} us, tau_3V3A {tau_a*1e6:5.1f} us: Q502 off at {t_q502*1e6:5.1f} us, "
              f"3V3A 0.3 V low at {(t_q502+t_drop)*1e6:5.1f} us, gate low at {t_gate*1e6:6.1f} us -> "
              f"window {window*1e6:+6.1f} us + t_dis; 3V3A then {v_a:4.2f} V, clamp current <= {i_pk*1e3:4.1f} mA peak")
        if worst is None or window > worst[0]:
            worst = (window, i_pk)
print(f"   -> worst case: XI driven up to {worst[0]*1e6:.0f} us (+ X201 disable time) after VCCA fell 0.3 V below it,")
print(f"      pad-clamp current up to ~{worst[1]*1e3:.0f} mA peak [CALC with ASSUMP R_out/Vf]. Outside every published limit.")
typ = (1.5, 1.0)   # typical LVC threshold vs typical Vth: the gate normally wins
tau = 64e-6
print(f"   (typical: gate at ~{typ[0]} V, Q502 at ~{typ[1]} V, tau 64 us -> gate first by "
      f"{tau*math.log(typ[0]/typ[1])*1e6:.0f} us; the problem exists only at the datasheet corners)")
assert worst[0] > 0

print()
print("2. New gate (74LVC1G11, X201 INH = MCLK_EN AND AVCC_EN AND MCLK_PERMIT), MCLK_PERMIT = MCU PB14 + R234 10 k")
R234 = 10e3
c_pb14 = 5e-12 + 5e-12 + 3e-12           # MCU CIO 5 pF [DS] + U206 CI 5 pF [DS-typ] + 3 pF trace [ASSUMP]
tau_p = R234 * c_pb14
t_low = tau_p * math.log(V0 / VIL_LVC)
t_oe = t_low + TPD_GATE
t_first_discharge = min(R303 * C_EN[0] * math.log(V0 / VTH_Q502[1]) + R_DIS * C_3V3A[0] * math.log(V0 / (V0 - DV_ALLOWED)), 1)
print(f"   PB14 floats at reset -> R234 pulls it below 0.8 V in {t_low*1e9:.0f} ns (tau {tau_p*1e9:.0f} ns); U206 Y low after "
      f"{t_oe*1e9:.0f} ns; Kyocera t_dis <= {T_DIS*1e9:.0f} ns [DS] -> X201 stopped <= {(t_oe+T_DIS)*1e6:.2f} us")
print(f"   earliest 3V3A 0.3 V drop (fast corner of section 1): {t_first_discharge*1e6:.1f} us -> margin "
      f"{(t_first_discharge - t_oe - T_DIS)*1e6:.1f} us, all terms datasheet limits [CALC]")
assert t_first_discharge - t_oe - T_DIS > 20e-6
c_xi = 13.1e-12
t_xi = 10e3 * c_xi * math.log(V0 / 0.4)
print(f"   after the stop, R227 10 k discharges the XI net ({c_xi*1e12:.1f} pF) below VIL 0.4 V in {t_xi*1e9:.0f} ns (if the")
print(f"   stand-by output is Hi-Z; the Kyocera spec does not state it - a driven-low output only makes it faster)")
print("   NDK NSC5338D-80M (conditional 2nd source): disable time not stated -> acceptance at bring-up: stopped <= 10 us after INH low [MEAS]")
slope = (V0 / 2) / tau_p
print(f"   slew at the threshold {1/slope*1e9:.0f} ns/V (Nexperia recommends <= 10 ns/V; one-time reset edge, inputs have")
print(f"   Schmitt-trigger action per the data sheet); AVCC_EN edge at reset is {R303*C_EN[0]/1.65*1e6:.0f}-{R303*C_EN[1]/1.65*1e6:.0f} us/V (same remark).")
print(f"   R234 current while PB14 is high: {V0/R234*1e3:.2f} mA (configured states only; 0 at attach and in suspend)")
leak = 1e-6                                 # 74LVC1G11 II max +-1 uA (-40..85 C) [DS]
print(f"   leakage margin: 1 uA x 10 k = {leak*R234*1e3:.0f} mV << VIL 0.8 V")

print()
print("3. Firmware error case: AVCC_EN driven low (push-pull edge <= 5 ns [DS Tab 4-24]) while MCLK runs")
R526, c_q503 = 22e3, 0.3e-9                 # discharge-FET gate pull-up and a low-bound gate capacitance [ASSUMP]
t_on = R526 * c_q503 * math.log(V0 / (V0 - VTH_Q502[0]))
t_a = R_DIS * C_3V3A[0] * math.log(V0 / (V0 - DV_ALLOWED))
print(f"   gate + Kyocera stop within ~{(5e-9+TPD_GATE+T_DIS)*1e9:.0f} ns; Q503 needs >= {t_on*1e6:.2f} us to reach 0.65 V, then "
      f"3V3A needs {t_a*1e6:.1f} us to fall 0.3 V -> margin {(t_on+t_a-5e-9-TPD_GATE-T_DIS)*1e6:.1f} us (hardware-backed by input B)")
print()
print("4. Controlled sequences (firmware): RELAY_EN low -> 1.1 ms -> reg 14 = 0x03 ramp (1.4 ms) -> MCLK_PERMIT = 0, MCLK_EN = 0 -> RESETB low ->")
print("   AUD_EN/AVCC_EN low -> no race.  Brown-out ISR: RELAY_EN and AVCC_EN low together; U206 input B stops MCLK first (section 3).")

print()
print("5. Every path that stops MCLK versus the output-switch permit (D-19: Q616 gate = N2_MCLK_OE via R645 1 k)")
R645, CG = 1e3, 1e-9                          # protection: Q616 gate adds 1 k + <= 1 nF to N2_MCLK_OE
t_q616 = R645 * CG * math.log(3.3 / 0.45)      # gate from 3.3 V to below 0.45 V (0.2 V under VGS(th) min)
t_q616_r235 = (100e3 + R645) * CG * math.log(3.3 / 0.45)   # U206 unpowered: discharge through R235
paths = [
    ("CPLD clears MCLK_EN (SPI write, CPLD reset/reconfiguration)", "U206 Y low -> Q616 off", "HW"),
    ("MCU reset / IWDG: PB14 floats -> R234", "U206 Y low in 0.19 us -> Q616 off; RELAY_EN -> R646 as well", "HW"),
    ("firmware drops MCLK_PERMIT while RELAY_EN is high", "U206 Y low -> Q616 off (was firmware-only before D-19)", "HW"),
    ("firmware drops AVCC_EN while RELAY_EN is high", "U206 Y low -> Q616 off at once (was 'late' via the CM window)", "HW"),
    ("3V3D collapse (AUD_EN low / brownout)", "U206 unpowered -> R235 holds Y and the Q616 gate low", "HW"),
]
for p, effect, tag in paths:
    print(f"   [{tag}] {p}: {effect}")
print(f"   Q616 gate (<= 1 nF) through R645 into U206 Y: {t_q616*1e6:.2f} us to < 0.45 V -> switch open <= 1.002 ms after N2_MCLK_OE falls;")
print(f"   U206 unpowered: through R235 + R645 {t_q616_r235*1e6:.0f} us -> <= 1.204 ms (protection p05 numbers)")
print("   frozen-DAC-code exposure <= ~1 ms -> the protection's frozen-code residual no longer")
print("   applies to any MCLK stop the design itself commands; only an oscillator failing while enabled remains (protection 4.4).")
print("   U206 Y load: X201 INH (CMOS input, current not stated [ASSUMP << 100 uA]) + R235 34 uA + R645/<= 1 nF (<= 3.3 mA transient)")
print("   -> VOH >= VCC - 0.1 V static [DS 74LVC1G11 at 100 uA].")
print("   Firmware keeps the ordering rule anyway (RELAY_EN low >= 1.1 ms before MCLK_PERMIT/AVCC_EN fall) to avoid a hard switch-off.")
print("All MCLK-gate race assertions passed.")
