#!/usr/bin/env python3
"""Digital-stream current budget per rail and USB state (R8 round 3: X-6/X-7/X-10 parts, DX-2 suspend wake; inputs for power c03/c17).

Tags: DS = datasheet maximum, DS-typ = typical only, CALC = computed here, ASSUMP = assumption, PH = placeholder.
Rails: 3V3D = TLV76733 +-1 % [DS via power pw_common] -> 3.333 V max used; 3.40 V (+3 %) shown as a sensitivity.
       3V3M = TPS7A2033 +-1.5 % [DS via power] -> 3.35 V max.
Decision-file values (integration/decisions_r8b.md): MCU 80 mA [ASSUMP], CPLD 40 mA [ASSUMP], X201 Kyocera KC2520K80 (D-3 revised),
one NDK running 15 mA + other stand-by 35 uA [DS 25 C] (D-4), U205 4.7 mA, R234 0.33 mA, I2C 4.7 k. Round 3: R233 retired (X-7),
R240 100 k (Q207 gate) 33 uA while PA8 is low, U208 74LVC3G34 on 3V3D, JTAG pull bounds, suspend RTC/IWDG wake (DX-2).
Run: python3 currents.py > currents_output.txt
"""
V3D = 3.3 * 1.01
V3D_HI = 3.3 * 1.03
V3M = 3.3 * 1.015


def x201_kyocera(v):
    """Kyocera KC2520K80.0000C1GE00: ICC <= 8.0 mA loaded (CL 15 pF max, 2.8 < VCC <= 3.63 V, over temperature; 'all electrical
    characteristics defined on the maximum loaded condition') [DS]; our load 14.4 pF (incl. protection R665 tap 1.29 pF) <= 15 pF; + R227 10 k DC load at 50 % duty."""
    return 8.0e-3 + 0.5 * v / 10e3


def x201_epson(v, c_load=13.1e-12, f=75e6):
    """Obsolete D-3 original (reference only): 3.0 mA no load + fo x L_CMOS x VCC [DS] + R227."""
    return 3.0e-3 + f * c_load * v + 0.5 * v / 10e3


def d3(v):
    """3V3D loads owned by the digital stream at rail voltage v, playing, one family oscillator (steady state)."""
    return [
        ("U202 AGRV2KQ32 CPLD", 40e-3, "ASSUMP", "no AGM figure; decision-file value; [MEAS] at bring-up"),
        ("X201 Kyocera KC2520K80 80 MHz + R227", x201_kyocera(v), "DS/CALC",
         "8.0 mA max loaded (15 pF, over temperature) [DS] + R227 50 % duty; our load 14.4 pF (XI 10 pF [DS] + trace 2.6 + pads 0.5 [ASSUMP] + R665 tap 1.29 pF)"),
        ("X202 or X203 NDK NZ2520SDA, running", 15e-3, "DS", "ICC max 15 mA at 25 C (no over-temperature maximum published)"),
        ("X203 or X202 NDK NZ2520SDA, stand-by", 35e-6, "DS", "IST max 35 uA at 25 C"),
        ("U205 74LVC1G157 mux at 49.152 MHz", (18e-12 + 10e-12) * v * 49.152e6 + 4e-6, "DS-typ/CALC",
         "CPD 18 pF [DS-typ] + 10 pF load (R215, FAM_CLK trace, CPLD pin) [ASSUMP] + ICC 4 uA [DS]"),
        ("U206 74LVC1G11 gate", 4e-6, "DS", "ICC max 4 uA; output static except at enable edges"),
        ("R218 (MCLK_EN) + R212 or R213 (active OSCxx_EN) 10 k", 2 * v / 10e3, "CALC", "two enables high in steady state"),
        ("R216 or R217 10 k at the running oscillator output", 0.5 * v / 10e3, "CALC", "50 % duty; the stand-by output is Hi-Z"),
        ("R235 100 k at U206 Y (new)", v / 100e3, "CALC", "Y high while MCLK runs"),
        ("R207/R208 10 k I2C pull-ups (DZ-2), both lines low", 2 * v / (10e3 * 0.99), "CALC", "worst static; 0 with the bus idle (was 4.7 k)"),
        ("MCU internal pull-downs on 3V3D-driven inputs", 5 * v / 30e3, "ASSUMP",
         "MISO, IRQ, DAC_LOCK high + LRCLK_FB and 3 capture taps at 50 %; 30 k assumed (WCH value not retrieved); moved from 3V3M"),
        ("R231 CPLD_NRST pull-up", 0.0, "CALC", "0 unless CPLD_NRST is held low"),
        ("U208 74LVC3G34 link buffer (X-7)", u208(v), "DS/CALC/ASSUMP",
         "ICC 10 uA [DS TI] + (CPD 14 pF [DS-typ] + CL 6 pF [ASSUMP: CPLD pin + 5 mm]) x V x (SCK 36 MHz + MOSI <= 18 MHz) x 70 % burst duty (384 kHz)"),
        ("R238/R239 JTMS/JTCK 10 k vs unpublished AGRV2K internal pulls", 2 * v / (10e3 + 30e3), "ASSUMP",
         "bound for internal pulls >= 30 k of the opposite sense; 0 if none (typical)"),
    ]


def u208(v, duty=0.70, cl=6e-12):
    return 10e-6 + (14e-12 + cl) * v * (36e6 + 18e6) * duty   # VE: TI ICC <= 10 uA [DS]; CPD 14 pF kept (TI CPD typ not larger [ASSUMP])


def m3(v, leds=("G",), resetb=True, permit=True):
    items = [("U201 CH32V307RCT6, 144 MHz, USBHS active", 80e-3, "ASSUMP",
              "WCH gives only typicals (22.4 mA at 144 MHz, all peripherals); PHY current unpublished")]
    if "G" in leds:
        items.append(("D705 green LED via R701 1 k", (v - 2.6) / 990, "CALC", "VF min 2.6 V, R -1 %"))
    if "R" in leds:
        items.append(("D706 red LED via R702 2.2 k", (v - 1.8) / 2178, "CALC", "VF min 1.8 V, R -1 %"))
    if resetb:
        items.append(("R240 100 k Q207 gate pull-up (PA8 low = DAC released, X-7)", v / (100e3 * 0.99), "CALC", "PA8 low; 0 with PA8 high"))
    if permit:
        items.append(("R234 10 k (MCLK_PERMIT high, PB14)", v / (10e3 * 0.99), "CALC", "PB14 high"))
    return items


def tot(items):
    return sum(i[1] for i in items)


def show(title, items):
    print(title)
    for n, i, tag, note in items:
        print(f"   {n:56s} {i*1e3:8.3f} mA [{tag}]  {note}")
    print(f"   {'TOTAL':56s} {tot(items)*1e3:8.3f} mA")


show(f"1. 3V3D digital loads, playing, steady state (3V3D {V3D:.3f} V max)", d3(V3D))
d3_play = tot(d3(V3D))
print(f"   sensitivity at 3V3D {V3D_HI:.2f} V: {tot(d3(V3D_HI))*1e3:.2f} mA (X201 {x201_kyocera(V3D_HI)*1e3:.2f} mA)")
x = x201_kyocera(V3D)
print(f"   X201 + R227: {x*1e3:.2f} mA at {V3D:.3f} V ({x201_kyocera(V3D_HI)*1e3:.2f} mA at {V3D_HI:.2f} V) vs D-3 revised budget 8.2 mA -> "
      f"{'confirmed' if x <= 8.2e-3 else 'exceeded'} [DS + CALC]")
assert x <= 8.2e-3
fam = 15e-3 - 35e-6 + V3D / 10e3
print(f"   family change (<= 10 ms): second NDK running + third enable pull-down: +{fam*1e3:.2f} mA")
misc = sum(i[1] for i in d3(V3D) if i[0].startswith(("U206", "R218", "R216", "R235", "R207", "MCU internal")))
print(f"   'U206 + pull-downs + I2C 4.7 k + misc' group (decision file ~2.9 mA): {misc*1e3:.2f} mA")
print()
show(f"2. 3V3M digital loads, configured/playing (3V3M {V3M:.3f} V max), green LED only", m3(V3M))
print()

states = []
m_attach = m3(V3M, leds=("G",), resetb=False, permit=False)
states.append(("S1 attached, not configured (3V3M only)", tot(m_attach), 0.0,
               "MCU at 80 mA [ASSUMP], one LED, PA8 high (R240 0 A), PB14 low, 3V3D off"))
states.append(("S2/S3 configured idle / playing", tot(m3(V3M)), d3_play, "switch closed or open: same digital share"))
states.append(("S3f family change, <= 10 ms", tot(m3(V3M)), d3_play + fam, "both NDKs running for <= 10 ms, audio muted"))
# programming mode (D-15): domains up through AUD_EN, RESETB low, MCLK off (PB14 low -> X201 stand-by 2.7 uA), switch open.
d_prog = []
for n, i, tag, note in d3(V3D):
    if n.startswith("X201"):
        d_prog.append(("X201 in stand-by (MCLK_PERMIT low) [DS IST 5 uA]", 5e-6, "DS", "R227: 0"))
    elif n.startswith("X203 or X202"):
        d_prog.append(("second NDK: may run if the CPLD ISP weak pull-up (value unpublished) beats R212/R213", 15e-3, "DS/ASSUMP",
                       "worst case both run"))
    elif n.startswith("R218"):
        d_prog.append(("R212/R213/R218 against CPLD ISP pull-ups (bound V/10 k each)", 3 * V3D / 10e3, "CALC", "bound"))
    elif n.startswith("R216"):
        d_prog.append(("R216 + R217 (both oscillators running, worst)", V3D / 10e3, "CALC", "bound"))
    elif n.startswith("R235") or n.startswith("R207"):
        continue
    else:
        d_prog.append((n, i, tag, note))
m_prog = m3(V3M, leds=("G", "R"), resetb=False, permit=False) + [("PC13 PROG internal pull-up while TP732 is shorted", V3M / 30e3,
                                                                 "ASSUMP", "30 k assumed; only while the strap is held")]
states.append(("S5 programming mode (D-15; CPLD/JTAG)", tot(m_prog), tot(d_prog), "RESETB low, MCLK off, switch open, worst oscillators"))
I_WAKE = 4.54e-6   # DX-2: RTC-alarm IWDG wake every 30,000 LSI cycles (0.50-1.20 s), firmware_sequences.py section 10 [CALC on ASSUMP]
I_PC14 = 3.343 / 1e6  # R9 E-16: PC14 high into R537 1 M (Q507 gate, power) in suspend; 3V3M max 3.343 V (TPS70933)
I_WAKE = I_WAKE + I_PC14
states.append(("S6 suspend", 1.9e-3 + I_WAKE, 0.0,
               "MCU Stop + USBHS PHY suspended 1.9 mA [PH, v0.8 value; WCH typ Stop 110 uA, PHY unpublished] + IWDG wake 4.5 uA (DX-2) + PC14 into R537 3.3 uA (E-16); 5V_SYS off in suspend (E-16)"))

print("3. Per USB state, digital share (maxima; the DAC DVCC/DVDD, analog, protection and power lines are separate)")
print(f"   {'state':42s} {'3V3M':>9s} {'3V3D':>9s} {'sum':>9s}  note")
for nm, m, d, note in states:
    print(f"   {nm:42s} {m*1e3:7.2f} mA {d*1e3:7.2f} mA {(m+d)*1e3:7.2f} mA  {note}")
print()
show("   S5 detail, 3V3D:", d_prog)
print()
print("4. Suspend detail (3V3D off -> CPLD, oscillators, logic, pull-ups = 0 mA)")
for n, v in (("MCU Stop, USBHS PHY suspended [PH 1.9 mA, kept]", 1.9e-3), ("LEDs off", 0.0),
             ("PB14/PC10-12/PA11/PA15 low, PB8 spare (analog input) -> R234/pull-downs 0 A", 0.0),
             ("PA8 HIGH (DAC reset state) -> R240 0 A; Q207 on into a dead DVCC -> 0 A", 0.0),
             ("N2_LINK_*_MCU low -> U208 IOFF 0 A (3V3D off)", 0.0),
             ("RTC-alarm wake refreshing the IWDG (DX-2) + PC14 high into R537 1 M (E-16)", I_WAKE),
             ("MCU inputs from 3V3D (3V3D = 0 V) and PB1 readback: 0 A", 0.0),
             ("U206 IOFF: <= 2 uA [DS] from its inputs, sourced by pins that are low -> 0 A", 0.0)):
    print(f"   {n:78s} {v*1e3:5.3f} mA")
print("   D+ pull-up 0.214 mA and all power-stream items are counted in power c08/c17.")
print()
print("4a. Round-3 items counted by the POWER stream (c17), listed here only so nothing is counted twice (0 in the digital share):")
print(f"   R237 4.7 k + R508 10 k, AUD_EN high (PC10 high): {V3M/(4.7e3*0.99+10e3*0.99)*1e3:.3f} mA on 3V3M (power c17: 0.230 mA)")
print(f"   R305 10 k (analog) through Q207 while the DAC is held in reset with 3V3D on (S5, power-up): {V3D/(10e3*0.99)*1e3:.3f} mA on 3V3D")
print("   R236 10 k: no DC current with 3V3A good (U206 CMOS input); 0.35 mA only while U605A pulls N2_AVCC_EN_G low (transient)")
print(f"   U208 in the digital share above: {u208(V3D)*1e3:.2f} mA at 384 kHz ({u208(V3D, duty=0.103)*1e3:.2f} mA at 44.1 kHz) vs power c17")
print(f"   placeholder 1.667 mA -> +{(u208(V3D)-1.667e-3)*1e3:.2f} mA; JTAG pull bound +{2*V3D/40e3*1e3:.3f} mA (not in c17).")
print()
print("5. Comparison with round 1 and alternatives")
r1 = 102.53e-3
print(f"   3V3D digital share: round 1 {r1*1e3:.1f} mA -> {d3_play*1e3:.1f} mA ({(d3_play-r1)*1e3:+.1f} mA): X201 40 -> {x*1e3:.2f} mA (Kyocera),")
print("   MCU internal pull-downs moved in from 3V3M, R235 added, rail 3.40 -> 3.333 V.")
ndk = 9.0e-3 + 80e6 * 14.4e-12 * V3D + 0.5 * V3D / 10e3   # NDK NSC5338D-80M: 9 mA max at 25 C, load not stated -> add C*V*f [ASSUMP]
print(f"   conditional 2nd source NDK NSC5338D-80M: 9.0 mA (25 C, load not stated) + 80 MHz x 14.4 pF x V + R227 = {ndk*1e3:.2f} mA "
      f"[ASSUMP] -> budget 12.7 mA (D-3 revised), {(ndk-x)*1e3:+.2f} mA vs Kyocera")
print(f"   obsolete Epson SG-210STF 75 MHz (original D-3): {x201_epson(V3D)*1e3:.2f} mA - reference only; TXC 7X withdrawn (15.2 mA, runs")
print("   while disabled); SCTF SX3M80 (40 mA) NOT approved.")
sctf = 2 * 20e-3 - (15e-3 + 35e-6)
print(f"   SCTF SX3M49.152/45.1584 on X202/X203 (output-disable only, both run, 20 mA each [DS-listing]): {sctf*1e3:+.2f} mA steady ->")
print("   NON-COMPLIANT fallback (Default power targets not met, power c03: best Default IOS min 161.7 mA < 174.2 mA need) (D-4).")
