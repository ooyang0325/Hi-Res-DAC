#!/usr/bin/env python3
"""Generate netlist.csv and bom_rows.csv for the digital stream (block 2 + D705/D706, R701/R702, J703/R703, TP732).

Single source of truth for pins and nets; runs consistency checks:
  - all 64 MCU pins and all 32 CPLD pins + exposed pad present exactly once,
  - every net name is either an interface net of brief Section 5, GND/NC, or a block-internal N2_/N7_ net,
  - every net connects to >= 2 pins inside this netlist unless it is an interface net (other streams),
  - BOM refs == netlist refs.
Run: python3 gen_netlist_bom.py > gen_netlist_bom_output.txt
"""
import csv
import re
from collections import defaultdict

IFACE = set("""VBUS 5V_SYS GND 3V3M 3V3D 1V3 3V3A 5V_ANA 5V_ANA_F VPOS VNEG USB_DP USB_DN CC1 CC2 CC1_ADC CC2_ADC VBUS_SENSE
AUD_EN AVCC_EN ANA_EN ANA_SENSE ILIM_HI RELAY_EN DAC_RESETB LED_G LED_R RAILS_OK_N ANA_FAULT_N DC_PERMIT_N
CPLD_IRQ DAC_LOCK LRCLK_FB PROG DC_SENSE_LP DC_SENSE_LN DC_SENSE_RP DC_SENSE_RN V3A_MON LINK_SCK LINK_MOSI LINK_MISO
LINK_FRAME I2C_SCL I2C_SDA SWDIO SWCLK NRST BOOT0 USART_TX USART_RX CPLD_JTMS CPLD_JTCK CPLD_NRST MCLK MCLK_EN FAM_CLK
OSC48_EN OSC44_EN BCLK LRCLK SDATA""".split())
RETIRED = {"DOM_DIS", "AMP_EN", "RAIL_EN", "N2_SCK_CPLD", "N2_MOSI_CPLD", "N2_RESETB_MCU"}   # R8 FU-1 + round 3 (X-1 RAIL_EN deleted; X-7 nets replaced)

rows = []          # (refdes, pin, pin_name, net, note)


def add(ref, pin, name, net, note=""):
    rows.append((ref, str(pin), name, net, note))


# ---------------------------------------------------------------- U201 CH32V307RCT6 (LQFP-64M)
MCU = [
    (1, "VBAT", "3V3M", "no backup battery; tied to 3V3M, 100 nF C203"),
    (2, "PC13-TAMPER-RTC", "PROG", "input, internal pull-up; TP732 shorted to GND at reset = programming mode"),
    (3, "PC14-OSC32_IN", "N5_U102_OFF", "R9 E-16: push-pull (RTC-domain pin, static gate signal): HIGH = Q507 (power) on = U102 EN low = 5V_SYS off (suspend only, after ANA_EN/AVCC_EN/AUD_EN are low); LOW in every other state; floats at reset -> R537 1M -> U102 on (default on)"),
    (4, "PC15-OSC32_OUT", "N6_ORTEST", "R10 F-1 (protection OR self-test line): push-pull, LOW in every state except the boot OR self-test (g), high <= 32 ms per run, low again in the DC_PERMIT_N EXTI at the trip; RTC-domain pin, static load <= 34 uA (R950 100 k to Q627 base + V_OR- divider); Hi-Z at reset -> protection divider pulls to about -0.5 V via 470 k (<= 8 uA negative injection into the pin clamp, << +-5 mA IINJ [ASSUMP STM32F1-class], only while VNEG is up and before GPIO init; no ADC conversion then); no series R needed"),
    (5, "OSC_IN", "N2_HSE_IN", "Y201 8 MHz"),
    (6, "OSC_OUT", "N2_HSE_OUT", "Y201 8 MHz"),
    (7, "NRST", "NRST", "R201 10k pull-up, C212 100 nF, J201-4"),
    (8, "PC0", "N2_DCS_LP_PIN", "DZ-1: via R242 330R from DC_SENSE_LP (injection <= 3.0 mA); ADC2 IN10, slot 5 of 9, TS 41.5 cyc, 20.000 kHz per channel (D-13); R_TH 2.49 k + 4.7 uF (protection)"),
    (9, "PC1", "N2_DCS_LN_PIN", "DZ-1: via R243 330R from DC_SENSE_LN; ADC2 IN11, slot 6 (as PC0)"),
    (10, "PC2", "N2_DCS_RP_PIN", "DZ-1: via R244 330R from DC_SENSE_RP; ADC2 IN12, slot 7 (as PC0)"),
    (11, "PC3", "N2_DCS_RN_PIN", "DZ-1: via R245 330R from DC_SENSE_RN; ADC2 IN13, slot 8 (as PC0)"),
    (12, "VSSA", "GND", ""),
    (13, "VDDA", "3V3M", "must equal VIO [DS 2.5.3]; C204 100 nF + C221 1 uF"),
    (14, "PA0-WKUP", "ANA_SENSE", "X-5: ADC2 IN0, slot 9 of 9 (TS 41.5 cyc, 20.000 kHz); 5V_ANA_F divider R535/R536 100k/47k + C516 100 pF C0G at the pin (power VE), <= 1.799 V at 5.55 V, source 32.0 k; < 4.0 V = 1.279 V at the pin = ADC code 1587 at VDDA 3.30 V with ANA_EN high > 5 ms after the start-up window = supply fault in every state -> ANA_EN low"),
    (15, "PA1", "VBUS_SENSE", "ADC1 IN1 only (all 9 slots, dual regular-simultaneous master, TIM4-triggered 20 kHz), TS 41.5 cyc, AWD LTR 1587 = 4.00 V; C103 100 pF C0G (power, X-10)"),
    (16, "PA2", "CC1_ADC", "ADC2 IN2, slot 1 of 9 (TS 41.5 cyc, 20.000 kHz); source 12.3-15.3 k (R103 + Rd||Rp); thresholds 0.2 / 0.66 / 1.23 V (Type-C R2.0 sink CC table)"),
    (17, "PA3", "CC2_ADC", "ADC2 IN3, slot 2 of 8 (as CC1)"),
    (18, "VSS_4", "GND", ""),
    (19, "VDD_4", "3V3M", "C205 + C206 100 nF (USB PHY supply side)"),
    (20, "PA4", "N2_LINK_FRAME_MCU", "GPIO push-pull, active high -> U208 3A (X-7: Ioff buffer on 3V3D at the CPLD); set low before AUD_EN falls"),
    (21, "PA5", "N2_LINK_SCK_MCU", "SPI1_SCK AF push-pull 36 MHz (writes) / 9 MHz (register reads); R224 33R at this pin -> U208 1A (X-7)"),
    (22, "PA6", "LINK_MISO", "SPI1_MISO input, internal pull-down"),
    (23, "PA7", "N2_LINK_MOSI_MCU", "SPI1_MOSI AF push-pull; R225 33R at this pin -> U208 2A (X-7)"),
    (24, "PC4", "N2_V3A_MON_PIN", "DZ-1: via R246 330R from V3A_MON; ADC2 IN14, slots 3 (dummy, discarded) and 4 of 9 (reference: reading = leg - ref); R_TH 2.49 k + 4.7 uF (protection)"),
    (25, "PC5", "CPLD_NRST", "GPIO open-drain only (never push-pull high); R231 10k pull-up on the CPLD side"),
    (26, "PB0", "N6_ARM_MCU", "R9 E-2 (protection request): input, no pull - re-arm latch readback via R695 100k from N6_ARM (U608 74LVC1G74 on 3V3D); high = armed; must read high <= 1 ms after each RELAY_EN rising edge"),
    (27, "PB1", "N2_MCLK_OE", "floating input (R235 defines it): readback of the X201 run / Q616 permit signal for the boot self-test of U206/R234 (D-19); never an output"),
    (28, "PB2/BOOT1", "N2_BOOT1", "R232 10k pull-down: BOOT1 defined 0 (BOOT0 pad selects the system bootloader)"),
    (29, "PB10", "I2C_SCL", "I2C2_SCL open-drain, 100 kHz; R207 4.7k to 3V3D"),
    (30, "PB11", "I2C_SDA", "I2C2_SDA open-drain; R208 4.7k to 3V3D"),
    (31, "VSS_1", "GND", ""),
    (32, "VIO_1", "3V3M", "C207 100 nF; VIO <= VDD [DS 2.5.3]"),
    (33, "PB12", "N2_CAP_WS", "I2S2_WS slave-receive input (on-board I2S capture), R229"),
    (34, "PB13", "N2_CAP_CK", "I2S2_CK slave input, R228"),
    (35, "PB14", "N2_MCLK_PERMIT", "GPIO push-pull (never SPI2 AF); U206 input C; R234 10k pull-down: MCLK stops <0.2 us after any MCU reset"),
    (36, "PB15", "N2_CAP_SD", "I2S2_SD slave-receive input, R230"),
    (37, "PC6", "LED_G", "push-pull, active high, R701"),
    (38, "PC7", "LED_R", "push-pull, active high, R702"),
    (39, "PC8", "CPLD_IRQ", "input, internal pull-down, EXTI8"),
    (40, "PC9", "DAC_LOCK", "input, internal pull-down (DAC GPIO2 tri-stated in reset), EXTI9"),
    (41, "PA8", "N2_RESET_DRV", "X-7: push-pull; LOW = DAC released (Q207 off, R305 10k pulls RESETB to DVCC); HIGH or floating (MCU reset: R240 100k to 3V3M) = Q207 on = DAC in reset; keep HIGH whenever AUD_EN is low (no R240 current in suspend)"),
    (42, "PA9", "USART_TX", "USART1_TX debug, J201-7"),
    (43, "PA10", "USART_RX", "USART1_RX debug, J201-8, input pull-up"),
    (44, "PA11", "RELAY_EN", "push-pull; protection load R662/R663 LED-sink reference + R646 100k pull-down = 66 uA, no capacitor; floats in reset -> switch open <= 1.01 ms; USBFS/USBD never enabled (PA11/PA12 are their pins)"),
    (45, "PA12", "N6_V3AG_A_MCU", "input, no pull (protection request): U605 ch1 3V3A-good readback via R688 470k; high = 3V3A not good, low = good (boot self-test d)"),
    (46, "PA13", "SWDIO", "SDI data at reset [DS pin table 'Main function (after reset) SWDIO']; J201-2"),
    (47, "VSS_2", "GND", ""),
    (48, "VDD_2", "3V3M", "C208 + C209 100 nF"),
    (49, "PA14", "SWCLK", "SDI clock at reset [DS]; J201-3"),
    (50, "PA15", "ILIM_HI", "push-pull -> U505 TMUX1101 SEL (fail-safe 5.5 V; 1 = High limit), R511 pull-down (power); floating GPIO at reset (no JTAG on CH32V307)"),
    (51, "PC10", "N2_AUD_EN_MCU", "push-pull -> R237 4.7k -> AUD_EN (X-6: U605B pulls AUD_EN low while 3V3A is not good)"),
    (52, "PC11", "AVCC_EN", "push-pull; also R236 10k -> N2_AVCC_EN_G = U206 input B (X-6: U605A pulls it low while 3V3A is not good)"),
    (53, "PC12", "ANA_EN", "push-pull"),
    (54, "PD2", "LRCLK_FB", "TIM3_ETR (external clock mode 2), latched in the USB SOF ISR; internal pull-down"),
    (55, "PB3", "DC_PERMIT_N", "input (FT), no internal pull, EXTI3 both edges, highest priority; Q618 drain + R648 100k to 3V3M (protection)"),
    (56, "PB4", "RAILS_OK_N", "input, FT, no internal pull: R522 10k series + R532 470k pin-side pull-down (power, D-8) -> 3.22..4.76 V high; valid only with ANA_EN = 1 for >= 20 ms (X-1: RAIL_EN deleted)"),
    (57, "PB5", "ANA_FAULT_N", "input (FT), no internal pull, EXTI5 falling: U503 TPS259621 FLT (open drain) + R512 100k to 3V3M (power); valid with ANA_EN high"),
    (58, "PB6", "USB_DN", "USBHS_DM (90 ohm pair)"),
    (59, "PB7", "USB_DP", "USBHS_DP (90 ohm pair)"),
    (60, "BOOT0", "BOOT0", "R202 10k pull-down; J201-6 pad next to J201-1 (3V3M) for the bootloader bridge"),
    (61, "PB8", "N6_V13_TEST", "open drain, default Hi-Z (protection request; freed by X-1): low 5 ms = 1V3-good test injection via D610 (boot self-test c); Hi-Z in every other state"),
    (62, "PB9", "N6_V3AG_B_MCU", "input, no pull (protection request): U605 ch2 3V3A-good readback via R689 470k (boot self-test d)"),
    (63, "VSS_3", "GND", ""),
    (64, "VIO_3", "3V3M", "C210 100 nF"),
]
assert [p[0] for p in MCU] == list(range(1, 65))
for pin, name, net, note in MCU:
    add("U201", pin, name, net, note)

# ---------------------------------------------------------------- U202 AGRV2KQ32 (QFN-32 4x4, EP)
CPLD = [
    (1, "IO_GB/PIN_1", "FAM_CLK", "only dedicated global clock pin; I2S engine clock (no PLL)"),
    (2, "IO/PIN_2", "OSC48_EN", "X202 stand-by pin; R212 10k pull-down"),
    (3, "IO/PIN_3", "OSC44_EN", "X203 stand-by pin and U205 select S; R213 10k pull-down (default: X202 selected)"),
    (4, "NRST", "CPLD_NRST", "soft reset, active low, internal pull-up [AGM guide]; R231, MCU PC5, J202-4"),
    (5, "IO/PIN_5", "NC", "spare"),
    (6, "VDDA33", "N2_V33_CPLD", "PLL unused but supply pin stays powered; C213 100 nF"),
    (7, "IO/PIN_7", "NC", "spare"),
    (8, "IO/PIN_8", "NC", "spare"),
    (9, "IO/PIN_9", "LINK_SCK", "from U208 1Y (X-7 Ioff buffer, 3V3D); to global network through ALTCLKCTRL; no internal pull needed (driven)"),
    (10, "IO/PIN_10", "LINK_MOSI", "from U208 2Y (X-7)"),
    (11, "IO/PIN_11", "LINK_FRAME", "from U208 3Y (X-7)"),
    (12, "IO/PIN_12", "LINK_MISO", "output, register read data"),
    (13, "IO/PIN_13", "LRCLK_FB", "copy of LRCLK (own output register)"),
    (14, "IO/PIN_14", "CPLD_IRQ", "FIFO under/overflow, sticky, cleared by register read"),
    (15, "IO/PIN_15", "NC", "spare"),
    (16, "VDD33", "N2_V33_CPLD", "C214 100 nF"),
    (17, "GND", "GND", ""),
    (18, "IO/PIN_18", "N2_BCLK_SRC", "BCLK output register -> R204 -> BCLK; R228 capture tap"),
    (19, "IO/PIN_19", "N2_LRCLK_SRC", "LRCLK output register -> R205 -> LRCLK; R229 tap"),
    (20, "IO/PIN_20", "N2_SDATA_SRC", "SDATA output register -> R206 -> SDATA; R230 tap"),
    (21, "IO/PIN_21", "MCLK_EN", "register bit, reset 0; U206 input A; R218 10k pull-down (Q616 is now fed from U206 Y, D-19)"),
    (22, "IO/PIN_22", "NC", "spare"),
    (23, "IO/PIN_23", "NC", "spare"),
    (24, "JTMS", "CPLD_JTMS", "2-wire Compact-JTAG; J202-3; R238 10k pull-up at U202 (TAP held in Test-Logic-Reset, X-10)"),
    (25, "JTCK", "CPLD_JTCK", "2-wire Compact-JTAG; J202-2; R239 10k pull-down at U202 (X-10)"),
    (26, "IO/PIN_26", "NC", "spare"),
    (27, "IO/PIN_27", "NC", "spare"),
    (28, "IO/PIN_28", "NC", "spare"),
    (29, "IO/PIN_29", "NC", "spare"),
    (30, "GND", "GND", ""),
    (31, "IO/PIN_31", "NC", "spare"),
    (32, "VDD33", "N2_V33_CPLD", "C215 100 nF"),
    ("EP", "EXPOSED_PAD", "GND", "2.7 mm EP (LCSC footprint QFN-32_L4.0-W4.0-P0.40-BL-EP2.7) to GND"),
]
assert [p[0] for p in CPLD[:-1]] == list(range(1, 33))
for pin, name, net, note in CPLD:
    add("U202", pin, name, net, note)

# ---------------------------------------------------------------- oscillators and clock logic
add("X201", 1, "INH (stand-by)", "N2_MCLK_OE", "Kyocera KC2520K: H (>= 0.7 VCC) or open = run; L (<= 0.3 VCC) = oscillation stop, stand-by <= 5 uA, t_dis <= 200 ns; driven by U206 (same net feeds R645 -> Q616, D-19)")
add("X201", 2, "GND (case)", "GND")
add("X201", 3, "OUT", "N2_X201_OUT", "80 MHz CMOS; R203 33R to XI, R227 10k pull-down (XI low in stand-by); load <= 14.4 pF incl. the protection R665 MCLK-alive tap 1.29 pF at XI (Kyocera <= 15 pF)")
add("X201", 4, "VCC", "3V3D", "C217 10 nF HF type at the pad (Kyocera: 0.01 uF at the nearest position)")
for ref, en, out, cap in (("X202", "OSC48_EN", "N2_X202_OUT", "C218"), ("X203", "OSC44_EN", "N2_X203_OUT", "C219")):
    add(ref, 1, "STAND-BY", en, "H/open = run, L <= 0.3 VCC = output Hi-Z, oscillation stopped [DS NDK]")
    add(ref, 2, "GND", "GND")
    add(ref, 3, "OUTPUT", out)
    add(ref, 4, "VCC", "3V3D", cap + " 100 nF")
add("U205", 1, "I1", "N2_MUX_I1", "X203 (44.1k family), S = H")
add("U205", 2, "GND", "GND")
add("U205", 3, "I0", "N2_MUX_I0", "X202 (48k family), S = L (default)")
add("U205", 4, "Y", "N2_MUX_Y", "-> R215 -> FAM_CLK")
add("U205", 5, "VCC", "3V3D", "C222 100 nF")
add("U205", 6, "S", "OSC44_EN", "select = OSC44_EN: X203 selected exactly while it is enabled")
add("U206", 1, "A", "MCLK_EN", "74LVC1G11 3-input AND; CPLD register bit, R218 pull-down")
add("U206", 2, "GND", "GND")
add("U206", 3, "B", "N2_AVCC_EN_G", "X-6: AVCC_EN via R236 10k, pulled low by U605A (protection) while 3V3A is not good; IOFF, 5.5 V tolerant, Schmitt action")
add("U206", 4, "Y", "N2_MCLK_OE", "X201 INH = MCLK_EN AND AVCC_EN AND MCLK_PERMIT; R235 100k pull-down; MCU PB1 readback; protection R645 1k -> Q616 gate (D-19)")
add("U206", 5, "VCC", "3V3D", "C223 100 nF")
add("U206", 6, "C", "N2_MCLK_PERMIT", "MCU PB14 with R234 10k pull-down (fast stop at MCU reset)")

# ---------------------------------------------------------------- X-7 domain crossing: U208 (Ioff buffer on 3V3D at the CPLD), Q207
U208 = [  # TI SN74LVC3G34DCUR (VE; DCU pin table SCES366L) = Nexperia 74LVC3G34DC (SOT765-1, DS Rev 16 s.6.1): 1 1A, 2 3Y, 3 2A, 4 GND, 5 2Y, 6 3A, 7 1Y, 8 VCC
    (1, "1A", "N2_LINK_SCK_BUF", "from R224 33R (MCU PA5); 5.5 V tolerant input; Ioff <= +-10 uA with VCC = 0 (TI)"),
    (2, "3Y", "LINK_FRAME", "-> CPLD pin 11 (<= 5 mm)"),
    (3, "2A", "N2_LINK_MOSI_BUF", "from R225 33R (MCU PA7)"),
    (4, "GND", "GND", ""),
    (5, "2Y", "LINK_MOSI", "-> CPLD pin 10 (<= 5 mm)"),
    (6, "3A", "N2_LINK_FRAME_MCU", "from MCU PA4 (direct)"),
    (7, "1Y", "LINK_SCK", "-> CPLD pin 9 (<= 5 mm)"),
    (8, "VCC", "3V3D", "C224 100 nF at the pin; place U208 next to U202"),
]
for pin, name, net, note in U208:
    add("U208", pin, name, net, note)
add("Q207", 1, "G", "N2_RESET_DRV", "AO3400A; gate = MCU PA8 + R240 100k pull-up to 3V3M (DAC held in reset while the MCU is in reset)")
add("Q207", 2, "S", "GND", "")
add("Q207", 3, "D", "DAC_RESETB", "open drain; R305 10k pull-up to DVCC at U301 (analog); PA8 low = DAC released")

# ---------------------------------------------------------------- MCU crystal
add("Y201", 1, "XTAL1", "N2_HSE_IN")
add("Y201", 2, "XTAL2", "N2_HSE_OUT")

# ---------------------------------------------------------------- two-pin passives
two = [
    # ref, net1, net2, note
    ("C201", "N2_HSE_IN", "GND", "33 pF C0G"),
    ("C202", "N2_HSE_OUT", "GND", "33 pF C0G"),
    ("C203", "3V3M", "GND", "VBAT pin 1"),
    ("C204", "3V3M", "GND", "VDDA pin 13"),
    ("C205", "3V3M", "GND", "VDD_4 pin 19"),
    ("C206", "3V3M", "GND", "VDD_4 pin 19, second (USB PHY)"),
    ("C207", "3V3M", "GND", "VIO_1 pin 32"),
    ("C208", "3V3M", "GND", "VDD_2 pin 48"),
    ("C209", "3V3M", "GND", "VDD_2 pin 48, second"),
    ("C210", "3V3M", "GND", "VIO_3 pin 64"),
    ("C211", "3V3M", "GND", "MCU bulk 2.2 uF"),
    ("C212", "NRST", "GND", "NRST filter"),
    ("C221", "3V3M", "GND", "VDDA 1 uF"),
    ("C213", "N2_V33_CPLD", "GND", "CPLD VDDA33 pin 6"),
    ("C214", "N2_V33_CPLD", "GND", "CPLD VDD33 pin 16"),
    ("C215", "N2_V33_CPLD", "GND", "CPLD VDD33 pin 32"),
    ("C220", "N2_V33_CPLD", "GND", "FB202 branch bulk 1 uF"),
    ("C217", "3V3D", "GND", "10 nF HF bypass at the X201 VCC pad (Kyocera spec: 0.01 uF high-frequency type, nearest position)"),
    ("C218", "3V3D", "GND", "X202"),
    ("C219", "3V3D", "GND", "X203"),
    ("C222", "3V3D", "GND", "U205"),
    ("C223", "3V3D", "GND", "U206"),
    ("C224", "3V3D", "GND", "U208 VCC pin 8 (X-7)"),
    ("FB202", "3V3D", "N2_V33_CPLD", "bead-isolated CPLD feed [AGM guide]"),
    ("R201", "NRST", "3V3M", "10k pull-up"),
    ("R202", "BOOT0", "GND", "10k pull-down"),
    ("R232", "N2_BOOT1", "GND", "10k pull-down (PB2/BOOT1)"),
    ("R203", "N2_X201_OUT", "MCLK", "33R source termination, at X201"),
    ("R227", "N2_X201_OUT", "GND", "10k: XI low when X201 is in standby (Epson OUT Hi-Z; ESS standby rule)"),
    ("R204", "N2_BCLK_SRC", "BCLK", "33R at CPLD pin 18"),
    ("R205", "N2_LRCLK_SRC", "LRCLK", "33R at CPLD pin 19"),
    ("R206", "N2_SDATA_SRC", "SDATA", "33R at CPLD pin 20"),
    ("R228", "N2_BCLK_SRC", "N2_CAP_CK", "330R capture tap, at CPLD pin 18"),
    ("R229", "N2_LRCLK_SRC", "N2_CAP_WS", "330R capture tap"),
    ("R230", "N2_SDATA_SRC", "N2_CAP_SD", "330R capture tap"),
    ("R207", "I2C_SCL", "3V3D", "10k pull-up (DZ-2: sink <= 0.35 mA; tr <= 0.85 us at 100 pF, 100 kHz)"),
    ("R208", "I2C_SDA", "3V3D", "10k pull-up (DZ-2)"),
    ("R210", "N2_X202_OUT", "N2_MUX_I0", "33R at X202"),
    ("R211", "N2_X203_OUT", "N2_MUX_I1", "33R at X203"),
    ("R216", "N2_MUX_I0", "GND", "10k: defined low while X202 is in stand-by (Hi-Z)"),
    ("R217", "N2_MUX_I1", "GND", "10k: defined low while X203 is in stand-by"),
    ("R215", "N2_MUX_Y", "FAM_CLK", "33R at U205 output"),
    ("R212", "OSC48_EN", "GND", "10k: X202 off by default"),
    ("R213", "OSC44_EN", "GND", "10k: X203 off by default"),
    ("R218", "MCLK_EN", "GND", "10k: gate input A low while the CPLD is unconfigured"),
    ("R224", "N2_LINK_SCK_MCU", "N2_LINK_SCK_BUF", "33R source termination at MCU PA5 (long trace to U208 at the CPLD)"),
    ("R225", "N2_LINK_MOSI_MCU", "N2_LINK_MOSI_BUF", "33R source termination at MCU PA7"),
    ("R234", "N2_MCLK_PERMIT", "GND", "10k at U206: MCLK_PERMIT low within 0.2 us of any MCU reset"),
    ("R235", "N2_MCLK_OE", "GND", "100k at U206 Y: defines X201 INH, PB1 and the Q616 gate (via R645, D-19) while U206 is unpowered"),
    ("R231", "CPLD_NRST", "N2_V33_CPLD", "10k pull-up (noise immunity of the J202/MCU trace)"),
    ("R236", "AVCC_EN", "N2_AVCC_EN_G", "X-6: 10k series, MCU AVCC_EN -> U206 input B; U605A (open collector) overrides low while 3V3A is not good (0.35 mA)"),
    ("R237", "N2_AUD_EN_MCU", "AUD_EN", "X-6: 4.7k series, MCU PC10 -> AUD_EN; U605B (open collector) overrides low while 3V3A is not good (0.74 mA); R508 10k to GND (power)"),
    ("R238", "CPLD_JTMS", "N2_V33_CPLD", "X-10: 10k JTMS pull-up at U202 (CPLD VDD33 = 3V3D after FB202)"),
    ("R239", "CPLD_JTCK", "GND", "X-10: 10k JTCK pull-down at U202"),
    ("R242", "DC_SENSE_LP", "N2_DCS_LP_PIN", "DZ-1: 330R at MCU PC0 - limits clamp injection from the 4.7 uF protection node with the MCU unpowered"),
    ("R243", "DC_SENSE_LN", "N2_DCS_LN_PIN", "DZ-1: 330R at MCU PC1"),
    ("R244", "DC_SENSE_RP", "N2_DCS_RP_PIN", "DZ-1: 330R at MCU PC2"),
    ("R245", "DC_SENSE_RN", "N2_DCS_RN_PIN", "DZ-1: 330R at MCU PC3"),
    ("R246", "V3A_MON", "N2_V3A_MON_PIN", "DZ-1: 330R at MCU PC4"),
    ("R240", "N2_RESET_DRV", "3V3M", "X-7: 100k Q207 gate pull-up: DAC in reset whenever PA8 floats (MCU reset)"),
    ("R241", "3V3M", "N2_J201_3V3", "X-10: DNF 0R link to J201-1 (WCH-LinkE 3V3 is a power output; fit only for a verified sense-only probe)"),
    ("R701", "LED_G", "N7_LEDG_A", "1k"),
    ("R702", "LED_R", "N7_LEDR_A", "2.2k"),
    ("R703", "MCLK", "N7_MCLK_MON", "DNF 1k, fitted with J703 (monitor only)"),
]
for ref, n1, n2, note in two:
    add(ref, 1, "1", n1, note)
    add(ref, 2, "2", n2, note)
for ref, a in (("D705", "N7_LEDG_A"), ("D706", "N7_LEDR_A")):
    add(ref, 1, "K", "GND", "pad 1 = cathode per the EasyEDA/LCSC footprint convention; NOT confirmed from the KENTO drawing (not retrievable here, B-09 open): overlay the drawing + cathode bar on silk before layout")
    add(ref, 2, "A", a, "anode")

# ---------------------------------------------------------------- pads / header
for pin, name, net in ((1, "3V3_DNF", "N2_J201_3V3"), (2, "SWDIO", "SWDIO"), (3, "SWCLK", "SWCLK"), (4, "NRST", "NRST"),
                       (5, "GND", "GND"), (6, "BOOT0", "BOOT0"), (7, "USART_TX", "USART_TX"), (8, "USART_RX", "USART_RX")):
    add("J201", pin, name, net, "WCH-LinkE pad; pin 1 only via DNF R241 (X-10): never connect the probe 3V3 lead" if pin == 1 else "")
for pin, name, net in ((1, "3V3D_SENSE", "3V3D"), (2, "JTCK", "CPLD_JTCK"), (3, "JTMS", "CPLD_JTMS"),
                       (4, "NRST", "CPLD_NRST"), (5, "GND", "GND")):
    add("J202", pin, name, net, "J-Link / AGM DAP-Link (Blaster) pad; 3V3D sense only" if pin == 1 else "")
add("TP732", 1, "PROG", "PROG", "PROG strap pad (Notes 3.8 allocation): short to an adjacent GND pad at reset = programming mode")
for pin, name, net in ((1, "MCLK_MON", "N7_MCLK_MON"), (2, "BCLK", "BCLK"), (3, "LRCLK", "LRCLK"), (4, "SDATA", "SDATA"),
                       (5, "GND", "GND"), (6, "3V3D_REF", "3V3D")):
    add("J703", pin, name, net, "DNF 1x6 2.54 mm test header")

# ---------------------------------------------------------------- checks
seen = set()
for r in rows:
    key = (r[0], r[1])
    assert key not in seen, f"duplicate pin {key}"
    seen.add(key)
nets = defaultdict(list)
for r in rows:
    nets[r[3]].append((r[0], r[1]))
assert not (RETIRED & set(nets)), f"retired nets used: {RETIRED & set(nets)}"
PROT_IFACE = {"N6_V13_TEST", "N6_V3AG_A_MCU", "N6_V3AG_B_MCU", "N6_ARM_MCU", "N6_ORTEST"}   # protection-owned nets ending at MCU pins (R9: N6_ARM_MCU; R10 F-1: N6_ORTEST)
POWER_IFACE = {"N5_U102_OFF"}   # R9 E-16: power-owned gate net of the U102 EN NMOS, driven by MCU PC14
IFACE |= PROT_IFACE | POWER_IFACE
bad = [n for n in nets if not (n in IFACE or n == "NC" or re.match(r"^N[27]_[A-Z0-9_]+$", n))]
assert not bad, f"non-conforming nets: {bad}"
single = sorted(n for n, p in nets.items() if len(p) < 2 and n not in IFACE and n != "NC")
assert not single, f"internal nets with a single pin: {single}"
iface_used = sorted(n for n in nets if n in IFACE)

with open("netlist.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["refdes", "pin", "pin_name", "net", "note"])
    for r in rows:
        w.writerow(r)

# ---------------------------------------------------------------- BOM
BOM = [
    # block, refs, desc, value, package, rating, mpn, lcsc, class, stock/sourcing, fit, leadless, smt, tht, price, url, note
    ("2", "U201", "MCU, RISC-V V4F 144 MHz, USB2.0 HS PHY, own UAC2 firmware", "CH32V307RCT6", "LQFP-64M 10x10", "3.3 V, -40..85 C",
     "WCH CH32V307RCT6", "C2988083", "Extended", "LCSC 193 / JLCPCB 364 (Sep 2026): reserve", "Yes", "No", 64, 0, 3.47,
     "https://www.wch-ic.com/downloads/CH32V307DS0_PDF.html", "pin map in report s.5; MSL 3"),
    ("2", "Y201", "Crystal, MCU HSE (USBHS PLL ref = HSE/2 = 4 MHz)", "8 MHz", "5.0x3.2 mm 2-pad", "+-10 ppm, CL 20 pF",
     "YXC X50328MSB2GI", "C115962", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.2452,
     "https://www.lcsc.com/product-detail/C115962.html", "kept"),
    ("2", "C201, C202", "Crystal load capacitors", "33 pF", "0402", "50 V C0G", "FH 0402CG330J500NT", "C1562", "Basic",
     "JLCPCB Basic", "Yes", "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C1562.html", "2x(20-3.5) pF"),
    ("2", "C203-C210, C212-C215, C218, C219, C222-C224", "100 nF: decoupling (MCU x8, CPLD x3, X202/X203, U205, U206, U208) and NRST filter C212", "100 nF", "0402",
     "16 V X7R", "Samsung CL05B104KO5NNNC", "C1525", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.0045,
     "https://www.lcsc.com/product-detail/C1525.html", "C216 retired; C213-C215 = CPLD pins 6/16/32; C212 = NRST filter; C217 moved to 10 nF (round 2); C224 new (U208, round 3)"),
    ("2", "C217", "X201 high-frequency bypass at the VCC pad", "10 nF", "0402", "50 V X7R", "Samsung CL05B103KB5NNNC", "C15195", "Basic",
     "JLCPCB Basic", "Yes", "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C15195.html",
     "round 2: 100 nF -> 10 nF; Kyocera spec: 'mount high frequency type capacitor 0.01 uF to the nearest position of oscillator' (D-3 revised)"),
    ("2", "C211", "MCU 3V3M bulk", "2.2 uF", "0402", "6.3 V X5R (~1.1 uF at 3.3 V DC bias)", "Samsung CL05A225MQ5NSNC", "C12530",
     "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.005, "https://www.lcsc.com/product-detail/C12530.html", "kept (attach charge: power stream)"),
    ("2", "C220, C221", "Bulk: CPLD FB202 branch; MCU VDDA", "1 uF", "0603", "50 V X5R", "Samsung CL10A105KB8NNNC", "C15849",
     "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.006, "https://www.lcsc.com/product-detail/C15849.html", ""),
    ("2", "FB202", "Ferrite bead 3V3D -> CPLD VDD33/VDDA33 (AGM: bead-isolated feed)", "600 R @ 100 MHz", "0603",
     "200 mA, 0.45 R", "Sunlord GZ1608D601TF", "C1002", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.0127,
     "https://www.lcsc.com/product-detail/C1002.html", "<= 40 mA CPLD budget -> 18 mV drop"),
    ("2", "U202", "CPLD 2K LUT (AG32 silicon): SPI link, FIFO, I2S master, osc/mux/MCLK enables", "AGRV2KQ32", "QFN-32 4x4, EP 2.7",
     "3.3 V, TJ -40..85 C", "AGM AGRV2KQ32", "C18208899", "Extended", "LCSC 980 (Sep 2026): reserve", "Yes", "Yes", 33, 0, 1.6503,
     "https://www.ag32mcu.com/wp-content/uploads/2026/02/AGRV2K_Rev_3_0.pdf", "programmed via J202 (J-Link / AGM DAP-Link)"),
    ("2", "X201", "Oscillator 80 MHz CMOS SPXO (crystal), stand-by pin 1 (oscillation stop) - DAC MCLK only", "80.000 MHz",
     "2.5x2.0 mm 4-pad, 2520-ONLY land (X-10/B-08; no 3225 pads)",
     "+-50 ppm (-40..85 C incl. initial/temp/supply/load/1-yr aging), ICC <= 8.0 mA loaded 15 pF (2.8-3.63 V, over temp), stand-by <= 5 uA, "
     "SYM 45-55 %, tr/tf <= 4.5 ns (10-90 %), t_dis <= 200 ns, enable/start-up <= 2 ms (spec; 3 ms catalogue), VIH >= 0.7 VCC, "
     "VIL <= 0.3 VCC, abs max 4.0 V, reflow 260 C x2, MSL 1",
     "Kyocera KC2520K80.0000C1GE00", "C1988889", "Extended (global sourcing)",
     "LCSC C1988889 not stocked -> JLCPCB global sourcing: DigiKey 2,964 (Aug 2026), Mouser 1,375 (+10,000 on order)",
     "Yes", "Yes", 4, 0, 1.39, "https://ele.kyocera.com/assets/products/crystal-device/specification/KC2520K80.0000C1GE00_e.pdf",
     "D-3 revised (25 Sep 2026): replaces the obsolete Epson SG-210STF 75 MHz; conditional 2nd source NDK NSC5338D-80M (bring-up checks: "
     "disable time, edges; budget 12.7 mA; 2520 too); TXC 7X-80.000MBE-T withdrawn; SCTF SX3M80 (C5179978, 3225) NOT approved and has no land; stand-by driven by U206"),
    ("2", "X202", "Oscillator 49.152 MHz ultra-low phase noise, stand-by (Hi-Z, osc stops)", "49.152 MHz", "2.5x2.0 mm 4-pad, 2520-ONLY land (X-10)",
     "+-50 ppm overall, 15 mA max, 35 uA stand-by", "NDK NZ2520SDA-49.152MHZ-NSC5083D", "-", "Extended (global sourcing)",
     "JLCPCB global sourcing: DigiKey 644-NSC5083D-49.152M, 3,438 in stock (24 Sep 2026); JLCPCB record C9900006427",
     "Yes", "Yes", 4, 0, 2.0, "https://www.ndk.com/en/products/upload/lineup/pdf/NDKT02-00008_en.pdf",
     "replaces 24.576 MHz OT3225 (C2831388); compliant 2nd source SiT8008BI-xx-33S-49.152000 (ST, 2.5x2.0, 4.3 uA stand-by); SCTF SX3M49.152M20F30TNN (C2901591, 3225) = NON-COMPLIANT fallback (D-4: output-disable only, both run, +25 mA -> Default power targets not met) and not placeable on the 2520-only land"),
    ("2", "X203", "Oscillator 45.1584 MHz ultra-low phase noise, stand-by (Hi-Z, osc stops)", "45.1584 MHz", "2.5x2.0 mm 4-pad, 2520-ONLY land (X-10)",
     "+-50 ppm overall, 15 mA max, 35 uA stand-by", "NDK NZ2520SDA-45.1584MHZ-NSC5083D", "-", "Extended (global sourcing)",
     "JLCPCB global sourcing: DigiKey NSC5083D-45.158M 3,166 (Sep 2026, parts FU-1), 24-week lead", "Yes", "Yes", 4, 0, 2.0,
     "https://www.ndk.com/en/products/upload/lineup/pdf/NDKT02-00008_en.pdf",
     "replaces 22.5792 MHz SX2M (C5452663); compliant 2nd source SiT8008BI-xx-33S-45.158400 (ST); SCTF SX3M45.1584M20F30TNN (C2901589, 3225) = NON-COMPLIANT fallback (D-4: output-disable only, both run, +25 mA -> Default power targets not met) and not placeable on the 2520-only land"),
    ("2", "U205", "2:1 clock mux (family select) - now FITTED", "74LVC1G157", "SOT-363 (TSSOP6)", "1.65-5.5 V, IOFF",
     "Nexperia 74LVC1G157GW,125", "C135822", "Extended", "LCSC stock (v0.8 list)", "Yes", "No", 6, 0, 0.2106,
     "https://assets.nexperia.com/documents/data-sheet/74LVC1G157.pdf", "S = OSC44_EN; S=L -> I0 (X202)"),
    ("2", "U206", "3-input AND: X201 E/D = MCLK_EN AND AVCC_EN AND MCLK_PERMIT (hardware MCLK stop)", "74LVC1G11", "SOT-363 (TSSOP6)",
     "1.65-5.5 V, IOFF, inputs 5.5 V tolerant, Schmitt action, tpd <= 4.9 ns", "Nexperia 74LVC1G11GW-Q100H", "C548242", "Extended",
     "LCSC 3,690 (search snippet, Sep 2026)", "Yes", "No", 6, 0, 0.0768,
     "https://assets.nexperia.com/documents/data-sheet/74LVC1G11.pdf",
     "R8 round 2: was 74LVC1G08GW (C12512, SOT353 5-pin); 6-PIN SOT363-2 footprint in every list (B-16): 1 A, 2 GND, 3 B, 4 Y, 5 VCC, 6 C; input B = N2_AVCC_EN_G (X-6); VOH >= VCC-0.1 V vs Kyocera VIH 0.7 VCC; Y also feeds R645 -> Q616 (D-19)"),
    ("2", "U208", "Triple buffer, Ioff (partial power-down), 3V3M -> 3V3D domain crossing of LINK_SCK/LINK_MOSI/LINK_FRAME, placed at U202", "74LVC3G34",
     "VSSOP-8 0.5 mm (TI DCU = Nexperia SOT765-1 land)", "1.65-5.5 V, Ioff +-10 uA (VCC = 0, VI/VO 5.5 V), inputs 5.5 V tolerant, tpd 1.4-4.1 ns (3.3 V +-0.3 V, -40..85 C), ICC <= 10 uA, MSL1 260 C",
     "TI SN74LVC3G34DCUR", "C130024", "Extended", "LCSC 550 (25 Sep 2026), min/multiple 5", "Yes", "No", 8, 0, 0.2012,
     "https://www.ti.com/lit/ds/symlink/sn74lvc3g34.pdf",
     "VE (25 Sep 2026): replaces Nexperia 74LVC3G34DC,125 (C548774, US$ 0.7647) - same DCU pinout 1 1A, 2 3Y, 3 2A, 4 GND, 5 2Y, 6 3A, 7 1Y, 8 VCC [TI DS SCES366L pin table]; Nexperia part = approved alternate"),
    ("2", "Q207", "N-MOSFET, open-drain DAC_RESETB driver (on = DAC reset; gate PA8 + R240 pull-up to 3V3M)", "AO3400A", "SOT-23",
     "30 V, VGS +-12 V, VGS(th) 0.65-1.45 V, RDS(on) <= 48 mOhm at 2.5 V", "AOS AO3400A", "C20917", "Basic", "JLCPCB Basic (same part as Q502-Q506, Q616, Q617)",
     "Yes", "No", 3, 0, 0.0524, "https://www.aosmd.com/res/datasheets/AO3400A.pdf", "R8 round 3 (X-7): replaces R233; pins 1 G, 2 S, 3 D (as power Q502-Q506)"),
    ("2", "R203-R206, R210, R211, R215, R224, R225", "Series source terminations (MCLK, I2S, osc->mux, mux->CPLD, link)", "33 R",
     "0402", "1 %, 62.5 mW", "UNI-ROYAL 0402WGF330JTCE", "C25105", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.002,
     "https://www.lcsc.com/product-detail/C25105.html", "R215 now fitted"),
    ("2", "R228-R230, R242-R246", "330 R: I2S capture taps to MCU I2S2 (CPLD side); ADC pin injection limiters PC0-PC4 (DZ-1)", "330 R", "0402", "1 %, 62.5 mW", "UNI-ROYAL 0402WGF3300TCE",
     "C25104", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C25104.html",
     "R228-R230 round 1; R242-R246 new in round 3 (DZ-1, at the MCU pins); LCSC no. per UNI-ROYAL series - parts stream to confirm"),
    ("2", "R237", "AUD_EN series resistor from MCU PC10 (X-6)", "4.7 k", "0402", "1 %", "UNI-ROYAL 0402WGF4701TCE", "C25900", "Basic",
     "JLCPCB Basic", "Yes", "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C25900.html",
     "R237 new (X-6); R207/R208 moved to the 10 k line (DZ-2); R233 retired in round 3 (X-7, Q207); LCSC no. to confirm"),
    ("2", "R201, R202, R207, R208, R212, R213, R216-R218, R227, R231, R232, R234, R236, R238, R239", "10 k: pull-ups/downs (NRST, BOOT0, BOOT1, I2C SCL/SDA, osc enables, mux inputs, MCLK_EN, MCLK, CPLD_NRST, MCLK_PERMIT, JTMS, JTCK) and the AVCC_EN series R236",
     "10 k", "0402", "1 %", "UNI-ROYAL 0402WGF1002TCE", "C25744", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.002,
     "https://www.lcsc.com/product-detail/C25744.html", "R212/R213/R218 changed from 2.2k; R216/R217 now fitted; R227/R231/R232/R234 new (R226 not used); R236/R238/R239 new (round 3: X-6, X-10); R207/R208 4.7k -> 10k (DZ-2, B-14)"),
    ("2", "R235, R240", "100 k: pull-down at U206 Y (X201 INH / PB1 readback / Q616 gate via R645, D-19); Q207 gate pull-up to 3V3M (X-7)", "100 k", "0402", "1 %",
     "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.002,
     "https://www.lcsc.com/product-detail/C25741.html", "R8 round 2: new; same part as protection R646/R648; R240 new in round 3"),
    ("2", "R241", "J201 pin 1 link to 3V3M (DNF: WCH-LinkE 3V3 is a power output)", "0 R", "0402", "jumper", "UNI-ROYAL 0402WGF0000TCE", "C17168", "Basic",
     "JLCPCB Basic", "DNF", "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C17168.html", "R8 round 3 (X-10, states #32); net N2_J201_3V3"),
    ("2", "J201", "Pads: MCU 2-wire SDI debug (WCH-LinkE) + BOOT0 + USART1", "-", "8 SMD pads", "-", "PCB pads (no component)", "-", "-", "-",
     "Yes", "No", 0, 0, 0, "", "copper pads only - exclude from JLCPCB BOM/CPL; pin 1 = N2_J201_3V3 via DNF R241 (never power the board from the probe)"),
    ("2", "J202", "Pads: CPLD 2-wire Compact-JTAG (J-Link / AGM DAP-Link)", "-", "5 SMD pads", "-", "PCB pads (no component)", "-", "-", "-",
     "Yes", "No", 0, 0, 0, "", "copper pads only - exclude from JLCPCB BOM/CPL; 3V3D sense only"),
    ("7", "TP732", "Test pad: PROG strap (MCU PC13), shorted to GND at reset", "-", "1 SMD pad 1.0 mm", "-", "PCB pads (no component)", "-", "-", "-",
     "Yes", "No", 0, 0, 0, "", "copper pad only - exclude from JLCPCB BOM/CPL; Notes 3.8 allocation TP732 = PROG (parts layout draft says TP737: reconcile)"),
    ("7", "D705", "LED status green, 3.3 V GPIO", "Green", "0805", "Vf 2.6-3.1 V", "Hubei KENTO KT-0805G", "C2297", "Basic",
     "JLCPCB Basic", "Yes", "No", 2, 0, 0.0163, "https://www.lcsc.com/product-detail/C2297.html", "kept"),
    ("7", "D706", "LED fault red, 3.3 V GPIO", "Red", "0603", "Vf 1.8-2.4 V", "Hubei KENTO KT-0603R", "C2286", "Basic",
     "JLCPCB Basic", "Yes", "No", 2, 0, 0.0075, "https://www.lcsc.com/product-detail/C2286.html", "kept"),
    ("7", "R701", "Green LED series", "1 k", "0402", "1 %", "UNI-ROYAL 0402WGF1001TCE", "C11702", "Basic", "JLCPCB Basic", "Yes",
     "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C11702.html", "0.10-0.80 mA"),
    ("7", "R702", "Red LED series", "2.2 k", "0402", "1 %", "UNI-ROYAL 0402WGF2201TCE", "C25879", "Basic", "JLCPCB Basic", "Yes",
     "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C25879.html", "0.36-0.73 mA"),
    ("7", "J703", "Header 1x6 2.54 mm, I2S test port (MCLK monitor, BCLK, LRCLK, SDATA, GND, 3V3D)", "1x6", "2.54 mm THT",
     "-", "Generic 2.54 mm header", "-", "-", "-", "DNF", "No", 0, 6, 0.1, "", "DNF; pads only on the PCB"),
    ("7", "R703", "J703 MCLK monitor series (monitor only)", "1 k", "0402", "1 %", "UNI-ROYAL 0402WGF1001TCE", "C11702", "Basic",
     "JLCPCB Basic", "DNF", "No", 2, 0, 0.002, "https://www.lcsc.com/product-detail/C11702.html", "fit with J703"),
]


def expand(refs):
    out = []
    for part in refs.split(","):
        part = part.strip()
        m = re.match(r"^([A-Z]+)(\d+)-([A-Z]+)?(\d+)$", part)
        if m:
            p, a, _, b = m.groups()
            out += [f"{p}{i}" for i in range(int(a), int(b) + 1)]
        else:
            out.append(part)
    return out


bom_refs = []
with open("bom_rows.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["block", "refs", "qty", "desc", "value", "package", "rating_tolerance", "mpn", "lcsc", "jlcpcb_class",
                "jlcpcb_stock_or_sourcing", "fit", "leadless", "smt_pins_per_part", "tht_pins_per_part", "unit_price_usd",
                "datasheet_url", "note"])
    for b in BOM:
        refs = expand(b[1])
        bom_refs += refs
        w.writerow([b[0], b[1], len(refs)] + list(b[2:]))
assert len(bom_refs) == len(set(bom_refs)), "ref in two BOM lines"
net_refs = sorted(set(r[0] for r in rows))
assert sorted(set(bom_refs)) == net_refs, (sorted(set(bom_refs) ^ set(net_refs)))

# ---------------------------------------------------------------- report
print(f"netlist rows: {len(rows)}; parts: {len(net_refs)}; nets: {len(nets)}")
mcu_gpio = [p for p in MCU if not re.match(r"^(V|OSC|NRST|BOOT0)", p[1])]
used = [p for p in mcu_gpio if p[2] != "NC"]
print(f"MCU GPIO: {len(mcu_gpio)} available, {len(used)} used, {len(mcu_gpio)-len(used)} spare "
      f"({', '.join(p[1] for p in mcu_gpio if p[2]=='NC')})")
cpld_io = [p for p in CPLD if p[1].startswith("IO")]
cused = [p for p in cpld_io if p[2] != "NC"]
print(f"CPLD user I/O: {len(cpld_io)} available, {len(cused)} used, {len(cpld_io)-len(cused)} spare")
print("interface nets used here:", " ".join(iface_used))
unused_iface = sorted(IFACE - set(iface_used))
print("interface nets not touched by the digital stream:", " ".join(unused_iface))
print("BOM lines:", len(BOM), "; fitted parts:", sum(len(expand(b[1])) for b in BOM if b[10] == "Yes"))
fit_refs = sum(len(expand(b[1])) for b in BOM if b[10] == "Yes")
pads = sum(len(expand(b[1])) for b in BOM if b[10] == "Yes" and b[6].startswith("PCB pads"))
smt = sum(len(expand(b[1])) * b[12] for b in BOM if b[10] == "Yes")
cost = sum(len(expand(b[1])) * b[14] for b in BOM if b[10] == "Yes")
print(f"fitted refs {fit_refs} (components {fit_refs - pads}, pad groups {pads}); SMT joints {smt}; "
      f"leadless {[b[1] for b in BOM if b[11] == 'Yes']}; fitted parts cost {cost:.2f} USD (sample-tier prices, NDK estimated)")
print("All netlist/BOM checks passed.")
