#!/usr/bin/env python3
"""Logic levels, pull-up/pull-down sizing, FT-pin limit, I2C timing, LED currents, tap RC.
Run: python3 levels_and_pullups.py > levels_and_pullups_output.txt
"""
import math

VCC_MIN, VCC_NOM, VCC_MAX = 3.3 * 0.97, 3.3, 3.3 * 1.03    # 3V3 rail band [ASSUMP: power stream LDO +-3 %]

print("1. RAILS_OK_N at MCU PB4 (FT pin) - data for the power-stream divider [DS Tab 4-1, Tab 4-22]")
# Tab 4-22: VIH(FT) >= 0.42*(VDD-1.8)+1.0 V, max 5.0 V; VIL(FT) <= 0.32*(VDD-1.8)+0.55 V; Vhys(FT) >= 90 mV;
# Ilkg(FT) <= 3 uA (standard I/O 1 uA); conditions are not printed in the table. Tab 4-1: FT abs max 5.5 V.
def vih_ft(vdd):
    return 0.42 * (vdd - 1.8) + 1.0


def vil_ft(vdd):
    return 0.32 * (vdd - 1.8) + 0.55


for vdd in (3.0, 3.25, 3.3, 3.35, 3.6):
    print(f"   VDD {vdd:4.2f} V: VIH(FT) >= {vih_ft(vdd):5.3f} V, VIL(FT) <= {vil_ft(vdd):5.3f} V")
VIH_WC, VIL_WC = vih_ft(3.6), vil_ft(3.0)
print(f"   design limits for any VDD 3.0-3.6 V: 'high' needs >= {VIH_WC:.3f} V, 'low' needs <= {VIL_WC:.3f} V;"
      f" operating max 5.0 V (VIH max), abs max 5.5 V; leakage <= 3 uA")
R505, R522 = 100e3, 10e3                 # PGOOD pull-up to 5V_ANA_F and series resistor (power stream)
ILK = 3e-6
V_NODE_MAX, V_NODE_MIN = 5.55, 4.30      # 5V_ANA_F highest (OVP clamp) / lowest operating 5V_SYS (power stream)
print("   PGOOD released (rails not good), pin-side pull-down R_pd, leakage +-3 uA in the worst direction:")
best = None
for rpd in (470e3, 560e3, 680e3, 1e6):
    rth = (R505 + R522) * rpd / (R505 + R522 + rpd)
    vmax = V_NODE_MAX * rpd / (R505 + R522 + rpd) + ILK * rth
    vmin = V_NODE_MIN * rpd / (R505 + R522 + rpd) - ILK * rth
    ok = vmax <= 5.0 and vmin >= VIH_WC
    print(f"     R_pd {rpd/1e3:5.0f} k: pin {vmin:4.2f} .. {vmax:4.2f} V  -> {'OK' if ok else 'exceeds 5.0 V'}")
    if ok:
        best = rpd
print(f"   PGOOD low (rails good): pin <= VOL(PGOOD) + 3 uA x 10 k = VOL + {ILK*R522*1e3:.0f} mV (must be <= {VIL_WC:.3f} V)")
print(f"   -> R_pd <= 560 k keeps PB4 <= 5.0 V at 5.55 V with the leakage in the worst direction; 470 k recommended;"
      f" 1 M does not (5.30 V). 5V_ANA off reads 'good' (0 V) -> firmware validity rule (ANA_EN = RAIL_EN = 1, >= 20 ms). [CALC]")
assert best is not None and best >= 470e3

print()
print("1b. [SUPERSEDED in round 3 (X-7): R233 retired; DAC_RESETB is open drain via Q207 with R305 10 k to DVCC -> no current into")
print("    U301-28 with DVCC off; the round-2 case below is kept only as the record]")
print("1b. DAC_RESETB: MCU PA8 -> R233 (at the MCU) -> DAC_RESETB (U301-28) with R305 100 k to GND (analog stream)")
R233, R305 = 4.7e3, 100e3
VDD_M = (3.25, 3.35)                      # 3V3M band (power stream)
DVCC_MAX = 3.3 * 1.05                     # ESS DVCC 3.3 V +-5 % [DS p.28]
vih_dac = DVCC_MAX / 2 + 0.4              # ESS VIH >= DVCC/2 + 0.4 V; VIL <= 0.4 V [DS p.29]
voh_min = VDD_M[0] - 0.4                  # CH32 VOH >= VDD - 0.4 V at 8 mA [DS Tab 4-23-1] (actual load < 35 uA)
v_hi = voh_min * R305 / (R233 + R305)
i_inj = VDD_M[1] / R233
vol_ohmic = 0.4 / 8e-3 * (VDD_M[1] / (R233 + R305))   # VOL scaled from 0.4 V at 8 mA (ohmic output) [CALC]
v_lo = vol_ohmic * R305 / (R233 + R305)
print(f"   high: VOH >= {voh_min:.2f} V -> pin >= {v_hi:.2f} V vs VIH {vih_dac:.3f} V (DVCC 3.465 V): margin {v_hi-vih_dac:.2f} V")
print(f"   low: driven <= {v_lo*1e3:.1f} mV (ohmic VOL at {VDD_M[1]/(R233+R305)*1e6:.0f} uA); floating MCU pin -> 0 V via R305; VIL 0.4 V")
print(f"   3V3D off, pin driven high by mistake: injection <= {i_inj*1e3:.2f} mA (analog limit 1 mA); R233 >= 3.3 k satisfied")
c_node = 5e-12 + 3e-12                    # ESS CIN 5 pF [DS p.29] + trace [ASSUMP]
tau = (R233 * R305 / (R233 + R305)) * c_node
vf = VDD_M[0] * R305 / (R233 + R305)
t_rise = tau * math.log(vf / (vf - vih_dac))
print(f"   edge: tau {tau*1e9:.0f} ns, reaches VIH {t_rise*1e9:.0f} ns after the MCU edge; RESETB is a static level (ESS: >= 1 ms"
      f" after supplies+MCLK at power-up, later resets >= 10 ns) -> no timing constraint [CALC]")
print(f"   high-state current {VDD_M[1]/(R233+R305)*1e6:.0f} uA from 3V3M; R233 dissipation with 3.35 V across (fault) "
      f"{VDD_M[1]**2/R233*1e3:.2f} mW")
assert v_hi - vih_dac > 0.3 and i_inj <= 1e-3 and v_lo < 0.4

print()
print("2. Oscillator / mux enable pull-downs (10 kOhm) against unknown internal or CPLD weak pull-ups")
thr = 0.3 * VCC_MIN                # NDK stand-by L level <= 0.3 VCC [DS]
for rpu in (10e3, 23.3e3, 50e3, 100e3, 1e6):
    v = VCC_MAX * 10e3 / (10e3 + rpu)
    print(f"   Rpu {rpu/1e3:7.1f} k -> {v:4.2f} V ({'stand-by' if v <= thr else 'may run'}; L threshold {thr:.2f} V)")
print("   With the mux fitted, 'may run' only costs current; it cannot cause clock contention. [CALC]")
print(f"   Current when driven high: {VCC_MAX/10e3*1e3:.2f} mA each (was {VCC_MAX/2.2e3*1e3:.2f} mA with 2.2 kOhm). [CALC]")

print()
R_I2C = 10e3                       # DZ-2 (B-14): R207/R208 4.7 k -> 10 k
print("3. I2C (I2C2 -> ES9018K2M), pull-ups R207/R208 10 kOhm to 3V3D (DZ-2; was 4.7 k)")
for cb in (30e-12, 50e-12, 100e-12):
    tr = 0.8473 * R_I2C * 1.01 * cb    # 30 %..70 % rise, R +1 %
    print(f"   Cb {cb*1e12:4.0f} pF: tr = {tr*1e9:5.0f} ns (standard mode limit 1000 ns, fast mode 300 ns)")
    assert tr < 1000e-9
i_sink = VCC_MAX / (R_I2C * 0.99)
r_on = 0.2 / 100e-6                # ES9018K2M VOL 0.2 V at 100 uA [DS p.29] as an ohmic 2 k output (extrapolation) [ASSUMP]
vol_x = VCC_MAX * r_on / (r_on + R_I2C * 0.99)
print(f"   sink current {i_sink*1e3:.2f} mA (ES9018K2M VOL specified only at 100 uA [DS p.29]); ohmic extrapolation VOL <= {vol_x:.2f} V")
print(f"   (4.7 k gave {VCC_MAX*r_on/(r_on+4.7e3*0.99):.2f} V) vs MCU VIL ~0.98 V (B-14) -> margin {0.98-vol_x:.2f} V; 100 kHz standard mode; firmware")
print("   keeps an ACK-error counter (bring-up [MEAS] of SDA VOL during DAC ACK/read).")

print()
print("4. LED currents (active-high from 3.3 V GPIO, VOH drop ignored)")
for name, r, vf in (("D705 green KT-0805G", 1e3, (2.6, 3.1)), ("D706 red KT-0603R", 2.2e3, (1.8, 2.4))):
    imax = (VCC_MAX - vf[0]) / r
    imin = max(0.0, (VCC_MIN - vf[1]) / r)
    print(f"   {name}: {imin*1e3:.2f} .. {imax*1e3:.2f} mA [CALC]")

print()
print("5. I2S capture taps (CPLD side -> 330 Ohm -> MCU I2S2 pins)")
c_load = 5e-12 + 4e-12            # MCU pin + ~4 cm trace [ASSUMP]
tau = 330 * c_load
print(f"   tau = 330 Ohm x {c_load*1e12:.0f} pF = {tau*1e9:.1f} ns; 10-90 % = {2.2*tau*1e9:.1f} ns vs BCLK half period 20.3 ns (384 kHz) [CALC]")
print(f"   fault current if an MCU pin were driven against the CPLD: {VCC_MAX/330*1e3:.1f} mA (< 25 mA pin rating [DS Tab 4-1])")

print()
print("6. MCLK net: X201 (Kyocera KC2520K80.0000C1GE00, 80 MHz, D-3 revised) -> R203 33 Ohm -> XI (CCLK 10 pF [DS p.29]); R227 10 k")
c_xi = 10e-12 + 2.6e-12 + 0.5e-12          # XI + <= 20 mm trace + pads [ASSUMP, see clock_timing.py 4]
tau = 33 * (10e-12 + 1e-12)
print(f"   load {c_xi*1e12:.1f} pF <= 15 pF (Kyocera CL max) ; R203 x C_XI = {tau*1e12:.0f} ps; R227 DC load at 50 % duty "
      f"{VCC_MAX/10e3*0.5*1e3:.2f} mA (counted in the X201 budget 8.2 mA)")
print("   Kyocera INH low -> stand-by (oscillation stop, IST <= 5 uA), output within t_dis <= 200 ns [DS]; the spec does not state")
print(f"   the stand-by output level -> R227 still required: it holds XI at 0 V (ESS standby: external MCLK 'stopped at logic low level'")
print(f"   [DS p.7]) whether the output is Hi-Z or low; discharge of the net {10e3*c_xi*math.log(VCC_MAX/0.4)*1e9:.0f} ns to < 0.4 V; ESS gives")
print("   no XI leakage figure -> 1 uA [ASSUMP] x 10 k = 10 mV.  Same for the NDK NSC5338D-80M conditional second source.")
print("   Kyocera: 'mount high frequency type capacitor 0.01 uF to the nearest position of oscillator' [DS] -> C217 = 10 nF at pad 4.")
print("   INH must stay within 0..VCC (abs max VCC + 0.3 V) [DS] -> same rail as U206 (3V3D); U206 Y is low while 3V3D ramps")
print("   (MCLK_EN = MCLK_PERMIT = 0 at every AUD_EN rising edge).")

print()
print("7. U206 (74LVC1G11) output driving X201 pad 1 INH (Kyocera: run >= 0.7 VCC or open, stand-by <= 0.3 VCC [DS])")
for vdd in (VCC_MIN, 3.3 * 1.01, VCC_MAX):
    voh, vol = vdd - 0.1, 0.1              # 74LVC1G11 VOH >= VCC-0.1 V, VOL <= 0.1 V at |IO| = 100 uA [DS]; same rail as X201
    print(f"   3V3D {vdd:.3f} V: VOH >= {voh:.3f} V vs VIH(INH) {0.7*vdd:.3f} V (margin {voh-0.7*vdd:.2f} V); "
          f"VOL <= {vol:.2f} V vs VIL(INH) {0.3*vdd:.3f} V (margin {0.3*vdd-vol:.2f} V) -> OK")
    assert voh >= 0.7 * vdd + 0.8 and vol <= 0.3 * vdd - 0.8
print("   Static Y load: INH input (current not stated, CMOS [ASSUMP]) + R235 34 uA + Q616 gate leakage (<= 0.1 uA [DS AO3400A IGSS])")
print("   << 100 uA test current -> the 100 uA rows apply; the <= 1 nF Q616 gate sits behind R645 1 k (<= 3.3 mA transient, D-19).")
print("   U206 and X201 share 3V3D, so 'open = enabled' can only occur with U206 unpowered, i.e. with X201 unpowered too.")
print("   MCU-reset stop latency and the race against the 3V3A discharge: mclk_gate_race.py (<= 0.39 us, margin 27.6 us).")

print()
print("8. N2_MCLK_OE: U206 Y -> X201 INH, R645 -> Q616 gate (protection, D-19), R235 100 k pull-down, MCU PB1 readback")
r235 = 100e3
print(f"   R235 current with Y high: {VCC_MAX/r235*1e3:.3f} mA; U206 IOFF output while 3V3D is off -> R235 keeps the node (X201 INH,")
print(f"   PB1 and, through R645, the Q616 gate) at 0 V; leakage 1 uA x 100 k = {1e-6*r235*1e3:.0f} mV << 0.45 V (Q616 off level)")
vil_std, vih_std = 0.32 * (3.0 - 1.8) + 0.55, 0.42 * (3.6 - 1.8) + 1.0   # same WCH formulas as section 1 (conservative) [DS]
print(f"   PB1 (not FT): VIN <= VIO + 0.3 V = {3.25+0.3:.2f} V min vs node <= {VCC_MAX:.2f} V -> OK [DS Tab 4-1]; high >= {VCC_MIN-0.1:.2f} V vs "
      f"VIH {vih_std:.2f} V; low <= 0.1 V vs VIL {vil_std:.2f} V (FT-pin formulas as a proxy; standard-I/O rows not retrieved, "
      f"assumed <= 2.0 V / >= 0.8 V [ASSUMP] -> margin > 1 V either way)")
print("   PB1 configured as floating input (R235 defines it; no internal pull needed); never an output.")
print("   Firmware self-test each power-up: MCLK_EN=1, PERMIT=0 -> PB1=0; PERMIT=1 -> PB1=1; PERMIT=0 -> PB1=0 within 10 us")
print("   -> proves U206 inputs A/C, R234 and the run/permit node (which now also gates the output switch) without an oscilloscope.")
