# Power stream report — design iteration R8 (Spec v0.9 / Notes v0.8 / Parts List v0.7)

Order (newest first): **R10 fixes (26 Sep 2026) — the current values**, R9 fixes, VE, round 3, round 2, round 1. Older sections are history wherever they differ from the R10 section (marked "superseded (R9 …)" where a statement could look current); the round-1 report keeps its **[superseded → R2.x]** marks and ~~struck~~ values.

Scope: brief Section 7.1 — blocks 1 and 5, U302 (3V3A) and U303 (1V3) with their capacitors/EN parts, and all discharge parts.
Author: power-supply engineer (stream 7.1), round 1 24 Sep 2026, rounds 2–3, VE and R9 25 Sep 2026, R10 26 Sep 2026. All calculations are in `calc/` (`cNN_*.py` with `cNN_*.out.txt`); raw datasheet extracts used for the numbers are in `ds/`.

Labels: **[DS]** datasheet min/max (document, table, URL in §12 / R2.16), **[DS-typ]** typical only, **[CALC]** worst case computed in the named script, **[ASSUMP]** assumption with reason, **[PH]** brief Section 6 placeholder, **[MEAS]** bring-up measurement with its designed-in fallback.

## R10 fixes — 26 Sep 2026 (decisions_r10.md F-3 power share, F-2 power rows; reviews R10-A…C)

Scripts re-run on 26 Sep 2026: `calc/c17_budget_r3.py` (text/basis only, states unchanged), `calc/c21_r9_checks.py` (regenerated), `calc/c20_ve_checks.py` (re-run, reads c17); backups `calc/*_preR10*.bak`. **This section holds the current values; every differing figure further down is history** (marked "superseded (R9 …)" where it could look current).

**Current values (c17 / c21 / c22 runs of 26 Sep 06:57, including protection's R10 F-1 loads with analog's final F-1 figures, see F-1.1):**

| Quantity | Value | Evidence |
|---|---|---|
| R509 / R510 | **4.75 kΩ 0.1 % owner-fitted** (KOA RN73R1JTTD4751B25) / 3.74 kΩ 0.1 % (YAGEO RT0603BRD073K74L) | E-18; `bom_rows.csv` |
| Default IOS min / nom / max | **180.05 / 201.3 / 222.6 mA** | c17 [DS Eq. 5, ±10.4 % max, R 0.1 % + 25 ppm] |
| Default need / margin | **178.96 mA → +1.09 mA** (178.961 / +1.0900; E, register A-35) with F-1 (analog need_for() 178.9230 + ANA_SENSE 0.0378); before F-1 178.83 / +1.22 mA (F-3.6; the R9 release quoted 178.82 / +1.23 from the rounded analog base) | c17 (analog need_for() R10 F-1 final 178.9230 mA unrounded + ANA_SENSE 0.0378 mA) |
| High IOS (R510 3.74 k) | **395.4 / 442.7 / 489.7 mA** | c17 |
| States, Kyocera X201 (mA) | **S1 82.40, S2 344.39, S3 493.46, S3f 359.72, S4 760.77, S5 352.53; S6 2.2755 / 2.1815** (legacy A-to-C / C-to-C) — with F-1; before F-1 S2 344.22, S3 493.45, S3f 359.55, S4 760.76, S5 352.36 (F-3.7) | c17, c22 |
| States, NDK X201 second source (E-27) | **S2 348.89, S3 497.96, S3f 364.22, S4 765.27 mA** (with F-1; before 348.72 / 497.95 / 364.05 / 765.26) (+4.50 mA on 3V3D while MCLK runs); S1, S5, S6 unchanged; R509 unchanged | c17 (now computed, was a hand +4.5 mA) |
| Margins | S1 +17.60 (100), S2 +155.61, S3 +6.54 (NDK +2.04), S3f +140.28, S5 +147.47 (500), S4 +739.23 (1500) mA; S6 +224 / +318 µA (2.5 mA) | c17, c22 |
| Suspend timing | suspend level reached **≤ 8.75 ms after the last SOF** (U102 off at S7 + 0.1 ms, tOFF ≤ 0.3 ms) | R9.E16, c22 |
| Production test (Q — open obligation, no board exists) | S3 ≤ 480 mA and S1 ≤ 90 mA per board; fail → firmware Default volume ceiling (E-21) | E-17, E-21 |
| Brown-out margin at the VBUS 4.40 V corner | **+67 … +114 mV** (band 3.704–4.236 V; 5V_SYS min 4.318 / 4.303 (J101 drop) / 4.350 V; was +52 … +98 mV) | c21, c04 (R10) |

| Item | Action | Result | Evidence |
|---|---|---|---|
| F-3.1 c21 not regenerated after R509 changed (R10-C) | E-6 now reads every Default figure from `c17_results.json`; E-5 kept as R9 history with a "superseded (R9 E-16)" banner and the final S6 from c22; regenerated `.py`, `.out.txt`, `c21_results.json` | **numbers that moved:** Default total 490.80 → **493.45 mA** (+9.20 → **+6.55 mA** to 500; NDK 497.95 mA, +2.05, added); IOS 177.9 / 198.9 / 220.0 → **180.05 / 201.3 / 222.6 mA**; need 176.96 → **178.83 mA**; margin +0.97 (+0.99) → **+1.22 mA** (F-3.6) **[superseded (F-1.1, F-1.2): need 178.96 mA, +1.09 mA; S3 493.46 mA, +6.54 (NDK 497.96, +2.04)]**; limit window 42 → 43 mA; trade example "4.84 k: +1.3 / −1.0 mA" → "4.78 k: +1.32 / −1.07 mA" (ratio 1 : 1.24 unchanged); fallback "R509 4.84 k" → E-21 firmware ceiling (4.84 k gives IOS min 176.89 mA < need). json: S3 490.80 → 493.45, IOSmin 177.93 → 180.05; keys S6 / S6_fallback renamed S6_preE16 / S6_fallback_R9_estimate (values unchanged: 2.5094 / 2.2381 mA, pre-E-16 history); added S6_final_c22 2.2755, S6_final_c22_CC 2.1815, S3_NDK, IOSmax, NEED, MARGIN_DEF, R509, brown-out and LM27762-VIN keys | `calc/c21_r9_checks.*`, `c21_results.json` |
| F-3.1b brown-out line in c21 (found by the grep: stale inputs) | recomputed from the final c17 totals (c04 had the round-2 totals 487.1 / 748.1 mA) and the TPS70933 3V3M range 3.207–3.343 V (c09 had the TPS7A20 ±1.5 %) | band 3.756–4.244 → **3.704–4.236 V**; 5V_SYS min 4.311 / 4.296 / 4.342 → **4.318 / 4.303 / 4.350 V** (c04 method on the final basis with the E-16 topology — the U502 input 83.8 mA bypasses the U102 RON, F-3.8); margin +67 / +52 / +98 → **+82 / +67 / +114 mV** (tighter TPS70933 upper tolerance +1.30 % vs 1.5 %: +8 mV; U502 bypass: +8 mV; final loads: −1 … −2 mV); the band bottom 3.704 V holds only while 3V3M regulates (L-12, PVD backup) | c21 brown-out section |
| F-3.2 current-looking 4.81 k / 490.80 / 177.9 / 176.96 mA in this report | fixed in place in the R9 section (E-6, E-18 rows; old values quoted as history); marked **"superseded (R9 E-18)"** in the R9 decision-history rows, VE #1/#6/#12, R3.F (both tables), R3.0, R3.13, R3.14, R3.15, R3.17; history banners on the round-3, round-2 and round-1 sections | no current-looking stale statement left (grep of 4.81 k, 490.8, 177.9, 176.9x, 342.28, 357.62, 350.43, 758.11, 344.21, 359.55, 352.36, 178.81/178.84, +1.25/+1.28, 497.92, 2.4965, 393.3: only marked history) | this file |
| F-3.3 state narratives | aligned to the final c17 run (after F-3.7) | first aligned to the R9 release S2 344.17, S3f 359.50, S5 352.31 mA; F-3.7 then showed that run 0.05 mA low → narratives now **S2 344.22, S3f 359.55, S5 352.36 mA** (the pre-reconciliation 344.21 / 359.55 / 352.36 were within 0.01 mA); IOS min 180.1 → **180.05 mA**; margin "+1.21–1.23", "+1.25" → **+1.22 mA**; need 178.81 / 178.84 → **178.83 mA** (F-3.6) **[superseded (F-1.1, F-1.4): need 178.96 mA, +1.09 mA; S2 344.39, S3f 359.72, S5 352.53 mA]** (R9.E16 E-18 row, S1–S5 row); NDK states from c17 | c17 |
| F-3.4 folder grep (report, BOM, netlist, all calc scripts/outputs/json) | c17: labels "FINAL round 3 … R509 4.81 k", "DY-1 … 490.8 mA accepted" replaced by the E-17/E-18 wording, pre-E-16 S6 lines labelled history, need printed on the released analog basis (178.812 → 178.823 → **178.829 mA**, F-3.6; margin +1.24 → **+1.22 mA** [superseded (F-1.1): 178.961 mA, +1.090 mA]; rule-conflict text 4.78 k "need +0.17" → +0.16; json NEED changed, NEED_INC / MARGIN_DEF / S_NDK / NDK_DELTA added; **S1–S6, DEF, HIGH, NONANA identical**); c20 re-run (it reads c17): **S4 758.1 → 760.76 mA, U102 margin +112 → +109 mA** (NDK +105 mA) **[superseded (F-1.4): S4 760.77 mA, U102 +109 mA; NDK 765.27 mA, +105 mA]**, stale lines marked (region B 40.2 µC → c22 20.1 µC; TPS7A20 D+ timing → E-16; "R509 4.81 k +0.99 mA" → 4.75 k, need 178.82 / +1.23 mA as released in R9) | remaining hits are history only: `*.bak`, `fix_progress.md` log, BOM R509 text "CHANGED (E-18) 4.81 k → 4.75 k", θJA 176.9 °C/W (c10, c12, pw_common) | c17, c20 |
| F-3.4b round-2 load basis (found; fixed by F-3.8) | c04, c10, c11, c14, c15, c16, c18 read `c03_results.json` (round 2: non-analog 264.04 mA, High IOS max 483.4 mA with R510 3.83 k); the final loads are 270.37 mA and 489.7 mA | quantified in c21: 5V_SYS min −0.7 / −1.5 mV (Default / High); **LM27762 VIN (= 5V_ANA_F) at VBUS 4.40 V 4.300 → 4.307 V (Default), 4.219 → 4.224 V (High)** (final loads + E-16 bypass) — analog's R10 headroom table uses its own 4.202 V (more conservative), so R-46 is not affected; U503 dissipation at the High limit +0.8 mW. The dynamic models (c14 unplug, c18 start) keep the c03 loads: +2.4 % non-analog load changes decay/start times by far less than their margins (not re-run, E) | c21 by-product lines |
| F-3.4c reproducibility re-run (every quick power calc in a scratch copy, compared with the shipped outputs) | c03–c13, c17, c19–c22 and every json reproduce exactly; fixed: c01/c02 out.txt carried a hand-split E-16 line (content identical) → regenerated from the scripts; c15 quotes `analog/out/headroom_table.csv` (analog regenerated it 26 Sep 04:51) → c15 re-run: only the analog-reference column moved (e.g. High 32 Ω 2.38 → 2.35 Ω), power figures and `c15_results.json` unchanged — **run analog before power**; BOM generator lacked integration's 20:07 Q507 text → aligned, and R108 text "S4 758.1 mA" → "S4 760.76 mA, NDK 765.26 mA" (the only BOM change; netlist identical) **[superseded (26 Sep 08:13, F-1): R108 text "S4 760.77 mA, NDK X201 765.27 mA"]**; `gen_bom_netlist.out.txt` was the round-2 stdout → regenerated (66 lines, 78 parts, 225 rows) | c16 (462 s): every section identical, but the shipped out.txt had been assembled from partial runs (order B, D, E, C, A) and its json held only section A → replaced by the full re-run; c17 now reads c16 E i_r508 = 0.23016 mA (was its 0.230 fallback) → states +0.0002 mA, every 2-decimal value unchanged; c20/c21 re-run. c14 (428 s): out.txt and json identical. c18 (4 runs: `10 reduced`, `470 reduced`, `10 timing`, `470 timing`, appending to an emptied out.txt): every table number and both timing jsons identical; the current script also prints the T_START metric in the reduced runs (json keys TSTART/tstart) → shipped c18 out.txt and the two reduced jsons replaced by the re-run | scratch run (deleted), `calc/*_preR10*.bak` |
| F-3.4d Q507 EN level | noted | 3.19 V (c22: 0.55 µA at 60 °C) vs 3.18 V (BOM/register: parts' 0.57 µA at 50 °C); both ≥ 1.9 V with ≥ 1.28 V margin; BOM text kept | c22 §6, bom_rows.csv |
| F-3.6 Default need rounding (found against analog's R10 output) | c17 now takes analog's unrounded need (r2_common need_for(): 178.7912 mA, final block 6 inside) + ANA_SENSE 0.0378 mA; c21 re-run | **178.829 mA → 178.83 mA; margin +1.2218 → +1.22 mA** **[superseded (F-1.1): 178.961 → 178.96 mA, +1.090 → +1.09 mA]** — the released 178.82 / +1.23 used the rounded R9 analog figure (178.81 − 0.025 + 0.038 = 178.823); analog r10_fixes prints the same 178.83 / +1.22; states unchanged; BOM R509 text then "Default need 178.83 mA [E, A-35] → margin +1.22 mA" (since 26 Sep 08:03 "Default need 178.96 mA [E, A-35] → margin +1.09 mA", orchestrator text fix); c20 note updated | c17 §2, c21 E-6; analog out/r10_fixes.txt (F-2) |
| F-3.7 analog quiescent in c17 (found against analog's R10 r2_power) | c17 now takes the analog 5V_ANA quiescent directly (analog out/r2_power.txt R10: I+ 36.149 / I− 35.221 mA → 73.482 mA; DAC in reset 88.215 mA) instead of R3.12 + deltas (73.434 / 88.164 mA) | the delta chain missed the D413/D414 BAT54 clamp leakage (DY-3, 25 µA per rail → 0.05 mA at 5V_ANA): **S2 344.17 → 344.22, S3f 359.50 → 359.55, S5 352.31 → 352.36 mA; NDK S2 348.67 → 348.72, S3f 364.00 → 364.05 mA** **[superseded (F-1.4): S2 344.39, S3f 359.72, S5 352.53 mA; NDK S2 348.89, S3f 364.22 mA]**; S1, S3, S4, S6, the need and the non-analog total unchanged (S3/S4 carry the analog branch at IOS max) | c17 §1/§3; analog out/r2_power.txt §1 |
| F-3.8 one current input set for the round-2-era release scripts (R10-A3; integration's 390.4 mA find) | pw_common `released_limits()` / `load_basis()`; c17 writes `c17_basis.json` (c03 format: non-analog 270.37 mA, analog I+/I− 36.149/35.221 mA, quiescent 73.48 / 88.21 mA, R509 4.75 k / R510 3.74 k limits, S1–S5, per-rail S2 loads + the c17 deltas, S6 from c22) and computes i_r508 itself (no c16 → c17 → c16 cycle); c04, c09, c10, c11, c14, c15, c16, c18 read it (else c03); run order c03 → c17 → consumers | **moved:** c04 5V_SYS min High 4.311 → 4.318 V (Default 4.342 → 4.350 V; the U502 input now bypasses the U102 RON, E-16 topology), LM27762 VIN 4.219 → 4.224 V (High) / 4.300 → 4.307 V, TLV767 3V3D 145.5 → 151.6 mA, headroom +0.772 → +0.770 V; c10 **LM27762 overload bound 115.4 → 116.1 °C (margin +9.6 → +8.9 °C)**, U102 clamp case 136.6 → 137.9 °C (out-of-spec source, +17.1), TLV767 S5 row now derived (165.0 mA, 88.8 °C, +36.2; was a hard-coded 158.6 mA / 87.7 °C), U503 High short 2.68 → 2.72 W (TSD, unchanged verdict); c15 High R_NEG allowance at 4.40 V (convention A) 2.49 / 2.37 → **2.53 / 2.41 Ω**, negative envelope 148/111/88 → 150/112/90 mA; c11 High limiting 0.19/0.77 → 0.20/0.78 W, start-step table ±0.04 ms; c09 margin +0.067 → +0.074 V (note: the c21 TPS70933 band supersedes c09's). E-16 topology note printed in c04/c10 (U502 rows superseded by c22). **c14** (final basis, 641 s): I/V rails never below 4.5 V in the window, 3V3A < 0.3 V ≤ 0.743 ms (was 0.749), brown-out action 0.046–0.080 ms (was 0.082) before the MCU reset in 96/96 corners, 3V3D − 3V3A +0 mV while MCLK runs, DVDD − DVCC ≤ +5 mV, X-4 U302 +458 / U503 +448 mV (were +457 / +447; L-8), U502 +401 mV (allowed, TPS70933), U504 −23, U303 +5 mV; **c16** A (history start model, 467 s): rails good 4.35 → 4.40 ms, ≤ 291 UVLO trips, 1.44 mJ; sections B–E unchanged; c18: see F-3.9 | outputs + `calc/*_preR10*.bak` |
| F-3.9 c18 (release start model) on the final basis | re-run 26 Sep 07:25–07:44 (the 06:59 c18 runs had all failed at start with "No module named 'pw_common'"): out.txt emptied, then `10 reduced`, `470 reduced`, `10 timing`, `470 timing` from `calc/`, sequential, detached (106 / 299 / 77 / 261 s); `10 timing` failed twice at start (nothing written) → cause: the runner's working directory goes stale on this rclone-backed workspace (getcwd() fails, logged) → the runner re-`cd`s and checks the import before every run, resumed at invocation 3 (the invocations are independent → same file as one uninterrupted sequence); script unchanged: every block carries the line `BASIS: R10 final (c17_basis.json)` | **C514 10 nF (release): T_START metric (RAILS_OK_N low AND 5V_ANA_F ≥ 4.00 / 4.12 V, settled) ≤ 18.6 / 18.8 → ≤ 19.0 / 19.1 ms → T_START 40 ms keeps +20.9 ms (was +21.2)**; rails good (PGOOD) Default min 17.9 → 18.3 ms (timing set 18.0 → 18.3), Default max 14.1 → 14.2 (15.5 → 15.7 at I_st 0.10 A), High min 8.2 (15.5 → 15.7 at 0.10 A); I/V rails 95 % ≤ 17.7 → 18.0 ms; UVLO trips ≤ 919 / 842 / 619 → **929 / 848 / 609** (Default min / Default max / High min); time in current limit 16.8 / 12.5 / 6.1 → **17.1 / 12.7 / 6.0 ms**; U503 energy ≤ 4.5 / 4.1 / 3.5 → **4.6 / 4.2 / 3.5 mJ**; 5V_ANA_F min 2.22–2.25 V unchanged. **High limit: the High-min corner 390.4 → 395.4 mA (U503 peak 390 → 395 mA)**; Default 180.05 / 222.6 mA unchanged; c18 has no High-max corner (as before), so 489.7 mA appears only in its BASIS line (High 395.4 / 442.7 / 489.7 mA). Drivers: analog quiescent left on VPOS/VNEG 17.1 / 19.0 → 18.8 / 20.5 mA (Default rows) and the High-min limit. C514 470 nF (DX-4 history): T_START 105.0 / 106.7 ms unchanged, PGOOD ≤ 101.2 → 101.4 ms, trips 929 / 848 / 610, current limit 17.1 / 12.7 / 4.4 ms, ≤ 4.7 → 4.8 mJ. Verdicts unchanged: input current never above the U503 limit (USB budget unchanged), no limit breaks; class E (R-51: register note "rails good ≤ 18.8 ms" → ≤ 19.1 ms, integration) | `calc/c18_x8_rail_start.out.txt`, `c18_10nF.json`, `c18_470nF.json`, `c18_10nF_timing.json`, `c18_470nF_timing.json`; `calc/run_c18_R10.sh`, `calc/long_R10.log`; backups `calc/c18_*_preR10final*.bak` |
| F-3.5 files changed | — | `report.md` (this section + marks), `fix_progress.md`, `calc/c17_budget_r3.py` / `.out.txt` / `c17_results.json`, `calc/c21_r9_checks.py` / `.out.txt` / `c21_results.json`, `calc/c20_ve_checks.py` / `.out.txt`, `calc/c01_ovp_hotplug.out.txt`, `calc/c02_attach_inrush.out.txt`, `calc/c15_lm27762_headroom.out.txt`, `calc/c16_r3_review_fixes.out.txt` / `c16_results.json`, `calc/c18_x8_rail_start.out.txt` / `c18_10nF.json` / `c18_470nF.json`, `calc/gen_bom_netlist.py` / `.out.txt`, `calc/pw_common.py`, `calc/c17_basis.json` (new), `calc/c04*`, `c09*`, `c10*`, `c11*`, `c15*` (.py/.out.txt, c04_results.json), `c14*`, `c16*`, `c18*` (re-run on the final basis), `bom_rows.csv` (R108 and R509 description texts only); backups `calc/*_preR10*.bak`, `calc/report_preR10.md.bak`. Netlist unchanged. Integration: the package INDEX.md and the summary still quote c21's 4.81 k figures | — |

**R10 F-1 — protection's new block-6 loads (message 26 Sep 06:43, maxima vs the R9-check basis I+ 2.66 / I− 2.48 mA):**

| Item | Action | Result | Evidence |
|---|---|---|---|
| F-1.1 VPOS +0.078 mA, VNEG +0.086 mA (block 6 now I+ ≤ 2.74, I− ≤ 2.57 mA: U601/U602 and their dividers removed; U611/U612 over-range TLV1704, 8 × TLV3402, 8 × 680 k timer resistors at VNEG, two VNEG dividers added) | first a provisional flat term I+ + 1.03·I− = +0.1666 mA (need 178.996 / +1.055 mA, 06:47); then, as agreed with analog (06:36), **analog's final F-1 figures (06:53, one r2_power run: block 6 2.738 / 2.566 mA, new LEG taps 245.6 k per leg): need_for() 178.9230 mA (= 178.7912 − 0.0348 taps + 0.1666 block 6), quiescent I+ 36.2266 / I− 35.3067 → 73.648 mA, DAC in reset 49.1569 / 37.0543 → 88.378 mA**; c17 `F1_IN_ANALOG = True` (flat term 0) | **Default need 178.829 → 178.961 mA; margin +1.222 → +1.090 mA (+1.09), ≥ 0 → R509 stays 4.75 k** (margin used up at LM27762 IQ 2.09 mA or CP 1.038, analog); S3 unchanged by the analog term (analog branch at IOS max) | c17 §1/§2; analog out/r2_power.txt (F-1) |
| F-1.1b analog interim (06:50) | superseded by F-1.1 final (06:53) | the new LEG taps lower the need by 0.035 mA (inside the final 178.9230 mA) | analog messages 06:50 / 06:53 |
| F-1.1c protection correction (07:09): final block 6 VPOS +0.054 / VNEG +0.062 mA (I+ ≤ 2.714 / I− ≤ 2.542 mA) | noted; the budget keeps the 06:53 figures (block 6 2.738 / 2.566 mA) as a stated bound unless analog re-runs r2_power (asked); **closed 07:48 (protection FYI): the orchestrator keeps this bound deliberately, no re-run** (c14, c16, c18 on `c17_basis.json` stand); the new R951 (OR self-test) draws 0 in normal operation | the budget is conservative by 0.024 + 1.03 × 0.024 = **0.049 mA** at 5V_ANA: guaranteed margin ≥ +1.090 mA (exact ≈ +1.14 mA); S2/S3f/S5 are high by ≤ 0.05 mA; 3V3A/3V3M/3V3D unchanged | protection message 07:09 |
| F-1.2 3V3A +0.0072 mA (two 3V3A dividers) | c17 non-analog, S2–S5 | S3 493.45 → **493.46 mA** (NDK 497.95 → **497.96**), S4 760.76 → 760.77 (NDK 765.27) | c17 |
| F-1.3 3V3M/3V3D: no static change (MCU/CPLD test line ≤ 4 µA into a GND-referenced divider, boot self-test only) | recorded as 0 (c17, c22) | S1 82.40 mA and **S6 2.2755 / 2.1815 mA unchanged** (VPOS/VNEG/3V3A are off in Stop; E-5 margin +224 µA kept) | c17, c22 §5 |
| F-1.4 all states | c17, c22, c20, c21, c04, c09, c10, c11, c15 re-run (06:57) | **S1 82.40, S2 344.39, S3 493.46, S3f 359.72, S4 760.77, S5 352.53, S6 2.2755 / 2.1815 mA; NDK S2 348.89, S3 497.96, S3f 364.22, S4 765.27 mA**; USB totals: Default 493.46 mA (+6.54; NDK +2.04), High 760.77 mA (+739.23 to 1.5 A), U102 IOS min margin +109 mA | c17, c20, c21, c22 |
| F-1.5 limits | checked | **no limit breaks:** Default margin +1.09 mA ≥ 0; S3 ≤ 500 mA on the planning values (+6.54 / +2.04 NDK); production test S3 ≤ 480 mA: the measured S3 rises by ≤ 0.17 mA (not a planning-value quantity; Q obligation unchanged); S1 ≤ 90 / 100 mA unchanged; S6 ≤ 2.5 mA with ≥ 0.2 mA (E-5) unchanged; R509 4.75 k kept; High need +0.17 mA vs High IOS min 395.4 mA (+75 mA) | — |
| F-1.6 dynamic models | c16, c14 and c18 (4 invocations) re-run on the final basis: c16 / c14 06:59–07:07 (`calc/run_long_R10.sh`: sequential, `PYTHONDONTWRITEBYTECODE=1`, retry on the transient "No module named pw_common" seen twice today on this filesystem); its c18 runs all failed at start → c18 re-run 07:25–07:44 (`calc/run_c18_R10.sh`) | results → F-3.9 | `calc/long_R10.log` |

**F-2 (evidence classes, power rows; rule: G only if every input is a datasheet limit or a G result; any assumption, typical value or model → E; resting on a measurement → Q; no power row rests on a passed measurement — every Q item is an open obligation, no board exists):**

| Row | Register | Proposed | Reason |
|---|---|---|---|
| R-13 Default 32 Ω ≥ 38 mW | G | **E** | IOS min 180.05 mA is G (Eq. 5, ±10.4 % max, R509 0.1 %/25 ppm), but the need 178.96 mA (R10 F-1) contains the LM27762 IQ (390 µA typ, no max) and the estimated CP factor 1.03 → margin +1.09 mA is E (register A-35) |
| R-14 Default 4.4 mm targets | G | **E** | same need basis as R-13 |
| R-73 Default acceptance criterion | E | E | its "G" clause becomes E with R-13; production test S3 ≤ 480 / S1 ≤ 90 mA = Q obligation (open) |
| R-32 S1 ≤ 100 mA | E | E | MCU 80 mA planning value (L-1); Q obligation: S1 on every board |
| R-33 S3 ≤ 500 mA | E | E | MCU/CPLD/DVDD planning values, U208 70 % burst; 493.46 mA (NDK 497.96 mA; R10 F-1); Q obligation: S3 ≤ 480 mA per board |
| R-45 S5 | E | E | planning values |
| R-34 High only with ≥ 1.5 A | G | **E** (or split) | S4 760.77 mA (NDK 765.27; R10 F-1) vs U102 IOS min 870 mA [DS] and 1.5 A rests on the planning values; the gating itself (CC ADC, ILIM_HI pulled to Default at reset, U505) is construction/DS → G if kept as a separate row |
| R-35 Attach ≤ 50 µC | G | **E** | region separation uses the U502 start ≤ 1 ms [ASSUMP]; the 3V3M term uses a load credit (1 − 0.1 A / ICL) [ASSUMP]; D102 10 nF is not a DS maximum. A bound re-run (no credit, 3V3M charge in either region: A ≤ 33.6 µC, B ≤ 40.4 µC) could restore G |
| R-36 Suspend ≤ 2.5 mA in 10 ms | E | E | MCU Stop 1.9 mA planning value, Q507 hot leakage and U502 IGND estimated, U503 turn-off typical only; Q obligation: first-board suspend current |
| R-37 Thermal | E | E | RthJA and +10 °C local rise assumed (c10 on round-2 loads: High-limit terms +1.3 %, < 1 °C) |
| R-42 ESS order + 1V3 range | G | **E** (or split: 1V3 range G) | 1V3 1.2716–1.3248 V is DS-based (c12); "DVDD − DVCC ≤ +5 mV at every unplug corner" rests on the c14 model (LDOs as resistive-dropout models, MCU reset thresholds assumed) and the TLV3402 delay typical × 3 (p10) |
| R-43 3V3D ≤ 3V3A + 0.3 V | E | E | c14 model |
| R-44 / A-22 Brown-out | E | E | PA1 leakage 1 µA and PVD level assumed; value → +67 … +114 mV (R10 c21) |
| R-51 LM27762 EN ≤ VIN | G | G | EN± tied to VIN at the pins (construction); the "rails good ≤ 18.8 ms / T_START 40 ms" note rests on the c18 model (start-up current not in the DS, UVLO typical) → label that note E |
| R-52 U102 IN ≤ 20 V | E | E | cable model, SMDJ12A hot VBR factor assumed; Q obligation i-9 |
| R-53 Reverse bias (L-8) | E | E | c14 model |
| R-54 5V_ANA short detectable | G | G (short) + **new E row** | a short reads ≈ 0 V against any threshold (G); but the threshold band text 3.89–4.12 V ignored ADC error and pin leakage and used the TPS7A20 VDDA — with the VBUS_SENSE treatment it is **3.704–4.236 V** (1 µA PA0 leakage assumed → E). No-false-fault margin at VBUS 4.40 V (E-16 topology): Default +71 mV; High at the 320.1 mA peak need +21 mV, +6 mV with the J101 contact drop (every error at its worst sign) with a common 4.00 V threshold (first estimate without the U502 bypass: +13 / −3 mV) → **digital ADOPTED (R10) a High-mode threshold 3.90 V = 1.247 V = code 1548** (switches with ILIM_HI, only with the switch open or in the downgrade sequence; Default keeps 4.00 V = 1587): band 3.608–4.133 V → **High +124 mV at the peak need, +108 mV with the J101 drop; Default +71 mV**; a short still reads ≈ 0 V (digital firmware_sequences §3, adc_settings §3; power c21 R10 addendum) |
| R-65 ROC/VRM at 5.55 V (L-10) | G | G | datasheet limits only |
| R-67 D+ within TSIGATT | E | E | MCU boot ≤ 10 ms assumed |
| R-69 owner-fit order | − | − | process |
| A-06 BAT54 in S6 | G | G | U102 off → TPS25200 OUT discharge (RDCHG [DS]) holds 5V_SYS at 0 V → D104/D105 unbiased |
| A-11 LM27762, A-12 LP5907 | E | E | typical-only data |
| A-17 C442/C443 reverse | E | E | BAT54 tempco and the AVX reverse rule assumed; **one set agreed: the register uses analog r9_fixes E-8** (13.0 mA: ≤ 0.469 / 0.386 V vs 1.00 / 0.71 V); power c21 E-8 is a cross-check with 17.4 / 14.8 mA and now the AVX limits (was the pre-VE KEMET rule): ≥ +0.17 V |
| A-19 cable model, A-20 thermal model, A-24 USB total, A-28 Q507 leakage | E | E | assumptions (A-24: 493.46 / 497.96 mA NDK; R10 F-1) |
| A-27 TPS70933 range | G | G | DS |

Power inputs to other streams' rows: R-09…R-11 (High power) — power's High IOS min 395.4 mA is G, but the High need carries the same LM27762 IQ / CP 1.03 terms → E by propagation (analog); R-40 (photorelay IF at 5V_SYS 4.30 V, protection) — 5V_SYS min is 4.318 V at the final loads (+18 mV; 4.303 V, +3 mV, with the J101 contact drop; E-16 topology).


## R9 fixes — 25 Sep 2026 (decisions_r9.md E-1…E-15; reviews R9-A…D)

Script: `calc/c21_r9_checks.py` (`.out.txt`, `c21_results.json`); BOM text fixes regenerated (`gen_bom_netlist.py`). Classes: G = datasheet limits + worst-case calculation, E = engineering estimate (assumption named), Q = qualified by bring-up measurement.

| Item | Action | Result | Evidence |
|---|---|---|---|
| E-1 (R9-A A1) Value cells | source checked | power `bom_rows.csv` already carries R108 **100 kΩ**, R109 **470 kΩ**, R535 **100 kΩ**, R536 **47 kΩ** (MPN 0402WGF1003/4703/1003/4702 decode to them); stale derived texts fixed: U102 rating "IOS 0.87–1.08 A with R108 100 k", C104 "R109 470 k: U102 on 3.31–55.3 ms" | bom_rows.csv; c20 |
| E-7 (R9-A A2) U503 OVCSEL | datasheet cited, no change | OPEN is a specified setting: TPS2596 SLVSET8A feature list "3.8-V, 5.7-V and 13.8-V pin-selectable" clamp; §7.5 rows "ROVCSEL = OPEN": VOVC 12.97/13.77/14.52 V, VCLAMP 13.13/13.58/13.97 V (next to "short to GND" 3.75/3.83/3.92 V and "400 kΩ" 5.54/5.69/5.83 V) → pin 8 stays on an isolated pad (no trace, keep clean) | ds/tps2596_fetch.txt lines 9, 94, 284–303 (G) |
| E-5 (R9-B3/C3/D2) suspend margin | inventory corrected, options evaluated | on the planning values (MCU Stop 1.9 mA) S6 (legacy A-to-C) = **2.5094 mA → −9.4 µA** with the corrected BAT54 bound (21.6 µA at 50 °C: 2 µA/25 V/25 °C [DS] × 8.3 (φB 0.65 V) × voltage factors [ASSUMP]) and U102 IIN(on) 191.4 µA at R108 100 k (interpolated [DS]); with the reviewers' 12 µA: 2.4998 mA (+0.2 µA). Fixed terms 2.208 mA (MCU 1.9 + D+ 0.214 + legacy Rp 0.094) leave 0.092 mA for everything else if 0.2 mA margin is wanted; the rest is 0.301 mA, U102 alone 0.193 mA. **No drop-in/BOM change reaches 0.2 mA**: VBUS divider ×10 rejected (1 µA pin leakage × 320 k → 1.0 V error on 5V_SYS, false brown-out), low-leakage clamp (BAS70 class) rejected (loses the L-8 VF), U605 dividers/digital pins ≤ −7 µA. **Designed-in fallback (owner/orchestrator decision): "suspend power cut"** — U502 → 30 V low-IQ LDO from VBUS (TI TPS709 class: 150 mA, 1 µA IQ, ±2 %) + NMOS on U102 EN (MCU GPIO, default on) → U102 off in Stop (IIN(off) ≤ 5 µA [DS]), divider and D104/D105 at 0 → **S6 ≈ 2.238 mA (+0.26 mA)**; impacts: attach region A +20.3 µC → C102 4.7 → 2.2 µF, 3V3M ±2 % (U605 thresholds, ADC reference re-check), one GPIO, resume order (U102 on ≤ 7.3 ms before any domain), c01/c02/c14/c16/c17 re-runs. Until decided: S6 is class **Q** (first-board S6 at 25 °C and 50 °C, MCU Stop measured) **[superseded (R9 E-16): the owner adopted the suspend power cut → S6 2.2755 / 2.1815 mA (+224 / +318 µA), c22; the 2.5094 mA inventory is the pre-E-16 circuit]** | c21 E-5 (E, Q) |
| E-6 (R9-D4) Default margins | acceptance criterion defined | USB **493.46 mA** (+6.54 mA to 500; 497.96 mA, +2.04 mA with the NDK X201) and IOS min **180.05 mA** vs need **178.96 mA (+1.09 mA)** [R10: final c17 run with R509 4.75 k (E-18), unrounded analog need with the F-1 block-6 bound (R10 F-3.6, F-1.1; before F-1 493.45 mA, 178.83 / +1.22; R9 released 178.82 / +1.23); the R9 text had 490.80 mA (+9.20), IOS min 177.9 mA vs need 176.96 mA (+0.97) at the round-3 R509 4.81 k]; no BOM change widens both (R509 trades them 1 : 1.24; the ±10.4 % TPS2596 limit [DS] spans 43 mA). **E (register A-35, R10 F-2; G in R9):** Default power targets at IOS min (+1.09 mA over the need). **E:** USB ≤ 500 mA on the planning values (MCU 80 vs 22.4 mA typ, CPLD 40 mA unpublished, DVDD 60 vs 50 mA nominal, U208 at 70 % burst). **Q (production test, every board):** VBUS current in S3 (Default, full-scale 1 kHz into the worst Default load, 25 °C) ≤ 480 mA (10 mA guard for 25→50 °C and meter error) and S1 ≤ 90 mA; fail → firmware Default volume ceiling (E-21; R509 4.84 k no longer meets the need after E-18) | c21 E-6, c17 |
| E-8 (R9-A5) C442/C443 reverse bias | closed by calculation | reservoir reversal only through the OPA2210 supply pins (D411/D412 block VPOS/VNEG excursions); reverse current ≤ the other rail's load 17.4 / 14.8 mA → D413/D414 BAT54 ≤ 0.475 V at 0 °C, ≤ 0.425 V at 50 °C, ≤ 0.415 V at 60 °C [DS maxima, −1 mV/K ASSUMP] vs KEMET MnO2 reverse limit 15 % (25 °C) … 5 % (85 °C) of 10 V → ≥ 0.92 V at 60 °C (linear [ASSUMP]) → margin ≥ +0.50 V; **open item 6 closed** **[R10: since VE the reservoirs are AVX TAJD227K010RNJ → AVX rule 10 % → 3 % (≥ 0.59 V at 60 °C): margin ≥ +0.17 V with these currents; register A-17 uses analog's set (13.0 mA OPA2210 bound): ≤ 0.469 / 0.386 V vs 1.00 / 0.71 V]** | c21 E-8 (G + E) |
| E-9 rows (power) | constraints given below | see table "Power rows for the canonical power-down order" | c06, c14, c18, c19 |
| R9-A A4 wording | corrected | at AUD_EN low U303 (EN = 3V3D) keeps regulating 1.3 V into R530 (≈ 0.28 A, < 0.1 mJ) for ≈ 90 µs until 3V3D falls below ≈ 1.7 V, then U303 stops at its UVLO and Q506/R530 finish 1V3 (≈ 0.76 ms to < 0.1 V, estimate); DVDD ≤ DVCC throughout (c14 ≤ +5 mV). Replaces "≤ 0.134 ms" and "a regulator never fights its discharge" (R2.4/R2.9) | c14, R3.4 |
| R9-C C2 claim | rebutted (netlist) | Q505/Q506 gates = N5_DIS_D = R528 22 k to **3V3M** (always on), pulled low by Q504 only while AUD_EN is high; at any MCU reset/IWDG AUD_EN falls (R508 10 k) → Q504 off → Q505 (3V3D) and Q506 (1V3) turn ON; U303 stops at its UVLO as 3V3D collapses → the 1V3 discharge **is** guaranteed at a reset | netlist.csv (Q504–Q506, R528, R530, U303) |
| R9-A A8 brown-out margin | thin-margins line | trip band on 5V_SYS 3.756–4.244 V; 5V_SYS min at VBUS 4.40 V: 4.311 V High (+67 mV), 4.296 V with the J101 contact drop (+52 mV), 4.342 V Default (+98 mV) → **+52 … +98 mV** (not 0.17 V); dominated by the 1 µA PA1 leakage assumption (100 mV) **[R10 recomputed (c21): band 3.704–4.236 V with the TPS70933 3V3M range (E-16), 5V_SYS min 4.318 / 4.303 / 4.350 V with the final loads and the E-16 topology → +82 / +67 / +114 mV, i.e. +67 … +114 mV]** | c09, c21 |

**Power rows for the canonical power-down order (E-9; digital owns the table):**

| Exit | Power order and timing that the table must keep |
|---|---|
| Host stop / rate / family change | no rail change (switch open first per digital; MCLK/U205 only) |
| Suspend (DX-1) | fade/mute → RELAY_EN low (switch open ≤ 1.01 ms) → MCLK off → AVCC_EN low (3V3A < 0.1 V ≤ 0.472 ms; U605B forces AUD_EN low ≤ 1.04 ms after 3V3A < 3.0–3.1 V) → AUD_EN low (3V3D < 0.1 V ≤ 0.63 ms, 1V3 follows) → ≥ 0.53 ms after AVCC_EN (≥ 0.75 ms if C441 is fitted) ANA_EN low (U503 off ≈ 12 µs; LM27762 UVLO ≈ 0.4 ms later; I/V reservoirs hold the OPA2210 ≥ 8 ms) → Stop. U102 stays on (unless the E-5 fallback is adopted) |
| Fault shutdown (overload, ANA_SENSE, RAILS_OK_N) | RELAY_EN low first; then as suspend; ANA_EN may drop at any time after RELAY_EN (X-8 keeps the I/V rails above 3V3A) |
| Brown-out (VBUS_SENSE < 4.00 V, action 0.043–0.090 ms) | RELAY_EN → AVCC_EN → AUD_EN low in one interrupt (µs apart); ANA_EN left high (rails follow 5V_ANA_F); hard unplug without firmware (c14 a): I/V ≥ 4.5 V for ≥ 8 ms, 3V3A < 0.3 V ≤ 0.85 ms, DVDD − DVCC ≤ +5 mV |
| I²C double fault (analog fallback) | MCLK off → AVCC_EN low → hardware AUD_EN low (U605B) ≤ 1.04 ms after 3V3A < 3.0–3.1 V → 3V3D < 0.1 V ≤ 0.63 ms later (DVCC falls while 3V3A ≈ 3 V: ESS-correct) → ANA_EN low ≥ 0.53 ms after AVCC_EN |
| MCU reset / IWDG (hardware-defined) | all enables fall together through their pull-downs (AUD_EN R508, AVCC_EN R303, ANA_EN R513, ILIM_HI R511 → Default); discharges from 3V3M turn on (R526/R528): 3V3A ≤ 0.47 ms, 3V3D ≤ 0.63 ms, 1V3 ≈ 0.76 ms; U503 off → rails via UVLO; I/V reservoirs hold ≥ 8 ms |
| Programming mode | entry after SET_CONFIGURATION as the normal power-up (T_START 40 ms); exit = suspend order without the fade |


**E-9 check of digital's table (digital firmware_sequences §15, message 17:11):** S6 row — keep "AVCC_EN and AUD_EN low in one GPIOC write, then ≥ 0.53 ms, then ANA_EN low (S7)", but correct the power numbers: 3V3A < 0.1 V **≤ 0.472 ms** (with C440; 0.512 ms with C441 → wait ≥ 0.75 ms if C441 is ever fitted), 3V3D < 0.1 V **≤ 0.63 ms** (c06; the 0.53 ms wait only has to cover 3V3A, 3V3D is covered by the 1 ms re-enable rule), and replace "DVDD first" by "DVDD ≤ DVCC throughout: U303 (EN = 3V3D) regulates ≈ 90 µs until 3V3D ≈ 1.7 V, then UVLO, Q506 finishes (≈ 0.76 ms, estimate)". Brown-out row — the c14 (b) results assume RELAY_EN, AVCC_EN **and AUD_EN** low in the same interrupt; with only RELAY_EN + AVCC_EN, U605B still forces AUD_EN low ≤ 1.04 ms after 3V3A < 3.0–3.1 V and DVDD ≤ DVCC holds, but it is not the modelled case → add AUD_EN to the same write (no cost). MCU-reset row confirmed (R303/R508/R513, Q502 → N5_DIS_A → Q503; Q504 → N5_DIS_D → Q505/Q506; discharges from 3V3M).
**E-5 follow-up (digital 17:11):** digital adds 0 A beyond the 1.9 mA planning value (+4.5 µA wake). R105/R106 ×1.5 (−11.9 µA) rejected: +0.05 V on the brown-out band leaves ≈ +2 mV at the 4.40 V/J101-drop corner (my c09 band; digital's "0.17 → 0.12 V" uses the R9-A figure). Switched divider (AO3401A high-side + AO3400A driver + 1 MΩ gate pull-up, gate from PB0; all Basic types) saves ≈ 37 µA → S6 2.472 mA (+28 µA with my BAT54 bound) — **not adopted yet**: it does not reach 0.2 mA, becomes redundant if the "suspend power cut" is adopted, and uses the last free ADC-capable pin (PB0) — offered as option (a) for the E-5 owner decision; option (b) is the suspend power cut (+0.26 mA). **[superseded → R9.E16: the owner adopted the suspend power cut; 5V_SYS (and the divider) is unpowered in Stop, option (a) is dropped. N5_U102_OFF needs one static GPIO — digital proposes spare PC14 (weak drive is enough: Q507 gate + R537 1 MΩ, 3.4 µA)]**

### R9.E16 Suspend power cut (owner decision E-16, 25 Sep 2026) and E-17

| Item | Action | Result | Evidence |
|---|---|---|---|
| U502 3V3M LDO | TPS7A2033PDBVR → **TI TPS70933DBVR (C89347, LCSC 5,280 / JLCPCB 32,252, Extended, Economic+Standard, MSL 1)**, IN moved **5V_SYS → VBUS** (next to U102/C102; C102 is its CIN), EN pin 3 **not connected** (floating = enabled; EN max 6.5 V → never tie to VBUS) | 3V3M independent of U102; VIN 2.7–30 V (32 V abs) ≥ the 17.1 V kick and a mis-set 9 V source; 3V3M **3.207–3.343 V** (1 % + 10 mV line + 50 mV load [DS]; was ±1.5 %); dropout ≤ 650 mV at 50 mA / 1400 mV at 150 mA → regulated down to VBUS 4.25 V at the 84 mA planning load (+137 mV at 4.40 V − J101 drop); TJ ≤ 99 °C in spec, 9 V → thermal-shutdown cycling (survives), 17 V kick ≤ 10 µs (≤ 12 µJ) | c22 §1; ds/tps709_fetch.txt (SBVS186H) |
| C502 | 1 µF → **2.2 µF 16 V 0603 (C23630, Basic)** | TPS709 needs COUT ≥ 2.2 µF [DS] | c22 |
| D103 | **deleted** | TPS70933 has reverse-current protection and VOUT abs 7 V independent of VIN [DS] → no OUT→IN clamp needed; its leakage leaves the suspend budget | c22 §1 |
| Q507 + R537 + R538 | **NPN MMBT3904 (C20526, Basic; protection's type)** collector N1_U102_EN, base via **R537 100 kΩ** from **N5_U102_OFF** (MCU PC14), **R538 100 kΩ** base-emitter (all Basic C25741) — replaces the AO3400A (R9 leakage check: its IDSS bound 5 µA at 30 V/55 °C would pull EN to 1.08 V < 1.9 V at VBUS 4.40 V) | PC14 high = U102 off (IB 18 µA, forced β < 1, EN ≪ 0.6 V); low/floating at reset = U102 on; off-state leakage ICEX ≤ 50 nA (30 V, 25 °C) [DS class], ≤ 0.55 µA at 60 °C [ASSUMP ×11] → EN ≥ 3.19 V at VBUS 4.40 V (allowance 3.27 µA, margin ≥ 6×); Stop cost 26.8 µA from PC14 + 11.9 µA through R109; resume: U102 on 3.3–55.3 ms after release | c20 b, c22 §5–6 |
| C102 | 4.7 µF → **2.2 µF 25 V X5R 0805** (Samsung CL21A225KAFNNNE; LCSC code by parts) | attach region A now includes the 3V3M charge: **29.6 µC (41 % margin)**; region B **20.1 µC (60 %)**; gap ≥ 2 ms; hard-short kick with D102 **≤ 17.08 V** (C102 1.1–2.42 µF effective, no tIOS credit) | c22 §2–3 |
| U101 pin 5 | 5V_SYS → **3V3M** | with 5V_SYS off in Stop the D+ J level would forward-bias the USBLC6 upper diode into 5V_SYS; on 3V3M no back-feed; VRM/Transil untouched | c22 §4 |
| Back-feed review | netlist walk | no remaining path from 3V3M into 5V_SYS in Stop (D104/D105 at 0 V bias, dividers at 0, U503 FLT open-drain 7 V abs, U505 D/S at 0 V, TPS70933 blocks OUT→IN) | c22 §4 |
| **S6** | recomputed | **2.2755 mA legacy A-to-C (margin +224 µA ≥ 0.2 mA, E-5 met)**, 2.1815 mA C-to-C (with the NPN Q507 base drive 26.8 µA); MCU Stop stays the 1.9 mA planning value (L-1) | c22 §5, c17 |
| **S1–S5** | unchanged by E-16 | ~~S1 82.40, S2 342.28, S3 490.80, S3f 357.62, S4 758.11, S5 350.43 mA~~ **[superseded (R9 E-18 / R10 F-1.4): S1 82.40, S2 344.39, S3 493.46, S3f 359.72, S4 760.77, S5 352.53 mA, c17 final; before F-1 (F-3.7) 344.22 / 493.45 / 359.55 / 760.76 / 352.36]** (U502 input current moves from 5V_SYS to VBUS: same USB total; Q507/R537 carry 0 while running) | c17 final |
| Brown-out detection | caveat | ratiometric to VDDA = 3V3M: the 4.00 V trip is guaranteed only while the 3V3M load ≤ 50 mA (VDO ≤ 0.65 V [DS]); on the 80 mA planning value 3V3M may leave regulation first (**Q**: MCU current measured; digital may compare against VREFINT). Unplug compliance does not depend on it (c14 case a, X-8) | c22 §1, c14 |
| Unplug / brown-out model | c14 re-run (288 corners, 4 ms; U502 from VBUS with a 13 Ω dropout model, no D103, ratiometric brown-out trip, C102 1.2–2.42 µF) | I/V rails ≥ 4.5 V for the whole 4 ms in every corner while 3V3A < 0.3 V by ≤ 0.749 ms (X-8 compliant, no firmware needed); 3V3D ≤ 3V3A while MCLK runs (+0 mV); DVDD − DVCC ≤ +5 mV; brown-out action 0.046–0.082 ms, before the MCU reset in 96/96 corners (fast unplug: C_3V3M holds VDDA — the ratiometric caveat applies to a slow sag); X-4: U302 +457 / U503 +447 mV without firmware (L-8 residual unchanged), U502 +387 mV now allowed (TPS70933 VOUT abs 7 V, reverse-current protection), U504 −17 mV, U303 +5 mV; MCU reset 0.089–0.579 ms (no firmware) | c14 (E-16 run) |
| Boot / attach (TSIGATT ≤ 23.9 ms per digital, was 79.2 ms) | firmware fact | 3V3M (MCU) now starts at contact, 5V_SYS only 3.3–55.3 ms later (U102 EN delay) → VBUS_SENSE reads 0 during early boot as in Stop; must not count as unplug/brown-out (digital) | c20 b, c22 |
| U102-off timing (digital question 17:27) | answered | U102 may be switched off **0.1 ms after ANA_EN low (S7)**; nothing has to decay first: U503 is off ≤ ~12 µs typ after ANA_EN (0.1 ms allowance, no max published), the LM27762 then drains 5V_ANA_F to its UVLO in ≈ 0.4 ms from its own charge, and the residual charge on 5V_ANA_F/VPOS/VNEG decays internally (not from USB). 5V_SYS falls only ≈ 12 mV/ms (≤ 43 µA of loads on 3.6 µF), so U503 sees VIN > VOUT; any later reversal is clamped by D105 at ≤ 0.24 V (BAT54 at ≤ 0.1 mA [DS]) — X-4 holds. USB current reaches the suspend level within U102 tOFF ≤ 0.3 ms [DS] → S7 + 0.4 ms = 8.75 ms after the last SOF (≤ 9.9 ms, margin 1.15 ms). Gate net renamed to digital's **N5_U102_OFF** (PC14) | c22, DS TPS25200 tOFF |
| Protection R9 E-3/E-2 loads (message 17:29) | budget re-run (c17) | **[history — superseded (R9 E-18), see the end of this cell]** block 6 +0.85 mA (VPOS) / +1.02 mA (VNEG) → +1.90 mA at 5V_ANA, 3V3D +0.03 mA → Default need **178.84 mA**: R509 4.81 k (DY-1) gives IOS min 177.9 mA = **need −0.94 mA (Default targets not guaranteed)**. Options: (i) R509 **4.78 k** (E192): IOS 179.0/200.1/221.3 mA, need +0.15 mA (+0.55 mA with protection's TLV3404 variant, −0.4 mA), Default total **492.13 mA** (7.87 mA to 500; DY-1 accepted ≤ 490.8 mA) — S2 344.21, S3 492.13, S3f 359.55, S4 759.44, S5 352.36 mA; (ii) keep 4.81 k if protection brings the increase to ≤ +0.9 mA at 5V_ANA (asked). **BOM keeps 4.81 k (DY-1) until the orchestrator decides** **[superseded (R9 E-18 and the 19:58 reconciliation): need 178.96 mA (R10 F-1; 178.83 before F-1, released in R9 as 178.82); R509 4.75 k → IOS min 180.05 mA, +1.09 mA; final states in the R10 table]** | c17 (protection R9) |
| Analog R9 need (message 17:30) | confirmed | **[history — superseded (R9 E-18), see the end of this cell]** analog: 5V_ANA quiescent 73.51 mA (G), 88.24 mA DAC in reset, Default need **178.81 mA (G)** (≈ 169.1 mA E at 25 °C maxima) — equals my c17 178.84 mA (ANA_SENSE is 0.038 mA after the VE 100 k/47 k change, not 0.057). G margins: 4.75 k +1.23 mA (Default total 493.45 mA, 6.55 mA to 500), 4.78 k +0.13 mA (492.13 mA), 4.81 k −0.97 mA, 4.87 k −2.97 mA; with protection's TLV3404 variant (≈ −0.8 mA at 5V_ANA): 4.78 k +0.93, 4.81 k −0.17 mA. **Recommendation: R509 4.75 k** (largest G margin with USB ≤ 500 mA) or 4.78 k (minimum for G > 0); both exceed the DY-1 accepted 490.8 mA → orchestrator decision; BOM keeps 4.81 k until then **[superseded (R9 E-18): 4.75 k fitted; need 178.96 mA incl. the F-1 block-6 bound and ANA_SENSE (+0.038 mA) → +1.09 mA (R10 F-1; before F-1 178.83 / +1.22; R9 released 178.82 / +1.23)]** | analog r2_power/r9_fixes, c17 |
| **E-18** R509 | set (orchestrator); analog confirmed G +1.25 mA at the rounded 180.1 mA (**+1.09 mA** at 180.05 mA vs 178.96 mA, R10 F-1; before F-1 +1.22 / 178.83 (F-3.6); the 19:58 reconciliation quoted +1.23 / 178.82; E +11.0 mA), 32 Ω Default ≈ 38.9 mW vs 38, High IOS min 395.4 vs peak need 320.1 mA (+75.3) | **R509 4.75 kΩ 0.1 % owner-fitted (KOA RN73R1JTTD4751B25, DigiKey)**: Default IOS **180.05 / 201.3 / 222.6 mA** (need **178.96 mA → +1.09 mA**, E (A-35), R10 F-1; before F-1 178.83 / +1.22; R9 released 178.82 / +1.23); **R510 3.74 k kept**: High IOS **395.4 / 442.7 / 489.7 mA** (≥ 390 mA and ≥ the High need); final states with the suspend power cut: **S1 82.40, S2 344.39, S3 493.46, S3f 359.72, S4 760.77, S5 352.53 mA, S6 2.2755 mA (legacy A-to-C) / 2.1815 mA (C-to-C)** [R10 F-1.4: final c17 run with the F-1 loads; before F-1 (F-3.7) S2 344.22, S3 493.45, S3f 359.55, S4 760.76, S5 352.36; before F-3.7 this row had S2 344.21, the R9 release 344.17 / 359.50 / 352.31]; USB totals ≤ 500 mA on the planning values (S3 +6.54 mA; NDK X201: S2 348.89, S3 497.96, S3f 364.22, S4 765.27 mA, S3 +2.04 mA); production test unchanged (S3 ≤ 480 mA, S1 ≤ 90 mA); fallback per **E-21** (firmware Default volume ceiling, row below) | c17 (C17_R509 4750, C17_R510 3740), c22 |
| **E-21** fallback for a board failing S3 ≤ 480 mA | defined | **Firmware Default-mode volume ceiling, set per board at production test:** measure I_S3 (Default, 0 dBFS 1 kHz both channels into the worst Default load, 25 °C, USB meter ≤ 1 % + 1 mA) and I_S2 (same state, digital silence); if I_S3 > 480 mA: I_sig = I_S3 − I_S2, ΔI = I_S3 − 478 mA (2 mA guard), ceiling A = −20·log10(1 − ΔI/I_sig) dB (supply current ∝ output amplitude for the class-AB legs), rounded up to the next 0.5 dB DAC volume step, stored in MCU flash; firmware clamps the Default-mode volume to −A (High mode unaffected, U503 hardware limit unchanged). **Verify:** re-measure S3 with the ceiling ≤ 480 mA; log the Default output power at the ceiling (that board's Default power becomes a characterised, not rated, figure); check the ceiling survives reset/power cycle | E-21, c17 |
| E-17 | referenced | Default acceptance criterion approved as defined in R9 fixes E-6 (production test S3 ≤ 480 mA, S1 ≤ 90 mA; ~~a failing board gets R509 4.84 k~~ **[superseded (R9 E-21): a failing board gets the firmware Default volume ceiling; 4.84 k (IOS min 176.89 mA) no longer meets the need]**) | decisions_r9 E-17 |

## VE (value engineering) — 25 Sep 2026 (brief `ve/brief_ve.md`, owner decisions O-1…O-4)

Script: `calc/c20_ve_checks.py` (`.out.txt`); BOM/netlist regenerated (`gen_bom_netlist.py`, `gen_sch_part.py`). Fee basis for the savings: Economic PCBA US$ 3.07 per Extended part type per order (Basic free), Standard US$ 1.53 [VE brief]; global-sourcing charges per line are the parts stream's fee model (not re-priced here). Per board = per order / 5.

| # | Candidate | Verdict | Saving per board / per 5-board order | Checks re-run |
|---|---|---|---|---|
| 1 | R108 86.6 k (Extended C19709) → **100 kΩ Basic C25741** (same type as R105) | **adopted** (drop-in, value recalculated) | US$ 0.61 / 3.07 (one Extended type less) | c20 a: U102 IOS 870/970/1077 mA ≥ S4 ~~758.1 mA (+112 mA)~~ **760.77 mA (+109 mA; NDK X201 765.27 mA, +105 mA) [R10 c20 re-run, F-1; before F-1 760.76 / 765.26]**; post-interruption current 1.08 A (≤ 1.24 A before → kick ≤ 16.99 V holds); attach credit 36.5 µC |
| 2 | R109 300 k (Extended C25774) → **470 kΩ C25790** (same type as R532) | **adopted** | US$ 0.61 / 3.07 (one type less) | c20 b: U102 on 3.31 ms … 55.3 ms after attach (≥ 1 ms; D+ pull-up < TSIGATT 100 ms with ≥ 30 ms margin [ASSUMP MCU boot ≤ 10 ms]); EN ≥ 3.45 V at VBUS 4.40 V with 2 µA; TI ≥ 300 k rule kept |
| 3 | R535/R536 68.1 k/30.1 k (new Extended types) → **100 k / 47 k Basic** (types of R105/R106) | **adopted** | US$ 1.23 / 6.14 (two types less) | c20 c: 5.55 V → ≤ 1.7987 V (≤ 1.8 V, margin 1.3 mV), source 32.0 kΩ (≤ 40 k), 37.8 µA; **firmware constant: 4.00 V = 1.279 V = 1587 counts** (was 1.226 V / 1522); band 3.89–4.12 V → T_START unchanged; need −0.02 mA (favourable) |
| 4 | D103–D105 BAT54 (own type) → **Nexperia BAT54,215 C85084** (the analog D413/D414 type) | **adopted** (consolidation) | US$ 0.61 / 3.07 (one type less) | same part and maxima as modelled in c14 (L-8 unchanged) |
| 5 | R510 3.74 k (LCSC code unknown → global) → **YAGEO RT0603BRD073K74L C861382** (LCSC 4,320, US$ 0.035) | **adopted** (ordering) | US$ 0.025 / 0.13 in part price + one global-sourcing line avoided | none (same part) |
| 6 | R509 4.81 k 0.1 % (YAGEO C861445: LCSC/JLCPCB 0 stock → global) | **owner-fitted**: KOA RN73R1JTTD4811B25 (DigiKey 3,950; 0603, O-4 allowed) **[superseded (R9 E-18): R509 = 4.75 kΩ 0.1 %, KOA RN73R1JTTD4751B25, still owner-fitted]** | one global-sourcing line avoided; owner buys 5 × ≈ US$ 0.10 (+ shared shipping) | value unchanged at the VE time (R9 E-18: 4.75 k); fit before the first ANA_EN — if missing, U503 stays off (ILM open = shutdown [DS Table 3]) |
| 7 | D102 Littelfuse SMDJ12A (global) | **owner-fitted**: Littelfuse SMDJ12A (DigiKey 5,498, US$ 1.01 at 10+; SMC, O-4 allowed) | one global-sourcing line avoided; owner pays 5 × US$ 1.01 (vs US$ 0.75 + global charges) | same part (c16 C unchanged); fit before the first USB attach; ≤ 5 mm from J101, toes +0.3 mm, 1.5 mm iron clearance |
| 8 | D102 → LGE SMDJ12A C5806873 (LCSC 915, US$ 0.31) / Jingdao C438150 (230) | **rejected** | (would save ≈ US$ 0.70/board vs owner-fitted) | IR and VBR max not on the LCSC page and the datasheet is not retrievable; the S6 margin (+3.5 µA) cannot absorb an unverified leakage. MDD C2994091 / TSC C3717799 (IR ≤ 2/1 µA) are out of stock |
| 9 | J101 GCT USB4105 (global, 255 °C/5 s → blocks Economic) → **HRO TYPE-C-31-M-12 C165948** (16P, 20 V, 5 A, −30…+80 °C, JLCPCB "Economic and Standard", MSL 1, LCSC 268,080, US$ 0.19) | **not adopted — pending datasheet check** | would save ≈ US$ 0.90/board in part price + the global/inspection charges and unblock Economic PCBA | the HRO datasheet (reflow peak/time, pad drawing) is cookie-gated for my tools → reflow ≥ 260 °C and the pad map are NOT verified. If parts confirms both, it is a drop-in with the standard 16P row (A1/B12 GND … B1/A12 GND, 4 shell stakes; map from the HRO drawing) and L-7 sample continuity applies |
| 10 | Amphenol 12401610E4#2A (C5119948, 24P USB 3.2, US$ 1.33) | rejected | none (more expensive, 24P land) | — |
| 11 | R501–R504 / R533/R534 0.1 % → 1 % Basic | rejected | — | D-6/D-7 windows and the analog/protection thresholds were verified with 0.1 % (other streams' re-verification needed) |
| 12 | U505 TMUX1101 → AO3400A | rejected | — | D-5: MOSFET off-leakage has no guarantee at 0.7 V/60 °C (5 µA bound = 3 % of the Default limit → breaks the ~~490.8 mA~~ total **[R9: 493.45 mA, R10 F-1: 493.46 mA; +3 % of the limit ≈ +6.7 mA would exceed 500 mA]**) |

**Totals (power, adopted):** Extended types −5 → **US$ 15.35 per order (US$ 3.07 per board)** in Economic fees (US$ 7.65 in Standard); 3 global-sourced lines removed (R509, R510, D102; value per the parts fee model); part-price change ≈ +US$ 0.19 per board (owner-bought D102 at the 10+ price), owner purchase ≈ US$ 5.55 per order + shipping share. J101 would add the largest single saving once its datasheet is verified.

**Economic PCBA (O-2) for the JLCPCB-placed power parts:** all ICs (TI), MLCCs, resistors, BAT54, AO3400A, FB501 are standard lead-free parts listed by JLCPCB for Economic and Standard [JLCPCB part pages; individual reflow ratings not re-read]; minimum pitch 0.5 mm (WSON/SOT-5X3) ≥ 0.4 mm; smallest package 0402. **J101 USB4105 (255 °C −0/+5, ≤ 5 s) is the only power part that blocks Economic** — item 9.

**Interface:** digital — ANA_SENSE threshold 1.279 V / 1587 counts, source 32.0 kΩ + 100 pF; U102 may turn on up to 55 ms after attach (D+ pull-up still within TSIGATT). Parts — verify HRO TYPE-C-31-M-12 (reflow rating, pad drawing) and the Basic/Extended class of C25790; owner-fitted list: R509 (0603), D102 (SMC).

## R8 review fixes (round 3) — 25 Sep 2026

**History (round 3).** Superseded wherever R9/R10 differ: R509 4.75 kΩ (E-18; the round-3 values 4.81 k / 4.84 k), every IOS, need, margin and state total → R10 table; D103 deleted, U502 TPS70933 on VBUS, C102 2.2 µF, attach 29.6 / 20.1 µC, kick ≤ 17.08 V (E-16, c22); R535/R536 100 k / 47 k → 1.279 V = 1587 counts (VE).

Binding inputs: `integration/decisions_r8c.md` X-1…X-10 (power items X-1…X-5, X-10) with D-1…D-19 of `decisions_r8b.md`; review evidence `review/review_states.md` #2, #3, #16, #19, #22, #28, #30 and `review/review_pins_a.md` findings 1 and 4. New scripts: `calc/c16_r3_review_fixes.py` (sections A X-1, B X-2, C X-3, D X-5, E X-10; `.out.txt`, `c16_results.json`), `calc/c17_budget_r3.py` (budget; `c17_results.json`), `calc/c14_unplug_order.py` re-run (EN = VIN, U303 EN = 3V3D, Schottky clamps, C103 100 pF; variant output `c14_unplug_order_pmeg.out.txt`), `calc/gen_sch_part.py` + `gen_bom_netlist.py` (BOM/netlist). c01 §4, c02 and c11 §6 carry a "superseded by c16" note. Round-2 sections below stay valid unless contradicted here. Labels as before.

### R3.F Final values — round 3 (decisions_r8c DY-1, DY-2, DY-4, DY-5; supersedes every earlier R3 value below) **[round-3 finals — superseded where R9/R10 differ, see the R10 table]**

| Item | Final value | Basis |
|---|---|---|
| U501 LM27762 EN+/EN− | tied to VIN (5V_ANA_F); RAIL_EN, R506, R507 deleted | X-1 |
| C514 (U503 dVdt) | **10 nF** 50 V X7R 0402 (C15195) — 470 nF option of DX-4 reverted | DY-2; ramp 0→5.5 V 0.9–1.9 ms; rails good ≤ 18.8 ms with the X-8 reservoirs (incl. 5V_ANA_F ≥ 4.12 V, c18) |
| Firmware T_START (RAILS_OK_N / ANA_SENSE validity after ANA_EN) | **40 ms** | DY-2 (model ≤ 18.8 ms) |
| C104 (U102 EN) | 100 nF 16 V X7R 0402 (C1525) | X-2; U102 on ≥ 2.24 ms after attach; regions A 28.5 µC / B 40.2 µC (37.0 µC with IOS credit) **[VE R109 470 k: ≥ 3.31 ms; R9 E-16: regions 29.6 / 20.1 µC, c22]** |
| D102 (VBUS TVS) | Littelfuse SMDJ12A | X-3; U102 IN ≤ 16.99 V, no tIOS credit **[R9 E-16: ≤ 17.08 V with C102 2.2 µF, c22]** |
| D103 / D104 / D105 (OUT→IN) | Nexperia BAT54,215 on U502 / U302 / U503; U303 EN = 3V3D | X-4; residual VOUT − VIN 0.40–0.46 V accepted (**L-8**, DY-5) **[R9 E-16: D103 deleted (TPS70933)]** |
| R535 / R536 / C516 (ANA_SENSE) | 68.1 k / 30.1 k 1 % / 100 pF C0G | X-5; 4.00 V ↔ 1.226 V (1522 counts) **[VE: 100 k / 47 k → 1.279 V = 1587 counts]** |
| C103 / R508 | 100 pF C0G (C1546) / 10 kΩ | X-10 |
| **R509 / R510** | ~~**4.81 kΩ (E192, 0.1 %)**~~ **[superseded (R9 E-18): 4.75 kΩ 0.1 % owner-fitted]** / 3.74 kΩ | DY-1 (round 3): Default total ≤ 490.8 mA accepted (9.2 mA to 500 mA); IOS 177.9/198.9/220.0 mA (need 176.96 mA, +0.97); High 393.3/440.4/487.1 mA **[superseded (R9 E-18): IOS 180.05/201.3/222.6 mA, need 178.96 mA, +1.09 mA (R10 F-1); total 493.46 mA; High 395.4/442.7/489.7 mA]** |
| C441 | DNF | DY-4 |
| C440 (analog) | confirmed: 3V3A ≤ 8.04–8.54 µF effective ≤ 10 µF | c19 |

| State (c17 final, round 3 — superseded (R9 E-16/E-18)) | S1 | S2 | S3 | S3f | S4 | S5 | S6 (A-to-C / C-to-C) |
|---|---|---|---|---|---|---|---|
| Max (mA) | 82.40 | 342.28 | 490.80 | 357.62 | 758.11 | 350.43 | 2.4965 / 2.4021 |
| Limit (mA) | 100 | 500 | 500 (490 rule −0.80, DY-1) | 500 | 1500 | 500 | 2.5 |
| Margin | +17.60 | +157.72 | +9.20 | +142.38 | +741.89 | +149.57 | +3.5 / +97.9 µA |
| **Final (R9 E-16/E-18, R10 F-1; c17/c22; before F-1 see R10 F-3.7)** | **82.40** | **344.39** | **493.46** | **359.72** | **760.77** | **352.53** | **2.2755 / 2.1815** (+224 / +318 µA) |

L-1 applies to every state (MCU/CPLD placeholders; production test measures every board). Remaining power statements in R3.0–R3.17 stay valid except where this table differs (C514 470 nF in R3.13 and the intermediate R509 values are superseded).

### R3.0 What changed (every change) and the new numbers

| # | Change | Result / evidence |
|---|---|---|
| X-1 | **U501 EN+ (pin 12) and EN− (pin 8) tied to U501 VIN (5V_ANA_F) at the pins; RAIL_EN, R506, R507 deleted** (MCU PB8 spare, digital) | EN = VIN in every state → LM27762 abs max (GND−0.3 V … VIN) met by construction; rails start with the U503 dVdt ramp after ANA_EN and stop when 5V_ANA_F falls below UVLO after ANA_EN low (c16 A, c14) |
| X-1 | **C514 stays 10 nF** (sweep 10/47/100/220 nF) **[final → R3.F: 10 nF (DY-2)]** | rails good ≤ 4.35 ms after ANA_EN (**with the analog X-8 reservoirs ≤ 18.8 ms incl. 5V_ANA_F ≥ 4.12 V → R3.11/R3.12**) (47 nF 11.0 ms, 100 nF 21.1 ms, 220 nF 46.0 ms); a slower ramp does **not** remove UVLO cycling (see R3.1) |
| X-2 | **C104 100 nF 16 V X7R 0402 (C1525) U102 EN → GND** | U102 cannot turn on earlier than **2.24 ms** after attach (EN 0.6 V min threshold, +2 µA leakage, R109 −1 %, C104 −27 %); latest 5V_SYS up 33.9 ms; attach regions separated by ≥ 1.96 ms (c16 B) |
| X-3 | **D102 Littelfuse SMDJ12A** (3000 W, DO-214AB) VBUS–GND at J101 | U102 IN ≤ **16.99 V** at a 5V_SYS hard short with **no tIOS credit** (cable 0.05–0.4 Ω, 0.25–1.5 µH); SMF/SMAJ/SMBJ/SMCJ12A and SMAJ13A fail (31.1/25.4/27.5/22.7/18.6 V) (c16 C) |
| X-4 | **D103 (U502 3V3M→5V_SYS), D104 (U302 3V3A→5V_SYS), D105 (U503 5V_ANA→5V_SYS): Nexperia BAT54,215**; U504 and U303 need none (−3 mV, +5 mV) | VOUT − VIN ≤ +404 / +458 / +452 mV with BAT54 (round 2, body diodes only: 0.54–0.62 V) — **the 0.3 V target is NOT met with a low-leakage diode**, see R3.4 |
| X-4 | **U303 EN (pin 3) tied to 3V3D** (its IN); Q506/R530 kept | TLV758P "VEN > VIN needs 1 mA IN sink" case removed (pins-a F4); DVDD − DVCC ≤ +5 mV at every unplug corner (c14 §3) |
| X-5 | **R535 68.1 k / R536 30.1 k (1 %) 5V_ANA_F → ANA_SENSE (MCU PA0) + C516 100 pF C0G (C1546)** | ≤ 1.725 V at 5.55 V, source 20.9 kΩ, 57 µA; 4.00 V ↔ **1.226 V = 1522 counts** (band 3.89–4.12 V) (c16 D) |
| X-10 | **C103 10 nF → 100 pF C0G 0402 (Samsung CL05C101JB5NNNC, C1546)** | VBUS_SENSE τ 3.6 µs; brown-out action 0.049–0.118 ms after the source loss, before the MCU reset in 96/96 corners (c14 §5) |
| X-10 | **R508 47 k → 10 kΩ** (AUD_EN now fed through digital R237 4.7 k) | AUD_EN high ≥ **2.18 V** (2.245 V nominal; ≥ 1.2 V TLV767, ≥ 1.45 V Q504); low with PC10 floating ≤ **0.11 V** for a TLV767 pull-up up to 10 µA (≤ 0.4 V up to 39 µA) (c16 E) |
| Budget | new loads added; **R509 4.75 k / R510 3.83 k unchanged** (same rule) **[superseded → R3.17: R509 4.81 k (E192, D-5 rule conflict), R510 3.74 k → superseded (R9 E-18): R509 4.75 k, R510 3.74 k]** | Default total **489.96 mA** (≤ 490 by 0.04 mA); IOS 180.1/201.3/222.6 mA; need 176.27 mA (+3.8 mA); High 390.4/437.1/483.4 mA (c17) |

| State | Round 3 max (mA) — superseded (R9), see the R10 table | Limit | Margin |
|---|---|---|---|
| S1 attached, unconfigured | 83.39 | 100 | +16.6 |
| S2 configured idle | 338.19 | 500 | +161.8 |
| S3 Default playing at IOS max | 489.96 | 490 rule / 500 | +0.04 / +10.04 |
| S3f family change | 353.53 | 500 | +146.5 |
| S4 High | 751.0 | 1500 | +749 |
| S5 programming mode (only after SET_CONFIGURATION) | 346.30 | 500 | +153.7 |
| **S6 suspend** (legacy A-to-C / C-to-C) **[superseded → R3.14: 2.4965 / 2.4021 mA with DX-2 → superseded (R9 E-16): 2.2755 / 2.1815 mA]** | **3.673 / 3.579** with all placeholders; **2.683 / 2.589** with a nanopower U605 | 2.5 | **−1.17 / −1.08; −0.18 / −0.09 → NOT met on the placeholders (L-1)** |

### R3.1 X-1: LM27762 start with EN = VIN during the dVdt ramp (c16 A)
* Model: 2880 corners (C514 10/47/100/220 nF × SR min/max; LM27762 start current per path I_st 0.10/0.15/0.25/0.5/1.0 A — **not specified**, 500 mA typ is the datasheet's shorted-output input current limit; UVLO 2.6/2.4 V typ plus [ASSUMP] 2.7/2.6 and 2.5/2.2 V corners; Default min/max and High min limits; 5V_ANA 5.0/12.1 µF, rails 15.6/33.8 µF, CP 4.2/11 µF; 5V_SYS 4.30/5.50 V).
* The LM27762 leaves UVLO at ≈ 2.6 V with its rails at 0 V; the step from 0 V to VIN draws I_st. If 2 × I_st + quiescent + C_5V_ANA × SR exceeds the U503 limit at that instant, 5V_ANA_F falls back through UVLO — **independent of the ramp rate**. Cycling is seen for I_st ≥ 0.10 A (Default min), ≥ 0.15 A (Default max), ≥ 0.25 A (High min) at every C514; ≤ 287 UVLO trips; **no C514 value gives a cycle-free start** with the unspecified (≈ 0.5 A typ) start current. The minimum "safe ramp" does not exist for I_st > (ILIM − quiescent)/2 ≈ 55 mA per path.
* Consequences (all corners): EN = VIN throughout (abs max met); input current ≤ the U503 limit (peak 390 mA only in the High-min corner) → the USB budget is unchanged; 5V_ANA_F ≥ 2.13 V after the first turn-on; U503 energy ≤ 1.42 mJ (10 nF), no FLT; **rails good ≤ 4.35 ms** after ANA_EN with C514 10 nF (≤ 18.8 ms with the X-8 reservoirs, R3.12) → keep 10 nF (slower ramps only lengthen the start: 100 nF 21.1 ms would break the 20 ms rule). Bring-up M9 stays (scope 5V_ANA_F/VPOS/VNEG/PGOOD at ANA_EN).
* **Sequences (rails now follow ANA_EN):** power-up — ANA_EN high → U503 ramp → LM27762 start (≤ 4.35 ms) → RAILS_OK_N and ANA_SENSE valid only with ANA_EN high ≥ 20 ms → AVCC_EN → (3V3A good, U605A/B release) → AUD_EN → 3V3D, and 1V3 follows 3V3D through the U303 UVLO (EN = IN). Controlled power-down / suspend — RELAY_EN low → MCLK off → AUD_EN + AVCC_EN low → wait ≥ 0.39 ms (3V3A < 0.1 V) → ANA_EN low → U503 off (~12 µs typ) → the LM27762 load drains 5V_ANA_F (C506 + C507) to UVLO in ≈ 0.4 ms → rails stop (active pull-down / 50 kΩ); no RAIL_EN step. Brown-out — firmware at VBUS_SENSE < 4.00 V: RELAY_EN + AVCC_EN + AUD_EN low in one interrupt, ANA_EN left high; the rails follow 5V_ANA_F down; c14 window (3V3A ≥ 0.3 V with rails < 4.5 V): (b) Default −0.43…−0.04 ms (compliant), High −0.09…+0.085 ms; (a) no firmware ≤ +0.50 ms (High) — the D-17/X-8 analog residual.

### R3.2 X-2: C104 and the attach regions (c16 B)
* TPS25200 EN [DS 5.5]: turn-on ≤ 1.9 V (no minimum → bounded only by the 0.6 V turn-off minimum), IEN ±2 µA, tON 7.3 ms max, no minimum. Earliest: VBUS 5.50 V, +2 µA into C104, R109 297 k, C104 72.7 nF (100 nF −10 % −15 % −5 % ageing), threshold 0.6 V, tON 0 → **2.24 ms**; latest 26.6 ms + 7.3 ms = 33.9 ms (+1.15 ms TPS7A20 + MCU boot < TSIGATT 100 ms). Alternatives: 47 nF C0G 1.37 ms, 47 nF X7R 1.05 ms (too close).
* Region A (contact): C102 + D102 (≤ 10 nF [ASSUMP]) = 5.18 µF × 5.5 V = **28.5 µC** (43 % margin); the ringing envelope falls below 100 mA ≤ 273 µs after contact → **gap ≥ 1.96 ms ≥ 100 µs** → the regions are separate by construction.
* Region B (U102 soft start): 5V_SYS 3.63 µF (incl. D103–D105 Cj) × 5.5 V + 3V3M 6.05 µF (incl. a 0.2 µF [PH] for the new U605/Q207 decoupling) × 3.35 V = **40.2 µC** (19.5 % margin, no soft-start credit) / **37.0 µC** (26 %) with the guaranteed U102 current-limit credit. Rule for the other streams: 3V3M ≤ 5.3 µF nominal.
* Caveat: a re-plug within ~30 ms (C104 not yet discharged through R109) can turn U102 on early; not a compliance case (USB-IF starts from a discharged device).

### R3.3 X-3: D102 (c16 C)
* No tIOS credit: the interruption may come at any instant; before it the cable current rises towards 5.5 V/(Rc + Ron); Ron 0.045 Ω [ASSUMP min, typ 63 mΩ −30 %] / 0.099 Ω [DS]; after it U102 passes ≤ 1.24 A. Without a TVS the kick reaches **50 V** (review #28 confirmed and worse).
* **SMDJ12A**: VRWM 12 V, VBR 13.3–14.7 V (1 mA), VC 19.9 V at 150.8 A (10/1000 µs), IR ≤ 2 µA at 12 V/25 °C, ΔVBR 0.1 %/K [Littelfuse product page / DigiKey]; model VBR,max at TJ 60 °C + secant R_dyn 34.5 mΩ → worst **16.99 V** (Rc 0.05 Ω, Lc 1.5 µH, C102 2.16 µF, Ron 0.045 Ω, steady state), TVS 51.6 A peak, 2.9 mJ (≪ 3000 W rating). A mis-set 9 V source (≤ 9.45 V) stays below VRWM; its hot-plug ringing (≤ 18.9 V) is clamped.
* Leakage at 5.5 V/50 °C is **not in the datasheet**; estimate from the 2 µA/12 V/25 °C maximum: **3.0 µA** (crude bound without the voltage terms 12.2 µA) → budget uses 5 µA; measurement M14. Package SMC (7.9 × 6.2 mm): pads ≤ 5 mm from J101 VBUS/GND with direct vias (layout rule). JLCPCB global sourcing (DigiKey 5,498); alternates SMDJ12A-E, YINT/MDD SMDJ12A (same ratings; LCSC not verified).

### R3.4 X-4: reverse-voltage clamps, U303 EN (c14 round 3)
* c14 re-run (288 corners; EN = VIN; U303 EN = 3V3D; C103 100 pF) with the Schottky OUT→IN in parallel with the body diode. Peak reverse currents 8–54 mA (U502 ≤ 22.6 mA, U302 ≤ 54 mA only without firmware, U503 ≤ 49 mA).
* **BAT54 class (chosen; VF ≤ 0.24/0.32/0.40/0.50/0.80 V at 0.1/1/10/30/100 mA, IR ≤ 2 µA at 25 V/25 °C [Nexperia DS])**: max VOUT − VIN = **+404 mV (U502), +458 mV (U302, no firmware; +45 mV with the brown-out action), +452 mV (U503)** → the 0.3 V abs-max line is still exceeded by ≤ 0.16 V for sub-ms, but the internal body diodes carry ~0 in the model (round 2: 0.54–0.62 V with body-diode conduction). Suspend leakage (D103 1.7 V, D104/D105 5 V reverse): not in the datasheet at 50 °C; estimate ≤ 15 µA total from the 25 V/25 °C maximum, ~1.5 µA typical — **10 µA target not verified**.
* **PMEG2005AEL class (ultra-low VF: 0.19 V/10 mA, 0.29 V/100 mA max)**: VOUT − VIN ≤ **+200 mV** everywhere (`c14_unplug_order_pmeg.out.txt`) but IR 210 µA typ / **600 µA max at 10 V, 25 °C** per diode → suspend impossible → rejected.
* **Plain statement:** no Schottky I could verify meets both X-4 criteria (VF ≤ 0.3 V at ~55 mA and ≤ 10 µA total at 50 °C); the low-leakage choice keeps suspend intact and cuts the reverse stress, the formal 0.3 V limit remains a residual. Fix path for the next round: cut the reverse current at its source (an ANA_EN-derived discharge of 5V_ANA_F and a faster 3V3M-vs-5V_SYS order), or a parts search for a mid-VF low-leakage Schottky.
* U303 EN = 3V3D: 1V3 starts/stops with the U303 UVLO (1.21–1.47 V rising); at a controlled AUD_EN-low shutdown U303 stays enabled until 3V3D < UVLO and feeds R530 (≤ 0.27 A for ≤ ~0.5 ms, ≤ 0.2 mJ) — DVDD ≤ DVCC holds (LDO output ≤ input; c14 ≤ +5 mV); estimated 1V3 < 0.1 V ≤ ~0.76 ms (< 1 ms re-enable rule; c06 not re-run).

### R3.5 X-5 ANA_SENSE and X-10 details (c16 D, E)
* ANA_SENSE: k 0.3023/0.3065/0.3108 (1 %); 5.55 V → ≤ 1.725 V; 20.9 kΩ; C516 τ 2.1 µs; worst injection into an unpowered PA0 66 µA (review #1 class, limited by 20.9 k). Firmware (X-5): < 4.0 V (1522 counts; **digital's netlist note says 1.297 V — correct to 1.226 V**) with ANA_EN high > 5 ms after the ≥ 20 ms start-up window = supply fault in every state → ANA_EN low.
* AUD_EN: R237 4.7 k (digital) / R508 10 k; high ≥ 2.18 V (VOH ≥ 3V3M min − 20 mV [ASSUMP], 1 %); low (PC10 floating at reset) ≤ 0.11 V with a 10 µA [ASSUMP] TLV767 pull-up bound; U605B (protection) must pull ≤ 0.4 V at 0.71 mA; 3V3M load 0.23 mA while AUD_EN is high. AUD_EN now drives U504 EN, Q504 gate and U605B only.

### R3.6 Budget (c17) and L-1 **[round-3 intermediate — superseded (R9 E-18), see the R10 table]**
* New loads: protection U605/U606/U607 + dividers 1.0 mA on 3V3M [PH until protection reports] + U606 0.3 mA/rail on VPOS/VNEG [PH, analog branch]; digital U208 1.67 mA (14 pF × 3.3 V × 36 MHz, counted continuous) [digital], R240 33 µA (PA8 low) [digital], R233 retired (−0.032 mA), R305 10 k via Q207 in S5 0.34 mA; R237/R508 +0.16 mA; ANA_SENSE 57 µA; D102 5 µA; D103–D105 10 µA; IWDG/RTC wake **189 µA** average in suspend [digital, replaces the 0.05 mA PH].
* Same rule: non-analog 266.88 mA → **R509 4.75 k** (IOS min 180.1 mA ≥ need 176.27 mA and ≥ 180 mA; Default total 489.96 mA ≤ 490 by **0.04 mA**); +0.04 mA more → 4.78 k (E192 0.1 %, 179.0 mA) or 4.81 k (177.9 mA), BOM value only; 4.87 k (175.9 mA) would miss the need. R510 3.83 k.
* **L-1 (plain):** the CH32V307 run/Stop/USB-PHY-suspend and AGRV2K currents are vendor-unpublished; the budgets use MCU 80 mA (22.4 mA typ), Stop 1.9 mA (0.11 mA typ), CPLD 40 mA. On these placeholders **the 2.5 mA suspend limit is not met** (2.68 mA even with a nanopower U605; 0.89 mA with the typical Stop); 100 mA/500 mA/2.5 mA compliance is established only by measuring every board in every state (production test). Request to protection: U605 + its 3V3M dividers ≤ 10 µA in suspend (their TLV3402 choice).

### R3.7 Stress (new/changed parts, worst state)

| Ref | Parameter | Worst case | Rating | Margin |
|---|---|---|---|---|
| D102 SMDJ12A | V / pulse | 5.5 V standing; 51.6 A, 2.9 mJ, 17.0 V clamp | VRWM 12 V; 3000 W 10/1000 µs | ×2.2; large |
| C104 | V | ≤ 5.5 V (≤ 7 V with a 20 V fault via the EN Zener) | 16 V | ×2.3 |
| D103–D105 BAT54 | VR / IF | ≤ 5.55 V / ≤ 54 mA for < 1 ms | 30 V / 200 mA cont. | ×5.4 / ×3.7 |
| R535, R536, C516 | V / P | 5.55 V, 0.2 mW; 1.73 V | 50 V, 62.5 mW; 50 V C0G | large |
| R508 10 k | P | 0.5 mW | 62.5 mW | large |
| U501 EN± | V | = VIN | GND−0.3 … VIN | met by construction |
| R530 | pulse | ≤ 0.27 A, ≤ 0.2 mJ at AUD_EN low (U303 on until UVLO) | 0.1 W 0603 pulse | met (not re-measured) |

### R3.8 Interface notes
* **Digital:** RAIL_EN deleted (PB8 spare — done in your netlist); every rule that referred to RAIL_EN now refers to ANA_EN (RAILS_OK_N valid only with ANA_EN = 1 ≥ 20 ms; the rails start ≤ 4.35 ms after ANA_EN, may step through UVLO); ANA_SENSE threshold 1.226 V / 1522 counts (not 1.297 V); source 20.9 kΩ + 100 pF for the ADC sample time; C103 is 100 pF; U303 no longer on AUD_EN.
* **Protection:** U605B VOL ≤ 0.4 V at 0.71 mA against R237; U605 + dividers ≤ 10 µA in suspend; please report the final U605/U606/U607 currents (the 1 mA PH decides R509: +0.04 mA margin).
* **Analog:** Default need with the new analog-branch loads 176.27 mA (+0.67 mA: ANA_SENSE 57 µA, U606 PH) vs IOS min 180.1 mA; rails start in UVLO steps ≤ 4.35 ms after ANA_EN (switch open).
* **Integration:** `check_design.py` IFACE list — remove RAIL_EN, add ANA_SENSE.

### R3.9 What is still assumed / not verified
LM27762 start current and UVLO thresholds (typical only; model behavioural, M9); TPS25200 EN leakage bound applied at all EN voltages, C104 X7R ageing 5 % [ASSUMP]; SMDJ12A leakage at 5.5 V/50 °C (estimate 3.0 µA), capacitance ≤ 10 nF [ASSUMP], secant clamp model, TPS25200 Ron min 45 mΩ [ASSUMP], uncorrelated cable R/L envelope, LCSC/JLCPCB sourcing of SMDJ12A; BAT54 leakage at 50 °C (estimate ≤ 15 µA total) and the X-4 VF ≤ 0.3 V target (not met, R3.4); TLV767 EN pull-up bound 10 µA and MCU VOH drop 20 mV [ASSUMP]; placeholders (protection 1 mA, U606 0.3 mA/rail, MCU/CPLD per L-1); c06 discharge times and c08 suspend timeline not re-run (U303 EN change; the suspend order is digital's); LCSC codes of R535/R536/BAT54 to be confirmed by parts.

### R3.10 Integration check (`check_design.py power protection analog digital`, 25 Sep 2026 ~09:00; re-run 09:33 after analog X-8: 371 parts, 203 nets, 1095 pins, same two items)
332 parts, 184 nets, 992 pins. Issues: `iface_absent` **RAIL_EN** (deleted by X-1; the checker's interface list still names it) and `cross_stream_non_iface` **ANA_SENSE** (new X-5 net power ↔ digital, not yet in the checker's list). No other issue on power nets (no duplicate designators, no pin on two nets, pin counts match: D103–D105 3 pins incl. NC, D102 2, J101 16).

### R3.11 Follow-up 1 (09:02): analog X-8 adopted — reservoirs in the start and unplug models, C514, C440/C441
* Inputs (analog r3 message, `analog/netlist.csv`): D411 VPOS → N4_VPOS_IV, D412 N4_VNEG_IV → VNEG (PMEG2010AEH), C442/C443 KEMET T520D227M006ATE015 220 µF 6.3 V polymer (176–264 µF), OPA2210 + I/V networks 17.4/14.8 mA on the I/V rails; C440 2.2 µF on VCCA after FB302; C441 1 µF DNF on 3V3A. New scripts: `calc/c18_x8_rail_start.py` (start with the reservoirs, replaces c11 §6 / c16 A for the X-8 build; `.out.txt`, `c18_10nF.json`, `c18_470nF.json`), `calc/c19_3v3a_c440.py`; `calc/c14_unplug_order.py` now includes the reservoirs (`C14_X8=1`, 8 ms window).
* **Start with the reservoirs (c18, reduced corner set: SR min/max, I_st 0.5/1.0 A per path, UVLO 2.6/2.4 V, 5V_ANA 5 µF, rails 33.8 µF, reservoirs 176/264 µF, 5V_SYS 4.30 V, Default min/max + High min; dt 0.5 µs):**

| C514 | U503 ramp 0→5.5 V | PGOOD (max) | I/V rails 95 % (max) | UVLO trips (max) / last trip | U503 in current limit | 5V_ANA_F min | U503 energy |
|---|---|---|---|---|---|---|---|
| **10 nF (kept)** | 1.1–2.0 ms | **17.9 ms** | 17.6 ms | 919 / 10.0 ms | ≤ 16.8 ms | 2.23 V | ≤ 4.5 mJ |
| 470 nF (analog's ≥ 40 ms request) | 42–75 ms | 101.2 ms | 100.7 ms | 919 / 92.9 ms | ≤ 16.8 ms | 2.22 V | ≤ 4.7 mJ |

* **Decision: C514 stays 10 nF — the ≥ 40 ms ramp is not adopted, with evidence:** the LM27762 (EN = VIN) leaves UVLO at ≈ 2.6 V with its outputs and the reservoirs at 0 V, so the reservoir charge up to ≈ 2.3 V (≈ 60 % of the 1.03 + 1.00 mC) is delivered in the UVLO-cycling phase at the U503 limit for ANY C514; the slow ramp gives the same trip count, the same 16.8 ms in current limit and the same energy, and only delays the start by ≈ 83 ms. The start-up current never exceeds the U503 limit (Default ≤ 222.6 mA incl. quiescent), which the Default rule already allocates → the USB budget is unchanged (S2/S3 as in R3.0).
* **Firmware window (request to digital/orchestrator):** PGOOD ≤ 17.9 ms leaves only 2.1 ms to the "RAILS_OK_N valid with ANA_EN ≥ 20 ms" rule → use **≥ 40 ms** (2× the model) for RAILS_OK_N and the ANA_SENSE start-up window, and set AVCC_EN only after that window with RAILS_OK_N good (the I/V rails are then ≥ 95 %).
* **Unplug with the reservoirs (c14, 288 corners, 8 ms):** the I/V supply (N4_VPOS_IV + |N4_VNEG_IV|) stays ≥ 4.5 V for the whole 8 ms in every corner while 3V3A < 0.3 V at 0.14–0.85 ms → **the analog requirement is met with ≥ 7.1 ms margin in all cases incl. no firmware** (round 3 without X-8: up to +0.50 ms violation). DVDD − DVCC ≤ +5 mV; brown-out action 0.043–0.090 ms, before the MCU reset in 96/96 corners; X-4 (BAT54): U502 +410 mV, U302 +456 mV (no firmware; +120 mV with it), U503 +452 mV — unchanged conclusion (R3.4).
* **C440 / LP5907 COUT (c19):** 3V3A 9.10 µF nominal; effective upper bound 8.04 µF (DC-bias factor 0.8 for the 2.2 µF 16 V 0603 parts [ASSUMP]; analog 8.54 µF) ≤ 10 µF effective [DS] → **C440 confirmed** (the 10.01 µF no-credit count is not the LP5907 criterion). 3V3A < 0.1 V after AVCC_EN low ≤ **0.472 ms** (was 0.385 ms) vs the digital 0.53 ms wait (+0.058 ms).
* **C441 (DNF): footprint OK; fitting it** gives 9.03 µF effective (≤ 10 µF) and 0.512 ms (+0.018 ms to the 0.53 ms wait) → fit only with the digital wait AUD_EN/AVCC_EN → ANA_EN raised to ≥ 0.75 ms (with X-8 the I/V hold-up no longer depends on this wait; the rule keeps the order explicit).
* T520 leakage (DCL ≤ 0.1 CV = 139 µA per capacitor at 6.3 V, KEMET series rule [not re-checked]) → ≤ 0.28 mA on the analog branch: Default need 176.27 → ≤ 176.55 mA vs IOS min 180.1 mA (+3.5 mA); analog to confirm in its quiescent. The reservoirs are not charged at attach (U503 off) → attach regions unchanged; in suspend they discharge through the OPA2210, not from USB.
* Not verified: PMEG2010AEH forward characteristic (fit [ASSUMP]), reservoir ESR/leakage in the model (ignored), the reduced c18 corner set (the full 576-corner run did not finish on the shared single-CPU host), LM27762 start current/UVLO (typical only, M9).

### R3.12 Follow-up 2 (09:31): digital r3 message — T_START, S6 wake figures, AUD_EN
* **T_START input (c18 timing run, C514 10 nF, X-8 reservoirs 176/264 µF, I_st 0.10/0.25/0.5/1.0 A per path, Default min/max + High min, 5V_SYS 4.30 V):** ANA_EN → (RAILS_OK_N low = LM27762 PGOOD, both outputs ≥ 95 % [DS Table 6-1, typ] AND 5V_ANA_F ≥ 4.00 V), settled: **≤ 18.6 ms**; with 5V_ANA_F ≥ 4.12 V (reads ≥ 4.00 V at every ADC/divider corner, R3.5): **≤ 18.8 ms** (Default min limit is the slowest; High min 8.2–15.5 ms). Digital's rule max(20 ms, 1.25 × 18.8 ms) = **23.5 ms**; power recommendation **T_START ≥ 40 ms** (the model is behavioural, the LM27762 start current/UVLO are typical-only and only the reduced corner set ran); the 60 ms placeholder is also safe. C514 stays 10 nF (the ≥ 40 ms ramp is not adopted, R3.11), so the 20 ms rule alone would be too tight (1.2 ms margin) — T_START replaces it.
* **S6 suspend (c17), both wake figures:** binding ≤ 30 ms wake (0.189 mA [digital bound]): **3.673 / 3.579 mA** (A-to-C / C-to-C) with the 1 mA protection placeholder, **2.683 / 2.589 mA** with a nanopower U605 (≤ 10 µA); digital's suspend-only IWDG proposal (+0.0034 mA, needs the orchestrator because it changes the ≤ 30 ms rule): **3.488 / 3.393 mA** and **2.498 / 2.403 mA** (margin +0.002 / +0.097 mA). All figures keep the 1.9 mA MCU Stop placeholder (L-1); PA8 is HIGH in suspend → R240 0 (already so in c17).
* **AUD_EN (X-10) agreed:** 2.24 V nominal at PC10 = 3.3 V (digital) = my 2.245 V nominal; worst case ≥ 2.18 V (1 % resistors, VOH ≥ 3V3M min − 20 mV); PC10 sources ≤ 0.23 mA while AUD_EN is high (c17 counts 0.230 mA).

### R3.13 Follow-up 3 (09:35): orchestrator DX-2…DX-4 (binding) — C514 470 nF, T_START, budget with the final protection loads, S6 **[R509 4.81 k, budget and S6 superseded (R3.14/R3.17 → R9 E-16/E-18)]**
* **[superseded → R3.F / DY-2: C514 reverted to 10 nF, T_START 40 ms]** **C514 = 470 nF 25 V X7R 0603 (DX-4, binding):** U503/5V_ANA_F ramp 0→5.5 V in **41.9–78.0 ms** (IdVdt/GdVdt limits, C −10 %/−5 %/−5 % … +10 %/+5 % [ASSUMP X7R 0–60 °C, ageing]) → ≥ 40 ms at every corner. Supersedes "C514 stays 10 nF" in R3.0/R3.1/R3.11/R3.12.
* **Evidence stated plainly (c18, same reduced corner set for both values):** the peak start current, the time at the U503 limit and the U503 energy do **not** change with C514 (16.8 ms at the limit, ≤ 919 UVLO trips, ≤ 4.7 mJ for 470 nF vs 16.8 ms, ≤ 919, ≤ 4.5 mJ for 10 nF), because the LM27762 (EN = VIN, X-1) leaves UVLO at ≈ 2.6 V with its outputs and the reservoirs at 0 V and ≈ 60 % of the reservoir charge is delivered at the U503 limit whatever the ramp. What the slow ramp changes: the analog branch draws ≤ quiescent + ≈ 69 mA instead of the U503 limit in the tracking phase, and the start takes ×5.7 longer. Orchestrator: with this evidence DX-4 can be reverted to 10 nF (T_START 23.5 ms) — BOM value only, same land; this BOM follows DX-4.
* **Time ANA_EN → rails good for digital (DX-3):** with 470 nF, ANA_EN → (RAILS_OK_N low AND 5V_ANA_F ≥ 4.00 V) ≤ **105.0 ms**; with 5V_ANA_F ≥ 4.12 V (reads ≥ 4.00 V at every ADC/divider corner) ≤ **106.7 ms**; PGOOD ≤ 101.2 ms, I/V rails ≥ 95 % ≤ 100.7 ms (the ramp dominates; includes a 48 ms turn-on-delay bound [ASSUMP, DS 7.7 typ scaled with C, ×2]). → **RAILS_OK_N / ANA_SENSE validity wait T_START = 1.25 × 106.7 ms = 133 ms; the 60 ms placeholder is too short with 470 nF** (it would false-trip the overload rule at every start). With 10 nF it would be 18.8 ms → 23.5 ms.
* **Attach / start current with the reservoirs:** attach unchanged (the reservoirs sit behind U503, off at attach: region A 28.5 µC, region B 40.2 / 37.0 µC, R3.2). Start: the analog branch never exceeds the U503 limit (Default ≤ 220.0 mA with R509 4.81 k; 390 mA peak only in the High-min corner) → USB ≤ 269.32 + 220.0 + 0.44 = 489.8 mA (the S3 bound) **[superseded (R9 E-18): ≤ 222.6 mA with 4.75 k; S3 bound 493.46 mA (R10 F-1)]**.
* **Budget with the final protection loads (protection R3.7) and DX-2 (c17):** protection 3V3M 74.2 µA (7.6 µA with 3V3A off), 3V3A 5.7 µA, 3V3D 3.36 mA (U607 at 80 MHz), block 6 +0.416/+0.400 mA on VPOS/VNEG; analog C442/C443 now KEMET T495D227K010ATE100 (MnO2, 198–242 µF, DCL ≤ 22 µA at 25 °C, ×3 at 50 °C [ASSUMP]) — replaces the 1 mA / 0.3 mA placeholders and the T520 note of R3.11. Non-analog 269.32 mA; Default need 176.62 mA (+1.02 mA analog-branch additions, analog to confirm). **[superseded (R9 E-18): R509 4.75 k]** **No E96 R509 meets "total ≤ 490 mA AND IOS min ≥ need" → R509 = 4.81 kΩ (E192, 0.1 %, 25 ppm; Panasonic ERA-3AEB4811V / Vishay TNPW06034K81BEEA, availability to be confirmed by parts)**: IOS 177.9 / 198.9 / 220.0 mA, Default total **489.78 mA** (≤ 490 by 0.22 mA, ≤ 500 by 10.22 mA), need +1.3 mA, below the 180 mA target (the budget does not allow it). **R510 = 3.74 kΩ** (largest E96 with High IOS min ≥ 390 mA): High 393.3 / 440.4 / 487.1 mA. States: S1 82.40, S2 340.99, S3 489.78, S3f 356.32, S4 757.09, S5 349.09 mA.
* **S6 suspend with the DX-2 wake (3.4 µA):** **2.4954 mA (legacy A-to-C) / 2.4010 mA (C-to-C) → margin +4.6 µA / +99 µA** (digital's 2.59–2.68 mA used the superseded 0.189 mA wake: 2.681 / 2.587 mA). The A-to-C margin rests on the 1.9 mA MCU Stop + USB-PHY placeholder (typ 0.11 mA; L-1): it may rise to 1.9046 mA before the limit is reached. Production test measures every board.
* **C440 / C441 (analog question 3):** C440 confirmed — 3V3A effective ≤ 8.04 µF (mine) / 8.54 µF (analog) ≤ the LP5907 10 µF effective limit (the 10.1 µF no-credit count is not the criterion). **C441 may be fitted** only if (a) the effective total stays ≤ 10 µF (9.03 µF mine / ≈ 9.4 µF with analog's credit; it relies on the DC-bias credit — 11.1 µF without), confirmed by a bring-up 3V3A load-step check, and (b) digital raises the AUD_EN/AVCC_EN → ANA_EN wait to ≥ 0.75 ms (3V3A < 0.1 V in 0.512 ms with C441).

### R3.14 Follow-up 4 (09:42): digital currents round 3 — R509 re-balanced **[R509 4.84 k, budget and S6 superseded (R3.17 → R9 E-16/E-18)]**
* New digital figures (digital `currents_output.txt` round 3): U208 on 3V3D **2.52 mA** at 384 kHz (4 µA + (14 + 6 pF) × 3.333 V × (36 + 18 MHz) × 70 % burst; 0.37 mA at 44.1 kHz) replaces 1.67 mA; **R238/R239** JTAG 10 k against the unpublished AGRV2K internal pulls ≤ **0.167 mA** on 3V3D [digital ASSUMP, typ 0]; suspend IWDG wake **4.5 µA** (DX-2: 0.67–1.60 s timeout, wake 0.50–1.20 s) replaces 3.4 µA. Unchanged: R240 0.034 mA (PA8 low, S2–S4), R233 −0.032 mA; R237/R508 and R305-through-Q207 stay in the power lines.
* c17 re-run: non-analog **270.34 mA** (+1.02 mA); need 176.62 mA. 4.81 k now gives 490.80 mA (> 490) → **[superseded (R9 E-18): R509 4.75 k]** **R509 = 4.84 kΩ (E192, 0.1 %, 25 ppm; Panasonic ERA-3AEB4841V / Vishay TNPW06034K84BEEA, availability to be confirmed by parts)**: IOS **176.9 / 197.8 / 218.7 mA**, Default total **489.51 mA** (≤ 490 by 0.49 mA, ≤ 500 by 10.49 mA), IOS min − need **+0.27 mA**; **R510 3.74 k** kept: High 392.3 / 439.2 / 485.8 mA (≥ 390 mA). States: S1 82.40, S2 342.01, S3 489.51, S3f 357.34, S4 756.82, S5 350.11 mA.
* **S6: 2.4965 mA (legacy A-to-C) / 2.4021 mA (C-to-C) → margin +3.5 µA / +97.9 µA** (the MCU Stop placeholder may rise to 1.9035 mA). T_START unchanged (R3.13).
* **Plain statement:** the Default mode is now at its limit on both sides — +0.49 mA to the 490 mA rule and +0.27 mA to the analog need (the need includes my ×3-at-50 °C bound on the C442/C443 DCL, 0.13 mA [ASSUMP]). Any further non-analog increase forces a choice between the 10 mA USB reserve (rule) and the Default 32 Ω target (IOS min ≥ need) — owner/orchestrator decision; the placeholders behind the budget (MCU 80 mA, CPLD 40 mA, U208 at 70 % burst) are replaced only by measurement (L-1, production test).

### R3.15 Follow-up 5 (09:43): protection round-3 message
* Protection loads (3V3M +74.2 µA running / +7.6 µA with 3V3A off and in suspend; 3V3D +3.36 mA U607 + pump, X201 +0.35 mA inside its 8.0 mA; 3V3A +5.7 µA; block 6 I+ ≤ 1.660 / I− ≤ 1.631 mA) are exactly the c17 inputs of R3.13/R3.14 → no change: S3 489.51 mA with R509 4.84 k, S6 2.4965 / 2.4021 mA **[superseded (R9 E-16/E-18): S3 493.46 mA (R10 F-1) with 4.75 k, S6 2.2755 / 2.1815 mA]** (+3.5 / +97.9 µA; the "31 → 23.4 µA" in the message is the round-2 basis, superseded).
* Transient X-6 currents (not steady budget items): Q619 0.338 mA via R236 while AVCC_EN is high and 3V3A is not yet good (≤ the 3V3A ramp); Q620 0.72 mA via R237 only if PC10 is high while 3V3A is not good (firmware order or a 3V3A fault) — both from 3V3M, inside the S2–S5 margins.
* Power facts for the analog I²C-fail fallback conflict (analog owns the pop figure): with AVCC_EN low first, U605B/Q620 force AUD_EN low ≤ 1.04 ms after 3V3A < 3.006–3.125 V → Q504 off → Q505/Q506 discharge 3V3D (< 0.1 V ≤ 0.63 ms, c06) and 1V3 (U303 EN = 3V3D → off at its UVLO, then Q506) → DVDD ≤ DVCC holds (c14 ≤ +5 mV). The power sequences of R3.1 lower AUD_EN and AVCC_EN in one write, so the override adds nothing there.

### R3.16 Follow-up 6 (09:44): DX-4 R501 fallback coupling (protection R3.16)
* **Rule recorded in the BOM (R501 note):** the DX-4 fallback R501 221 k → 232 k (VPOS 3.789/3.852/3.915 V → **3.919/3.984/4.049 V**) may be fitted **only together with protection R672 237 k → 243 k** (U606 1V3-good release maximum 1.262 V: 21 mV to the 1V3 minimum with 237 k, 43 mV with 243 k), and protection p03/p04/p06/p10 must be re-run before release (protection `p13_r501_fallback_check_out.txt`).
* Power-side check of the fallback: LM27762 positive-LDO headroom at VBUS 4.40 V in High mode 5V_ANA_F ≥ 4.223 V (4.208 V with the J101 contact drop) − VPOS max 4.049 V = **0.17 / 0.16 V** vs the 45 mV typical dropout at 100 mA (no maximum published → typical-only, as M2); Default mode more. VPOS stays ≤ the LM27762 5 V output limit; the X-8 reservoirs (T495, 10 V) and the op-amp supply ranges are unaffected; start/unplug conclusions unchanged (reservoir charge +3.6 %; the 470 nF T_START is ramp-dominated). No power part changes with it.

### R3.17 Follow-up 7 (09:45): analog budget update — D-5 rule conflict (orchestrator decision), O15 **[R509 4.81 k, need and states superseded (R9 E-18)]**
* Analog final (R3.12): 5V_ANA quiescent **71.56 mA** (was 70.32; block 6 1.660/1.631 mA incl. U606, T495 leakage bound 0.22 mA per rail), DAC in reset **86.29 mA** (was 85.01), Default need **176.9 mA** + ANA_SENSE 0.057 mA = **176.957 mA** **[superseded (R9/R10): 178.96 mA (R10 F-1)]**. c17 now uses these instead of my separate block-6/DCL additions; C442/C443 = KEMET T495D227K010ATE100 (MnO2, 220 µF ±10 %, 10 V, ESR 100 mΩ, same 7343-31 land; start charge ≤ 1.03/1.00 mC unchanged — c18 used 176–264 µF, which covers 198–242 µF).
* **D-5 rule conflict (no hardware answer inside the rule):** with non-analog 270.34 mA no R509 meets both "Default total ≤ 490 mA" and "IOS min ≥ need". ~~**R509 = 4.81 kΩ (E192) is fitted**~~ **[superseded (R9 E-18): 4.75 kΩ fitted]** (analog request): IOS 177.9/198.9/220.0 mA, need **+0.97 mA**, Default total **490.80 mA** → the 490 mA reserve rule is exceeded by **0.80 mA**; the USB 500 mA limit is met by **9.20 mA**. Alternative 4.84 kΩ: 489.51 mA (rule met) but IOS min 176.9 mA = need −0.07 mA (Default 32 Ω ≈ 37.9–38.0 mW). **Orchestrator decision needed** (reserve 9.2 mA vs 10 mA, or the Default 32 Ω target); BOM value only, same land. R510 3.74 k: High 393.3/440.4/487.1 mA. **[superseded (R9 E-16/E-18) → R10 table]** States: S1 82.40, S2 342.28, S3 490.80, S3f 357.62, S4 758.11, S5 350.43 mA; S6 unchanged (2.4965 / 2.4021 mA, +3.5 / +97.9 µA).
* **O15 (VPOS ≥ −0.2 V and VNEG ≤ +0.2 V while the LM27762 is off or starting): NOT confirmed.** The LM27762 datasheet guarantees only the 50 kΩ output pull-downs in shutdown and gives no limit for OUT+ below GND / OUT− above GND; my models (c14, c18) clamp both rails at 0 V, so they cannot show it. Physically an excursion arises when the rail-to-rail loads (OPA1622, U606, dividers) outlast one rail (the rail-to-GND loads are unequal, e.g. the DC-sense networks load only VNEG). Two facts for analog: (i) **D411/D412 block such an excursion from the reservoirs** — VPOS < 0 reverse-biases D411 (anode VPOS), VNEG > 0 reverse-biases D412 (cathode VNEG) — so C442/C443 are not reverse-biased by "VF + excursion"; their polarity can only be reversed through the OPA2210 supply pins when one I/V rail is exhausted before the other (analog's domain). (ii) If a guarantee is wanted, the direct fix is a reverse clamp across each reservoir (Schottky GND → N4_VPOS_IV and N4_VNEG_IV → GND) and, for the LM27762 pins, GND → VPOS and VNEG → GND; a BAT54-class clamp gives ≤ 0.32 V at 1 mA / 0.40 V at 10 mA with ≤ 2 µA leakage [Nexperia DS]; a PMEG2005AEL-class clamp gives ≤ 0.19 V at 10 mA but 0.6 mA leakage (would break the Default need). Not added in this round (needs the analog current in the excursion; decision with analog).

## R8 follow-up (round 2) — 25 Sep 2026

**History (round 2).** Every budget, IOS, need, margin, state, S6, 5V_SYS-minimum and brown-out figure in this section is superseded (R9 E-16/E-18) → R10 table (R509 was 4.75 k in round 2 as in the final design, but on the round-2 loads: Default total 487.12 mA).

Binding inputs: `integration/decisions_r8b.md` D-1…D-18 and its load table; brief §4/§5. Round-2 scripts: `calc/c02`–`c06`, `c08`–`c14`, `gen_bom_netlist.py` (each `.py` with `.out.txt`; `c03_results.json`, `c04_results.json`, `c14_results.json` pass numbers between scripts). Round-1 sections below stay valid unless marked **[superseded → R2.x]**. Labels as in §5 of the brief.

### R2.0 What changed (every change) and the new headline numbers

| # | Change | Why / evidence |
|---|---|---|
| C1 | **U503 TPS2553 → TI TPS259621DDAR** (HSOIC-8 PowerPAD, auto-retry, C2155774); EN/UVLO = ANA_EN (R513 kept), FLT → ANA_FAULT_N (R512 kept), **OVCSEL (pin 8) open**, **C514 10 nF dVdt**, pad to GND | D-5; c11 |
| C2 | **Q501 2N7002 → U505 TI TMUX1101DBVR** (C1852057) switching R510; VDD 3V3M with **C515 100 nF**; SEL = ILIM_HI (PA15, R511) | D-5; off-leakage 0.2 nA vs a 5 µA MOSFET bound (5.1 % of the limit) — c03 §4 |
| C3 | **R509 196 k → 4.75 kΩ** (Susumu RG1608P-4751-B-T5, global sourcing), **R510 84.5 k → 3.83 kΩ** (C861384), both 0.1 % 25 ppm 0603 | D-5 rule with the Kyocera X201, c03 §3–4 (4.64 k only with the non-procurable Epson) |
| C4 | **U303 ME6216A13 → TI TLV75801PDBVR** (C2877852) + **R533 15.0 k / R534 11.0 k** 0.1 % (C326733, C728581); **EN = AUD_EN** | D-7; c12 |
| C5 | **Q506/R530 kept** (TLV758P internal discharge is 95 Ω *typical*, too slow and unguaranteed) | c06, c12 §5 |
| C6 | **J101 → GCT USB4105-GF-A** (C3020560), netlist pins = GCT drawing pad labels (12 SMT + 4 shell stakes) | D-8; c13 §1 |
| C7 | **U103 TPD2E2U06DRLR** (C1972959) on CC1/CC2 at J101 | D-8; c13 §2 |
| C8 | **R532 470 kΩ** PB4 pin-side pull-down (C25790) | D-8; c13 §3 |
| C9 | **C301/C302 1 µF → 2.2 µF 16 V 0603** (C23630) | D-8, parts P-M2 |
| C10 | **C503 deleted** (TLV767 input): C501 serves U502 and U504 (both IN pins ≤ 3 mm from C501) | compensates C9 in the attach charge: 45.5 µC (9 %) → 39.5 µC (21 %) — c02 |
| C11 | Budget: photorelay drive recomputed by protection r2 (op-amp sink U604 OPA2333): 13.20 mA on 5V_SYS + 0.10 mA on 3V3M + 0.32 mA on 3V3D with RELAY_EN high, U604 56 µA on 3V3D whenever it is up (replaces 14.3 + 1.02 mA, D-1 'unless recomputed'); R234, R233, 3V3A networks 1.82 mA, TLV1704, new DC-sense V− load; relay coil removed | decisions load table; protection r2 message (06:13); c03 |
| C12 | DOM_DIS retired (confirmed; the round-1 design never used it), RAIL_EN kept, C103 kept (recommendation R2.7) **[superseded → R3.0: RAIL_EN/R506/R507 deleted (X-1), C103 = 100 pF C0G (X-10)]** | D-11, D-13 |
| C13 | **X201 = Kyocera KC2520K80.0000C1GE00 (80 MHz): budget 8.2 mA incl. R227** instead of the Epson 6.5 mA (EOL); conditional second source NDK NSC5338D-80M (12.7 mA → ~~R509 4.87 k~~ **[superseded (R9 E-27): the NDK needs no R509 change; R509 stays 4.75 k; S3 497.96 mA with the NDK (R10 F-1)]**); TXC withdrawn; SCTF not approved | **D-3 revised (binding, 25 Sep 2026)**; parts Follow-up 3 |
| C14 | **D-19:** R235 100 k on N2_MCLK_OE (U206 output) counted on 3V3D (0.034 mA while MCLK runs); R645/Q616 and the PB1 readback add no other load | D-19 (binding) |
| C15 | **Analog round 2 final:** 5V_ANA quiescent **70.32 mA** (**85.01 mA** with the DAC in reset) [analog r2 report R2.4; the orchestrator note quoted 70.30 / 84.85 mA — the budget uses the larger analog-report values, +0.02 / +0.16 mA], Default need IOS min ≥ 175.6 mA, High peak need **317 mA** (was 357 mA), VCCA 2.9 mA at 80 MHz (+2.1 mA on 3V3A); High-mode headroom → RAILS_OK_N headroom-dip rule (< 25 ms = no fault, protection R2.13a), no VBUS volume ceiling; brown-out: RELAY_EN + AVCC_EN in one interrupt | orchestrator 25 Sep 2026 06:01 (binding); analog r2 message |
| C16 | **§5.5 LM27762 envelopes reissued with the TPS2596 path** and the analog R_NEG limits recomputed with the new VIN (c15): VIN 4.300 / 4.219 V (Default / High, VBUS 4.40 V), 4.500 / 4.419 V (4.60 V); High 32 / 60 Ω regulation limit 2.49 / 2.37 Ω (analog r2 had 2.38 / 2.26 Ω with the round-1 VIN), Default 32 Ω 3.43 Ω (was 3.51 Ω) | analog r2 request; c15 (new) |
| C17 | 5V_SYS / 5V_ANA one node while U503 is on (answer to analog, R2.13 A-f); BOM descriptions of R527/R529/R530 updated to the round-2 discharge times; RAILS_OK_N rule aligned to protection's 25 ms (my 50 ms [ASSUMP] withdrawn) | c14, c06; protection R2.13a |

| Item | Round 2 value |
|---|---|
| Non-analog maximum (configured, switch closed) | **264.04 mA** [CALC c03] (incl. VCCA 2.9 mA and the protection r2 drive; round-2 draft 266.8 mA) |
| Analog quiescent (5V_ANA) | **70.32 mA** [analog r2 final, 0–50 °C]; **85.01 mA** with the DAC in reset; my cross-check 70.32 mA = I+ 34.50 + 1.03 × I− 33.75 + 1.0 + 0.056 mA [CALC c03 §1]; TPS2596 IQ 0.266 mA extra (IN → GND) |
| **Default IOS (R509 4.75 k)** | **180.1 / 201.3 / 222.6 mA** min/nom/max [DS ±10.4 % + CALC] → Default total **487.12 mA** (≤ 490, +2.88 mA) **[superseded (R9 E-18): 180.05 / 201.3 / 222.6 mA, total 493.46 mA (R10 F-1)]** |
| High IOS (R509 ∥ (R510 3.83 k + U505)) | **390.4 / 437.1 / 483.4 mA** [DS + CALC]; ≥ 390 mA (+0.4) and ≥ the analog r2 High peak need 317 mA (+73.4); High total 748.1 mA |
| Analog Default need (analog r2 final) | **175.6 mA** (32 Ω: 37.6 mW at 175 mA, 41.0 mW at 180 mA) → IOS min 180.1 mA: **+4.5 mA**, and ≥ the 180 mA target by 0.05 mA |
| States | S1 82.4 · S2 334.7 · S3 487.1 · S3f 350.0 · S4 748.1 · S5 342.5 mA · S6 **2.469 / 2.375 mA** **[superseded (R9) → R10 table]** |
| LM27762 envelopes (reissued §5.5, TPS2596 path) | I− max at VBUS 4.40 V: Default 176/131/105 mA, High 148/111/88 mA (R_NEG 2.5/3.5/4.5 Ω); 4.60 V: 244/182/145, 216/161/129 mA [CALC c15] |
| Attach charge (largest region) | 39.5 µC guaranteed (21 % margin), 36.3 µC with the U102 current-limit credit [CALC c02] **[superseded → R3.2: 40.2 / 37.0 µC; C104 separates the regions]** |
| Discharge to < 0.1 V | 3V3A ≤ 0.39 ms, 3V3D ≤ 0.63 ms, 1V3 ≤ 0.13 ms [CALC c06] |
| Suspend level reached | ≤ 2.79 ms after the last SOF (margin 7.21 ms) [CALC c08] |
| 1V3 | 1.272–1.325 V (TJ ≤ 85 °C) incl. line/load; TJ 82 °C [CALC c12] |
| Hard unplug | 3V3D ≤ 3V3A while MCLK runs (all 288 corners); I/V rails fall first by up to **0.46 ms** (no firmware), **0.26 ms** (brown-out action with C103), 0.08 ms (without C103) [CALC c14] |

### R2.1 Method, inputs, and what could not be verified (round 2)
* Inputs: decisions D-1…D-18; protection §3.4/§6/§12 and p05/p06; analog §9 (set B split, `analog_budget.py`) and §14; digital `firmware_sequences`, `levels_and_pullups`, `mclk_gate_race`, `pin_tables` outputs; parts Follow-up 1–2 and the Follow-up 3 source list (`parts/web/fu3_sources.txt`); TI SLVSET8A (TPS2596), SBVS351D (TLV758P), SCDS410D (TMUX1101), SLLSEG9C (TPD2E2U06), SNVSAF7C (LM27762), GCT USB4105 drawing text layer (Mouser/SnapEDA copies; `gct.co/files/drawings/usb4105.pdf` is blocked for this tool).
* No SPICE: vectorised explicit time-domain models (c11 LM27762 start, 144 corners; c14 unplug, 288 corners), nodal RC (c06), closed-form budgets.
* **Not verified:** LM27762 start-up/soft-start current (not in SNVSAF7C → swept 0.25–1 A, bring-up M9); LM27762 UVLO and PGOOD VOL have no min/max; TPS2596 foldback, tLIM, tD,ON, internal dVdt capacitance and the ±10.4 % headline between table rows are typical/feature-list statements (the rule uses ±10.4 %); TLV758P RPULLDOWN typical only; LP5907 reverse-current behaviour (both variants modelled); CH32V307 reset threshold (1.8/2.3 V assumed), PA1 leakage (1 µA assumed), ADC pin injection limit; JLCPCB classes marked "(not verified)"; LCSC stock of USB4105 (out of stock at LCSC), TPD2E2U06 and TPS259621 live stock; unit prices of the new ICs are indicative. X201: the parts stream reported (Follow-up 3 message, 25 Sep 2026) that the D-3 Epson SG-210STF 75 MHz is not procurable; the orchestrator revised D-3 (binding): X201 = Kyocera KC2520K80, budget 8.2 mA incl. R227; conditional second source NDK NSC5338D-80M (12.7 mA); the lookup (R2.2) covers both. The Kyocera phase jitter is a catalogue value ([MEAS] per D-3).

### R2.2 USB budget and the U503 limits (c03)
**Loads** (maxima; full list with state flags in `c03_usb_budget_ilim.out.txt` §2): 3V3M 83.04 mA (MCU 80 [ASSUMP], LEDs 0.80 + 0.73, EN pull-downs 0.17, discharge inverter pull-ups 0.31, photorelay drive 0.10 [protection r2], R234 0.33, R233 0.032, MCU internal pull-downs 0.57 [ASSUMP], U505 0.0007) → 83.60 mA at 5V_SYS; 3V3D 145.54 mA (CPLD 40 [ASSUMP], X201 Kyocera + R227 8.2 [D-3 rev], R235 0.034 [D-19], U604 drive 0.32 + quiescent 0.056 [protection r2], NDK 15 + 0.035, U205 4.7, U206/pull-downs/I²C 2.9, DVCC 14.2, DVDD 60 [PH], TLV758P IGND 0.035 + divider 0.051, FET leakage 0.01) → 145.96 mA; 3V3A 20.90 mA (AVCC 16, **VCCA 2.9 at 80 MHz [ASSUMP analog r2]**, VREF 0.17, protection 1.82 [D-10]) → 20.95 mA; 5V_SYS direct 13.53 mA (LED strings 13.20 [protection r2], TPS25200 0.19 + 0.002, divider 0.038, USBLC6, legacy Rp 0.094). The PGOOD network (R505/R522/R532) is on 5V_ANA_F, i.e. inside the U503 limit.

**Analog quiescent recompute** (analog set B split, 2 × LM339B replaced) [CALC c03 §1]:

| Term | I+ (mA) | I− (mA) |
|---|---|---|
| OPA1622 4 ch × 4.2 mA / OPA2210 4 ch × 3.25 mA [DS] | 16.80 + 13.00 | 16.80 + 13.00 |
| TLV1704 × 3 incl. dividers and H pull-up [D-9] | 1.26 | 1.25 |
| I/V → leg networks 4 × VREF/2 k / leg-output sink 4 × VREF/4 k [analog] | 3.412 | 1.706 |
| DC-sense networks into the legs, 4 × **0.2416 mA** [CALC: 3V3A 3.366 V, R_U 5.1 k, R_D 16.9 k, R_S 6.8 k, 0.1 % → node 1.64 V at a 0 V leg] | — | 0.966 |
| CM summing 2 × 14 µA (zero at silence) [protection] | 0.028 | 0.028 |
| **Total** | **34.50** | **33.75** |

5V_ANA = 34.50 + 1.03 × 33.75 + LM27762 1.0 [ASSUMP] + PGOOD 0.056 = 70.32 mA (round 1: 72.92 mA) — equal to the **analog round-2 final 70.32 mA** (85.01 mA with the DAC in reset, analog report R2.4; the orchestrator note quoted 70.30 / 84.85 mA, the budget uses the larger values), which the budget uses. My estimate of the Default need with the analog-stream method was 171.6 mA; the **analog final need is 175.6 mA** (used). The decisions' "≈ 0.24 mA per leg" is confirmed (0.232/0.237/0.242 mA at 3V3A min/nom/max).

**TPS2596 guaranteed limit**: ILIM = 903/R_ILM + 11.2 mA [DS Eq.5] × (1 ± 10.4 %) [DS feature list; the 7.5 table rows are −10.3/+10.4 % at 7.87 k and −9.3/+8.9 % at 3.83 k vs Eq.5], R_ILM 0.1 % + 25 ppm × 35 K. Default total = non-analog + IOS max + IQ 0.266 mA + ILM current (GIMON ≤ 800 µA/A × IOS) [DS/ASSUMP].
* **R509 = 4.75 kΩ → Default IOS 180.1 / 201.3 / 222.6 mA; total 487.12 mA** (≤ 490 by 2.88 mA; ≤ 500 by 12.88 mA) **[round-2 loads; superseded (R9 E-18): 180.05 mA, total 493.46 mA (R10 F-1)]**. IOS min ≥ 180 mA (+0.05) and ≥ the **175.6 mA** analog need (**+4.5 mA**). Row interpolation (information only) gives 181.5/220.8 mA. (With the original Epson 6.5 mA the rule would have given 4.64 k: 184.1/205.8/227.6 mA, 489.92 mA.)
* **R510 = 3.83 kΩ** (largest E96 meeting both High minima) → **High IOS 390.4 / 437.1 / 483.4 mA** (≥ 390 mA +0.4; ≥ the analog r2 High peak need **317 mA** +73.4; the round-1 357 mA +33.4); High total 748.1 mA vs 1.5 A (752 mA margin) and U102 IOS min 1011 mA (263 mA). (3.74 k would give ~395 mA min if more High margin is wanted; BOM value only.)
* Above ILIM the device regulates within tLIM 87 µs typ, above 1.5 × ILIM a fast clamp acts within 5 µs typ [DS-typ]; that sub-100 µs excursion is filtered by C506/C507.

**States** [CALC c03 §5] **[round 2 — superseded (R9), see the R10 table]**:

| State | Max (mA) | Limit | Margin |
|---|---|---|---|
| S1 attached, unconfigured (3V3M only, MCU max, LEDs on) | 82.4 | 100 | +17.6 |
| S2 configured idle (all domains, analog quiescent, switch closed) | 334.7 | 500 | +165.3 |
| S3 Default playing, analog at IOS max | 487.1 | 500 (rule 490) | +12.9 (+2.9) |
| **S3f family change** (both NDK running + 2nd enable pull-down, muted → analog quiescent) | **350.0** | 500 | +150.0 |
| S3f′ not allowed: both NDK running while the analog is at its limit | 502.5 | 500 | −2.5 → firmware order rule |
| S4 High (≥ 1.5 A advertisement) | 748.1 | 1500 | +752 |
| **S5 programming mode (D-15)**: rails + 3V3A + 3V3D on, DAC in reset (analog final 85.01 mA), MCLK off (X201 ST low, Kyocera stand-by 5 µA), both NDK counted running (CPLD pull-up case), switch open | **342.5** | source ≥ 350 mA (charger/bench) | — |
| **S6 suspend** | **2.469** (legacy A-to-C Rp) / **2.375** (C-to-C) | 2.5 | +31 / +125 µA **[superseded → R3.6: 3.673 / 3.579 mA on the placeholders]** |

S6 detail [c03 §9]: MCU Stop 1.900 [PH]; D+ pull-up 0.214; TPS7A20 IGND 0.025; TPS25200 0.190 + 0.002; divider 0.038; USBLC6 0.001; TLV767 ISHDN 0.003; LP5907 0.001; **TPS2596 ISD 1.13 µA** [DS VIN ≥ 4 V, EN < VSD]; **TMUX1101 IDD 0.65 µA + SEL 0.05 µA** [DS]; **TPD2E2U06 2 × 10 nA** (CC ≤ 2.5 V) [DS]; **TLV758P 0** (its input 3V3D is off; ISHDN 1 µA [DS] would apply only with VIN present); **R532 0** (5V_ANA_F = 0 → PGOOD network at 0 V); discharge FETs/pull-ups 0; legacy Rp 0.094. MCU Stop may be ≤ 1.931 mA.

**Integration lookup** (best E96 R509 for a given non-analog total, guaranteed ±10.4 %) [c03 §6] **[superseded (R9 E-18/E-27): history only — R509 is fixed at 4.75 k owner-fitted; the NDK needs no change]**:

| Non-analog total (mA) | R509 | Default IOS min / nom / max (mA) | R510 for High min ≥ 390 mA (High min) |
|---|---|---|---|
| ≤ 251.2 | 4.42 k | 192.7 / 215.5 / 238.3 | 4.02 k (393.2) |
| ≤ 256.7 | 4.53 k | 188.3 / 210.5 / 232.8 | 3.92 k (393.8) |
| ≤ 261.9 (original Epson case: 261.85) | 4.64 k | 184.1 / 205.8 / 227.6 | 3.83 k (394.4) |
| **≤ 266.9 (now 264.04)** | **4.75 k** | **180.1 / 201.3 / 222.6** | **3.83 k (390.4)** |
| ≤ 272.1 | 4.87 k | 175.9 / 196.6 / 217.5 | 3.74 k (391.2) |
| ≤ 277.0 | 4.99 k | 171.9 / 192.2 / 212.5 | 3.65 k (392.6) |
| ≤ 281.8 | 5.11 k | 168.1 / 187.9 / 207.8 | 3.57 k (393.7) |

Read the other way: a required IOS min X needs the non-analog total ≤ the row's limit (e.g. 188 mA → ≤ 256.7 mA). Sensitivities [c03 §7]: X201 = the original Epson figure (6.5 mA, EOL) → 4.64 k (184.1 mA); ~~X201 = NDK NSC5338D-80M conditional second source (12.7 mA, D-3 rev) → 4.87 k (175.9 mA: +0.3 mA over the 175.6 mA need, below 180 mA)~~ **[superseded (R9 E-27): the NDK needs no R509 change; R509 stays 4.75 k; S3 497.96 mA with the NDK (R10 F-1)]**; TXC 7X withdrawn (D-3 rev); SCTF SX3M80 (not approved) or SCTF family oscillators → ≤ 160.7 mA (Default targets not met, D-3/D-4 non-compliant); −10 mA of MCU, CPLD or DVDD assumption → 4.53 k (188.3 mA). The rule is met by 2.88 mA; ~~+2.88 mA of non-analog load moves R509 to 4.87 k (175.9 mA, +0.3 mA over the need; BOM value only, same 0603 land)~~ **[superseded (R9 E-18/E-27): R509 is fixed at 4.75 k; 4.87 k gives 175.9 mA < the 178.96 mA need (R10 F-1)]**; beyond +8.1 mA (4.99 k, 171.9 mA) the Default targets are no longer met.

### R2.3 U503 TPS259621DDAR + U505 TMUX1101 (c11)

| U503 pin | Function | Net / part | Notes |
|---|---|---|---|
| 1 | GND | GND | |
| 2 | dVdt | N5_DVDT → **C514 10 nF 50 V X7R** → GND | SR 3.06–5.57 V/ms (typ 4.0) [DS IdVdt, GdVdt + CALC]; inrush ≤ 67 mA into C506 + C507 (129 mA with C513) < IOS min 180 mA; settled ≤ 3.0 ms after ANA_EN (RAIL_EN ≥ 5 ms, margin 2.0 ms) |
| 3 | EN/UVLO | ANA_EN, R513 100 k pull-down | on > 1.18–1.22 V, off < 1.08–1.13 V, lowest ISD/fault reset < VSD 0.53–1.05 V [DS]; MCU 0/3.3 V; EN abs 7 V |
| 4 | IN | 5V_SYS, C505 100 nF at the pin | UVP 2.46–2.58 V rising / 2.36–2.46 V falling [DS] |
| 5 | OUT | 5V_ANA, C506 1 µF; FB501 → 5V_ANA_F (C507 10 µF) | |
| 6 | FLT | ANA_FAULT_N, R512 100 k to 3V3M | open drain, leakage ≤ 1 µA → VOH ≥ 3.15 V [DS] |
| 7 | ILM | N5_ILIM: R509 4.75 k to GND; R510 3.83 k → N5_ILIM_HI → U505 D; U505 S → GND | ILM ≈ 0.6 V at the limit; keep the node short |
| 8 | OVCSEL | **no connection** (13.8 V option) | see below |
| EP | thermal pad | GND, 9 vias | θJA 52.7 °C/W soldered (119.8 unsoldered) [DS] |

* **OVCSEL open — coexistence with U102:** U102 clamps 5V_SYS at 5.25–5.55 V for any VBUS < 6.8 V [DS]; the open option's threshold is 12.97–14.52 V [DS] → never engaged (≥ 7.42 V margin) and the ROC note "VIN limited to the selected clamp option" is met. The 400 kΩ (5.7 V) option would clamp at 5.54–5.83 V → only 40 mV above the in-spec 5.50 V and overlapping U102's band by 10 mV (two linear clamps in cascade for an out-of-spec source) and it would guard only the analog branch against a U102 short (a double fault). U102 remains the single OV element (round-1 D1); no part added.
* **FLT semantics changed:** FLT asserts only for thermal shutdown and an ILM short, **not** for current limiting or short-circuit limiting [DS Table 3] (the TPS2553 flagged over-current after 5–10 ms). Overload is seen through RAILS_OK_N; a dead short **on** 5V_ANA/5V_ANA_F collapses the PGOOD pull-up so RAILS_OK_N reads "good" while DC_PERMIT_N reads "not permitted" → **new firmware supply-fault rule** (R2.13 D-a).
* **Music peaks:** above ILIM the device regulates (no trip, no FLT); worst FET dissipation while limiting with 5V_ANA sagged to 3.9 V: 0.36 W (Default) / 0.78 W (High) → TJ ≤ 79 / 101 °C (TSD 157 °C typ) [CALC]; C506 + C507 bridge ~80 µs of a 60 mA excess; longer peaks sag 5V_ANA_F → soft clipping, PGOOD "not good" → overload policy.
* **Short:** fast clamp above 1.5 × ILIM (tSC 5 µs typ), then regulation with foldback (typ 0.8–1.0 × ILIM at our levels, Fig. 22/23 — no credit taken). Default: 5.55 V × 222.6 mA = 1.24 W → TJ ≈ 125 °C at 60 °C local — below TSD, so U503 sits in current limit without FLT until firmware removes ANA_EN (fault-only; at the 125 °C ROC limit). High: 2.68 W → thermal shutdown, FLT low, cool 11.5 °C + 95 ms, auto-retry [DS].
* **[superseded → R3.1: EN = VIN, start during the dVdt ramp, rails good ≤ 4.35 ms after ANA_EN]** **LM27762 start into the limit** (time-domain model, 144 corners; LM27762 start current unknown → 0.25/0.5/1 A): rails good (both ≥ 95 %) within **≤ 2.19 ms** of RAIL_EN in every corner; with the Default limit 5V_ANA_F dips to 2.33–2.40 V and the LM27762 may pass through UVLO cycles (≤ 133 in the model) — a current-limited self-soft-start; U503 energy ≤ 1.12 mJ; no FLT. Keep "RAILS_OK_N valid ≥ 20 ms after RAIL_EN"; measure (M9).
* **Stability:** switch on = passive network (c05: 1.59 Ω peak at 39.5 kHz, Q ≈ 3.3, set by the cable; R531/C513 DNF kept); the dVdt ramp is a ms-scale loop, TI uses 1–100 µF (C506 1 µF + C507 10 µF inside), FB501/C507 resonates ≥ 48 kHz; in current limit the device is a current source (no voltage loop); OV-clamp loop never active.
* **Thermal:** 8.0 mW (Default) / 32.1 mW (High) → TJ 60.4 / 61.7 °C.
* **U505:** pins 1 D → N5_ILIM_HI, 2 S → GND, 3 GND, 4 SEL → ILIM_HI (R511 100 k), 5 VDD → 3V3M + C515 100 nF [DS SCDS410D]; SEL VIH 1.35 / VIL 0.8 V at VDD 3.3 V; PA15 is plain GPIO at reset (digital D6) → Default through reset; switched current ≤ 0.21 mA, VS/VD ≤ 0.7 V ≤ VDD; Ron ≤ 9.5 Ω included; off-leakage ≤ 0.2 nA → 2 ppm of the Default limit.

### R2.4 U303 TLV75801PDBVR (c12)
* Pins [DS Fig. 4-2]: 1 IN = 3V3D (C311 1 µF), 2 GND, 3 EN = **AUD_EN**, 4 FB = N3_1V3_FB, 5 OUT = 1V3 (C312 1 µF + DAC C310/C309); R533 15.0 k OUT→FB, R534 11.0 k FB→GND.
* VOUT: **1.2716–1.3248 V** at TJ ≤ 85 °C (VFB ±1 %, ratio ±0.22 %, IFB × R1 1.5 mV, line 7.5 mV max, load 2 × typ) and 1.2651–1.3314 V at TJ ≤ 125 °C, vs ESS 1.235–1.365 V (margins ≥ 37/40 mV; D-7's 1.283–1.317 V excludes line/load). Pd 122 mW → TJ 81.6 °C. Headroom ≥ 1.94 V vs VDO ≤ 400 mV at 500 mA [DS]; ICL ≥ 530 mA.
* **DVDD ≤ DVCC:** ramp-up — the LDO cannot put OUT above IN → DVDD ≤ DVCC + 6.4 mV (FB301 drop); controlled ramp-down — both LDOs off at AUD_EN low, Q506/R530 take 1V3 < 0.1 V in ≤ 0.13 ms, before 3V3D (≤ 0.63 ms): max(1V3 − 3V3D) ≤ +1.2 mV at 143 mA 3V3D load [c06]; hard unplug ≤ +5 mV [c14].
* **Internal discharge:** RPULLDOWN 95 Ω **typical** at VIN 6 V, no min/max, active when disabled or in UVLO → τ ≈ 345 µs with 3.63 µF → 1V3 < 0.1 V after ~0.89 ms typ, slower than 3V3D (≤ 0.63 ms); without Q506 the model gives 1V3 − 3V3D up to +0.6 V (body-diode clamp) → **Q506/R530 stay**; EN = AUD_EN means no regulator-vs-discharge fight (R530 sees only the 0.28 A capacitor pulse).

### R2.5 J101 GCT USB4105-GF-A and U103 (c13)
The GCT drawing names pads by contact (no numbers). Pad row, left to right as viewed from the component side: **A1/B12** GND · **A4/B9** VBUS · **B8** SBU2 → NC · **A5** CC1 · **B7** D− (Dn2) → USB_DN · **A6** D+ (Dp1) → USB_DP · **A7** D− (Dn1) → USB_DN · **B6** D+ (Dp2) → USB_DP · **A8** SBU1 → NC · **B5** CC2 · **B4/A9** VBUS · **B1/A12** GND; 4 wide pads 0.60 mm (the combined ones), 8 narrow 0.30 mm; 4 plated shell stakes "SHELL GND" (netlist S1–S4 → N1_SHIELD, R107 0 Ω); 2 NPTH ⌀0.65 plastic pegs (no net). The drawing text was readable through the Mouser/SnapEDA copies (Oct 2019 / rev B 2021); the gct.co original is blocked here. Ratings: 48 V DC per the GCT page (the drawing copies still say 20 V), VBUS 5 A, GND 6.25 A, others 0.25 A, 40 mΩ max initial, peak 255 °C (−0/+5) ≤ 5 s → Standard PCBA 240 ± 5 °C (D-14). R8-A10 sample continuity check stays.

U103 TPD2E2U06DRLR: pins 1 NC, 2 NC, 3 IO1 = CC1, 4 GND, 5 IO2 = CC2 [DS]. At a CC short to 5.55 V (0.05 V above VRWM 5.5 V, 0.95 V below VBR min 6.5 V): no breakdown, leakage ≤ **12.6 µA** (bound by interpolating the two guaranteed points; only < 10 µA at 5.5 V is guaranteed), 70 µW. Effect on the CC ADC readings: normal operation (CC ≤ 2.5 V) ≤ 10 nA × 5.1 kΩ = **51 µV** (< 0.1 LSB); during the short the node is forced by the short, the reading saturates at full scale (> vRd-3.0) → firmware treats CC > 2.3 V as invalid (Default, no High); R101/R102 6.0 mW; ADC pin clamp current ≤ 0.19 mA through R103/R104 (injection limit and cross-channel effect on ADC2: digital to confirm). CL ≤ 1.9 pF.

### R2.6 R532 / PB4, C301/C302 and the attach charge (c13, c02)
* R532 470 k with R505 100 k (to 5V_ANA_F) and R522 10 k, digital FT data (VIH ≥ 1.756 V, VIL ≤ 0.934 V, leakage ≤ 3 µA, VIH max 5.0 V, abs 5.5 V): **PGOOD released** → PB4 3.12–4.78 V at 5V_ANA_F 4.20–5.55 V (margins +1.37 V to VIH, +0.22 V to 5.0 V), still "not good" down to 5V_ANA_F 2.50 V; **PGOOD low** → PB4 = VOL(PGOOD) + 29 mV (needs VOL ≤ 0.905 V at 56 µA; LM27762 PGOOD VOL is unspecified [not verified], typically < 50 mV). 5V_ANA off reads "good" as before → firmware validity rule (R8-C4).
* C301/C302 2.2 µF 16 V 0603: LP5907 CIN ≥ 1.04 µF effective at 5.5 V, COUT total 3.84–7.59 µF (0.7…10 µF) [c04]. The extra 1.32 µF on 5V_SYS raised the guaranteed attach region B to 45.5 µC (9 % margin); **deleting C503** restores **39.5 µC (21 %)**; with the guaranteed U102 current-limit credit 36.3 µC (27 %); region A 28.4 µC (43 %). Budget rule: 5V_SYS ≤ 3.3 µF nominal (C501 shared, C301, C505).

### R2.7 Unplug ordering (the lost round-2 item) (c14)
Model: source removed at t = 0 from VBUS 5.00 V, all loads at their c03 values ("idle" S2, Default max, High max), capacitance sets from c02/c04/c06 (effective low … +10 % high, and two mixed stress sets), MCU 84/25 mA, MCU reset at 1.8/2.3 V [ASSUMP], LP5907 reverse through a body diode or its channel; 288 corners; ms from t = 0, min…max:

| | (a) hard unplug, no firmware, Default max | (a) High max | (b) brown-out action at VBUS_SENSE 4.00 V (C103 10 nF), Default max | (b′) same without C103 |
|---|---|---|---|---|
| 5V_SYS < 90 % | 0.011–0.028 | 0.007–0.016 | 0.011–0.028 | 0.011–0.028 |
| VPOS / VNEG < 90 % | 0.08–0.19 / 0.11–0.26 | 0.04–0.09 / 0.05–0.11 | 0.08–0.19 / 0.11–0.26 | 0.08–0.20 / 0.11–0.26 |
| 3V3D < 90 % (< 10 %) | 0.08–0.19 (0.28–0.84) | 0.06–0.16 (0.26–0.79) | 0.08–0.19 (0.28–0.58) | 0.07–0.12 (0.20–0.38) |
| 3V3M < 90 % | 0.08–0.23 | 0.07–0.19 | 0.08–0.23 | 0.10–0.42 |
| 3V3A < 90 % (< 10 %) | 0.09–0.28 (0.25–0.80) | 0.08–0.25 (0.23–0.77) | 0.09–0.28 (0.25–0.49) | 0.07–0.11 (0.15–0.27) |
| 1V3 < 90 % (< 10 %) | 0.17–0.67 (0.20–0.72) | 0.15–0.58 (0.18–0.67) | 0.17–0.34 (0.20–0.37) | 0.07–0.11 (0.09–0.14) |
| firmware acts / MCU resets | — / 0.15–0.64 | — / 0.13–0.59 | 0.22–0.32 / 0.15–0.93 | 0.06–0.09 / 0.22–1.05 |
| MCLK stops | 0.15–0.53 | 0.13–0.43 | 0.15–0.32 | 0.06–0.09 |
| VPOS − VNEG < 4.5 V | 0.27–0.61 | 0.13–0.31 | 0.27–0.63 | 0.27–0.71 |
| 3V3A < 0.3 V | 0.25–0.81 | 0.23–0.77 | 0.25–0.49 | 0.15–0.27 |
| **Window: 3V3A ≥ 0.3 V with rails < 4.5 V** | **−0.10 … +0.35** | **+0.09 … +0.46** | −0.14 … +0.16 (High +0.09 … +0.26) | −0.44 … −0.04 (High −0.10 … +0.08) |

* **Order at a hard unplug:** 5V_SYS falls first (tens of µs); with music load the I/V rails lose regulation next (the LM27762 needs VIN ≳ 3.9 V), then 3V3D ≈ 3V3M ≈ 3V3A leave regulation together when 5V_SYS < ~3.4 V, 1V3 follows 3V3D; the MCU resets at 0.13–0.67 ms and the EN-derived discharges finish 3V3A/3V3D/1V3. At idle the rails outlive 3V3A (window −1.2 … −0.17 ms: compliant).
* **Digital requirement (3V3D ≤ 3V3A + 0.3 V while MCLK can run): met in all 288 corners, both firmware cases** — 3V3D never rises above 3V3A (both track 5V_SYS in dropout, 3V3D carries 143 mA through ≤ 1.4 Ω vs 19 mA through ≤ 1 Ω); at the MCLK stop 3V3D − 3V3A = −0.82 … −0.03 V in (a)/(b) (3V3D then 1.65–2.57 V); in (b′) MCLK stops while both still regulate (3V3D ≥ 3.17 V, difference −0.11 … 0 V). DVDD − DVCC ≤ +5 mV (a).
* **Analog requirement (I/V rails up while 3V3A ≥ 0.3 V): violated at a hard unplug with load** — up to **0.35 ms (Default max) / 0.46 ms (High max)** with no firmware, with 3V3A still at **2.3–3.0 V** when the I/V supply drops below 4.5 V (High); the brown-out action (RELAY_EN + AVCC_EN, analog rule) cuts it to ≤ 0.16 / 0.26 ms, and to ≤ 0 / 0.08 ms without C103. The BAT54S clamps D405–D408 bound the DAC pins in this window (D-17, analog stream).
* **Output switch (D-19):** N2_MCLK_OE also gates Q616, so the switch opens from the "MCLK stops" instants above (+ ≤ 1.01 ms incl. the PhotoMOS toff, protection p05) — at a hard unplug additionally when the LED strings lose 5V_SYS.
* **C103 finding:** with C103 10 nF (τ 0.32 ms) the watchdog acts 0.21–0.34 ms after the source is lost and **too late in 30/96 corners** (MCU resets first); without it (the digital TS = 55.5 cycles already covers the 32 k source) it acts in 0.05–0.12 ms in 96/96. **Recommendation to integration: C103 → 100 pF C0G or DNF** (BOM value only; D-13 names 10 nF, so this BOM keeps 10 nF) plus a 2-sample debounce (c09). **[adopted → R3.0 X-10: C103 = 100 pF C0G; c14 round 3: action before the MCU reset in 96/96 corners]**

### R2.8 LM27762 UVLO facts the protection stream relies on (item 7)
Confirmed with caveats [DS SNVSAF7C]: §6.3.1 "forces the device into shutdown if the input voltage drops to 2.4 V … resumes above 2.6 V" (typical text, no min/max); §6.3.4 "in shutdown, the LM27762 actively pulls down on the outputs (OUT+, OUT–) until the output voltage reaches GND"; §6.1/§6.4.1 internal 50 kΩ from each OUT to GND in shutdown. Caveats: (i) thresholds typical only; (ii) 50 kΩ with the 16–34 µF per rail gives τ ≈ 0.8–1.7 s, so the fast part of the collapse is load-driven (op-amp/comparator quiescent) — c14: VPOS − VNEG < 4.5 V at 0.13–1.9 ms after the source loss — and the last ~1 V decays over ~1 s through the resistive loads and the 50 kΩ; (iii) whether the pull-down works with VIN ≈ 0 (deep short) is not stated. So "both rails off and pulled to 0 V" holds as an end state; below ~1 V it is slow, and the MCU path (DC_PERMIT_N via Q618, threshold 1.0–2.5 V, above Q617's 0.65–1.45 V) acts first.

### R2.9 Discharge and suspend (c06, c08)
3V3A (C302 2.2 µF, AVCC 2 × 2.53 µF, five 5.17 µF sense/reference nodes back-feeding through 5.1 k): < 0.1 V in **≤ 0.385 ms** (round 1 0.352), residual 13 mV; 3V3D (7.4–15.2 µF): **≤ 0.63 ms** (round 1 0.525: the ME6216 used to drain 3V3D into R530); 1V3: **≤ 0.134 ms**. The digital wait AUD_EN/AVCC_EN → RAIL_EN/ANA_EN (0.53 ms) still exceeds the 3V3A time (S6 met); the 1 ms re-enable rule covers 3V3D. Suspend (D-16): SOF-loss 1.02 ms → RELAY_EN low + 1.1 ms → SPI/PB14/RESETB → AUD_EN + AVCC_EN → +0.53 ms RAIL_EN/ANA_EN (U503 off ≤ ~35 µs) → Stop: **≤ 2.79 ms, margin 7.21 ms**. RAIL_EN is no longer needed for the suspend timing (the TPS2596 stops the analog load in ~12 µs typ) but stays for the defined LM27762 shutdown and the EN ≤ VIN rule. **[superseded → R3.1: RAIL_EN deleted; the rails stop when 5V_ANA_F falls below UVLO after ANA_EN low]**

### R2.10 Regulators, FB501, VBUS sense, thermal (c04, c05, c09, c10)
* 5V_SYS min **4.311 V** (VBUS 4.40 V at the J101 pads, High 751 mA; 4.342 V Default) — the J101 mated-contact drop (4 + 4 contacts, ≤ 20 mΩ loop) would lower it to 4.296 V (sensitivity) **[R10 (c04/c21, final loads, E-16 topology): 4.318 V High, 4.350 V Default, 4.303 V with the contact drop]**. LDO margins: TPS7A20 +0.92 V, TLV767 +0.78 V, LP5907 +0.92 V (20.9 mA) (±2 % test condition 4.30 V met), TLV758P 1.94 V. EN margins with the realistic VOL ≤ 0.05 V all positive (TLV758P VEN(LO) 0.30 V, +0.25 V). LM27762 negative-rail envelope at 4.40 V: 176/131/105 mA Default, 148/111/88 mA High (R_NEG 2.5/3.5/4.5 Ω); dissipation bound 0.89 W → 115.4 °C. **Analog r2 final:** at 4.40 V in High mode the negative LDO stays in regulation for the 32/60 Ω targets only if R_NEG ≤ 2.38/2.26 Ω (2.5 Ω typ) — no clipping up to 6.7 Ω, but PGOOD may dip at peaks → firmware debounces RAILS_OK_N (R2.13 D-i); the round-1 'VBUS-dependent volume ceiling' fallback is withdrawn (it would break the 300 Ω target).
* FB501: peak |Z| 1.59 Ω at 39.5 kHz with the TPS2596 Ron — unchanged conclusion (no damping, R531/C513 DNF).
* VBUS_SENSE band 3.756–4.244 V (ADC 11 LSB, leakage 1 µA [ASSUMP]); no false trip at 4.311 V (+67 mV); trips ≥ 0.22 V before 3V3D drops out. **[superseded (R9 E-16 / R10 c21): band 3.704–4.236 V with the TPS70933 3V3M range; margin +67 … +114 mV at the final loads]**
* Thermal (50 + 10 °C): TPS25200 63.7 °C (76.2 °C clamping at 5.50 V); TPS7A20 96.0 °C; TLV767 85.4 °C (87.7 °C in S5); LP5907 69.2 °C; TLV758P 81.9 °C; TPS2596 61.7 °C (High), 125.1 °C Default dead short (fault only), TSD/auto-retry High short; LM27762 ≤ 115.4 °C; TMUX1101, TPD2E2U06 negligible.

### R2.11 Removed / changed / added in round 2
* **Removed:** Q501 (2N7002 ILIM switch → U505, leakage), C503 (attach charge), DOM_DIS net (retired, D-11; never used by the power design), the relay-coil budget term (D-1 photorelays). Parts replaced under the same designator: U503 TPS2553DBVR → TPS259621DDAR, U303 ME6216A13M3G → TLV75801PDBVR, J101 SHOU HAN → GCT USB4105-GF-A.
* **Changed:** R509 196 k 1 % 0402 → 4.75 k 0.1 % 0603 (Susumu, global sourcing; ~~4.87 k if the NDK X201 is fitted~~ **[superseded (R9 E-27): the NDK needs no R509 change; R509 stays 4.75 k; S3 497.96 mA with the NDK (R10 F-1)]**); R510 84.5 k → 3.83 k 0.1 % 0603; C301/C302 1 µF 50 V → 2.2 µF 16 V (0603); C501 now feeds U502 and U504; roles: R511 = U505 SEL pull-down, R512 = FLT pull-up, R513 = EN/UVLO pull-down, C505 = TPS2596 CIN, R508 now also holds the U303 EN.
* **Added (each earns its place):** U103 (CC ESD, D-8), U505 (precision ILM switch, D-5), C514 (dVdt: 67 mA instead of a current-limited turn-on), C515 (U505 decoupling required by TI), R532 (PB4 ≤ 5.0 V), R533/R534 (U303 feedback, D-7).
* Net: 7 parts added, 2 removed → 67 fitted + 3 DNF (C101, R531, C513) in 59 BOM lines; fitted cost ≈ US$ 6.98 per board (indicative prices).

### R2.12 Component stress table — round-2 parts and changed operating points (worst state)

| Ref | Parameter | Worst case (state) | Rating [DS] | Margin |
|---|---|---|---|---|
| U503 TPS259621 | VIN / VOUT | 5.55 V (U102 clamp) | 19 V op, 21 V abs; OUT ≤ VIN + 0.3 V | 13.5 V |
| U503 | I / TJ | 483 mA (High limit) / 61.7 °C; Default dead short 1.24 W → 125.1 °C (fault, firmware ends it) | 2 A cont. / 125 °C ROC, TSD 157 °C typ | ×4.1 / fault case at the ROC edge |
| U503 | EN, FLT, dVdt, ILM | 3.35 V; 3.35 V (33.5 µA sink); ≤ 2.5 V internal; ≤ 0.7 V | 7 V abs (6 V ROC); 7 V, 10 mA; 2.5 V abs; internal | large |
| U505 TMUX1101 | VDD / SEL / D,S / I | 3.35 V / 3.35 V / ≤ 0.7 V / ≤ 0.21 mA | 5.5 V op, 6 V abs / 5.5 V / 0…VDD / 120 mA at 85 °C | ×1.6 / — / — / ×570 |
| U303 TLV758P | VIN / EN / FB / I / TJ | 3.33 V / 3.35 V / 0.56 V / 60 mA / 81.6 °C | 6.0 V op, 6.5 V abs / 6.5 V / 2.0 V / 500 mA / 125 °C | 2.7 V / 3.1 V / 1.4 V / ×8 / 43 °C |
| U303 | VOUT vs VIN in ramps | ≤ VIN + 0 V (Q506 first) | VOUT ≤ VIN + 0.3 V abs | met (c06/c14) |
| U103 TPD2E2U06 | VIO / leakage / P | ≤ 2.5 V normal; 5.55 V in a CC-to-VBUS fault, ≤ 12.6 µA, 70 µW | VRWM 5.5 V, VBR ≥ 6.5 V, ROC 5.5 V | normal large; fault 0.95 V to VBR, ROC +50 mV |
| J101 USB4105 | V / I / T | 5.5 V (5.55 V clamp side is after U102) / 751 mA VBUS / 60 °C local, reflow 240 °C | 48 V (20 V drawing) / 5 A VBUS / 85 °C, 255 °C 5 s | ×3.6 / ×6.7 / 25 °C, 15 °C |
| C514 | V | ≤ 2.5 V | 50 V | ×20 |
| C515 | V | 3.35 V | 16 V | ×4.8 |
| C301 / C302 (2.2 µF 16 V) | V | 5.55 V / 3.37 V | 16 V | ×2.9 / ×4.7 (DC bias in c04) |
| R509, R510, R533, R534 (0603 thin film) | P / V | < 0.2 mW / ≤ 1.3 V | 100 mW / 75 V | large |
| R532 | P / V | 0.049 mW / 4.78 V | 62.5 mW / 50 V | large |
| R512 | P | 0.11 mW (FLT asserted) | 62.5 mW | large |
| Q506 / R530 | pulse | 1.33 V / 4.75 Ω → 0.28 A for µs (≤ 3.5 µJ); 0 W continuous (U303 off first) | 30 A pulsed / 3.1 J STOL | large |
| U504 TLV767 | I / TJ | 158.7 mA (S5) / 87.7 °C | 1 A / 125 °C | ×6 / 37 °C |
| U501 LM27762 | TJ bound | 115.4 °C (483 mA into the lower rail) | 125 °C | 9.6 °C |

Round-1 rows not listed here keep their §9 values (U102, U101, C102, R101–R109, U502, U302, FB501, C507–C511, R501–R507, R522, Q502–Q505, R526–R529).

### R2.13 Interface requests (round 2)
**Digital (firmware)** — D-a Supply-fault rule: with ANA_EN high and ≥ 20 ms after RAIL_EN, RAILS_OK_N high **continuously ≥ 50 ms** (D-i) **or** ANA_FAULT_N low **or** DC_PERMIT_N high for > 200 ms after the DAC soft start with all leg readings ≈ 0 → RELAY_EN, RAIL_EN, ANA_EN low (TPS2596 FLT no longer reports over-current). D-b Family change: finish the mute before enabling the second oscillator (else 505 mA). D-c Brown-out action at the VBUS watchdog (2-sample debounce): **RELAY_EN and AVCC_EN low in the same interrupt (analog rule, adopted)**; AUD_EN goes low in the same GPIOC write as AVCC_EN (1V3 first via Q506); MCLK stops through U206 (AVCC_EN input) and MCLK_PERMIT low; leave RAIL_EN/ANA_EN high. D-d CC ADC > 2.3 V → invalid → Default mode; confirm the CH32V307 pin injection limit (≤ 0.19 mA through R103/R104) and its effect on the ADC2 DC-sense channels. D-e Keep ANA_EN → RAIL_EN ≥ 5 ms (U503 settles ≤ 3.0 ms), RAILS_OK_N valid ≥ 20 ms after RAIL_EN, the 0.53 ms AUD_EN/AVCC_EN → RAIL_EN wait (≥ 0.39 ms) and the 1 ms re-enable rule. D-f U303 EN is on AUD_EN (no extra pin). D-g X201 is budgeted as the Kyocera KC2520K80 (8.2 mA incl. R227, D-3 rev); ~~if the conditional NDK NSC5338D-80M second source is fitted, R509 becomes 4.87 k (R2.2 lookup)~~ **[superseded (R9 E-27): the NDK needs no R509 change; R509 stays 4.75 k; S3 497.96 mA with the NDK (R10 F-1)]**; the Kyocera disable time ≤ 200 ns closes the mclk_gate_race t_dis item. D-h D-19: R235 (0.034 mA on 3V3D) is in the budget; the PB1 readback of N2_MCLK_OE adds no load. **D-i RAILS_OK_N debounce:** short PGOOD dips during High-mode peaks at VBUS 4.40 V (R_NEG > 2.26–2.38 Ω, analog r2) are not overload; treat RAILS_OK_N as 'not good' only when high continuously ≥ 50 ms [ASSUMP: > 2 × the 20 Hz half-period; protection owns the value].
**Protection** — P-0 Your r2 drive loads (13.20 / 0.10 / 0.32 mA with RELAY_EN high, U604 56 µA) and TLV1704 I+ 1.244 / I− 1.231 mA (≤ D-9) are in the budget; 5V_SYS min is 4.311 V at VBUS 4.40 V (4.296 V if the J101 mated-contact drop is counted) **[R10 (c04/c21, final loads, E-16 topology): 4.318 V (4.303 V with the contact drop)]** → your Q612 VCE ≥ 0.426 V at 4.30 V stays ≥ 0.42 V; note D-3 revised: MCLK 80 MHz, soft start 104.9 ms (your message used 111.9 ms at 75 MHz). P-a ANA_FAULT_N now means thermal shutdown/ILM short only; overload → RAILS_OK_N (debounced ≥ 50 ms, D-i: High-mode peaks at 4.40 V may dip PGOOD without clipping); update §10 policy and the "firmware reacts to PGOOD/FAULT in ≤ 1 ms" deep-short statement (a 5V_ANA dead short reads RAILS_OK_N "good"; DC_PERMIT_N reports it). P-c LM27762 UVLO facts per R2.8 (typical; slow last volt). P-d DC-sense V− load confirmed 0.242 mA per leg.
**Analog** — A-a Default IOS 180.1/201.3/222.6 mA (+4.5 mA over your 175.6 mA need), High 390.4/437.1/483.4 mA for the power tables **[superseded (R9 E-18): need 178.96 mA, +1.09 mA (R10 F-1); High 395.4/442.7/489.7 mA (R510 3.74 k)]**; my quiescent cross-check 70.32 mA agrees with your 70.30 mA. A-b Unplug window (R2.7): ≤ 0.46 ms without firmware, ≤ 0.26 ms with the brown-out action (C103), ≤ 0.08 ms without C103, 3V3A 2.3–3.0 V at the rail collapse (High) — for the D-17 evaluation. A-c 3V3A capacitance now ≤ 7.6 µF (limit 10 µF): no new 3V3A capacitors without telling power; VCCA 2.9 mA is in the 3V3A budget (LP5907 20.9 mA, TJ 69 °C). A-d Rails may ramp in UVLO steps at RAIL_EN in Default (≤ 2.1 ms, switch open). A-e Programming mode (DAC reset) analog current 84.85 mA (your figure) in S5.
**Parts** — TPS259621DDAR is MSL 2 (bake); USB4105-GF-A out of stock at LCSC → global sourcing (DigiKey 127,933); verify classes/stock of C861444, C861384, C326733, C728581, C1852057, C1972959; R509 4.75 k 0.1 %/25 ppm has no LCSC stock: Susumu RG1608P-4751-B-T5 (DigiKey 114,162) via global sourcing, alternates YAGEO RT0603BRD074K75L / KOA RS73F1JTTD4751B; J101 sample continuity check.
**Integration** — R509 value per the lookup when X201/MCU/CPLD maxima are final; C103 → 100 pF recommendation (D-13); programming mode needs a ≥ 350 mA source.

### R2.14 Open items (round 2 additions; measurements with designed-in fallbacks)

| # | Item | Method | Fallback (no board change) |
|---|---|---|---|
| M2 (round 1, revised) | LM27762 R_NEG / PGOOD dips at VBUS 4.40 V High (analog r2: regulation needs R_NEG ≤ 2.26–2.38 Ω, no clipping up to 6.7 Ω) | peak test at the High envelopes, scope PGOOD | firmware RAILS_OK_N debounce (D-i); the VBUS volume-ceiling fallback is withdrawn |
| M9 | LM27762 start into the Default limit (UVLO cycling, time to PGOOD) | scope 5V_ANA_F, VPOS, VNEG, PGOOD at RAIL_EN, VBUS 4.40 V, Default | firmware waits longer before reading RAILS_OK_N; R509 value |
| M10 | U503 limits and FLT behaviour (Default/High, short) | electronic load on 5V_ANA; short test | R509/R510 values (same lands); firmware supply-fault rule |
| M11 | Hard-unplug ordering (5V_SYS, 3V3A, VPOS/VNEG, 3V3D, XI) with music at the limit | scope at unplug | C103 → 100 pF/DNF (BOM value); firmware brown-out action |
| M12 | PB4 low level with PGOOD low (VOL unspecified) | DMM at PB4, rails good | R522/R532 values (same lands) |
| M13 | TLV758P 1V3 at the DAC over temperature | DMM 0/50 °C | R533/R534 values |

### R2.15 Integration check (`check_design.py power protection analog digital`, 25 Sep 2026)
Last run (after D-3 revised / D-19): 309 parts, 177 nets, 936 pins, **no issues**. Earlier runs this round flagged only `iface_absent` DOM_DIS and AMP_EN (nets retired by D-11; DOM_DIS is in my scope and intentionally absent). No duplicate designators, no pin on two nets, BOM pin counts match the netlist (J101 12 SMT + 4 THT = 16), no single-pin interface nets, no cross-stream non-interface nets for my parts.

### R2.16 New sources
TI TPS2596 SLVSET8A (ti.com/lit/ds/symlink/tps2596.pdf) §6, 7.1–7.7, 8.3, Table 3; TI TLV758P SBVS351D §4–6; TI TMUX1101 SCDS410D §5–6.6; TI TPD2E2U06 SLLSEG9C §5–7; TI LM27762 SNVSAF7C §5.1, 6.1, 6.3.1–6.3.5, 6.4.1, 7.1; GCT USB4105 product page (gct.co/connector/usb4105) and drawing copies (mouser.com/datasheet/2/837/USB4105-1948910.pdf, …/usb4105-2448855.pdf, s3.amazonaws.com/snapeda/datasheet/USB4105-GF-A_GCT.pdf); LCSC C3020560, C861444, C861384, C326733, C728581 pages; JLCPCB C1852057, C2155774 (parts FU3 list).

---

# Round 1 report (24 Sep 2026) — valid unless marked [superseded → R2.x] — **history: every budget, limit and state figure is superseded (R9) → R10 table**

---

## 0. Summary of decisions and headline numbers

| # | Decision | Key evidence |
|---|---|---|
| D1 | **Input OVP = TI TPS25200DRVR (U102)** between J101/VBUS and 5V_SYS. It *clamps* the output at 5.25–5.55 V for any VIN below its OVLO (6.8–8.45 V) and disconnects above; IN withstands 20 V. An in-spec 5.50 V source is never disconnected, and 5V_SYS can never exceed 5.55 V → ≥ 0.25 V below the lowest downstream abs max (LM27762 VIN 5.8 V). **D102 deleted.** | TPS25200 SLVSCJ0F §5.1, §5.5 (V(OVC), V(OVLO)); c01 §1 |
| D2 | Adjustable-OVLO eFuses rejected: TPS25963x OVLO reference 1.17–1.22 V (±2 %) cannot place a trip inside [5.50, 5.80) V with margin; TPS2596x 5.7 V clamp option engages up to 5.83 V; TVS parts conduct only above 6 V. | TPS2596 SLVSET8A §7.5; c01 |
| D3 | **USBLC6-2SC6 (U101) stays at J101; its VBUS pin 5 moves to 5V_SYS** (behind the clamp), so its 6 V-min Transil never sees an OVP event. No TVS on raw VBUS. | USBLC6-2 Table 2 (VBR ≥ 6 V) |
| D4 | **C102 = 4.7 µF 25 V 0805** (was 1 µF): keeps the cable-inductance kick at U102 IN ≤ 18.7 V in the worst modelled hard short (≤ 14.4 V with the typical 3.5 µs response); 1 µF would reach 22–30 V (> 20 V abs max). | c01 §4 |
| D5 | **Attach inrush meets the USB-IF rule with ≥ 20 % margin without any soft-start or DC-bias credit**: largest region ~~38.3 µC (limit 50 µC, margin 23 %)~~ → 39.5 µC (21 %) with C301 2.2 µF and C503 deleted **[superseded → R2.6]**; with the typical TPS25200 soft start only the contact region counts, 28.4 µC (43 %). | USB-IF Compliance Update #45; c02 |
| D6 | Regulators: **3V3M = TPS7A2033PDBVR** (U502, IQ ≤ 15 µA, ±1.5 %), **3V3D = TLV76733DRVR** (U504, WSON-6 with pad, 18 V abs max, handles ~~0.50 W~~ 0.32 W itself — R519/R520/R521 deleted), **3V3A = LP5907** (kept), ~~**1V3 = ME6216A13** (kept)~~ → **1V3 = TLV75801PDBVR** (D-7) **[superseded → R2.4]**. | c04, c10 |
| D7 | (still valid; Q506/R530 kept with the TLV758P, times updated → R2.9) **Guaranteed discharge is derived from the regulator enables** (discharge FET on whenever its EN is low; AO3400A inverter + AO3400A discharge, 22 k gate pull-up to 3V3M). No DOM_DIS line is needed, a regulator can never fight its discharge, discharge is automatic at boot and during an MCU reset. Bleeders R524/R525 deleted. | c06 |
| D8 | **RAIL_EN is kept** (LM27762 EN± via R507/R506). ~~Without it the analog branch would only stop when the TPS2553 output falls (toff up to 3 ms), which would cost 3 ms of the 10 ms suspend deadline.~~ Reason superseded: the TPS2596 stops the load in ~12 µs; RAIL_EN stays for the defined LM27762 shutdown and EN ≤ VIN **[→ R2.9]**. | TPS2553 §7.5 toff; c08 |
| D9 | **[superseded → D-1: four TLP3545A photorelays, LED strings 14.3 mA on 5V_SYS + 1.02 mA on 3V3M, R2.2]** ~~**Relay coil supply: recommend a 3 V coil from 3V3D** (regulated, VBUS-independent, drops automatically with AUD_EN). A 5 V coil on 5V_SYS cannot reach its hot must-operate voltage at VBUS 4.40 V (G6K 5 V: −0.43 V; 150 mW / 75 % placeholder: −0.14 V).~~ | Omron G6K coil table; c07 |
| D10 | **[superseded → R2.2/R2.3: TPS259621 U503, R509 4.75 kΩ → Default 180.1/201.3/222.6 mA, R510 3.83 kΩ via U505 → High 390.4/437.1/483.4 mA]** ~~**TPS2553 single-resistor limits**: R509 = 196 kΩ (Default 117/138/165 mA min/nom/max) and R510 = 84.5 kΩ via Q501 (High 396/445/509 mA), chosen from the full USB budget with the Section-6 placeholders.~~ **With these placeholders the Default analog minimum is 117 mA — below the 157 mA of v0.8 and far below the 175 mA the Default power targets need.** 175 mA requires the non-analog maximum ≤ 247 mA (now 323 mA); lookup table in §6.3. | c03 |
| D11 | LM27762: **single 0.1 % thin-film feedback resistors** 221 k/100 k (VPOS 3.789/3.852/3.915 V) and 205 k/100 k (\|VNEG\| 3.661/3.721/3.781 V) — both ranges inside the global conventions, V+max 0.10 V lower. PGOOD pull-up R505 100 k to 5V_ANA_F, R522 10 k to PB4. FB501 damping: not needed, DNF footprint R531/C513. | c04 §5, c05 |
| D12 | VBUS sensing: R105/R106 kept (100 k/47 k on 5V_SYS) + **new C103 10 nF at PA1** (kept per D-13; round-2 recommendation 100 pF/DNF → R2.7), which makes the WCH R_AIN table irrelevant (R8-B4/D6). Brownout threshold 4.00 V nominal (band ~~3.77–4.23 V~~ 3.756–4.244 V → R2.10). | c09 |

**Headline numbers**

| Item | Value |
|---|---|
| OVP | output clamp 5.25–5.55 V [DS]; OVLO 6.8–8.45 V [DS]; response 0.6 µs [DS-typ]; IN abs 20 V; margin to LM27762 5.8 V: +0.25 V; hot-plug peak ≤ 10.7 V before the switch (c01) |
| Attach charge (USB-IF regions) | contact region ≤ 28.4 µC; soft-start region ≤ ~~38.3 µC~~ 39.5 µC without any credit → ~~23 %~~ **21 % margin** (typical 43 %) **[→ R2.6]** |
| USB budget (maxima + placeholders) **[superseded → R2.2]** | ~~unconfigured 82.9 mA (≤ 100, margin 17.1 mA); configured idle 382 mA (≤ 500, margin 118 mA); Default max 488.0 mA (≤ 500, margin 12.0 mA); High max 832 mA (≤ 1.5 A, margin 668 mA); programming 278 mA (charger); suspend 2.469 mA A-to-C cable / 2.374 mA C-to-C (≤ 2.5 mA, margin 31 / 126 µA)~~ |
| Current limits | ~~TPS2553 Default 117/138/165 mA, High 396/445/509 mA~~ → TPS2596 Default 180.1/201.3/222.6 mA, High 390.4/437.1/483.4 mA **[→ R2.2]**; TPS25200 1011/1120/1236 mA |
| Suspend | ~~current reached ≤ 6.62 ms after the last bus activity with the SOF-loss rule (margin 3.38 ms, relay release 5 ms [PH]); ≤ 9.61 ms without it (0.39 ms)~~ → ≤ 2.79 ms (margin 7.21 ms) with the photorelays and D-16 **[→ R2.9]** |
| Discharge (EN low → < 0.1 V) **[superseded → R2.9: 0.39 / 0.63 / 0.13 ms]** | ~~3V3A incl. AVCC pins ≤ 0.35 ms, 3V3D ≤ 0.53 ms, 1V3 ≤ 0.21 ms (incl. 89 µs gate bound)~~ |
| Thermal (50 °C + 10 °C local, 5.5 V) **[superseded → R2.10]** | ~~TLV767 98.6 °C, TPS7A20 95.8 °C, ME6216 101.3 °C, LP5907 68.1 °C, TPS25200 64.6 °C (78.4 °C when clamping at 5.50 V), TPS2553 66.4 °C, LM27762 ≤ 118.4 °C (overload bound)~~ |

---

## 1. Inputs used, method, and what could not be verified

* Brief `brief_r8_master.md` (Sections 0–7); Notes v0.7 §2, §2.5, §3.1, §3.4, §3.6; Spec v0.8 §3.2, §4, §5.3; `parts_list_current.csv`; ES9018K2M v3.7 (local text).
* Datasheets fetched from the manufacturers (list with URLs in §11). Stock/class from JLCPCB/LCSC part pages (dates in `bom_rows.csv`).
* No SPICE: numerical models in Python (series-RLC and ODE time stepping for hot-plug/kick, nodal RC transient for discharge, complex impedance sweep for FB501, closed-form budgets).

**Not verified (plainly):**
1. TPS25200 minimum rise time and minimum turn-on time are not specified (only typ/max). The guaranteed inrush bound therefore takes no soft-start credit; the hot-plug argument uses t_on ≥ 1 ms [ASSUMP] (typ 5.12 ms).
2. LM27762 charge-pump output resistance R_NEG is typical only (2.5 Ω at 5.5 V, 100 mA); headroom is given for 2.5/3.5/4.5 Ω. PGOOD threshold (95 %) and PGOOD VOL have no min/max.
3. ~~ME6216 has only 25 °C electrical specs (±1 %, dropout, IQ); temperature drift is not specified.~~ (ME6216 replaced by the TLV758P, R2.4.)
4. MLCC DC-bias factors are conservative assumptions (Samsung curves not extracted); upper-bound calculations use no DC-bias credit.
5. CH32V307 values (Stop current, GPIO VOL/VOH, ADC pin leakage, C_ADC, JTAG-default pull-ups, PB4 FT) are the digital stream's; placeholders are used and marked.
6. ~~J101 pad numbering: netlist uses USB-C contact names (A1…B12, SH1–SH4); the SHOU HAN drawing was not readable here → parts stream maps pads (R8-A10).~~ J101 is now the GCT USB4105-GF-A with the GCT pad labels (R2.5).
7. JLCPCB library class for several resistors is marked "(not verified)" in the BOM where the page did not show it.
8. The USB-IF 50 µC limit value is taken from USBET-based secondary sources (TestUSB, Epsilon Labs); the region method itself is from the official USB-IF compliance update.

---

## 2. R8 review items in the power scope — dispositions

| ID | Finding | Disposition (design specified / calculated / to measure) |
|---|---|---|
| R8-A1 (Blocking) | D102 SMF6.0A cannot protect ≤ 6 V inputs | **Closed by design.** TPS25200 clamp ≤ 5.55 V [DS]; D102 deleted. Downstream margins c01 §1 [CALC]. |
| R8-B9 | 6.0 V TVS cannot protect LM27762 (5.8 V) | Closed with A1 (margin +0.25 V to 5.8 V). |
| R8-A4 (Blocking) | Suspend ≤ 10 ms relied on LP5907 typical discharge | **Closed by design.** Relay opens first (no pop dependency), switched discharge with Rds(on)max, ≤ 0.35 ms [CALC c06]; suspend level ≤ 6.62 ms [CALC c08] with the SOF-loss rule, ≤ 9.61 ms without it. |
| R8-B11 | LP5907 230 Ω is typical | Closed: internal discharge not relied on; external guaranteed path. |
| R8-C minor | Suspend 9.3 ms, 0.7 ms margin | Closed: 6.62 ms (3.38 ms margin) with t_rel 5 ms [PH]. |
| R8-A7 | Inrush ≈ 49 µC vs 50 µC | **Closed by design.** OVP soft start + USB-IF region method; guaranteed ~~38.3 µC (23 % margin)~~ 39.5 µC (21 %) after C301 2.2 µF and C503 deleted (R2.6), typical 28.4 µC [CALC c02]. |
| R8-A2 (Blocking) | FAULT → D606 → node F threshold | Obsolete: latch deleted; FAULT → ANA_FAULT_N (MCU) with R512 only. |
| R8-A8 | PGOOD → PB4 acceptable only because FT | Kept: R505 now 100 k to 5V_ANA_F, R522 10 k; node ≤ 5.55 V. PB4 FT to be confirmed by the digital stream (interface request I4). |
| R8-C4 / D3 | RAILS_OK_N reads "good" with 5V_ANA off | Physical (PGOOD pull-up to VIN, TI). Firmware rule: RAILS_OK_N valid only when ANA_EN = RAIL_EN = 1 and ≥ 20 ms after RAIL_EN (protection stream policy). |
| R8-D3 | Keep ANA_EN on in suspend for faster resume | **Rejected**: 5V_ANA on in suspend costs ≥ 100 µA (TPS2553 IQ [DS]) + LM27762 ISD; the slow resume came from the deleted blanking capacitor. |
| R8-B4 / D6 | VBUS watchdog: 32 kΩ vs 7.5-cycle sampling; single channel | **Closed by design**: C103 10 nF at PA1 (charge-sharing error ≤ 4 mV even multiplexed; ~0 single-channel) [CALC c09]; the < 5 µs requirement is dropped (brief 3.4). |
| R8-D10 | ME6211 dropout at 160 mA not guaranteed | Closed: TLV767 VDO ≤ 1.4 V at 1 A [DS] → ≤ 0.31 V at 221 mA (resistive scaling) → 0.66 V margin at the 4.40 V corner [CALC c04]. |
| R8-D2 | Comparator current costs the charge-pump factor | ~~Budget uses the analog stream's 58.6 mA (incl. factor) [PH]~~ → TLV1704 I+ 1.26 / I− 1.25 mA in the recomputed 70.32 mA quiescent (R2.2); the analog stream re-issues the power table. |
| R8-D7 | JTAG-default pull-ups on PA15 (ILIM_HI) / PB4 | Closed by the digital stream: PA15/PB4 are plain GPIO at reset on the CH32V307 (digital D6); R511 holds U505 (was Q501) in Default. |

---

## 3. Where this stream overrides the orchestrator baseline (with evidence)

1. **OVP type (3.4 "trip between 5.5 V and the lowest abs max")** — replaced "trip" by "clamp + OVLO". Any disconnect-type OVP needs its whole tolerance band inside [5.50, 5.80) V; TI's adjustable OVLO (TPS25963x) has a 1.17–1.22 V reference [DS TPS2596 §7.5] → with 0.1 % resistors the best window is 5.50–5.76 V: zero margin above vSafe5V max and 42 mV below 5.8 V [CALC]; its IQ (259 µA max) would also break the suspend budget. The TPS25200 clamp keeps the board running up to 6.8 V and never lets 5V_SYS exceed 5.55 V [DS]. Cost: 190 µA IQ max — handled in the suspend budget (§6.4).
2. **DOM_DIS (3.4 "controlled by the MCU, net DOM_DIS")** — replaced by EN-derived discharge. With an independent DOM_DIS a firmware error can enable a regulator into its discharge resistor; that forces R_dis ≥ ~110 Ω (0603 continuous) and ~3 ms discharges. EN-derived gating makes the fight impossible, so 10 Ω/4.7 Ω give ≤ 0.53 ms [CALC c06]; the order of discharge simply follows the EN order the firmware already runs; the MCU line is freed. (+2 FETs, +2 resistors vs DOM_DIS.)
3. **[superseded → D-1 photorelays]** ~~**Relay coil from 5V_SYS (3.4/7.1-5)** — a 5 V coil cannot operate hot at the 4.40 V corner (§5.7).~~ Recommendation: 3 V coil from 3V3D; alternative only with a relay whose V_mo(23 °C) ≤ 3.64 V on 5V_SYS.
4. **Keep RAIL_EN** although "EN± tied to VIN" would delete 2 resistors and a GPIO: ~~the TPS2553 toff is up to 3 ms [DS]; RAIL_EN stops the analog load in microseconds and keeps the suspend margin at 3.38 ms (c08)~~ → round 2: kept for the defined LM27762 shutdown and EN ≤ VIN (R2.9).
5. **3V3M stays behind the OVP** (baseline), but note the alternative evaluated: a ≥ 20 V-rated always-on LDO before U102 with U102 switched by the MCU would raise the suspend margin to ~0.25 mA but needs a slower HV LDO on the MCU/ADC reference, one more GPIO and moves U101 pin 5 to 3V3M. Not adopted; revisit only if the digital stream's MCU Stop maximum exceeds 1.93 mA.
6. **3V3D as a buck** evaluated (saves ~32 mA of worst-case USB current → +24 mA Default analog minimum, 0.45 W less heat). Not adopted: switching noise next to the MCLK oscillator and the 120 dB DAC; the same budget is available risk-free from the oscillator/MCU placeholders (§6.3).

---

## 4. Circuit description (as designed)

### 4.1 Block 1 — USB-C input, OVP, sensing
**[J101, U103, C103 note superseded → R2.5/R2.7]**
* J101 ~~(unchanged)~~ → GCT USB4105-GF-A with GCT pad labels; U103 TPD2E2U06 on CC1/CC2. VBUS contacts A4/A9/B4/B9 → net **VBUS**. C102 4.7 µF 25 V X5R at U102 IN / J101.
* **U102 TPS25200DRVR**: pin 6 IN = VBUS; pin 1 OUT = **5V_SYS**; pin 4 EN ← R109 300 kΩ from VBUS (TI: ≥ 300 k so the internal EN Zener limits EN at 20 V input; EN leakage ≤ 2 µA → EN ≥ VIN − 0.6 V) [DS §7.3.1]; pin 2 ILIM ← R108 86.6 kΩ → IOS 1011/1120/1236 mA [DS Eq.1, CALC c04 §8]; pin 3 FAULT not connected (the MCU is unpowered during OVLO, and a clamp event must not stop audio); pin 5 + pad GND.
* U101 USBLC6-2SC6 at J101: pins 1/6 USB_DP, 3/4 USB_DN, 2 GND, **5 → 5V_SYS**.
* CC: R101/R102 5.1 kΩ Rd; R103/R104 10 kΩ to CC1_ADC/CC2_ADC (unchanged). Shell: R107 0 Ω, C101 DNF (unchanged).
* VBUS_SENSE: R105 100 k from 5V_SYS, R106 47 k to GND, **C103 10 nF** at the MCU pin (PA1).

### 4.2 Block 5 and U302/U303 — domains
| Rail | Regulator | Input | EN | Output caps | Discharge |
|---|---|---|---|---|---|
| 3V3M | U502 TPS7A2033PDBVR | 5V_SYS (C501 1 µF) | tied to 5V_SYS | C502 1 µF + MCU caps (≤ 5.1 µF total) | none (always on) |
| 3V3D | U504 TLV76733DRVR | 5V_SYS (~~C503 1 µF~~ C501 shared, R2.6) | AUD_EN, R508 47 k | C512 10 µF (C504 deleted) | Q505 + R529 10 Ω, gate N5_DIS_D |
| 1V3 | ~~U303 ME6216A13M3G~~ U303 TLV75801PDBVR + R533/R534 (R2.4) | 3V3D (C311 1 µF) | ~~none (follows 3V3D)~~ AUD_EN | C312 1 µF + DAC C310/C309 | Q506 + R530 4.7 Ω, gate N5_DIS_D |
| 3V3A | U302 LP5907MFX-3.3 | 5V_SYS (C301 ~~1 µF~~ 2.2 µF) | AVCC_EN, R303 100 k | C302 ~~1 µF~~ 2.2 µF + C303/C304 (analog) | Q503 + R527 10 Ω, gate N5_DIS_A |
| 5V_ANA | ~~U503 TPS2553DBVR~~ U503 TPS259621DDAR (R2.3) | 5V_SYS (C505 100 nF) | ANA_EN, R513 100 k | C506 1 µF (+ C514 dVdt) | — |
| VPOS/VNEG | U501 LM27762DSSR | 5V_ANA_F via FB501 (C507 10 µF) | RAIL_EN via R507 10 k, R506 100 k | C509/C510/C511 10 µF, C508 1 µF | internal 50 k [DS] |

Discharge gate nodes: N5_DIS_A (R526 22 k to 3V3M, pulled down by Q502 whose gate is AVCC_EN); N5_DIS_D (R528 22 k to 3V3M, pulled down by Q504, gate AUD_EN).
~~TPS2553: ILIM = R509 196 k to GND and R510 84.5 k in series with Q501 2N7002 (gate ILIM_HI, R511 100 k). FAULT → ANA_FAULT_N with R512 100 k to 3V3M.~~ → TPS2596 ILM = R509 4.75 k ∥ (R510 3.83 k + U505 TMUX1101, SEL ILIM_HI, R511); FLT → ANA_FAULT_N with R512 (R2.3).
LM27762: R501 221 k/R502 100 k (FB+), R503 205 k/R504 100 k (FB−), all 0.1 % 0603 thin film; PGOOD → N5_PGOOD, R505 100 k to 5V_ANA_F, R522 10 k to RAILS_OK_N. DNF R531 1 Ω + C513 10 µF across C507.

---

## 5. Calculations (by brief item)

### 5.1 Input protection (7.1-1) — c01
* **Static:** 5V_SYS ≤ min(VBUS, 5.55 V) for VBUS < V(OVLO)min 6.8 V; ≥ V(OVLO) the switch is off [DS §5.5]. Margins to abs max: LM27762 VIN +0.25 V, LP5907 +0.45 V, USBLC6 VBR +0.45 V, TPS7A20 +0.95 V, TPS2553 +1.45 V, TLV767 +12.45 V [CALC].
* **vSafe5V ≤ 5.50 V:** never disconnected (clamp min 5.25 V only regulates). Between 5.50 and 5.55 V the LP5907/LM27762 are above their 5.5 V operating maximum but inside abs max (out-of-spec source only).
* **Hot-plug (USB-A-to-C into a live port):** series-RLC step, VBUS 5.50 V, C_eff 0.8–5.2 µF, L 0.25–1.5 µH, R 0.05–0.4 Ω → peak ≤ 10.69 V (≤ 2 × 5.5 V) at J101/C102/U102 IN only; envelope decays in ≤ 240 µs, U102 turns on after t_on (5.12 ms typ) → downstream never sees it. U102 IN margin 9.3 V; C102 (25 V) margin 14 V [CALC].
* **ESD charge (8 kV / 150 pF):** 1.2 µC into C102 (≥ 2.16 µF effective) → +0.56 V (ESL ignored) [CALC]. No IEC system-level requirement exists; no VBUS TVS is fitted because any TVS that survives a 20 V faulty source clamps above U102's 20 V rating.
* **Hard short behind U102 (single fault):** cable-inductance kick at IN: C102 1 µF → up to 22–30 V (fails); **4.7 µF → ≤ 14.4 V with t_IOS 3.5 µs [DS-typ], ≤ 18.7 V with 7 µs** (< 20 V) [CALC].
* **Fast OV transients on a live input:** the clamp handles source ramps (USB-PD source transitions are slew-limited to tens of mV/µs — recalled from the PD spec, not re-fetched); for a 1 V/µs step to > OVLO TI shows V_OUT overshoot decreasing with C_OUT (Fig 8-3, not extractable) — only a faulty source can do this; the board is protected by OVLO within 0.6 µs [DS-typ].
* **Thermal:** 0.832 A → 69 mW, 64.6 °C; clamping at VBUS 5.50 V (VOUT 5.25 V) 0.277 W, 78.4 °C; out-of-spec VBUS 6.79 V: 1.28 W, 145 °C (self-protected by OTSD2 ≥ 155 °C) [CALC c10].

### 5.2 Inrush / attach (7.1-2) — c02 **[numbers superseded → R2.6]**
* **Rule (exact):** USB-IF Compliance Update #45 (Jun 2021): current measured ≥ 100 ms after attach; any current > 100 mA is part of the inrush event; a *region* runs from > 100 mA until < 100 mA for ≥ 100 µs; the tool integrates the **charge above 100 mA** per region; pass/fail on the largest region; no region = pass. Limit 50 µC (10 µF at 5 V, USB 2.0 §7.2.4.1; USBET limit per TestUSB/Epsilon Labs). (USB 2.0 §7.2.4.1 also requires surge limiting when more bypass capacitance is used — recalled from the spec, not re-fetched here.)
* **Capacitance budget:** VBUS ≤ 4.7 µF (C102); 5V_SYS ≤ 3.1 µF nominal (C501, C503, C301 1 µF; C505 100 nF); 3V3M ≤ 5.1 µF nominal (C502 + MCU caps).
* **Region A (contact):** ≤ 5.17 µF × 5.5 V = **28.4 µC** [CALC].
* **Region B (U102 turn-on, ≥ 5 ms later = separate region):** guaranteed bound with instant turn-on and no DC-bias credit: 3.41 µF × 5.5 V + 5.83 µF × 3.35 V = **38.3 µC** → 23 % margin [CALC]. With the typical 2.05 ms rise the peak is 31.5 mA (MCU at HSI) → no region; with the MCU at 80 mA during the ramp 0.56 µC (typ) / 8.2 µC (4× faster ramp).
* **Firmware rule (I3):** MCU stays at low clock (PLL/USBHS off) for ≥ 5 ms after reset → attach current < 100 mA during the U102 ramp.

### 5.3 Regulators (7.1-3) — c04, c10
Worst input: 5V_SYS min 4.301 V (VBUS 4.40 V, High, 832 mA through 99 mΩ + 20 mΩ) [CALC]; max 5.50 V in-spec (5.55 V clamp).

| Reg | Why this part | Abs max vs worst input | Dropout at 4.40 V corner | Pd / TJ at 5.5 V, 50 °C (+10 °C local) | EN vs driver | Output caps | Noise/PSRR | Pinout |
|---|---|---|---|---|---|---|---|---|
| U502 TPS7A20 (3V3M) | IQ 6.5 µA typ, 15 µA max; ±1.5 % over line/load/temp (VDDA reference); fast transient; EN abs 6.5 V independent of VIN | 6.5 V vs 5.55 V (+0.95 V); op max 6.0 V ✓ | VDO ≤ 145 mV at 300 mA → 40 mV at 83.5 mA; needs 3.39 V, margin +0.91 V | 0.191 W, θJA 187.1 → 95.8 °C | EN tied to IN (VEN(HI) ≤ 0.9 V) | C_eff ≥ 0.69 µF (≥ 0.47 µF), total ≤ 5.83 µF (≤ 200 µF) | 7–10 µVrms, 95 dB @1 kHz [DS-typ] | DBV 1 IN, 2 GND, 3 EN, 4 NC, 5 OUT |
| U504 TLV767 (3V3D) | 1 A, 18 V abs, WSON pad θJA 77.7; ±1 %; EN abs 18 V independent of VIN (deletes R521); no dropper | 18 V vs 5.55 V | VDO ≤ 1.4 V at 1 A → ≤ 0.31 V at 221 mA; margin +0.66 V | 0.497 W → 98.6 °C | VEN(HI) ≤ 1.2 V; EN internal pull-up 0.4 µA typ vs R508 47 k → 19 mV | C512 10 µF (2.2–220 µF nominal ✓, eff. 5.35 µF ≥ 0.5 µF) | 70 dB @1 kHz; noise irrelevant (digital) | DRV 1 OUT, 2 SNS, 3 GND, 4 EN, 5 GND, 6 IN, pad |
| U302 LP5907 (3V3A) | lowest-noise in design (6.5 µVrms), analog stream's budget; with the clamp its 6.0 V abs max has +0.45 V | 6.0 V vs 5.55 V; op max 5.5 V (in-spec ✓) | VDO ≤ 18 mV at 18.4 mA; margin +0.92 V; ±2 % spec requires VIN ≥ 4.30 V → at the edge at 4.301 V | 0.042 W → 68.1 °C | VIH 1.2 V / VIL 0.4 V; EN abs 6 V independent of VIN (deletes R307) | 2.24 µF eff. min (≥ 0.7), 6.71 µF max (≤ 10) | 6.5 µVrms, 82 dB @1 kHz [DS-typ] | DBV 1 IN, 2 GND, 3 EN, 4 NC, 5 OUT |
| ~~U303 ME6216A13 (1V3)~~ **[superseded → R2.4 TLV75801P]** | no EN → follows 3V3D so DVDD ≤ DVCC on ramp-up; DVDD 1.3 V ±5 % (ESS p.28) vs ±1 % [DS 25 °C] | 6.5 V vs 3.35 V | 3.3 → 1.3 V, 2 V headroom | 0.124 W, θ ≈ 333 °C/W [ASSUMP from Pd 300 mW] → 101.3 °C | — | C312 1 µF + C310 2.2 µF + C309 100 nF | 50 dB @1 kHz [DS-typ] | SOT23-3 1 VSS, 2 VOUT, 3 VIN |

### 5.4 TPS2553 (U503) **[superseded → R2.3: U503 is the TPS259621DDAR]**
* Single RILIM R509; High = R509 ∥ (R510 + Q501). Equations IOSmax = 22980/R^0.94, IOSnom = 23950/R^0.977, IOSmin = 25230/R^1.016 (mA, kΩ, 15–232 k) [DS §9.5.1], plus 1 % resistor, plus 1.5 % allowance for Q501 off-leakage at the ILIM pin [ASSUMP; IDSS is specified only at 60 V].
* Default 196 k → 117/138/165 mA; High 59.1 k → 396/445/509 mA [CALC c03]. Q501 at VGS ≥ 2.85 V: triode estimate ≤ 30 Ω in series with 84.5 k (0.04 %). TI Fig 24 uses the same topology.
* EN threshold 0.66–1.1 V [DS]; FAULT VOL ≤ 180 mV at 1 mA, deglitch 5–10 ms [DS]; R512 100 k to 3V3M → 33.5 µA when asserted.
* toff up to 3 ms [DS] → reason for keeping RAIL_EN (§3.4).

### 5.5 LM27762 (U501) — c04 §5–7, c05
* **Feedback (single 0.1 % resistors):** VPOS = VFB+ (1.182–1.218 V [DS]) × (1 + 221/100) = 3.789/3.852/3.915 V; \|VNEG\| = VFB− (1.202–1.238 V) × (1 + 205/100) = 3.661/3.721/3.781 V; R2 = R4 = 100 k ≥ 50 k [DS §7.2.2.1]. 226 k (3.90 V class) is not stocked at LCSC (3.848–3.976 V if sourced); 215 k gives a 3.78 V option (3.718–3.842 V). The analog stream confirms V+ (I1); the footprint is the same for all values.
* **PGOOD:** open drain, low = both outputs ≥ 95 % of target [DS §6.3.5] → +3.66 V / −3.53 V (typ threshold). R505 100 k to VIN (TI recommends a pull-up to VIN; 10 k→100 k because no latch timing is needed: 55 µA instead of 0.55 mA); R522 10 k to PB4 (FT). Reads "good" when 5V_ANA is off → firmware qualification (R8-C4).
* **EN ≤ VIN [DS §5.1]:** RAIL_EN high only ≥ 5 ms after ANA_EN (TPS2553 ton ≤ 3 ms); low before ANA_EN. At unplug 3V3M tracks 5V_SYS through the TPS7A20 in dropout, so RAIL_EN ≤ VIN + small; R507 limits any residual injection.
* **Peak-current headroom (clean-signal envelopes for the analog stream)** **[table superseded → R2.10: 175/131/104 mA Default, 148/110/88 mA High at 4.40 V]**: VIN_LM = 5V_SYS − I_ana × (135 + 50 + 10 mΩ).

| VBUS | Mode | VIN_LM | I_neg max for R_NEG 2.5 / 3.5 / 4.5 Ω | I_pos max |
|---|---|---|---|---|
| 4.40 V | Default | 4.310 V | 179 / 134 / 107 mA | 585 mA |
| 4.40 V | High | 4.202 V | 143 / 107 / 85 mA | 425 mA |
| 4.60 V | Default | 4.510 V | 247 / 184 / 147 mA | 881 mA |
| 4.60 V | High | 4.402 V | 210 / 157 / 125 mA | 721 mA |

  Condition: VIN − I·R_NEG ≥ \|VNEG\|max 3.781 V + I·0.45 Ω (LDO dropout 30 mV typ at 100 mA × 1.5) [DS-typ/ASSUMP]. The negative rail carries 2 × I_leg,pk + its quiescent in both jack modes. ~~Designed-in fallback if R_NEG measures high: firmware VBUS-dependent volume ceiling in High mode (VBUS_SENSE), or R503 value change.~~ **[superseded → R2.10: analog r2 — no clipping up to R_NEG 6.7 Ω; no volume ceiling; firmware debounces PGOOD dips]**
* **Dissipation:** upper bound 509 mA into the lower rail at 5.5 V → 0.94 W → 108.4 °C (118.4 °C with +10 °C local) vs 125 °C [CALC c10]. Thermal pad to GND pour mandatory.
* **Capacitors:** 10 µF 25 V 0805 ≥ 4.97 µF effective at 4 V vs EC test conditions 2.2 µF (IN/OUT) and 4.7 µF (CP) [DS §5.5]; C508 1 µF (0.61 µF eff. at 5.5 V) [ASSUMP factors].
* **FB501 + C507 (R7-A P-22):** worst |Z_in| at VIN 1.61 Ω at 39.7 kHz (Q 3.3) with the most pessimistic set; the peak is the USB cable inductance resonating with the board capacitance, barely dependent on the ferrite. Worst VIN ripple estimate 61 mV if a PFM burst sits on the peak → ≤ 0.44 mV on the rails after the LM27762 LDOs [DS-typ PSRR]. **No damping fitted; R531 1 Ω + C513 10 µF DNF** (peak −7.9 dB) as fallback [MEAS, §9].

### 5.6 Guaranteed discharge (7.1-4) — c06 **[times superseded → R2.9: 3V3A ≤ 0.39 ms, 3V3D ≤ 0.63 ms, 1V3 ≤ 0.13 ms; U303 now TLV758P with EN = AUD_EN]**
* **Scheme:** discharge FET gate pulled to 3V3M (22 k) and held at ~0 V by an AO3400A inverter whose gate is the regulator EN net. EN high → discharge off within < 1 µs (before any LDO output rises: LP5907 tON 80 µs typ, TLV767 soft start 500 µs typ). EN low → discharge on after ≤ 89 µs (gate charge bound 3 nC at ≥ 33.8 µA) [CALC/ASSUMP].
* **FET:** AO3400A, VGS(th) 0.65–1.45 V, Rds(on) ≤ 48 mΩ at VGS 2.5 V [DS], × 1.15 at 60 °C → 55 mΩ; VGS 3.25–3.35 V available.
* **Worst-case times (C at +tolerance, no DC-bias credit, R +1 %, loads ignored, DC-sense back-feed included):** 3V3A and both AVCC pins < 0.1 V in ≤ **0.352 ms**; 3V3D ≤ **0.525 ms**; 1V3 ≤ **0.210 ms** [CALC]. Residual on 3V3A from the DC-sense network back-feed: 5 mV.
* **Pulse stress:** I_pk ≤ 340 mA, energy ≤ 0.1 mJ per event in a 0603 thick-film resistor (STOL 0.625 W for 5 s = 3.1 J) — negligible [CALC].
* **Ordering constraints met:** MCLK stopped first (firmware; X201 is on 3V3D anyway); **DVDD ≤ DVCC**: 1V3 (4.7 Ω, τ ≤ 18 µs) collapses faster than 3V3D in every bounding case with 3V3D constant-current loads ≤ 120 mA (V1V3 − V3V3D ≤ −60 mV); only with an unphysical 180 mA constant load down to 0.6 V does 1V3 lead by ≤ +0.16 V, which is below any junction forward voltage [CALC]. R530 = 4.7 Ω keeps the ME6216 at 277 mA (< 300 mA) while it still regulates during the first < 0.1 ms. **DAC pins held by the I/V while AVCC falls**: RAIL_EN/ANA_EN go low only after t_A,max = 0.35 ms.
* **Start-up discharge at boot:** ENs are low at reset (R303, R508, R513, R506) → all discharge FETs on as soon as 3V3M > ~1.5 V → domains at 0 V long before enumeration. Firmware rule: an EN that went low stays low ≥ 1 ms.
* **MCU reset case:** EN nets decay through their pull-downs (τ ≈ 64 µs with the inverter gate); a brief overlap of ≤ ~80 µs may load an LDO into its current limit — ≤ 0.1 mJ, harmless.

### 5.7 Relay coil supply (7.1-5) — c07 **[superseded → D-1: photorelays; c07 kept as history]**
Must-operate is specified at 23 °C coil temperature [DS G6K note 2] and rises with copper resistance: V_mo(T) = V_mo(23) × (234.5 + T)/257.5; worst coil at operate 70 °C (50 °C ambient + 10 °C local + 10 °C residual self-heating) [ASSUMP] → ×1.1825. Driver: two AO3400A-class NMOS (placeholder for the protection stream).

| Coil (supply) | V_mo hot | Coil voltage min (4.40 V, High) | Margin | Coil voltage max | I_max |
|---|---|---|---|---|---|
| 5 V 150 mW 75 % placeholder (5V_SYS) | 4.43 V | 4.298 V | **−0.136 V** | 5.545 V (111 %) | 40.6 mA |
| Omron G6K 5 V 80 % (5V_SYS) | 4.73 V | 4.299 V | **−0.431 V** | 111 % | 28.6 mA |
| Omron G6K 4.5 V 80 % (5V_SYS) | 4.26 V | 4.299 V | +0.042 V | 123 % | 34.9 mA |
| generic 4.5 V 100 mW 75 % (5V_SYS) | 3.99 V | 4.299 V | +0.308 V | 123 % | 33.4 mA |
| **Omron G6K 3 V 80 % (3V3D) — recommended** | 2.84 V | 3.259 V | **+0.421 V (+14.8 %)** | 3.327 V (111 %) | 44.6 mA |

Requirement to the protection stream: on 5V_SYS V_mo(23 °C) ≤ 3.64 V (5 V coils ≤ 73 %, 4.5 V coils ≤ 81 %); on 3V3D any 3 V coil ≤ 92 %. Max voltage 150 % instantaneous [DS]; continuous at 70 °C per the manufacturer derating graph (111 % is expected to be inside it — protection stream confirms).

### 5.8 VBUS sensing (7.1-8) — c09 **[band and latency superseded → R2.10/R2.7]**
k = 0.3197 (5.55 V → 1.774 V), R_th 31.97 kΩ, τ 0.32 ms with C103. Current 37.8 µA (counted in suspend). Brownout threshold 4.00 V nominal → band 3.771–4.229 V (divider 1.4 %, VDDA 1.5 %, pin leakage 1 µA [ASSUMP] → ±100 mV, ADC ±5 LSB [ASSUMP]); no false trip at the 4.301 V minimum operating 5V_SYS (margin 72 mV); trips before 3V3D (3.646 V) or 3V3M (3.390 V) drop out (margin 125 mV). Use: brownout → RELAY_EN low, mute, orderly power-down; not a protection element any more.

---

## 6. USB current budget (7.1-6) and suspend (7.1-7) — c03, c08 **[whole section superseded → R2.2 (budget, limits, lookup) and R2.9 (suspend timeline)]**

### 6.1 Loads (maxima)
| Load | Max | Source |
|---|---|---|
| MCU run / suspend | 80 mA / 1.9 mA | [PH] |
| LEDs (both on) | 0.76 + 0.71 mA | [CALC] VF min, R −1 % |
| EN pull-downs / inverter pull-ups / misc | 0.17 / 0.31 / 0.5 mA | [CALC]/[ASSUMP] |
| TPS7A20 ground current | ≤ 10 µA + 6.6 µA/mA | [CALC] linear interp. of DS max (10 µA at 0 mA, 2 mA at 300 mA) |
| CPLD / X201 / X202 / X203 | 25 / 40 / 15 / 15 mA | [PH] |
| DAC DVCC / DVDD | 14.2 / 60 mA | [DS-typ] ESS "current nominal" / [PH] |
| I²C pull-ups (both low) / CPLD enable pull-downs | 3.06 / 3.3 mA | [CALC] / [PH] R8-D2 |
| Relay coil | 45 mA on 3V3D (30 mA on 5V_SYS) | [CALC c07] / [PH] |
| TLV767 IGND | 95 µA + 2.25 mA/A | [DS] IQ max + [ASSUMP] 1.5× typ slope |
| 3V3A (DAC analog / DC-sense) | 17.5 / 0.87 mA | [PH] |
| LP5907 IQ | 25 µA + 1.6 µA/mA | [CALC] interp. DS max |
| TPS25200 IQ / EN leakage | 190 / 2 µA | [DS] |
| VBUS divider | 37.8 µA | [CALC] |
| Analog quiescent (idle) | 59.0 mA | [PH] R8-D2 58.6 mA + LM27762 IQ + PGOOD pull-up |
| TPS2553 IQ | 140 µA | [DS] (20 k value, conservative) |
| Legacy A-to-C cable Rp through Rd | 94 µA | [ASSUMP] Rp 56 k ±5 % to VBUS |

### 6.2 States
| State | Total (max) | Limit | Margin |
|---|---|---|---|
| S1 attached, unconfigured (3V3M, MCU at max, LEDs on) | 82.9 mA | 100 mA | 17.1 mA |
| S2 configured idle (all domains, relay closed, analog quiescent) | 382.1 mA | 500 mA | 117.9 mA |
| S3 Default max (non-analog 323.0 mA + IOS max 165 mA + IQ) | 488.0 mA | 500 mA | 12.0 mA (rule: ≥ 10 mA) |
| S4 High max (non-analog + 509 mA) | 832 mA | 1.5 A advertisement | 668 mA; TPS25200 IOS min 1011 mA (+22 %) |
| S5 programming mode (3V3M+3V3D+3V3A, no analog, no relay) | 277.7 mA | source ≥ 500 mA (charger/bench) | — |
| S6 suspend | 2.469 mA (A-to-C) / 2.374 mA (C-to-C) | 2.5 mA | 31 µA / 126 µA |

### 6.3 Current-limit choice and the integration lookup
Rule: largest IOS min such that non-analog max + IOS max(R509 −1 %) × 1.015 + IQ ≤ 490 mA. With the placeholders (relay on 3V3D): **R509 = 196 k (117/138/165 mA), R510 = 84.5 k (396/445/509 mA)**. With the relay on 5V_SYS (30 mA [PH]): 178 k (129/152/181 mA).
**Consequence:** the Default power targets (3.5 mm 32 Ω ≥ 38 mW needs ≈ 175 mA [analog stream]) cannot be met within 500 mA with the Section-6 placeholders. Required non-analog maximum for 175 mA: **≤ 247 mA** (R509 = 130 k). Largest levers (not in this stream): X201 40 → ≤ 10 mA (−30 mA), X202/X203 with a true standby pin (−15 mA), MCU 80 mA → datasheet value, relay 45 → 33 mA (4.5 V/75 % coil on 5V_SYS), 4.7 k I²C pull-ups (−1.6 mA). ΔIOS min ≈ 0.72 × Δ(non-analog).

| Non-analog max (mA) | R509 | Default IOS min/nom/max (mA) | R510 | High min/max (mA) |
|---|---|---|---|---|
| 230 | 121 k | 191/221/259 | 118 k | 392/504 |
| 240 | 127 k | 182/211/248 | 113 k | 391/503 |
| 250 | 133 k | 174/202/237 | 107 k | 395/507 |
| 260 | 140 k | 165/192/226 | 102 k | 396/510 |
| 270 | 147 k | 157/183/216 | 100 k | 393/506 |
| 280 | 154 k | 150/175/207 | 97.6 k | 392/504 |
| 300 | 169 k | 136/159/190 | 90.9 k | 396/509 |
| 323 (placeholders) | 196 k | 117/138/165 | 84.5 k | 396/509 |
(Full table 210–340 mA in `calc/c03_usb_budget_ilim.out.txt`.) R509/R510 are 0402 values on the same footprints: the final value is a BOM entry fixed at integration from the digital stream's datasheet maxima — no layout impact.

### 6.4 Suspend current (≤ 2.5 mA) — details
MCU Stop + PHY suspended 1.900 [PH]; D+ pull-up 3.35 V/(1.425 k + 14.25 k) = 0.214 [CALC] (brief: 0.2); TPS7A20 IGND at 2.2 mA 0.025; TPS25200 IQ 0.190 + EN 0.002 [DS]; VBUS divider 0.038; USBLC6 0.001 [ASSUMP]; TLV767 0.003, LP5907 0.001, TPS2553 0.001 (off) [DS]; discharge FETs/pull-ups 0 (drains at 0 V, EN low); A-to-C cable Rp 0.094 [ASSUMP] → **2.469 mA** (margin 31 µA) / **2.374 mA** without the cable Rp (126 µA). The MCU Stop maximum may be at most **1.931 mA** (worst cable). LEDs off; 5V_ANA off (PGOOD pull-up carries no current).

### 6.5 Suspend timeline (guaranteed) — c08
Sequence (firmware): (1) RELAY_EN low → wait t_rel,max; (2) MCLK_EN and family enables low (one SPI write); (3) AUD_EN and AVCC_EN low (EN-derived discharge starts; rails still up); (4) after 0.53 ms: RAIL_EN low (LM27762 off in µs), ANA_EN low, LEDs off; (5) MCU Stop.

| Trigger | RELAY_EN low | contacts open | AUD/AVCC_EN low | RAIL/ANA_EN low | suspend current | margin to 10 ms |
|---|---|---|---|---|---|---|
| **SOF-loss timer 1.0 ms (required rule)** | 1.02 ms | ≤ 6.02 ms | 6.04 ms | 6.57 ms | **≤ 6.62 ms** | **+3.38 ms** |
| suspend interrupt at 3.0 ms | 3.02 | ≤ 8.02 | 8.04 | 8.56 | ≤ 8.61 | +1.39 |
| suspend interrupt ≤ 4.0 ms (HS revert-to-FS) [ASSUMP] | 4.02 | ≤ 9.02 | 9.04 | 9.56 | ≤ 9.61 | +0.39 |

USB 2.0 §7.1.7.6: transition begins after > 3.0 ms idle; the device must draw only suspend current after no more than 10 ms of bus inactivity. With the SOF-loss rule t_rel may be up to 8.39 ms. Opening the relay after 1 ms without SOF is safe: isochronous audio has already stopped (no SOF = no data).

---

## 7. Power sequences (hardware facts the firmware must follow)

**Power-up after configuration:** ILIM_HI per CC → ANA_EN high → ≥ 5 ms → RAIL_EN high (EN ≤ VIN) → PGOOD good (RAILS_OK_N low, valid only now) → AVCC_EN high (VCCA/AVCC first, ESS p.27; the LP5907 output rises only after its discharge FET is off) → ≥ 1 ms → AUD_EN high (DVCC with/after VCCA; DVDD follows from 3V3D, so DVDD ≤ DVCC) → ≥ 2 ms → MCLK_EN → RESETB ≥ 1 ms after MCLK stable → DAC init → analog/DC checks (protection stream) → RELAY_EN.
**Controlled power-down / suspend / fault:** §6.5 order (relay first; rails last; 3V3A discharged while the rails still hold the I/V).
**RAILS_OK_N (round 2):** valid ≥ 20 ms after RAIL_EN; short 'not good' dips during High-mode peaks at VBUS 4.40 V are expected and are not overload — act only on ≥ 50 ms continuous (R2.13 D-i).
**Resume:** power-up sequence; the power part takes ≈ 10–15 ms (TPS2553 ton ≤ 3 ms + 5 ms rule + LM27762 start + LDO starts); total resume-to-audio is set by the protection stream's settling/DC checks.
**Unplug/brownout [superseded → R2.7]:** VBUS_SENSE < 4.00 V → RELAY_EN low + mute + orderly power-down; at a hard unplug 3V3M/3V3D/5V_ANA collapse together within tens of µs (the LDO pass devices track their inputs in dropout); unplug pop stays the protection/analog stream's measured target.
**Programming mode:** ~~AVCC_EN → AUD_EN with RESETB low; ANA_EN, RAIL_EN, RELAY_EN low; source must supply ≥ 300 mA (278 mA max).~~ → D-15: normal power-up through AUD_EN, RESETB low, MCLK off, switch open; 342.3 mA max, source ≥ 350 mA (R2.2 S5).
**MCU reset / IWDG:** all ENs fall to their pull-downs (R303, R508, R513, R506, R511) → every domain off and actively discharged; RELAY_EN pull-down (protection stream) opens the relay; U102 stays on (3V3M only).

---

## 8. Simplification — removed, changed, added

| Removed | Why |
|---|---|
| D102 (SMF6.0A DNF TVS) | cannot protect ≤ 6 V inputs (R8-A1); replaced by U102 clamp |
| R519, R520 (3V3D dropper) | TLV767 dissipates 0.50 W itself at TJ 98.6 °C |
| R521 (AUD_EN series) | TLV767 EN abs max 18 V independent of VIN |
| R307 (AVCC_EN series) | Q611 latch gone; LP5907 EN abs max 6 V independent of VIN |
| R524, R525 (bleeders) | replaced by guaranteed switched discharge (no standing current) |
| C504 (TLV767 output 1 µF) | redundant with C512 10 µF at the output |
| R514 (RILIM series part) | single-resistor RILIM |
| R515, R516, R523 / R517, R518 (FB top parts) | single 0.1 % resistors R501/R503 |
| D606, R638, FAULT → latch path | latch deleted; FAULT to MCU only (protection stream lists the latch parts) |
| DOM_DIS MCU line | discharge derived from the ENs |

Changed: C102 1 µF → 4.7 µF; C505 1 µF → 100 nF; U502/U504 ME6211 → TPS7A20/TLV767; R508 100 k → 47 k; R505 10 k → 100 k; R509/R510 → 196 k/84.5 k; R501–R504 → 221 k/100 k/205 k/100 k 0.1 %; U101 pin 5 → 5V_SYS; R105/R106 now on 5V_SYS.
Added (each earns its place): U102 (OVP), R108 (U102 ILIM), R109 (U102 EN), C103 (ADC acquisition), Q502–Q506 + R526–R530 (guaranteed discharge, 3 domains, no GPIO), R531/C513 DNF (damping fallback).
Net: 13 fitted parts and 1 DNF footprint (D102) removed; 14 fitted parts and 2 DNF footprints added; one GPIO freed (DOM_DIS); fitted cost of this stream's parts ≈ US$ 4.22 per board (unit prices in `bom_rows.csv`).

---

## 9. Component stress table (power-stream parts, worst operating point in any state) **[rows for U503, Q501, U303, J101, C301/C302 and the TLV767/LM27762 operating points superseded → R2.12]**

| Ref | Parameter | Worst case (state) | Rating | Margin |
|---|---|---|---|---|
| U102 TPS25200 | V_IN | 10.7 V hot-plug; ≤ 18.7 V hard-short kick (pessimistic) | 20 V abs [DS] | 9.3 V / 1.3 V |
| U102 | I_OUT / TJ | 832 mA (High) / 78.4 °C (clamping at 5.50 V) | IOS min 1011 mA, 2.6 A cont. / 125 °C | 22 % / 46.6 °C |
| U102 | EN | Zener-clamped (6.4 V typ, block-diagram note [DS-typ]) at 20 V IN via 300 k (45 µA) | 7 V abs | per TI §7.3.1 |
| C102 | V | 18.7 V peak | 25 V | 25 % |
| U101 | VBUS pin | 5.55 V | Transil VBR ≥ 6.0 V | 0.45 V |
| R101/R102 | P at CC short to 5.5 V | 5.9 mW | 62.5 mW | ×10 |
| R103/R104 | CC at 5.5 V → MCU pin | 0.19 mA injection, 0.4 mW | 62.5 mW (pin limit: digital stream) | — |
| R105/R106/C103 | V/P | 5.55 V, 0.14 mW; C103 1.8 V | 50 V / 62.5 mW / 50 V | large |
| R108/R109 | V/P | R109 13.6 V, 0.62 mW at a 20 V fault | 50 V / 62.5 mW | large |
| U502 TPS7A20 | V_IN / I / TJ | 5.55 V / 83.5 mA / 95.8 °C | 6.0 V op, 6.5 V abs / 300 mA / 125 °C | 0.45 V / ×3.6 / 29 °C |
| U504 TLV767 | V_IN / I / TJ | 5.55 V / 221 mA / 98.6 °C | 16 V op / 1 A / 125 °C | large / ×4.5 / 26 °C |
| U302 LP5907 | V_IN / I / TJ | 5.50 V in-spec (5.55 V clamp region) / 18.4 mA / 68.1 °C | 5.5 V op, 6.0 V abs / 250 mA / 125 °C | 0 V op (in-spec) / ×13 / 57 °C |
| U303 ME6216 | V_IN / I / Pd | 3.35 V / 60 mA (277 mA for < 0.1 ms during discharge) / 0.124 W | 6 V / 300 mA output, 390 mA abs / 0.30 W (25 °C) | large / ok / derated ok |
| U503 TPS2553 | V_IN / I / TJ | 5.55 V / 509 mA (limit) / 66.4 °C | 6.5 V op, 7 V abs / 1.2 A / 125 °C | 0.95 V / ×2.4 / 58.6 °C |
| U503 | short on 5V_ANA | 2.8 W → thermal cycling (135 °C) until firmware drops ANA_EN (FAULT deglitch ≤ 10 ms) | self-protected [DS] | by design |
| Q501 2N7002 | V_DS / I | ≤ 1 V / µA | 60 V / 115 mA | large |
| FB501 | I | 509 mA | 2 A | ×3.9 |
| U501 LM27762 | V_IN / EN / TJ | 5.55 V (in-spec 5.50) / ≤ VIN (R507) / ≤ 118.4 °C overload bound | 5.5 V op, 5.8 V abs / ≤ VIN / 125 °C | 0.25 V abs / — / 6.6 °C |
| C507, C509 | V | 5.55 V | 25 V | ×4.5 |
| C510 / C511 | V | 3.915 V / 3.781 V | 25 V | ×6 |
| C508 | V | 5.55 V | 50 V | ×9 |
| R501–R504 | V / P | ≤ 3.9 V / µW | 75 V / 100 mW | large |
| R505 / R522 | P | 0.30 mW / µW | 62.5 mW | large |
| Q502–Q506 AO3400A | V_DS / V_GS / I_D | 3.35 V / 3.35 V / ≤ 0.34 A pulses (Q503/Q505), ≤ 0.28 A (Q506), 152 µA (Q502/Q504) | 30 V / ±12 V / 30 A pulsed | large |
| R527/R529/R530 | pulse | ≤ 0.1 mJ per event, peak ≤ 1.2 W for < 50 µs; 0 W continuous | 0603 STOL 3.1 J | ×10⁴ |
| R526/R528 | P | 0.51 mW | 62.5 mW | large |
| C301, C501, C503 | V | 5.55 V | 50 V | ×9 |
| C502, C302, C311, C312, C512 | V | ≤ 3.35 V | 50 V (C512 25 V) | large |

---

## 10. Interface requests to other streams **[I1, I2, I7, I10 superseded → R2.13]**

| # | To | Request |
|---|---|---|
| I1 | Analog | Confirm V+: R501 = 221 k (3.789/3.852/3.915 V) is the default (inside the published VPOS range); 215 k gives 3.78 V class; 226 k (3.90 V class) needs global sourcing. \|VNEG\| 3.661–3.781 V. Use the §5.5 negative/positive peak-current envelopes (per VBUS corner, R_NEG 2.5/3.5/4.5 Ω). Re-issue the Default power table for IOS min 117 mA (placeholder case) and the §6.3 lookup values. PGOOD pull-up now draws 55 µA from 5V_ANA_F. |
| I2 | Digital | **Replace the placeholders with datasheet maxima** (MCU run/Stop, CPLD, X201/X202/X203). Default analog minimum of 175 mA needs non-analog ≤ 247 mA (now 323 mA): pick X201 ≤ 10 mA and X202/X203 with a true standby pin; MCU Stop max ≤ 1.93 mA keeps the suspend budget. |
| I3 | Digital (firmware) | (a) SOF-loss timer: no SOF for 1.0 ms → RELAY_EN low (suspend margin 3.38 ms; without it 0.39 ms). (b) Power sequences of §7 (RAIL_EN ≥ 5 ms after ANA_EN; EN low ≥ 1 ms before re-enable; MCLK_EN low before AUD_EN/AVCC_EN). (c) Keep the MCU at low clock, PLL/USBHS off, for ≥ 5 ms after reset (attach current < 100 mA). (d) ADC1 single channel on PA1 with C103 fitted, sampling ≥ 7.5 cycles; brownout watchdog at 4.00 V on 5V_SYS. (e) RAILS_OK_N valid only with ANA_EN = RAIL_EN = 1 and ≥ 20 ms after RAIL_EN. |
| I4 | Digital | PB4 must be FT (node ≤ 5.55 V through R522 10 k). DOM_DIS is **not needed** (net retired; one GPIO freed). RAIL_EN stays. |
| I5 | Digital | No EN/RELAY_EN/ILIM_HI line on a pin with a reset-default pull-up (R8-D7): with R508 47 k a 40 k pull-up would lift AUD_EN to 1.8 V (> TLV767 1.2 V) during reset. |
| I6 | Digital | 3V3M capacitance ≤ 5.1 µF nominal and no extra bulk on 5V_SYS (attach budget). Pull-up/enable resistor currents on 3V3M ≤ 0.5 mA total. |
| I7 | Protection | Relay coil: recommended 3 V coil on **3V3D** (must-operate margin +0.42 V hot; coil current ≤ 44.6 mA, used in the budget). On 5V_SYS only a coil with V_mo(23 °C) ≤ 3.64 V qualifies (e.g. 4.5 V ≤ 81 %, 5 V ≤ 73 %); a 5 V coil fails at 4.40 V. Guaranteed release ≤ 5 ms keeps the suspend margin; ≤ 8.39 ms is the limit with the SOF-loss rule. Coil must not be on 5V_SYS bulk-wise (no extra capacitance). |
| I8 | Protection | FAULT (ANA_FAULT_N) and PGOOD (RAILS_OK_N) reach the MCU only; a deep short collapses VPOS/VNEG and removes the relay permit in hardware. The 5V_ANA node has no discharge (not needed). |
| I9 | Parts | Verify J101 pad numbering vs contact names (netlist uses A1…B12, SH1–SH4); order R503 205 k 0.1 % early (LCSC 900 pcs); confirm classes marked "(not verified)". |
| I10 | Integration | Set R509/R510 from the §6.3 table once I2 is answered (BOM value only). |

---

## 11. Open items (measurements only) with designed-in fallbacks

| # | Item | Method | Designed-in fallback (no board change) |
|---|---|---|---|
| M1 | Attach inrush per USB-IF (#45) | current probe, 100 ms window, USBET | none needed (guaranteed ≤ 38.3 µC); if a region appears from the MCU start current → firmware rule I3(c) |
| M2 | LM27762 R_NEG / negative-rail headroom at 4.40 and 4.60 V | peak-current test at the High envelopes | ~~firmware VBUS-dependent volume ceiling (VBUS_SENSE); R503 value change (same footprint)~~ **[→ R2.14 M2 revised]** |
| M3 | LM27762 VIN ripple at light load | scope VIN and V+/V− | fit R531 1 Ω + C513 10 µF (DNF) if VIN > 200 mVpp or rails > 50 µVrms in-band |
| M4 | Discharge times and DVDD ≤ DVCC at power-down | scope 3V3A/AVCC_L, 3V3D, 1V3 | EN order/delays in firmware; R530 value |
| M5 | Suspend current vs time | USB meter + scope from the last SOF | SOF-loss timeout adjustable in firmware |
| M6 | **[→ M10]** ~~TPS2553 limits (Default/High) incl. Q501 leakage | electronic load on 5V_ANA | R509/R510 values (same footprints)~~ |
| M7 | Hot-plug at J101 / U102 IN | USB-A-to-C into a live port, scope C102 | none needed (≤ 11 V vs 20 V) |
| M8 | **[superseded: photorelays]** ~~Relay pick-up at 4.40 V, 50 °C (protection stream)~~ | chamber or heat gun | supply choice per I7 is the design fix; firmware can retry |

---

## 12. Sources (datasheet facts used) — round-2 additions in R2.16

| Part | Document, sections used | URL |
|---|---|---|
| TPS25200 | SLVSCJ0F Jul 2025: §4 pin table 4-1, §5.1 abs max (IN 20 V), §5.4 θJA 66.5, §5.5 V(OVC) 5.25–5.55 V, V(OVLO) 6.8–8.45 V, rDS(on) 99 mΩ, IIN(on) 190 µA, IIN(off) 5 µA, IEN 2 µA, EN 1.9/0.6 V; §5.6 tr 2.05/3.2 ms, ton 5.12/7.3 ms, t(OVLO) 0.6 µs, t(IOS) 3.5 µs; §7.3.1 EN pull-up 300 k; §8.2.2.3 Eq.1 | https://www.ti.com/lit/ds/symlink/tps25200.pdf |
| TPS2553 | SLVS841F: pin table, §7.1 (7 V), §7.3 (RILIM 15–232 k), §7.4 θJA 182.6, §7.5 (135 mΩ, IIN 120/140 µA, EN 0.66–1.1 V, FAULT 180 mV, deglitch 5–10 ms, ton/toff 3 ms), §9.5.1 Eq.(1), §10.2.1 Fig 24 | https://www.ti.com/lit/ds/symlink/tps2553.pdf |
| LM27762 | SNVSAF7C: Table 4-1 pins, §5.1 (VIN 5.8 V, EN ≤ VIN), §5.4 θJA 62.2, §5.5 (VFB±, R_NEG 2.5 Ω typ, dropout, VIH/VIL), §6.3.1–6.3.5, §7.1 PGOOD pull-up to VIN, §7.2.2.1 R2 ≥ 50 k | https://www.ti.com/lit/ds/symlink/lm27762.pdf |
| TPS7A20 | SBVS338H: DBV pinout, §5.1, §5.3, §5.4 θJA 187.1, §5.5 (±1.5 %, IGND 15 µA/2 mA, VDO 145 mV, VEN, UVLO), §5.6 tSTR | https://www.ti.com/lit/ds/symlink/tps7a20.pdf |
| TLV767 | SLVSE84D: Table 5-1 (DRV fixed pins), §6.1 (18 V), §6.3 (COUT 2.2–220 µF), §6.4 θJA 77.7, §6.5 (±1 %, VDO 1.4 V at 1 A DRV, IQ 95 µA, ISHDN 3 µA, VEN, EN pull-up) | https://www.ti.com/lit/ds/symlink/tlv767.pdf |
| LP5907 | §4 DBV pinout, §5.1 (VIN/VEN 6 V), §5.3, §5.4 θJA 193.4, §5.5 (±2 %, IQ, VDO 250 mV, VIL/VIH, RAD 230 Ω typ, tON), §5.6 (COUT 0.7–10 µF) | https://www.ti.com/lit/ds/symlink/lp5907.pdf |
| ME6216 | pin assignment, abs max (6.5 V, 390 mA, Pd 300 mW SOT23-3), EC at 25 °C | http://szyucan.com/upfile/IC-microne/ME6216.pdf ; LCSC C236662 |
| AO3400A | Rev 3.1 Jul 2023: VGS(th) 0.65–1.45 V, Rds(on) 48 mΩ at 2.5 V, IDSS, IGSS, Qg, pinout | https://www.aosmd.com/res/datasheets/AO3400A.pdf |
| 2N7002 (JSCJ) | VGS(th) ≤ 2.5 V, Rds(on) 5–7.5 Ω at 10 V, 60 V, 115 mA | https://www.lcsc.com/product-detail/C8545.html |
| USBLC6-2 | Rev 7: pinout, Table 2 (IRM 150 nA at 5.25 V, VBR ≥ 6 V) | https://www.st.com/resource/en/datasheet/usblc6-2.pdf |
| Omron G6K | coil table (3/4.5/5 V: 33.0/23.2/21.1 mA, 91/194/237 Ω, must-operate 80 %, max 150 %), notes 1–3, release 3 ms max | https://omronfs.omron.com/en_US/ecb/products/pdf/en-g6k.pdf |
| ES9018K2M | v3.7 p.7 (DVDD), p.27 power-up order, p.28 abs max and currents | local `current/ES9018K2M_datasheet_v3.7.txt` |
| USB-IF | Compliance Update #45 "Inrush Current Test Description" (Jun 2021) | https://compliance.usb.org/index.asp?updatefile=electrical&format=standard |
| USB inrush limit | 50 µC (10 µF at 5 V; USBET) | https://testusb.com/inrush_issue.htm ; http://www.epsilonlabs.com/USB_Inrush_I.html |
| USB 2.0 §7.1.7.6 | suspend: > 3.0 ms idle, suspend current after ≤ 10 ms (quoted) | https://forums.ni.com/t5/Multifunction-DAQ/Does-the-USB-DAQ-driver-support-selective-suspend/td-p/1498284 |
| Stock/class | JLCPCB/LCSC part pages (dates in `bom_rows.csv`) | per BOM row |

## 13. Files (updated round 2)

* `report.md` (this file), `bom_rows.csv` (59 lines, 70 parts: 67 fitted, 3 DNF), `netlist.csv` (206 pin rows, every pin incl. pads, NC and shell stakes).
* `calc/pw_common.py` (datasheet data with labels; round-2 block at the end), `c01_ovp_hotplug.*` (round 1, valid), `c02_attach_inrush.*`, `c03_usb_budget_ilim.*` (+ `c03_results.json`), `c04_regulators.*` (+ `c04_results.json`), `c05_fb501_damping.*`, `c06_discharge.*`, `c07_relay_coil.*` (round 1, superseded by D-1), `c08_suspend.*`, `c09_vbus_sense.*`, `c10_thermal.*`, **new** `c11_u503_tps2596.*`, `c12_u303_tlv758p.*`, `c13_j101_cc_pb4.*`, `c14_unplug_order.*` (+ `c14_results.json`), `gen_bom_netlist.*` (each `.py` with its `.out.txt`). Run order: c03 → c04 → c02, c05, c06, c08, c10–c14 → c09 → gen_bom_netlist.
* `calc/*.bak`: round-1 and interrupted round-2 versions kept for traceability (`c03_usb_budget_ilim_r1.py.bak`, `c03_usb_budget_ilim_r2a.*.bak`, `c04/c06/c09/c10_*_r1.*.bak`, `gen_bom_netlist_r1.py.bak`, `bom_rows_r1.csv.bak`, `netlist_r1.csv.bak`, `report_r1.md.bak`).
* `ds/*.txt`: raw text extracts of the fetched datasheets (evidence).
