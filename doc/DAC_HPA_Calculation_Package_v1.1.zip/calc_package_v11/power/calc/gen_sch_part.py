"""R8 round 3 (X-4): OUT->IN Schottky diodes - part data used by gen_bom_netlist.py. Locations from c14 round 3 (VOUT - VIN > 0.3 V
with the body diode only): U502 (3V3M -> 5V_SYS), U302 (3V3A -> 5V_SYS), U503 (5V_ANA -> 5V_SYS). U504 (-3 mV) and U303 (+5 mV) need none."""
SCH_PAIRS = {"D104": ("3V3A", "5V_SYS"), "D105": ("5V_ANA", "5V_SYS")}   # D103 deleted (E-16: U502 TPS70933 has reverse-current protection, VOUT abs 7 V)   # (anode = OUT, cathode = IN)
SCH_REFS = ", ".join(SCH_PAIRS)
SCH_DESC = ("Schottky OUT->IN reverse-voltage clamps (X-4): D104 across U302 (3V3A->5V_SYS),"
            " D105 across U503 (5V_ANA->5V_SYS); D103 deleted in E-16 (TPS70933 blocks reverse current)")
SCH_PKG = "SOT-23 (pin 1 A, 2 NC, 3 K)"
SCH_RATING = "30 V, 200 mA, VF <= 0.24/0.32/0.40/0.50/0.80 V at 0.1/1/10/30/100 mA, IR <= 2 uA at 25 V (25 C), Cd <= 10 pF"
SCH_MPN = "Nexperia BAT54,215"
SCH_LCSC = "C85084"
SCH_CLASS = "Extended"
SCH_STOCK = "LCSC C85084 (same type as analog D413/D414; VE consolidation)"
SCH_PINS = 3
SCH_PRICE = 0.02
SCH_URL = "https://assets.nexperia.com/documents/data-sheet/BAT54_SER.pdf"
SCH_PINMAP = [(1, "A", "A"), (2, "NC", "NC"), (3, "K", "K")]
