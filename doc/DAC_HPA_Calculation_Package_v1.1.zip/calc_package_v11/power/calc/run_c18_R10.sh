#!/bin/bash
# R10 F-3.9: c18 (release start model) on the final basis (c17_basis.json): the four release invocations from calc/, sequential, never
# parallel: rm out.txt, then "10 reduced", "470 reduced", "10 timing", "470 timing" (python3 -B, PYTHONDONTWRITEBYTECODE=1).
# Usage: run_c18_R10.sh [k]  (k = 1, default: fresh out.txt; k = 2..4: resume after an abort, appending from invocation k).
# Every run starts from a fresh `cd` of the absolute calc path (on this rclone mount a long-lived shell's cwd can go stale:
# getcwd() fails -> Python drops sys.path[0] -> "No module named 'pw_common'"), after a pre-flight import check (<= 10 min);
# one retry per run on that start error, abort on any other failure. Log: long_R10.log.
CALC=power/calc
LOG=$CALC/long_R10.log; ERR=$CALC/run_c18.err
export PYTHONDONTWRITEBYTECODE=1
log() { echo "$*" >> "$LOG"; }
fresh() { python3 -B -c "import os; os.getcwd()" 2>/dev/null || log "  runner cwd stale (getcwd failed) -> fresh cd"; cd "$CALC" || exit 1; }
preflight() {
  local i=0
  while [ $i -lt 60 ]; do fresh; python3 -B -c "import pw_common" 2>/dev/null && return 0; i=$((i+1)); sleep 10; done
  log "  pre-flight: pw_common not importable for 10 min"; return 1
}
run() {
  local try s rc d
  for try in 1 2; do
    preflight
    s=$(date +%s)
    timeout 3000 python3 -B c18_x8_rail_start.py "$@" > /dev/null 2> "$ERR"
    rc=$?; d=$(( $(date +%s) - s ))
    if [ $rc -eq 0 ]; then log "c18_x8_rail_start.py $* rc=0 ${d}s (end $(date -u +%H:%M:%S))"; return 0; fi
    log "c18_x8_rail_start.py $* try $try failed rc=$rc ${d}s: $(tail -1 "$ERR")"
    if [ $try -eq 1 ] && grep -q "No module named 'pw_common'" "$ERR"; then sleep 30; continue; fi
    return 1
  done
  return 1
}
K=${1:-1}
cd "$CALC" || exit 1
ARGS=("10 reduced" "470 reduced" "10 timing" "470 timing")
if [ "$K" -eq 1 ]; then
  log "start $(date -u +%H:%M:%S) c18 only (final F-1 basis, c17_basis.json), sequential, 1 retry on the pw_common import error"
  rm -f c18_x8_rail_start.out.txt; sleep 10
  [ -e c18_x8_rail_start.out.txt ] && { log "ABORT: c18_x8_rail_start.out.txt still present after rm"; exit 1; }
else
  log "resume $(date -u +%H:%M:%S) at c18 invocation $K (${ARGS[$((K-1))]}), appending to the existing out.txt; fresh cd + import check before every run"
fi
for ((j=K-1; j<4; j++)); do
  run ${ARGS[$j]} || { log "ABORT at c18 ${ARGS[$j]} (out.txt incomplete; backups *_preR10final*.bak)"; exit 1; }
done
rm -f "$ERR"
log "DONE $(date -u +%H:%M:%S)"
