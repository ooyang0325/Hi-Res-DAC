"""c08 - Suspend timeline (guaranteed bounds) and current (budget detail in c03 S6). R8 round 2: D-16 (SOF-loss timer 1.0 ms ->
RELAY_EN low -> wait 1.1 ms -> MCLK off -> domain order), photorelay switch open <= 1.01 ms after RELAY_EN low [protection p05],
discharge bounds from c06 (3V3A <= 0.39 ms, 3V3D <= 0.63 ms, 1V3 <= 0.13 ms), U503 TPS2596 turn-off delay 11.6 us typ [DS-typ]."""
from pw_common import *
out = []
P = out.append
T_SOF = 1.0e-3 + 20e-6          # [digital] SOF-loss timer + ISR latency [ASSUMP 20 us]
T_WAIT = 1.1e-3                 # [digital/D-16] wait after RELAY_EN low (>= protection bound 1.01 ms)
T_SPI = 2 * 32 / 9e6 + 1e-6     # [digital] two register writes at 9 MHz
T_A, T_D, T_1 = 0.385e-3, 0.630e-3, 0.134e-3   # [CALC c06]
T_RAIL_WAIT = 0.53e-3           # [digital] AUD_EN/AVCC_EN low -> RAIL_EN/ANA_EN low (>= T_A: rails held until 3V3A < 0.1 V)
T_STOP = 0.1e-3                 # [digital ASSUMP] Stop entry
T_U503_OFF = 11.6e-6 * 3        # [DS-typ x 3, ASSUMP bound] TPS2596 turn-off delay
P(hdr("Suspend sequence (firmware; digital stream implements) - all times from the last SOF"))
steps = [("SOF-loss timer expires + ISR", T_SOF), ("RELAY_EN low; wait (switch open <= 1.01 ms)", T_WAIT),
         ("SPI: MCLK_EN, OSC48_EN, OSC44_EN = 0; MCLK_PERMIT (PB14) low; DAC_RESETB low", T_SPI),
         ("AUD_EN + AVCC_EN low (one GPIOC write): TLV767, TLV758P, LP5907 off; discharges start", T_RAIL_WAIT),
         ("RAIL_EN, ANA_EN, ILIM_HI low, LEDs off (U503 FET off <= ~35 us)", T_U503_OFF),
         ("MCU Stop (USBHS PHY suspended)", T_STOP)]
t = 0.0
for n, dt in steps:
    t += dt
    P(f"  {t*1e3:6.3f} ms  {n}")
P(f"  -> suspend current reached <= {t*1e3:.2f} ms after the last SOF; margin {(10e-3-t)*1e3:+.2f} ms to 10 ms [CALC] (digital: 2.76 ms)")
P(f"  Checks: 3V3A < 0.1 V at <= {T_A*1e3:.2f} ms after AVCC_EN low, before RAIL_EN low at {T_RAIL_WAIT*1e3:.2f} ms (analog S6) - OK;"
  f" 1V3 falls before 3V3D (c06) - OK; 3V3D < 0.1 V <= {T_D*1e3:.2f} ms (<= 1 ms re-enable rule) - OK. The discharge energy comes from"
  " the rails' own capacitors, not from VBUS, so the USB current is at the suspend level as soon as the regulators are off.")
P("  Without the SOF-loss rule (controller suspend interrupt at 3.0-4.0 ms [ASSUMP]): add 2.0-3.0 ms -> <= 5.8 ms, margin >= 4.2 ms.")
P("  Suspend current: 2.47 mA worst (A-to-C cable Rp) / 2.38 mA (C-to-C) with the MCU placeholder 1.9 mA (c03 section 9).")
P("  RAIL_EN kept (round-1 D8): with the TPS2596 the analog load would also stop within ~12 us of ANA_EN low, so RAIL_EN is no longer"
  " needed for the suspend timing; it stays because it gives a defined LM27762 shutdown (50 k output pull-downs) independent of the"
  " 5V_ANA decay and the EN <= VIN rule at power-up (R507/R506). Removing it would save 2 resistors and a GPIO - not proposed now.")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
