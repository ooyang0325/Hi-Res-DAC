"""Shared data for the R8 power-stream calculations (Spec v0.9 / Notes v0.8 / Parts List v0.7).

Every number carries a label:
  [DS]     datasheet min/max (source key in SRC)
  [DS-typ] datasheet typical only
  [PH]     placeholder from brief Section 6 (other streams' parts)
  [ASSUMP] engineering assumption (reason given)
  [CALC]   computed in these scripts
All currents in A, voltages in V, resistances in ohm, capacitances in F, time in s.
"""
import math

SRC = {
    "TPS25200": "TI TPS25200 datasheet SLVSCJ0F (Jul 2025) https://www.ti.com/lit/ds/symlink/tps25200.pdf",
    "TPS2553": "TI TPS2553 datasheet SLVS841F https://www.ti.com/lit/ds/symlink/tps2553.pdf",
    "LM27762": "TI LM27762 datasheet SNVSAF7C https://www.ti.com/lit/ds/symlink/lm27762.pdf",
    "LP5907": "TI LP5907 datasheet https://www.ti.com/lit/ds/symlink/lp5907.pdf",
    "TPS7A20": "TI TPS7A20 datasheet SBVS338H (Jul 2024) https://www.ti.com/lit/ds/symlink/tps7a20.pdf",
    "TLV767": "TI TLV767 datasheet SLVSE84D (Jul 2021) https://www.ti.com/lit/ds/symlink/tlv767.pdf",
    "ME6216": "Microne ME6216 datasheet http://szyucan.com/upfile/IC-microne/ME6216.pdf (LCSC C236662)",
    "AO3400A": "AOS AO3400A datasheet Rev 3.1 Jul 2023 https://www.aosmd.com/res/datasheets/AO3400A.pdf",
    "2N7002": "JSCJ 2N7002 (LCSC C8545) https://www.lcsc.com/product-detail/C8545.html",
    "USBLC6": "ST USBLC6-2 datasheet Rev 7 https://www.st.com/resource/en/datasheet/usblc6-2.pdf",
    "G6K": "Omron G6K datasheet https://omronfs.omron.com/en_US/ecb/products/pdf/en-g6k.pdf",
    "ESS": "ESS ES9018K2M datasheet v3.7 (22 Apr 2021), local copy current/ES9018K2M_datasheet_v3.7.txt",
    "USBIF45": "USB-IF Compliance Update #45 'Inrush Current Test Description' (Jun 2021) "
               "https://compliance.usb.org/index.asp?updatefile=electrical&format=standard",
    "USB20_7176": "USB 2.0 spec 7.1.7.6 (quoted) https://forums.ni.com/t5/Multifunction-DAQ/"
                  "Does-the-USB-DAQ-driver-support-selective-suspend/td-p/1498284",
    "TESTUSB": "TestUSB inrush page https://testusb.com/inrush_issue.htm (50 uC limit)",
    "BRIEF6": "brief_r8_master.md Section 6 placeholders",
    # ---- R8 follow-up 1
    "TPS2596": "TI TPS2596xx datasheet SLVSET8A https://www.ti.com/lit/ds/symlink/tps2596.pdf (local ds/tps2596_fetch.txt)",
    "TMUX1101": "TI TMUX1101/TMUX1102 datasheet SCDS410D (Feb 2024) https://www.ti.com/lit/ds/symlink/tmux1101.pdf",
    "TLV758P": "TI TLV758P datasheet SBVS351D (Oct 2023) https://www.ti.com/lit/ds/symlink/tlv758p.pdf",
    "TPD2E2U06": "TI TPD2E2U06 datasheet SLLSEG9C (Dec 2019) https://www.ti.com/lit/ds/symlink/tpd2e2u06.pdf",
    "USB4105": "GCT USB4105 product page https://gct.co/connector/usb4105 (ratings, solder profile)",
    "MAX17608": "ADI MAX17608/9/10 datasheet https://www.analog.com/media/en/technical-documentation/data-sheets/MAX17608-MAX17610.pdf",
    "ORCH_FU1": "orchestrator R8 follow-up 1 (analog/digital/parts stream figures)",
}

# ---------------------------------------------------------------- operating conditions
VBUS_MIN, VBUS_DES, VBUS_MAX = 4.40, 4.60, 5.50       # [brief Sec. 5] receptacle
TA_MAX = 50.0                                         # [brief Sec. 5] ambient
T_LOCAL_RISE = 10.0   # [ASSUMP] local board heating near power parts above ambient

# ---------------------------------------------------------------- TPS25200 (U102, input OVP eFuse)
TPS25200 = dict(
    VIN_ABS=20.0,                 # [DS] 5.1 voltage on IN
    VOUT_ABS=7.0,                 # [DS] 5.1 OUT, EN, ILIM, FAULT
    VOVC_MIN=5.25, VOVC_MAX=5.55, # [DS] 5.5 V(OVC) OUT clamp (CL=1uF, RL=100R, VIN=6.5V)
    VOVLO_MIN=6.8, VOVLO_MAX=8.45,# [DS] 5.5 V(OVLO) IN rising
    T_OVLO_TYP=0.6e-6,            # [DS-typ, reference only] 5.6
    RON_MAX=0.099,                # [DS] 5.5 rDS(on) -40..125 C
    RON_MAX_85=0.090,             # [DS] 5.5 rDS(on) -40..85 C
    IQ_ON_MAX=190e-6,             # [DS] 5.5 IIN(on) VIN=5V, RILIM=150k (200 uA at 33k)
    IQ_ON_MAX_33K=200e-6,         # [DS]
    IQ_OFF_MAX=5e-6,              # [DS] IIN(off) VEN=0, VIN=5V
    IEN_MAX=2e-6,                 # [DS] EN leakage
    VEN_ON_MAX=1.9, VEN_OFF_MIN=0.6,  # [DS] EN thresholds
    UVLO_MAX=2.45,                # [DS]
    TR_TYP=2.05e-3, TR_MAX=3.2e-3,# [DS-typ]/[DS] OUT rise time (CL=1uF,RL=100R)
    TON_TYP=5.12e-3, TON_MAX=7.3e-3,  # [DS-typ]/[DS] turn-on time
    TOFF_MAX=0.3e-3,              # [DS]
    T_IOS_TYP=3.5e-6,             # [DS-typ, reference only] short-circuit response
    THETA_JA=66.5,                # [DS] 5.4 DRV (JEDEC)
    TSD_CL=135.0,                 # [DS] thermal shutdown in current limit
)
def tps25200_ios(r_k):
    """[DS] Eq.1 (8.2.2.3) IOS max/nom/min in A for RILIM in kOhm (33k..1100k)."""
    imax = (96754.0 / r_k ** 0.985 + 30.0) / 1000.0
    inom = (98322.0 / r_k ** 1.003) / 1000.0
    imin = (97399.0 / r_k ** 1.015 - 30.0) / 1000.0
    return imin, inom, imax

# ---------------------------------------------------------------- TPS2553 (U503, analog current limit)
TPS2553 = dict(
    VABS=7.0,                     # [DS] 7.1 IN, OUT, EN, ILIM, FAULT
    RON_MAX=0.135,                # [DS] 7.5 DBV -40..125 C
    IQ_ON_MAX_210K=120e-6, IQ_ON_MAX_20K=140e-6,  # [DS] 7.5
    IQ_OFF_MAX=1e-6,              # [DS]
    VEN_TH_MIN=0.66, VEN_TH_MAX=1.1,  # [DS] EN threshold
    FAULT_VOL_MAX=0.18,           # [DS] at 1 mA
    TOFF_MAX=3e-3, TON_MAX=3e-3,  # [DS] (CL=1uF, RL=100R)
    RILIM_MIN_K=15.0, RILIM_MAX_K=232.0,  # [DS] 7.3
    THETA_JA=182.6,               # [DS] 7.4 DBV
)
def tps2553_ios(r_k):
    """[DS] 9.5.1 Eq.(1): IOS max/nom/min (A) for RILIM in kOhm (15..232k), excl. resistor tolerance."""
    imax = 22980.0 / r_k ** 0.94 / 1000.0
    inom = 23950.0 / r_k ** 0.977 / 1000.0
    imin = 25230.0 / r_k ** 1.016 / 1000.0
    return imin, inom, imax

# ---------------------------------------------------------------- LM27762 (U501)
LM27762 = dict(
    VIN_ABS=5.8,                  # [DS] 5.1
    VIN_OP_MAX=5.5,               # [DS] operating input voltage
    VFBP_MIN=1.182, VFBP_MAX=1.218,   # [DS] 5.5
    VFBN_MIN=1.202, VFBN_MAX=1.238,   # [DS] 5.5 (magnitude)
    RNEG_TYP=2.5,                 # [DS-typ] output resistance to CPOUT, VIN=5.5V, 100 mA
    VLDO_N_TYP=0.030, VLDO_P_TYP=0.045,  # [DS-typ] dropout at 100 mA
    IQ_TYP=390e-6, ISD_MAX=5e-6,  # [DS-typ]/[DS]
    VEN_IH=1.2, VEN_IL=0.4,       # [DS]
    UVLO_FALL_TYP=2.4, UVLO_RISE_TYP=2.6,  # [DS-typ] 6.3.1
    THETA_JA=62.2,                # [DS] 5.4
    TJ_OP_MAX=125.0,
    R2_MIN=50e3,                  # [DS] 7.2.2.1 R2 >= 50 k
)

# ---------------------------------------------------------------- LDOs
TPS7A20 = dict(   # U502 3V3M (TPS7A2033PDBVR)
    VIN_ABS=6.5, VIN_OP_MAX=6.0, VEN_ABS=6.5,          # [DS] 5.1/5.3
    ACC=0.015,                                          # [DS] DBV VOUT>=2.8V, over line/load/temp
    IGND0_MAX_85=10e-6, IGND0_MAX_125=15e-6,            # [DS] no load
    IGND300_MAX=2000e-6,                                # [DS] at 300 mA
    VDO300_MAX=0.145,                                   # [DS] DBV 3.3V at 300 mA
    ICL_MIN=0.360,                                      # [DS]
    VEN_HI_MAX=0.9, VEN_LO_MIN=0.3,                     # [DS]
    COUT_EFF_MIN=0.47e-6, COUT_EFF_MAX=200e-6,          # [DS] 5.3
    THETA_JA=187.1,                                     # [DS] DBV
    TSTR_TYP=750e-6, TSTR_MAX=1150e-6,                  # [DS-typ]/[DS]
)
TLV767 = dict(    # U504 3V3D (TLV76733DRVR)
    VIN_ABS=18.0, VEN_ABS=18.0,                         # [DS] 6.1
    VIN_OP_MAX=16.0,
    ACC=0.01,                                           # [DS] over temp, 1mA..1A, VIN>=3V
    LOADREG_MAX_PER_A=0.005,                            # [DS] 0.5 %/A
    VDO_1A_MAX_DRV=1.4,                                 # [DS] DRV at 1 A
    IQ_MAX=95e-6,                                       # [DS] fixed, no load
    IGND_1A_TYP=1.5e-3,                                 # [DS-typ]
    ISHDN_MAX=3e-6,                                     # [DS] VIN=16V
    VEN_HI_MAX=1.2, VEN_LO_MIN=0.4,                     # [DS]
    IEN_PULLUP_TYP=400e-9,                              # [DS-typ] internal pull-up
    ICL_MIN=1.1,                                        # [DS]
    COUT_NOM_MIN=2.2e-6, COUT_NOM_MAX=220e-6, COUT_EFF_MIN=0.5e-6,  # [DS] 6.3
    THETA_JA=77.7,                                      # [DS] DRV
    TSS_TYP=500e-6,                                     # [DS-typ]
)
LP5907 = dict(    # U302 3V3A (LP5907MFX-3.3)
    VIN_ABS=6.0, VEN_ABS=6.0,                           # [DS] 5.1
    VIN_OP_MAX=5.5,                                     # [DS] 5.3
    ACC=0.02,                                           # [DS] VIN=VOUT+1V..5.5V, 1..250 mA
    IQ0_MAX=25e-6, IQ250_MAX=425e-6, IQ_OFF_MAX=1e-6,   # [DS]
    VDO250_MAX=0.250,                                   # [DS] SOT-23
    VIL=0.4, VIH=1.2,                                   # [DS]
    COUT_EFF_MIN=0.7e-6, COUT_EFF_MAX=10e-6,            # [DS] 5.6
    CIN_EFF_MIN=0.7e-6,
    RAD_TYP=230.0,                                      # [DS-typ] auto-discharge
    THETA_JA=193.4,                                     # [DS] DBV
    TON_MAX=150e-6,                                     # [DS]
)
ME6216 = dict(    # U303 1V3 (ME6216A13M3G)
    VIN_ABS=6.5, IOUT_ABS=0.390, PD_SOT23_3=0.300,      # [DS] abs max
    ACC=0.01,                                           # [DS] 25 C only
    IQ_MAX=8e-6,                                        # [DS]
    ISHORT_TYP=0.030, ISHORT_MAX=0.060,                 # [DS] foldback short-circuit current
    ILIMIT_TYP=0.420,                                   # [DS-typ]
    TOPR_MAX=85.0,                                      # [DS]
)

# ---------------------------------------------------------------- small parts
AO3400A = dict(VDS=30.0, VGS_ABS=12.0, VTH_MIN=0.65, VTH_MAX=1.45,
               RDS_2V5_MAX=0.048, RDS_4V5_MAX=0.032,
               RDS_TEMP_125=38.0 / 26.5,       # [DS] ratio 125 C / 25 C at 10 V (applied to 2.5 V spec)
               IDSS_55C_MAX=5e-6, IGSS_MAX=100e-9,
               CISS_TYP=630e-12, QG_4V5_TYP=6e-9, QG_4V5_MAX=7e-9,
               RTHJA=125.0)                    # [DS]
N2N7002 = dict(VDS=60.0, VTH_MAX=2.5, RDS_10V_MAX=7.5, ID_MAX=0.115)   # [DS] JSCJ C8545
USBLC6 = dict(VBR_MIN=6.0, IRM_MAX_525=150e-9)  # [DS] Table 2
ESS_DAC = dict(AVCC_ABS=4.7, DVDD_ABS=1.8, DVDD_NOM=1.3, DVDD_TOL=0.05,
               DVCC_NOM_I=14.2e-3, DVDD_NOM_I=50e-3, VCCA_I=0.8e-3, AVCC_I=8.0e-3)  # [DS-typ] "current nominal"

# ---------------------------------------------------------------- MLCC (existing Basic parts)
def cap(nom, tol):
    return dict(nom=nom, lo=nom * (1 - tol), hi=nom * (1 + tol))
# upper bounds (charge/discharge time): nominal x (1+tol), no DC-bias credit  [ASSUMP conservative]
# lower bounds (stability/damping): nominal x (1-tol) x temp 0.85 x DC-bias factor below [ASSUMP]
DCBIAS = {  # [ASSUMP] conservative effective-capacitance factors at the stated bias (Samsung curves not extracted)
    ("1u50V0603", 5.5): 0.80, ("1u50V0603", 3.3): 0.90,
    ("10u25V0805", 5.5): 0.55, ("10u25V0805", 3.3): 0.70, ("10u25V0805", 4.0): 0.65,
    ("4u7_25V0805", 5.5): 0.60,
    ("2u2_6V3_0402", 3.3): 0.45, ("2u2_6V3_0402", 1.3): 0.75,
    ("100n16V0402", 3.3): 0.90,
}
TEMP_X5R = 0.85   # [ASSUMP] X5R/X7R +-15 % over temperature

def e96():
    base = [100,102,105,107,110,113,115,118,121,124,127,130,133,137,140,143,147,150,154,158,162,165,169,174,
            178,182,187,191,196,200,205,210,215,221,226,232,237,243,249,255,261,267,274,280,287,294,301,309,
            316,324,332,340,348,357,365,374,383,392,402,412,422,432,442,453,464,475,487,499,511,523,536,549,
            562,576,590,604,619,634,649,665,681,698,715,732,750,768,787,806,825,845,866,887,909,931,953,976]
    return base

def hdr(title):
    return "\n" + "=" * 100 + "\n" + title + "\n" + "=" * 100


# =============================================================================== R8 follow-up 1 additions
# ---------------------------------------------------------------- TPS2596 (U503 new: TPS259621DDAR, OV clamp option, auto-retry)
TPS2596 = dict(
    VIN_ABS=21.0, VEN_ABS=7.0, VFLT_ABS=7.0, VDVDT_ABS=2.5,      # [DS] 7.1 ; OUT abs max = min(21, VIN + 0.3)
    VIN_OP_MIN=2.7, VIN_OP_MAX=19.0,                              # [DS] 7.3
    RILM_MIN=453.0, RILM_MAX=7869.0,                              # [DS] 7.3 ILM pin resistance range
    RON_TYP=0.089, RON_MAX=0.131,                                 # [DS-typ title] / [DS] Ron max (VIN > 4 V) - see report
    IQ_ON_MAX=266e-6, IQ_ON_TYP=206e-6,                           # [DS] 7.5 TPS25962x (VIN 12 V test condition)
    ISD_MAX=1.132e-6,                                             # [DS] VIN >= 4 V, EN < VSD
    VUVLO_R_MIN=1.18, VUVLO_R_MAX=1.22, VSD_MIN=0.53, VSD_MAX=1.05,   # [DS] EN/UVLO rising, shutdown threshold
    VUVP_R_MIN=2.46, VUVP_R_MAX=2.58,                             # [DS] IN undervoltage protection
    GIMON_013_MIN=531.22e-6, GIMON_013_TYP=653.21e-6, GIMON_013_MAX=800.0e-6,   # [DS] A/A at IOUT 0.13 A
    IDVDT_MIN=1.89e-6, IDVDT_MAX=2.33e-6, GDVDT_MIN=20.31, GDVDT_MAX=21.5,     # [DS] dVdt charging current / gain
    SR_OPEN_5V_TYP=42.7e3,                                        # [DS-typ] V/s with CdVdt open, 5 V
    T_LIM_TYP=87e-6, T_SC_TYP=5e-6,                               # [DS-typ] current-limit / short-circuit response
    FAST_CLAMP_RATIO=1.5,                                         # [DS] 8.3.3.3 fast clamp above 1.5 x ILIM
    TSD_TYP=157.0, T_RETRY_TYP=95e-3,                             # [DS-typ]
    THETA_JA=52.7,                                                # [DS] DDA, exposed pad soldered
    VCLAMP_OPEN_MIN=13.13,                                        # [DS] OVCSEL open (13.8 V option) clamp min
)
# [DS] 7.5 current-limit table (TJ -40..125 C, VIN = 12 V, VDS = 0.5 V; the 7.87 k row is TA -40..80 C):
TPS2596_ILIM_TABLE = [  # (R_ILM ohm, min A, typ A, max A)
    (7870.0, 0.113, 0.125, 0.139), (3830.0, 0.224, 0.247, 0.269), (909.0, 0.949, 1.005, 1.051), (453.0, 1.83, 2.004, 2.147)]
TPS2596_HEADLINE_ACC = 0.104      # [DS] feature list: +-10.4 % max across the current range
def tps2596_inom(r_ohm):
    """[DS] Eq.5 inverted: ILIM(A) = 903 / R_ILM + 0.0112."""
    return 903.0 / r_ohm + 0.0112
def tps2596_acc(i_nom):
    """[CALC] guaranteed relative limits (lo, hi) at a nominal ILIM, linear interpolation in ILIM of the DS table
    limits normalised to the Eq.5 nominal (outside the table: end values)."""
    pts = []
    for r, lo, ty, hi in TPS2596_ILIM_TABLE:
        n = tps2596_inom(r)
        pts.append((n, lo / n - 1.0, hi / n - 1.0))
    pts.sort()
    if i_nom <= pts[0][0]:
        return pts[0][1], pts[0][2]
    for (n0, l0, h0), (n1, l1, h1) in zip(pts, pts[1:]):
        if n0 <= i_nom <= n1:
            f = (i_nom - n0) / (n1 - n0)
            return l0 + f * (l1 - l0), h0 + f * (h1 - h0)
    return pts[-1][1], pts[-1][2]
def tps2596_ios(r_nom, tol=0.001 + 25e-6 * 35, r_series_max=0.0, mode="interp"):
    """[CALC] (min, nom, max) current limit in A for a nominal R_ILM (ohm) with resistor tolerance+TCR (0.1 % + 25 ppm x
    35 K = 0.19 %), optional extra series resistance range (0..r_series_max, e.g. switch Ron)."""
    inom = tps2596_inom(r_nom)
    lo, hi = tps2596_acc(inom) if mode == "interp" else (-TPS2596_HEADLINE_ACC, TPS2596_HEADLINE_ACC)
    imin = tps2596_inom(r_nom * (1 + tol) + r_series_max) * (1 + lo)
    imax = tps2596_inom(r_nom * (1 - tol)) * (1 + hi)
    return imin, inom, imax

# ---------------------------------------------------------------- TMUX1101 (U505, Default/High ILM switch)
TMUX1101 = dict(VDD_MIN=1.08, VDD_MAX=5.5, VDD_ABS=6.0, VSEL_ABS=6.0,     # [DS] 6.1/features
                RON_MAX_3V3_85=9.5, RON_MAX_5V_85=4.5,                     # [DS] 6.6 / 6.5 (-40..85 C)
                IOFF_MAX_85=0.3e-9, IOFF_MAX_125=0.9e-9,                   # [DS] 6.5 IS(OFF)/ID(OFF) (VDD 5 V)
                IDD_TYP=3e-9,                                              # [DS-typ] 25 C (max over temp not legible in extract)
                VIH_MAX_5V=1.49, VIL_MIN_5V=0.87, ISEL_MAX=0.06e-6)        # [DS] 6.5 logic (VDD 5 V)
AO3400A_IDSS_BOUND = 5e-6   # [DS] IDSS at VDS 30 V, 55 C (the only guaranteed off-state figure)

# ---------------------------------------------------------------- TLV758P (U303 new: TLV75801PDBVR, adjustable)
TLV758P = dict(VIN_ABS=6.5, VEN_ABS=6.5, VFB_ABS=2.0,                       # [DS] 5.1 ; VOUT abs max = VIN + 0.3 V
               VIN_OP_MIN=1.5, VIN_OP_MAX=6.0,                              # [DS] 5.3
               VFB=0.55, ACC_85=0.01, ACC_125=0.015,                         # [DS] 5.5 output accuracy (resistors excluded)
               LINE_REG_MAX=7.5e-3, LOAD_REG_TYP=0.030,                      # [DS] mV max / [DS-typ] V/A
               IGND_MAX=35e-6, ISHDN_MAX=1e-6, IFB_MAX=0.1e-6,               # [DS]
               ICL_MIN=0.530, VDO_500_12_15=0.400,                          # [DS] current limit, dropout 1.2 <= VOUT < 1.5 V
               UVLO_R_MIN=1.21, UVLO_R_MAX=1.47, UVLO_F_MIN=1.17, UVLO_F_MAX=1.42,   # [DS]
               VEN_HI_MAX=1.0, VEN_LO_MIN=0.3, IEN_TYP=10e-9,                # [DS] / [DS-typ]
               RPD_TYP=95.0,                                                 # [DS-typ] VIN = 6 V (no min/max)
               TSTR_TYP=500e-6, COUT_EFF_MIN=0.47e-6, COUT_MAX=220e-6,       # [DS-typ] / [DS]
               THETA_JA=176.9)                                               # [DS] DBV
def tlv758p_vout(r1, r2, tol, tj85=True, iout=0.060):
    """[CALC] VOUT min/nom/max: VFB accuracy, R1/R2 tolerance (incl. TCR), IFB x R1, line reg (max), load reg (2 x typ)."""
    acc = TLV758P["ACC_85"] if tj85 else TLV758P["ACC_125"]
    k_lo = 1 + r1 * (1 - tol) / (r2 * (1 + tol)); k_hi = 1 + r1 * (1 + tol) / (r2 * (1 - tol))
    extra = TLV758P["IFB_MAX"] * r1 + TLV758P["LINE_REG_MAX"] + 2 * TLV758P["LOAD_REG_TYP"] * iout
    vmin = TLV758P["VFB"] * (1 - acc) * k_lo - extra
    vmax = TLV758P["VFB"] * (1 + acc) * k_hi + TLV758P["IFB_MAX"] * r1 + TLV758P["LINE_REG_MAX"]
    return vmin, TLV758P["VFB"] * (1 + r1 / r2), vmax

# ---------------------------------------------------------------- TPD2E2U06 (U103 new, CC1/CC2 ESD)
TPD2E2U06 = dict(VRWM=5.5, IRWM_MAX=10e-6, VIO_OP_MAX=5.5, VBR_MIN=6.5, ILEAK_2V5_MAX=10e-9,   # [DS] 6.3/6.5
                 CL_TYP=1.5e-12, CL_MAX=1.9e-12, IPP=5.5, PPP_DRL=85.0, THETA_JA=286.8)        # [DS]
# ---------------------------------------------------------------- GCT USB4105-GF-A (J101 new)
USB4105 = dict(V_RATED=48.0, I_VBUS=5.0, I_GND=6.25, I_B5=1.25, I_OTHER=0.25, R_CONTACT_MAX=0.040,   # [DS] GCT page
               T_OP_MAX=85.0, T_SOLDER_PEAK=255.0, T_SOLDER_PLUS=5.0, T_SOLDER_S=5.0)              # 255 C (-0/+5) max 5 s
# ---------------------------------------------------------------- output switch (protection stream) - PhotoMOS
PHOTOMOS = dict(I_LED_5VSYS_PH=0.013,        # [PH] orchestrator: LED string current max on 5V_SYS
                I_GATE_3V3M_ASSUMP=0.0001,   # [ASSUMP] two NMOS gate pull-downs driven from 3V3M
                I_DRAFT_5VSYS=0.0143, I_DRAFT_3V3M=0.00102,   # [protection p05 draft] two current-limited strings
                T_OFF_MAX=0.5e-3, T_ON_MAX=5e-3)              # [orchestrator / DS TLP3545A]


# =============================================================================== R8 round 2 (25 Sep 2026) - decisions_r8b.md D-1..D-18
SRC.update({
    "DEC_R8B": "integration/decisions_r8b.md (orchestrator decisions D-1..D-18 and load table, 25 Sep 2026)",
    "PROT_R1": "protection/report.md round 1 (3.4 drive, 6 DC-sense networks, 12 requests) and p05/p06 outputs",
    "ANA_R1": "analog/report.md round 1 (9 quiescent split, 14 sequencing S1-S9) and scripts/analog_budget.py",
    "DIG_R2": "digital/firmware_sequences_output.txt, levels_and_pullups_output.txt, mclk_gate_race_output.txt, pin_tables_output.txt",
    "PARTS_FU": "parts/followup_r8.md Follow-up 1 and 2; parts/web/fu3_sources.txt (Follow-up 3 sources, in progress)",
    "GCT_DRW": "GCT USB4105 drawing (Oct 2019, rev B 29/04/21) text layer via https://www.mouser.com/datasheet/2/837/USB4105-1948910.pdf,"
               " https://www.mouser.com/datasheet/2/837/usb4105-2448855.pdf, https://s3.amazonaws.com/snapeda/datasheet/USB4105-GF-A_GCT.pdf"
               " (gct.co/files/drawings/usb4105.pdf itself blocked)",
    "TLV758P_EC": "TI TLV758P SBVS351D 5.5 EC table (local ds/tlv758p_fetch.txt)",
    "LCSC_R2": "LCSC part pages C861444, C861384, C326733, C728581 (read 24/25 Sep 2026); JLCPCB C1852057, C2155774 (parts FU3)",
})
# ---- TPS2596 (U503) additions [DS SLVSET8A unless labelled]
TPS2596.update(dict(
    VUVP_F_MIN=2.36, VUVP_F_TYP=2.42, VUVP_F_MAX=2.46,          # [DS] IN UVP falling
    VUVLO_F_MIN=1.08, VUVLO_F_MAX=1.13,                          # [DS] EN/UVLO falling
    IEN_MAX=0.1e-6,                                              # [DS] EN leakage
    IFLT_LKG_MAX=1e-6, RFLT_TYP=11.52,                           # [DS] FLT leakage at 6 V; [DS-typ] pull-down when asserted
    VOVC_400K=(5.54, 5.69, 5.83), VCLAMP_400K=(5.28, 5.45, 5.61), # [DS] OVCSEL 400 k to GND
    VOVC_OPEN=(12.97, 13.77, 14.52), VCLAMP_OPEN=(13.13, 13.58, 13.97),  # [DS] OVCSEL open
    TD_ON_5V=(78.9e-6, 247.3e-6), TR_5V=(94.1e-6, 311.0e-6),     # [DS-typ] 7.7 (CdVdt open / 3300 pF), ROUT 100 R, COUT 1 uF
    SR_5V=(42.7e3, 13.1e3),                                      # [DS-typ] V/s (open / 3300 pF)
    TD_OFF_5V_TYP=11.6e-6,                                       # [DS-typ]
    TSD_HYS_TYP=11.5, T_OVC_TYP=5e-6, ICB_TYP=1.5,               # [DS-typ]
    DVDT_PIN_ABS=2.5, DVDT_CAP_VRATING_MIN=4.0,                  # [DS] 7.1 / 7.3
    VEN_ROC_MAX=6.0, VFLT_ROC_MAX=6.0,                           # [DS] 7.3
    C_DVDT_INT_EST=44.16e-6 / 42.7e3,                            # [CALC] internal dVdt capacitance from the 'open' SR (~1.03 nF)
))
TPS2596_FAULT_TABLE = [  # [DS] Table 3 Fault Response
    ("Overtemperature shutdown", "shut down, auto-retry (x1)", "FLT asserted"),
    ("Undervoltage cut-off (UVP)", "off", "no FLT"),
    ("Overvoltage clamp (TPS25962x)", "clamp", "no FLT"),
    ("Overcurrent - current limit", "regulates at ILIM", "no FLT"),
    ("Short-circuit current limit", "fast clamp > 1.5 x ILIM, then regulates", "no FLT"),
    ("ILM pin short to GND", "shut down", "FLT asserted"),
    ("ILM pin open", "shut down", "no FLT")]
# ---- LM27762 additions
LM27762.update(dict(UVLO_FALL_NOTE="[DS-typ] 6.3.1 'forces the device into shutdown if VIN drops to 2.4 V; resumes above 2.6 V' (no min/max)",
                    R_PD_SHDN=50e3,          # [DS-typ] 6.1/6.4.1 internal 50 k pull-down on OUT+ and OUT- in shutdown
                    ILIM_IN_TYP=0.500,       # [DS-typ] 6.3.2 input current limit (output shorted)
                    TSD_TYP=150.0, TSD_REL_TYP=130.0))
# ---- TLV758P (U303) additions [DS SBVS351D 5.5]
TLV758P.update(dict(RPD_TYP_6V=95.0, ICL=(0.530, 0.720, 0.865), ISC_TYP=0.350, LINE_REG_TYP=2e-3,
                    IGND_25C_MAX=31e-6, VDO_500_12_15=(0.285, 0.400),
                    PINS={1: "IN", 2: "GND", 3: "EN", 4: "FB", 5: "OUT"}))
# ---- other LDO behaviour at unplug [DS]
TLV767.update(dict(UVLO_R_TYP=2.2, UVLO_R_MAX=2.4, UVLO_F_TYP=1.9, IPULLDOWN_TYP=1.2e-3,   # [DS] / [DS-typ]
                   REVERSE="body diode, not limited [DS 9.1.4]"))
TPS7A20.update(dict(UVLO_F_DBV=(1.11, 1.3, 1.55), RPD_TYP=150.0, REN_PD_TYP=500e3, IEN_MAX=250e-9,
                    REVERSE="body diode; limit to 5 % of rated current [DS 6.3.x]"))
LP5907.update(dict(VIN_FUNC_MIN=2.2, REVERSE="not stated in the extract"))
# ---- TMUX1101 (U505) [DS SCDS410D 6.6, VDD = 3.3 V +-10 %]
TMUX1101.update(dict(RON_MAX_3V3_25=8.8, RON_MAX_3V3_125=9.8, IOFF_3V3_85=0.2e-9, IOFF_3V3_125=0.9e-9,
                     ION_LKG_3V3_85=0.35e-9, IDD_MAX_125=0.65e-6, VIH_3V3=1.35, VIL_3V3=0.8, ISEL_MAX_3V3=0.05e-6,
                     VSD_ABS_OVER_VDD=0.5, PINS={1: "D", 2: "S", 3: "GND", 4: "SEL", 5: "VDD"},
                     THETA_JA_DBV=224.9, LCSC="C1852057"))
# ---- TPD2E2U06 (U103) [DS SLLSEG9C]
TPD2E2U06.update(dict(PINS_DRL={1: "NC", 2: "NC", 3: "IO1", 4: "GND", 5: "IO2"}, VBR_MAX=8.5, VC_1A=9.7, VC_5A=12.4,
                      VRWM_TEST_I=10e-6))
# ---- GCT USB4105-GF-A (J101): pad map from the GCT drawing (text layer), 'Recommended PCB Layout, as viewed from component side'
USB4105_PADS = [  # (pad label on the GCT drawing, contacts carried, signal) - left to right
    ("A1/B12", ("A1", "B12"), "GND"), ("A4/B9", ("A4", "B9"), "VBUS"), ("B8", ("B8",), "SBU2"), ("A5", ("A5",), "CC1"),
    ("B7", ("B7",), "Dn2"), ("A6", ("A6",), "Dp1"), ("A7", ("A7",), "Dn1"), ("B6", ("B6",), "Dp2"), ("A8", ("A8",), "SBU1"),
    ("B5", ("B5",), "CC2"), ("B4/A9", ("B4", "A9"), "VBUS"), ("B1/A12", ("B1", "A12"), "GND")]
USB4105.update(dict(V_RATED_DRAWING=20.0, CYCLES_DRAWING=10000, N_SMT=12, N_SHELL_THT=4, N_NPTH_PEG=2))
# ---- protection-stream loads (D-1, D-9, D-10; protection p05/p06)
PROT = dict(I_LED_5VSYS=0.0143, I_DRIVE_3V3M=0.00102, I_3V3A=0.00182, I_TLV1704_POS=0.00126, I_TLV1704_NEG=0.00125,
            R_S=6.8e3, R_U=5.1e3, R_D=16.9e3, C_N=4.7e-6, CM_SUM_MAX=14e-6, T_SW_OFF=1.01e-3)
# ---- digital-stream loads (D-3, load table)
DIG = dict(I_MCU=0.080, I_LED_G=0.00080, I_LED_R=0.00073, I_MCU_PD_ASSUMP=0.000567, I_R234=0.00033, I_R233=0.000032,
           I_CPLD=0.040, I_X201=0.0065, I_NDK_RUN=0.015, I_NDK_STBY=0.000035, I_U205=0.0047, I_U206_MISC=0.0029,
           I_X201_STBY=2.7e-6, T_X201_STOP=100e-9, I_OSC_EN_PD=3.35 / 10e3)
# ---- X201 update (parts Follow-up 3 message, 25 Sep 2026 05:45): Epson SG-210STF 75 MHz not procurable (all codes EOL);
#      replacement Kyocera KC2520K80.0000C1GE00 [DS Kyocera K-series Ver. E via parts]: 80.000 MHz, 1.6-3.63 V, Icc 8.0 mA max
#      (2.8-3.63 V, 62.5-80 MHz, max 15 pF load, over temperature), stand-by 5 uA max, disable 200 ns max, start-up 3 ms max.
DIG.update(dict(I_X201=0.0080 + 0.00017,      # [DS Kyocera, loaded] + R227 10 k pull-down 0.17 mA [digital]
                I_X201_STBY=5e-6, T_X201_STOP=200e-9, X201_VCC_MIN=1.6,
                I_X201_NDK=0.0124,            # [ASSUMP parts] NDK NSC5338D-80M second source (9 mA at 25 C + CV^2f)
                I_X201_EPSON=0.0065))         # [D-3] budget of the non-procurable Epson part (reference only)
# ---- D-3 revised / D-19 (orchestrator, 25 Sep 2026 05:54, binding)
DIG.update(dict(I_X201=0.0082,               # [D-3 revised] Kyocera KC2520K80 Icc <= 8.0 mA (15 pF, over temperature) + R227
                I_X201_NDK=0.0127,           # [D-3 revised] conditional second source NDK NSC5338D-80M budget
                I_R235=3.333 / (100e3 * 0.99)))   # [CALC D-19] R235 100 k pull-down on N2_MCLK_OE (U206 output, 3V3D) while MCLK runs
# ---- analog round 2 final (orchestrator, 25 Sep 2026 06:01, binding)
ANA_FINAL = dict(I_Q=0.07030,        # [CALC analog] guaranteed 5V_ANA quiescent 0-50 C (TLV1704, new DC-sense, CP 1.03 [PH], LM27762 1.0 mA [ASSUMP])
                 I_Q_RESET=0.08485,  # [CALC analog] while the DAC is in reset (start-up, programming mode D-15)
                 NEED=0.1756,        # [CALC analog] Default IOS min for all Default targets (32 ohm: 37.6 mW at 175 mA, 41.0 mW at 180 mA)
                 I_VCCA=0.0029,      # [ASSUMP analog] VCCA at 80 MHz, scaled from ESS 0.8 mA at 22 MHz (+2.1 mA vs D-10)
                 RNEG_MAX_32=2.38, RNEG_MAX_60=2.26, RNEG_NOCLIP=6.7)   # [CALC analog] VBUS 4.40 V High-mode headroom
# ---- protection round 2 (message 25 Sep 2026 06:13; D-1 'unless recomputed'): op-amp current sink U604 OPA2333 (3V3D)
PROT.update(dict(I_LED_5VSYS=0.01320,     # [CALC protection r2] LED strings, RELAY_EN high
                 I_DRIVE_3V3M=0.00010,    # [CALC protection r2] 3V3M share, RELAY_EN high
                 I_DRIVE_3V3D=0.00032,    # [CALC protection r2] 3V3D share (reference divider / sink), RELAY_EN high
                 I_U604_3V3D=0.000056,    # [DS/CALC protection r2] OPA2333 quiescent whenever 3V3D is up
                 I_TLV1704_POS_R2=0.001244, I_TLV1704_NEG_R2=0.001231))   # [CALC protection r2] permitted (<= D-9)
# ---- analog round 2 report values (analog message 25 Sep 2026 06:29; owner's final, >= the orchestrator's rounded 70.30/84.85 mA)
ANA_FINAL.update(dict(I_Q=0.07032, I_Q_RESET=0.08501,   # [CALC analog r2] I+ 34.50 / I- 33.75 mA split; DAC in reset (comparators tripped)
                      NEED_HIGH=0.317,                  # [CALC analog r2] rated-target High-mode analog peak
                      RNEG_PGSAFE_32=3.14, RNEG_PGSAFE_60=2.99, RNEG_DEF32=3.51, RNEG_460_ALL=3.55, VNEG_MIN_300=3.625))

# =============================================================================== R8 round 3 (25 Sep 2026) - decisions_r8c.md X-1..X-10
SRC.update({
    "DEC_R8C": "integration/decisions_r8c.md (review-fix decisions X-1..X-10, 25 Sep 2026)",
    "SMDJ12A": "Littelfuse SMDJ12A product page https://www.littelfuse.com/products/overvoltage-protection/tvs-diodes/surface-mount/smdj/smdj12a"
               " and DigiKey 1835309 (VRWM 12 V, VBR 13.3-14.7 V @ 1 mA, VC 19.9 V @ 150.8 A 10/1000 us, IR 2 uA @ VR, dVBR 0.1 %/K)",
    "BAT54": "Nexperia BAT54 series data sheet https://assets.nexperia.com/documents/data-sheet/BAT54_SER.pdf",
    "PMEG2005AEL": "Nexperia PMEG2005AEL data sheet Rev 03 (15 Jan 2010) https://assets.nexperia.com/documents/data-sheet/PMEG2005AEL.pdf",
})
SMDJ12A = dict(VRWM=12.0, VBR_MIN=13.3, VBR_MAX=14.7, VC=19.9, IPP=150.8, IR_VRWM_25C=2e-6, TC_VBR=0.001, PPK=3000.0,
               C_BOUND_ASSUMP=10e-9)                                                       # [DS] / capacitance [ASSUMP]
BAT54 = dict(VR=30.0, IF=0.2, VF_MAX=((1e-4, 0.24), (1e-3, 0.32), (1e-2, 0.40), (3e-2, 0.50), (1e-1, 0.80)),
             IR_MAX_25V_25C=2e-6, CD_MAX=10e-12, PINS={1: "A", 2: "NC", 3: "K"})             # [DS Nexperia]
PMEG2005AEL = dict(VF_MAX=((1e-4, 0.060), (1e-3, 0.110), (1e-2, 0.190), (1e-1, 0.290), (0.5, 0.440)),
                   IR_10V_25C=(210e-6, 600e-6), CD_1V=(19e-12, 25e-12))                       # [DS] typ/max
TPS25200.update(dict(VEN_RISE_MAX=1.9, VEN_FALL_MIN=0.6, IEN_BOUND=2e-6))                     # [DS 5.5] EN (no rising minimum)


# ---------------------------------------------------------------- R10 (F-3): one current input set for the release calculations
R509_REL, R510_REL = 4750.0, 3740.0      # R509 4.75 k 0.1 % owner-fitted (E-18), R510 3.74 k 0.1 % (round 3)
def released_limits():
    """[CALC] TPS2596 (DEF, HIGH) limits in A (min, nom, max) for R509_REL / R510_REL: Eq. 5 + headline +-10.4 % [DS],
    R 0.1 % + 25 ppm x 35 K, U505 RON 0..9.5 ohm in the High branch (same formulas as c17)."""
    d = tps2596_ios(R509_REL, mode="headline")
    rp = lambda a, b: a * b / (a + b)
    ron = TMUX1101["RON_MAX_3V3_85"]
    rmin = rp(R509_REL * 0.9981, R510_REL * 0.9981); rmax = rp(R509_REL * 1.0019, R510_REL * 1.0019 + ron)
    h = ((903 / rmax + 0.0112) * (1 - TPS2596_HEADLINE_ACC), 903 / rp(R509_REL, R510_REL) + 0.0112,
         (903 / rmin + 0.0112) * (1 + TPS2596_HEADLINE_ACC))
    return list(d), list(h)
def load_basis(here):
    """R10: the final load/limit basis written by c17 (c17_basis.json, c03 format, units A); falls back to the round-2 c03_results.json.
    Run order: c03 -> c17 -> consumers (c04, c10, c11, c14, c15, c16, c18)."""
    import json as _j, os as _o
    p = _o.path.join(here, "c17_basis.json")
    if _o.path.exists(p):
        return _j.load(open(p))
    return _j.load(open(_o.path.join(here, "c03_results.json")))
def basis_line(R):
    return ("BASIS: " + R.get("BASIS", "round-2 inventory c03_results.json (R510 3.83 k) - no c17_basis.json found")) 

def u502_bypass(R):
    """[CALC] R10: since E-16 U502 (TPS70933) is fed from VBUS ahead of U102 -> its input current (3V3M load + IGND, S2 set) does not flow
    through the TPS25200 RON; it still flows through J101 and the input copper. 0 on the round-2 basis (U502 on 5V_SYS)."""
    return R["IN_S2"]["3V3M"] if R.get("BASIS", "").startswith("R10") else 0.0
