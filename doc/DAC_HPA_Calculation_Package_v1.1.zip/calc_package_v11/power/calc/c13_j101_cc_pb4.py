"""c13 - J101 GCT USB4105-GF-A pad map (GCT drawing text layer), U103 TPD2E2U06DRLR on CC1/CC2 (leakage at a CC short to
5.55 V, effect on the CC ADC readings), R532 470 k pin-side pull-down on PB4 / RAILS_OK_N (digital FT data) in both states."""
from pw_common import *
out = []
P = out.append
P(hdr("1. J101 GCT USB4105-GF-A: USB-C contact names -> GCT pad labels -> nets"))
P("  Source: GCT drawing 'Recommended PCB Layout, as viewed from component side' + pin/signal table (Oct 2019 / rev B 29-04-21) read"
  " from the text layer of the Mouser and SnapEDA copies; gct.co/files/drawings/usb4105.pdf itself is blocked for this tool.")
P("  The drawing labels pads by contact name (no numeric pad numbers): 12 SMT pads in one row, left to right, 4 wide (0.60 mm) +"
  " 8 narrow (0.30 mm); 4 shell stakes (plated, THT) and 2 NPTH locating-peg holes (d 0.65 mm).")
NETS = {"GND": "GND", "VBUS": "VBUS", "CC1": "CC1", "CC2": "CC2", "Dp1": "USB_DP", "Dp2": "USB_DP", "Dn1": "USB_DN",
        "Dn2": "USB_DN", "SBU1": "NC", "SBU2": "NC"}
for pad, contacts, sig in USB4105_PADS:
    P(f"   pad {pad:7s} contacts {'+'.join(contacts):8s} signal {sig:5s} -> net {NETS[sig]}")
P("   shell stakes x4 (drawing: 'SHELL GND', not numbered) -> net N1_SHIELD (R107 0 ohm to GND, C101 DNF) - netlist pins S1..S4")
P("   locating pegs x2: plastic, NPTH, no net (not netlist pins)")
P("  Contact names checked against the USB Type-C pin-out: A1/A12/B1/B12 GND, A4/A9/B4/B9 VBUS, A5 CC1, B5 CC2, A6/B6 D+, A7/B7 D-,"
  " A8/B8 SBU - identical to the GCT table (which also gives the mating sequence: GND/VBUS first, signals second).")
P(f"  Ratings [GCT page]: 48 V DC (the 2019/2021 drawing still says 20 V DC), VBUS 5 A collectively, GND 6.25 A, B5 1.25 A, others"
  f" 0.25 A per pin; contact resistance 40 mOhm max initial; -40..85 C; solder peak 255 C (-0/+5) max 5 s -> JLCPCB Standard PCBA"
  f" (240 +- 5 C) OK (D-14); shell stakes are THT (hand/selective solder step).")
P("  Remaining pre-layout action (R8-A10, unchanged): continuity-check two samples against this map before the footprint is frozen.")

P(hdr("2. U103 TPD2E2U06DRLR (SOT-5X3 'DRL') at J101"))
P("  Pins [DS SLLSEG9C 5]: 1 NC, 2 NC (floating, grounded or VCC allowed), 3 IO1 -> CC1, 4 GND, 5 IO2 -> CC2; place at J101, GND pin"
  " with its own via.")
vr, vbr, i_vr, i_br = TPD2E2U06["VRWM"], TPD2E2U06["VBR_MIN"], TPD2E2U06["VRWM_TEST_I"], 1e-3
def ileak(v):
    """[CALC/ASSUMP] exponential interpolation between the two guaranteed points (5.5 V, < 10 uA) and (VBR min 6.5 V, 1 mA)."""
    return i_vr * (i_br / i_vr) ** ((v - vr) / (vbr - vr))
v_sh = 5.55
P(f"  Ratings: VRWM {vr} V (IIO < 10 uA), VBR {vbr}-{TPD2E2U06['VBR_MAX']} V at 1 mA, ILEAK <= 10 nA at 2.5 V, VIO ROC 0-5.5 V, CL 1.5"
  " typ / 1.9 max pF, IEC 61000-4-2 +-25 kV contact, 5.5 A 8/20 us [DS].")
P(f"  CC short to {v_sh} V: {v_sh - vr:+.2f} V above VRWM, {vbr - v_sh:.2f} V below VBR min -> no breakdown; leakage <= {ileak(v_sh)*1e6:.1f} uA"
  f" (bound; the datasheet guarantees only < 10 uA at 5.5 V), {v_sh*ileak(v_sh)*1e6:.0f} uW -> no stress; VIO ROC exceeded by 50 mV"
  " only in this fault.")
R_D, R_S = 5.1e3, 10e3
P("  Effect on the CC ADC readings (CC -> R103/R104 10 k -> CC1_ADC/CC2_ADC, ADC2 scan, D-13):")
for vcc in (0.41, 0.92, 1.68, 2.5):
    e = TPD2E2U06["ILEAK_2V5_MAX"] * R_D
    P(f"    normal, CC {vcc:.2f} V (Rp source through Rd 5.1 k): leakage <= 10 nA -> error <= {e*1e6:.0f} uV at CC (< 0.1 LSB) - negligible")
inj = (v_sh - 3.35 - 0.3) / R_S
P(f"    CC shorted to {v_sh} V: the node is forced by the short, the TVS leakage does not change it; the reading saturates at full scale"
  f" (> vRd-3.0 max 2.18 V) -> firmware must classify CC > 2.3 V as 'invalid/fault' (Default mode, no High); R101/R102 dissipate"
  f" {v_sh**2/R_D*1e3:.1f} mW (62.5 mW); the ADC pin clamp takes <= {inj*1e3:.2f} mA through R103/R104 (digital stream: confirm the CH32V307"
  " injection limit and that it does not disturb the ADC2 DC-sense channels) [not verified].")
P("  Capacitance 1.9 pF max per CC line vs the Type-C sink cReceiver 200-600 pF window -> negligible.")

P(hdr("3. R532 470 k pull-down at PB4 (RAILS_OK_N), with R505 100 k to 5V_ANA_F and R522 10 k from N5_PGOOD (digital FT data)"))
VIH, VIL, LKG, VMAX, VABS = 1.756, 0.934, 3e-6, 5.0, 5.5     # [digital levels_and_pullups] worst VDD 3.0-3.6 V
R505, R522, R532 = 100e3, 10e3, 470e3
def pb4_released(v5, tol=0.01, lk=+LKG):
    ra = (R505 + R522) * (1 + tol if lk < 0 else 1 - tol); rb = R532 * (1 - tol if lk < 0 else 1 + tol)
    vth = v5 * rb / (ra + rb); rth = ra * rb / (ra + rb)
    return vth + lk * rth
lo = pb4_released(4.20, lk=-LKG); hi = pb4_released(5.55, lk=+LKG)
P(f"  PGOOD released (rails not good), 5V_ANA_F 4.20..5.55 V: PB4 {lo:.2f} .. {hi:.2f} V with 1 % resistors and 3 uA leakage in the worst"
  f" direction -> 'high' needs >= {VIH} V (margin {lo-VIH:+.2f} V) and <= {VMAX} V FT operating (margin {VMAX-hi:+.2f} V; abs {VABS} V)")
v5_edge = (VIH + LKG * (R505 + R522) * R532 / (R505 + R522 + R532)) * (R505 + R522 + R532) / R532
P(f"  ... still reads 'not good' down to 5V_ANA_F = {v5_edge:.2f} V (the LM27762 UVLO is 2.4 V typ -> below ~2.2 V the reading is"
  " undefined, as with 5V_ANA off: firmware validity rule ANA_EN = RAIL_EN = 1 and >= 20 ms, R8-C4).")
i_pg = 5.55 / R505
v_lo = LKG * (R522 * R532 / (R522 + R532))
P(f"  PGOOD low (rails good): PB4 = VOL(PGOOD) + {v_lo*1e3:.0f} mV; needs <= {VIL} V -> PGOOD may have VOL <= {(VIL-v_lo)*1e3:.0f} mV at"
  f" {i_pg*1e6:.0f} uA sink (LM27762 PGOOD VOL is not specified [DS] - an open-drain NMOS at 56 uA is typically < 50 mV) [not verified].")
P(f"  Currents: rails good 55.5 uA (R505, in the analog quiescent); rails not good <= {5.55/(R505+R522+R532)*1e6:.1f} uA; 5V_ANA off 0.")
P("  -> R532 = 470 k (<= 560 k digital limit) verified in both states.")

P(hdr("4. C301 / C302 -> 2.2 uF 16 V X5R 0603 (C23630, D-8 / parts P-M2)"))
P("  LP5907 CIN/COUT >= 0.7 uF effective over all conditions [DS 5.6]: C301 >= 1.04 uF at 5.5 V, 3V3A total >= 3.84 uF, upper bound"
  " 7.59 uF <= 10 uF (c04); attach charge +1.32 uF on 5V_SYS compensated by deleting C503 (c02: 39.5 uC, 21 % margin); 3V3A discharge"
  " <= 0.39 ms (c06).")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
