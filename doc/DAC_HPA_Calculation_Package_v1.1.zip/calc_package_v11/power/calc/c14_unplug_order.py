"""c14 - Unplug ordering (the lost round-2 item): behavioural time-domain model of every rail after the USB source disappears.
Cases: (a) hard unplug, no firmware action (MCU runs until 3V3M < its reset threshold, then every EN falls to its pull-down);
(b) firmware brown-out action at VBUS_SENSE 4.00 V (C103 10 nF, D-13): ADC1 watchdog + ISR (31 us) -> MCLK_PERMIT (PB14) low,
RELAY_EN low, AVCC_EN + AUD_EN low (one GPIOC write); RAIL_EN/ANA_EN left high; (b') the same without C103 (sensitivity).
Checks: digital requirement max(3V3D - 3V3A) while MCLK can run (<= 0.3 V); DVDD - DVCC; analog requirement: I/V rails
(VPOS - VNEG >= 4.5 V, OPA2210 minimum supply) while 3V3A >= 0.3 V.
Model (all [ASSUMP] where the datasheets give no curve): LDOs = ideal regulators with resistive dropout (TPS7A20 0.48, TLV767 1.4,
LP5907 1.0, TLV758P 0.8 ohm from the VDO maxima), reverse current through a body diode (0.6 V / 0.5 ohm) [TI DS statements] or, as a
variant, LP5907 reverse through its channel (1 ohm) [not stated in its DS]; UVLO/active pull-downs at their typical values [DS-typ];
TPS2596 switch 131 mOhm (bidirectional while on), off below UVP 2.42 V typ; TPS25200 off below 2.30 V (reverse blocking);
LM27762: positive LDO 0.45 ohm, charge pump 2.5 ohm, negative LDO 0.30 ohm, UVLO 2.4 V typ, 50 k pull-downs in shutdown;
digital/CMOS loads proportional to their supply; op-amp/comparator quiescent scaled with the total supply (0 below 1 V);
headphone load treated as a DC equivalent at the limit (Default/High max); U206 (74LVC1G11 on 3V3D) passes ST high only while
the MCU outputs exceed its VIH (2.0 / 1.7 / 0.65 x VCC); X201 (Kyocera KC2520K80, 1.6-3.63 V, disable <= 200 ns) assumed to
oscillate down to 1.65 V (conservative for the check).
Capacitances: c02/c04/c06 bounds (low = effective, high = +10 % without DC-bias credit). Initial state: VBUS 5.00 V, steady."""
import json, os, itertools
import numpy as np
from pw_common import *

out = []
P = out.append
R = load_basis(os.path.dirname(os.path.abspath(__file__)))   # R10 F-3: final basis from c17 (c17_basis.json), else round-2 c03
DMAX, HMAX = R["DEF"][2], R["HIGH"][2]
IQP, IQN = R["IP"], R["IN"]

CAPSETS = {  # C_B, C_5, C_M, C_D, C_1, C_A, C_AN, C_P(=C_N), C_CP
    "all-low":   (1.2e-6, 2.1e-6, 3.3e-6, 7.4e-6, 2.28e-6, 3.84e-6, 5.0e-6, 15.6e-6, 4.2e-6),
    "all-high":  (2.42e-6, 3.6e-6, 5.8e-6, 15.2e-6, 3.63e-6, 7.59e-6, 12.1e-6, 33.8e-6, 11e-6),
    "dig-stress": (1.8e-6, 2.8e-6, 4.5e-6, 15.2e-6, 3.63e-6, 3.84e-6, 8.5e-6, 24.7e-6, 7.6e-6),   # 3V3D holds, 3V3A falls fast
    "ana-stress": (1.8e-6, 2.8e-6, 4.5e-6, 11.3e-6, 2.95e-6, 7.59e-6, 5.0e-6, 15.6e-6, 4.2e-6)}   # rails fall fast, 3V3A holds
LOADS = {"idle (S2)": 0.0, "Default max": DMAX, "High max": HMAX}
MCU_I = {"MCU 84 mA": 0.0840, "MCU 25 mA": 0.025}
REV = ("body-diode", "LP5907-channel")
PDR = (1.8, 2.3)                     # [ASSUMP] CH32V307 reset threshold range (not in the digital data)
FW = ("a: none", "b: 4.00 V, C103 100 pF", "b': 4.00 V, no C103")
grid = list(itertools.product(CAPSETS, LOADS, MCU_I, REV, PDR, FW))
n = len(grid)
def col(i, m=None):
    return np.array([m[g[i]] if m else g[i] for g in grid])
C = np.array([CAPSETS[g[0]] for g in grid]).T
C_B, C_5, C_M, C_D, C_1, C_A, C_AN, C_P, C_CP = C
X8 = os.environ.get("C14_X8", "1") == "1"     # R3 follow-up: analog X-8 I/V rails (D411/D412 PMEG2010AEH, C442/C443 220 uF polymer)
CRES_SET = {"all-low": 176e-6, "all-high": 264e-6, "dig-stress": 220e-6, "ana-stress": 176e-6}
C_RES = np.array([CRES_SET[g[0]] for g in grid])
I_IVP, I_IVN = (0.0174, 0.0148) if X8 else (0.0, 0.0)          # [analog X-8] OPA2210 + I/V networks, moved to the I/V rails
I_IVLK = 1e-3 if X8 else 0.0                                   # [analog ASSUMP] D411/D412 reverse leakage during hold-up
def sch_iv(v):                                                 # [ASSUMP fit] PMEG2010AEH-class forward characteristic
    v = np.maximum(v, 0.0); i = np.zeros_like(v)
    for _ in range(3):
        i = 1.0e-5 * np.expm1(np.clip((v - i * 0.10) / 0.026, -50, 60)); i = np.minimum(i, v / 0.10)
    return np.where(X8, i, 0.0)
I_ANA = np.array([LOADS[g[1]] for g in grid]); I_M0 = np.array([MCU_I[g[2]] for g in grid])
REVCH = np.array([g[3] == "LP5907-channel" for g in grid]); VPDR = np.array([g[4] for g in grid])
FWK = np.array([FW.index(g[5]) for g in grid])
TAU_S = np.where(FWK == 1, 31.97e3 * 112e-12, 31.97e3 * 12e-12)     # R3 X-10: C103 100 pF C0G (+12 pF pin) vs pin only
I_HP = np.maximum(0.0, (I_ANA - R["I_ANA_Q"]) / 2.03)                # per-rail DC-equivalent headphone load
I_D0 = R['RO_S2']['3V3D'] - 0.060; I_10 = 0.060; R_A = 3.3 / R['RO_S2']['3V3A']   # 3V3D direct, DVDD, 3V3A resistive (c03 S2 maxima)
K_S = 47.0 / 147.0; VTH_BO = 4.00

dt, T = 0.05e-6, (4.0e-3 if X8 else 3.0e-3)
V = {}
V5_0 = 5.0 - (R["NONANA"] + I_ANA) * 0.099
VB = np.full(n, 5.0); V5 = V5_0.copy(); VM = np.full(n, 3.30); VD = np.full(n, 3.30); V1 = np.full(n, 1.30); VA = np.full(n, 3.30)
VAN = V5 - I_ANA * 0.131; VP = np.full(n, 3.852); VN = np.full(n, 3.721); VCP = VAN - (IQN + I_HP) * 2.5; VS = K_S * V5
VGA = np.zeros(n); VGD = np.zeros(n)
VPI = np.where(X8, 3.852 - 0.22, 0.0); VNI = np.where(X8, 3.721 - 0.22, 0.0)
run = np.ones(n, bool); acted = np.zeros(n, bool); t_act = np.full(n, np.nan); t_rst = np.full(n, np.nan)
u102 = np.ones(n, bool); lm_on = np.ones(n, bool); u503 = np.ones(n, bool)
mclk = np.ones(n, bool); t_mclk_off = np.full(n, np.nan)
worst_da = np.full(n, -9.0); worst_1d = np.full(n, -9.0); da_stop = np.full(n, np.nan); vd_stop = np.full(n, np.nan)
t_r45 = np.full(n, np.nan); t_a03 = np.full(n, np.nan); va_at_r45 = np.full(n, np.nan)
names = ("5V_SYS", "3V3M", "3V3D", "1V3", "3V3A", "VPOS", "VNEG")
init = {"5V_SYS": V5_0.copy(), "3V3M": 3.3, "3V3D": 3.3, "1V3": 1.3, "3V3A": 3.3, "VPOS": 3.852, "VNEG": 3.721}
t90 = {k: np.full(n, np.nan) for k in names}; t10 = {k: np.full(n, np.nan) for k in names}
def ldo(vin, vout, vset, rdo, load, cout, on):
    g = 0.3 * cout / dt
    i = load + g * (vset - vout)
    return np.where(on, np.clip(i, 0.0, np.maximum(0.0, (vin - vout) / rdo)), 0.0)
def diode(va, vb):                   # current a -> b through a body diode
    return np.maximum(0.0, (va - vb - 0.6) / 0.5)
SCH = os.environ.get("C14_SCHOTTKY", "1") == "1"   # R3 X-4: external Schottky OUT->IN (D103 U502, D104 U504, D105 U302, D106 U303, D107 U503)
VT_N, IS_S, RS_S = [float(x) for x in os.environ.get("C14_SCH_PAR", "0.0347,9.9e-8,3.0").split(",")]    # [CALC fit] BAT54-class maxima: VF <= 0.32 V at 1 mA, 0.40 V at 10 mA, 0.50 V at 30 mA, 0.80 V at 100 mA
def schottky(va, vb):
    v = np.maximum(va - vb, 0.0)
    i = np.zeros_like(v)
    for _ in range(3):                               # I = Is exp((V - I Rs)/(n Vt)), fixed-point on the series drop
        i = IS_S * np.expm1(np.clip((v - i * RS_S) / VT_N, -50, 60))
        i = np.minimum(i, v / RS_S)
    return np.where(SCH, i, 0.0)
def vih_u206(vd):
    return np.where(vd >= 2.7, 2.0, np.where(vd >= 2.3, 1.7, 0.65 * vd))
REVMAX = {k: np.full(n, -9.0) for k in ("U502", "U504", "U302", "U303", "U503")}
ISMAX = {k: np.zeros(n) for k in REVMAX}
steps = int(T / dt)
for k in range(steps):
    t = k * dt
    # --- MCU and firmware
    rst_now = run & (VM < VPDR)
    t_rst[rst_now] = t; run &= ~rst_now
    det = (FWK > 0) & np.isnan(t_act) & (VS * 3.3 / np.maximum(VM, 0.1) < K_S * VTH_BO)   # E-16: ratiometric to VDDA = 3V3M
    t_act[det] = t + 31e-6
    act_now = run & ~acted & (t >= t_act)
    acted |= act_now
    cmd = acted
    en_hi = run & ~cmd                               # AVCC_EN, AUD_EN, MCLK_PERMIT, RELAY_EN
    en_v = np.where(en_hi, VM, 0.0)
    ana_v = np.where(run, VM, 0.0)                   # ANA_EN / RAIL_EN stay high in (b)
    # --- MCLK
    st = en_hi & (VM >= vih_u206(VD)) & (VD >= 1.65)
    stop_now = mclk & ~st
    t_mclk_off[stop_now] = t; da_stop[stop_now] = (VD - VA)[stop_now]; vd_stop[stop_now] = VD[stop_now]; mclk &= st
    # --- U102
    u102 &= VB >= 2.30
    i_u102 = np.where(u102, (VB - V5) / 0.099, 0.0)
    # --- loads
    i_m = np.where(run, I_M0, 0.003) * VM / 3.3
    i_d = I_D0 * np.clip(VD / 3.3, 0, 1.1)
    i_1 = np.where(mclk, I_10, 0.005) * np.clip(V1 / 1.3, 0, 1.1)
    i_a = VA / R_A
    led = np.where(en_hi, PROT["I_LED_5VSYS"] * np.clip((V5 - 3.0) / 1.1, 0, 1), 0.0) + 0.3e-3
    f = np.clip((VP + VN - 1.0) / 3.5, 0.0, 1.0)
    i_p_load = (IQP - I_IVP + I_HP) * f; i_n_load = (IQN - I_IVN + I_HP) * f
    fiv = np.clip((VPI + VNI - 1.0) / 3.5, 0.0, 1.0)
    i_dp = sch_iv(VP - VPI); i_dn = sch_iv(VN - VNI)
    lk_p = np.where(VPI > VP, I_IVLK * np.clip((VPI - VP) / 1.0, 0, 1), 0.0); lk_n = np.where(VNI > VN, I_IVLK * np.clip((VNI - VN) / 1.0, 0, 1), 0.0)
    # --- regulators
    on_m = VB >= 2.5                                 # E-16: U502 TPS70933 fed from VBUS [ASSUMP UVLO ~2.5 V]
    i_mp = ldo(VB, VM, 3.3, 13.0, i_m, C_M, on_m)     # [DS] VDO 650 mV max at 50 mA -> 13 ohm resistive dropout (conservative)
    on_d = (en_v >= 0.8) & (V5 >= 1.9)
    on_1 = VD >= 1.29                                      # R3 X-4: U303 EN tied to its IN (3V3D) -> UVLO only
    i_1p = ldo(VD, V1, 1.30, 0.8, i_1, C_1, on_1)
    i_dp = ldo(V5, VD, 3.3, 1.4, i_d + i_1p, C_D, on_d)
    on_a = (en_v >= 0.8) & (V5 >= 2.0)          # [ASSUMP] LP5907 not functional below 2.2 V [DS 6.4.2]
    i_ap = ldo(V5, VA, 3.3, 1.0, i_a, C_A, on_a)
    u503 &= (ana_v >= 1.13) & (V5 >= 2.42)
    i_an = np.where(u503, np.minimum((V5 - VAN) / 0.131, np.where(I_ANA > 0.3, HMAX, DMAX)), 0.0)
    lm_on = np.where(lm_on, VAN >= 2.4, VAN >= 2.6)          # R3 X-1: EN+/EN- = VIN (5V_ANA_F), UVLO only
    i_pp = ldo(VAN, VP, 3.852, 0.45, i_p_load, C_P, lm_on)
    i_cp = np.where(lm_on, np.maximum(0.0, (VAN - VCP) / 2.5), 0.0)
    i_np = ldo(VCP, VN, 3.721, 0.30, i_n_load, C_P, lm_on)
    # reverse / pull-downs
    s_m = schottky(VM, V5); s_d = schottky(VD, V5); s_1 = schottky(V1, VD); s_an = schottky(VAN, V5); s_a = schottky(VA, V5)
    s_m = s_m * 0.0; r_m = s_m                       # E-16: TPS70933 reverse-current protection, D103 deleted
    r_d = diode(VD, V5) + s_d; r_1 = diode(V1, VD) + s_1; r_an = np.where(u503, 0.0, diode(VAN, V5)) + s_an
    r_a = np.where(REVCH, np.maximum(0.0, (VA - V5) / 1.0), diode(VA, V5)) + s_a
    pd_m = np.zeros(n)                               # TPS70933: no active output discharge
    pd_d = np.where(~on_d & (V5 >= 1.0), 1.2e-3, 0.0)
    pd_1 = np.where(~on_1 & (VD >= 1.0), V1 / 95.0, 0.0)
    pd_a = np.where(~(en_v >= 0.8) & (V5 >= 1.5), VA / 230.0, 0.0)
    pd_lm = np.where(lm_on, 0.0, 1.0 / 50e3)
    # discharge FETs (gate RC 22 k x 1.2 nF from 3V3M; held low while the EN inverter conducts)
    inv_on = en_v >= 1.0
    VGA = np.where(inv_on, 0.0, VGA + (VM - VGA) / (22e3 * 1.2e-9) * dt)
    VGD = np.where(inv_on, 0.0, VGD + (VM - VGD) / (22e3 * 1.2e-9) * dt)
    ron_a = np.where(VGA > 1.45, 0.055 * 1.05 / np.maximum(VGA - 1.45, 1e-3), 1e9)
    ron_d = np.where(VGD > 1.45, 0.055 * 1.05 / np.maximum(VGD - 1.45, 1e-3), 1e9)
    d_a = VA / (10.1 + ron_a); d_d = VD / (10.1 + ron_d); d_1 = V1 / (4.75 + ron_d)
    # --- integrate
    VB = VB + (-i_u102 - i_mp - 0.2e-3) / C_B * dt
    V5 = V5 + (i_u102 - i_dp - i_ap - i_an - led + r_d + r_a + r_an) / C_5 * dt
    VM = VM + (i_mp - i_m - pd_m - r_m) / C_M * dt
    VD = VD + (i_dp - i_d - i_1p - pd_d - r_d + r_1 - d_d) / C_D * dt
    V1 = V1 + (i_1p - i_1 - pd_1 - r_1 - d_1) / C_1 * dt
    VA = VA + (i_ap - i_a - pd_a - r_a - d_a) / C_A * dt
    VAN = VAN + (i_an - i_pp - i_cp - np.where(lm_on, 1e-3, 0.0) - r_an) / C_AN * dt
    VP = VP + (i_pp - i_p_load - VP * pd_lm - i_dp + lk_p) / C_P * dt
    VN = VN + (i_np - i_n_load - VN * pd_lm - i_dn + lk_n) / C_P * dt
    if X8:
        VPI = np.maximum(VPI + (i_dp - I_IVP * fiv - lk_p) / C_RES * dt, 0.0)
        VNI = np.maximum(VNI + (i_dn - I_IVN * fiv - lk_n) / C_RES * dt, 0.0)
    VCP = VCP + (i_cp - i_np) / C_CP * dt
    VS = VS + (K_S * V5 - VS) / TAU_S * dt
    for arr in (VB, V5, VM, VD, V1, VA, VAN, VP, VN, VCP):
        np.maximum(arr, 0.0, out=arr)
    # --- metrics
    for key, dv, isch in (("U502", VM - VB, s_m), ("U504", VD - V5, s_d), ("U302", VA - V5, s_a), ("U303", V1 - VD, s_1),
                          ("U503", VAN - V5, s_an)):
        REVMAX[key] = np.maximum(REVMAX[key], dv); ISMAX[key] = np.maximum(ISMAX[key], isch)
    worst_da = np.where(mclk, np.maximum(worst_da, VD - VA), worst_da)
    worst_1d = np.maximum(worst_1d, V1 - VD)
    r45 = np.isnan(t_r45) & (((VPI + VNI) if X8 else (VP + VN)) < 4.5)
    t_r45[r45] = t; va_at_r45[r45] = VA[r45]
    a03 = np.isnan(t_a03) & (VA < 0.3)
    t_a03[a03] = t
    for nm, arr in zip(names, (V5, VM, VD, V1, VA, VP, VN)):
        i0 = init[nm]
        m90 = np.isnan(t90[nm]) & (arr < 0.9 * i0); t90[nm][m90] = t
        m10 = np.isnan(t10[nm]) & (arr < 0.1 * i0); t10[nm][m10] = t
t_a03 = np.where(np.isnan(t_a03), T, t_a03)

def rng(a, m, scale=1e3, fmt="{:6.3f}"):
    x = a[m]
    if np.all(np.isnan(x)):
        return "   n/a        "
    s = "" if not np.any(np.isnan(x)) else "*"
    return (fmt.format(np.nanmin(x) * scale) + ".." + fmt.format(np.nanmax(x) * scale) + s).rjust(15)
P(basis_line(R))
P(hdr("1. Order and timing of the rails after the source disappears (ms from t = 0; min..max over corners; * = not reached in 3 ms)"))
P(f"   {n} corners: capacitance sets {list(CAPSETS)}, loads {list(LOADS)}, {list(MCU_I)}, LDO reverse {REV}, MCU reset {PDR} V")
for fk, fn in enumerate(FW):
    for ln in LOADS:
        m = (FWK == fk) & np.array([g[1] == ln for g in grid])
        P(f"\n  {fn} | {ln}: firmware act {rng(t_act, m)} ms, MCU reset {rng(t_rst, m)} ms, MCLK stops {rng(t_mclk_off, m)} ms")
        P("    rail     " + "".join(f"{'<90 %':>16s}{'<10 %':>16s}" for _ in [0]))
        for nm in names:
            P(f"    {nm:7s} {rng(t90[nm], m)} {rng(t10[nm], m)}")
P("\n  (90 %/10 % of the initial value: 5V_SYS ~4.95 V, 3V3M/3V3D/3V3A 3.3 V, 1V3 1.3 V, VPOS 3.85 V, |VNEG| 3.72 V.)")

P(hdr("2. Digital requirement: 3V3D must not exceed 3V3A by > 0.3 V while MCLK can run (XI back-power of VCCA)"))
for fk, fn in enumerate(FW):
    for rv in REV:
        m = (FWK == fk) & (REVCH == (rv == "LP5907-channel"))
        w = worst_da[m]
        P(f"  {fn:22s} LP5907 reverse {rv:15s}: max(3V3D - 3V3A) while MCLK runs = {w.max()*1e3:+5.0f} mV"
          f" -> {'OK' if w.max() <= 0.3 else 'VIOLATED'}; at the MCLK stop 3V3D - 3V3A = {np.nanmin(da_stop[m])*1e3:+5.0f}.."
          f"{np.nanmax(da_stop[m])*1e3:+5.0f} mV with 3V3D {np.nanmin(vd_stop[m]):.2f}..{np.nanmax(vd_stop[m]):.2f} V")
P("  (The running maximum is the 0 mV at t = 0: 3V3D never rises above 3V3A afterwards.)")
P("  Why: at a collapse both LDOs track 5V_SYS in dropout (3V3D drops 0.2 V more than 3V3A: 143 vs 19 mA through 1.4 vs 1.0 ohm),"
  " and 3V3D carries the heavier load, so 3V3D falls first; U206 also drops ST as soon as the MCU outputs (3V3M) fall below its VIH.")

P(hdr("3. DVDD vs DVCC during the collapse (analog S3: DVDD <= DVCC + 0.3 V)"))
for fk, fn in enumerate(FW):
    m = FWK == fk
    P(f"  {fn:22s}: max(1V3 - 3V3D) = {worst_1d[m].max()*1e3:+6.0f} mV (min {worst_1d[m].min()*1e3:+6.0f})"
      f" -> {'OK' if worst_1d[m].max() <= 0.3 else 'VIOLATED'}")

P(hdr("4. Analog requirement: I/V rails >= 4.5 V whenever 3V3A >= 0.3 V" + (" - X-8: N4_VPOS_IV + |N4_VNEG_IV| (reservoirs 176-264 uF, D411/D412)" if X8 else " (VPOS - VNEG)")))
P(f"  {'case':22s} {'load':12s} | {'rails < 4.5 V at ms':>20s} {'3V3A < 0.3 V at ms':>20s} {'window ms (3V3A up, rails < 4.5 V)':>36s} {'3V3A then V':>14s}")
WIN = {}
for fk, fn in enumerate(FW):
    for ln in LOADS:
        m = (FWK == fk) & np.array([g[1] == ln for g in grid])
        win = t_a03[m] - t_r45[m]
        WIN[(fk, ln)] = win
        P(f"  {fn:22s} {ln:12s} | {rng(t_r45, m):>20s} {rng(t_a03, m):>20s} {np.nanmin(win)*1e3:15.3f} .. {np.nanmax(win)*1e3:6.3f}"
          f"      {np.nanmin(va_at_r45[m]):5.2f}..{np.nanmax(va_at_r45[m]):4.2f}")
P("  Window > 0 = time during which the DAC outputs are driven while the I/V op-amps are below their 4.5 V minimum supply (the BAT54S"
  " clamps D405-D408 bound the pins, D-17). Negative = compliant (3V3A gone first).")
for fk in range(3):
    w = np.concatenate([WIN[(fk, ln)] for ln in LOADS])
    P(f"  {FW[fk]:22s}: worst window {np.nanmax(w)*1e3:.3f} ms, best {np.nanmin(w)*1e3:.3f} ms over all corners")

P(hdr("5. Brown-out detection latency (VBUS_SENSE through R105/R106 = 31.97 k, threshold 4.00 V, ADC watchdog + ISR 31 us)"))
for fk in (1, 2):
    m = FWK == fk
    lag = t_act[m] - t90["5V_SYS"][m]
    P(f"  {FW[fk]:22s}: action at {np.nanmin(t_act[m])*1e3:.3f}..{np.nanmax(t_act[m])*1e3:.3f} ms; executed before the MCU reset in"
      f" {int(np.sum(acted[m]))}/{int(np.sum(m))} corners")
P("  With C103 = 10 nF (tau 0.32 ms) the filtered pin lags a fast collapse by hundreds of mV, so the action comes late; without C103"
  " (TS 55.5 cycles already covers the 32 k source, digital D9) it comes within ~40 us of 5V_SYS crossing 4.00 V.")
P(hdr("6. R3 X-4: VOUT - VIN of every regulator at the collapse (abs max VOUT <= VIN + 0.3 V) and the OUT->IN Schottky current"))
P(f"  Schottky model {'ON' if SCH else 'OFF (body diodes only)'}: n*Vt {VT_N*1e3:.1f} mV, Is {IS_S:.2e} A, Rs {RS_S:.2f} ohm ({os.environ.get('C14_SCH_NAME', 'BAT54-class maxima fit: 0.24 V/0.1 mA, 0.32 V/1 mA, 0.40 V/10 mA, 0.53 V/30 mA, 0.78 V/100 mA')}),"
  " in parallel with the internal body diode (0.6 V / 0.5 ohm).")
for key in REVMAX:
    for fk, fn in enumerate(FW):
        m = FWK == fk
        P(f"  {key} {fn:24s}: max(VOUT - VIN) = {REVMAX[key][m].max()*1e3:+6.0f} mV, peak Schottky current {ISMAX[key][m].max()*1e3:7.2f} mA")
res_rev = {k: dict(dv=float(REVMAX[k].max()), i=float(ISMAX[k].max())) for k in REVMAX}
res = dict(rev=res_rev, worst_da={fn: float(worst_da[FWK == k].max()) for k, fn in enumerate(FW)},
           worst_1d={fn: float(worst_1d[FWK == k].max()) for k, fn in enumerate(FW)},
           window={fn: (float(np.nanmin(np.concatenate([WIN[(k, ln)] for ln in LOADS]))),
                        float(np.nanmax(np.concatenate([WIN[(k, ln)] for ln in LOADS])))) for k, fn in enumerate(FW)})
json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c14_results" + os.environ.get("C14_SUFFIX", "") + ".json"), "w"), indent=1)
open(__file__.replace(".py", os.environ.get("C14_SUFFIX", "") + ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
