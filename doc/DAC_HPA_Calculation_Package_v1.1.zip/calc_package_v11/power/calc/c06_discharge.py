"""c06 - Guaranteed switched discharge of 3V3A, 3V3D and 1V3 (EN-derived: discharge FET on whenever the regulator EN is low;
gate pulled to 3V3M through 22 k, held low by an AO3400A inverter on the EN net). R8 round 2:
- 3V3A: C302 2.2 uF (D-8); protection DC-sense/reference networks 6.8 k / 5.1 k / 16.9 k with 4.7 uF (5 networks) and the CM
  threshold chain back-feed 3V3A while it is discharged.
- 1V3: U303 = TLV75801P with EN = AUD_EN (pass device off at AUD_EN low); its internal pull-down is 95 ohm TYPICAL only
  (VIN = 6 V, no min/max [DS]) -> the guaranteed bound ignores it; Q506/R530 decision below.
- 3V3D capacitance from the digital netlist (C217-C219, C222, C223, FB202 branch C213-C215 + C220) + C512 + C311 + C308.
Worst case for time: C at +tolerance (no DC-bias credit), R +1 %, AO3400A Rds(on) max at 2.5 V x 1.15 (60 C), regulator
pull-downs ignored, loads ignored (they only help), gate delay counted as 'no discharge'."""
import numpy as np
from pw_common import *

out = []
P = out.append
RDS = AO3400A["RDS_2V5_MAX"] * 1.15
R_DIS = {"3V3A": 10.0, "3V3D": 10.0, "1V3": 4.7}
R_PU = 22e3
Q_G25 = 3.0e-9                                   # [ASSUMP] gate charge to VGS 2.5 V (Qg 7 nC max at 4.5 V [DS])
I_G_MIN = (3.25 - 2.5) / (R_PU * 1.01)
T_GATE = Q_G25 / I_G_MIN
P(hdr("Gate drive (unchanged)"))
P(f"R_PU 22 k from 3V3M (>= 3.25 V): I_gate >= {I_G_MIN*1e6:.1f} uA at VGS 2.5 V -> t_gate <= {T_GATE*1e6:.0f} us (bound; no discharge"
  " before). The inverter pulls the gate below 50 mV in < 1 us when EN rises (before any LDO output rises).")

def sim(nodes, links, t_end, dt, active_after):
    names = list(nodes)
    V = np.array([nodes[n][1] for n in names], float)
    C = np.array([nodes[n][0] for n in names], float)
    idx = {n: i for i, n in enumerate(names)}
    t = 0.0; hist = []
    while t < t_end:
        I = np.zeros_like(V)
        for a, b, R, tag in links:
            if tag == "dis" and t < active_after:
                continue
            va = V[idx[a]]; vb = 0.0 if b == "GND" else (V[idx[b]] if b in idx else float(b))
            i = (va - vb) / R
            I[idx[a]] -= i
            if b in idx:
                I[idx[b]] += i
        V = V + I / C * dt
        t += dt
        hist.append((t, V.copy()))
    return names, hist
def t_below(names, hist, which, thr=0.1):
    ids = [names.index(w) for w in which]
    for t, V in hist:
        if all(V[i] < thr for i in ids):
            return t
    return None

P(hdr("3V3A (LP5907 off at t = 0, AVCC_EN low) - DC-sense back-feed with the new networks"))
V0A = 3.3 * 1.02
a_sense = PROT["R_D"] * PROT["R_S"] / (PROT["R_D"] + PROT["R_S"])
a = a_sense / (a_sense + PROT["R_U"])                       # node = a x 3V3A with the leg (or reference input) at 0 V
C_SN = PROT["C_N"] * 1.10
nodesA = {"A": [2.2e-6 * 1.1 + 0.11e-6, V0A],              # C302 2.2 uF + C307 100 nF (VCCA via FB302)
          "AL": [2.2e-6 * 1.1 + 0.11e-6, V0A], "AR": [2.2e-6 * 1.1 + 0.11e-6, V0A]}   # C303/C305, C304/C306 behind R301/R302
for s in ("S1", "S2", "S3", "S4", "REF"):
    nodesA[s] = [C_SN, a * V0A]
linksA = [("A", "AL", 2.2 * 1.01, ""), ("A", "AR", 2.2 * 1.01, ""),
          ("A", "GND", R_DIS["3V3A"] * 1.01 + RDS, "dis"),
          ("A", "GND", 19.76e3 * 1.001, ""),                                   # VREF divider R431 + R432
          ("A", "GND", (10e3 + 6.8e3 + 10e3) * 1.001, "")]                     # CM threshold chain R657/R658/R659
for s in ("S1", "S2", "S3", "S4", "REF"):
    linksA += [("A", s, PROT["R_U"] * 0.999, ""), (s, "GND", PROT["R_D"] * 1.001, ""), (s, "GND", PROT["R_S"] * 1.001, "")]
names, hist = sim(nodesA, linksA, 3e-3, 0.02e-6, T_GATE)
tA = t_below(names, hist, ["A", "AL", "AR"])
vend = hist[-1][1]
i_bf = 5 * a * V0A / PROT["R_U"] + 3.915 / 330e3
P(f"C upper bound: node A {nodesA['A'][0]*1e6:.2f} uF, AVCC_L/R {nodesA['AL'][0]*1e6:.2f} uF each; 5 sense/reference nodes {C_SN*1e6:.2f} uF"
  f" at {a*V0A:.3f} V; R_dis {R_DIS['3V3A']} ohm +1 % + Rds {RDS*1e3:.0f} mOhm")
P(f"3V3A, AVCC_L, AVCC_R all < 0.1 V at t <= {tA*1e3:.3f} ms after AVCC_EN low (incl. {T_GATE*1e6:.0f} us gate bound) [CALC]"
  f" (round 1: 0.352 ms with the old 1 uF C302 and 10 k/22 k/15 k networks)")
P(f"Residual at 3 ms from the sense-node back-feed: A = {vend[names.index('A')]*1e3:.1f} mV (initial back-feed {i_bf*1e3:.2f} mA incl."
  f" R660 from VPOS; decays with the ~12 ms sense-node tau) - the DAC pins see < 20 mV, below any junction threshold.")
E = 0.5 * sum(nodesA[n][0] for n in ("A", "AL", "AR")) * V0A ** 2
P(f"Discharge pulse: I_pk <= {V0A/(R_DIS['3V3A']*0.99)*1e3:.0f} mA, energy {E*1e6:.0f} uJ in R527 (0603 STOL 3.1 J) - negligible [CALC]")

P(hdr("3V3D + 1V3 (TLV767 and TLV758P both disabled at t = 0 by AUD_EN low)"))
C_D_HI = 11e-6 + 5 * 0.11e-6 + 3 * 0.11e-6 + 1.1e-6 + 1.1e-6 + 0.11e-6 + 1.0e-6   # C512, 5x digital, CPLD 3x100n + C220, C311, C308, reserve
C_D_LO = 10e-6 * 0.9 * 0.85 * 0.70 + (5 + 3 + 1) * 0.1e-6 * 0.9 * 0.85 * 0.9 + 2 * 1e-6 * 0.9 * 0.85 * 0.9
C_1_HI = 1.1e-6 + 2.42e-6 + 0.11e-6
C_1_LO = 1e-6 * 0.9 * 0.85 * 0.9 + 2.2e-6 * 0.9 * 0.85 * 0.90 + 0.08e-6
P(f"3V3D C: {C_D_LO*1e6:.1f} .. {C_D_HI*1e6:.1f} uF (upper incl. 1 uF reserve); 1V3 C: {C_1_LO*1e6:.2f} .. {C_1_HI*1e6:.2f} uF;"
  f" R529 {R_DIS['3V3D']} ohm, R530 {R_DIS['1V3']} ohm")
def sim_d(C_D, C_1, R1, I_LD, I_L1, rpd_int=None, with_q506=True, dt=0.02e-6, t_end=2e-3, vf=0.6, rdiode=0.5):
    """TLV758P disabled at t=0: pass device off; body diode 1V3 -> 3V3D (vf, rdiode); optional internal pull-down (typ 95 ohm,
    active while 3V3D >= 1.0 V [ASSUMP]); Q505/Q506 discharge after T_GATE; constant-current loads (linear below 0.3 V)."""
    vd, v1 = 3.3 * 1.01, 1.326
    t = 0.0; worst = -9.0; td = t1 = None
    while t < t_end:
        on = t >= T_GATE
        i_dd = vd / (R_DIS["3V3D"] * 1.01 + RDS) if on else 0.0
        i_d1 = v1 / (R1 * 1.01 + RDS) if (on and with_q506) else 0.0
        i_pd = (v1 / rpd_int) if (rpd_int and vd >= 1.0) else 0.0
        ild = I_LD if vd > 0.3 else I_LD * vd / 0.3
        il1 = I_L1 if v1 > 0.3 else I_L1 * v1 / 0.3
        i_bd = max(0.0, (v1 - vd - vf) / rdiode)
        vd += (-i_dd - ild + i_bd) / C_D * dt
        v1 += (-i_d1 - i_pd - il1 - i_bd) / C_1 * dt
        t += dt
        worst = max(worst, v1 - vd)
        if td is None and vd < 0.1: td = t
        if t1 is None and v1 < 0.1: t1 = t
    return td, t1, worst
td, t1, _ = sim_d(C_D_HI, C_1_HI, R_DIS["1V3"], 0.0, 0.0)
P(f"Time bound (C max, no loads, TLV758P pull-down ignored): 3V3D < 0.1 V at {td*1e3:.3f} ms, 1V3 < 0.1 V at {t1*1e3:.3f} ms after"
  " AUD_EN low [CALC]")
P("DVDD <= DVCC + 0.3 V check (analog S3), max(V1V3 - V3V3D) over bounding cases, TLV758P pull-down ignored (no min spec):")
for ild in (0.0, 0.070, 0.143, 0.180):
    w = max(sim_d(CD, C1, R_DIS["1V3"], ild, 0.0, dt=0.05e-6, t_end=1.2e-3)[2] for CD in (C_D_LO, C_D_HI) for C1 in (C_1_LO, C_1_HI))
    P(f"    with Q506/R530: 3V3D constant load {ild*1e3:5.0f} mA, 1V3 load 0 -> max(V1V3 - V3V3D) = {w*1e3:+7.1f} mV")
P("  (70 mA = controlled power-down with MCLK and the family oscillators already stopped; 143 mA = S2 maximum; 180 mA = unphysical"
  " bound. The only coupling is the TLV758P body diode, so V1V3 - V3V3D can never exceed ~0.6 V; with Q506 it stays <= the values"
  " above.)")
P("Q506/R530 decision - TLV758P internal discharge alone (95 ohm TYPICAL at VIN 6 V; assumed active while 3V3D >= 1.0 V):")
for ild in (0.0, 0.070, 0.143):
    for rpd in (95.0, 190.0):
        r = [sim_d(CD, C1, R_DIS["1V3"], ild, 0.0, rpd_int=rpd, with_q506=False, dt=0.05e-6, t_end=2e-3)
             for CD in (C_D_LO, C_D_HI) for C1 in (C_1_LO, C_1_HI)]
        w = max(x[2] for x in r); t1s = [x[1] for x in r]
        t1txt = "not within 2 ms" if any(v is None for v in t1s) else f"{max(t1s)*1e3:5.2f} ms"
        P(f"    no Q506: 3V3D load {ild*1e3:5.0f} mA, R_pd {rpd:5.0f} ohm -> max(V1V3 - V3V3D) {w*1e3:+7.1f} mV, 1V3 < 0.1 V: {t1txt}"
          f" (3V3D bound {td*1e3:.2f} ms)")
P("  -> the internal pull-down alone is slower than the 3V3D discharge (1V3 would outlive 3V3D and DVDD would exceed DVCC by up to"
  " ~0.6 V, clamped only by the body diode), and 95 ohm is typical-only and needs VIN -> Q506 + R530 STAY (guaranteed: 1V3 falls"
  " first, tau 4.7 ohm x 3.85 uF = 18 us after the <= 89 us gate delay). R530 4.7 ohm: 1.326 V / 4.7 ohm = 0.28 A peak for"
  " microseconds (TLV758P already off - no regulator-vs-discharge fight because EN = AUD_EN).")
P(hdr("Summary of guaranteed discharge times (from EN low to < 0.1 V)"))
P(f"3V3A (incl. AVCC_L/R pins): <= {tA*1e3:.2f} ms ; 3V3D: <= {td*1e3:.2f} ms ; 1V3: <= {t1*1e3:.2f} ms  [CALC]")
P("Start-up discharge at boot: all EN nets are low at reset (pull-downs), so all three discharge FETs are on as soon as 3V3M exceeds"
  " ~1.5 V. Firmware rule: an EN that went low stays low >= 1 ms before re-enabling. Firmware wait AUD_EN/AVCC_EN low -> RAIL_EN/ANA_EN"
  f" low: >= {tA*1e3:.2f} ms keeps the I/V rails up until 3V3A < 0.1 V (analog S6) - the digital 0.53 ms wait meets it. The 3V3D bound"
  f" is now {td*1e3:.2f} ms (round 1 0.525 ms, which the digital wait was copied from); no power or analog rule needs 3V3D < 0.1 V before"
  f" RAIL_EN/ANA_EN low (the 1 ms re-enable rule covers 3V3D); if the digital stream wants its wait to stay 'the 3V3D bound', use"
  f" {td*1e3:.2f} ms (suspend total +{(td-0.53e-3)*1e3:.2f} ms).")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
