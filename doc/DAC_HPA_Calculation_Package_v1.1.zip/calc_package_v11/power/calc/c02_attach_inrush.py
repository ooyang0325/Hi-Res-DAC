"""c02 - Attach inrush per the USB-IF method (Compliance Update #45): charge ABOVE 100 mA per region,
region = current > 100 mA until < 100 mA for >= 100 us, pass/fail on the largest region, 100 ms window after attach.
Limit 50 uC (USB 2.0 7.2.4.1: 10 uF at 5 V; USBET limit). Owner margin >= 20 % -> <= 40 uC.
R8 round 2: C301 -> 2.2 uF (D-8, parts P-M2) adds 1.32 uF (upper bound) on 5V_SYS; 3V3M inventory from the digital netlist
(C203-C210, C211, C221) + C502 + the new U505 decoupling C515. Compensation: C503 (TLV767 input) deleted - C501 serves both
LDO inputs (U502/U504 adjacent, both IN pins <= 3 mm from C501; TLV767 and TPS7A20 need no input capacitor for stability [DS]).
"""
from pw_common import *

out = []
P = out.append
P(hdr("Capacitance inventory (nominal, tolerance) - upper bounds use +tol and NO DC-bias credit"))
VBUS_CAPS = [("C102", 4.7e-6, 0.10, "4.7uF 25V X5R 0805 (TPS25200 IN, at J101)")]
V5_CAPS_KEEP503 = [("C501", 1.0e-6, 0.10, "TPS7A20 IN (shared with U504 IN)"),
           ("C503", 1.0e-6, 0.10, "TLV767 IN (round-1 part, DELETED in round 2)"),
           ("C301", 2.2e-6, 0.10, "LP5907 IN, 2.2 uF 16 V 0603 (D-8)"),
           ("C505", 0.1e-6, 0.10, "TPS2596 IN (100 nF recommended by TI)")]
V5_CAPS = [c for c in V5_CAPS_KEEP503 if c[0] != "C503"]
V3M_CAPS = [("C502", 1.0e-6, 0.10, "TPS7A20 OUT"),
            ("C203-C210", 8 * 0.1e-6, 0.10, "MCU decoupling 8x100nF (digital netlist)"),
            ("C221", 1.0e-6, 0.10, "MCU VDDA bulk (digital netlist)"),
            ("C211", 2.2e-6, 0.20, "MCU 3V3M bulk 2.2uF M-tol (digital netlist)"),
            ("C515", 0.1e-6, 0.10, "U505 TMUX1101 VDD decoupling (new)")]
def tot(caps):
    return sum(c[1] for c in caps), sum(c[1] * (1 + c[2]) for c in caps)
for name, caps in (("VBUS (before switch)", VBUS_CAPS), ("5V_SYS, C503 kept", V5_CAPS_KEEP503), ("5V_SYS (C503 deleted)", V5_CAPS),
                   ("3V3M", V3M_CAPS)):
    n, h = tot(caps)
    P(f"{name:22s} nominal {n*1e6:5.2f} uF, upper bound {h*1e6:5.2f} uF   ({', '.join(c[0] for c in caps)})")

P(hdr("Region A - contact: C_VBUS charged through the cable in microseconds (always a region)"))
nV, hV = tot(VBUS_CAPS)
QA = hV * VBUS_MAX            # charge above 100 mA ~= total charge (duration << 1 ms)
P(f"Q_A <= {hV*1e6:.2f} uF x {VBUS_MAX} V = {QA*1e6:.1f} uC   [CALC]")

P(hdr("Region B - TPS25200 soft start (starts t_on = 5.12 ms typ after attach -> separate region, gap >> 100 us)"))
n5, h5 = tot(V5_CAPS); n3, h3 = tot(V3M_CAPS)
V5max = min(VBUS_MAX, TPS25200["VOVC_MAX"])
QB_keep = tot(V5_CAPS_KEEP503)[1] * V5max + h3 * 3.3 * (1 + TPS7A20["ACC"])
QB_worst = h5 * V5max + h3 * 3.3 * (1 + TPS7A20["ACC"])
IOS_MAX = tps25200_ios(86.6 * 0.99)[2]
credit = 1 - 0.100 / IOS_MAX
P(f"(i) Worst case, NO soft-start credit (instant turn-on), C503 kept: {tot(V5_CAPS_KEEP503)[1]*1e6:.2f} uF x {V5max} V + "
  f"{h3*1e6:.2f} uF x {3.3*(1+TPS7A20['ACC']):.3f} V = {QB_keep*1e6:.1f} uC -> margin {(1-QB_keep/50e-6)*100:.0f} % (< 20 %: FAIL)")
P(f"(i) Worst case, NO soft-start credit (instant turn-on), C503 deleted: Q_B <= {h5*1e6:.2f} uF x {V5max} V + {h3*1e6:.2f} uF x "
  f"{3.3*(1+TPS7A20['ACC']):.3f} V = {QB_worst*1e6:.1f} uC   [CALC]")
P(f"    guaranteed extra credit (not needed): U102 current limit IOS <= {IOS_MAX*1e3:.0f} mA [DS Eq.1, R108 -1 %] -> the region lasts"
  f" >= Q/IOS,max, so charge above 100 mA <= Q x (1 - 0.1 A/IOS,max) = {QB_worst*credit*1e6:.1f} uC (C503 kept: {QB_keep*credit*1e6:.1f} uC)")
# typical soft start: 5V_SYS ramps linearly 0 -> V5max in tr/0.8 (10-90 % definition assumed).
# 3V3M tracks 5V_SYS (TPS7A20 in dropout, UVLO <= 1.59 V [DS]) until it regulates at 3.35 V; then only 5V_SYS caps charge.
def region_charge(tr, i_mcu, dt=1e-6):
    sr = 0.8 * V5max / tr
    t, v5, q_above, ipk = 0.0, 0.0, 0.0, 0.0
    while v5 < V5max:
        v5 = min(V5max, v5 + sr * dt)
        i = h5 * sr + (h3 * sr if v5 < 3.35 + TPS7A20["VDO300_MAX"] else 0.0)
        i += (i_mcu if v5 > 2.7 else 0.0) + TPS25200["IQ_ON_MAX"] + 0.0015
        ipk = max(ipk, i)
        q_above += max(0.0, i - 0.100) * dt
        t += dt
    return sr, ipk, q_above, t
for label, tr in (("typ", TPS25200["TR_TYP"]), ("typ/4 (sensitivity)", TPS25200["TR_TYP"] / 4)):
    for mcu_lbl, i_mcu in (("MCU at HSI 10 mA [ASSUMP, needs firmware rule]", 0.010), ("MCU at 80 mA max [PH]", 0.080)):
        sr, ipk, qa, t = region_charge(tr, i_mcu)
        P(f"(ii) soft start {label:20s} {mcu_lbl:46s}: dV/dt {sr:5.0f} V/s, peak {ipk*1e3:6.1f} mA, "
          f"charge above 100 mA {qa*1e6:5.2f} uC")
P("TPS25200 rise time min is not specified (typ 2.05 ms, max 3.2 ms [DS]); (i) is therefore the guaranteed bound.")

P(hdr("Result"))
lim, target = 50e-6, 40e-6
worst = max(QA, QB_worst)
P(f"Largest region, guaranteed (no soft-start or DC-bias credit): {worst*1e6:.1f} uC vs limit 50 uC -> margin "
  f"{(1-worst/lim)*100:.0f} % (target >= 20 %: {'PASS' if worst <= target else 'FAIL'})")
P(f"Largest region with the typical TPS25200 soft start: {QA*1e6:.1f} uC (contact region) -> margin {(1-QA/lim)*100:.0f} %")
P(f"C503 kept would give {QB_keep*1e6:.1f} uC ({(1-QB_keep/lim)*100:.0f} % margin, 16 % even with the current-limit credit) -> C503 deleted.")
P("Budget rules handed to the layout/other streams: C_VBUS <= 4.7 uF nominal; 5V_SYS total <= 3.3 uF nominal "
  "(C501 1 uF shared by U502/U504, C301 2.2 uF, C505 100 nF; photorelay strings carry no capacitance); 3V3M total <= 5.1 uF nominal.")
P("Unconfigured current <= 100 mA during the 100 ms window: see c03 (state S1).")
P(hdr("R8 round 3 note")); P("  SUPERSEDED by c16_r3_review_fixes.out.txt section B: C104 100 nF on U102 EN -> U102 on >= 2.24 ms after attach (every corner), region A 28.5 uC (incl. D102) ends <= 273 us, region B 40.2 uC (37.0 uC with the guaranteed U102 current-limit credit); the 100 us separation holds by construction. E-16 (R9): superseded again by c22 section 2 (C102 2.2 uF; region A 29.6 uC incl. the 3V3M charge, region B 20.1 uC).")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
