"""c05 - FB501 + C507 resonance (R7-A P-22): input impedance seen by the LM27762 VIN pin, with the real upstream
network (C506, U503 switch, 5V_SYS caps, TPS25200, C102, USB cable). R8 round 2: U503 = TPS2596 (Ron 89 mOhm typ / 131 mOhm
max [DS]) instead of the TPS2553 (85/135 mOhm); 5V_SYS capacitance C501 + C301 2.2 uF + C505 (C503 deleted) = 2.1..3.6 uF eff. Ferrite low-frequency inductance is not given in the
parts data -> swept 0.1..1.0 uH [ASSUMP]; DCR 30..50 mOhm (50 mOhm max [DS])."""
import numpy as np, itertools
from pw_common import *
out = []
P = out.append
f = np.logspace(3, 7, 4000)
w = 2 * np.pi * f
def zc(C, esr=0.005, esl=0.5e-9):
    return esr + 1j * w * esl + 1 / (1j * w * C)
def par(a, b):
    return a * b / (a + b)
def zin(L_fb, R_fb, C507, C506, C5v, C102, Rc, Lc, r2553, r25200, damp=None):   # r2553 = U503 switch resistance
    z_src = Rc + 1j * w * Lc                        # ideal host behind the cable
    z_c102 = par(zc(C102), z_src)
    z_5v = par(zc(C5v), r25200 + z_c102)
    z_up = par(zc(C506), r2553 + z_5v)
    z_fb = R_fb + 1j * w * L_fb
    z507 = zc(C507)
    if damp:
        Rd, Cd = damp
        z507 = par(z507, Rd + 1 / (1j * w * Cd))
    return par(z507, z_fb + z_up)
rows = []
for L_fb, C507, C506, Rc, Lc, r2553, r25200, C5v in itertools.product(
        (0.1e-6, 0.3e-6, 1.0e-6), (4.2e-6, 6.0e-6, 11e-6), (0.6e-6, 1.1e-6), (0.1, 0.4), (0.5e-6, 1.5e-6),
        (TPS2596["RON_TYP"], TPS2596["RON_MAX"]), (0.06, 0.099), (2.1e-6, 3.6e-6)):
    z = np.abs(zin(L_fb, 0.03, C507, C506, C5v, 2.2e-6, Rc, Lc, r2553, r25200))
    i = np.argmax(z[f > 5e3]) + np.sum(f <= 5e3)
    rows.append((z[i], f[i], L_fb, C507, C506, Rc, Lc, r2553, r25200, C5v))
rows.sort(reverse=True)
P(hdr("Peak |Z_in| at LM27762 VIN (5 kHz..10 MHz), worst combinations, no damping"))
P(f"{'|Z|pk':>7s} {'f_pk':>9s} {'L_FB':>6s} {'C507':>6s} {'C506':>6s} {'Rc':>5s} {'Lc':>6s} {'RU503':>6s} {'R25200':>7s} {'C5V':>6s}")
for r in rows[:6]:
    P(f"{r[0]:7.3f} {r[1]/1e3:8.1f}k {r[2]*1e6:5.1f}u {r[3]*1e6:5.1f}u {r[4]*1e6:5.1f}u {r[5]:5.2f} {r[6]*1e6:5.1f}u {r[7]:6.3f} {r[8]:7.3f} {r[9]*1e6:5.1f}u")
worst = rows[0]
for Lsel in (0.1e-6, 0.3e-6):
    r = max(x for x in rows if x[2] == Lsel)
    P(f"Worst peak with L_FB = {Lsel*1e6:.1f} uH: {r[0]:.3f} ohm at {r[1]/1e3:.1f} kHz")
P("The ~40 kHz peak is the USB-cable inductance (1.5 uH) resonating with the whole board capacitance (C102 + 5V_SYS +"
  " C506 + C507 ~ 9-10 uF): it barely depends on L_FB, i.e. it is not an FB501 artefact and exists in any bus-powered"
  " device; FB501 itself adds a higher-frequency, better-damped pole.")
P(f"Characteristic impedance sqrt(L/C) of the worst pair: {np.sqrt(worst[2]/worst[3]):.3f} ohm; peak/Z0 = "
  f"{worst[0]/np.sqrt(worst[2]/worst[3]):.2f} (effective Q)")
P(hdr("Ripple estimate and effect"))
I1 = 2 / np.pi * 0.060   # fundamental of a 60 mA, 50 %-duty PFM burst current (idle analog load) [ASSUMP]
v = worst[0] * I1
P(f"Worst-case VIN ripple if a PFM burst sits exactly on the peak: {v*1e3:.1f} mV (60 mA idle load, fundamental {I1*1e3:.0f} mA)")
P(f"At the rails: LM27762 LDO PSRR 43..50 dB typ at 10 kHz [DS-typ] -> <= {v*10**(-43/20)*1e3:.2f} mV; op-amp PSRR adds >= 90 dB "
  "(OPA1622/OPA2210 datasheets, analog stream) -> negligible at the jacks.")
z_d = np.abs(zin(worst[2], 0.03, worst[3], worst[4], worst[9], 2.2e-6, worst[5], worst[6], worst[7], worst[8], damp=(1.0, 10e-6)))
P(f"With the optional DNF damping R531 1 ohm + C513 10 uF across C507: peak {z_d[f>5e3].max():.3f} ohm "
  f"({20*np.log10(worst[0]/z_d[f>5e3].max()):.1f} dB lower).")
P("Decision (unchanged): no damping fitted: Q stays ~3 even with the worst assumptions (the upstream U503/TPS25200/cable network"
  " damps the tank), the resonance is ultrasonic (~40 kHz and above), and the LDO + op-amp PSRR leave microvolts at the"
  " rails/outputs. R531 1 ohm + C513 10 uF footprints are kept DNF as the designed-in fallback; fit them if the bring-up"
  " measurement at light load shows VIN ripple > 200 mVpp or V+/V- ripple > 50 uVrms in 20 Hz..20 kHz [MEAS].")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
