#!/bin/bash
# R10: long release calculations on the final basis (c17_basis.json), sequential, one retry on the transient import error
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
run() { for i in 1 2 3; do s=$(date +%s); timeout 1800 python3 -B "$@" > /dev/null 2> run_long.err && { echo "$* rc=0 $(( $(date +%s)-s ))s" >> long_R10.log; return 0; }; echo "$* try $i failed: $(tail -1 run_long.err)" >> long_R10.log; sleep 5; done; return 1; }
echo "start $(date -u +%H:%M) (final F-1 basis)" >> long_R10.log
run c16_r3_review_fixes.py
run c14_unplug_order.py
rm -f c18_x8_rail_start.out.txt
run c18_x8_rail_start.py 10 reduced
run c18_x8_rail_start.py 470 reduced
run c18_x8_rail_start.py 10 timing
run c18_x8_rail_start.py 470 timing
rm -f run_long.err
echo "DONE $(date -u +%H:%M)" >> long_R10.log
