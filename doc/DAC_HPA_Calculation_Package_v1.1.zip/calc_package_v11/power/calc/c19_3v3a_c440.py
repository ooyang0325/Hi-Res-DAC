"""c19 - R8 round 3 follow-up: 3V3A with the analog C440 2.2 uF on VCCA (after FB302) and the optional C441 1 uF (DNF):
LP5907 COUT limit (0.7-10 uF effective [DS]) and the 3V3A discharge time (c06 nodal model re-used, node A capacitance changed)."""
import os, re
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "c06_discharge.py")).read()
src = src.split('P(hdr("3V3D + 1V3')[0]              # 3V3A part only
out = []; P = out.append
P(hdr("c19: 3V3A capacitance with C440 (and the C441 option) - LP5907 COUT limit and discharge time"))
# capacitance inventory on 3V3A (the LP5907 output net incl. the VCCA/AVCC pins behind FB302/R301/R302)
inv = [("C302 LP5907 OUT", 2.2e-6, 3.3), ("C307 VCCA 100 nF", 0.1e-6, 3.3), ("C303/C305 AVCC_L 2.2 uF + 100 nF", 2.3e-6, 3.3),
       ("C304/C306 AVCC_R 2.2 uF + 100 nF", 2.3e-6, 3.3), ("C440 VCCA 2.2 uF (new, after FB302)", 2.2e-6, 3.3)]
nom = sum(c for _, c, _ in inv)
P(f"  Inventory (nominal): {nom*1e6:.2f} uF; upper bound (+10 %, no DC-bias credit) {nom*1.1*1e6:.2f} uF; with C441 1 uF: {(nom+1e-6)*1.1*1e6:.2f} uF.")
dcb = 0.80   # [ASSUMP] Samsung CL10A225KO8NNNC 2.2 uF 16 V X5R 0603 at 3.3 V: >= 20 % loss (the 1 uF 50 V parts lose less; 0.9 used)
eff_hi = (2.2e-6 * 4 * dcb + 0.3e-6 * 0.9) * 1.10
P(f"  Effective upper bound with a conservative DC-bias factor {dcb} for the 2.2 uF 16 V 0603 parts at 3.3 V [ASSUMP; Samsung curve"
  f" not extracted] and +10 % tolerance: {eff_hi*1e6:.2f} uF (analog: 4.98-8.54 uF) -> <= 10 uF effective [DS LP5907 COUT] by"
  f" {(10e-6-eff_hi)*1e6:.2f} uF; with C441 (1 uF 50 V, factor 0.9): {(eff_hi+1.1e-6*0.9)*1e6:.2f} uF.")
res = {}
for label, extra in (("with C440", 2.2e-6 * 1.1), ("with C440 + C441", 2.2e-6 * 1.1 + 1.0e-6 * 1.1)):
    s = src.replace('nodesA = {"A": [2.2e-6 * 1.1 + 0.11e-6, V0A],', f'nodesA = {{"A": [2.2e-6 * 1.1 + 0.11e-6 + {extra!r}, V0A],')
    ns = {}
    exec(compile(s, "c06_part", "exec"), ns)
    res[label] = ns["tA"]
    P(f"  3V3A, AVCC_L/R < 0.1 V after AVCC_EN low: <= {ns['tA']*1e3:.3f} ms {label} (round 2 without C440: 0.385 ms) [CALC c06 model]")
P("  Wait rule: AUD_EN/AVCC_EN low -> ANA_EN low >= the 3V3A time (analog S6; digital wait 0.53 ms) -> "
  + ("met" if res["with C440"] <= 0.53e-3 else "NOT met") + f" with C440 ({(0.53e-3-res['with C440'])*1e3:+.3f} ms);"
  + (" met" if res["with C440 + C441"] <= 0.53e-3 else " NOT met") + f" with C441 fitted ({(0.53e-3-res['with C440 + C441'])*1e3:+.3f} ms).")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
