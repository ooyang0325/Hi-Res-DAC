"""c07 - Relay coil supply: coil voltage at every VBUS corner incl. driver drops vs must-operate (hot coil) and max.
Must-operate is specified at 23 C coil temperature [DS G6K note 2]; it rises with copper resistance:
V_mo(T) = V_mo(23) x (234.5 + T)/(234.5 + 23)  [ASSUMP: copper alpha, Omron graph 'ambient temperature vs must
operate voltage' shows the rise]. Worst coil temperature at operate: 50 C ambient + 10 C local + 10 C residual
self-heating after a recent energisation = 70 C [ASSUMP]."""
from pw_common import *

out = []
P = out.append
KT = lambda T: (234.5 + T) / (234.5 + 23.0)
T_HOT, T_COLD = 70.0, 0.0
R_DRV = 2 * AO3400A["RDS_2V5_MAX"] * 1.15 + 0.02    # two series NMOS (protection stream placeholder) + copper [ASSUMP]

# 5V_SYS corners (from c04): min at VBUS 4.40 V High (4.301 V) / Default (4.342 V); max 5.50 (in-spec) / 5.55 (clamp)
V5 = {"4.40 High": 4.301, "4.40 Default": 4.342, "4.60 High": 4.501, "5.50": 5.50, "5.55 clamp": 5.55}
V3D = {"min": 3.3 * (1 - TLV767["ACC"]) - 0.25 * TLV767["LOADREG_MAX_PER_A"] * 3.3, "max": 3.3 * (1 + TLV767["ACC"])}

relays = [
    # name, supply, Vnom, R23 nominal, mo %, max %
    ("Placeholder 5 V coil, 150 mW, 75 % (e.g. Panasonic TQ2-class)", "5V_SYS", 5.0, 5.0**2/0.150, 0.75, 1.5),
    ("Omron G6K-2F-Y DC5 (100 mW, 80 %) [DS]", "5V_SYS", 5.0, 237.0, 0.80, 1.5),
    ("Omron G6K-2F-Y DC4.5 (100 mW, 80 %) [DS]", "5V_SYS", 4.5, 194.0, 0.80, 1.5),
    ("Generic 4.5 V, 100 mW, 75 % must-operate", "5V_SYS", 4.5, 4.5**2/0.100, 0.75, 1.5),
    ("Omron G6K-2F-Y DC3 (100 mW, 80 %) [DS]  <- recommended", "3V3D", 3.0, 91.0, 0.80, 1.5),
]
P(hdr("Coil voltage vs hot must-operate and maximum (driver: 2 x AO3400A-class NMOS, placeholder)"))
P(f"Hot-coil factor at {T_HOT:.0f} C: x{KT(T_HOT):.4f}; cold (0 C) resistance factor x{KT(T_COLD):.4f}; coil R tol +-10 % [DS G6K note 1]")
for name, sup, vn, r23, mo, mx in relays:
    vmo_hot = mo * vn * KT(T_HOT)
    if sup == "5V_SYS":
        vs_min, vs_max = V5["4.40 High"], V5["5.55 clamp"]
        vs_des = V5["4.60 High"]
    else:
        vs_min, vs_max, vs_des = V3D["min"], V3D["max"], V3D["min"]
    i_hot = vs_min / (r23 * 1.1 * KT(T_HOT) + R_DRV)
    vcoil_min = vs_min - i_hot * R_DRV
    vcoil_des = vs_des - vs_des / (r23 * 1.1 * KT(T_HOT) + R_DRV) * R_DRV
    i_cold = vs_max / (r23 * 0.9 * KT(T_COLD) + R_DRV)
    vcoil_max = vs_max - i_cold * R_DRV
    P(f"\n{name}  (supply {sup})")
    P(f"  must-operate at 23 C {mo*vn:.2f} V -> at {T_HOT:.0f} C {vmo_hot:.2f} V")
    P(f"  coil voltage min {vcoil_min:.3f} V (stress corner) -> margin {vcoil_min - vmo_hot:+.3f} V "
      f"({(vcoil_min/vmo_hot-1)*100:+.1f} %); at the 4.60 V design corner {vcoil_des:.3f} V -> margin {vcoil_des-vmo_hot:+.3f} V")
    P(f"  coil voltage max {vcoil_max:.3f} V = {vcoil_max/vn*100:.0f} % of rated (max {mx*100:.0f} % instantaneous [DS]); "
      f"coil current max {i_cold*1e3:.1f} mA (cold coil, -10 % R, supply max)")
P("\nRequirement for any relay on 5V_SYS: V_mo(23 C) <= " f"{(V5['4.40 High'])/KT(T_HOT):.2f} V (zero margin) -> 5 V coils need "
  f"<= {(V5['4.40 High'])/KT(T_HOT)/5*100:.0f} % must-operate, 4.5 V coils <= {(V5['4.40 High'])/KT(T_HOT)/4.5*100:.0f} %.")
P(f"On 3V3D (3.25..3.33 V, regulated) any 3 V coil with must-operate <= {V3D['min']/KT(T_HOT)/3*100:.0f} % works, independent of VBUS.")
P("Recommendation: 3 V coil from 3V3D (coil loses power automatically when AUD_EN drops); USB budget uses 45 mA.")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
