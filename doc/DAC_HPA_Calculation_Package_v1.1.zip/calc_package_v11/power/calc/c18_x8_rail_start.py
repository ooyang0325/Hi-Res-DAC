"""c18 - R8 round 3 follow-up (analog X-8 adopted, message 25 Sep 2026 09:02): LM27762 start with EN = VIN (X-1) during the
TPS259621 dVdt ramp INCLUDING the I/V reservoirs: D411 VPOS -> N4_VPOS_IV, D412 N4_VNEG_IV -> VNEG (PMEG2010AEH), C442/C443
220 uF polymer (176-264 uF), OPA2210 load 17.4 / 14.8 mA on the I/V rails (moved from VPOS/VNEG). Usage: c18_x8_rail_start.py <C514 nF>
(each run appends its block to c18_x8_rail_start.out.txt and writes c18_<nF>nF.json). Labels as in pw_common."""
import json, os, sys
import numpy as np
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
R = load_basis(HERE)   # R10 F-3: final basis from c17 (c17_basis.json), else round-2 c03
CNF = float(sys.argv[1]) if len(sys.argv) > 1 else 10.0
FAST = len(sys.argv) > 2 and sys.argv[2] in ("reduced", "timing")   # reduced corner set (shared single-CPU host)
TIMING = len(sys.argv) > 2 and sys.argv[2] == "timing"            # + I_st 0.10/0.25 A and the firmware T_START metrics
C514 = CNF * 1e-9
DMIN, DMAX = R["DEF"][0], R["DEF"][2]; HMIN = R["HIGH"][0]
C_INT = TPS2596["C_DVDT_INT_EST"]
CLO, CHI = 0.9 * 0.95 * 0.95, 1.10 * 1.05       # X7R: tolerance, 0-60 C, ageing [ASSUMP]
SRMIN = TPS2596["IDVDT_MIN"] * TPS2596["GDVDT_MIN"] / (C514 * CHI + 1.5 * C_INT)
SRMAX = TPS2596["IDVDT_MAX"] * TPS2596["GDVDT_MAX"] / (C514 * CLO)
ISTS = (0.25, 0.50, 1.00)
UV = ((2.6, 2.4), (2.5, 2.2))
ILS = (("Default min", DMIN), ("Default max", DMAX), ("High min", HMIN))
if FAST:
    ISTS = (0.10, 0.25, 0.50, 1.00) if TIMING else (0.50, 1.00); UV = ((2.6, 2.4),)
grid = [(srk, ist, uv, il, ca, cr, cres, v5) for srk in (0, 1) for ist in ISTS for uv in UV for _, il in ILS
        for ca in ((5.0e-6,) if FAST else (5.0e-6, 12.1e-6)) for cr in ((33.8e-6,) if FAST else (15.6e-6, 33.8e-6))
        for cres in (176e-6, 264e-6) for v5 in ((4.30,) if FAST else (4.30, 5.50))]
n = len(grid)
g = lambda i: np.array([x[i] for x in grid])
SR = np.where(g(0) == 0, SRMIN, SRMAX); IST = g(1); UVR = np.array([x[2][0] for x in grid]); UVF = np.array([x[2][1] for x in grid])
ILM = g(3); CA = g(4); CR = g(5); CRES = g(6); V5 = g(7); CC = np.where(CR > 20e-6, 11e-6, 4.2e-6)
TD = 2 * (78.9e-6 + (247.3e-6 - 78.9e-6) / 3.3e-9 * C514)      # [ASSUMP] DS 7.7 typ delay scaled with C, x2 (upper bound)
VPS, VNS = 3.852, 3.721
I_IVP, I_IVN = 0.0174, 0.0148                                   # [analog X-8] OPA2210 + I/V networks on the I/V rails
IQP_R, IQN_R = R["IP"] - I_IVP, R["IN"] - I_IVN                 # remainder on VPOS/VNEG (OPA1622, comparators, sense)
VT_N, IS_D, RS_D = 0.026, 1.0e-5, 0.10                          # [ASSUMP fit] PMEG2010AEH-class: ~0.18 V/10 mA, 0.25 V/100 mA, 0.40 V/1 A
def sch(v):
    v = np.maximum(v, 0.0); i = np.zeros_like(v)
    for _ in range(3):
        i = IS_D * np.expm1(np.clip((v - i * RS_D) / VT_N, -50, 60)); i = np.minimum(i, v / RS_D)
    return i
dt = 0.5e-6 if FAST else 0.25e-6
T = float(np.max(TD) + 5.6 / SRMIN + 0.06)
van = np.zeros(n); vp = np.zeros(n); vn = np.zeros(n); vcp = np.zeros(n); vpi = np.zeros(n); vni = np.zeros(n)
on = np.zeros(n, bool); ever = np.zeros(n, bool); trips = np.zeros(n, int)
t_pg = np.full(n, np.nan); t_iv = np.full(n, np.nan); t_last_trip = np.zeros(n); t_ilim = np.zeros(n)
vmin = np.full(n, 9.0); e2596 = np.zeros(n); ipk = np.zeros(n)
ok40p = np.zeros(n, bool); ok41p = np.zeros(n, bool); t_ok40 = np.full(n, np.nan); t_ok41 = np.full(n, np.nan)
steps = int(T / dt)
for k in range(steps):
    t = k * dt
    vref = np.clip((t - TD) * SR, 0.0, V5)
    i_want = (vref - van) / TPS2596["RON_MAX"]
    i2596 = np.clip(i_want, 0.0, ILM)
    t_ilim += np.where(i_want > ILM, dt, 0.0)
    f = np.clip((vp + vn - 1.0) / 3.5, 0.0, 1.0); fiv = np.clip((vpi + vni - 1.0) / 3.5, 0.0, 1.0)
    ip = np.where(on, np.minimum(IST, np.maximum(0.0, 20.0 * (VPS - vp))), 0.0)
    ip = np.minimum(ip, np.maximum(0.0, (van - vp) / 0.45))
    icp = np.where(on, np.minimum(IST, np.maximum(0.0, (van - vcp) / 2.5)), 0.0)
    ineg = np.where(on, np.minimum(IST, np.maximum(0.0, 20.0 * (VNS - vn))), 0.0)
    ineg = np.minimum(ineg, np.maximum(0.0, (vcp - vn) / 0.30))
    idp = sch(vp - vpi); idn = sch(vn - vni)
    iin = ip + icp + np.where(on, 1e-3, 0.0) + van / 98.2e3 + van / 100e3 * 0.0
    pd = np.where(on, 0.0, 1.0 / 50e3)
    van = np.maximum(van + (i2596 - iin) / CA * dt, 0.0)
    vp = np.maximum(vp + (ip - IQP_R * f - vp * pd - idp) / CR * dt, 0.0)
    vn = np.maximum(vn + (ineg - IQN_R * f - vn * pd - idn) / CR * dt, 0.0)
    vcp = np.maximum(vcp + (icp - ineg) / CC * dt, 0.0)
    vpi = np.maximum(vpi + (idp - I_IVP * fiv) / CRES * dt, 0.0)
    vni = np.maximum(vni + (idn - I_IVN * fiv) / CRES * dt, 0.0)
    off_now = on & (van < UVF); on_now = (~on) & (van > UVR)
    trips += off_now; t_last_trip = np.where(off_now, t, t_last_trip); on = (on & ~off_now) | on_now; ever |= on_now
    vmin = np.where(ever, np.minimum(vmin, van), vmin)
    pg = np.isnan(t_pg) & (vp >= 0.95 * VPS) & (vn >= 0.95 * VNS); t_pg[pg] = t
    iv = np.isnan(t_iv) & (vpi >= 0.95 * (VPS - 0.30)) & (vni >= 0.95 * (VNS - 0.30)); t_iv[iv] = t
    e2596 += (V5 - van) * i2596 * dt; ipk = np.maximum(ipk, i2596)
    pgc = (vp >= 0.95 * VPS) & (vn >= 0.95 * VNS)                 # LM27762 PGOOD low (= RAILS_OK_N low) [DS Table 6-1, 95 % typ]
    ok40 = pgc & (van >= 4.00); ok41 = pgc & (van >= 4.12)          # 5V_ANA_F >= 4.00 V true / >= 4.12 V (reads >= 4.00 V at every ADC corner, c16 D)
    t_ok40 = np.where(ok40 & ~ok40p, t, t_ok40); t_ok41 = np.where(ok41 & ~ok41p, t, t_ok41)   # last false->true transition
    ok40p = ok40; ok41p = ok41
t_ok40 = np.where(ok40p, t_ok40, np.nan); t_ok41 = np.where(ok41p, t_ok41, np.nan)   # must still hold at the end (settled)
L = []; P = L.append
P(hdr(f"c18: rail start with the X-8 reservoirs, C514 = {CNF:.0f} nF (SR {SRMIN*1e-3:.3f}..{SRMAX*1e-3:.3f} V/ms; 0->5.5 V in"
      f" {5.5/SRMAX*1e3:.1f}..{5.5/SRMIN*1e3:.1f} ms; delay bound {float(np.max(TD))*1e3:.1f} ms [ASSUMP])"))
P("  " + basis_line(R))
P(f"  {n} corners ({'REDUCED set: SR min/max, I_st ' + str(ISTS) + ' A, UVLO 2.6/2.4 V, 5V_ANA 5 uF, rails 33.8 uF, 5V_SYS 4.30 V' if FAST else 'SR min/max, I_st ' + str(ISTS) + ' A per path, UVLO 2.6/2.4 and 2.5/2.2 V, 5V_ANA 5/12.1 uF, rails 15.6/33.8 uF, 5V_SYS 4.30/5.50 V'},"
  f" Default min/max + High min, reservoirs 176/264 uF), dt {dt*1e6:.2f} us, {T*1e3:.0f} ms; OPA2210 17.4/14.8 mA on the I/V rails,"
  f" remainder {IQP_R*1e3:.1f}/{IQN_R*1e3:.1f} mA on VPOS/VNEG; D411/D412 PMEG2010AEH-class fit [ASSUMP].")
P(f"  {'U503 limit':>12s} | {'PGOOD ms max':>12s} {'I/V rails 95 % ms max':>21s} {'UVLO trips max':>14s} {'last trip ms':>12s}"
  f" {'in ILIM ms max':>14s} {'5V_ANA_F min':>12s} {'U503 mJ':>8s}")
res = {}
for nm, il in ILS:
    m = ILM == il
    tp = "never" if np.any(np.isnan(t_pg[m])) else f"{np.nanmax(t_pg[m])*1e3:.1f}"
    ti = "never" if np.any(np.isnan(t_iv[m])) else f"{np.nanmax(t_iv[m])*1e3:.1f}"
    P(f"  {nm:>12s} | {tp:>12s} {ti:>21s} {int(trips[m].max()):14d} {t_last_trip[m].max()*1e3:12.1f} {t_ilim[m].max()*1e3:14.1f}"
      f" {vmin[m].min():12.2f} {e2596[m].max()*1e3:8.1f}")
    res[nm] = dict(t_pg=None if tp == "never" else float(np.nanmax(t_pg[m])), t_iv=None if ti == "never" else float(np.nanmax(t_iv[m])),
                   trips=int(trips[m].max()), t_last_trip=float(t_last_trip[m].max()), t_ilim=float(t_ilim[m].max()),
                   vmin=float(vmin[m].min()), e=float(e2596[m].max()), ipk=float(ipk[m].max()))
P(f"  U503 peak current {ipk.max()*1e3:.0f} mA (<= its limit in every corner); input current never above the U503 limit -> USB budget unchanged.")
P("  Firmware T_START metric: ANA_EN -> (RAILS_OK_N low AND 5V_ANA_F >= 4.00 V), settled (last false->true transition, still true at the end):")
for nm, il in ILS:
    for ist in ISTS:
        m = (ILM == il) & (IST == ist)
        a = t_ok40[m]; b = t_ok41[m]
        sa = "not reached" if np.any(np.isnan(a)) else f"{np.nanmax(a)*1e3:.1f} ms"
        sb = "not reached" if np.any(np.isnan(b)) else f"{np.nanmax(b)*1e3:.1f} ms"
        P(f"    {nm:11s} I_st {ist:4.2f} A: true 4.00 V {sa:>12s}; 4.12 V (ADC worst case) {sb:>12s}")
        res.setdefault("tstart", {})[f"{nm} {ist}"] = dict(t40=None if np.any(np.isnan(a)) else float(np.nanmax(a)),
                                                          t412=None if np.any(np.isnan(b)) else float(np.nanmax(b)))
TS40 = float(np.nanmax(t_ok40)) if not np.any(np.isnan(t_ok40)) else None
TS41 = float(np.nanmax(t_ok41)) if not np.any(np.isnan(t_ok41)) else None
res["TSTART"] = dict(t40=TS40, t412=TS41)
P(f"  -> worst over all corners: {TS40*1e3 if TS40 else float('nan'):.1f} ms (true 4.00 V), {TS41*1e3 if TS41 else float('nan'):.1f} ms (4.12 V)")
open(os.path.join(HERE, "c18_x8_rail_start.out.txt"), "a").write("\n".join(L) + "\n")
json.dump(dict(C514=C514, SR=(SRMIN, SRMAX), TD=float(np.max(TD)), res=res), open(os.path.join(HERE, f"c18_{CNF:.0f}nF" + ("_timing" if TIMING else "") + ".json"), "w"), indent=1)
print("\n".join(L))
