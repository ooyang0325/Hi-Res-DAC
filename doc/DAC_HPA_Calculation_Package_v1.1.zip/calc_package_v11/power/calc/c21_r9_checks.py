"""c21 - R9 fixes (decisions_r9.md): E-5 suspend inventory and options, E-8 C442/C443 reverse bias with D413/D414,
brown-out margin line, E-6 Default acceptance numbers. Labels as in pw_common.
Regenerated in R10 (decisions_r10 F-3): every Default figure is read from the final c17 run (R509 4.75 k, E-18); E-5 is kept as R9
history and marked superseded by E-16 (final S6 from c22); the brown-out line uses the final c17 loads and the TPS70933 3V3M range (c22)."""
import json, math, os
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
C17 = json.load(open(os.path.join(HERE, "c17_results.json")))
C22 = json.load(open(os.path.join(HERE, "c22_results.json")))
out = []; P = out.append
P(hdr("E-5  Suspend (S6, legacy A-to-C cable) - inventory on the planning values, corrected terms, options"))
P(f"  [R9 HISTORY - superseded (R9 E-16): the owner adopted the suspend power cut; final S6 = c22 {C22['S6']:.4f} mA legacy A-to-C"
  f" (margin {(2.5-C22['S6'])*1e3:+.0f} uA), {C22['S6']-0.094:.4f} mA C-to-C. The inventory below is the pre-E-16 circuit (U102 on, TPS7A20, D103).]")
inv = [("MCU Stop + USB-HS PHY suspended [PH brief s6, L-1; typ 0.11 mA]", 1.900, "fixed (E-5)"),
       ("D+ 1.5 k pull-up into the host 15 k (USB 2.0, mandatory)", 0.214, "fixed"),
       ("legacy A-to-C cable Rp 56 k -> Rd 5.1 k (Type-C, mandatory)", 0.094, "fixed"),
       ("U102 TPS25200 IIN(on) [DS 190 uA at 150 k / 200 uA at 33 k; 100 k interpolated by ILIM conductance]", 0.1914, "power"),
       ("U102 EN leakage through R109 [DS IEN 2 uA]", 0.002, "power"),
       ("U502 TPS7A20 IGND at the MCU load [DS]", 0.025, "power"),
       ("VBUS_SENSE divider R105/R106 100 k/47 k at 5.5 V", 0.0374, "power"),
       ("D102 SMDJ12A leakage at 5.5 V/50 C [c16 C estimate 3.0 uA; budget 5 uA]", 0.005, "power"),
       ("D103-D105 BAT54 reverse leakage at 50 C (D104/D105 5 V, D103 1.7 V) - corrected bound", None, "power"),
       ("U101 USBLC6, U504 ISHDN, U302, U503 ISD, U505, U103 [DS]", 0.001 + 0.003 + 0.001 + 0.00113 + 0.0007 + 0.00002, "power"),
       ("protection U605 + dividers (3V3A off) [protection R3.7]", 0.0076, "protection"),
       ("MCU suspend IWDG wake (DX-2) [digital]", 0.0045, "digital")]
# BAT54 leakage bound: IR <= 2 uA at 25 V, 25 C [Nexperia DS]; Schottky IR ~ T^2 exp(-q phiB / kT): phiB 0.65 V [ASSUMP] -> x8.3 at 50 C;
# voltage factor vs 25 V: 0.5 at 5 V, 0.3 at 1.7 V [ASSUMP, barrier lowering]
kT = (323.15 / 298.15) ** 2 * math.exp(0.65 / 8.617e-5 * (1 / 298.15 - 1 / 323.15))
bat = 2e-6 * kT * (0.5 + 0.5 + 0.3) * 1e3
inv[8] = (inv[8][0], bat, "power")
tot = sum(x[1] for x in inv)
for nm, i, own in inv:
    P(f"  {nm:112s} {i:7.4f} mA  [{own}]")
P(f"  TOTAL S6 (A-to-C) = {tot:.4f} mA vs 2.500 mA -> margin {(2.5-tot)*1e3:+.1f} uA  (c17: 2.4965 mA with 10 uA for D103-D105 and 190 uA for U102)")
P(f"  BAT54 bound: 2 uA (25 V, 25 C) x {kT:.1f} (50 C, phiB 0.65 V) x (0.5 + 0.5 + 0.3) = {bat*1e3:.1f} uA [CALC/ASSUMP]; typical ~1.5 uA total;"
  " the reviewer's 12 uA lies inside this bound -> the 10 uA allowance of X-4 is NOT guaranteed.")
fixed = 1.900 + 0.214 + 0.094
P(f"  Fixed by the planning value and USB/Type-C: {fixed:.3f} mA -> everything else must be <= {2.5-0.2-fixed:.3f} mA for a 0.2 mA margin;"
  f" it is {tot-fixed:.3f} mA, of which U102 {0.1914+0.002:.3f} mA.")
P("  Options (power side), saving -> verdict:")
P("   a) VBUS divider 10x higher (1 M/470 k): -34 uA; REJECTED - the 1 uA pin-leakage bound [ASSUMP digital] x 320 k = 0.32 V at PA1 = 1.0 V on 5V_SYS"
  " (band 3.756-4.244 V would widen past the 4.311 V operating minimum -> false brown-out trips).")
P("   b) BAT54 -> lower-leakage diode (BAS70 class, IR <= 0.1 uA at 50 V): -20 uA; REJECTED - VF 0.75-1.0 V at the 10-50 mA reverse currents of c14 -> body"
  " diodes conduct again (X-4 / L-8 residual 0.40-0.46 V would be lost).")
P("   c) protection U605 dividers x10 (protection), digital pin states (digital): <= -7 uA / digital's figure.")
P("   => no drop-in or BOM change reaches a 0.2 mA margin: the U102 IQ (0.19 mA) alone is 95 % of the missing 0.2 mA.")
P("   Designed-in fallback (circuit change, owner/orchestrator decision): 'suspend power cut' - U502 becomes a 30 V low-IQ LDO fed from VBUS"
  " (e.g. TI TPS70933, IQ ~1-2 uA, 150 mA [DS to be re-read]) and an NMOS on U102 EN (MCU GPIO, default = U102 on) turns U102 off in Stop:"
  " U102 5 uA (IIN(off) [DS]), divider 0, D104/D105 0 ->")
fb = fixed + 0.005 + 0.002 + 0.005 + 0.005 + 0.0076 + 0.0045 + 0.001
P(f"      S6 ~ {fb:.3f} mA (margin {(2.5-fb)*1e3:+.0f} uA). Costs/impacts: attach region A +20.3 uC (3V3M caps charge at contact) -> C102 4.7 -> 2.2 uF"
  " (c16 C already covers 2.16 uF effective), 3V3M accuracy/transient re-check (protection U605 thresholds use 3V3M +-1.5 %), a free MCU GPIO"
  " (digital), resume sequence (U102 on, 5V_SYS up <= 7.3 ms before any domain), c01/c02/c14/c16/c17 re-runs. Adopted as E-16 (R9) -> c22.")
res = dict(S6_preE16=tot, BAT54=bat, S6_fallback_R9_estimate=fb, S6_final_c22=C22["S6"], S6_final_c22_CC=C22["S6"] - 0.094)

P(hdr("E-8  C442/C443 (AVX TAJD227K010RNJ since VE, MnO2, 10 V) reverse bias during LM27762 start/off, with D413/D414 (BAT54) clamps"))
P("  [R10: register A-17 uses analog r9_fixes E-8 (13.0 mA = OPA2210 4 x 3.25 mA [DS]; AVX rule): <= 0.469 V at 0 C vs 1.00 V, <= 0.386 V at 50 C vs 0.71 V."
  " This section is the power cross-check with the larger I/V-rail loads (17.4 / 14.8 mA) and -1 mV/K; the limits now follow the AVX rule"
  " (10 % of VR up to 25 C, 3 % at 85 C, linear [ASSUMP]) instead of the pre-VE KEMET T495 rule (15 % -> 5 %).]")
I_IVP, I_IVN = 0.0174, 0.0148   # [analog X-8] maximum I/V-rail loads (the current that can drive the other reservoir reverse)
def vf_bat54(i, dT=0.0):
    pts = [(1e-4, 0.24), (1e-3, 0.32), (1e-2, 0.40), (3e-2, 0.50), (1e-1, 0.80)]   # [DS Nexperia maxima, 25 C]
    for (i0, v0), (i1, v1) in zip(pts, pts[1:]):
        if i0 <= i <= i1:
            return v0 + (v1 - v0) * math.log(i / i0) / math.log(i1 / i0) - 0.001 * dT   # -1 mV/K [ASSUMP Schottky tempco]
    return pts[-1][1]
for nm, i in (("C442 (N4_VPOS_IV pulled below GND by the V+ supply current while VNEG_IV is up)", I_IVP),
              ("C443 (N4_VNEG_IV pulled above GND by the V- supply current while VPOS_IV is up)", I_IVN)):
    for T in (0.0, 25.0, 50.0, 60.0):
        v = vf_bat54(i, T - 25.0)
        lim = 10.0 * (0.10 - 0.07 * max(0.0, T - 25.0) / 60.0)   # AVX TAJ: 10 % up to 25 C, 3 % at 85 C (linear [ASSUMP]); was KEMET 15 % -> 5 % (pre-VE)
        P(f"  {nm:88s} T {T:4.0f} C: reverse <= {v:.3f} V (BAT54 at {i*1e3:.1f} mA) vs limit {lim:.2f} V -> margin {lim-v:+.2f} V")
P("  Mechanism: D411/D412 block VPOS/VNEG excursions (R3.17); a reservoir can only be reversed through the OPA2210 supply pins when the other I/V rail"
  " is up and its own is empty (start: EN = VIN releases both LM27762 paths together, either may lead; off: the rail that empties first). The"
  " reverse current is bounded by that rail's maximum load (17.4 / 14.8 mA), which D413/D414 carry at <= 0.45 V (25 C), <= 0.43 V (50 C)."
  " Duration: until the other LM27762 path catches up (start, <= the 18.8 ms start) or the reservoirs discharge (off, tens of ms) - inside"
  " the steady-state reverse rating used here (no pulse credit taken).")
P("  -> open item 6 CLOSED: reverse bias <= 0.48 V at 0 C and <= 0.43 V at 50 C vs >= 0.59 V allowed (60 C local) [AVX reverse-voltage rule,"
  " linear between 25 and 85 C = ASSUMP]; margin >= +0.17 V with these conservative currents (analog, 13.0 mA: >= +0.22 V).")

P(hdr("Brown-out margin line (thin-margins table, R9-A A8) - R10: final c17 loads, TPS70933 3V3M range (c22)"))
# c09 band: divider 1.4 % + VDDA (ratiometric, VDDA = 3V3M) + |abs| (PA1 leakage 1 uA x R105 [ASSUMP] + ADC 11 LSB [DS]); c04 path to 5V_SYS:
# TPS25200 RON max 99 mOhm + 20 mOhm copper [ASSUMP], VBUS 4.40 V at the J101 pads; J101 sensitivity 4 + 4 mated contacts x 40 mOhm [DS]
k_div = 47.0 / 147.0
e_abs = 1e-6 * 100e3 + (4 + 3 + 4) * 3.3 / 4096 / k_div
v3lo, v3hi = C22["v3m"]
band_old = (4.00 * (1 - 0.014 - 0.015) - e_abs, 4.00 * (1 + 0.014 + 0.015) + e_abs)
band = (4.00 * (1 - 0.014 + (v3lo / 3.3 - 1)) - e_abs, 4.00 * (1 + 0.014 + (v3hi / 3.3 - 1)) + e_abs)
R_PATH = TPS25200["RON_MAX"] + 0.020; R_J101 = 2 * 0.040 / 4
R_LM = TPS2596["RON_MAX"] + 0.050 + 0.010                   # U503 RON max + FB501 DCR max + copper (c04)
S = C17["S"]; DEF = C17["DEF"]; HIGH = C17["HIGH"]
B = load_basis(HERE)                                            # c17_basis.json: same currents as c04 (non-analog + IOS max + TPS2596 IQ)
i_def, i_high = B["NONANA"] + B["DEF"][2] + B["IQ2596"], B["NONANA"] + B["HIGH"][2] + B["IQ2596"]
I_BYP = u502_bypass(B)                                        # E-16: U502 input bypasses the U102 RON (copper still at the full current)
drop = lambda i: i * 0.020 + (i - I_BYP) * TPS25200["RON_MAX"]
v5 = {"High, VBUS 4.40 V": 4.40 - drop(i_high), "High, with the J101 mated-contact drop": 4.40 - drop(i_high) - i_high * R_J101,
      "Default, VBUS 4.40 V": 4.40 - drop(i_def)}
v5_r2 = {"High, VBUS 4.40 V": 4.311, "High, with the J101 mated-contact drop": 4.296, "Default, VBUS 4.40 V": 4.342}
P(f"  VBUS_SENSE trip band on 5V_SYS {band[0]:.3f} .. {band[1]:.3f} V: divider 1.4 %, VDDA = 3V3M {v3lo:.3f}..{v3hi:.3f} V"
  f" ({(v3lo/3.3-1)*100:+.2f} / {(v3hi/3.3-1)*100:+.2f} %, TPS70933 [DS], c22), pin leakage 1 uA x 100 k [ASSUMP] 100 mV, ADC 11 LSB [DS]"
  f" {(e_abs-0.1)*1e3:.0f} mV. (c09, round 2, TPS7A20 VDDA +-1.5 %: {band_old[0]:.3f} .. {band_old[1]:.3f} V - superseded by E-16.)")
P(f"  5V_SYS minimum with the c04 method on the final basis ({i_def*1e3:.2f} / {i_high*1e3:.2f} mA through U102; c04 before R10: round-2 487.1 / 748.1 mA;"
  f" since E-16 the U502 input {I_BYP*1e3:.1f} mA bypasses the U102 RON):")
for nm, v in v5.items():
    P(f"  5V_SYS min {nm:40s} {v:.3f} V (c04 round-2 loads {v5_r2[nm]:.3f} V) -> margin to the band top {(v-band[1])*1e3:+.0f} mV"
      f" (R9 figure {(v5_r2[nm]-band_old[1])*1e3:+.0f} mV)")
mb = [(v - band[1]) * 1e3 for v in v5.values()]
P(f"  -> brown-out margin at the 4.40 V corner {min(mb):+.0f} ... {max(mb):+.0f} mV (R9: +52 ... +98 mV); dominated by the assumed 1 uA PA1 leakage"
  f" (100 mV). The band bottom {band[0]:.3f} V holds only while 3V3M is in regulation (L-12: slow sag backed by the PVD on 3V3M).")
vin_lm = {"Default": v5["Default, VBUS 4.40 V"] - DEF[2] * 1e-3 * R_LM, "High": v5["High, VBUS 4.40 V"] - HIGH[2] * 1e-3 * R_LM}
P(f"  By-product (input of analog R-46, High headroom at VBUS 4.40 V): LM27762 VIN min Default {vin_lm['Default']:.3f} V, High {vin_lm['High']:.3f} V"
  f" (c04 round-2 loads and R510 3.83 k: 4.300 / 4.219 V).")
res.update(dict(BO_BAND=band, BO_V5MIN=v5, BO_MARGIN_MV=[min(mb), max(mb)], LM27762_VIN_440=vin_lm))

P(hdr("E-6  Default mode - explicit margins and acceptance criterion (final: R9 E-17/E-18/E-21, c17 final run)"))
NEED = C17["NEED"]; SN = C17["S_NDK"]
P(f"  Design values (c17 final, R509 {C17['R509']/1e3:.2f} k owner-fitted, E-18): Default total {S['S3']:.2f} mA vs 500 mA ({500-S['S3']:+.2f});"
  f" with the NDK X201 second source {SN['S3']:.2f} mA ({500-SN['S3']:+.2f}, E-27); IOS min/nom/max {DEF[0]:.2f} / {DEF[1]:.1f} / {DEF[2]:.1f} mA;"
  f" Default need {NEED:.2f} mA (c17: analog need_for() incl. R10 F-1 + ANA_SENSE)"
  f" -> margin {DEF[0]-NEED:+.2f} mA.")
P(f"  Conservatism of the planning values inside the {S['S3']:.2f} mA: MCU 80 mA vs WCH 22.4 mA typ (+57.6 mA), CPLD 40 mA [ASSUMP, unpublished],"
  " DVDD 60 mA [PH] vs ESS 50 mA nominal (+10), U208 70 % burst at 36 MHz (+~0.8), DVCC/AVCC at nominal-as-max (L-1).")
alt = []
for rv in (4780.0, 4840.0):          # the adjacent E192 value and the E-17 fallback value (the round-3 4.81 k is history)
    mn, nm_, mx = [x * 1e3 for x in tps2596_ios(rv, mode="headline")]
    alt.append((rv, mn, S["S3"] - (DEF[2] - mx)))
a1 = alt[0]
P(f"  No BOM change widens both margins: R509 trades them 1 : {(S['S3']-a1[2])/(DEF[0]-a1[1]):.2f} (4.78 k: {S['S3']-a1[2]:+.2f} mA USB margin,"
  f" {a1[1]-DEF[0]:+.2f} mA need margin); the +-10.4 % TPS2596 limit tolerance [DS] ({DEF[2]-DEF[0]:.0f} mA window) is the cause. "
  + "; ".join(f"{rv/1e3:.2f} k: IOS min {mn:.2f} mA ({mn-NEED:+.2f} vs the need), total {tot:.2f} mA" for rv, mn, tot in alt) + ".")
P(f"  Acceptance criterion (E-17/E-18/E-21): Default output-power targets at IOS min {DEF[0]:.2f} mA vs the need {NEED:.2f} mA ({DEF[0]-NEED:+.2f} mA;"
  " E (register A-35, R10 F-2): the need contains the LM27762 IQ without a published maximum and the estimated CP factor 1.03;"
  f" the R9 release quoted 178.82 / +1.23 mA from the rounded analog base); USB <= 500 mA with {500-S['S3']:.2f} mA on the planning values (E; {500-SN['S3']:.2f} mA with the NDK X201); production"
  " test on every board (Q, an open obligation until boards exist): VBUS current in S3 (Default, full-scale 1 kHz sine into the worst Default load,"
  " 25 C) <= 480 mA (20 mA below 500 mA) and S1 <= 90 mA; a failing board gets the firmware Default-mode volume ceiling (E-21); R509 4.84 k"
  f" is no longer an option (IOS min {alt[1][1]:.2f} mA < the need).")
res.update(dict(S3=S["S3"], S3_NDK=SN["S3"], IOSmin=DEF[0], IOSmax=DEF[2], NEED=NEED, MARGIN_DEF=DEF[0] - NEED, R509=C17["R509"]))
P(hdr("R10 addendum (F-2 walk, row R-54): ANA_SENSE 4.00 V supply-fault threshold with the VBUS_SENSE error treatment"))
# same divider (R535/R536 100 k / 47 k 1 %) and ADC as VBUS_SENSE; c16 D / c20 c used divider + VDDA 1.5 % only ("ADC error ignored")
band_c20 = (4.00 * (1 - 0.014 - 0.015), 4.00 * (1 + 0.014 + 0.015))
band_na = (4.00 * (1 - 0.014 + (v3lo / 3.3 - 1)), 4.00 * (1 + 0.014 + (v3hi / 3.3 - 1)))
I_HIGH_NEED = 0.3201                                          # [analog r9_fixes / E-18 row] High peak need at 5V_ANA
v5f = {"Default at IOS max": v5["Default, VBUS 4.40 V"] - DEF[2] * 1e-3 * R_LM,
       "High at IOS max": v5["High, VBUS 4.40 V"] - HIGH[2] * 1e-3 * R_LM,
       "High at the 320.1 mA peak need": v5["High, VBUS 4.40 V"] - I_HIGH_NEED * R_LM,
       "High at the peak need, J101 contact drop": v5["High, with the J101 mated-contact drop"] - I_HIGH_NEED * R_LM}
P(f"  Threshold band on 5V_ANA_F: c20 (divider + VDDA 1.5 %, ADC error ignored) {band_c20[0]:.3f} .. {band_c20[1]:.3f} V; with the TPS70933 VDDA"
  f" {band_na[0]:.3f} .. {band_na[1]:.3f} V; + ADC 11 LSB and 1 uA PA0 leakage [ASSUMP, as VBUS_SENSE] {band[0]:.3f} .. {band[1]:.3f} V.")
for nm, v in v5f.items():
    P(f"  5V_ANA_F min at VBUS 4.40 V, {nm:42s} {v:.3f} V -> vs band top {band[1]:.3f} V: {(v-band[1])*1e3:+4.0f} mV;"
      f" without the leakage term ({band_na[1]+e_abs-0.1:.3f} V): {(v-band_na[1]-e_abs+0.1)*1e3:+4.0f} mV")
P("  -> (with a common 4.00 V threshold) Default: no false supply fault at any corner. High at VBUS 4.40 V: a reading below 4.00 V is possible only when the assumed 1 uA PA0"
  " leakage, the ADC error, the divider and VDDA all take their worst sign at once (4.40 V in High mode is below what a 1.5 A Type-C source"
  " delivers through a compliant cable; L-3 corner). Firmware option (digital): High-mode threshold 3.90 V -> band top "
  f"{band[1]-0.10*(1+0.014+(v3hi/3.3-1)):.3f} V. Not a hardware change.")
TH_HIGH = 3.90                                                # ADOPTED by digital (R10, firmware_sequences 3 / adc_settings 3): High mode (ILIM_HI = 1)
code_hi = round(TH_HIGH * k_div / 3.3 * 4096)
band_hi = (TH_HIGH * (1 - 0.014 + (v3lo / 3.3 - 1)) - e_abs, TH_HIGH * (1 + 0.014 + (v3hi / 3.3 - 1)) + e_abs)
P(f"  ADOPTED (digital R10): High-mode threshold {TH_HIGH:.2f} V = {TH_HIGH*k_div:.3f} V = code {code_hi} (switches with ILIM_HI, i.e. only with the switch open"
  f" or inside the downgrade sequence); band {band_hi[0]:.3f} .. {band_hi[1]:.3f} V -> High margins at VBUS 4.40 V: peak need"
  f" {(v5f['High at the 320.1 mA peak need']-band_hi[1])*1e3:+.0f} mV, with the J101 contact drop {(v5f['High at the peak need, J101 contact drop']-band_hi[1])*1e3:+.0f} mV;"
  f" Default keeps 4.00 V = 1587 counts ({(v5f['Default at IOS max']-band[1])*1e3:+.0f} mV). A short still reads ~0 V.")
res.update(dict(ANA_SENSE_BAND=band, V5F_440=v5f, ANA_SENSE_HIGH_TH=TH_HIGH, ANA_SENSE_HIGH_CODE=code_hi, ANA_SENSE_HIGH_BAND=band_hi))
json.dump(res, open(os.path.join(HERE, "c21_results.json"), "w"), indent=1)
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
