"""c01 - Input OVP (TPS25200) : downstream abs-max check, hot-plug ringing, ESD charge, hot-short kick."""
import math, itertools
import numpy as np
from pw_common import *

out = []
P = out.append

P(hdr("1. Downstream absolute-maximum ratings vs the TPS25200-protected 5V_SYS"))
v5_clamp_max = TPS25200["VOVC_MAX"]
P(f"5V_SYS <= min(VBUS, V(OVC)max) = min(VBUS, {v5_clamp_max:.2f} V) for VBUS < V(OVLO)min {TPS25200['VOVLO_MIN']} V [DS];"
  f" above V(OVLO) the switch is open (5V_SYS -> 0).")
parts = [
    ("LM27762 VIN (via TPS2553+FB501)", LM27762["VIN_ABS"], LM27762["VIN_OP_MAX"]),
    ("LP5907 VIN / EN", LP5907["VIN_ABS"], LP5907["VIN_OP_MAX"]),
    ("TPS7A20 VIN / EN", TPS7A20["VIN_ABS"], TPS7A20["VIN_OP_MAX"]),
    ("TPS2553 IN/EN/FAULT/ILIM", TPS2553["VABS"], 6.5),
    ("TLV767 VIN / EN", TLV767["VIN_ABS"], TLV767["VIN_OP_MAX"]),
    ("USBLC6-2SC6 VBUS pin (Transil VBR min, must not conduct)", USBLC6["VBR_MIN"], 5.25),
]
P(f"{'part':58s} {'abs max':>8s} {'op max':>7s} {'margin to 5.55 V clamp':>24s}")
for n, a, o in parts:
    P(f"{n:58s} {a:8.2f} {o:7.2f} {a - v5_clamp_max:+24.2f}")
worst = min(parts, key=lambda x: x[1])
P(f"Lowest downstream abs max: {worst[0]} = {worst[1]} V -> margin {worst[1]-v5_clamp_max:.2f} V (static clamp) [CALC]")
P("In-spec VBUS (<= 5.50 V): 5V_SYS <= 5.50 V, never disconnected (clamp min 5.25 V only limits, it does not trip).")
P("Note: between 5.50 V and 5.55 V the LP5907 (op max 5.5 V) and LM27762 (op max 5.5 V) are above their operating "
  "range but inside abs max; this only happens for an out-of-spec source.")

P(hdr("2. Hot-plug ringing (USB-A-to-C into a live port): peak at J101/TPS25200 IN, switch still OFF"))
P("Model: ideal 5.50 V step through cable R,L into C_VBUS (series RLC). TPS25200 is off for t_on (5.12 ms typ,"
  " 7.3 ms max [DS]); ringing decays within ~100 us -> downstream never sees it.")
Vs = VBUS_MAX
res = []
for C in (0.8e-6, 1.1e-6, 3.0e-6, 5.2e-6):
    for L in (0.25e-6, 0.5e-6, 1.0e-6, 1.5e-6):
        for R in (0.05, 0.1, 0.2, 0.4):
            zeta = R / 2 * math.sqrt(C / L)
            if zeta < 1:
                os_ = math.exp(-zeta * math.pi / math.sqrt(1 - zeta ** 2))
            else:
                os_ = 0.0
            vpk = Vs * (1 + os_)
            ipk = Vs / math.sqrt(L / C) * math.exp(-zeta * math.atan(math.sqrt(1 - zeta**2) / max(zeta, 1e-9)) / math.sqrt(max(1 - zeta**2, 1e-9))) if zeta < 1 else Vs / R
            tdecay = 4 * 2 * L / R   # 4 time constants of the envelope
            res.append((vpk, C, L, R, zeta, tdecay))
res.sort(reverse=True)
P(f"{'Vpk':>6s} {'C_eff':>7s} {'L':>7s} {'R':>5s} {'zeta':>6s} {'4*tau_env':>10s}")
for r in res[:6]:
    P(f"{r[0]:6.2f} {r[1]*1e6:6.2f}u {r[2]*1e6:6.2f}u {r[3]:5.2f} {r[4]:6.3f} {r[5]*1e6:8.1f}us")
vmax = max(r[0] for r in res)
P(f"Worst peak {vmax:.2f} V (<= 2 x 5.50 = 11.0 V) vs TPS25200 IN abs max {TPS25200['VIN_ABS']} V -> margin "
  f"{TPS25200['VIN_ABS']-vmax:.1f} V; C102 50 V rating -> margin {50-vmax:.0f} V [CALC]")
P(f"Longest envelope decay (4 tau) {max(r[5] for r in res)*1e6:.0f} us << TPS25200 turn-on (ms) [CALC; t_on min not "
  "specified, typ 5.12 ms -> ASSUMP t_on >= 1 ms]")

P(hdr("3. ESD charge on VBUS (IEC 61000-4-2 contact 8 kV, 150 pF) absorbed by C_VBUS (no TVS on raw VBUS)"))
q = 8000 * 150e-12
for name, ceff in (("1 uF 0603 50V, derated", 1e-6 * 0.9 * 0.85 * 0.80), ("4.7 uF 0805 25V, derated", 4.7e-6 * 0.9 * 0.85 * 0.60)):
    P(f"{name:30s} C_eff {ceff*1e6:5.2f} uF : dV = {q/ceff:5.2f} V -> V_IN <= {VBUS_MAX + q/ceff:5.2f} V (< 20 V) [CALC, ESL ignored]")

P(hdr("4. Hard short on 5V_SYS while running: cable-inductance kick at TPS25200 IN"))
P("Model: source 5.5 V, cable R_c/L_c, C_VBUS at IN; short behind TPS25200 Ron=0.06 ohm (typ, gives the largest current)"
  " until t_IOS, then output current limited to IOS max 1.24 A. t_IOS = 3.5 us [DS-typ, reference only]; 7 us checked.")
def kick(C, L, Rc, tios, ron=0.06, i0=0.5, ilim=1.24):
    dt = 5e-9
    v = VBUS_MAX - Rc * i0
    i = i0
    t = 0.0
    vpk = v
    ipk = i
    while t < 200e-6:
        iout = v / ron if t < tios else ilim
        di = (VBUS_MAX - Rc * i - v) / L
        dv = (i - iout) / C
        i += di * dt
        v += dv * dt
        t += dt
        vpk = max(vpk, v)
        ipk = max(ipk, i)
    return vpk, ipk
rows = []
for C in (0.72e-6, 2.16e-6):   # 1 uF / 4.7 uF derated effective
    for L in (0.5e-6, 1.0e-6, 1.5e-6):
        for Rc in (0.1, 0.2):
            for tios in (3.5e-6, 7e-6):
                vpk, ipk = kick(C, L, Rc, tios)
                rows.append((C, L, Rc, tios, vpk, ipk))
P(f"{'C_eff':>7s} {'L':>6s} {'Rc':>5s} {'t_IOS':>6s} {'Vpk_IN':>7s} {'Ipk':>6s}")
for r in rows:
    flag = "  <-- exceeds 20 V" if r[4] > 20 else ""
    P(f"{r[0]*1e6:6.2f}u {r[1]*1e6:5.1f}u {r[2]:5.2f} {r[3]*1e6:5.1f}u {r[4]:7.2f} {r[5]:6.2f}{flag}")
worst1 = max(r[4] for r in rows if r[0] < 1e-6)
worst47 = max(r[4] for r in rows if r[0] > 1e-6)
P(f"Worst V_IN peak: C102 = 1 uF -> {worst1:.1f} V ; C102 = 4.7 uF -> {worst47:.1f} V (abs max 20 V) [CALC]")
P("Decision: C102 = 4.7 uF 25 V X5R 0805 at the TPS25200 IN pin (keeps the kick below 20 V with margin in the "
  "stated envelope; attach charge re-checked in c02).")

P(hdr("5. Why not a disconnect-type OVP with adjustable OVLO or the TPS2596x 5.7 V clamp option"))
ref_lo, ref_hi, rt = 1.17, 1.22, 0.001        # [DS] TPS25963x VOVLO(R) 1.17..1.22 V; 0.1 % divider
k_min = 5.50 / (ref_lo * (1 - 2 * rt))         # smallest ratio that never trips at 5.50 V
v_hi = ref_hi * k_min * (1 + 2 * rt)
P(f"TPS25963x adjustable OVLO: ratio >= {k_min:.4f} to keep the trip >= 5.50 V -> trip band 5.500..{v_hi:.3f} V; margin to "
  f"LM27762 5.8 V = {5.8 - v_hi:.3f} V, margin above vSafe5V max = 0.000 V; IQ 259 uA max [DS] [CALC]")
P("TPS25962x 5.7 V clamp option: clamp threshold 5.54..5.83 V [DS] -> 5V_SYS can reach 5.83 V > 5.8 V before clamping.")
P("TPS25200: output clamp 5.25..5.55 V for VIN < 6.8 V, OVLO above -> chosen.")

P(hdr("R8 round 3 note")); P("  Section 4 (hard-short kick with tIOS 3.5/7 us) is SUPERSEDED by c16_r3_review_fixes.out.txt section C: no tIOS credit, cable R 0.05-0.4 ohm / L 0.25-1.5 uH, D102 SMDJ12A -> U102 IN <= 17.0 V; without a TVS up to 50 V. Section 3 (ESD charge, no TVS) is superseded by D102. E-16 (R9): kick with C102 2.2 uF <= 17.08 V (c22 section 3); U502 TPS70933 on VBUS (32 V abs).")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
