"""c16 - R8 review fixes round 3 (decisions_r8c.md X-1, X-2, X-3, X-5, X-10 power items). Sections write their own
output file c16_r3_review_fixes.out.txt (appended section by section so an interrupted run keeps what was computed).
  A  X-1: LM27762 EN+/EN- tied to VIN (5V_ANA_F); start during the TPS259621 dVdt ramp, C514 sweep, UVLO cycling
  B  X-2: C104 on U102 EN (earliest/latest turn-on) and the two USB-IF attach regions (with D102 capacitance)
  C  X-3: D102 VBUS TVS - hard-short cable kick with NO tIOS credit, cable R/L envelope incl. 0.05 ohm
  D  X-5: ANA_SENSE divider R535/R536 + C516
  E  X-10: C103 100 pF C0G; R508 10 k with R237 4.7 k (AUD_EN levels)
Labels as in pw_common."""
import json, os, math, sys
import numpy as np
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
OUTF = os.path.join(HERE, "c16_r3_review_fixes.out.txt")
R = load_basis(HERE)   # R10 F-3: final basis from c17 (c17_basis.json), else round-2 c03
RES = {}
def emit(lines):
    with open(OUTF, "a") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines)); sys.stdout.flush()
SECTIONS = sys.argv[1:] or ["A", "B", "C", "D", "E"]
if SECTIONS == ["A", "B", "C", "D", "E"] and os.path.exists(OUTF):
    os.remove(OUTF)

# ------------------------------------------------------------------------------------------------ A  X-1
if "A" in SECTIONS:
    L = []; P = L.append
    P(hdr("A. X-1: LM27762 EN+/EN- = VIN (5V_ANA_F); rails start during the TPS259621 dVdt ramp after ANA_EN"))
    P("  [history: the release start model is c18 (X-8 reservoirs); " + basis_line(R) + "]")
    P("  EN abs max GND-0.3 V .. VIN [DS 5.1] -> met by construction (EN = VIN in every state: start, cycling, shutdown, unplug).")
    P("  EN VIH 1.2 V [DS] is reached below the UVLO rising threshold (2.6 V typ, no min/max [DS-typ 6.3.1]) -> the LM27762 starts")
    P("  when 5V_ANA_F crosses its UVLO; with the rails at 0 V (50 k pull-downs) its LDO/charge pump draw their start current")
    P("  I_st (NOT specified; 500 mA typ 'input current limit with the output shorted' [DS-typ 6.3.2]) into the rail capacitors.")
    DMIN, DNOM, DMAX = R["DEF"]; HMIN = R["HIGH"][0]
    C514S = (10e-9, 47e-9, 100e-9, 220e-9)
    C_INT = TPS2596["C_DVDT_INT_EST"]
    def sr(c):   # (min, max) V/s
        return (TPS2596["IDVDT_MIN"] * TPS2596["GDVDT_MIN"] / (c * 1.10 + 1.5 * C_INT),
                TPS2596["IDVDT_MAX"] * TPS2596["GDVDT_MAX"] / (c * 0.90))
    ISTS = (0.10, 0.15, 0.25, 0.50, 1.00)
    UV = ((2.6, 2.4), (2.7, 2.6), (2.5, 2.2))            # (rising, falling): typ, narrow-high, wide-low [ASSUMP around DS-typ]
    ILS = (("Default min", DMIN), ("Default max", DMAX), ("High min", HMIN))
    C_AN = (5.0e-6, 12.1e-6); C_RL = (15.6e-6, 33.8e-6); V5S = (4.30, 5.50)
    grid = [(c, srk, ist, uv, nm, il, ca, cr, v5) for c in C514S for srk in (0, 1) for ist in ISTS for uv in UV
            for nm, il in ILS for ca in C_AN for cr in C_RL for v5 in V5S]
    n = len(grid)
    g = lambda i: np.array([x[i] for x in grid])
    CD = g(0); SRK = g(1); IST = g(2); UVR = np.array([x[3][0] for x in grid]); UVF = np.array([x[3][1] for x in grid])
    ILM = g(5); CA = g(6); CR = g(7); V5 = g(8)
    CC = np.where(CR > 20e-6, 11e-6, 4.2e-6)
    SR = np.array([sr(c)[k] for c, k in zip(CD, SRK)])
    TD = 2 * (78.9e-6 + (247.3e-6 - 78.9e-6) / 3.3e-9 * CD)   # [ASSUMP] turn-on delay x2 (DS 7.7 typ scaled with C)
    VPS, VNS = 3.852, 3.721
    IQP, IQN = R["IP"], R["IN"]
    dt = 0.25e-6
    T = float(np.max(TD + 5.6 / SR)) + 8e-3
    van = np.zeros(n); vp = np.zeros(n); vn = np.zeros(n); vcp = np.zeros(n)
    on = np.zeros(n, bool); ever = np.zeros(n, bool); trips = np.zeros(n, int); t_good = np.full(n, np.nan)
    van_min_after = np.full(n, 9.0); e2596 = np.zeros(n); ipk = np.zeros(n); t_first = np.full(n, np.nan)
    steps = int(T / dt)
    for k in range(steps):
        t = k * dt
        vref = np.clip((t - TD) * SR, 0.0, V5)
        i2596 = np.clip((vref - van) / TPS2596["RON_MAX"], 0.0, ILM)
        f = np.clip((vp + vn - 1.0) / 3.5, 0.0, 1.0)
        ip = np.where(on, np.minimum(IST, np.maximum(0.0, 20.0 * (VPS - vp))), 0.0)
        ip = np.minimum(ip, np.maximum(0.0, (van - vp) / 0.45))
        icp = np.where(on, np.minimum(IST, np.maximum(0.0, (van - vcp) / 2.5)), 0.0)
        ineg = np.where(on, np.minimum(IST, np.maximum(0.0, 20.0 * (VNS - vn))), 0.0)
        ineg = np.minimum(ineg, np.maximum(0.0, (vcp - vn) / 0.30))
        iin = ip + icp + np.where(on, 1e-3, 0.0) + van / 98.2e3          # + LM27762 IQ (ASSUMP 1 mA) + ANA_SENSE divider
        pd = np.where(on, 0.0, 1.0 / 50e3)
        van = np.maximum(van + (i2596 - iin) / CA * dt, 0.0)
        vp = np.maximum(vp + (ip - IQP * f - vp * pd) / CR * dt, 0.0)
        vn = np.maximum(vn + (ineg - IQN * f - vn * pd) / CR * dt, 0.0)
        vcp = np.maximum(vcp + (icp - ineg) / CC * dt, 0.0)
        off_now = on & (van < UVF); on_now = (~on) & (van > UVR)
        trips += off_now; on = (on & ~off_now) | on_now
        first = on_now & ~ever; t_first[first] = t; ever |= on_now
        van_min_after = np.where(ever, np.minimum(van_min_after, van), van_min_after)
        good = (vp >= 0.95 * VPS) & (vn >= 0.95 * VNS) & np.isnan(t_good)
        t_good[good] = t
        e2596 += (V5 - van) * i2596 * dt; ipk = np.maximum(ipk, i2596)
    P(f"  Model (vectorised, {n} corners, dt 0.25 us, {T*1e3:.0f} ms): U503 = dVdt-ramped source (SR = IdVdt x GdVdt / (C514 + 1.03 nF"
      f" internal) [DS], turn-on delay x2) through 131 mOhm with a hard limit at ILIM; LM27762 on above UVLO-rise / off below UVLO-fall"
      f" (typ 2.6/2.4 V and two [ASSUMP] corners 2.7/2.6 V, 2.5/2.2 V); positive LDO and charge pump each limited to I_st (swept"
      f" {ISTS} A), neg. LDO likewise; rails 15.6/33.8 uF, CP 4.2/11 uF, 5V_ANA 5.0/12.1 uF, 5V_SYS 4.30/5.50 V; op-amp quiescent"
      f" {IQP*1e3:.1f}/{IQN*1e3:.1f} mA scaled with the total supply; ANA_SENSE divider 98.2 k.")
    P(f"  {'C514':>6s} {'SR V/ms':>13s} {'I_st A':>6s} | {'corners cycling':>15s} {'UVLO trips max':>14s} {'5V_ANA_F min after 1st on':>26s}"
      f" {'rails good ms (max)':>19s} {'U503 mJ max':>11s}")
    RES["A"] = {}
    for c in C514S:
        s0, s1 = sr(c)
        for ist in ISTS:
            m = (CD == c) & (IST == ist)
            cyc = int(np.sum(trips[m] > 0)); tg = t_good[m]
            tgs = "never" if np.any(np.isnan(tg)) else f"{np.nanmax(tg)*1e3:.2f}"
            P(f"  {c*1e9:4.0f}nF {s0/1e3:5.2f}-{s1/1e3:5.2f} {ist:6.2f} | {cyc:6d}/{int(m.sum()):<8d} {int(trips[m].max()):14d}"
              f" {van_min_after[m].min():26.2f} {tgs:>19s} {e2596[m].max()*1e3:11.2f}")
            RES["A"][f"{c*1e9:.0f}nF_{ist}"] = dict(cyc=cyc, n=int(m.sum()), trips=int(trips[m].max()),
                                                   vmin=float(van_min_after[m].min()), tgood=float(np.nanmax(tg)) if not np.any(np.isnan(tg)) else None)
    # cycle-free condition per limit
    P("  Cycle-free condition (per corner): after the LM27762 leaves UVLO the node must not fall back below UVLO-fall, i.e. its start")
    P("  current plus the ramp current C_5V_ANA x SR plus the quiescent must stay below the U503 limit at that instant:")
    for nm, il in ILS:
        m0 = (ILM == il) & (trips == 0)
        m1 = (ILM == il) & (trips > 0)
        P(f"    {nm:11s} (ILIM {il*1e3:5.1f} mA): cycle-free for I_st <= {IST[m0].max() if m0.any() else 0:.2f} A in all its corners?"
          f" {'yes' if not np.any((ILM == il) & (IST <= (IST[m0].max() if m0.any() else 0)) & (trips > 0)) else 'no'};"
          f" cycling seen for I_st >= {IST[m1].min() if m1.any() else float('nan'):.2f} A")
    tgmax = float(np.nanmax(t_good)); RES["A"]["tgood_max"] = tgmax
    RES["A"]["vmin_all"] = float(van_min_after.min()); RES["A"]["trips_max"] = int(trips.max())
    RES["A"]["ipk_max"] = float(ipk.max()); RES["A"]["e_max"] = float(e2596.max())
    P(f"  Worst over all corners: rails good <= {tgmax*1e3:.2f} ms after ANA_EN; 5V_ANA_F never below {van_min_after.min():.2f} V after the"
      f" first turn-on; U503 current <= ILIM ({ipk.max()*1e3:.0f} mA peak, High-min corner); U503 energy <= {e2596.max()*1e3:.2f} mJ; no FLT.")
    P("  CONCLUSION: no C514 value removes the UVLO cycling when the (unspecified) LM27762 start current exceeds the U503 limit minus the")
    P("  quiescent - it is set by the step from 0 V rails to VIN at the UVLO instant, not by the ramp rate. With the 500 mA typical")
    P("  input current limit the Default start WILL cycle; it stays a benign current-limited self soft-start: EN = VIN in every cycle,")
    P("  input current <= the U503 limit (USB budget unchanged), node >= UVLO-fall - hysteresis corner, rails good within the time above.")
    emit(L)
    json.dump(RES, open(os.path.join(HERE, "c16_results.json"), "w"), indent=1)

def save_res():
    p = os.path.join(HERE, "c16_results.json")
    old = json.load(open(p)) if os.path.exists(p) else {}
    old.update(RES); json.dump(old, open(p, "w"), indent=1)

# ------------------------------------------------------------------------------------------------ B  X-2
if "B" in SECTIONS:
    L = []; P = L.append
    P(hdr("B. X-2: C104 on U102 EN (pin 4) - guaranteed turn-on delay after attach; the two USB-IF attach regions"))
    VTH_LO, VTH_HI = TPS25200["VEN_OFF_MIN"], TPS25200["VEN_ON_MAX"]   # 0.6 V (falling min) .. 1.9 V (rising max) [DS 5.5]
    IEN = TPS25200["IEN_MAX"]                                          # +-2 uA [DS]
    R109 = 300e3; RT = 0.01
    P(f"  [DS 5.5] EN turn-on (rising) <= {VTH_HI} V, turn-off (falling) >= {VTH_LO} V, hysteresis 330 mV typ -> the rising threshold is"
      f" only bounded below by the falling minimum: {VTH_LO} V; IEN -2..+2 uA (positive into the pin); tON 5.12 typ / 7.3 max, NO minimum.")
    P("  Earliest turn-on: VBUS 5.50 V (max) steps at contact, EN leakage 2 uA OUT of the pin (charges C104), R109 -1 %, C104 minimum,")
    P("  threshold 0.6 V, tON = 0.  Latest: VBUS 4.40 V, 2 uA INTO the pin, R109 +1 %, C104 maximum, threshold 1.9 V, tON 7.3 ms.")
    def t_cross(vb, i_out, r, c, vth):
        veff = vb + i_out * r
        return float("inf") if veff <= vth else -r * c * math.log(1 - vth / veff)
    rows = []
    for nm, cn, lo, hi in (("47 nF C0G 0603 (+-5 %, +-30 ppm)", 47e-9, 0.95 * (1 - 30e-6 * 60), 1.05 * (1 + 30e-6 * 60)),
                           ("47 nF X7R 0402 (+-10 %, +-15 %, ageing 5 %)", 47e-9, 0.9 * 0.85 * 0.95, 1.1 * 1.15),
                           ("100 nF X7R 0402 16 V (+-10 %, +-15 %, ageing 5 %) C1525", 100e-9, 0.9 * 0.85 * 0.95, 1.1 * 1.15),
                           ("220 nF X7R 0402 (same factors)", 220e-9, 0.9 * 0.85 * 0.95, 1.1 * 1.15)):
        te = t_cross(5.50, IEN, R109 * (1 - RT), cn * lo, VTH_LO)
        tl = t_cross(4.40, -IEN, R109 * (1 + RT), cn * hi, VTH_HI) + TPS25200["TON_MAX"]
        rows.append((nm, cn, te, tl))
        P(f"    C104 = {nm:52s}: earliest U102 turn-on {te*1e3:6.2f} ms, latest 5V_SYS up {tl*1e3:6.1f} ms after attach")
    C104 = 100e-9
    te = [r for r in rows if r[1] == C104 and "X7R" in r[0]][0][2]; tl = [r for r in rows if r[1] == C104 and "X7R" in r[0]][0][3]
    RES["B"] = dict(C104=C104, t_early=te, t_late=tl)
    P(f"  CHOICE: C104 = 100 nF 16 V X7R 0402 (Samsung CL05B104KO5NNNC, C1525, Basic) -> earliest {te*1e3:.2f} ms (>= 1 ms, x{te/1e-3:.1f});"
      f" latest {tl*1e3:.1f} ms + TPS7A20 1.15 ms + MCU boot -> D+ pull-up well inside TSIGATT 100 ms (USB 2.0 7.1.7.3).")
    P("  DC bias is ignored in the early bound (EN < 0.6 V, no bias effect) and only shortens the late bound. EN steady = VBUS (Zener"
      " not reached at 5.5 V); a 20 V fault input: Zener current (20-6.4)/300 k = 45 uA as before. C104 does not affect OVLO/clamp.")
    P("  Re-plug caveat: after an unplug EN decays through R109 into the discharged VBUS node (tau 30 ms); a re-plug within ~30 ms can"
      " turn U102 on early (regions may merge). The USB-IF attach test starts from a discharged device -> not a compliance case.")
    # ---------------- region A: C102 + D102 through the cable
    CD102 = 10e-9   # [ASSUMP] SMDJ12A junction capacitance bound at 0-5.5 V (not in the DS extract; 3 kW 12 V TVS typ 3-6 nF at 0 V)
    CA_hi = 4.7e-6 * 1.1 + CD102
    QA = CA_hi * VBUS_MAX
    P(f"  Region A (contact): C102 4.7 uF +10 % + D102 <= {CD102*1e9:.0f} nF [ASSUMP] = {CA_hi*1e6:.2f} uF x 5.50 V = {QA*1e6:.1f} uC (limit 50 uC,"
      f" {(1-QA/50e-6)*100:.0f} % margin). D102 does not conduct (VBR >= 13.3 V > ringing peak <= 11.0 V, c01 section 2).")
    tend = 0.0
    for C in (0.8e-6, 2.16e-6, CA_hi):
        for Lc in (0.25e-6, 0.5e-6, 1.0e-6, 1.5e-6):
            for Rc in (0.05, 0.1, 0.2, 0.4):
                z0 = math.sqrt(Lc / C); zeta = Rc / 2 / z0
                if zeta < 1:
                    ipk = VBUS_MAX / z0 * math.exp(-zeta * math.atan(math.sqrt(1 - zeta**2) / zeta) / math.sqrt(1 - zeta**2))
                    t100 = 2 * Lc / Rc * math.log(max(ipk, 0.1) / 0.1 / math.sqrt(1 - zeta**2))
                else:
                    t100 = 5 * Rc * C
                tend = max(tend, t100)
    P(f"  Region A ends (current envelope < 100 mA) <= {tend*1e6:.0f} us after contact over the c01 cable envelope (R 0.05-0.4 ohm, L 0.25-1.5 uH)"
      f" -> gap to region B >= {(te - tend)*1e6:.0f} us >= 100 us (USB-IF CU #45) -> separated BY CONSTRUCTION.")
    # ---------------- region B: 5V_SYS + 3V3M capacitance (new parts added)
    C5 = [("C501", 1.0e-6, 0.10), ("C301", 2.2e-6, 0.10), ("C505", 0.1e-6, 0.10),
          ("D103-D105 Schottky (OUT->IN, on 5V_SYS side) Cj", 3 * 10e-12, 0.0), ("D107 Schottky U503 Cj", 10e-12, 0.0)]
    C3 = [("C502", 1.0e-6, 0.10), ("C203-C210", 0.8e-6, 0.10), ("C221", 1.0e-6, 0.10), ("C211", 2.2e-6, 0.20), ("C515", 0.1e-6, 0.10),
          ("protection U605 + digital Q207 decoupling on 3V3M [PH]", 0.2e-6, 0.10)]
    h5 = sum(c * (1 + t) for _, c, t in C5); h3 = sum(c * (1 + t) for _, c, t in C3)
    V5max = min(VBUS_MAX, TPS25200["VOVC_MAX"])
    QB = h5 * V5max + h3 * 3.3 * (1 + TPS7A20["ACC"])
    IOS_MAX = tps25200_ios(86.6 * 0.99)[2]
    QBc = QB * (1 - 0.100 / IOS_MAX)
    RES["B"].update(QA=QA, QB=QB, QBc=QBc, tA_end=tend)
    P(f"  Region B (U102 soft start, >= {te*1e3:.2f} ms): 5V_SYS {h5*1e6:.2f} uF x {V5max} V + 3V3M {h3*1e6:.2f} uF x 3.35 V = {QB*1e6:.1f} uC"
      f" ({(1-QB/50e-6)*100:.0f} % margin, no soft-start credit); with the guaranteed U102 current-limit credit {QBc*1e6:.1f} uC"
      f" ({(1-QBc/50e-6)*100:.0f} %). Round 2: 39.5 / 36.3 uC; the +0.2 uF 3V3M placeholder for the new U605/Q207 decoupling adds 0.7 uC.")
    P("  3V3M capacitance rule for the other streams: <= 5.3 uF nominal (was 5.1 uF) keeps region B <= 40.3 uC.")
    P("  Owner margin >= 20 %: region A 43 %, region B " + f"{(1-QB/50e-6)*100:.1f} % (no credit) / {(1-QBc/50e-6)*100:.1f} % (current-limit credit).")
    emit(L); save_res()

# ------------------------------------------------------------------------------------------------ C  X-3
if "C" in SECTIONS:
    L = []; P = L.append
    P(hdr("C. X-3: D102 VBUS TVS - hard short on 5V_SYS, cable kick at U102 IN with NO credit for tIOS (U102 20 V abs max, target <= 18 V)"))
    P("  No tIOS credit: U102 may interrupt the short current at ANY instant (0.5 us .. steady state). Before the interruption the cable"
      " current rises towards (5.5 V)/(Rc + Ron,U102); the kick is set by the current at the interruption. Envelope: Rc 0.05/0.1/0.2/0.4 ohm"
      " (loop, incl. source and both connectors), Lc 0.25/0.5/1.0/1.5 uH (all combinations, uncorrelated = conservative), C102 effective"
      " 2.16 uF (4.7 uF derated) and 5.17 uF, U102 Ron 0.045 ohm [ASSUMP min: 63 mOhm typ at 25 C (DS Fig 5-4) -30 %] and 0.099 ohm [DS max];"
      " after the interruption U102 passes <= 1.24 A (IOS max) [DS]; source 5.50 V; TVS at the J101 pads (layout rule: <= 5 mm, direct vias).")
    P("  TVS model: I = (V - VBR,max,hot)/Rdyn above VBR, VBR,max,hot = VBR,max(1 mA) x (1 + 0.1 %/K x 35 K) [DS dVBR note, TJ 60 C],"
      " Rdyn = (VC - VBR,max)/IPP (secant to the 10/1000 us rating point; conservative for us pulses: less self-heating).")
    TVS = [("SMF12A (200 W, SOD-123FL)", 13.3, 14.7, 19.9, 10.1),
           ("SMAJ12A (400 W, SMA)", 13.3, 14.7, 19.9, 20.1), ("SMAJ13A (400 W, SMA)", 14.4, 15.9, 21.5, 18.6),
           ("SMBJ12A (600 W, SMB)", 13.3, 14.7, 19.9, 30.2), ("SMCJ12A (1500 W, SMC)", 13.3, 14.7, 19.9, 75.4),
           ("SMDJ12A (3000 W, SMC/DO-214AB)", 13.3, 14.7, 19.9, 150.8), ("5.0SMDJ12A (5000 W, DO-214AB)", 13.3, 14.7, 19.9, 251.0)]
    def kick(C, Lc, Rc, ron, tint, vbr, rd, dt=5e-9, tend=60e-6):
        i0 = 0.5; v = VBUS_MAX - Rc * i0; i = i0; t = 0.0; vpk = v; itv = 0.0; e = 0.0; ipk = i
        while t < tint + tend:
            iout = v / ron if t < tint else min(1.24, v / ron)
            itvs = max(0.0, (v - vbr) / rd) if rd else 0.0
            i += (VBUS_MAX - Rc * i - v) / Lc * dt
            v += (i - iout - itvs) / C * dt
            t += dt; vpk = max(vpk, v); itv = max(itv, itvs); e += v * itvs * dt; ipk = max(ipk, i)
            if t > tint and i < 1.3 and v < VBUS_MAX + 0.5 and t > tint + 3e-6:
                break
        return vpk, itv, e, ipk
    TINT = (0.5e-6, 2e-6, 3.5e-6, 7e-6, 15e-6, 30e-6, 60e-6, 120e-6)
    RES["C"] = {}
    P(f"  {'TVS':32s} | {'worst V_IN':>10s} {'at Rc/Lc/C/Ron/t_int':>30s} {'I_TVS pk':>9s} {'E_TVS mJ':>9s} {'<= 18 V':>7s}")
    best = None
    for nm, vbrmin, vbrmax, vc, ipp in TVS:
        vbr_hot = vbrmax * (1 + 0.001 * 35); rd = (vc - vbrmax) / ipp
        worst = (0, None, 0, 0)
        for C in (2.16e-6, 5.17e-6):
            for Lc in (0.25e-6, 0.5e-6, 1.0e-6, 1.5e-6):
                for Rc in (0.05, 0.1, 0.2, 0.4):
                    for ron in (0.045, 0.099):
                        # steady-state current reached for t_int >= ~5 L/R; the longest t_int covers it
                        for tint in TINT:
                            if tint > 6 * Lc / (Rc + ron) + 5e-6 and tint != TINT[-1]:
                                continue
                            vpk, itv, e, ipk = kick(C, Lc, Rc, ron, min(tint, 6 * Lc / (Rc + ron) + 5e-6), vbr_hot, rd)
                            if vpk > worst[0]:
                                worst = (vpk, (Rc, Lc, C, ron, tint), itv, e)
        ok = worst[0] <= 18.0
        c = worst[1]
        P(f"  {nm:32s} | {worst[0]:9.2f}V {c[0]:.2f}/{c[1]*1e6:.2f}u/{c[2]*1e6:.2f}u/{c[3]:.3f}/{c[4]*1e6:5.1f}us {worst[2]:8.1f}A"
          f" {worst[3]*1e3:9.2f} {'yes' if ok else 'NO':>7s}")
        RES["C"][nm] = dict(vpk=worst[0], itvs=worst[2], e=worst[3])
        if ok and best is None:
            best = nm
    vpk0 = 0.0
    for C in (2.16e-6, 5.17e-6):
        for Lc in (0.25e-6, 0.5e-6, 1.0e-6, 1.5e-6):
            for Rc in (0.05, 0.1, 0.2, 0.4):
                v, _, _, _ = kick(C, Lc, Rc, 0.045, 6 * Lc / (Rc + 0.045) + 5e-6, 99.0, 0.0)
                vpk0 = max(vpk0, v)
    P(f"  Without a TVS (C102 only, no tIOS credit): worst V_IN {vpk0:.0f} V -> the review's finding #28 confirmed and worse than 22.4 V.")
    P(f"  -> smallest TVS meeting <= 18 V in every corner: {best}. SMAJ13A/SMF13A class does NOT (current up to V/(Rc+Ron) ~ 58 A).")
    RES["C"]["choice"] = best; RES["C"]["no_tvs"] = vpk0
    P("  D102 = Littelfuse SMDJ12A [DS Littelfuse SMDJ series / product page]: VRWM 12 V (a mis-set 9 V source (<= 9.45 V) is below VRWM;"
      " 9 V hot-plug ringing <= 18.9 V is clamped); VBR 13.3-14.7 V at 1 mA; VC 19.9 V at IPP 150.8 A (10/1000 us); IR <= 2 uA at 12 V, 25 C;"
      " dVBR 0.1 %/K; 3000 W; TJ -65..150 C; MSL 1; DigiKey 5,498 (Sep 2026) -> JLCPCB global sourcing; alternates YINT / MDD SMDJ12A (same"
      " ratings, LCSC not verified).")
    # leakage at 5.5 V / 50 C (not in the datasheet): bound from the 12 V / 25 C maximum
    ir12 = 2e-6
    m_ratio = (1 - (12 / 13.3) ** 4) / (1 - (5.5 / 13.3) ** 4)       # [ASSUMP] avalanche multiplication, Miller n = 4
    w_ratio = math.sqrt((5.5 + 0.7) / (12 + 0.7))                    # generation current ~ depletion width
    kT = (323.15 / 298.15) ** 1.5 * math.exp(1.12 / (2 * 8.617e-5) * (1 / 298.15 - 1 / 323.15))
    ir55 = ir12 * m_ratio * w_ratio * kT
    ir55_simple = ir12 * kT
    RES["C"]["ir_5v5_50c"] = ir55
    P(f"  Leakage at 5.5 V / 50 C: NOT in the datasheet (only IR <= 2 uA at VRWM 12 V, 25 C). Estimate from that maximum: x {m_ratio:.2f}"
      f" (no avalanche multiplication at 41 % of VBR) x {w_ratio:.2f} (depletion width) x {kT:.1f} (generation current 25->50 C) ="
      f" {ir55*1e6:.1f} uA [CALC/ASSUMP] (<= 5 uA target); the crude bound without the voltage terms is {ir55_simple*1e6:.1f} uA."
      f" -> budget uses 5 uA (target value); bring-up measurement M14 (leakage of 5 samples at 5.5 V, 50 C).")
    P("  Energy/peak power in the worst corner: see table (a few mJ in < 10 us) << SMDJ12A 3000 W (10/1000 us) -> no stress issue.")
    P("  ESD (8 kV contact): D102 now clamps the fast edge as well (the c01 section 3 charge argument ignored ESL).")
    P("  Attach: D102 capacitance counted in region A (section B). Suspend: 5 uA from VBUS (c03 round 3).")
    emit(L); save_res()

# ------------------------------------------------------------------------------------------------ D  X-5
if "D" in SECTIONS:
    L = []; P = L.append
    P(hdr("D. X-5: ANA_SENSE divider (5V_ANA_F -> MCU PA0 / ADC_IN0) R535 / R536 + C516"))
    r1, r2, tol = 68.1e3, 30.1e3, 0.01
    kmax = r2 * (1 + tol) / (r2 * (1 + tol) + r1 * (1 - tol)); kmin = r2 * (1 - tol) / (r2 * (1 - tol) + r1 * (1 + tol)); knom = r2 / (r1 + r2)
    rth = r1 * r2 / (r1 + r2)
    P(f"  R535 68.1 k (top) / R536 30.1 k (bottom), 1 %: k = {kmin:.4f} / {knom:.4f} / {kmax:.4f}; 5.55 V -> <= {5.55*kmax:.3f} V (<= 1.8 V);"
      f" source {rth/1e3:.1f} k (<= 40 k); load {5.55/(r1+r2)*1e6:.0f} uA on 5V_ANA_F (inside the U503 limit).")
    vref_lo, vref_hi = 3.3 * 0.985, 3.3 * 1.015
    th = 4.00
    code = th * knom / 3.3 * 4096
    lo = th * kmin / vref_hi * 4096; hi = th * kmax / vref_lo * 4096
    P(f"  Firmware threshold 4.00 V -> {th*knom:.3f} V at PA0 = {code:.0f} counts (VREF = 3V3M 3.3 V). Band of the true 5V_ANA_F at that"
      f" code: {3.3*0.985*code/4096/kmax:.2f} .. {3.3*1.015*code/4096/kmin:.2f} V (divider 1 %, 3V3M +-1.5 %, ADC error +-4 LSB ignored).")
    P("  C516 100 pF C0G at PA0 (Samsung CL05C101JB5NNNC, C1546): tau = 2.1 us; sample-time: source 20.9 k + 100 pF (digital chooses the"
      " WCH sampling time for 20.9 k; the 100 pF holds charge for the S&H).")
    P("  Unpowered-pin check (review #1): 5V_ANA_F can only be up while 3V3M is up (U503 EN = ANA_EN from the MCU); at a hard unplug 5V_ANA_F"
      f" falls with 5V_SYS; worst injection if 3V3M reached 0 with 5V_ANA_F still 5.5 V: (5.5 x {knom:.3f} - 0.3)/{rth/1e3:.1f} k = "
      f"{(5.5*knom-0.3)/rth*1e6:.0f} uA (well below any pin-injection limit).")
    P("  Firmware (X-5): 5V_ANA_F < 4.0 V with ANA_EN high for > 5 ms after the start-up window (>= 20 ms after ANA_EN, covers the"
      " section-A start) = supply fault in every state incl. programming -> ANA_EN low.")
    RES["D"] = dict(r535=r1, r536=r2, k=knom, rth=rth, i=5.55 / (r1 + r2))
    emit(L); save_res()

# ------------------------------------------------------------------------------------------------ E  X-10
if "E" in SECTIONS:
    L = []; P = L.append
    P(hdr("E. X-10 power items: C103 = 100 pF C0G; R508 47 k -> 10 k with R237 4.7 k from PC10 (AUD_EN levels)"))
    P("  C103 = 100 pF 50 V C0G 0402 Samsung CL05C101JB5NNNC (C1546): VBUS_SENSE tau = 31.97 k x (100 pF + 12 pF pin) = 3.6 us"
      " (was 0.32 ms) -> the brown-out watchdog acts before the MCU resets in every c14 corner (round-2 finding).")
    vm_min = 3.3 * (1 - TPS7A20["ACC"]); voh = vm_min - 0.02                      # [ASSUMP] VOH drop <= 20 mV at 0.23 mA (CH32V307 8 mA spec)
    r508, r237, tol = 10e3, 4.7e3, 0.01
    kmin = r508 * (1 - tol) / (r508 * (1 - tol) + r237 * (1 + tol)); knom = r508 / (r508 + r237)
    ipu_b = 10e-6          # [ASSUMP] TLV767 EN internal pull-up bound: 25 x the 400 nA typical (no max in the DS)
    i_mcu_lkg = 1e-6       # [ASSUMP] MCU pin leakage (floating at reset)
    i_q504 = AO3400A["IGSS_MAX"]; i_u605 = 1e-6   # [DS] IGSS; [ASSUMP] U605B off-state output leakage (protection to confirm)
    vh = voh * kmin - (i_q504 + i_u605) * (r508 * r237 / (r508 + r237))
    vl_float = (ipu_b + i_mcu_lkg + i_q504) * r508 * (1 + tol)
    vl_drv = 0.05 * knom + (ipu_b + i_q504) * (r508 * r237 / (r508 + r237))
    P(f"  AUD_EN high (PC10 = VOH >= {voh:.3f} V, divider R237 {r237/1e3:.1f} k / R508 {r508/1e3:.0f} k, 1 %, pull-up credit ignored, sinks"
      f" 1.1 uA): >= {vh:.3f} V (nominal {3.3*knom:.3f} V) vs TLV767 VEN(HI) <= 1.2 V (+{vh-1.2:.2f} V) and Q504 VGS(th) <= 1.45 V"
      f" (+{vh-1.45:.2f} V; Rds(on) spec point 2.5 V, at 2.18 V still << 1 ohm for the 0.15 mA R528 load).")
    P(f"  AUD_EN low, MCU pin floating (reset): TLV767 pull-up bound {ipu_b*1e6:.0f} uA [ASSUMP 25 x typ] + MCU leakage 1 uA + Q504 IGSS"
      f" 0.1 uA into R508 = {vl_float*1e3:.0f} mV <= 0.4 V (TLV767 VEN(LO)) and < 0.65 V (Q504 VGS(th) min) -> 3V3D off, discharge on."
      f" The node stays <= 0.4 V for any pull-up <= {(0.4/(r508*1.01) - i_mcu_lkg - i_q504)*1e6:.0f} uA (R508 47 k allowed only 7 uA).")
    P(f"  AUD_EN low, PC10 driven low: <= {vl_drv*1e3:.0f} mV. U605B (3V3A not good) pulls AUD_EN low against R237: sink 3.35 V/4.7 k ="
      f" {3.35/4.7e3*1e3:.2f} mA; needs VOL <= 0.4 V at 0.71 mA (protection to confirm for the TLV170x output).")
    P(f"  U303 EN is now tied to 3V3D (X-4), so AUD_EN drives only U504 EN, Q504 gate and U605B. Load on 3V3M while AUD_EN is high:"
      f" {3.3*1.015/(r508*0.99+r237*0.99)*1e3:.3f} mA (was 0.070 mA with 47 k).")
    RES["E"] = dict(vh=vh, vl_float=vl_float, i_r508=3.3 * 1.015 / (r508 * 0.99 + r237 * 0.99))
    emit(L); save_res()
