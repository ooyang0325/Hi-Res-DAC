"""c03 - USB current budget per state and the U503 current-limit selection (R8 round 2, decisions_r8b.md D-1..D-18).
Loads: decisions load table (X201 Epson SG-210STF <= 6.5 mA, photorelay LED strings 14.3 mA on 5V_SYS + 1.02 mA on 3V3M
while RELAY_EN is high, R234 0.33 mA, R233 0.032 mA, 3V3A protection networks 1.82 mA, TLV1704 I+ 1.26 / I- 1.25 mA).
Analog quiescent: analog round-1 set B split with the 2 x LM339B terms replaced by the TLV1704 figures and the new DC-sense
V- load computed from the protection network values (6.8 k / 5.1 k / 16.9 k).
Limiter: TI TPS259621DDAR (SLVSET8A); guaranteed limit = Eq.5 nominal x (1 +- 10.4 %) [DS feature list, consistent with the
7.5 table rows] with the 0.1 %/25 ppm R_ILM tolerance; the row interpolation is shown for information only.
Rule (D-5): Default total = non-analog maximum + IOS max + IQ (+ ILM current) <= 490 mA; High IOS min >= 390 mA and >= 357 mA.
Writes c03_results.json for c04/c10/c11/c14."""
import json, os
from pw_common import *

out = []
P = out.append
V3M = 3.3 * (1 + TPS7A20["ACC"])     # 3.3495 V
V3D = 3.3 * (1 + TLV767["ACC"])      # 3.333 V
V3A = 3.3 * (1 + LP5907["ACC"])      # 3.366 V
V5MAX = 5.50

def lin(i0, i_max, i_at, i):
    return i0 + (i_max - i0) * i / i_at
def tps7a20_in(i):
    return i + lin(TPS7A20["IGND0_MAX_85"], TPS7A20["IGND300_MAX"], 0.300, i)   # [CALC] interp of DS maxima
def tlv767_in(i):
    return i + TLV767["IQ_MAX"] + 1.5 * TLV767["IGND_1A_TYP"] * i                # [DS] IQ max + [ASSUMP] 1.5 x typ slope
def lp5907_in(i):
    return i + lin(LP5907["IQ0_MAX"], LP5907["IQ250_MAX"], 0.250, i)             # [CALC] interp of DS maxima

# ------------------------------------------------------------------------------------------------ 1. analog quiescent
P(hdr("1. Analog quiescent (5V_ANA) - analog round-1 set B split, 2 x LM339B replaced by TLV1704, new DC-sense V- load"))
Rs, Ru, Rd = PROT["R_S"], PROT["R_U"], PROT["R_D"]
def dcsense_leg_current(v3a, vleg=0.0, tol=0.001):
    """[CALC] current from the DC-sense node into the leg (A): R_U to 3V3A, R_D to GND, R_S to the leg; resistor corner
    for maximum current (R_U low, R_D high, R_S low)."""
    ru, rd, rs = Ru * (1 - tol), Rd * (1 + tol), Rs * (1 - tol)
    vth = v3a * rd / (ru + rd); rth = ru * rd / (ru + rd)
    return (vth - vleg) / (rth + rs), vth, rth
for lab, v, tol in (("3V3A min 3.234 V", 3.3 * 0.98, 0.001), ("3V3A nom 3.300 V", 3.3, 0.0), ("3V3A max 3.366 V", V3A, 0.001)):
    i, vth, rth = dcsense_leg_current(v, tol=tol)
    P(f"  {lab}: open-circuit node {vth:.3f} V (R_th {rth/1e3:.3f} k), node at a 0 V leg {vth - i*rth:.3f} V, current into the"
      f" leg {i*1e3:.4f} mA (sunk by the OPA1622 output into V-)")
I_DCS_LEG = dcsense_leg_current(V3A)[0]
P(f"  -> {I_DCS_LEG*1e3:.3f} mA per leg [CALC] confirms the decisions' '~0.24 mA per leg (node ~1.61 V through 6.8 k)';"
  f" 4 legs = {4*I_DCS_LEG*1e3:.3f} mA on V-")
P("  (Music is AC on the leg: the mean leg voltage is 0 V, so the mean V- current stays the 0 V-leg value.)")
P(f"  Protection r2: permitted TLV1704 block I+ {PROT['I_TLV1704_POS_R2']*1e3:.3f} / I- {PROT['I_TLV1704_NEG_R2']*1e3:.3f} mA (<= D-9"
  " 1.26/1.25 used in the analog final); +79 uA only while tripped (switch open); DC-sense sink ~0.24 mA/leg confirmed.")
VREF_HI = 1.706          # [CALC analog] VREF max (0.50607 x 3V3A max, analog report section 7)
CP = 1.03                # [PH] charge-pump input/output factor on I- (brief R8-D2; analog stream)
I_LM27762 = 1.0e-3       # [ASSUMP] LM27762 IQ (390 uA typ, no max published)
I_PG = 5.55 / 100e3      # [CALC] R505 100 k PGOOD pull-up with PGOOD low (rails good)
OPA1622, OPA2210 = 4.2e-3, 3.25e-3    # [DS] per channel, -40..125 C maxima (analog set B)
A_TERMS_P = [("OPA1622 4 ch x 4.2 mA", 4 * OPA1622, "[DS]"), ("OPA2210 4 ch x 3.25 mA", 4 * OPA2210, "[DS]"),
             ("TLV1704 x 3 incl. dividers and H pull-up (D-9)", PROT["I_TLV1704_POS"], "[DS/CALC protection]"),
             ("I/V outputs -> leg networks, 4 x VREF/2 k", 4 * VREF_HI / 2000.0, "[CALC analog]"),
             ("CM summing, 2 channels x 14 uA (zero at silence)", 2 * PROT["CM_SUM_MAX"], "[CALC protection, bound]")]
A_TERMS_N = [("OPA1622 4 ch x 4.2 mA", 4 * OPA1622, "[DS]"), ("OPA2210 4 ch x 3.25 mA", 4 * OPA2210, "[DS]"),
             ("TLV1704 x 3 incl. dividers (D-9)", PROT["I_TLV1704_NEG"], "[DS/CALC protection]"),
             ("OPA1622 outputs sink the feedback current, 4 x VREF/2/2 k", 4 * VREF_HI / 2 / 2000.0, "[CALC analog]"),
             ("DC-sense networks into the legs, 4 x %.3f mA" % (I_DCS_LEG * 1e3), 4 * I_DCS_LEG, "[CALC above]"),
             ("CM summing, 2 channels x 14 uA", 2 * PROT["CM_SUM_MAX"], "[CALC protection, bound]")]
IP = sum(t[1] for t in A_TERMS_P); IN = sum(t[1] for t in A_TERMS_N)
for n, v, l in A_TERMS_P:
    P(f"  I+  {n:58s} {v*1e3:7.3f} mA {l}")
P(f"  I+  {'TOTAL':58s} {IP*1e3:7.3f} mA   (round-1 set B with 2 x LM339B: 35.81 mA)")
for n, v, l in A_TERMS_N:
    P(f"  I-  {n:58s} {v*1e3:7.3f} mA {l}")
P(f"  I-  {'TOTAL':58s} {IN*1e3:7.3f} mA   (round-1: 34.52 mA)")
I_ANA_Q = IP + CP * IN + I_LM27762 + I_PG
P(f"  5V_ANA quiescent = I+ + {CP} x I- + LM27762 {I_LM27762*1e3:.1f} mA [ASSUMP] + PGOOD {I_PG*1e3:.3f} mA = {I_ANA_Q*1e3:.2f} mA "
  f"(round-1 set B: 72.92 mA incl. PGOOD 0.55 mA with the old 10 k; change {I_ANA_Q*1e3-72.92:+.2f} mA)")
RSER_UNBAL, RSER_BAL = 0.27, 0.32     # [analog] series R incl. switch (relay placeholder 0.10 >= TLP3545A 0.06 x 1.35)
NEED = []
for jack, R, bal, pd in (("3.5 mm", 32, False, 0.038), ("4.4 mm", 60, True, 0.017), ("4.4 mm", 120, True, 0.035),
                         ("4.4 mm", 300, True, 0.030)):
    rs = RSER_BAL if bal else RSER_UNBAL
    iload = math.sqrt(2 * pd / R) * (R + rs) / R
    k = 4.06 if bal else 2.06
    NEED.append((jack, R, pd, I_ANA_Q + k * iload))
NEED_MAX = max(n[3] for n in NEED)
P("  Default IOS min needed (analog-stream method: peak input = quiescent + k x peak load current, k 2.06 / 4.06) [CALC]:")
for jack, R, pd, need in NEED:
    P(f"     {jack} {R:3d} ohm {pd*1e3:4.0f} mW -> {need*1e3:6.1f} mA")
P(f"  -> my estimate {NEED_MAX*1e3:.1f} mA (was 174.2 mA with 2 x LM339B); every +1 mA of rail quiescent costs ~2.03 mA of 5V_ANA input")
I_ANA_Q_MINE, NEED_MINE = I_ANA_Q, NEED_MAX
I_ANA_Q, NEED_MAX = ANA_FINAL["I_Q"], ANA_FINAL["NEED"]
P(f"  ANALOG ROUND 2 FINAL (binding, used below): quiescent {I_ANA_Q*1e3:.2f} mA (my cross-check {I_ANA_Q_MINE*1e3:.2f} mA),"
  f" {ANA_FINAL['I_Q_RESET']*1e3:.2f} mA with the DAC in reset; Default need IOS min >= {NEED_MAX*1e3:.1f} mA (target 180 mA)")

# ------------------------------------------------------------------------------------------------ 2. load inventory
P(hdr("2. Load inventory by rail (maxima unless labelled) and the states in which each load flows"))
ALLCFG = {"S2", "S3", "S3f", "S4", "S5"}
PLAY = {"S2", "S3", "S3f", "S4"}                    # configured, switch may be closed, MCLK permitted
L = []   # (rail, name, amps, label, states)
def add(rail, name, a, lab, states):
    L.append((rail, name, a, lab, set(states)))
add("3V3M", "MCU CH32V307 run, 144 MHz, USBHS", DIG["I_MCU"], "[ASSUMP D load table; WCH typ 22.4 mA]", {"S1"} | ALLCFG)
add("3V3M", "LED green D705 via R701", DIG["I_LED_G"], "[CALC digital]", {"S1"} | ALLCFG)
add("3V3M", "LED red D706 via R702", DIG["I_LED_R"], "[CALC digital]", {"S1"} | ALLCFG)
add("3V3M", "MCU internal pull-downs on 3V3D-driven inputs", DIG["I_MCU_PD_ASSUMP"], "[ASSUMP digital, 30 k]", ALLCFG)
add("3V3M", "AUD_EN pull-down R508 47 k (high)", V3M / (47e3 * 0.99), "[CALC]", ALLCFG)
add("3V3M", "AVCC_EN pull-down R303 100 k (high)", V3M / 99e3, "[CALC]", ALLCFG)
add("3V3M", "ANA_EN pull-down R513 100 k (high)", V3M / 99e3, "[CALC]", ALLCFG)
add("3V3M", "RAIL_EN R507 + R506 110 k (high)", V3M / (110e3 * 0.99), "[CALC]", ALLCFG)
add("3V3M", "discharge inverter pull-ups R526/R528 22 k (ENs high)", 2 * V3M / (22e3 * 0.99), "[CALC]", ALLCFG)
add("3V3M", "U505 TMUX1101 IDD + SEL leakage", TMUX1101["IDD_MAX_125"] + TMUX1101["ISEL_MAX_3V3"], "[DS]",
    {"S1"} | ALLCFG)
add("3V3M", "photorelay drive, 3V3M share (RELAY_EN high)", PROT["I_DRIVE_3V3M"], "[CALC protection r2 p05; D-1 recomputed]", PLAY)
add("3V3M", "R234 MCLK_PERMIT pull-down (PB14 high)", DIG["I_R234"], "[CALC digital]", PLAY)
add("3V3M", "R233 DAC_RESETB series (RESETB high)", DIG["I_R233"], "[CALC digital]", PLAY)
add("3V3M", "R511 ILIM_HI pull-down (High mode only)", V3M / 99e3, "[CALC]", {"S4"})
add("3V3D", "CPLD AGRV2K", DIG["I_CPLD"], "[ASSUMP D load table]", ALLCFG)
add("3V3D", "photorelay drive, 3V3D share: U604 reference/sink (RELAY_EN high)", PROT["I_DRIVE_3V3D"], "[CALC protection r2 p05]", PLAY)
add("3V3D", "U604 OPA2333 quiescent (whenever 3V3D is up)", PROT["I_U604_3V3D"], "[DS/CALC protection r2]", ALLCFG)
add("3V3D", "X201 Kyocera KC2520K80 80 MHz (running) + R227", DIG["I_X201"], "[D-3 revised: 8.0 mA max, 15 pF, over T + R227]", PLAY)
add("3V3D", "R235 100 k pull-down on N2_MCLK_OE (U206 output high)", DIG["I_R235"], "[CALC D-19]", PLAY)
add("3V3D", "X201 stand-by (ST low)", DIG["I_X201_STBY"], "[DS Kyocera 5 uA]", {"S5"})
add("3V3D", "X202/X203 NDK NZ2520SDA running (one)", DIG["I_NDK_RUN"], "[DS 25 C]", ALLCFG)
add("3V3D", "X203/X202 NDK stand-by (other)", DIG["I_NDK_STBY"], "[DS 25 C]", ALLCFG - {"S3f", "S5"})
add("3V3D", "second NDK running (family change / CPLD pull-up case)", DIG["I_NDK_RUN"], "[DS 25 C]", {"S3f", "S5"})
add("3V3D", "second oscillator-enable 10 k pull-down driven high", DIG["I_OSC_EN_PD"], "[CALC digital]", {"S3f", "S5"})
add("3V3D", "U205 clock mux", DIG["I_U205"], "[CALC digital]", ALLCFG)
add("3V3D", "U206 AND + pull-downs + I2C 4.7 k", DIG["I_U206_MISC"], "[CALC digital]", ALLCFG)
add("3V3D", "DAC DVCC", ESS_DAC["DVCC_NOM_I"], "[DS nominal used as max]", ALLCFG)
add("3V3D", "DAC DVDD through U303 (1V3)", 0.060, "[PH] ESS nominal 50 mA at 80 MHz/192 kHz", ALLCFG)
add("3V3D", "U303 TLV758P IGND", TLV758P["IGND_MAX"], "[DS]", ALLCFG)
add("3V3D", "U303 feedback divider R533 + R534 (1.326 V / 26 k)", 1.326 / (26e3 * 0.999), "[CALC]", ALLCFG)
add("3V3D", "discharge FETs Q505/Q506 off-state", 2 * AO3400A["IDSS_55C_MAX"], "[DS bound at 30 V]", ALLCFG)
add("3V3A", "ESS AVCC_L + AVCC_R", 0.016, "[DS nominal, D-10]", ALLCFG)
add("3V3A", "ESS VCCA at 80 MHz", ANA_FINAL["I_VCCA"], "[ASSUMP analog r2: 0.8 mA at 22 MHz scaled; D-10 0.8]", ALLCFG)
add("3V3A", "VREF divider R431 + R432 (19.76 k) at 3V3A max", V3A / (19.76e3 * 0.999), "[CALC; D-10 0.167 mA nominal]", ALLCFG)
add("3V3A", "protection networks (5 DC-sense/reference + CM chain)", PROT["I_3V3A"], "[CALC protection, D-10]", ALLCFG)
add("3V3A", "discharge FET Q503 off-state", AO3400A["IDSS_55C_MAX"], "[DS bound]", ALLCFG)
add("5V_SYS", "photorelay LED strings, op-amp sink (RELAY_EN high)", PROT["I_LED_5VSYS"], "[CALC protection r2 p05; D-1 recomputed]", PLAY)
add("5V_SYS", "TPS25200 IQ (on)", TPS25200["IQ_ON_MAX"], "[DS]", {"S1"} | ALLCFG)
add("5V_SYS", "TPS25200 EN leakage via R109", TPS25200["IEN_MAX"], "[DS]", {"S1"} | ALLCFG)
add("5V_SYS", "VBUS_SENSE divider R105 + R106 at 5.5 V", V5MAX / (147e3 * 0.99), "[CALC]", {"S1"} | ALLCFG)
add("5V_SYS", "USBLC6 leakage at 5.5 V", 1e-6, "[ASSUMP; DS 150 nA at 5.25 V]", {"S1"} | ALLCFG)
add("5V_SYS", "legacy A-to-C cable Rp through Rd (56 k -5 % + 5.1 k)", V5MAX / (56e3 * 0.95 + 5.1e3 * 0.99),
    "[ASSUMP worst cable]", {"S1"} | ALLCFG)
add("5V_SYS", "U503 TPS2596 shutdown (ANA_EN low)", TPS2596["ISD_MAX"], "[DS VIN >= 4 V]", {"S1"})
add("5V_SYS", "U302 LP5907 shutdown", LP5907["IQ_OFF_MAX"], "[DS]", {"S1"})
add("5V_SYS", "U504 TLV767 shutdown", TLV767["ISHDN_MAX"], "[DS at VIN 16 V]", {"S1"})
RAILS = ("3V3M", "3V3D", "3V3A", "5V_SYS")
for rail in RAILS:
    for r, n, a, lab, st in L:
        if r == rail:
            P(f"  {rail:6s} {n:60s} {a*1e3:8.4f} mA {lab:44s} {','.join(sorted(st))}")

def rail_out(state):
    return {rail: sum(a for r, n, a, lab, st in L if r == rail and state in st) for rail in RAILS}
def usb_in(state):
    ro = rail_out(state)
    d = {"3V3M": tps7a20_in(ro["3V3M"]), "3V3D": tlv767_in(ro["3V3D"]) if ro["3V3D"] > 1e-4 else ro["3V3D"],
         "3V3A": lp5907_in(ro["3V3A"]) if ro["3V3A"] > 1e-4 else ro["3V3A"], "5V_SYS": ro["5V_SYS"]}
    return d, ro
d2, ro2 = usb_in("S2")
NONANA = sum(d2.values())
P(f"\nRegulator outputs (S2): 3V3M {ro2['3V3M']*1e3:.2f}, 3V3D {ro2['3V3D']*1e3:.2f}, 3V3A {ro2['3V3A']*1e3:.2f} mA; "
  f"inputs from 5V_SYS: 3V3M {d2['3V3M']*1e3:.2f}, 3V3D {d2['3V3D']*1e3:.2f}, 3V3A {d2['3V3A']*1e3:.2f}, direct {d2['5V_SYS']*1e3:.2f} mA")
P(f"NON-ANALOG TOTAL (configured, switch closed, MCLK permitted): {NONANA*1e3:.2f} mA [CALC]  (round-2 draft: 266.83 mA)")
P("  Note: the PGOOD network R505/R522/R532 hangs on 5V_ANA_F, i.e. inside the U503 limit (the draft counted 7 uA on 5V_SYS).")

# ------------------------------------------------------------------------------------------------ 3. U503 limits
P(hdr("3. U503 TPS259621 current limit: ILIM = 903/R_ILM + 0.0112 A [DS Eq.5]; guaranteed +-10.4 % [DS]"))
TOL = 0.001 + 25e-6 * 35         # 0.1 % + 25 ppm x 35 K (25 -> 60 C board)
IQ2596 = TPS2596["IQ_ON_MAX"]
def ilm_cur(i):
    return TPS2596["GIMON_013_MAX"] * i          # [DS max gain] ILM current, drawn from IN on top of IOUT [ASSUMP]
def default_total(nonana, imax):
    return nonana + imax + IQ2596 + ilm_cur(imax)
def lim(r, mode="headline"):
    return tps2596_ios(r, tol=TOL, mode=mode)
P("  Relative accuracy of the DS 7.5 rows vs Eq.5 (evidence for the +-10.4 % headline):")
for r, lo, ty, hi in TPS2596_ILIM_TABLE:
    n = tps2596_inom(r)
    P(f"    R_ILM {r:6.0f} ohm: Eq.5 {n*1e3:7.1f} mA, DS min {lo*1e3:6.0f} ({(lo/n-1)*100:+5.1f} %), max {hi*1e3:6.0f} ({(hi/n-1)*100:+5.1f} %)")
P(f"  {'R509':>7s} {'IOS min':>8s} {'nom':>7s} {'max':>7s} {'Default total':>14s} {'to 490':>7s} | interp: {'min':>6s} {'max':>6s} {'total':>7s}")
cands = []
for b in e96():
    r = b * 10.0
    if 4000 <= r <= 5500:
        mn, nm, mx = lim(r); t = default_total(NONANA, mx)
        mi, _, ma = lim(r, "interp"); ti = default_total(NONANA, ma)
        cands.append((r, mn, nm, mx, t))
        P(f"  {r:7.0f} {mn*1e3:8.2f} {nm*1e3:7.2f} {mx*1e3:7.2f} {t*1e3:14.2f} {(0.490-t)*1e3:+7.2f} | {mi*1e3:14.2f} {ma*1e3:6.2f} {ti*1e3:7.2f}")
ok = [c for c in cands if c[4] <= 0.490]
best = max(ok, key=lambda c: c[1])
R509 = best[0]
D_MIN, D_NOM, D_MAX, T_DEF = best[1], best[2], best[3], best[4]
P(f"\nSELECTED R509 = {R509/1e3:.2f} kOhm 0.1 % 25 ppm (E96): Default IOS {D_MIN*1e3:.1f} / {D_NOM*1e3:.1f} / {D_MAX*1e3:.1f} mA "
  f"(min/nom/max, guaranteed) -> Default total {T_DEF*1e3:.2f} mA (<= 490: {(0.490-T_DEF)*1e3:+.2f} mA; <= 500: {(0.5-T_DEF)*1e3:+.2f} mA)")
P(f"  IOS min vs the 180 mA target {(D_MIN-0.180)*1e3:+.2f} mA; vs the analog need {NEED_MAX*1e3:.1f} mA (r2 final) "
  f"{(D_MIN-NEED_MAX)*1e3:+.1f} mA; vs the round-1 need 174.2 mA {(D_MIN-0.1742)*1e3:+.1f} mA")
nxt = min([c for c in cands if c[0] > R509], key=lambda c: c[0])
P(f"  Robustness: the rule is met by {(0.490-T_DEF)*1e3:.2f} mA only; +{(0.490-T_DEF)*1e3:.2f} mA of non-analog load moves the choice"
  f" to {nxt[0]/1e3:.2f} k (IOS {nxt[1]*1e3:.1f}/{nxt[2]*1e3:.1f}/{nxt[3]*1e3:.1f} mA, total {default_total(NONANA, nxt[3])*1e3:.1f} mA):"
  f" IOS min {'>=' if nxt[1] >= 0.180 else '<'} 180 mA, {'>=' if nxt[1] >= NEED_MAX else '<'} the {NEED_MAX*1e3:.1f} mA analog need (lookup, section 6).")
P("  Transient: above ILIM the device regulates within tLIM (87 us typ); above 1.5 x ILIM a fast clamp acts within tSC (5 us typ)"
  " [DS 7.6, 8.3.3.2-3]; the <= 87 us excursion is filtered by C506/C507 and is not a steady-state USB load.")

P(hdr("4. High mode: R510 in series with U505 (Ron 0..9.5 ohm, VDD 3.3 V, -40..85 C [DS]) parallel to R509"))
def high(r509, r510, mode="headline"):
    rp_nom = 1 / (1 / r509 + 1 / r510)
    rp_hi = 1 / (1 / (r509 * (1 + TOL)) + 1 / (r510 * (1 + TOL) + TMUX1101["RON_MAX_3V3_85"]))
    rp_lo = 1 / (1 / (r509 * (1 - TOL)) + 1 / (r510 * (1 - TOL)))
    lo, hi = tps2596_acc(tps2596_inom(rp_nom)) if mode == "interp" else (-TPS2596_HEADLINE_ACC, TPS2596_HEADLINE_ACC)
    return tps2596_inom(rp_hi) * (1 + lo), tps2596_inom(rp_nom), tps2596_inom(rp_lo) * (1 + hi), rp_nom
NEED_HIGH = ANA_FINAL["NEED_HIGH"]   # [analog r2] High-mode rated-target peak need (round 1: 357 mA)
hrows = []
for b in e96():
    r = b * 10.0
    if 3400 <= r <= 4300:
        h = high(R509, r); hi_ = high(R509, r, "interp")
        hrows.append((r, h))
        P(f"  R510 {r/1e3:5.2f} k: R_par {h[3]:6.0f} ohm -> High IOS {h[0]*1e3:5.1f}/{h[1]*1e3:5.1f}/{h[2]*1e3:5.1f} mA (headline); "
          f"interp min {hi_[0]*1e3:5.1f} max {hi_[2]*1e3:5.1f}")
okh = [x for x in hrows if x[1][0] >= max(0.390, NEED_HIGH)]
R510, H = max(okh, key=lambda x: x[0])        # largest R510 (lowest High maximum) that meets both minima
S4_extra = rail_out("S4")["3V3M"] - rail_out("S2")["3V3M"]
T_HIGH = NONANA + S4_extra * 1.007 + H[2] + IQ2596 + ilm_cur(H[2])
P(f"SELECTED R510 = {R510/1e3:.2f} kOhm 0.1 % 25 ppm: High IOS {H[0]*1e3:.1f} / {H[1]*1e3:.1f} / {H[2]*1e3:.1f} mA; min >= 390 mA "
  f"({(H[0]-0.390)*1e3:+.1f}) and >= the {NEED_HIGH*1e3:.0f} mA analog peak need ({(H[0]-NEED_HIGH)*1e3:+.1f} mA)")
P(f"  High total max {T_HIGH*1e3:.0f} mA vs 1.5 A advertisement ({(1.5-T_HIGH)*1e3:.0f} mA margin); vs TPS25200 IOS min 1011 mA "
  f"({(1.011-T_HIGH)*1e3:.0f} mA)")
ilm_i = TPS2596["GIMON_013_MIN"] * D_MIN
P(f"  U505 leakage in Default (switch off): IS/ID(OFF) <= {TMUX1101['IOFF_3V3_85']*1e9:.1f} nA (-40..85 C, VDD 3.3 V) [DS] vs the ILM"
  f" current at the limit >= {ilm_i*1e6:.0f} uA -> {TMUX1101['IOFF_3V3_85']/ilm_i*1e6:.1f} ppm shift of the Default limit (negligible);"
  f" SEL leakage {TMUX1101['ISEL_MAX_3V3']*1e6:.2f} uA into R511 100 k -> 5 mV. (A 2N7002/AO3400A with a 5 uA IDSS bound would add"
  f" up to {AO3400A_IDSS_BOUND/ilm_i*100:.1f} %.)")

# ------------------------------------------------------------------------------------------------ 5. states
P(hdr("5. State budgets (maxima, VBUS current)"))
def state_total(state, i_ana=0.0, en2596=True):
    d, ro = usb_in(state)
    return sum(d.values()) + ((i_ana + IQ2596 + ilm_cur(i_ana)) if en2596 else 0.0)
# programming mode (D-15): DAC in reset (RESETB low, no MCLK): each I/V output sources <= 4.1 mA [analog 2 C2/D5] instead of
# the 0.853 mA quiescent leg term; OPA1622 inverting-side sink rises to (3.37 - 1.685)/2 k = 0.84 mA per leg [CALC]
RESET_IP = 4 * (4.1e-3 - VREF_HI / 2000.0)
RESET_IN = 4 * ((3.37 - 1.685) / 2000.0 - VREF_HI / 2 / 2000.0)
I_ANA_PROG_MINE = I_ANA_Q + RESET_IP + CP * RESET_IN
I_ANA_PROG = ANA_FINAL["I_Q_RESET"]                     # analog round 2 final
S = {}
S["S1"] = state_total("S1", en2596=False)
S["S2"] = state_total("S2", I_ANA_Q)
S["S3"] = T_DEF
S["S3f"] = state_total("S3f", I_ANA_Q)
S["S3f_x"] = state_total("S3f", D_MAX)
S["S4"] = T_HIGH
S["S5"] = state_total("S5", I_ANA_PROG)
rows = [("S1 attached, unconfigured (3V3M only, MCU max, LEDs on)", S["S1"], 0.100),
        ("S2 configured idle (all domains, analog quiescent, switch closed)", S["S2"], 0.500),
        ("S3 Default playing, analog at the U503 guaranteed maximum", S["S3"], 0.500),
        ("S3f family change (both NDK running, 2nd enable, muted: analog quiescent)", S["S3f"], 0.500),
        ("S3f' NOT ALLOWED: both NDK running while the analog is at the limit", S["S3f_x"], 0.500),
        ("S4 High (>= 1.5 A advertised), analog at the High maximum", S["S4"], 1.500),
        ("S5 programming mode (D-15: rails+3V3A+3V3D, DAC reset, no MCLK, switch open)", S["S5"], 0.500)]
P(f"  {'state':80s} {'max mA':>8s} {'limit':>6s} {'margin':>8s}")
for n, v, lm in rows:
    P(f"  {n:80s} {v*1e3:8.1f} {lm*1e3:6.0f} {(lm-v)*1e3:+8.1f}")
P(f"  S5 analog: {I_ANA_PROG*1e3:.2f} mA with the DAC in reset [analog r2 final] (my estimate {I_ANA_PROG_MINE*1e3:.1f} mA)"
  f" < Default IOS min {D_MIN*1e3:.0f} mA: not limited;"
  " both family oscillators counted as running (CPLD pull-up case, digital levels 2); CPLD programming current = 40 mA [ASSUMP].")
P("  Family change: the firmware must complete the mute (GPIO2 'minimum volume') before the second oscillator is enabled"
  f" (digital 4.4); otherwise S3f' exceeds 500 mA by {(S['S3f_x']-0.5)*1e3:.1f} mA.")

# ------------------------------------------------------------------------------------------------ 6. lookup
P(hdr("6. Integration lookup: best R509 (E96, 0.1 %) vs the non-analog total (guaranteed +-10.4 %; interp for info)"))
def best_r509(nonana, mode="headline", budget=0.490):
    b = None
    for v in e96():
        r = v * 10.0
        mn, nm, mx = lim(r, mode)
        if default_total(nonana, mx) <= budget and (b is None or mn > b[1]):
            b = (r, mn, nm, mx)
    return b
P(f"  {'non-analog mA':>13s} | {'R509':>6s} {'IOS min':>8s} {'nom':>7s} {'max':>7s} | {'R510 for 390':>12s} {'High min':>9s} | interp R509/min")
LOOK = []
for x10 in range(2500, 2801, 25):
    na = x10 / 10000.0
    b = best_r509(na); bi = best_r509(na, "interp")
    okh2 = [(r, high(b[0], r)) for r in (v * 10.0 for v in e96()) if 3000 <= r <= 5000 and high(b[0], r)[0] >= 0.390]
    r510x, hx = max(okh2, key=lambda x: x[0])
    LOOK.append((na, b, r510x, hx))
    P(f"  {na*1e3:13.1f} | {b[0]/1e3:6.2f} {b[1]*1e3:8.1f} {b[2]*1e3:7.1f} {b[3]*1e3:7.1f} | {r510x/1e3:12.2f} {hx[0]*1e3:9.1f} |"
      f" {bi[0]/1e3:.2f} k / {bi[1]*1e3:.1f}")
P("  Feasibility edges (largest non-analog total for each R509):")
for v in e96():
    r = v * 10.0
    if 4300 <= r <= 5300:
        mn, nm, mx = lim(r)
        P(f"    R509 {r/1e3:5.2f} k (IOS min {mn*1e3:6.1f} mA): non-analog <= {(0.490 - mx - IQ2596 - ilm_cur(mx))*1e3:6.2f} mA")

P(hdr("7. Sensitivities of the Default total (fixed R509) and of the R509 choice"))
X2 = DIG["I_X201"]
sens = [("X201 = Epson SG-210STF budget 6.5 mA (original D-3; EOL, reference only)", (DIG["I_X201_EPSON"] - X2) * 1.0023),
        ("X201 -> NDK NSC5338D-80M conditional second source (12.7 mA, D-3 rev)", (DIG["I_X201_NDK"] - X2) * 1.0023),
        ("X201 -> SCTF SX3M80 (40 mA, NOT approved, D-3 rev)", (0.04017 - X2) * 1.0023),
        ("X202/X203 -> SCTF SX3M (both run, +25 mA, non-compliant fallback)", 0.02496 * 1.0023),
        ("MCU 70 mA instead of 80 mA [ASSUMP]", -0.010 * 1.0067),
        ("CPLD 30 mA instead of 40 mA [ASSUMP]", -0.010 * 1.0023),
        ("DVDD 50 mA (ESS nominal) instead of 60 mA [PH]", -0.010 * 1.0023),
        ("green LED off in Default (firmware)", -DIG["I_LED_G"] * 1.0067)]
for n, dv in sens:
    b = best_r509(NONANA + dv)
    P(f"  {n:66s} {dv*1e3:+7.2f} mA -> total {default_total(NONANA+dv, D_MAX)*1e3:6.1f} mA; best R509 {b[0]/1e3:.2f} k, IOS min {b[1]*1e3:.1f} mA")

P(hdr("8. 3V3D buck check (orchestrator: 'a buck saves only ~10 % of 3V3D current at 4.30 V')"))
i3d = ro2["3V3D"]
for eta in (0.80, 0.85, 0.90):
    iin = 3.3 * i3d / (eta * 4.30)
    P(f"  eta {eta:.2f} at 5V_SYS 4.30 V: buck input {iin*1e3:6.1f} mA vs LDO {d2['3V3D']*1e3:6.1f} mA -> saves {(d2['3V3D']-iin)*1e3:5.1f} mA")
P("  -> ~10-15 %; not adopted (switching noise next to MCLK/DAC, parts, layout) - unchanged conclusion.")

P(hdr("9. S6 suspend (all switched domains off, MCU Stop, LEDs off, RELAY_EN/ILIM_HI/PB14/RESETB low)"))
s6 = [("MCU Stop + USBHS PHY suspended [PH, digital; WCH typ Stop 110 uA]", 0.0019),
      ("D+ 1.5 k pull-up into the host 15 k: 3.35 V / (1.425 k + 14.25 k) [CALC]", 3.35 / (1425 + 14250)),
      ("U502 TPS7A20 IGND at ~2.2 mA load (<= 85 C) [CALC interp DS max]", lin(10e-6, 2000e-6, 0.3, 0.0022)),
      ("U102 TPS25200 IQ on [DS]", TPS25200["IQ_ON_MAX"]), ("U102 EN leakage via R109 [DS]", TPS25200["IEN_MAX"]),
      ("VBUS_SENSE divider R105 + R106 at 5.5 V [CALC]", V5MAX / (147e3 * 0.99)),
      ("U101 USBLC6 leakage at 5.5 V [ASSUMP; DS 150 nA at 5.25 V]", 1e-6),
      ("U504 TLV767 shutdown [DS, VIN 16 V]", TLV767["ISHDN_MAX"]), ("U302 LP5907 shutdown [DS]", LP5907["IQ_OFF_MAX"]),
      ("U503 TPS2596 shutdown, VIN >= 4 V, EN < VSD [DS]", TPS2596["ISD_MAX"]),
      ("U505 TMUX1101 IDD -40..125 C [DS] + SEL leakage (SEL low) [DS]", TMUX1101["IDD_MAX_125"] + TMUX1101["ISEL_MAX_3V3"]),
      ("U103 TPD2E2U06 leakage, CC <= 2.5 V (Rd) [DS 10 nA each]", 2 * TPD2E2U06["ILEAK_2V5_MAX"]),
      ("U303 TLV758P: input 3V3D at 0 V -> 0 (ISHDN 1 uA [DS] applies only with VIN present)", 0.0),
      ("R532 PB4 pull-down: 5V_ANA_F = 0 V -> PGOOD network at 0 V", 0.0),
      ("discharge FETs / gate pull-ups / EN pull-downs (rails and ENs at 0 V)", 0.0),
      ("legacy A-to-C cable Rp through Rd [ASSUMP]", V5MAX / (56e3 * 0.95 + 5.1e3 * 0.99))]
t6 = 0.0
for n, v in s6:
    P(f"  {n:88s} {v*1e3:8.4f} mA"); t6 += v
S6_AC = t6; S6_CC = t6 - s6[-1][1]
P(f"  {'TOTAL, legacy A-to-C cable':88s} {S6_AC*1e3:8.4f} mA -> margin {(2.5e-3-S6_AC)*1e6:5.0f} uA to 2.5 mA")
P(f"  {'TOTAL, C-to-C cable':88s} {S6_CC*1e3:8.4f} mA -> margin {(2.5e-3-S6_CC)*1e6:5.0f} uA")
P(f"  MCU suspend current allowed (A-to-C, zero margin): {(2.5e-3 - S6_AC + 0.0019)*1e3:.3f} mA")

res = dict(NONANA=NONANA, I_ANA_Q=I_ANA_Q, IP=IP, IN=IN, I_DCS_LEG=I_DCS_LEG, NEED=NEED_MAX, R509=R509, R510=R510,
           DEF=(D_MIN, D_NOM, D_MAX), HIGH=(H[0], H[1], H[2]), T_DEF=T_DEF, T_HIGH=T_HIGH, S=S, S6_AC=S6_AC, S6_CC=S6_CC,
           I_ANA_PROG=I_ANA_PROG, RO_S2=ro2, IN_S2=d2, IQ2596=IQ2596)
json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c03_results.json"), "w"), indent=1)
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
