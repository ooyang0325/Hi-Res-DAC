"""c15 - Reissue of report section 5.5 (LM27762 peak-current envelopes) with the TPS2596 (U503) path, R8 round 2,
and the analog stream's R_NEG limits recomputed with the new LM27762 VIN values.

Analog r2 (headroom_table.csv) used the round-1 VIN (TPS2553 path): 4.310 / 4.202 V (Default / High, VBUS 4.40 V) and
4.510 / 4.402 V (VBUS 4.60 V).  Round 2: U503 = TPS2596, Ron 131 mOhm max, analog current at the guaranteed IOS max
(Default 222.6 mA, High 483.4 mA, c03) -> VIN changes.  Two conventions are printed:
  (A) envelope convention (round 1, conservative): the analog draws the U503 IOS max at the instant of the peak;
  (B) operating point: the analog draws the target's own 5V_ANA peak (analog r2 table), non-analog loads at maximum.
Formulas are the analog stream's (analog/out/r2_power.txt lines 77-79):
  regulation   R_NEG <= (VIN - |V-|max 3.781) / I-pk - 0.45
  PGOOD-safe   R_NEG <= (VIN - 3.668) / I-pk - 0.45          (97 % of 3.781 V [ASSUMP analog])
  no-clip      R_NEG <= (VIN - leg pk - 1.3) / I-pk - 0.45   (typ swing model [analog])
"""
import csv, json, os
from pw_common import *

HERE = os.path.dirname(os.path.abspath(__file__))
out = []
P = out.append
R = load_basis(HERE)   # R10 F-3: final basis from c17 (c17_basis.json), else round-2 c03

R_TR1, R_TR2, R_FB = 0.020, 0.010, 0.050       # same as c04 [ASSUMP copper; DS FB501 DCR max]
RON_U503 = TPS2596["RON_MAX"]                   # 0.131 ohm [DS]
VN_MAX, VP_MAX = 3.781, 3.915                   # |V-| max, V+ max [CALC c05, D-6 rails]
PG_LEVEL = 3.668                                # analog [ASSUMP] 97 % of 3.781 V
R_POS = 0.675                                   # positive path [DS-typ x 1.5, ASSUMP] (c04)
NONANA, IQ = R["NONANA"], R["IQ2596"]
IOS = {"Default": R["DEF"][2], "High": R["HIGH"][2]}
VIN_R1 = {(4.40, "Default"): 4.310, (4.40, "High"): 4.202, (4.60, "Default"): 4.510, (4.60, "High"): 4.402}

# analog r2 targets (analog/out/headroom_table.csv, 25 Sep 2026): mode, jack, ohm, mW, leg pk V, I+ pk, I- pk, 5V_ANA pk (mA)
TARGETS = [
    ("High", "3.5 mm", 32, 50.0, 1.803, 149.5, 148.8, 192.0),
    ("High", "4.4 mm", 60, 105.0, 1.786, 156.0, 155.2, 316.9),
    ("High", "4.4 mm", 120, 65.0, 1.981, 104.2, 103.4, 211.8),
    ("High", "4.4 mm", 300, 30.0, 2.124, 67.1, 66.4, 136.5),
    ("Default", "3.5 mm", 32, 38.0, 1.572, 134.4, 133.6, 175.6),
    ("Default", "4.4 mm", 60, 17.0, 0.719, 81.6, 80.8, 165.8),
    ("Default", "4.4 mm", 120, 35.0, 1.454, 84.8, 84.1, 172.5),
    ("Default", "4.4 mm", 300, 30.0, 2.124, 67.1, 66.4, 136.5),
]
ANA_CSV = os.path.normpath(os.path.join(HERE, "..", "..", "analog", "out", "headroom_table.csv"))
ana_ref = {}
if os.path.exists(ANA_CSV):
    for row in csv.DictReader(open(ANA_CSV)):
        ana_ref[(row["mode"], row["jack"], int(row["load_ohm"]), float(row["VBUS"]))] = row


def vin_lm(vbus, i_ana):
    itot = NONANA + i_ana + IQ
    v5 = min(vbus, TPS25200["VOVC_MAX"]) - itot * R_TR1 - (itot - u502_bypass(R)) * TPS25200["RON_MAX"]   # R10: U502 bypasses U102 (E-16)
    return v5, v5 - i_ana * (RON_U503 + R_FB + R_TR2)


def limits(vin, legpk, ineg):
    i = ineg * 1e-3
    return ((vin - VN_MAX) / i - 0.45, (vin - PG_LEVEL) / i - 0.45, (vin - legpk - 1.3) / i - 0.45)


P(basis_line(R))
P(hdr("1. Reissued 5.5 envelopes (convention A: analog current = U503 IOS max; VBUS at the J101 pads)"))
P("I-neg max = (VIN - 3.781 V)/(R_NEG + 0.45 ohm); I-pos max = (VIN - 3.915 V)/0.675 ohm; R_NEG typical 2.5 ohm only [DS-typ]")
P(f"{'VBUS':>5s} {'mode':8s} {'I_ana':>6s} {'5V_SYS':>7s} {'VIN':>6s} {'(r1)':>6s} | I-neg 2.5 / 3.5 / 4.5 ohm (r1)          | I-pos (r1)")
env = {}
for vb in (4.40, 4.60):
    for mode in ("Default", "High"):
        v5, vin = vin_lm(vb, IOS[mode])
        vr1 = VIN_R1[(vb, mode)]
        ng = [(vin - VN_MAX) / (r + 0.45) * 1e3 for r in (2.5, 3.5, 4.5)]
        ng1 = [(vr1 - VN_MAX) / (r + 0.45) * 1e3 for r in (2.5, 3.5, 4.5)]
        ip, ip1 = (vin - VP_MAX) / R_POS * 1e3, (vr1 - VP_MAX) / R_POS * 1e3
        env[(vb, mode)] = vin
        P(f"{vb:5.2f} {mode:8s} {IOS[mode]*1e3:5.1f}  {v5:6.3f}  {vin:6.3f} {vr1:6.3f} | {ng[0]:4.0f} / {ng[1]:4.0f} / {ng[2]:4.0f} mA "
          f"({ng1[0]:3.0f}/{ng1[1]:3.0f}/{ng1[2]:3.0f})  | {ip:4.0f} ({ip1:3.0f}) mA")
P("Change vs round 1: Default VIN -10 mV (U503 Default IOS max 165 -> 222.6 mA); High VIN +17 mV (High IOS max 509 -> 483.4 mA).")
P(f"J101 mated-contact sensitivity (if VBUS were specified before the contacts): <= 20 mOhm loop -> VIN -{0.020*R['T_HIGH']*1e3:.0f} mV High, "
  f"-{0.020*R['T_DEF']*1e3:.0f} mV Default.")

P(hdr("2. Analog R_NEG limits recomputed (regulation / PGOOD-safe / no-clip, ohm); A = VIN at IOS max, B = VIN at the target peak"))
P(f"{'target':28s} {'I-pk':>6s} {'ANApk':>6s} | VBUS 4.40: A (analog r1-VIN)        B (VIN)                 | VBUS 4.60: A                 B")
rows = []
worst = {}
for mode, jack, ohm, mw, legpk, ipos, ineg, anapk in TARGETS:
    line = f"{mode:7s} {jack} {ohm:3d} ohm {mw:5.1f} mW  {ineg:6.1f} {anapk:6.1f} |"
    rec = {"mode": mode, "jack": jack, "ohm": ohm, "mW": mw}
    for vb in (4.40, 4.60):
        va = env[(vb, mode)]
        vbb = vin_lm(vb, anapk * 1e-3)[1]
        la, lb = limits(va, legpk, ineg), limits(vbb, legpk, ineg)
        ref = ana_ref.get((mode, jack, ohm, vb))
        rtxt = f"({float(ref['RNEG_max_regulation']):.2f})" if ref else "(n/a)"
        line += f" {la[0]:4.2f}/{la[1]:4.2f}/{la[2]:5.2f} {rtxt:6s}  {lb[0]:4.2f}/{lb[1]:4.2f}/{lb[2]:5.2f} [{vbb:5.3f}] |"
        rec[f"A{vb}"], rec[f"B{vb}"], rec[f"VINB{vb}"] = la, lb, vbb
        # positive-rail check (convention A)
        rec[f"IPOS_ENV{vb}"] = (va - VP_MAX) / R_POS * 1e3
    rows.append(rec)
    P(line)
P("(analog r2 value of the regulation limit in brackets; their VIN was the round-1 value)")
ipos_min = min(min(r["IPOS_ENV4.4"], r["IPOS_ENV4.6"]) for r in rows)
P(f"Positive rail: I+ pk <= {max(t[5] for t in TARGETS):.1f} mA vs the positive envelope >= {ipos_min:.0f} mA in every case (convention A).")

P(hdr("3. Summary for the analog stream"))
h32 = [r for r in rows if r["mode"] == "High" and r["ohm"] == 32][0]
h60 = [r for r in rows if r["mode"] == "High" and r["ohm"] == 60][0]
d32 = [r for r in rows if r["mode"] == "Default" and r["ohm"] == 32][0]
h120 = [r for r in rows if r["mode"] == "High" and r["ohm"] == 120][0]
P(f"VBUS 4.40 V High 32 ohm SE / 60 ohm bal: regulation R_NEG <= {h32['A4.4'][0]:.2f} / {h60['A4.4'][0]:.2f} ohm (A; analog r2: 2.38 / 2.26), "
  f"PGOOD-safe <= {h32['A4.4'][1]:.2f} / {h60['A4.4'][1]:.2f} ohm (analog 3.14 / 2.99), no-clip >= {min(h32['A4.4'][2], h60['A4.4'][2]):.2f} ohm")
P(f"   at the target's own peak (B): regulation <= {h32['B4.4'][0]:.2f} / {h60['B4.4'][0]:.2f} ohm, PGOOD-safe <= {h32['B4.4'][1]:.2f} / {h60['B4.4'][1]:.2f} ohm")
P(f"VBUS 4.40 V Default 32 ohm SE: regulation <= {d32['A4.4'][0]:.2f} ohm (A; analog 3.51), {d32['B4.4'][0]:.2f} ohm (B)")
P(f"VBUS 4.40 V High 120 ohm: regulation <= {h120['A4.4'][0]:.2f} ohm (A; analog 3.62)")
P(f"VBUS 4.60 V High 60 ohm bal: regulation <= {h60['A4.6'][0]:.2f} ohm (A; analog 3.55), {h60['B4.6'][0]:.2f} ohm (B)")
allA = [(r['mode'], r['jack'], r['ohm'], vb, r[f'A{vb}'][0]) for r in rows for vb in (4.40, 4.60)]
below25 = [a for a in allA if a[4] < 2.5]
below35 = [a for a in allA if 2.5 <= a[4] < 3.5]
P(f"Convention A, regulation limit below the typical 2.5 ohm: {[(a[0], a[1], a[2], a[3], round(a[4], 2)) for a in below25]}")
P(f"Convention A, regulation limit between 2.5 and 3.5 ohm: {[(a[0], a[1], a[2], a[3], round(a[4], 2)) for a in below35]}")
P("Conclusion: the High-mode 32/60 ohm targets at VBUS 4.40 V still depend on R_NEG < 2.5 ohm for strict regulation; no clipping up to"
  f" >= {min(min(r['A4.4'][2], r['A4.6'][2]) for r in rows):.1f} ohm. The analog conclusions (no VBUS volume ceiling, PGOOD-dip rule in firmware) are unchanged.")

res = {"VIN_ENV": {f"{k[0]:.2f}_{k[1]}": v for k, v in env.items()},
       "ROWS": [{k: (list(v) if isinstance(v, tuple) else v) for k, v in r.items()} for r in rows]}
json.dump(res, open(os.path.join(HERE, "c15_results.json"), "w"), indent=1)
txt = "\n".join(out)
open(os.path.join(HERE, "c15_lm27762_headroom.out.txt"), "w").write(txt + "\n")
print(txt)
