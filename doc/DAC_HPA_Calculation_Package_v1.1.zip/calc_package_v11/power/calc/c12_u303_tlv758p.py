"""c12 - U303 TI TLV75801PDBVR (1V3 = ES9018K2M external DVDD) with R533 15.0 k / R534 11.0 k 0.1 % 25 ppm (D-7).
Output accuracy over temperature, dropout, EN, thermal, DVDD <= DVCC in the ramps (c06 for the controlled ramp-down,
c14 for the hard unplug) and the internal active discharge vs the c06 requirement."""
from pw_common import *
out = []
P = out.append
R1, R2, TOLR = 15.0e3, 11.0e3, 0.001 + 25e-6 * 35      # 0.1 % + 25 ppm x 35 K (board 25 -> 60 C)
VIN_MIN = 3.3 * (1 - TLV767["ACC"]) - 0.1434 * TLV767["LOADREG_MAX_PER_A"] * 3.3    # 3V3D minimum
VIN_MAX = 3.3 * (1 + TLV767["ACC"])
I1 = 0.060                                              # [PH] DVDD
P(hdr("1. Pinout and connections [DS SBVS351D Figure 4-2 (DBV), parts FU1-F]"))
P("  1 IN = 3V3D (C311 1 uF), 2 GND, 3 EN = AUD_EN (same net as U504 EN; R508 47 k pull-down), 4 FB = N3_1V3_FB, 5 OUT = 1V3 (C312 1 uF"
  " + DAC C310 2.2 uF / C309 100 nF at pin 21); R533 15.0 k OUT->FB, R534 11.0 k FB->GND.")
P("  EN = AUD_EN (not tied to IN): the pass device turns off at the same instant as the TLV767, so Q506/R530 never load a"
  " regulating LDO; EN abs max 6.5 V independent of VIN [DS] -> EN high before VIN is allowed.")

P(hdr("2. Output voltage over temperature (VOUT = VFB x (1 + R1/R2), VFB 0.55 V)"))
kn = 1 + R1 / R2
klo = 1 + R1 * (1 - TOLR) / (R2 * (1 + TOLR)); khi = 1 + R1 * (1 + TOLR) / (R2 * (1 - TOLR))
pd = (VIN_MAX - 1.30) * I1 + VIN_MAX * TLV758P["IGND_MAX"]
tj = TA_MAX + T_LOCAL_RISE + pd * TLV758P["THETA_JA"]
P(f"  Pd <= {pd*1e3:.0f} mW -> TJ <= {tj:.1f} C (theta_JA 176.9 C/W DBV [DS]) -> the +-1 % (TJ -40..85 C) accuracy row applies")
for acc, lab in ((TLV758P["ACC_85"], "TJ <= 85 C (design)"), (TLV758P["ACC_125"], "TJ <= 125 C (bound)")):
    ifb = TLV758P["IFB_MAX"] * R1
    line = TLV758P["LINE_REG_MAX"]              # [DS] max over VOUT+0.5..6 V (bound for 1.8 -> 3.35 V)
    load = 2 * TLV758P["LOAD_REG_TYP"] * I1     # [ASSUMP] 2 x typ 30 mV/A
    vmin = 0.55 * (1 - acc) * klo - ifb - line - load
    vmax = 0.55 * (1 + acc) * khi + ifb + line
    P(f"  {lab:22s}: {vmin:.4f} .. {0.55*kn:.4f} .. {vmax:.4f} V (VFB {acc*100:.1f} %, ratio +-{(khi/kn-1)*100:.2f} %, IFB x R1 {ifb*1e3:.1f} mV,"
      f" line {line*1e3:.1f} mV, load {load*1e3:.1f} mV) vs ESS 1.235..1.365 V -> margins {(vmin-1.235)*1e3:+.0f} / {(1.365-vmax)*1e3:+.0f} mV")
P("  (D-7 quotes 1.283-1.317 V = VFB +-1 %, ratio and IFB only; line/load regulation widen it to the values above.)"
  " External DVDD must exceed the ESS internal 1.2 V regulator to disable it (analog S3) -> min 1.27 V vs 1.2 V nominal internal.")

P(hdr("3. Dropout, current limit, capacitors"))
P(f"  VIN {VIN_MIN:.3f}..{VIN_MAX:.3f} V -> headroom >= {VIN_MIN-1.326:.2f} V vs VDO <= 400 mV at 500 mA (1.2 <= VOUT < 1.5 V, -40..125 C) [DS]"
  f" (~{0.400*I1/0.5*1e3:.0f} mV at 60 mA, resistive scaling); ICL 530 mA min (8.8 x the 60 mA load); ISC 350 mA typ [DS]")
P("  COUT >= 0.47 uF effective, <= 220 uF [DS]: C312 + C310 + C309 >= 2.27 uF effective (c04); CIN C311 1 uF (EC test condition).")
P("  UVLO: rising 1.21-1.47 V, falling 1.17-1.42 V [DS]; below UVLO the output is connected to GND through RPULLDOWN [DS 6.3.1].")

P(hdr("4. DVDD <= DVCC in every ramp (ESS: external DVDD with or after DVCC [DS p.27]; analog S3: DVDD <= DVCC + 0.3 V)"))
dv_fb = ESS_DAC["DVCC_NOM_I"] * 0.45
P(f"  Ramp-up (AUD_EN high): the TLV767 soft-starts 3V3D (500 us typ); the TLV758P can only start once VIN > UVLO and its pass device"
  f" cannot put OUT above IN (no reverse path in that direction) -> DVDD <= 3V3D; DVCC = 3V3D - 14.2 mA x 0.45 ohm (FB301) ="
  f" 3V3D - {dv_fb*1e3:.1f} mV -> DVDD - DVCC <= +{dv_fb*1e3:.1f} mV (only while tracking in dropout) -> met.")
P("  Controlled ramp-down (AUD_EN low; suspend, power-down, MCU reset): c06 - both LDOs off at once, Q506/R530 take 1V3 < 0.1 V in"
  " <= 0.13 ms, 3V3D (R529) <= 0.63 ms; max(DVDD - DVCC) <= +1.2 mV at 143 mA 3V3D load (+170 mV only at an unphysical 180 mA).")
P("  Hard unplug (no firmware): c14 (both collapse with 5V_SYS; reported there).")

P(hdr("5. Internal active discharge vs the c06 requirement -> Q506/R530 stay"))
C1_HI = 3.63e-6
tau = TLV758P["RPD_TYP_6V"] * C1_HI
P(f"  RPULLDOWN 95 ohm TYPICAL at VIN = 6 V; no min/max [DS 5.5]; active when disabled or VIN < UVLO [DS 6.3.1-6.3.2]; its gate drive"
  f" comes from VIN (3V3D here, 3.3 V -> weaker than at 6 V) [ASSUMP].")
P(f"  With C_1V3 <= {C1_HI*1e6:.2f} uF: tau = {tau*1e6:.0f} us typ -> 1V3 < 0.1 V after {tau*math.log(1.326/0.1)*1e3:.2f} ms typ, vs 3V3D"
  f" <= 0.63 ms (R529): 1V3 would lag 3V3D and DVDD would exceed DVCC by up to ~0.6 V (body-diode clamp) [CALC c06], and nothing is"
  " guaranteed -> it does NOT meet the requirement. Q506 (AO3400A, gate N5_DIS_D) + R530 4.7 ohm STAY: 1V3 < 0.1 V <= 0.13 ms,"
  " always before 3V3D. The internal pull-down is a welcome typical extra, not relied on.")

P(hdr("6. Thermal and stress"))
P(f"  Pd {pd*1e3:.0f} mW, TJ {tj:.1f} C (limit 125 C, accuracy row 85 C); VIN <= 3.33 V vs 6.0 V ROC / 6.5 V abs; FB <= 0.56 V vs 2.0 V abs;"
  " VOUT <= VIN + 0.3 V abs max: met in the ramps with Q506 (c06); R533/R534 dissipate <= 0.07 mW.")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
