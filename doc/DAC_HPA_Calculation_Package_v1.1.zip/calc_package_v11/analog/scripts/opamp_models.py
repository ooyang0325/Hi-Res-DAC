"""Op-amp AC macro-models used by the stability scripts.

OPA1622 (TI SBOS727B): open-loop gain magnitude and phase digitized from Fig. 10 (VS = +-18 V,
RL = 2 kOhm, 25 C, typical), open-loop output impedance magnitude digitized from Fig. 40 and fitted
with a minimum-phase R + (R||L) + (R||L) network (the phase of Zo is not published).
Validated against Fig. 24 (phase margin vs capacitive load, G = +1 and G = -1) in validate_opa1622.py.

OPA2210 (TI SBOS924H): only tabulated specs are available as text (figures could not be digitized):
A0 = 132 dB typ (126 dB min), GBW = 18 MHz typ, PM = 80 deg typ at G = +1, RL = 10 kOhm, CL = 25 pF,
input capacitance 9 pF differential, 0.5 pF common mode.  A 3-pole model is fitted so that the
G = +1 phase margin with 10 kOhm || 25 pF equals 80 deg for each assumed Zo shape; a family of Zo
shapes (the curve itself was not readable) and a +-30 % GBW spread bound the uncertainty.
"""
import json, math, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DIG = json.load(open(os.path.join(HERE, '..', 'ds', 'opa1622_digitized.json')))


def _interp_log(fq, xs, ys):
    lx = np.log10(xs)
    return np.interp(np.log10(fq), lx, ys)


class OPA1622:
    A0_DB = 136.0  # typ, SBOS727B 6.5 (600-ohm load, +-18 V)

    def __init__(self, gbw_scale=1.0, extra_pole_hz=150e6, zo_scale=1.0):
        g = sorted(DIG['fig10']['gain']); p = sorted(DIG['fig10']['phase'])
        # remove duplicate frequencies
        self.gf = np.array([a for a, b in g]); self.gd = np.array([b for a, b in g])
        self.pf = np.array([a for a, b in p]); self.pd = np.array([b for a, b in p]) - 180.0  # angle of A
        o = np.argsort(self.gf); self.gf, self.gd = self.gf[o], self.gd[o]
        o = np.argsort(self.pf); self.pf, self.pd = self.pf[o], self.pd[o]
        self.f_lo, self.f_hi = max(self.gf[0], self.pf[0]), min(self.gf[-1], self.pf[-1])
        g_lo = _interp_log(self.f_lo, self.gf, self.gd)
        self.fp1 = self.f_lo / math.sqrt(10 ** ((self.A0_DB - g_lo) / 10) - 1)
        # high-frequency extrapolation: slope of the last half decade
        f1 = self.f_hi / 3.16
        self.slope_hi = (_interp_log(self.f_hi, self.gf, self.gd) - _interp_log(f1, self.gf, self.gd)) / 0.5
        self.gbw_scale = gbw_scale
        self.extra_pole = extra_pole_hz
        self.zo_scale = zo_scale
        self._fit_zo()

    def A(self, f):
        f_eff = f / self.gbw_scale  # scaling the frequency axis scales GBW and every pole
        if f_eff <= self.f_lo:
            a = 10 ** (self.A0_DB / 20) / (1 + 1j * f_eff / self.fp1)
            return a
        if f_eff <= self.f_hi:
            gdb = _interp_log(f_eff, self.gf, self.gd)
            ph = _interp_log(f_eff, self.pf, self.pd)
        else:
            gdb = _interp_log(self.f_hi, self.gf, self.gd) + self.slope_hi * math.log10(f_eff / self.f_hi)
            ph = _interp_log(self.f_hi, self.pf, self.pd)
        a = 10 ** (gdb / 20) * np.exp(1j * ph * math.pi / 180)
        if self.extra_pole:  # conservative extra pole (beyond the published curve)
            a = a / (1 + 1j * f_eff / self.extra_pole) * (1 + 1j * self.f_hi / self.extra_pole) if f_eff > self.f_hi else a
        return a

    def _fit_zo(self):
        d = sorted(DIG['fig40_Zo'])
        f = np.array([a for a, b in d]); z = np.array([b for a, b in d])
        sel = f > 1e3
        f, z = f[sel], z[sel]
        best = None
        R0 = float(np.median(z[f < 1e5]))
        # coarse grid search for R0 + R1||sL1 + R2||sL2
        for R1 in np.linspace(5, 60, 23):
            for L1 in np.logspace(-8, -6, 25):
                for R2 in [0, 5, 10, 20, 40]:
                    for L2 in ([1e-9] if R2 == 0 else np.logspace(-8.5, -7, 7)):
                        zz = self._zo_net(f, R0, R1, L1, R2, L2)
                        err = np.sum((np.log(np.abs(zz)) - np.log(z)) ** 2)
                        if best is None or err < best[0]:
                            best = (err, R0, R1, L1, R2, L2)
        self.zo_par = best[1:]
        self.zo_fit_rms_pct = 100 * math.sqrt(best[0] / len(f))

    @staticmethod
    def _zo_net(f, R0, R1, L1, R2, L2):
        s = 2j * np.pi * f
        z = R0 + (R1 * s * L1) / (R1 + s * L1)
        if R2 > 0:
            z = z + (R2 * s * L2) / (R2 + s * L2)
        return z

    def Zo(self, f):
        return self.zo_scale * complex(self._zo_net(np.array([f / self.gbw_scale]), *self.zo_par)[0])

    CIN_DIFF = 0.8e-12  # SBOS727B 6.5 input impedance, differential 60 kOhm || 0.8 pF (typ)
    CIN_CM = 0.9e-12    # common mode 500 MOhm || 0.9 pF (typ)


class OPA2210:
    A0_DB = 132.0      # typ (126 dB min) SBOS924H 6.6
    GBW = 18e6         # typ
    CIN_DIFF = 9e-12   # 400 kOhm || 9 pF typ
    CIN_CM = 0.5e-12   # 1e9 Ohm || 0.5 pF typ

    ZO_SHAPES = {
        # name: (R_hf, R_lf, f_corner): Zo = R_hf + R_lf/(1 + j f/f_corner)  (RRO common-emitter style)
        'R20': (20.0, 0.0, 1.0),
        'R50': (50.0, 0.0, 1.0),
        'R100': (100.0, 0.0, 1.0),
        'CE700': (30.0, 700.0, 3e4),
        'CE300_L': (15.0, 300.0, 1e5),  # plus a 100 nH series inductance (added below)
    }

    def __init__(self, zo_shape='R50', gbw_scale=1.0, pm_target=80.0):
        self.zo_shape = zo_shape
        self.gbw = self.GBW * gbw_scale
        self.a0 = 10 ** (self.A0_DB / 20)
        self.fp1 = self.gbw / self.a0
        self.p3_ratio = 3.0
        self._fit_p2(pm_target)

    def Zo(self, f):
        rh, rl, fc = self.ZO_SHAPES[self.zo_shape]
        z = rh + rl / (1 + 1j * f / fc)
        if self.zo_shape.endswith('_L'):
            z += 2j * math.pi * f * 100e-9
        return z

    def _A(self, f, p2):
        return self.a0 / ((1 + 1j * f / self.fp1) * (1 + 1j * f / p2) * (1 + 1j * f / (self.p3_ratio * p2)))

    def A(self, f):
        return self._A(f, self.p2)

    def _pm_follower(self, p2, RL=10e3, CL=25e-12):
        from mna import Circuit, margins
        self.p2 = p2
        fr = np.logspace(3, 9.3, 500)
        T = []
        for f in fr:
            c = Circuit()
            c.OPAMP('U', 'inp', 'out', 'out', self.A, self.Zo)
            c.R('inp', '0', 1.0)
            c.R('out', '0', RL); c.C('out', '0', CL)
            c.C('inp', 'out', self.CIN_DIFF)
            T.append(c.loop_gain(f, 'U'))
        return margins(fr, np.array(T))['pm']

    def _fit_p2(self, target):
        lo, hi = 20e6, 5e9
        for _ in range(40):
            mid = math.sqrt(lo * hi)
            pm = self._pm_follower(mid)
            if pm is None or pm < target:
                lo = mid
            else:
                hi = mid
        self.p2 = math.sqrt(lo * hi)
        self.pm_fit = self._pm_follower(self.p2)
