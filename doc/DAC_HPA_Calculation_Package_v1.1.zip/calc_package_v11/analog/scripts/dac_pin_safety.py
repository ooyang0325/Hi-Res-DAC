"""ES9018K2M output-pin protection: v0.8 pin clamps (BAT54S at DACx) versus v0.9 output clamps
(BAT54A common-anode Schottky from GND to each OPA2210 output), per-state pin excursion bounds,
clamp leakage/offset, nonlinear-capacitance distortion at the virtual ground and at the I/V output.

ESS abs max (ES9018K2M v3.7 p.28): DAC output voltage range GND < Vout < AVCC (no margin, no injection rating).
Nexperia BAT54S/BAT54A v.6 (1 Jul 2022) Table 7: VF <= 240/320/400/500/800 mV at 0.1/1/10/30/100 mA (25 C, pulsed);
IR <= 2 uA at VR = 25 V, 25 C only; Cd <= 10 pF at VR = 1 V.  ST BAR43 (DocID3288 Rev 5): IR <= 100 uA at 100 C.
OPA2210 SBOS924H 6.6/7.3.4: CM (V-)+1.5..(V+)-1.5 V, ISC +-65 mA typ, no phase reversal (output limits into the
appropriate rail), input current limit 10 mA (abs max).  Output: ../out/dac_pin_safety.txt"""
import os, math
import numpy as np

OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
L = []
p = L.append
Rf = 698.0; Rs_min, Rs_max = 806 * 0.89, 806 * 1.11
AVCC = 3.3; VREF = 1.670

p('A. Clamp leakage -> guaranteed offset (v0.8 BAT54S at the DAC pins)')
ir25 = 2e-6
p('  Only IR <= 2 uA at 25 V, 25 C is guaranteed [DS]. Monotonic in VR, so at VR ~ 1.7 V IR <= 2 uA at 25 C;'
  ' no bound exists at 50 C. One diode of each pair can leak fully while the other does not (no guaranteed cancellation).')
for fac, lab in [(1.0, '25 C, datasheet'), (5.7, '50 C, typical Schottky x2 per 10 K [ASSUMP]')]:
    i = ir25 * fac
    p('  %-45s: net pin current <= %.1f uA -> I/V shift %.2f mV per pin, %.2f mV per leg (two pins, opposite sign) [CALC]'
      % (lab, i * 1e6, i * Rf * 1e3, 2 * i * Rf * 1e3))
p('  -> the offset budget cannot be guaranteed with BAT54S (or ST BAR43S: 100 uA at 100 C) -> pin clamps REJECTED (R8-A5, B6, B7, D9).')

p(''); p('B. Nonlinear junction capacitance at the virtual ground (v0.8 BAT54S, for the record)')
A20k = 18e6 / 20e3; A1k = 18e6 / 1e3
vout_pk = 1.13  # I/V output peak at calibrated full scale [CALC analog_budget]
Isig = vout_pk / Rf
Cj0, phi, M = 15e-12, 0.40, 0.5  # [ASSUMP] fitted so that Cj(1 V) = 8 pF (DS max 10 pF at 1 V)
def q_diode(vr):  # charge of a reverse-biased junction, integral of Cj dV
    return Cj0 * phi / (1 - M) * ((1 + vr / phi) ** (1 - M) - 1)
for f, A in [(1e3, A1k), (20e3, A20k)]:
    ve = vout_pk / A
    t = np.linspace(0, 1 / f, 4096, endpoint=False)
    v = ve * np.sin(2 * np.pi * f * t)
    for name, q in [('pair (to AGND and to AVCC)', q_diode(VREF + v) - q_diode(AVCC - VREF - v)), ('single diode (worst)', q_diode(VREF + v))]:
        i = np.gradient(q, t)
        spec = np.abs(np.fft.rfft(i)) / len(t) * 2
        h1, h2, h3 = spec[1], spec[2], spec[3]
        p('  f = %5.0f Hz, virtual-ground error %.3g Vpk, %-28s: fundamental %.2e A (%.0f dB re signal), H2 %.0f dB, H3 %.0f dB re signal current %.2f mA [CALC]'
          % (f, ve, name, h1, 20 * math.log10(h1 / Isig), 20 * math.log10(h2 / Isig + 1e-30), 20 * math.log10(h3 / Isig + 1e-30), Isig * 1e3))
p('  -> the nonlinear capacitance is harmless for THD (< -150 dB); the problem with pin clamps is only the leakage (A).')

p(''); p('C. v0.9 output clamps D405-D408 (Nexperia BAT54S,215 on each I/V output: lower diode to GND, upper diode to AVCC_L/AVCC_R)')
p('  Normal states (analog_budget.txt): I/V output 0.538..2.802 V at the calibrated level -> lower diode reverse >= 0.54 V, upper diode'
  ' reverse >= 0.41 V (AVCC min 3.216 V); pre-calibration default -3.0 dB keeps the same window; untrimmed 0 dBFS (firmware fault only):'
  ' upper diode forward <= 5 mV (nA).  Reset state (output switch open): I/V output <= 3.369 V -> upper diode forward <= 0.15 V, < 0.1 mA into AVCC, harmless [CALC/DS].')
Zo, T1k = 50.0, 10 ** (132 / 20) / (1 + 1e3 / (18e6 / 10 ** (132 / 20))) * 0.54
for ileak in (2e-6, 20e-6):
    p('  leakage %.0f uA at the output node: DC error = I x Zo/(1+T) = %.2g V (loads only the op-amp output; no current into the DAC pin) [CALC]' % (ileak * 1e6, ileak * Zo / (1 + 10 ** (126 / 20) * 0.5)))
t = np.linspace(0, 1e-3, 4096, endpoint=False)
vo = 1.67 + 1.13 * np.sin(2 * np.pi * 1e3 * t)
q = q_diode(vo)
i = np.gradient(q, t)
spec = np.abs(np.fft.rfft(i)) / len(t) * 2
Zcl20 = Zo / (18e6 / 20e3 * 0.54)
p('  nonlinear C at the output: H2 current %.2e A at 1 kHz; x closed-loop Zout (%.3f ohm at 20 kHz, worst) -> %.1e V = %.0f dB re 1.13 V [CALC]'
  % (spec[2], Zcl20, spec[2] * Zcl20, 20 * math.log10(spec[2] * Zcl20 / 1.13)))
p('  capacitance 2 x 10 pF max on each output is included in stability_iv.txt.')

p(''); p('D. Pin excursion bound when an I/V output is driven negative (rail collapse / OPA2210 out of its supply range)')
p('  The pin node sees the DAC source (>= 0 V, 806 ohm) and Rf to the I/V output.  Nothing else can pull it below GND:')
p('  OPA2210 input diodes go to its rails (conduct only below V- - 0.5 V) and to VREF (>= 0 V) [DS O2210 7.3.2/7.3.5].')
VF = {1e-3: 0.320, 10e-3: 0.400, 30e-3: 0.500, 100e-3: 0.800}
def vf(i):
    xs = sorted(VF); ys = [VF[x] for x in xs]
    return float(np.interp(math.log10(i), [math.log10(x) for x in xs], ys))
for i, lab in [(20e-3, 'realistic (collapsing supply)'), (65e-3, 'OPA2210 ISC typ at +-18 V (worst)')]:
    v = vf(i) + 0.05  # +50 mV for 0 C [ASSUMP -2 mV/K]
    k = Rs_max / (Rs_max + Rf)
    ipin = v * (1 - k) / Rf
    p('  clamp current %.0f mA (%s): VF <= %.2f V (25 C DS, log-interp) + 0.05 V (0 C) -> pin >= -%.2f V; current available to the pin node <= %.2f mA [CALC]'
      % (i * 1e3, lab, v - 0.05, k * v, (v - k * v) / Rf * 1e3))
p('  without any clamp: pin -> -Rs/(Rs+Rf) x |V-| = %.2f V -> the DAC ESD diode conducts ~ (3.83 - 0.6)/Rf = %.1f mA [CALC]'
  % (-Rs_max / (Rs_max + Rf) * 3.83, (3.83 - 0.6) / Rf * 1e3))
p('  v0.8 pin clamps: pin >= -0.40 V at 4.4 mA (25 C) with the DAC ESD diode in parallel; v0.9: comparable voltage bound, '
  '<= 0.5 mA available to the pin node, zero added leakage/capacitance at the virtual ground.')

p(''); p('E. Positive excursion (pin > AVCC) requires the I/V output above AVCC while the DAC source is high.  Without the upper clamp:')
for vplus in (3.915,):   # V+ max with the final rails (D-6); round 1 used 4.014 V
    for vdac in (1.65, 3.175):
        for Rs in (Rs_min, Rs_max):
            w = Rf / (Rs + Rf)
            vp = w * vdac + (1 - w) * (vplus - 0.2)
            p('  I/V output stuck at V+ - 0.2 = %.2f V, DAC source %.3f V, Rs %.0f ohm: pin %.3f V = AVCC %+.3f V [CALC]' % (vplus - 0.2, vdac, Rs, vp, vp - AVCC))
p('  unplug_model_r2.txt (round 2) shows that after the LM27762 UVLO the I/V supply falls below 4.5 V up to 3.5 ms BEFORE 3V3A < 0.3 V (the new'
  ' DC-sense 4.7 uF nodes back-feed 3V3A through 5.1 k), so the OPA2210 output is undefined while AVCC is still up: unclamped pin up to AVCC + 0.92 ... 1.3 V'
  ' (DAC ESD diode into AVCC); clamp exposure <= 4.9 ms, <= 0.62 ms with the firmware brown-out rule (AVCC_EN low in the VBUS_SENSE ISR).')
for i, lab in [(20e-3, 'realistic'), (65e-3, 'OPA2210 ISC typ')]:
    v = vf(i) + 0.05
    for Rs in (Rs_min, Rs_max):
        w = Rf / (Rs + Rf)
        exc = (1 - w) * v - w * 0.038 * AVCC
        p('  with the upper clamp (%s, %.0f mA, VF %.2f V at 0 C), Rs %.0f ohm: pin <= AVCC %+.3f V; current available to the pin <= %.2f mA [CALC]'
          % (lab, i * 1e3, v, Rs, exc, (v - exc) / Rf * 1e3))
p(''); p('F. DAC-pin state table (output switch architecture, TLP3545A x 4)')
rows = [
    ('Normal (rails, AVCC, clocks up)', 'pin = VREF +- Vout/A (<= 1.3 mV at 20 kHz)', 'inside', 'none'),
    ('Reset (RESETB low, AVCC up)', 'pins driven to ground inside the DAC, I/V holds pin at VREF; I/V out 2.91..3.37 V < 3.54 V limit', 'inside', 'none'),
    ('Power-up: rails first, AVCC second', 'VREF tracks 3V3A (tau 0.19 us), I/V in control from VREF = 0', 'inside', 'firmware order (power plan)'),
    ('Power-down: switch open, ramp to ground, MCLK stop, AVCC off, rails last', 'VREF tracks 3V3A; I/V rails up until 3V3A < 0.3 V', 'inside', 'firmware order'),
    ('Unplug / brownout (EVERY hot unplug)', 'LM27762 stops at UVLO 2.4 V; the I/V supply falls below 4.5 V up to 3.5 ms before 3V3A < 0.3 V (unplug_model_r2.txt): output undefined, clamped to -0.74 V .. AVCC + 0.74 V; exposure <= 0.62 ms with the firmware brown-out rule',
     'GND-0.42 .. AVCC+0.42 V', 'D405-D408 (both sides)'),
    ('Overload (TPS2596 limiting, rails droop)', 'no phase reversal: output limits toward V+ (< AVCC) or saturates low (> 0 V)', 'inside', 'none'),
    ('OPA1622 output-stage failure (stuck leg)', 'switch opens (permit/firmware); no load on the stuck leg -> rails stay -> controlled shutdown', 'inside', 'output switch'),
    ('OPA1622 rail-to-rail short (both rails collapse, AVCC up until firmware)', 'I/V output may head to either rail: clamped to -0.74 V / AVCC + 0.74 V', '-0.42 .. AVCC+0.42 V', 'D405-D408'),
    ('V- shorted, V+ alive, OPA2210 malfunction (double fault)', 'upper clamp holds the I/V output <= AVCC + 0.74 V', '<= AVCC + 0.42 V', 'D405-D408'),
    ('Failed OPA2210', 'not protectable at reasonable cost', 'undefined', 'residual'),
]
for r in rows:
    p('  %-72s | %-110s | %-18s | %s' % r)
open(os.path.join(OUT, 'dac_pin_safety.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
