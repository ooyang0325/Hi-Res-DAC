"""Detailed tables for the selected T network (R1a 1.33k + R1b 665 + Ct 1.8 nF, R2 = R4 = 2.00k),
optionally with an output snubber at the leg node.  Output: ../out/stability_legs_T2.txt"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA1622v
from stability_legs_T import build_T, FR, OUT

def build(R1a, R1b, Ct, load, CL, op, relay, cable, Rz=None, Cz=None):
    c = build_T(R1a, R1b, Ct, load, CL, op, relay, cable)
    if Rz:
        c.R('LEG', 'zz', Rz); c.C('zz', '0', Cz)
    return c

MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]
lines = []
for (Rz, Cz) in [(None, None), (22.0, 4.7e-9), (47.0, 2.2e-9), (10.0, 10e-9)]:
    lines.append('=== T 1.33k/665/1.8n, snubber %s' % ('none' if not Rz else '%g ohm + %g nF' % (Rz, Cz * 1e9)))
    lines.append(' load   CL(pF) cable | worst PM over models/relay | PM nominal (CAL x1, relay) | GM nominal dB | Ms nominal')
    allw = 999
    for load in ('open', 16, 32, 300, 600):
        for CL in ((0,) if load == 'open' else (0, 100e-12, 220e-12, 470e-12, 1e-9, 2e-9)):
            for cable in ((False,) if load == 'open' else ((False, True) if CL in (0, 1e-9) else (False,))):
                ws = []
                for (mk, gs) in MODELS:
                    for relay in (True, False):
                        m = margins(FR, build(1330, 665, 1.8e-9, load, CL, OPA1622v(mk, gs), relay, cable, Rz, Cz).loop_gain(FR, 'U'))
                        ws.append(m['pm_worst'] if m['pm_worst'] is not None else -99)
                mn = margins(FR, build(1330, 665, 1.8e-9, load, CL, OPA1622v('CAL', 1.0), True, cable, Rz, Cz).loop_gain(FR, 'U'))
                if CL <= 1e-9: allw = min(allw, min(ws))
                lines.append(' %5s %7.0f %5s | %6.1f | %6.1f @ %.2f MHz | %s | %.2f'
                             % (load, CL * 1e12, cable, min(ws), mn['pm_worst'], (mn['fc'] or 0) / 1e6,
                                'n/a' if mn['gm'] is None else '%.1f' % mn['gm'], 1 / mn['vector_margin']))
    lines.append(' => worst PM for CL <= 1 nF (incl. cable): %.1f deg' % allw)
open(os.path.join(OUT, 'stability_legs_T2.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
