"""Behavioural time-domain model of a hot unplug (VBUS removed at t = 0) to check the DAC-pin safety claim:
the I/V rails must outlive 3V3A (AVCC/VREF) so that the OPA2210 keeps the DAC pins at VREF, and the window in
which the OPA2210 common-mode range is violated (VREF > V+ - 1.5 V) must not let a pin exceed AVCC.
All capacitances and loads are placeholders [PH] from the power stream (v0.8 values) with a +-50 % sweep;
LP5907 and TPS2553 assumed NOT to block reverse current (worst case for 3V3A hold-up is irrelevant; for the rails
the worst case is the fastest 5V_ANA collapse).  Output: ../out/unplug_model.txt"""
import os, itertools
import numpy as np
OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
L = []

def run(C5=10e-6, Idig=0.25, C3a=5.0e-6, I3a=18.4e-3, Cana=12e-6, Iana=0.073, Crail=30e-6, Irail=0.036, hp=0.0, Rdis=None, t_isr=20e-6, v_det=4.1, lp_block=False):
    dt = 1e-7; t = 0.0
    v5, v3a, vana, vp, vn = 5.0, 3.3, 5.0, 3.9, 3.72
    on = True; res = []; t_det = None
    while t < 6e-3:
        if t_det is None and v5 < v_det: t_det = t
        # 5V_SYS: digital load constant current above 3.3 V, resistive below
        idig = Idig if v5 > 3.3 else Idig * v5 / 3.3
        # 5V_ANA tied to 5V_SYS through the TPS2553 (no reverse blocking assumed): common node
        iana = (Iana + hp) if on else 0.0
        dv = -(idig + iana + I3a) / (C5 + Cana) * dt
        v5 = max(0.0, v5 + dv); vana = v5
        # 3V3A: LP5907 regulates while v5 > 3.4 V, else follows (no reverse block: v3a <= v5 + 0.6)
        fast = Rdis is not None and t_det is not None and t >= t_det + t_isr
        if fast:   # firmware: AVCC_EN low + DOM_DIS on -> LP5907 off, switched discharge Rdis
            v3a = max(0.0, v3a - (I3a * min(1, v3a / 3.3) + v3a / Rdis) / C3a * dt)
        else:
            v3a_target = min(3.3, max(0.0, v5 - 0.1))
            v3a = max(v3a_target, v3a - I3a / C3a * dt) if v3a > v3a_target else v3a_target
        if not lp_block:
            v3a = min(v3a, v5 + 0.6)
        # LM27762: regulates while VIN > VOUT + drop; UVLO at 2.4 V falling
        if on and vana < 2.4:
            on = False
        if on:
            vp = min(3.9, max(0.0, vana - 0.05)); vn = min(3.72, max(0.0, vana - 0.03 - Irail * 3.0))
        else:
            vp = max(0.0, vp - (Irail + hp) / Crail * dt); vn = max(0.0, vn - (Irail + hp) / Crail * dt)
        res.append((t, v5, v3a, vp, vn))
        t += dt
    return np.array(res)

def sweep(Rdis=None, lp_block=False, clamp_vf=None):
    global CLAMP_VF
    CLAMP_VF = clamp_vf
    worst_pos = -9; worst_case = None; tmin_margin = 9
    for C5, Idig, C3a, Crail, hp in itertools.product((5e-6, 10e-6, 20e-6), (0.15, 0.25, 0.35), (2.5e-6, 5e-6, 7.5e-6), (15e-6, 30e-6, 45e-6), (0.0, 0.08)):
        r = run(C5=C5, Idig=Idig, C3a=C3a, Crail=Crail, hp=hp, Rdis=Rdis, lp_block=lp_block)
        t, v5, v3a, vp, vn = r.T
        vref = 0.50607 * v3a
        cm_bad = vref > vp - 1.5
        supply_ok = (vp + vn) >= 4.5
        # pin bound when CM violated: output limits into V+ (no phase reversal), DAC source <= 0.962 AVCC, w = Rf/(Rs+Rf)
        for w in (698 / (717 + 698), 698 / (895 + 698)):
            vout = np.maximum(vp, 0)          # output can reach at most its own V+ (conservative)
            if CLAMP_VF is not None:          # BAT54S upper diode from the I/V output to AVCC
                vout = np.minimum(vout, v3a + CLAMP_VF)
            loose = cm_bad | ((vp + vn) < 4.5)  # out of CM range or below the 4.5 V minimum supply
            pin = np.where(loose, w * 0.962 * v3a + (1 - w) * vout, vref)
            exc = pin - v3a
            m = float(np.max(exc[v3a > 0.05])) if np.any(v3a > 0.05) else -9
            if m > worst_pos:
                worst_pos, worst_case = m, (C5, Idig, C3a, Crail, hp, w)
        # time between 3V3A < 0.3 V and the OPA2210 total supply falling below 4.5 V (positive = rails outlive AVCC)
        i_a = np.argmax(v3a < 0.3) if np.any(v3a < 0.3) else len(t) - 1
        i_r = np.argmax(~supply_ok) if np.any(~supply_ok) else len(t) - 1
        tmin_margin = min(tmin_margin, t[i_r] - t[i_a])
    
    return worst_pos, worst_case, tmin_margin
for label, Rdis, lpb, cvf in [('no clamp, no action at unplug (LP5907 reverse conduction assumed)', None, False, None),
                         ('no clamp, LP5907 blocks reverse current', None, True, None),
                         ('no clamp, firmware AVCC_EN low + 10 ohm 3V3A discharge at VBUS < 4.1 V + 20 us', 10.0, True, None),
                         ('no clamp, firmware AVCC_EN low + 22 ohm 3V3A discharge at VBUS < 4.1 V + 20 us', 22.0, True, None),
                         ('BAT54S at each I/V output, upper diode to AVCC, VF 0.51 V (20 mA, 0 C)', None, False, 0.51),
                         ('BAT54S at each I/V output, upper diode to AVCC, VF 0.74 V (65 mA, 0 C)', None, False, 0.74)]:
    wp, wc, tm = sweep(Rdis, lpb, cvf)
    L.append('%s:' % label)
    L.append('  min time the I/V supply (>= 4.5 V total) outlives 3V3A < 0.3 V: %+.3f ms; worst pin above AVCC while the OPA2210 is out of its CM/supply range: %+.3f V' % (tm * 1e3, wp))
L.insert(0, 'Hot-unplug behavioural model, 486 corners per case (C5 5-20 uF, digital load 0.15-0.35 A, 3V3A 2.5-7.5 uF, rails 15-45 uF, headphone 0/80 mA) [CALC with PH]')
open(os.path.join(OUT, 'unplug_model.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
