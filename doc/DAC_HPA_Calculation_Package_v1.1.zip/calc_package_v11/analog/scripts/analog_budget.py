import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '../..'))
"""Analog-stream worst-case budgets for Spec v0.9 / Notes v0.8 (R8 iteration).

Every number printed carries a label:
  [DS]      datasheet min/max        [DS-typ]  datasheet typical only
  [CALC]    calculated here          [ASSUMP]  assumption (named)       [PH] placeholder from another stream
Sources (short keys, full citations in report.md):
  ESS   = ES9018K2M datasheet v3.7 (22 Apr 2021), current/ES9018K2M_datasheet_v3.7.txt
  O1622 = TI OPA1622 SBOS727B, external/input/opa1622.pdf (tables 6.1-6.5; Figs 10, 24, 34, 37-40 digitized)
  O2210 = TI OPA2210 SBOS924H (Aug 2021), https://www.ti.com/lit/ds/symlink/opa2210.pdf (table 6.6)
  YAG   = YAGEO RT series (0.1 % 25 ppm; 0.05 % 10 ppm variant), LCSC/Digi-Key pages
  B54A  = Nexperia BAT54A v.6 (1 Jul 2022)
Output: ../out/analog_budget.txt, ../out/offset_budget.csv  (round 2: rails D-6, TLP3545A switch; power tables in r2_power.py)
"""
import os, math, csv, json
import numpy as np

OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
L = []
def p(s=''):
    L.append(s)

kT4 = 4 * 1.380649e-23 * 298.15

# ---------------------------------------------------------------- design values (v0.9, this stream)
D = dict(
    Rf=698.0, Rf_tol=0.001, Rf_tcr=25e-6,                 # R423-R426 RT0603BRD07698RL [YAG]
    Cf=820e-12, Cf_tol=0.05,                                # C431-C434 C0G
    Rvt=9760.0, Rvb=10000.0, Rv_tol=0.001, Rv_tcr=25e-6,   # R438 top / R439 bottom (VREF), 0.1 %
    R2=2000.0, R1a=1300.0, R1b=680.0, Ct=1.8e-9, Clead=10e-12,   # round 2: T network retuned to stocked 0.05 %/10 ppm E24 values (round 1: 1330/665)
    Rleg_tol_base=0.001, Rleg_tcr_base=25e-6,               # fallback (LCSC stock) YAGEO RT0603BRD07
    Rleg_tol_hi=0.0005, Rleg_tcr_hi=10e-6,                  # fitted (round 2): Susumu RG1608N-xxx-W-T1 0.05 %/10 ppm
)
# ---------------------------------------------------------------- operating conditions (brief section 5)
V3A_nom, V3A_tol = 3.30, 0.02          # LP5907 output accuracy +-2 % [PH power stream / DS LP5907]
VPOS = (3.789, 3.915); VNEG = (3.661, 3.781)   # [DEC D-6] final rails, 0.1 % single resistors (round 1: brief 3.789-4.014 / 3.618-3.828)
T_amb = (0.0, 50.0); dT = 25.0           # worst temperature excursion from 25 C
I_AVCC_max = 8.0e-3                      # [DS] ESS p.28 AVCC 8.0 mA nominal ("current nominal"); used as max [ASSUMP]
R_AVCC = 2.2                             # R301/R302
# ESS output model [DS-typ]: source 0.924*AVCC p-p around AVCC/2 behind 806 ohm +-11 % (note *1 p.31)
Rs_nom, Rs_tol = 806.0, 0.11
k_fs = 0.924
# DAC null (zero DC current point) uncertainty: [DS-typ] 1.65 V = AVCC/2 (voltage model) vs 2.112 mA*806 = 1.702 V
knull = (0.500, 2.112e-3 * 806 / 3.3)

# ---------------------------------------------------------------- 1 Level and calibration
p('=' * 100); p('1. LEVEL AND CALIBRATION'); p('=' * 100)
AVCC_lo = V3A_nom * (1 - V3A_tol) - I_AVCC_max * R_AVCC
AVCC_hi = V3A_nom * (1 + V3A_tol)
g_lo = D['Rf'] * (1 - D['Rf_tol'] - D['Rf_tcr'] * dT) / (Rs_nom * (1 + Rs_tol))
g_hi = D['Rf'] * (1 + D['Rf_tol'] + D['Rf_tcr'] * dT) / (Rs_nom * (1 - Rs_tol))
g_nom = D['Rf'] / Rs_nom
leg_gain = D['R2'] / (D['R1a'] + D['R1b'])
def lvl(g, avcc):  # per-leg rms at 0 dBFS (differential pin pair, one leg)
    return g * k_fs * avcc / math.sqrt(2) * leg_gain
L_lo, L_nom, L_hi = lvl(g_lo, AVCC_lo), lvl(g_nom, V3A_nom - 0.5 * I_AVCC_max * R_AVCC), lvl(g_hi, AVCC_hi)
Lcal = 1.55
p('I/V gain Rf/Rs: %.4f nominal, %.4f .. %.4f [CALC: Rf %.0f ohm 0.1 %% 25 ppm, Rs 806 ohm +-11 %% DS]' % (g_nom, g_lo, g_hi, D['Rf']))
p('Untrimmed level per leg at 0 dBFS: nominal %.3f Vrms, range %.3f .. %.3f Vrms [CALC]' % (L_nom, L_lo, L_hi))
p('Calibrated level 1.55 Vrms per leg (req.), master trim needed: nominal %.2f dB, range %.2f .. %.2f dB [CALC]'
  % (20 * math.log10(Lcal / L_nom), 20 * math.log10(Lcal / L_hi), 20 * math.log10(Lcal / L_lo)))
p('Lowest-gain unit reaches 1.55 Vrms with %.2f dB to spare (trim cannot boost; must be > 0) [CALC]' % (20 * math.log10(L_lo / Lcal)))
precal_min = math.floor(20 * math.log10(Lcal / L_hi) * 2) / 2
precal = -4.5   # requirement (brief 4 / Spec v0.8 section 2): pre-calibration default -4.5 dB; round 1 used the minimum value -3.0 dB (superseded R2)
p('Pre-calibration default attenuation: %.1f dB [req. brief 4] -> highest-gain unit %.3f Vrms, lowest-gain unit %.3f Vrms (<= 1.55); the least attenuation that keeps'
  ' the highest-gain unit <= 1.55 Vrms would be %.1f dB (round 1 value, superseded) [CALC]' % (precal, L_hi * 10 ** (precal / 20), L_lo * 10 ** (precal / 20), precal_min))
p('ESS master trim is a 32-bit signed register (reg 17-20, ESS p.19): resolution far below 0.001 dB [DS]')

# ---------------------------------------------------------------- 2 VREF, OPA2210 CM and swing, reset state
p(); p('=' * 100); p('2. VREF, OPA2210 COMMON MODE, I/V SWING, RESET STATE, OPA1622 CM'); p('=' * 100)
kv = D['Rvb'] / (D['Rvt'] + D['Rvb'])
kv_lo = D['Rvb'] * (1 - D['Rv_tol'] - D['Rv_tcr'] * dT) / (D['Rvt'] * (1 + D['Rv_tol'] + D['Rv_tcr'] * dT) + D['Rvb'] * (1 - D['Rv_tol'] - D['Rv_tcr'] * dT))
kv_hi = D['Rvb'] * (1 + D['Rv_tol'] + D['Rv_tcr'] * dT) / (D['Rvt'] * (1 - D['Rv_tol'] - D['Rv_tcr'] * dT) + D['Rvb'] * (1 + D['Rv_tol'] + D['Rv_tcr'] * dT))
VREF_lo, VREF_hi = kv_lo * V3A_nom * (1 - V3A_tol), kv_hi * V3A_nom * (1 + V3A_tol)
Rth = D['Rvt'] * D['Rvb'] / (D['Rvt'] + D['Rvb'])
p('VREF = %.5f x 3V3A (%.5f..%.5f) = %.3f V nominal, %.3f .. %.3f V [CALC]; source %.0f ohm; divider current %.3f mA'
  % (kv, kv_lo, kv_hi, kv * V3A_nom, VREF_lo, VREF_hi, Rth, V3A_nom / (D['Rvt'] + D['Rvb']) * 1e3))
p('  target = midpoint of the ESS null range %.4f..%.4f x AVCC (1.65 V voltage model vs 1.702 V current formula) [DS-typ]' % knull)
cm_hi = VPOS[0] - 1.5
p('OPA2210 CM range (V-)+1.5 .. (V+)-1.5 V [DS O2210 6.6]: upper limit at V+min %.3f V = %.3f V; margin to VREFmax %.3f V [CALC]'
  % (VPOS[0], cm_hi, cm_hi - VREF_hi))
p('OPA2210 lower CM limit at |V-|max: %.3f V -> margin %.3f V [CALC]' % (-VNEG[1] + 1.5, VREF_lo - (-VNEG[1] + 1.5)))
# swing: [DS] (V+)-0.2 V at RL 10 k (1.5 mA at +-15 V) and (V+)-0.6 V at RL 600 (24 mA); linear interpolation in current [CALC]
def hr2210(i_mA):
    return 0.2 + (i_mA - 1.5) * (0.6 - 0.2) / (24.0 - 1.5) if i_mA > 1.5 else 0.2
# normal operation, highest-gain unit, calibrated and untrimmed
Ipin_pk = k_fs * AVCC_hi / 2 / (Rs_nom * (1 - Rs_tol))
Vsig_pk_untrim = D['Rf'] * (1 + D['Rf_tol']) * Ipin_pk
Iout_legs = lambda v: v / 2000.0  # two leg inputs: R1 path ~ (V - V/2)/2k plus R3+R4 path V/4k = V/2k
for name, vpk in [('untrimmed 0 dBFS (highest-gain unit)', Vsig_pk_untrim), ('calibrated full scale', Lcal * math.sqrt(2) / 2)]:
    vmax = VREF_hi + vpk; vmin = VREF_lo - vpk
    i = (vpk / D['Rf'] + Iout_legs(vmax)) * 1e3
    lim = VPOS[0] - hr2210(i)
    # upper clamp: VREF and AVCC come from the same 3V3A -> evaluate at both 3V3A corners consistently
    up = min(V3 - I_AVCC_max * R_AVCC - (kv_hi * V3 + vpk) for V3 in (V3A_nom * (1 - V3A_tol), V3A_nom * (1 + V3A_tol)))
    p('I/V output, %s: %.3f .. %.3f V; limit V+min - %.2f V = %.3f V -> margin %.3f V; lower clamp diode reverse biased >= %.3f V, '
      'upper clamp diode (to AVCC, same 3V3A) reverse biased >= %.3f V [CALC]' % (name, vmin, vmax, hr2210(i), lim, lim - vmax, vmin, up))
# reset state: pins driven to ground (ESS pin table), I/V holds pin at VREF: out = VREF*(1+Rf/Rs)
vr_max = VREF_hi * (1 + D['Rf'] * (1 + D['Rf_tol'] + D['Rf_tcr'] * dT) / (Rs_nom * (1 - Rs_tol)))
vr_min = VREF_lo * (1 + D['Rf'] * (1 - D['Rf_tol'] - D['Rf_tcr'] * dT) / (Rs_nom * (1 + Rs_tol)))
i_reset = (VREF_hi / (Rs_nom * (1 - Rs_tol)) + Iout_legs(vr_max)) * 1e3
p('Reset state (RESETB low, AVCC up; ESS pin table "driven to ground"): pin current %.2f mA max, I/V output %.3f .. %.3f V; '
  'limit %.3f V -> margin %.3f V: no saturation [CALC]' % (VREF_hi / (Rs_nom * (1 - Rs_tol)) * 1e3, vr_min, vr_max,
                                                        VPOS[0] - hr2210(i_reset), VPOS[0] - hr2210(i_reset) - vr_max))
p('  (even if saturated: pin = Vsat*Rs/(Rs+Rf) stays inside 0..AVCC and the input differential stays < 0.5 V; output current %.1f mA << ISC 65 mA typ [DS-typ])' % i_reset)
# round 2 (parts FU3 / protection question): conservative datasheet-row check.  SBOS924H 6.6: (V+) - 0.2 V at RL 10 k (AOL > 130 dB, 25 C;
# AOL > 120 dB over -40..125 C) and (V+) - 0.6 V at RL 600 ohm (AOL > 114 dB, 25 C only).  The I/V output sources 3.3-4.1 mA in the reset state
# (about 830 ohm to GND): the 10 k row (1.5 mA at 15 V) does not cover it, so the guaranteed bound is the 600 ohm row.
i_rst_lo = (VREF_lo / (Rs_nom * (1 + Rs_tol)) + vr_min * (1 - 2000.0 / 3980.0) / 1980.0 + vr_min / 3980.0) * 1e3
i_rst_hi = (VREF_hi / (Rs_nom * (1 - Rs_tol)) + vr_max * (1 - 2000.0 / 3980.0) / 1980.0 + vr_max / 3980.0) * 1e3
lim_c = VPOS[0] - 0.6
p('Reset-state I/V output load: Rf branch VREF/Rs %.2f .. %.2f mA + leg networks V x 0.5025 mS + CM taps <= 14 uA -> %.2f .. %.2f mA sourced (~%.0f ohm to GND) [CALC]'
  % (VREF_lo / (Rs_nom * (1 + Rs_tol)) * 1e3, VREF_hi / (Rs_nom * (1 - Rs_tol)) * 1e3, i_rst_lo, i_rst_hi, vr_max / i_rst_hi * 1e3))
cal_hi = VREF_hi + Lcal * math.sqrt(2) / 2
p('Conservative swing check with the 600 ohm row only [DS 25 C]: limit V+min - 0.6 V = %.3f V -> calibrated FS (%.3f V) margin %+.3f V; untrimmed 0 dBFS (%.3f V) %+.3f V;'
  ' reset state (%.3f V) %+.3f V [CALC]' % (lim_c, cal_hi, lim_c - cal_hi, VREF_hi + Vsig_pk_untrim, lim_c - VREF_hi - Vsig_pk_untrim, vr_max, lim_c - vr_max))
p('  -> reset state: soft saturation possible only in the Rs -11 %% / 3V3A +2 %% / V+min corner: pin = %.3f V x Rs/(Rs+Rf) = %.3f V (inside 0..AVCC), OPA2210 input'
  ' differential %.3f V (<< the back-to-back diode threshold), switch open, CM window tripped -> harmless; reset-state CM >= %.3f V in every corner (set by VREF(1+Rf/Rs), not by the swing)'
  % (lim_c, lim_c * (Rs_nom * (1 - Rs_tol)) / (Rs_nom * (1 - Rs_tol) + D['Rf']), VREF_hi - lim_c * (Rs_nom * (1 - Rs_tol)) / (Rs_nom * (1 - Rs_tol) + D['Rf']), vr_min))
p('  -> untrimmed 0 dBFS clipping on the highest-gain unit is only reachable if the calibration trim is lost (pre-calibration default -4.5 dB keeps %.3f V margin)'
  % (lim_c - VREF_hi - Vsig_pk_untrim * 10 ** (-4.5 / 20)))
fwd = max(kv_hi * V3 * (1 + D['Rf'] * (1 + D['Rf_tol'] + D['Rf_tcr'] * dT) / (Rs_nom * (1 - Rs_tol))) - (V3 - I_AVCC_max * R_AVCC)
          for V3 in (V3A_nom * (1 - V3A_tol), V3A_nom * (1 + V3A_tol)))
p('  reset state: upper clamp diode bias <= %+.3f V forward (VREF and AVCC from the same 3V3A): Schottky current << 1 uA, output switch open, harmless [CALC]' % fwd)
vcm_leg = VREF_hi / 2
p('OPA1622 input CM = V_IV/2 = %.3f V max; range (V-)+1.5 .. (V+)-1 V [DS O1622] = %.3f .. %.3f V at the worst rails -> margins %.2f / %.2f V [CALC]'
  % (vcm_leg, -VNEG[0] + 1.5, VPOS[0] - 1.0, VPOS[0] - 1.0 - vcm_leg, vcm_leg - (-VNEG[0] + 1.5)))
p('Rail choice (D-6 final): V+ 3.789/3.852/3.915 V, |V-| 3.661/3.721/3.781 V. A 3.78 V class V+ would cut the OPA2210 CM margin to %.3f V and the reset-state swing margin to %.3f V,'
  % (3.673 - 1.5 - VREF_hi, 3.673 - hr2210(i_reset) - vr_max))
p('  with no power benefit (the negative rail, |V-|min 3.661 V, sets the symmetrical swing) and no brown-out benefit (the charge-pump')
p('  negative rail drops out first: needs VIN >= |V-| + 0.03 V + I*Rcp). [CALC]')

# ---------------------------------------------------------------- 3 quiescent split and power tables -> ROUND 2: r2_power.py
p(); p('=' * 100); p('3. ANALOG QUIESCENT, POWER, SPL, LM27762 HEADROOM: moved to r2_power.py (round 2, out/r2_power.txt, power_table.csv,'); p('   headroom_table.csv).  The round-1 LM339B / relay-placeholder tables are superseded.'); p('=' * 100)

# ---------------------------------------------------------------- 4 output impedance
p(); p('=' * 100); p('4. OUTPUT IMPEDANCE (1 kHz)'); p('=' * 100)
A1k = 10 ** (136 / 20) / abs(1 + 1j * 1e3 / 5.31)   # [DS-typ Fig 10]
T1k = A1k / 2.0
Zcl = 5.47 / T1k
A20k = 10 ** (64.3 / 20); Zcl20 = 5.47 / (A20k / 2)
p('OPA1622 closed loop: Zo_ol 5.47 ohm [DS-typ Fig 40] / loop gain %.0f (1 kHz, noise gain 2) = %.2f mOhm; at 20 kHz %.1f mOhm [CALC]' % (T1k, Zcl * 1e3, Zcl20 * 1e3))
for name, parts in [('3.5 mm (L+ to sleeve)', [('OPA1622', Zcl), ('DFT link', 0.05), ('TLP3545A 60 C', 0.081), ('PCB trace', 0.02), ('tip contact', 0.05), ('sleeve contact', 0.05)]),
                    ('4.4 mm (L+ to L-)', [('OPA1622 x2', 2 * Zcl), ('DFT links x2', 0.10), ('TLP3545A x2 60 C', 0.162), ('PCB traces', 0.02), ('two jack contacts', 0.10)])]:
    tot = sum(v for _, v in parts)
    p('  %-24s ' % name + ' + '.join('%s %.3f' % (n, v) for n, v in parts) + ' = %.3f ohm (req <= 0.5 ohm incl. contacts) [CALC; switch DS 0.060 ohm x 1.35 ASSUMP, contacts ASSUMP]' % tot)
p('  R417-R420 kept as 0 ohm DFT links only (no isolation resistor is needed or useful for stability, see stability_final.txt).')

# ---------------------------------------------------------------- 5 offset budget
p(); p('=' * 100); p('5. DC OFFSET BUDGET (guaranteed worst case 0-50 C; DAC terms are assumptions)'); p('=' * 100)
AVCC_null_hi = V3A_nom * (1 + V3A_tol)
AVCC_null_lo_drop = I_AVCC_max * R_AVCC
dv_null = max(abs(kv_hi * AVCC_null_hi - knull[0] * (AVCC_null_hi - AVCC_null_lo_drop)),
              abs(kv_lo * AVCC_null_hi - knull[1] * AVCC_null_hi),
              abs(kv_hi * V3A_nom * (1 - V3A_tol) - knull[0] * (V3A_nom * (1 - V3A_tol) - AVCC_null_lo_drop)),
              abs(kv_lo * V3A_nom * (1 - V3A_tol) - knull[1] * V3A_nom * (1 - V3A_tol)))
def offset_terms(tol, tcr, dac_pair_mismatch=0.03, dac_null_mismatch_mV=1.0, tol2=None, tcr2=None):
    eps = tol + tcr * dT                                   # T network (R1a/R1b, R3a/R3b)
    eps2 = eps if tol2 is None else tol2 + tcr2 * dT       # 2.00 k (R2, R4)  [R9 E-4 mixed option]
    terms = []
    terms.append(('Difference-amp CM leakage: V_CM %.3f V x (eps_T %.4f %% + eps_2k %.4f %%) (tol + TCR x 25 K)' % (VREF_hi, eps * 100, eps2 * 100), VREF_hi * (eps + eps2), '[CALC from DS tol/TCR]'))
    terms.append(('OPA1622 Vos 0.6 mV max (-40..125 C) x noise gain 2', 0.6e-3 * 2, '[DS O1622]'))
    terms.append(('OPA1622 Ios 80 nA max (-40..125 C) x R2 2 kOhm', 80e-9 * 2000, '[DS O1622]'))
    terms.append(('OPA2210 Vos (35 uV + 0.5 uV/K x 25 K) x NG %.2f x 2 converters' % (1 + g_hi), (35e-6 + 0.5e-6 * dT) * (1 + g_hi) * 2, '[DS O2210]'))
    terms.append(('OPA2210 IB 4 nA max (-40..85 C) x Rf x 2', 4e-9 * D['Rf'] * 2, '[DS O2210]'))
    dg = g_hi * (dac_pair_mismatch + 2 * (D['Rf_tol'] + D['Rf_tcr'] * dT))
    terms.append(('Pair-gain mismatch (DAC Rs pair %.0f %% ASSUMP + 2 x Rf) x |VREF - Vnull| %.1f mV' % (dac_pair_mismatch * 100, dv_null * 1e3), dg * dv_null, '[ASSUMP x CALC]'))
    terms.append(('DAC pin-to-pin null mismatch %.1f mV x g' % dac_null_mismatch_mV, dac_null_mismatch_mV * 1e-3 * g_hi, '[ASSUMP, not in ESS DS]'))
    terms.append(('DAC-pin clamp leakage (clamps moved to the I/V outputs; nothing on the virtual ground)', 0.0, '[CALC]'))
    return terms
off_rows = []
for label, tol, tcr, tol2, tcr2 in [('0.1 %/25 ppm everywhere (VE choice, superseded by R9 E-4)', D['Rleg_tol_base'], D['Rleg_tcr_base'], None, None),
                        ('R9 E-4 FITTED mixed: T network 0.1 %/25 ppm (YAGEO RT0603BRD071K3L/07680RL) + 2.00 k 0.05 %/10 ppm (Susumu RG1608N-202-W-T1)', D['Rleg_tol_base'], D['Rleg_tcr_base'], D['Rleg_tol_hi'], D['Rleg_tcr_hi']),
                        ('0.05 %/10 ppm everywhere (Susumu RG1608N-132/681/202-W-T1; further option)', D['Rleg_tol_hi'], D['Rleg_tcr_hi'], None, None)]:
    terms = offset_terms(tol, tcr, tol2=tol2, tcr2=tcr2)
    tot = sum(t[1] for t in terms)
    rss = math.sqrt(sum(t[1] ** 2 for t in terms))
    ds_only = sum(t[1] for t in terms if 'ASSUMP' not in t[2])
    p('Leg resistors %s:' % label)
    for t in terms:
        p('    %-100s %6.3f mV %s' % (t[0], t[1] * 1e3, t[2]))
        off_rows.append(dict(resistors=label, term=t[0], mV=round(t[1] * 1e3, 3), label=t[2]))
    drift = VREF_hi * (tcr + (tcr if tcr2 is None else tcr2)) * dT + 2.5e-6 * dT * 2 + 0.5e-6 * dT * (1 + g_hi) * 2
    dac = tot - ds_only
    p('    => R9 E-4 split: GUARANTEED (published terms, 0-50 C) %.2f / %.2f mV [G]; DAC terms (unpublished: 3 %% pair, 1 mV null) %.2f mV/leg [E]; tolerable DAC terms %.2f mV/leg (%.2f x the assumption) [CALC]'
      % (ds_only * 1e3, 2 * ds_only * 1e3, dac * 1e3, 10 - ds_only * 1e3, (10 - ds_only * 1e3) / (dac * 1e3)))
    p('    => unbalanced worst case %.2f mV (datasheet terms only %.2f mV; RSS %.2f mV); req <= 10 mV -> margin %.2f mV [CALC]' % (tot * 1e3, ds_only * 1e3, rss * 1e3, 10 - tot * 1e3))
    p('    => balanced worst case %.2f mV (two independent legs, opposite sign); req <= 20 mV -> margin %.2f mV [CALC]' % (2 * tot * 1e3, 20 - 2 * tot * 1e3))
    p('    => temperature drift 25->0/50 C bounded by DS terms: %.2f mV unbal; 25 C screening limit for a guaranteed 0-50 C: %.2f mV unbal / %.2f mV bal [CALC]'
      % (drift * 1e3, 10 - drift * 1e3 - 0.5, 20 - 2 * drift * 1e3 - 1.0))
with open(os.path.join(OUT, 'offset_budget.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(off_rows[0].keys())); w.writeheader(); w.writerows(off_rows)
p('Sensitivity: DAC pair-gain mismatch assumption 3 %% -> each +1 %% adds %.2f mV; null mismatch each +1 mV adds %.2f mV per leg [CALC]'
  % (g_hi * 0.01 * dv_null * 1e3, g_hi))

# ---------------------------------------------------------------- 6 noise and dynamic range
p(); p('=' * 100); p('6. NOISE AND DYNAMIC RANGE (typical: no noise maxima are published)'); p('=' * 100)
f = np.logspace(np.log10(20), np.log10(20000), 4000)
def aweight(fr):
    f2 = fr ** 2
    ra = (12194 ** 2 * f2 ** 2) / ((f2 + 20.6 ** 2) * np.sqrt((f2 + 107.7 ** 2) * (f2 + 737.9 ** 2)) * (f2 + 12194 ** 2))
    return ra / ((12194 ** 2 * 1000 ** 4) / ((1000 ** 2 + 20.6 ** 2) * math.sqrt((1000 ** 2 + 107.7 ** 2) * (1000 ** 2 + 737.9 ** 2)) * (1000 ** 2 + 12194 ** 2)))
def en2210(fr):  # [DS-typ] 2.5 @10 Hz, 2.25 @100 Hz, 2.2 @1 kHz
    return np.interp(np.log10(fr), [1, 2, 3, 5], [2.5e-9, 2.25e-9, 2.2e-9, 2.2e-9])
def en1622(fr):  # [DS-typ] 10 @10, 4 @100, 2.8 @1k
    return np.interp(np.log10(fr), [1, 2, 3, 5], [10e-9, 4e-9, 2.8e-9, 2.8e-9])
def in1622(fr):  # [DS-typ] 2.5 pA @10, 0.8 pA @1k
    return np.interp(np.log10(fr), [1, 3, 5], [2.5e-12, 0.8e-12, 0.8e-12])
NG_iv = 1 + D['Rf'] / Rs_nom
iv = np.sqrt((en2210(f) * NG_iv) ** 2 + kT4 * D['Rf'] + kT4 / Rs_nom * D['Rf'] ** 2 + (0.4e-12 * D['Rf']) ** 2)
leg_res = math.sqrt(4 * kT4 * 2000.0)  # four 2 kOhm resistors of a unity-gain difference amplifier -> 2*sqrt(4kTR)
legamp = np.sqrt((en1622(f) * 2) ** 2 + 2 * (in1622(f) * 2000.0) ** 2)
unbal = np.sqrt(2 * iv ** 2 + leg_res ** 2 + legamp ** 2)
bal = np.sqrt((2 * math.sqrt(2) * iv) ** 2 / 2 * 2 + 2 * (leg_res ** 2 + legamp ** 2))  # I/V noise correlated in both legs
def vint(nd, weighted=True):
    w = aweight(f) if weighted else np.ones_like(f)
    return math.sqrt(np.trapezoid((nd * w) ** 2, f))
nA_u = vint(unbal); nA_b = vint(bal); nU_u = vint(unbal, False)
p('I/V output noise at 1 kHz: %.2f nV/rtHz (OPA2210 2.2 nV/rtHz x NG %.3f, Rf %.0f ohm thermal, DAC 806 ohm thermal x Rf) [DS-typ/CALC]'
  % (iv[np.searchsorted(f, 1e3)] * 1e9, NG_iv, D['Rf']))
p('Leg network (4 x 2 kOhm) %.1f nV/rtHz; OPA1622 en x 2 and in x R2: %.1f nV/rtHz at 1 kHz [CALC/DS-typ]' % (leg_res * 1e9, legamp[np.searchsorted(f, 1e3)] * 1e9))
p('Unbalanced leg: %.1f nV/rtHz at 1 kHz; A-weighted 20 Hz-20 kHz %.2f uVrms; unweighted %.2f uVrms [CALC]' % (unbal[np.searchsorted(f, 1e3)] * 1e9, nA_u * 1e6, nU_u * 1e6))
p('Balanced (I/V noise correlated in both legs): %.1f nV/rtHz at 1 kHz; A-weighted %.2f uVrms [CALC]' % (bal[np.searchsorted(f, 1e3)] * 1e9, nA_b * 1e6))
DNR = 127.0  # [DS-typ] ESS p.31 DNR differential current mode, A-weighted
for name, sig, n, trim_nom, trim_worst in [('unbalanced 3.5 mm', 1.55, nA_u, 20 * math.log10(Lcal / L_nom), 20 * math.log10(Lcal / L_hi)),
                                            ('balanced 4.4 mm', 3.10, nA_b, 20 * math.log10(Lcal / L_nom), 20 * math.log10(Lcal / L_hi))]:
    dr_an = 20 * math.log10(sig / n)
    for tn, tv in [('nominal trim', trim_nom), ('highest-gain unit', trim_worst)]:
        dr_dac = DNR + tv
        dr = -10 * math.log10(10 ** (-dr_an / 10) + 10 ** (-dr_dac / 10))
        p('  DR %s (%s): analog %.1f dB(A), DAC %.1f dB(A) after %.2f dB trim -> %.1f dB(A) typical (target >= 115, min 112) [CALC from DS-typ]'
          % (name, tn, dr_an, dr_dac, tv, dr))
p('  (the DAC DNR spec already contains its output-resistor noise; adding the 806 ohm term again makes these figures conservative)')

# ---------------------------------------------------------------- 7 frequency response
p(); p('=' * 100); p('7. FREQUENCY RESPONSE'); p('=' * 100)
def resp(fr, cf=D['Cf'], rf=D['Rf'], ct=D['Ct']):
    h_iv = 1 / (1 + 1j * 2 * math.pi * fr * rf * cf)
    s = 1j * 2 * math.pi * fr
    # T network transfer (source -> op-amp inverting input current), normalised
    zt = D['R1a'] + D['R1b'] + s * ct * D['R1a'] * D['R1b']
    h_t = (D['R1a'] + D['R1b']) / zt
    h_lead = 1 / (1 + s * D['R2'] * D['Clead'])
    return h_iv * h_t * h_lead
for cf_s, ct_s in [(1.0, 1.0), (1.05, 1.05), (0.95, 0.95)]:
    r20 = 20 * math.log10(abs(resp(20e3, D['Cf'] * cf_s, ct=D['Ct'] * ct_s)))
    r40 = 20 * math.log10(abs(resp(40e3, D['Cf'] * cf_s, ct=D['Ct'] * ct_s)))
    p('Analog response (C x %.2f): %+.3f dB at 20 kHz, %+.3f dB at 40 kHz [CALC]; I/V pole %.0f kHz, T pole %.0f kHz'
      % (cf_s, r20, r40, 1 / (2 * math.pi * D['Rf'] * D['Cf'] * cf_s) / 1e3, (D['R1a'] + D['R1b']) / (2 * math.pi * D['Ct'] * ct_s * D['R1a'] * D['R1b']) / 1e3))
p('DAC digital filter (fast roll-off): passband +-0.003 dB to 0.454 fs = 20.02 kHz at 44.1 kHz [DS ESS p.31] -> total 20 Hz-20 kHz within +0.003/-0.09 dB (req +0.1/-0.3 dB) [CALC]')
p('Load/output-impedance divider is frequency-flat (0.22 ohm into 16 ohm = -0.12 dB level, calibrated at the jack) [CALC]')

# ---------------------------------------------------------------- 8 crosstalk
p(); p('=' * 100); p('8. CROSSTALK'); p('=' * 100)
for Rg in (2e-3, 5.7e-3):
    p('Unbalanced shared return R_gnd %.1f mOhm into 32 ohm: %.1f dB (req <= -75 dB at the jack pins) [CALC]' % (Rg * 1e3, 20 * math.log10(Rg / 32)))
Crel = 0.3e-12  # [layout rule] switch-to-switch coupling: K601-K604 are separate DIP6 packages (no pole-to-pole capacitance inside a package)
Zleg1k = Zcl + 0.05 + 0.081
xt_rel = 20 * math.log10(2 * math.pi * 1e3 * Crel * Zleg1k)
p('Output switches (4 x TLP3545A, separate packages): <= %.1f pF layout coupling into a closed-switch victim of %.3f ohm: %.0f dB at 1 kHz, %.0f dB at 20 kHz [CALC]'
  % (Crel * 1e12, Zleg1k, xt_rel, xt_rel + 20 * math.log10(20)))
p('Balanced (4.4 mm): no shared signal return; limited by layout coupling, OPA1622 channel separation 140 dB typ [DS-typ], OPA2210 dual, DAC (not specified by ESS)')
p('  -> -100 dB at 300 ohm needs <= 0.3 pF equivalent coupling from a 3.1 Vrms leg into a 300 ohm victim node at 20 kHz: layout rule (guarded, separated legs) [CALC]')

# ---------------------------------------------------------------- 9 THD budget (typical)
p(); p('=' * 100); p('9. THD+N BUDGET AT 1 kHz, 1.55 Vrms/leg, 300 ohm (typical only)'); p('=' * 100)
thd = [('DAC ES9018K2M THD+N, current mode, 0 dBFS [DS-typ ESS p.31]', -120.0),
       ('OPA2210 I/V (THD+N 0.000025 %% at 20 Vpp/600 ohm, G=+1) [DS-typ O2210]', -132.0),
       ('OPA1622 leg at noise gain 2 (TI -123 dB at 10 mW/128 ohm, G=1, +6 dB for NG 2) [DS-typ O1622]', -117.0),
       ('Noise 20 Hz-20 kHz unweighted relative to 1.55 Vrms [CALC]', 20 * math.log10(nU_u / 1.55))]
tot = -10 * math.log10(sum(10 ** (-v / 10) for _, v in [(a, -b) for a, b in thd]) if False else sum(10 ** (v / 10) for _, v in thd))
tot = 10 * math.log10(sum(10 ** (v / 10) for _, v in thd))
for n, v in thd:
    p('  %-100s %7.1f dB' % (n, v))
p('  => power sum %.1f dB typical (target <= -105 dB, min -100 dB); TLP3545A switches <= -170 dB at 300 ohm (r2_switch.txt), thin-film R and C0G C << -130 dB [CALC]' % tot)

# ---------------------------------------------------------------- 10 channel balance
p(); p('=' * 100); p('10. CHANNEL BALANCE'); p('=' * 100)
p('Rf 0.1 %% pair (%.3f dB) + DAC L/R Rs match (not specified by ESS; +-11 %% absolute) -> untrimmed balance not guaranteed;'
  ' per-channel trim at calibration to +-0.05 dB (req <= 0.3 dB) with the 32-bit master trim / MCU scaling [CALC/DS]' % (20 * math.log10(1.002)))

open(os.path.join(OUT, 'analog_budget.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
