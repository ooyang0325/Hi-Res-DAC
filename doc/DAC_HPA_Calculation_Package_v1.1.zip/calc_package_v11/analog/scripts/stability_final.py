"""Final stability verification of the v0.9 analog chain (chosen values).

Legs: T input network R1a 1.33 k + R1b 665 (Ct 1.8 nF to GND at the midpoint), same on the + input,
R2 = R4 = 2.00 k with Clead 10 pF across each (C401-C408), no output link/isolation resistor.
Corners: OPA1622 CAL model (fitted to Fig. 24) and PHYS model, GBW x0.8/1.0/1.25; Ct and Clead +-5 %/+-0.5 pF;
relay path (+ legs) and direct path (- legs); loads open/16/32/60/300/600 ohm, CL 0..1 nF to GND, 3 m cable + 1 nF;
stress 2 nF (1 nF across a balanced pair, differential mode).
Reports worst phase margin, minimum gain margin, sensitivity peak Ms = max|1/(1+T)| (closed-loop error peaking)
and the closed-loop response peaking relative to the ideal filter response.
I/V: see stability_iv.txt (1080 corners, OPA2210 model family).  Output: ../out/stability_final.txt"""
import os, sys, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA1622v

OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
FR = np.logspace(3, 8.7, 900)


def build(load, CL, op, relay, cable, Ct=1.8e-9, Cl=10e-12, R1a=1330.0, R1b=665.0, R2=2000.0, drive=False):
    c = Circuit()
    if drive:
        c.R('sA', 'dA', 20.0); c.R('sB', 'dB', 20.0); c.V('VA', 'dA', '0', -0.5); c.V('VB', 'dB', '0', 0.5)
    else:
        c.R('sA', '0', 20.0); c.R('sB', '0', 20.0)
    c.R('sA', 'mA', R1a); c.R('mA', 'N', R1b); c.C('mA', '0', Ct)
    c.R('sB', 'mB', R1a); c.R('mB', 'P', R1b); c.C('mB', '0', Ct)
    c.R('N', 'OUT', R2); c.C('N', 'OUT', Cl); c.R('P', '0', R2); c.C('P', '0', Cl)
    c.OPAMP('U', 'P', 'N', 'OUT', op.A, op.Zo)
    c.C('P', 'N', op.CIN_DIFF); c.C('P', '0', op.CIN_CM + 1.5e-12); c.C('N', '0', op.CIN_CM + 1.5e-12)
    c.L('OUT', 'LEG', 5e-9); c.R('LEG', '0', 15e3); c.R('LEG', '0', 100e3)
    if relay:
        c.R('LEG', 'k', 0.1); c.L('k', 'JACK', 10e-9)
    else:
        c.L('LEG', 'JACK', 5e-9)
    c.C('JACK', '0', 12e-12)
    if load != 'open':
        if CL: c.C('JACK', '0', CL)
        if cable:
            prev = 'JACK'
            for i in range(3):
                c.R(prev, 'cr%d' % i, 0.2); c.L('cr%d' % i, 'cn%d' % i, 0.6e-6); c.C('cn%d' % i, '0', 100e-12)
                prev = 'cn%d' % i
            c.R(prev, 'hp', load); c.L('hp', '0', 30e-6)
        else:
            c.R('JACK', '0', load)
    return c


def ideal_response(f, Ct=1.8e-9, R1a=1330.0, R1b=665.0, R2=2000.0, Cl=10e-12):
    s = 2j * np.pi * f
    return (R1a + R1b) / (R1a + R1b + s * Ct * R1a * R1b) / (1 + s * R2 * Cl) * R2 / (R1a + R1b)


MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]
LOADS = [('open', 0, False)] + [(r, c, False) for r in (16, 32, 60, 300, 600) for c in (0, 100e-12, 220e-12, 470e-12, 1e-9)] \
        + [(r, 1e-9, True) for r in (16, 32, 300, 600)] + [(r, 2e-12, True) for r in (32, 300)]
STRESS = [(r, 2e-9, False) for r in (16, 32, 300, 600)]
lines = ['Final leg network: T 1.33k + 665 ohm, Ct 1.8 nF, R2 = R4 = 2.00 k, Clead 10 pF; typical OPA1622 models', '']
lines.append(' load  CL(pF) cable | worst PM (deg) | min GM (dB) | max Ms (dB) | peaking vs ideal (dB) @ MHz  [CAL x1, relay path]')
summary = dict(pm=999, gm=999, ms=0, pm2=999)
for (load, CL, cable) in LOADS + STRESS:
    pmw, gmw, msw = 999, 999, 0
    for (mk, gs), relay, (dct, dcl) in itertools.product(MODELS, (True, False), [(1, 0), (0.95, -0.5e-12), (1.05, 0.5e-12)]):
        op = OPA1622v(mk, gs)
        m = margins(FR, build(load, CL, op, relay, cable, Ct=1.8e-9 * dct, Cl=10e-12 + dcl).loop_gain(FR, 'U'))
        pm = m['pm_worst'] if m['pm_worst'] is not None else -99
        pmw = min(pmw, pm); msw = max(msw, 1 / m['vector_margin'])
        if m['gm'] is not None: gmw = min(gmw, m['gm'])
    op = OPA1622v('CAL', 1.0)
    v = build(load, CL, op, True, cable, drive=True).solve(FR)
    h = np.abs(v('JACK')) / np.abs(ideal_response(FR))
    h0 = h[np.searchsorted(FR, 1e3)]
    sel = FR < 20e6
    pk = 20 * np.log10(np.max(h[sel]) / h0); fpk = FR[sel][np.argmax(h[sel])]
    lines.append(' %5s %6.0f %5s | %8.1f | %8.1f | %8.2f | %+6.2f @ %.2f' % (load, CL * 1e12, cable, pmw, gmw, 20 * np.log10(msw), pk, fpk / 1e6))
    if CL <= 1e-9:
        summary['pm'] = min(summary['pm'], pmw); summary['gm'] = min(summary['gm'], gmw); summary['ms'] = max(summary['ms'], msw)
    else:
        summary['pm2'] = min(summary['pm2'], pmw)
lines.append('')
lines.append('SUMMARY legs: worst PM %.1f deg, min GM %.1f dB, max Ms %.2f dB for 0..1 nF + cable; worst PM %.1f deg at the 2 nF stress'
             % (summary['pm'], summary['gm'], 20 * np.log10(summary['ms']), summary['pm2']))
open(os.path.join(OUT, 'stability_final.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
