"""Round-2 (R8 follow-up) shared constants and the per-rail current model of the analog stream.

Labels: [DS] datasheet min/max, [DS-typ] typical only, [CALC] computed, [ASSUMP] assumption, [PH] other stream,
[DEC] orchestrator decision file integration/decisions_r8b.md (D-1 ... D-18).
"""
import math
import numpy as np

# ------------------------------------------------------------------ rails (D-6, power CALC: 0.1 % single resistors)
VPOS = (3.789, 3.852, 3.915)          # V min / nom / max  [DEC D-6]
VNEG = (3.661, 3.721, 3.781)          # |V-| min / nom / max [DEC D-6]
RAIL_MIN = min(VPOS[0], VNEG[0])      # 3.661 V: sets the symmetrical swing
V3A = (3.234, 3.300, 3.366)           # LP5907 +-2 % [DS]
AVCC_DROP = 8.0e-3 * 2.2              # 8 mA nominal x R301/R302 2.2 ohm [DS-typ ESS p.28]

# ------------------------------------------------------------------ analog network (this stream, round 1, unchanged)
RF = 698.0                            # R423-R426
R1 = 1300.0 + 680.0                   # T network R1a + R1b (= R3a + R3b); round-2 retune to stocked 0.05 %/10 ppm E24 values (round 1: 1330 + 665)
R2 = R4 = 2000.0
G_LEG = R2 / R1                       # 1.0025
KV_HI = 0.50690                       # VREF/3V3A upper corner (0.1 %, 25 ppm x 25 K) [CALC analog_budget]
VREF_HI = KV_HI * V3A[2]              # 1.706 V
VFS = 1.55 * math.sqrt(2)             # calibrated 0 dBFS per leg, V pk [req. brief 4]

# ------------------------------------------------------------------ output switch TLP3545A(TP1,F) (D-1) [DS Toshiba 2020-03/2023-05]
RON25_MAX = 0.060                     # ohm, A connection, IF 5 mA, 25 C [DS]
RON_TYP = 0.035                       # [DS-typ]
RON_TC = 1.35                         # x at 60 C device temperature [DEC D-1 / ASSUMP protection]
RON_HOT = RON25_MAX * RON_TC          # 0.081 ohm
COFF_TYP = 640e-12                    # output capacitance, VOFF = 0 V, 1 MHz [DS-typ]; no max published
COFF_BOUND = 1.0e-9                   # bound used here [ASSUMP: 1.56 x typ; decreases with VOFF, Fig. 16.1.11]
CS_IO_TYP = 0.8e-12                   # input-to-output capacitance, all pins shorted [DS-typ]
CS_IO_BOUND = 2.0e-12                 # [ASSUMP 2.5 x typ; AQV251G states 1.5 pF max for the same structure]
TOFF_MAX = 0.5e-3; TON_MAX = 5.0e-3   # IF 5 mA, 25 C [DS]
RTH_SW = 1.0 / 7.0e-3                 # K/W: PO 700 mW derated 7.0 mW/K above 25 C -> Tj 125 C [DS-derived]

# ------------------------------------------------------------------ series path to the headphone
R_LINK = 0.050                        # R417-R420 0-ohm jumper <= 50 mOhm [DS UNI-ROYAL]
R_TRACE_SE, R_TRACE_BAL = 0.020, 0.020  # PCB [ASSUMP / layout rule]
R_CONTACT = 0.050                     # per jack contact [ASSUMP]
ZO_CL = 0.00033                       # OPA1622 closed loop at 1 kHz [CALC round 1]
RSER_SE = ZO_CL + R_LINK + RON_HOT + R_TRACE_SE + 2 * R_CONTACT        # tip + sleeve
RSER_BAL = 2 * ZO_CL + 2 * R_LINK + 2 * RON_HOT + R_TRACE_BAL + 2 * R_CONTACT

# ------------------------------------------------------------------ quiescent components (guaranteed 0-50 C = DS max -40..125 C)
IQ_1622 = 4.2e-3                      # per channel [DS SBOS727B 6.5]
IQ_2210 = 3.25e-3                     # per channel [DS SBOS924H 6.6]
I_TLV_P, I_TLV_N = 2.738e-3, 2.566e-3   # protection block 6, switch closed: conservative budget bound (protection's 06:43 loads +0.078/+0.086 mA on the R9 check 2.66/2.48 mA);
                                        # design 2.714/2.542 mA (final loads +0.054/+0.062 mA, protection 07:09 via power) lies inside it; released need 178.961 mA / +1.090 mA
                                        # is computed on this bound (orchestrator budget-basis decision 26 Sep 07:18; value restored by integration 10:35 on orchestrator approval,
                                        # after a 07:10 edit to the design values had left the released 06:52 outputs unreproducible).
                                        # Design-value derivation (F-1 loads): -U601/U602 + VTH dividers 31/30 uA; +U611/U612 8 x 100 uA; +8 x TLV3402 16 x 0.95 uA; +8 x 680 k timer R at VNEG 93.4 uA;
                                        #  +2 VNEG dividers 7.6 uA; the 3V3A dividers 7.2 uA are power's.  History: R9 17:18 2.51/2.65; R3 1.660/1.631
I_TLV_TRIP_P, I_TLV_TRIP_N = I_TLV_P + 79e-6, I_TLV_N + 79e-6   # tripped (H pulled to V- through R647 100 k: +79 uA [protection R2]); F-1 delta assumed unchanged (asked protection 06:37)
R_E3_TAP = 1.487e6 / 2                # R9 E-3: two 1.487 M dividers (487 k + 1.00 M) per LEG_xx, returns AC-grounded -> AC load per leg
I_CLAMP = 25e-6                       # DY-3 D413/D414 BAT54 reverse leakage at ~3.5 V: 2 uA at 25 V/25 C x2 per 10 K to 60 C, no voltage credit [ASSUMP]
I_RES = 0.22e-3                       # X-8 reservoir DCL bound, each rail: AVX TAJD227K010RNJ (VE; was KEMET T495) 0.01CV = 22 uA at 25 C x 10 at 85 C [DS-rule/ASSUMP]
I_CM = 14e-6                          # CM summing R653-R656 cross current, each rail [protection 5]
I_LM = 1.0e-3                         # LM27762 IQ [ASSUMP; 390 uA typ, no max]
I_PG = 5.55 / 100e3                   # PGOOD pull-up R505 100 k (PGOOD low = good) [CALC]
CP = 1.03                             # charge-pump input/output factor on I- [PH power]
I_TPS2596 = 266e-6                    # TPS259621 IQ (IN -> GND, not through the limit) [DS]
# DC-sense network on each LEG_xx (protection 6): 6.8 k series to a node with 5.1 k to 3V3A and 16.9 k to GND, 4.7 uF
RS_SENSE, RU_SENSE, RD_SENSE = 6.8e3, 5.1e3, 16.9e3
R_TH_SENSE = 1.0 / (1 / RS_SENSE + 1 / RU_SENSE + 1 / RD_SENSE)
A_SENSE = R_TH_SENSE / RU_SENSE       # 0.4874
G_SENSE = R_TH_SENSE / RS_SENSE       # 0.3655
TOL_SENSE = 1.002                     # 0.1 % resistors, worst direction [CALC]
# R10 F-1 (protection 06:20): leg-window RC taps R601-R604 / C601-C604 and U601/U602 REMOVED; per LEG_xx now
#   OR tap R926-R929 330 k 1 % -> C639-C642 1 nF C0G (2 x TLV1704 inputs) and LPW tap R930-R933 1.00 M 1 % -> C643-C646 3.3 nF C0G
#   (2 x TLV3402 inputs); no DC path (DC <= 43 nA bias).  AC load: the caps only raise |Z| below 20 kHz, so both taps are taken as
#   resistive to AC ground at their -1 % values and in phase with the leg (upper bound on the current) [protection F-1 / CALC].
R_TAP_OR, R_TAP_LPW = 330e3 * 0.99, 1.00e6 * 0.99
R_FILT = 1.0 / (1.0 / R_TAP_OR + 1.0 / R_TAP_LPW)   # 245.6 k per leg (was R601-R604 105 k to 2.2 uF, AC ground)

# ------------------------------------------------------------------ LM27762 headroom (power report 5.5, c04 section 6)
ENV_VIN = {('Default', 4.40): 4.310, ('High', 4.40): 4.202, ('Default', 4.60): 4.510, ('High', 4.60): 4.402}  # [PH power c04]
LDO_N_R = 0.45                        # negative LDO dropout slope (30 mV typ at 100 mA x 1.5) [PH/ASSUMP power]
LDO_P_R = 0.675
PGOOD_FRAC = 0.97                     # PGOOD threshold 95 % typ, no min/max -> 97 % used as the worst (earliest) trip [ASSUMP]
IOS_HIGH_MIN = 0.3904                 # TPS2596 High (R509 || R510 3.83 k) headline min [PH power c03]

TARGETS = [  # (jack, load ohm, balanced, High mW, Default mW)  [req. brief 4]
    ('3.5 mm', 32, False, 50, 38), ('4.4 mm', 60, True, 105, 17), ('4.4 mm', 120, True, 65, 35), ('4.4 mm', 300, True, 30, 30)]
LOADS = [('3.5 mm', 16, False), ('3.5 mm', 32, False), ('3.5 mm', 60, False), ('3.5 mm', 300, False),
         ('4.4 mm', 32, True), ('4.4 mm', 60, True), ('4.4 mm', 120, True), ('4.4 mm', 300, True), ('4.4 mm', 600, True)]


def rail_currents(v_leg, R, balanced, n=721, v3a=V3A[2], vref=VREF_HI, iq1622=IQ_1622, iq2210=IQ_2210,
                  i_tlv=(I_TLV_P, I_TLV_N)):
    """Instantaneous I+(theta), I-(theta) of the analog rails for a 1 kHz sine of v_leg pk per leg, both channels in phase.
    Legs: LP = +v s, LN = -v s (same for R).  I/V outputs: VP = VREF - d s, VN = VREF + d s with 2 G d = v.
    Every op-amp output current is taken from V+ when sourcing and from V- when sinking; quiescent flows V+ -> V-.
    At 1 kHz the DC-sense node (4.7 uF) is AC ground; the R10 F-1 OR/LPW taps are taken as R_FILT to AC ground.  [CALC]"""
    th = np.linspace(0, 2 * np.pi, n)
    s = np.sin(th)
    d = v_leg / (2 * G_LEG)
    ip = np.full(n, 4 * iq1622 + 4 * iq2210 + i_tlv[0] + I_CM + I_RES + I_CLAMP)
    im = np.full(n, 4 * iq1622 + 4 * iq2210 + i_tlv[1] + I_CM + I_RES + I_CLAMP)
    VP = vref - d * s; VN = vref + d * s
    rser = RSER_BAL if balanced else RSER_SE
    legs = {'P': (VP, VN, v_leg * s), 'N': (VN, VP, -v_leg * s)}   # (INN source, INP source, output)
    for ch in ('L', 'R'):
        for lg, (src_n, src_p, vo) in legs.items():
            v_inp = src_p * R4 / (R1 + R4)
            i_r2 = (vo - v_inp) / R2
            i_sense = (vo - A_SENSE * TOL_SENSE * v3a) / RS_SENSE
            i_filt = vo / R_FILT
            if balanced:
                i_load = (2 * v_leg * s) / (R + rser) * (1 if lg == 'P' else -1)
            else:
                i_load = vo / (R + rser) if lg == 'P' else 0.0 * s
            io = i_load + i_r2 + i_sense + i_filt + vo / R_E3_TAP   # + R9 E-3 divider taps (AC part; DC <= 2.7 uA is in block 6)
            ip += np.maximum(io, 0); im += np.maximum(-io, 0)
        for X, other in ((VP, VN), (VN, VP)):
            i_rf = (X - vref) / RF
            i_a = (X - other * R4 / (R1 + R4)) / R1        # into the INN of the leg fed from X
            i_b = X / (R1 + R4)                           # into the INP divider of the other leg
            io = i_rf + i_a + i_b
            ip += np.maximum(io, 0); im += np.maximum(-io, 0)
    return th, ip, im


def ana_input(ip, im):
    """5V_ANA current (through the TPS2596 limit) for rail currents ip, im [CALC]."""
    return ip + CP * im + I_LM + I_PG


def load_voltage(v_leg, R, balanced):
    rser = RSER_BAL if balanced else RSER_SE
    return (2 * v_leg if balanced else v_leg) * R / (R + rser)


def leg_for_power(P, R, balanced):
    rser = RSER_BAL if balanced else RSER_SE
    vl = math.sqrt(2 * P * R)
    return vl * (R + rser) / R / (2 if balanced else 1)
