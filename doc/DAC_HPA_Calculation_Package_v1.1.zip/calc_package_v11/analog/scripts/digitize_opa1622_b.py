import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '../..'))
"""Digitize further OPA1622 (SBOS727B) typical curves from the vector PDF:
Fig 34 IQ vs temperature (page idx 11, right-bottom), Fig 37 ISC vs temperature (p12 left-top),
Fig 38/39 output voltage vs output current (p12 right-top / left-bottom), Fig 40 Zo vs frequency (p12 right-bottom).
Gridline pixel positions were read with pdf_dump_region.py. Output merged into ../ds/opa1622_digitized.json."""
import json, math, pdfplumber
PDF = _PKG_ROOT + '/external/input/opa1622.pdf'
pdf = pdfplumber.open(PDF)
def lin(v, p0, v0, p1, v1): return v0 + (v - p0) * (v1 - v0) / (p1 - p0)
def logm(v, p0, v0, p1, v1): return 10 ** (math.log10(v0) + (v - p0) * (math.log10(v1) - math.log10(v0)) / (p1 - p0))
def grab(page, box):
    x0, x1, y0, y1 = box; res = {}
    for c in pdf.pages[page].curves:
        if (c.get('linewidth') or 0) < 0.5: continue
        pts = [q for q in c['pts'] if x0 - 1 <= q[0] <= x1 + 1 and y0 - 1 <= q[1] <= y1 + 1]
        if len(pts) >= 2 and len(pts) >= 0.8 * len(c['pts']):
            res.setdefault(str(c.get('stroking_color')), []).extend(pts)
    return res
D = json.load(open(_PKG_ROOT + '/analog/ds/opa1622_digitized.json'))
# Fig 40 Zo: x 355.9 ->1 Hz, 538.7 -> 1e8 (log); y 422.1 -> 1 ohm, 297.7 -> 100 ohm (log)
g = grab(12, (355.9, 538.7, 297.7, 422.1))
D['fig40_Zo'] = sorted((logm(x, 355.9, 1, 538.7, 1e8), logm(y, 422.1, 1, 297.7, 100)) for col in g for (x, y) in g[col])
# Fig 39 negative VO vs IO: x 103.7 -> 0 mA, 285.7 -> 200 mA; y 296.8 -> 0 V, 420.6 -> -18 V (lin); colors per temperature
g = grab(12, (103.7, 285.7, 296.8, 420.6))
D['fig39'] = {col: sorted((lin(x, 103.7, 0, 285.7, 200), lin(y, 296.8, 0, 420.6, -18)) for (x, y) in pts) for col, pts in g.items()}
# Fig 38 positive VO vs IO: find gridlines: x 355.9 -> 0 mA, 538.7 -> 200 mA; y 234.6 -> 0 V, 110.7 -> 18 V
g = grab(12, (355.5, 539.0, 110.0, 235.0))
D['fig38'] = {col: sorted((lin(x, 355.9, 0, 538.7, 200), lin(y, 234.6, 0, 110.7, 18)) for (x, y) in pts) for col, pts in g.items()}
# Fig 37 ISC vs temperature: x 98+? ; use tick labels: -75 at 101.1? derive from words: '-75' x0=98.0 (text), '150' x0=281.5
# gridlines (from dump): need exact; approximate with label centers: -75 -> 103.7, 150 -> 285.7 ; y: 60 -> 235.8, 200 -> 110.7
g = grab(12, (103.0, 286.0, 105.0, 237.0))
D['fig37'] = {col: sorted((lin(x, 103.7, -75, 285.7, 150), lin(y, 235.8, 60, 110.7, 200)) for (x, y) in pts) for col, pts in g.items()}
# Fig 34 IQ vs temperature (p11 right-bottom): x -75 -> 355.9?, 150 -> 538.7 ; y 0 mA -> 421.0, 5 mA -> 296.8
g = grab(11, (355.5, 539.0, 296.0, 422.0))
D['fig34'] = {col: sorted((lin(x, 355.9, -75, 538.7, 150), lin(y, 421.0, 0, 296.8, 5)) for (x, y) in pts) for col, pts in g.items()}
json.dump(D, open(_PKG_ROOT + '/analog/ds/opa1622_digitized.json', 'w'), indent=1)
def show(name, data, xs):
    for x in xs:
        for (xa, ya), (xb, yb) in zip(data, data[1:]):
            if xa <= x <= xb and xb > xa:
                print('  %s x=%g -> %.3f' % (name, x, ya + (yb - ya) * (x - xa) / (xb - xa))); break
print('Fig40 Zo points', len(D['fig40_Zo']))
show('Zo(ohm)', D['fig40_Zo'], [10, 1e3, 1e4, 1e5, 1e6, 2e6, 4e6, 7.6e6, 1e7, 2e7, 5e7, 1e8])
for k in ['fig38', 'fig39', 'fig37', 'fig34']:
    for col, d in D[k].items():
        print(k, col, 'n=%d' % len(d), 'x %.1f..%.1f' % (d[0][0], d[-1][0]))
        show(k, d, {'fig38': [0, 20, 40, 60, 80, 100, 120, 140], 'fig39': [0, 20, 40, 60, 80, 100, 120, 140],
                    'fig37': [-25, 0, 25, 50, 85, 125], 'fig34': [-40, 0, 25, 50, 85, 125]}[k])
