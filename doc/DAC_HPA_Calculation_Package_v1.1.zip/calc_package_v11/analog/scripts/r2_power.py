"""Round 2: analog quiescent (TLV1704, real DC-sense load, CM summing), Default current-limit need, power tables
(Default at IOS min 175/180/185/190 mA, High at 390 mA), guaranteed swing floor with the final rails (D-6),
LM27762 peak-current headroom per rated target vs the power stream's envelopes (report 5.5 / c04 section 6),
and the firmware VBUS-dependent ceiling question.

Model (r2_common.rail_currents): instantaneous rail currents over a 1 kHz cycle, both channels in phase, every op-amp
output current taken from the rail it flows through, quiescent V+ -> V-, the I/V -> leg network currents, the leg
feedback, DC-sense and detector-filter currents, the load through the output switch path.
Rating (brief 4): 1 kHz, both channels, 1 % THD+N or calibrated 0 dBFS (1.55 Vrms/leg); clean swing
(|rail| - 1.3 V)/(1 + 8 ohm/R_leg) [DS-typ model, OPA1622 Table 2 + Figs 38/39]; a mode is 'current-limited' when the
instantaneous 5V_ANA peak reaches the TPS2596 IOS minimum.  Outputs: ../out/r2_power.txt, ../out/power_table.csv,
../out/headroom_table.csv"""
import os, sys, csv, math
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from r2_common import *

OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
L = []
def p(s=''):
    L.append(s)

# ================================================================== 1 quiescent
p('=' * 110); p('1. ANALOG QUIESCENT ON VPOS / VNEG AND AT 5V_ANA (switch closed, no signal) [CALC]'); p('=' * 110)
th, ip0, im0 = rail_currents(0.0, 32, False)
Ip, Im = ip0[0], im0[0]
q_in = ana_input(Ip, Im)
p('Components (guaranteed 0-50 C = datasheet maxima over -40..125 C):')
p('  OPA1622 4 ch x 4.2 mA [DS]          = %6.3f mA  V+ -> V-' % (4 * IQ_1622 * 1e3))
p('  OPA2210 4 ch x 3.25 mA [DS]         = %6.3f mA  V+ -> V-' % (4 * IQ_2210 * 1e3))
p('  Comparator block 6 (U601-U603+U606) = I+ %.3f / I- %.3f mA [protection R3 09:09, replaces D-9 1.26/1.25 mA]' % (I_TLV_P * 1e3, I_TLV_N * 1e3))
p('  X-8 reservoirs C442/C443 DCL       <= %.3f mA each rail [AVX TAJD227K010RNJ (VE, was KEMET T495) 0.01CV at 25 C x 10 at 85 C, DS-rule/ASSUMP; the polymer T520 would be 1.39 mA]' % (I_RES * 1e3))
p('  DY-3 clamps D413/D414 leakage      <= %.3f mA each rail [BAT54 2 uA at 25 V/25 C, x2 per 10 K to 60 C, ASSUMP]' % (I_CLAMP * 1e3))
i_ivleg = 4 * VREF_HI * ((1 - R4 / (R1 + R4)) / R1 + 1 / (R1 + R4))
p('  I/V outputs -> leg networks (V+)    = %6.3f mA  (4 x VREF %.3f V x [(1 - R4/(R3+R4))/R1 + 1/(R3+R4)])' % (i_ivleg * 1e3, VREF_HI))
i_legsink = 4 * VREF_HI * R4 / (R1 + R4) / R2
p('  OPA1622 outputs sink the R2 current = %6.3f mA  (V-)' % (i_legsink * 1e3))
i_sense1 = A_SENSE * TOL_SENSE * V3A[2] / RS_SENSE
p('  DC-sense networks (V-)              = %6.3f mA  = 4 x %.4f mA: node a x 3V3A (a = %.4f, 3V3A 3.366 V, 0.1 %% worst) through 6.8 k into a 0 V leg'
  % (4 * i_sense1 * 1e3, i_sense1 * 1e3, A_SENSE))
p('     (D-list estimate 0.24 mA per leg confirmed: %.4f mA nominal at 3.300 V, %.4f mA max)' % (A_SENSE * 3.3 / RS_SENSE * 1e3, i_sense1 * 1e3))
p('  CM summing R653-R656                <= %.3f mA each rail [protection 5]' % (I_CM * 1e3))
p('  => I+ = %.3f mA, I- = %.3f mA' % (Ip * 1e3, Im * 1e3))
p('  5V_ANA = I+ + %.2f x I- + LM27762 %.2f mA [ASSUMP] + PGOOD pull-up %.3f mA = %.2f mA  (guaranteed; round 2: 70.32 mA, round 1: 72.93 mA -> superseded)'
  % (CP, I_LM * 1e3, I_PG * 1e3, q_in * 1e3))
p('  TPS2596 IQ %.3f mA [DS] flows IN -> GND (not through its current limit): USB-budget item for the power stream' % (I_TPS2596 * 1e3))
# DAC in reset (RESETB low, AVCC up): programming mode (D-15) and every power-up until the ESS soft start has ended.
# Pins driven to ground inside the DAC -> each I/V output = VREF (1 + Rf/Rs), Rs 806 ohm -11 % (worst current) [DS-typ ESS p.31 model]
v_rst = VREF_HI * (1 + RF / (806 * 0.89))
i_pin = VREF_HI / (806 * 0.89)
ip_r = 4 * IQ_1622 + 4 * IQ_2210 + I_TLV_TRIP_P + I_CM + I_RES + I_CLAMP    # the CM window trips in reset -> H pulled low (+79 uA each rail)
im_r = 4 * IQ_1622 + 4 * IQ_2210 + I_TLV_TRIP_N + I_CM + I_RES + I_CLAMP
for _ in range(2):
    i_iv = i_pin + (v_rst - v_rst * R4 / (R1 + R4)) / R1 + v_rst / (R1 + R4)      # Rf (pin current) + INN leg + INP divider
    ip_r += 2 * i_iv                                                           # per channel pair, both channels
    vo = G_LEG * 0.0                                                           # legs: equal I/V outputs -> leg DC ~ 0
    i_leg = (vo - v_rst * R4 / (R1 + R4)) / R2 + (vo - A_SENSE * TOL_SENSE * V3A[2]) / RS_SENSE
    im_r += 2 * (-i_leg)
p('  DAC in reset (programming mode D-15 and each power-up until the soft start ends; switch open): I/V outputs %.3f V, pin current %.2f mA each ->'
  ' I+ %.2f mA, I- %.2f mA, 5V_ANA %.2f mA incl. the tripped comparator block (not a playback state; for the power stream\'s programming-mode and start-up budgets) [CALC]'
  % (v_rst, i_pin * 1e3, ip_r * 1e3, im_r * 1e3, ana_input(ip_r, im_r) * 1e3))
sets = {'A: DS max 25 C': (3.3e-3, 2.5e-3), 'C: 25 C max x DS-typ ratio at 50 C': (3.3e-3 * 2.843 / 2.638, 2.5e-3 * 1.08)}
for n, (a, b) in sets.items():
    _, i1, i2 = rail_currents(0.0, 32, False, iq1622=a, iq2210=b)
    p('  (reference) quiescent set %-36s: I+ %.2f, I- %.2f -> 5V_ANA %.2f mA' % (n, i1[0] * 1e3, i2[0] * 1e3, ana_input(i1[0], i2[0]) * 1e3))

# ================================================================== helpers
def peaks(v, R, bal):
    th, ip, im = rail_currents(v, R, bal)
    return ip.max(), im.max(), ana_input(ip, im).max()

def swing_typ(rail, R, bal):
    rl = R / 2 if bal else R
    return (rail - 1.3) / (1 + 8.0 / rl)

def feasible(v, R, bal, ios, vin=None, rneg=None):
    ipk, imk, ain = peaks(v, R, bal)
    rail_n, rail_p = VNEG[0], VPOS[0]
    if vin is not None:
        rail_n = min(VNEG[0], vin - imk * (rneg + LDO_N_R))
        rail_p = min(VPOS[0], vin - ipk * LDO_P_R)
    lims = []
    if v > VFS + 1e-12: lims.append('full scale')
    if v > swing_typ(min(rail_n, rail_p), R, bal): lims.append('swing' if rail_n >= VNEG[0] - 1e-9 else 'swing (V- sag)')
    if ain > ios: lims.append('current limit')
    return (len(lims) == 0), lims, (ipk, imk, ain, rail_n)

def rate(R, bal, ios, vin=None, rneg=None):
    lo, hi = 0.0, VFS
    ok, _, _ = feasible(hi, R, bal, ios, vin, rneg)
    if ok:
        v = hi; lim = 'full scale'
    else:
        for _ in range(40):
            mid = 0.5 * (lo + hi)
            if feasible(mid, R, bal, ios, vin, rneg)[0]: lo = mid
            else: hi = mid
        v = lo
        lim = '/'.join(feasible(hi * 1.0005, R, bal, ios, vin, rneg)[1]) or 'full scale'
    vl = load_voltage(v, R, bal)
    ipk, imk, ain = peaks(v, R, bal)
    return vl ** 2 / (2 * R), lim, v, ipk, imk, ain

# ================================================================== 2 Default current-limit need
p(); p('=' * 110); p('2. DEFAULT CURRENT-LIMIT MINIMUM NEEDED FOR EACH DEFAULT TARGET (instantaneous 5V_ANA peak at the target) [CALC]'); p('=' * 110)
need_rows = []
for jack, R, bal, ph, pd in TARGETS:
    v = leg_for_power(pd * 1e-3, R, bal)
    ipk, imk, ain = peaks(v, R, bal)
    need_rows.append((jack, R, pd, v, ipk, imk, ain))
    p('  %s %3d ohm %3d mW: leg %.3f V pk, load %.1f mA pk -> I+ pk %.1f, I- pk %.1f, 5V_ANA pk %.1f mA'
      % (jack, R, pd, v, load_voltage(v, R, bal) / R * 1e3, ipk * 1e3, imk * 1e3, ain * 1e3))
need = max(r[6] for r in need_rows)
p('  => Default IOS minimum needed = %.1f mA (%s %d ohm); round 2: 175.6 mA, round 1: 174.2 mA -> superseded' %
  (need * 1e3, max(need_rows, key=lambda r: r[6])[0], max(need_rows, key=lambda r: r[6])[1]))
p('  Sensitivity: +1 mA on both rails -> +%.2f mA at 5V_ANA -> 3.5 mm 32 ohm Default target needs +%.2f mA of IOS' % (1 + CP, 1 + CP))
p('  Power lookup (headline IOS min; + ANA_SENSE 0.038 mA on 5V_ANA is power\'s, 100 k/47 k after VE): R509 4.75 k 180.1 mA -> %+.2f mA; 4.78 k 179.0 -> %+.2f; 4.81 k 177.9 -> %+.2f; 4.87 k 175.9 -> %+.2f mA'
  % ((0.1801 - need - 38e-6) * 1e3, (0.1790 - need - 38e-6) * 1e3, (0.1779 - need - 38e-6) * 1e3, (0.1759 - need - 38e-6) * 1e3))

# ================================================================== 3 power tables
p(); p('=' * 110); p('3. POWER TABLES (both channels, 1 kHz; series R %.3f ohm SE / %.3f ohm balanced incl. TLP3545A %.3f ohm hot) [CALC]'
                   % (RSER_SE, RSER_BAL, RON_HOT)); p('=' * 110)
IOS_DEF = [0.175, 0.180, 0.185, 0.190]
CASES = [('VBUS 4.60 V (design corner), R_NEG 3.5 ohm', 4.60, 3.5), ('VBUS 4.40 V, R_NEG 3.5 ohm', 4.40, 3.5)]
rows = []
for cname, vb, rneg in CASES:
    p(''); p('%s:  (V- sag model: |V-| = min(%.3f, VIN - I-pk x (R_NEG + %.2f)), VIN from power c04)' % (cname, VNEG[0], LDO_N_R))
    hdr = '  %-7s %4s | %-30s' % ('jack', 'load', 'High (IOS 390 mA)') + ''.join(' | %-26s' % ('Default IOS %.0f mA' % (i * 1e3)) for i in IOS_DEF) + ' | target H/D'
    p(hdr)
    for jack, R, bal in LOADS:
        Ph, limh, vh, iph, imh, ainh = rate(R, bal, IOS_HIGH_MIN, ENV_VIN[('High', vb)], rneg)
        rec = dict(case=cname, jack=jack, load_ohm=R, high_mW=round(Ph * 1e3, 1), high_limit=limh, high_Ipos_pk_mA=round(iph * 1e3, 1),
                   high_Ineg_pk_mA=round(imh * 1e3, 1), high_5VANA_pk_mA=round(ainh * 1e3, 1))
        cells = ['%6.1f mW (%s)' % (Ph * 1e3, limh)]
        for ios in IOS_DEF:
            Pd, limd, vd, ipd, imd, aind = rate(R, bal, ios, ENV_VIN[('Default', vb)], rneg)
            rec['default_%.0f_mW' % (ios * 1e3)] = round(Pd * 1e3, 1); rec['default_%.0f_limit' % (ios * 1e3)] = limd
            cells.append('%6.1f mW (%s)' % (Pd * 1e3, limd))
        t = [x for x in TARGETS if x[0] == jack and x[1] == R]
        rec['target_high_mW'] = t[0][3] if t else ''; rec['target_default_mW'] = t[0][4] if t else ''
        rows.append(rec)
        p('  %-7s %4d | %-30s' % (jack, R, cells[0]) + ''.join(' | %-26s' % c for c in cells[1:]) + ' | %s' % (('%d/%d' % (t[0][3], t[0][4])) if t else '-'))
with open(os.path.join(OUT, 'power_table.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
p('')
p('Pass/fail of the rated targets (design corner, R_NEG 3.5 ohm):')
for jack, R, bal, ph, pd in TARGETS:
    r = [x for x in rows if x['case'].startswith('VBUS 4.60') and x['jack'] == jack and x['load_ohm'] == R][0]
    s = '  %s %3d ohm: High %.1f mW vs %d -> %s; Default ' % (jack, R, r['high_mW'], ph, 'PASS' if r['high_mW'] >= ph else 'FAIL')
    s += ', '.join('%.0f mA %.1f mW %s' % (i * 1e3, r['default_%.0f_mW' % (i * 1e3)], 'PASS' if r['default_%.0f_mW' % (i * 1e3)] >= pd else 'FAIL') for i in IOS_DEF)
    p(s + ' (target %d mW)' % pd)

# ================================================================== 4 guaranteed swing floor
p(); p('=' * 110); p('4. GUARANTEED SWING FLOOR (OPA1622 AOL test ranges only: linear within 2 V of the rails at 32 ohm, 1.5 V at 600 ohm) [CALC]'); p('=' * 110)
def guaranteed(R, bal, rail=RAIL_MIN):
    rl = R / 2 if bal else R
    def hr(i):
        return 1.5 if i <= 27.5e-3 else (2.0 if i >= 94e-3 else 1.5 + 0.5 * (i - 27.5e-3) / (94e-3 - 27.5e-3))
    v = rail - 1.5
    for _ in range(60):
        v = rail - hr(v / rl)
    v = min(v, VFS)
    vl = load_voltage(v, R, bal)
    return vl ** 2 / (2 * R), v
for jack, R, bal, ph, pd in TARGETS:
    g, v = guaranteed(R, bal)
    need_rail = None
    for rail in np.arange(3.40, 4.2, 0.001):
        if guaranteed(R, bal, rail)[0] * 1e3 >= ph:
            need_rail = rail; break
    p('  %s %3d ohm: floor %.1f mW (leg %.3f V pk) vs High target %d mW -> %s; |rail|min needed %.3f V (have %.3f V)'
      % (jack, R, g * 1e3, v, ph, 'PASS' if g * 1e3 >= ph else 'NOT GUARANTEED', need_rail, RAIL_MIN))
p('  -> the round-1 open item O2 (4.4 mm 300 ohm floor 29.8 mW, needed |V-|min >= 3.625 V) is closed by D-6 (|V-|min 3.661 V).')

# ================================================================== 5 headroom per rated target
p(); p('=' * 110); p('5. LM27762 PEAK-CURRENT HEADROOM PER RATED TARGET (power 5.5 envelopes; R_NEG typical only) [CALC]'); p('=' * 110)
p('Envelope (power): I- pk <= (VIN - |V-|max %.3f V)/(R_NEG + %.2f ohm) (negative LDO stays in regulation); I+ pk <= (VIN - V+max)/%.3f ohm.' % (VNEG[2], LDO_N_R, LDO_P_R))
p('PGOOD-safe (this stream): |V-| stays >= %.0f %% of the %.3f V set point, i.e. I- pk <= (VIN - %.3f)/(R_NEG + %.2f)  (PGOOD 95 %% typ, no min/max [ASSUMP 97 %%]).'
  % (PGOOD_FRAC * 100, VNEG[2], PGOOD_FRAC * VNEG[2], LDO_N_R))
p('No-clip (rating): sagged |V-| = VIN - I- pk (R_NEG + %.2f) >= leg pk + 1.3 V (typ swing model).' % LDO_N_R)
hrows = []
p('  %-6s %-7s %4s %4s | %6s %6s %6s %6s | %-24s | %-24s | %s' % ('mode', 'jack', 'ohm', 'mW', 'leg pk', 'I+ pk', 'I- pk', '5VANA', 'VBUS 4.40: I- env 2.5/3.5/4.5', 'VBUS 4.60: I- env 2.5/3.5/4.5', 'R_NEG max: regulation / PGOOD-safe / no-clip at 4.40 | 4.60 V'))
for mode in ('High', 'Default'):
    for jack, R, bal, ph, pd in TARGETS:
        P = (ph if mode == 'High' else pd) * 1e-3
        v = leg_for_power(P, R, bal)
        ipk, imk, ain = peaks(v, R, bal)
        cells = []; rmax = []
        for vb in (4.40, 4.60):
            vin = ENV_VIN[(mode, vb)]
            env = [(vin - VNEG[2]) / (rn + LDO_N_R) for rn in (2.5, 3.5, 4.5)]
            cells.append('/'.join('%3.0f%s' % (e * 1e3, '' if imk <= e else '!') for e in env))
            r_reg = (vin - VNEG[2]) / imk - LDO_N_R
            r_pg = (vin - PGOOD_FRAC * VNEG[2]) / imk - LDO_N_R
            r_clip = (vin - (v + 1.3)) / imk - LDO_N_R
            rmax.append('%.2f / %.2f / %.2f' % (r_reg, r_pg, r_clip))
            ipos_env = (vin - VPOS[2]) / LDO_P_R
            hrows.append(dict(mode=mode, jack=jack, load_ohm=R, target_mW=P * 1e3, leg_pk_V=round(v, 3), Ipos_pk_mA=round(ipk * 1e3, 1),
                              Ineg_pk_mA=round(imk * 1e3, 1), ana_pk_mA=round(ain * 1e3, 1), VBUS=vb, VIN_LM=vin,
                              Ineg_env_2p5=round(env[0] * 1e3, 0), Ineg_env_3p5=round(env[1] * 1e3, 0), Ineg_env_4p5=round(env[2] * 1e3, 0),
                              Ipos_env=round(ipos_env * 1e3, 0), RNEG_max_regulation=round(r_reg, 2), RNEG_max_PGOOD_safe=round(r_pg, 2),
                              RNEG_max_no_clip=round(r_clip, 2)))
        p('  %-6s %-7s %4d %4.0f | %6.3f %6.1f %6.1f %6.1f | %-24s | %-24s | %s | %s'
          % (mode, jack, R, P * 1e3, v, ipk * 1e3, imk * 1e3, ain * 1e3, cells[0], cells[1], rmax[0], rmax[1]))
p('  ("!" = the peak I- exceeds that envelope.  I+ pk is far inside the positive envelope in every case: >= %.0f mA available.)'
  % (min((ENV_VIN[k] - VPOS[2]) / LDO_P_R for k in ENV_VIN) * 1e3))
with open(os.path.join(OUT, 'headroom_table.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(hrows[0].keys())); w.writeheader(); w.writerows(hrows)
# TPS2596 update sensitivity on VIN (power c04 used the TPS2553 path at 165 mA max)
dvin = (0.2208 - 0.165) * (0.131 + 0.050 + 0.010) - 0.165 * (0.135 - 0.131)
p('  Sensitivity: with the TPS2596 (Default IOS max 220.8 mA, Ron 0.131 ohm) the Default VIN falls by ~%.0f mV -> Default envelopes -%.0f/-%.0f/-%.0f mA (power stream to reissue 5.5).'
  % (dvin * 1e3, dvin / 2.95 * 1e3, dvin / 3.95 * 1e3, dvin / 4.95 * 1e3))

# ================================================================== 6 VBUS-dependent ceiling
p(); p('=' * 110); p('6. FIRMWARE VBUS-DEPENDENT CEILING (High mode) [CALC]'); p('=' * 110)
p('A load-independent level ceiling that keeps 3.5 mm 32 ohm inside an envelope also lowers every other load.  Level (dB re calibrated')
p('full scale) at which the worst rated High load reaches the envelope, and what the same ceiling leaves for 4.4 mm 300 ohm (target 30 mW):')
for vb in (4.40, 4.45, 4.50, 4.55, 4.60):
    vin = ENV_VIN[('High', 4.40)] + (vb - 4.40) * (ENV_VIN[('High', 4.60)] - ENV_VIN[('High', 4.40)]) / 0.20
    out = []
    for crit, vset in (('regulation', VNEG[2]), ('PGOOD-safe', PGOOD_FRAC * VNEG[2])):
        for rn in (2.5, 3.5):
            env = (vin - vset) / (rn + LDO_N_R)
            worst_db = 0.0
            for jack, R, bal, ph, pd in TARGETS[:2]:
                lo, hi = 0.0, VFS
                if peaks(VFS, R, bal)[1] <= env:
                    continue
                for _ in range(40):
                    mid = 0.5 * (lo + hi)
                    if peaks(mid, R, bal)[1] <= env: lo = mid
                    else: hi = mid
                worst_db = min(worst_db, 20 * math.log10(lo / VFS))
            p300 = load_voltage(VFS * 10 ** (worst_db / 20), 300, True) ** 2 / 600
            out.append('%s R_NEG %.1f: %+5.1f dB (300 ohm %4.1f mW)' % (crit, rn, worst_db, p300 * 1e3))
    p('  VBUS %.2f V (VIN %.3f V): ' % (vb, vin) + '; '.join(out))
p('  -> a VBUS-dependent ceiling cannot be load-independent: below ~-0.3 dB it breaks the 4.4 mm 300 ohm target (needs %.3f V pk, %.2f dB re FS).'
  % (leg_for_power(0.030, 300, True), 20 * math.log10(leg_for_power(0.030, 300, True) / VFS)))

# ================================================================== 7 SPL
p(); p('=' * 110); p('7. SPL AT THE RATED POWER (maker sensitivity), design corner [CALC]'); p('=' * 110)
for name, R, sens in [('HIFIMAN Susvara', 60, 83.0), ('AKG K1000', 120, 74.0)]:
    r = [x for x in rows if x['case'].startswith('VBUS 4.60') and x['jack'] == '4.4 mm' and x['load_ohm'] == R][0]
    p('  %-16s %3d ohm %4.0f dB/mW: High %.1f mW = %.1f dB SPL; Default at 180 mA %.1f mW = %.1f dB SPL'
      % (name, R, sens, r['high_mW'], sens + 10 * math.log10(r['high_mW']), r['default_180_mW'], sens + 10 * math.log10(r['default_180_mW'])))

open(os.path.join(OUT, 'r2_power.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
