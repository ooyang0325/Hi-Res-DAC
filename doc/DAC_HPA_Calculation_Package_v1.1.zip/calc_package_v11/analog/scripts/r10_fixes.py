"""R10 (r10/decisions_r10.md): analog items
  F-5  leg peaks of the uncalibrated / calibrated unit (highest- and lowest-gain), swing limits, trim values and range,
       post-calibration drift of the calibrated full scale;
  F-2  inputs for the evidence-class walk: sensitivities that show which assumption each analog result rests on
       (Default need vs LM27762 IQ and CP factor, High floors vs R_NEG, 300 ohm full-scale margin vs 3V3A drift,
       offset G terms vs the ESS Rs tolerance, frequency response vs op-amp GBW).
Classes (F-2 rule): G = every input a datasheet limit or a G result; E = any assumption / typical / reconstructed model;
Q = rests on a measurement.  Output: ../out/r10_fixes.txt"""
import math, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from r2_common import (VPOS, VNEG, V3A, RF, R1, R2, rail_currents, TARGETS, leg_for_power, CP, I_LM, I_PG,
                       RSER_BAL, RSER_SE, LDO_N_R, ENV_VIN, I_TLV_P, I_TLV_N, R_FILT, R_TAP_OR, R_TAP_LPW)

OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
L = []
def p(s=''):
    L.append(s)

dT = 25.0
# ---------------------------------------------------------------- inputs (labels)
RS_NOM, RS_TOL = 806.0, 0.11          # ESS note *1 "806 ohm +-11 %", test conditions TA = 25 C, AVCC 3.3 V; no tempco [DS note, 25 C only]
K_FS = 0.924                          # ESS full-scale source 0.924 x AVCC p-p: TYP column only [DS-typ]
I_AVCC, R_AVCC = 8.0e-3, 2.2          # ESS AVCC 8 mA nominal used as max [ASSUMP]; R301/R302 2.2 ohm
RF_EPS = 0.001 + 25e-6 * dT           # R423-R426 0.1 % 25 ppm [DS]
EPS_T = 0.001 + 25e-6 * dT            # T network 1.30 k + 680 ohm 0.1 % 25 ppm [DS]
EPS_2K = 0.0005 + 10e-6 * dT          # 2.00 k legs Susumu 0.05 % 10 ppm (R9 E-4) [DS]
G_NOM = R2 / R1
G_HI = R2 * (1 + EPS_2K) / (R1 * (1 - EPS_T))
G_LO = R2 * (1 - EPS_2K) / (R1 * (1 + EPS_T))
KV = 10000.0 / 19760.0                # VREF divider R438/R439 (0.50607)
VF_MAX = 0.30                         # D411/D412 PMEG2010AEH 25 C max + typ tempco [E, parts R3.7]
HR_600, HR_TYP = 0.6, 0.246           # OPA2210 (V+) - 0.6 V at 600 ohm, 25 C only [DS]; interpolated typical at ~4 mA [E]
LCAL = 1.55                           # calibrated level per leg, Vrms [req.]
CAL_ALLOW_DB = 0.15                   # protection p03: +0.1 dB calibration tolerance + 0.05 dB trim
PRECAL_WORD = 0x4C3EA838              # -4.5 dB default master trim (digital C-7)
FULL = 0x7FFFFFFF                     # ESS master trim reg 17-20, signed 32 bit; reset default = 0 dB (untrimmed)
V_L_MIN, T_P_MIN = 1.80, 19.5e-3      # protection E-3 level threshold min and persistence min (register R-26/A-31) [protection]

def db(x): return 20 * math.log10(x)
def word(t_db): return int(round(FULL * 10 ** (t_db / 20)))

# ================================================================== F-5
p('=' * 110); p('F-5  LEG PEAKS AT 0 dBFS: UNTRIMMED (reset default 0x7FFFFFFF), -4.5 dB DEFAULT (0x%08X), CALIBRATED; SWING LIMITS; TRIM' % PRECAL_WORD); p('=' * 110)
pre_db = db(PRECAL_WORD / FULL)
p('Model: leg pk = G_leg x (Rf/Rs) x 0.924 x AVCC (two antiphase pins, one difference leg); pair = 2 x leg (LN = -LP).')
p('  -4.5 dB default word 0x%08X = %.4f dB re 0x7FFFFFFF [exact, digital]' % (PRECAL_WORD, pre_db))
av_hi = V3A[2]                                   # no AVCC-drop credit for the highest gain
av_lo = V3A[0] - I_AVCC * R_AVCC
g_iv_hi = RF * (1 + RF_EPS) / (RS_NOM * (1 - RS_TOL))
g_iv_lo = RF * (1 - RF_EPS) / (RS_NOM * (1 + RS_TOL))
g_iv_nom = RF / RS_NOM
leg_hi = G_HI * g_iv_hi * K_FS * av_hi
leg_lo = G_LO * g_iv_lo * K_FS * av_lo
leg_nom = G_NOM * g_iv_nom * K_FS * (V3A[1] - 0.5 * I_AVCC * R_AVCC)
k_pre = PRECAL_WORD / FULL
cal_pk = LCAL * math.sqrt(2)
cal_pk_allow = cal_pk * 10 ** (CAL_ALLOW_DB / 20)
p('  inputs: Rs 806 ohm -11/+11 %% [ESS note *1, 25 C]; 0.924 x AVCC [ESS TYP]; 3V3A %.3f..%.3f V [LP5907 DS]; AVCC drop 8 mA x 2.2 ohm [ASSUMP] (lowest only);'
  % (V3A[0], V3A[2]))
p('          Rf 698 ohm +-%.4f %% [DS]; leg gain R2/R1 %.5f nominal, %.5f .. %.5f (0.05 %%/10 ppm 2.00 k, 0.1 %%/25 ppm T network, x 25 K) [DS]'
  % (RF_EPS * 100, G_NOM, G_LO, G_HI))
rows = [('highest-gain, untrimmed 0 dBFS', leg_hi), ('highest-gain, -4.5 dB default', leg_hi * k_pre),
        ('nominal unit, untrimmed 0 dBFS', leg_nom), ('nominal unit, -4.5 dB default', leg_nom * k_pre),
        ('lowest-gain, untrimmed 0 dBFS', leg_lo), ('lowest-gain, -4.5 dB default', leg_lo * k_pre),
        ('calibrated full scale (1.55 Vrms)', cal_pk), ('calibrated + 0.15 dB (cal + trim, protection p03)', cal_pk_allow)]
p('  %-52s %9s %9s %9s %11s' % ('case (model, E: ESS TYP full scale)', 'leg V pk', 'leg Vrms', 'pair V pk', 'dB re cal'))
for n, v in rows:
    p('  %-52s %9.3f %9.3f %9.3f %+11.2f' % (n, v, v / math.sqrt(2), 2 * v, db(v / cal_pk)))

# ---- swing limits (they can only lower a peak; for the maximum no swing credit can be taken)
p(); p('Swing limits (a swing limit is guaranteed only as a minimum, so it can never be credited to cap the maximum peak):')
vref_hi = KV * V3A[2]
a_iv = g_iv_hi * K_FS * av_hi / 2                 # I/V output amplitude per pin, highest gain, 0 dBFS
top = vref_hi + a_iv
lim_ds = VPOS[0] - VF_MAX - HR_600
lim_typ = VPOS[0] - VF_MAX - HR_TYP
p('  I/V (OPA2210) per pin: amplitude %.3f V about VREF %.3f V -> top %.3f V (0 dBFS untrimmed), %.3f V (-4.5 dB), %.3f V (calibrated)'
  % (a_iv, vref_hi, top, vref_hi + a_iv * k_pre, vref_hi + cal_pk / (2 * G_HI)))
p('    limit, worst swing: VPOS min %.3f - VF %.2f - 0.6 V (600 ohm row, 25 C) = %.3f V [DS/E]; typical %.3f V [E]; best case: V+_IV up to %.3f V (no clip)'
  % (VPOS[0], VF_MAX, lim_ds, lim_typ, VPOS[2]))
clip_leg = G_HI * (lim_ds - (vref_hi - a_iv))
p('    0 dBFS untrimmed: worst-swing unit clips by %.3f V -> leg flattened symmetrically to +-%.3f V pk (pair %.3f V); typical unit %+.3f V (no clip)'
  % (top - lim_ds, clip_leg, 2 * clip_leg, lim_typ - top))
p('    -4.5 dB default: margin %+.3f V worst swing -> never clips; calibrated: %+.3f V' % (lim_ds - (vref_hi + a_iv * k_pre), lim_ds - (vref_hi + cal_pk / (2 * G_HI))))
p('  Leg (OPA1622): guaranteed linear range only |V| <= rail - 1.5 V = %.3f V (AOL test range, 600 ohm) [DS]; typical light-load swing within ~0.2..0.3 V of'
  % (min(VPOS[0], VNEG[0]) - 1.5))
p('    the rails [DS-typ] -> an unloaded / >= 300 ohm leg carries the full %.3f V; only low-impedance loads clip it (typ model 16 ohm %.2f V, 32 ohm %.2f V)'
  % (leg_hi, (VNEG[0] - 1.3) / (1 + 8.0 / 16), (VNEG[0] - 1.3) / (1 + 8.0 / 32)))
p('  => highest-gain untrimmed 0 dBFS, swing included: %.3f V pk per leg / %.3f V pair (maximum, any unit with typical or better swing);' % (leg_hi, 2 * leg_hi))
p('     worst-swing unit %.3f V / %.3f V (lower). -4.5 dB default: %.3f V / %.3f V in every unit (no swing limit reached).'
  % (clip_leg, 2 * clip_leg, leg_hi * k_pre, 2 * leg_hi * k_pre))

# ---- bounds for the class of these numbers
p(); p('Class of the peaks and the bounds that could replace the ESS TYP input:')
arch = G_HI * g_iv_hi * 1.0 * av_hi               # equivalent source bounded to 0..AVCC (p-p <= AVCC) instead of 0.924 AVCC
p('  (a) model values above: E (0.924 x AVCC is a TYP-column value; Rs +-11 % only at 25 C, no tempco; the AVCC drop is an assumption).')
p('  (b) supply-bounded source (ESS equivalent source cannot exceed 0..AVCC: p-p <= AVCC, i.e. factor 1.000 instead of 0.924):')
p('      untrimmed 0 dBFS <= %.3f V per leg / %.3f V pair; -4.5 dB <= %.3f / %.3f V -> still %.2f dB below the calibrated full scale.'
  % (arch, 2 * arch, arch * k_pre, 2 * arch * k_pre, db(cal_pk / (arch * k_pre))))
p('      Defensible, but it rests on the (unpublished) switched-resistor output structure and on Rs >= 717 ohm at 0-50 C -> E, not G.')
p('  (c) hard bound (G): an OPA1622 output cannot pass its rails: leg <= +%.3f / -%.3f V, pair <= %.3f V.  True but too loose for any content'
  % (VPOS[2], VNEG[2], VPOS[2] + VNEG[2]))
p('      boundary (the E-3 level threshold is 1.80-2.00 V across a pair).')
p('  (d) protection pcommon A_FS_UNTRIM = 3.66 V "per leg, swing-limited": %.0f %% above the model value %.3f V and %.0f %% above bound (b);'
  % (100 * (3.66 / leg_hi - 1), leg_hi, 100 * (3.66 / arch - 1)))
p('      conservative for a no-false-trip check, but not a swing limit (the I/V clips only in a worst-swing unit, and then lower, at %.2f V)' % clip_leg)
p('      and not a G bound.  Note: 3.66 V equals the model PAIR peak at the -4.5 dB default (%.3f V) - check per-leg vs pair use.' % (2 * leg_hi * k_pre))

# ---- calibration: how the level is set
p(); p('Calibration (how the level is set; ESS master trim = one common 32-bit word for both channels, reset default 0x7FFFFFFF = 0 dB):')
t_hi, t_lo, t_nom = db(cal_pk / leg_hi), db(cal_pk / leg_lo), db(cal_pk / leg_nom)
p('  per-board master trim T = 20 log10(1.55 Vrms / L0), L0 = measured untrimmed 0 dBFS level of the quieter channel; word = round(0x7FFFFFFF x 10^(T/20))')
p('  range (E, from the ESS TYP model): highest-gain T %.2f dB = 0x%08X; nominal %.2f dB = 0x%08X; lowest-gain %.2f dB = 0x%08X'
  % (t_hi, word(t_hi), t_nom, word(t_nom), t_lo, word(t_lo)))
p('  (analog_budget at nominal leg gain: -2.90 / -1.68 / -0.56 dB; the +-0.24 % leg-gain tolerance widens it by 0.02 dB each side)')
p('  measure at the -4.5 dB default, not at 0 dB: L0 = L(-4.5 dB) x 10^(4.5/20).  At 0 dB a worst-swing highest-gain unit clips its I/V by %.2f V'
  % (top - lim_ds))
p('  (the measurement would be wrong); at -4.5 dB every unit is linear (%+.3f V I/V margin).' % (lim_ds - (vref_hi + a_iv * k_pre)))
p('  louder channel: fine trim by attenuation only (MCU scaling <= 1.0, digital); the calibrated word is the ceiling: the firmware never exceeds it.')
p('  -4.5 dB default vs the calibrated level: highest-gain unit %.2f dB below (model), %.2f dB below with bound (b); every calibrated T lies in'
  % (db(cal_pk / (leg_hi * k_pre)), db(cal_pk / (arch * k_pre))))
p('  [%.2f, %.2f] dB (E), i.e. above the -4.5 dB default by >= %.2f dB -> a valid record never needs T < -4.5 dB unless the ESS full scale is'
  % (t_hi, t_lo, t_hi + 4.5))
r_lo, r_hi = 0x4BC89DFE, 0x7E88E865
p('  > %.2f dB above TYP.  Record check adopted by digital (R10 final 05:11, firmware_sequences 20): CRC valid and T in [0x%08X, 0x%08X]'
  % (t_hi + 4.5, r_lo, r_hi))
p('  = %.2f .. %.2f dB (bottom = protection 3.66 V bound %.2f dB - 0.1 dB, garbage filter only; top refuses 0x7FFFFFFF and anything within 0.1 dB),'
  % (db(r_lo / FULL), db(r_hi / FULL), db(cal_pk / 3.66)))
p('  else the -4.5 dB default; lowest-gain corner keeps %.2f dB for an ESS full-scale shortfall (yield).  Wrong in-range records: excluded by the'
  % (db(r_hi / FULL) - t_lo))
p('  firmware-enforced post-trim re-measurement (VERIFIED word programmed only after P-4: every leg 1.55 Vrms +-0.1 dB unloaded).')

# ---- post-calibration drift of the calibrated full scale (0-50 C; calibration at 25 +- 2 C)
p(); p('Post-calibration drift of the calibrated full scale over 0-50 C (the +0.15 dB allowance covers calibration + trim only):')
d_rf = 25e-6 * dT; d_leg = (25e-6 + 10e-6) * dT
d_3v3 = V3A[2] / V3A[0] - 1
p('  Rf TCR %.4f %% [DS] + leg ratio TCR %.4f %% [DS] = %.3f %% (G)' % (d_rf * 100, d_leg * 100, (d_rf + d_leg) * 100))
p('  3V3A (level ratiometric to AVCC): only the LP5907 +-2 %% window is published -> up to %+.2f %% (%.2f dB) if calibrated at 3.234 V and run at 3.366 V (G bound);'
  % (d_3v3 * 100, db(1 + d_3v3)))
p('    a typical LDO drift over 25 K is far smaller [E]')
p('  ESS Rs (806 ohm) temperature coefficient: not published [E]; the AVCC drop (8 mA x 2.2 ohm) may move by <= 0.5 % [E]')
cal_g = cal_pk_allow * (1 + d_rf + d_leg + d_3v3)
p('  => calibrated peak incl. G-bounded drift: %.3f V per leg / %.3f V pair (vs 2.228 / 4.457 V); ESS tempco on top (E).' % (cal_g, 2 * cal_g))

# ---- cross-check of the reviewer's times (protection owns the margins)
p(); p('Cross-check of R10-B (protection owns the margins): 20 Hz sine, time per half-cycle with |pair| > V_L min %.2f V (T_P min %.1f ms):'
       % (V_L_MIN, T_P_MIN * 1e3))
def t_above(apair, f=20.0, vl=V_L_MIN):
    if apair <= vl: return 0.0
    return (1 - 2 * math.asin(vl / apair) / math.pi) / (2 * f)
for n, apair in [('calibrated 1.55 Vrms (4.384 V pair)', 2 * cal_pk), ('calibrated + 0.15 dB', 2 * cal_pk_allow),
                 ('calibrated + 0.15 dB + G-bounded drift', 2 * cal_g), ('highest-gain -4.5 dB default (model)', 2 * leg_hi * k_pre),
                 ('highest-gain -4.5 dB default (bound b)', 2 * arch * k_pre),
                 ('-4.5 dB default, protection 3.66 V basis', 2 * 3.66 * k_pre), ('highest-gain untrimmed 0 dBFS (model)', 2 * leg_hi),
                 ('highest-gain untrimmed, worst-swing clip', 2 * clip_leg), ('lowest-gain untrimmed 0 dBFS', 2 * leg_lo)]:
    t = t_above(apair)
    p('  %-44s pair %6.3f V: %5.2f ms %s' % (n, apair, t * 1e3, 'TRIP (>= T_P min)' if t >= T_P_MIN else 'no trip (%.1f %% below)' % (100 * (1 - t / T_P_MIN))))
frac = T_P_MIN * 2 * 20.0
a_b = V_L_MIN / math.sin((1 - frac) * math.pi / 2)
p('  20 Hz sine boundary at V_L min / T_P min: %.3f V pair = %.3f V pk per leg (%.3f Vrms): calibrated+0.15 dB is %.2f dB below, -4.5 dB default %.2f dB below,'
  % (a_b, a_b / 2, a_b / 2 / math.sqrt(2), db(a_b / (2 * cal_pk_allow)), db(a_b / (2 * leg_hi * k_pre))))
p('  untrimmed highest-gain %.2f dB above (the clipped worst-swing unit %.2f dB above).  The untrimmed state exists after every DAC reset until the'
  % (db(2 * leg_hi / a_b), db(2 * clip_leg / a_b)))
p('  master-trim write -> the switch must stay open until the trim word (calibrated or 0x4C3EA838) is written and read back (digital).')

# ================================================================== F-2 inputs
p(); p('=' * 110); p('F-2  SENSITIVITIES FOR THE EVIDENCE-CLASS WALK [CALC]'); p('=' * 110)
IOS_MIN, ANA_SENSE = 180.0507e-3, 0.0378e-3  # power c17 R10 unrounded (R509 4.75 k) [power], ANA_SENSE 5.55 V / 147 k [power]

def need_for(cp=CP, ilm=I_LM):
    best = 0.0
    for jack, R, bal, ph, pd in TARGETS:
        v = leg_for_power(pd * 1e-3, R, bal)
        th, ip, im = rail_currents(v, R, bal)
        best = max(best, (ip + cp * im + ilm + I_PG).max())
    return best

def need_target(jack, R, cp=CP, ilm=I_LM, mode='D'):
    for j, RR, bal, ph, pd in TARGETS:
        if j == jack and RR == R:
            v = leg_for_power((pd if mode == 'D' else ph) * 1e-3, R, bal)
            th, ip, im = rail_currents(v, R, bal)
            return (ip + cp * im + ilm + I_PG).max(), ip.max(), im.max(), v

n0 = need_for()
m0 = IOS_MIN - ANA_SENSE - n0
_, _, im32, _ = need_target('3.5 mm', 32)
p('Default need (3.5 mm 32 ohm 38 mW; F-1 leg taps in, block 6 %.3f / %.3f mA): %.4f mA + ANA_SENSE %.4f = %.3f mA vs IOS min %.4f mA -> margin %+.4f mA'
  % (I_TLV_P * 1e3, I_TLV_N * 1e3, n0 * 1e3, ANA_SENSE * 1e3, (n0 + ANA_SENSE) * 1e3, IOS_MIN * 1e3, m0 * 1e3))
p('  (pre-F-1 = power c17 R10: 178.7912 + 0.0378 = 178.829 mA, +1.222 mA; the F-1 leg taps (245.6 k per leg, was 105 k) give -0.035 mA)')
p('  E inputs inside: LM27762 IQ 1.0 mA (390 uA TYP, no max) and CP 1.03 (charge-pump input/output factor, estimate); the need also uses')
p('  the AVX DCL x10-at-85 C rule (0.22 mA/rail) and the BAT54 x2-per-10-K leakage rule (25 uA/rail) [ASSUMP].')
p('  The margin is consumed at: LM27762 IQ <= %.2f mA (%.1f x TYP) with CP 1.03, or CP <= %.4f with IQ 1.0 mA (I- at the peak %.1f mA).'
  % ((I_LM + m0) * 1e3, (I_LM + m0) / 390e-6, CP + m0 / im32, im32 * 1e3))
p('  No datasheet bound exists for either (LM27762 SNVSAF7C: IQ and RNEG TYP only; PFM at light load, so the 390 uA no-load figure does not')
p('  bound the 2 MHz full-load overhead) -> the need, the Default margin and R-13 are E; per-board evidence = production test (Q).')
for jack, R in (('4.4 mm', 60), ('4.4 mm', 120), ('4.4 mm', 300)):
    n, ip, im, v = need_target(jack, R)
    m = IOS_MIN - ANA_SENSE - n
    p('  Default %s %3d ohm: need %.1f mA -> margin %+.1f mA; tolerates IQ <= %.1f mA or CP <= %.3f' % (jack, R, n * 1e3, m * 1e3, (I_LM + m) * 1e3, CP + m / im))

p(); p('High targets: guaranteed swing floor (OPA1622 AOL test range, DS) needs the sagged |V-| >= rail_needed; LM27762 RNEG is TYP only (2.5 ohm):')
def hr(i):
    return 1.5 if i <= 27.5e-3 else (2.0 if i >= 94e-3 else 1.5 + 0.5 * (i - 27.5e-3) / (94e-3 - 27.5e-3))
for jack, R, bal, ph, pd in TARGETS:
    v = leg_for_power(ph * 1e-3, R, bal)
    rl = R / 2 if bal else R
    rail_need = v + hr(v / rl)
    th, ip, im = rail_currents(v, R, bal)
    out = []
    for vb in (4.60, 4.40):
        vin = ENV_VIN[('High', vb)]
        rmax = (vin - rail_need) / im.max() - LDO_N_R
        out.append('VBUS %.2f V: RNEG <= %.2f ohm (%.1f x TYP)' % (vb, rmax, rmax / 2.5))
    p('  %s %3d ohm %3d mW: leg %.3f V pk, |V-| needed %.3f V at I- pk %.1f mA -> %s' % (jack, R, ph, v, rail_need, im.max() * 1e3, '; '.join(out)))
p('  (LDO dropout slope 0.45 ohm = 30 mV TYP at 100 mA x 1.5 and the c04 VIN are further non-G inputs) -> R-09..R-12 are E; M2 (RNEG) + i-12 = Q.')

p(); p('300 ohm (4.4 mm) High and Default targets sit at the calibrated full scale:')
v300 = leg_for_power(30e-3, 300, True)
m_db = db(cal_pk / v300) - 0.1
p('  30 mW needs %.3f V pk per leg; calibrated FS %.3f V (-0.1 dB: %.3f V) -> margin %.3f dB = %.2f %% of level after the calibration tolerance.'
  % (v300, cal_pk, cal_pk * 10 ** (-0.1 / 20), m_db, 100 * (1 - 10 ** (-m_db / 20))))
p('  Post-calibration drift allowed only by the LP5907 window: %.2f %% (G bound) > %.2f %% -> not G; typical drift << 1 %% (E); per-board level at 0-5/50 C (Q).'
  % (100 * (1 - V3A[0] / V3A[2]), 100 * (1 - 10 ** (-m_db / 20))))

p(); p('Offset G sub-result (5.61 / 11.21 mV) vs the ESS Rs tolerance (enters only the OPA2210 Vos noise gain 1 + Rf/Rs):')
for rs in (RS_NOM * (1 - RS_TOL), RS_NOM * 0.5):
    ng = 1 + RF * (1 + RF_EPS) / rs
    p('  Rs %.0f ohm: OPA2210 term (35 uV + 0.5 uV/K x 25 K) x %.3f x 2 = %.3f mV' % (rs, ng, (35e-6 + 0.5e-6 * dT) * ng * 2 * 1e3))
p('  -> even Rs at half of nominal adds only 0.07 mV (5.68 / 11.36 mV): the published-terms figure is insensitive to the ESS model (G-robust);')
p('     the requirement itself rests on the DAC terms (unpublished) -> qualified per board (E-4 procedure) = Q.')

p(); p('Frequency response (req +0.1/-0.3 dB): passive poles with DS tolerances (C0G +-5 %, 0.1 % R) -0.073 dB worst + ESS filter passband (DS max column)')
p('  -> -0.09 dB with ideal op-amps.  Dominant-pole op-amp at f << GBW: 1/T = NG x j f/GBW is almost pure phase, so the magnitude error is')
p('  second order, -10 log10(1 + (NG f/GBW)^2):')
for gbw_frac in (1.0, 0.1, 0.01):
    x1622 = 2.0 * 20e3 / (32e6 * gbw_frac)        # NG 2, OPA1622 GBW 32 MHz TYP
    x2210 = 1.87 * 20e3 / (18e6 * gbw_frac)       # NG ~1.87, OPA2210 GBW 18 MHz TYP
    e = 10 * math.log10(1 + x1622 ** 2) + 10 * math.log10(1 + x2210 ** 2)
    p('  GBW x %.2f of TYP: op-amp magnitude error at 20 kHz %.5f dB -> total %.3f dB' % (gbw_frac, e, 0.09 + e))
p('  (stability_switch closed-loop run, typical model: leg |H(20 kHz)| -0.0434 dB = the ideal T-network pole alone -> no op-amp term visible)')
p('  -> fails only if both GBW were below ~1/100 of TYP.  No GBW minimum is published: G only with a conservative bound GBW >= 1/10 TYP')
p('     (op-amp term <= 0.001 dB, defensible: GBW spread is a few tens of %); otherwise E.  i-11 = Q.')

p(); p('Rs lower bound implied by protection\'s A_FS_UNTRIM 3.66 V per leg (supply-bounded source, highest-gain Rf/leg/3V3A corners):')
rs_366 = G_HI * RF * (1 + RF_EPS) * V3A[2] / 3.66
p('  3.66 V per leg <=> Rs >= %.0f ohm (%.1f %% below 806 ohm: the -11 %% note tolerance plus a further %.1f %% temperature allowance for 0-50 C)'
  % (rs_366, 100 * (1 - rs_366 / RS_NOM), 100 * (rs_366 / (RS_NOM * (1 - RS_TOL)) - 1) * -1))
p('  -> 3.66 V is a defensible conservative (E) bound for the untrimmed peak; at the -4.5 dB default the same bound gives %.3f V per leg / %.3f V pair,'
  % (3.66 * k_pre, 2 * 3.66 * k_pre))
p('     %.2f dB below the calibrated 2.192 V (and %.2f dB below 2.228 V): the -4.5 dB default keeps even this bound at or below the calibrated level.'
  % (db(cal_pk / (3.66 * k_pre)), db(cal_pk_allow / (3.66 * k_pre))))

# ================================================================== F-1 leg-tap interface check (protection 06:20)
p(); p('=' * 110); p('F-1  NEW LEG TAPS (protection 06:20): OR 330 k -> 1 nF (2 x TLV1704), LPW 1.00 M -> 3.3 nF (2 x TLV3402); R601-R604/C601-C604 removed [CALC]'); p('=' * 110)
kT4 = 4 * 1.380649e-23 * 298.15
ZO_1K, ZO_20K = 0.33e-3, 6.7e-3                 # OPA1622 closed-loop Zout (analog_budget 4, typical AOL) [E]
def ztap(r, c, f):
    return abs(r + 1 / (2j * math.pi * f * c))
for f in (20.0, 1e3, 20e3):
    z_or, z_lp = ztap(R_TAP_OR, 1e-9, f), ztap(R_TAP_LPW, 3.3e-9, f)
    p('  |Z| per leg at %6.0f Hz: OR %.0f k, LPW %.0f k -> both %.0f k (removed R601-R604: 115 k to AC ground; model used 105 k)'
      % (f, z_or / 1e3, z_lp / 1e3, 1 / (1 / z_or + 1 / z_lp) / 1e3))
p('  load model (need, power tables): resistive %.1f k per leg to AC ground, in phase (upper bound on the current; caps only raise |Z|)' % (R_FILT / 1e3))
for v in (leg_hi, cal_g):
    p('  OPA1622 extra output current at %.3f V pk: %+.2f uA per leg vs the removed 115 k (%.2f uA new, %.2f uA old) -> negligible vs mA loads'
      % (v, (v / R_FILT - v / 115e3) * 1e6, v / R_FILT * 1e6, v / 115e3 * 1e6))
i_dc = 2 * 20e-9 + 2 * 1.5e-9
p('  offset: DC injection <= %.0f nA per leg (bias currents only, no DC path) x Zout (<= 0.33 mOhm at 1 kHz, lower at DC) <= %.0f pV -> no change'
  % (i_dc * 1e9, i_dc * ZO_1K * 1e12))
p('    (G sub-result 5.61 / 11.21 mV and E 7.73 / 15.47 mV unchanged; the removed C601-C604 X5R leakage and U601/U602 IB were similar nA terms)')
p('    protection side (FYI): bias-current error at the tap nodes 2 x 20 nA x 330 k = %.1f mV (OR), 2 x 1.5 nA x 1 M = %.1f mV (LPW)'
  % (2 * 20e-9 * 330e3 * 1e3, 2 * 1.5e-9 * 1e6 * 1e3))
p('  noise: sqrt(4kT/R) = %.2f pA/rtHz (330 k), %.2f pA/rtHz (1 M) x Zout <= 6.7 mOhm (20 kHz) -> < %.0e V/rtHz; DR / 1.75 / 2.83 uVrms unchanged'
  % (math.sqrt(kT4 / 330e3) * 1e12, math.sqrt(kT4 / 1e6) * 1e12, (math.sqrt(kT4 / 330e3) + math.sqrt(kT4 / 1e6)) * ZO_20K * 10))
vcr = 100e-6                                      # thick-film voltage coefficient bound, ppm/V [ASSUMP]
i_nl = cal_g / R_TAP_OR * vcr * cal_g
p('  THD: linear R / C0G; thick-film VCR <= 100 ppm/V [ASSUMP] -> nonlinear current %.2f nA at %.3f V x Zout 6.7 mOhm = %.1e V (< -200 dB)'
  % (i_nl * 1e9, cal_g, i_nl * ZO_20K))
i_clamp = (VNEG[2] - 0.3) / R_TAP_LPW
p('    if a TLV3402 input ever sits outside its supply (e.g. on 3V3M while the leg is negative): clamp current <= %.1f uA (half-wave) x 6.7 mOhm'
  % (i_clamp * 1e6))
p('    = %.0f nV (%.0f dB re 2.192 V pk) -> still negligible for THD (the comparator function in that case is protection\'s)'
  % (i_clamp * ZO_20K * 1e9, db(i_clamp * ZO_20K / cal_pk)))
r_off = 6.8e3 + 1 / (1 / 5.1e3 + 1 / 16.9e3)      # leg held by the DC-sense path while the OPA1622 is below minimum supply
v_open = V3A[2] * 16.9 / (5.1 + 16.9)             # DC-sense open-circuit voltage (upper bound of the leg during a ramp)
i_ramp = v_open / R_TAP_OR + v_open / R_TAP_LPW
dv_ramp = i_ramp * r_off
p('  pop (switch open during every rail ramp): taps charge from the leg; bound with unpowered comparator inputs clamped at 0 V and the leg at the')
p('    DC-sense open-circuit %.3f V: %.1f uA x %.2f k = %.0f mV leg shift (old 115 k / 2.2 uF path: up to %.0f mV, tau 253 ms)'
  % (v_open, i_ramp * 1e6, r_off / 1e3, dv_ramp * 1e3, v_open / 115e3 * r_off * 1e3))
p('    through COFF 1 nF into 300 ohm: even as an edge (20 kHz band) %.2f mV; over a >= 10 ms rail ramp %.1f uV; a separate event from the'
  % (300 * 1e-9 * dv_ramp * 2 * math.pi * 20e3 * 1e3, 300 * 1e-9 * dv_ramp / 10e-3 * 1e6))
p('    AVCC_EN step, whose leg is driven by the powered OPA1622 (taps irrelevant) -> controlled-transition bound 4.70 mV unchanged.')
p('    Tap time constants 0.33 ms (OR) / 3.3 ms (LPW) settle long before RELAY_EN (rails up >= 18.8 ms, DAC init + soft start >= 105 ms).')
p('  CM: I/V-side CM window and its summing network (R653-R656) assumed unchanged -> I/V stability (A-38) and I/V load unchanged.')
p('  stability: see out/stability_switch.txt (F-1 taps in the LEG model) and out/r3_fixes.txt (bead alternate).')

with open(os.path.join(OUT, 'r10_fixes.txt'), 'w') as fh:
    fh.write('\n'.join(L) + '\n')
print('\n'.join(L))
