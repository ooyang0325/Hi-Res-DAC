"""ROUND 1 (superseded by dac_timing_pop.py, round 2): ES9018K2M timing used by the firmware sequences, and pop bounds
with the output relay placeholder.  Restored verbatim from round 1 except the output file name.

ESS ES9018K2M v3.7: soft-mute ramp rate 0.0078125 * fs / 2^(vol_rate-5) dB/s (p.6, reg 6 vol_rate default 2);
soft start time 4096 * 2^(soft_start_time+1) / MCLK (reg 14, default soft_start_time = 10, p.19);
DPLL/ASRC lock after stop_div FSR edges, stop_div = 0 -> 16384 edges, required for FSR > 96 kHz (reg 10, p.16);
automute time 2096896 / (automute_time * DATA_CLK) (reg 4, p.13); GPIO cfg 4'd2 = minimum volume reached (p.15).
Relay data are placeholders from the protection stream [PH].  Output: ../out/dac_timing_pop_r1.txt"""
import os, math
OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
L = []; p = L.append
MCLK = 80e6
RATES = [44.1e3, 48e3, 88.2e3, 96e3, 176.4e3, 192e3, 352.8e3, 384e3]
vol_rate = 2
p('Soft mute ramp (0 dB -> -127.5 dB) and DPLL lock time (stop_div = 0) per rate [DS formula, CALC]:')
p('   fs (kHz)   ramp rate (dB/s)   ramp time (ms)   lock 16384/fs (ms)   firmware timeout mute (ms) / lock (ms)')
for fs in RATES:
    rate = 0.0078125 * fs / 2 ** (vol_rate - 5)
    t_ramp = 127.5 / rate
    t_lock = 16384 / fs
    p('   %7.1f   %14.0f   %12.1f   %16.1f        %6.0f / %6.0f' % (fs / 1e3, rate, t_ramp * 1e3, t_lock * 1e3, math.ceil(1.5 * t_ramp * 1e3), math.ceil(1.5 * t_lock * 1e3 + 10)))
t_ss = 4096 * 2 ** (10 + 1) / MCLK
p('Soft start (reg 14 soft_start_time = 10, MCLK 80 MHz): %.1f ms [DS formula]; relay may close only after %.0f ms (x1.2) [CALC]' % (t_ss * 1e3, t_ss * 1.2e3))

p(''); p('Pop bounds with the output relay (pop = transient beyond the settled DC step, 20 Hz-20 kHz, AC coupled; req <= 5 mV):')
Vos = (6.24e-3, 9.23e-3)  # worst-case leg offset, 0.05 % / 0.1 % leg resistors (analog_budget.txt)
Ccoil = 2e-12; dVcoil = 5.5; Rhp = (16.0, 300.0)  # [PH] coil-to-contact capacitance, coil step at 5.5 V
for R in Rhp:
    q = Ccoil * dVcoil
    # charge injected through the headphone; AC-coupled 20 kHz band-limit: the impulse integrates into a pulse of ~tau = 1/(2 pi 20 kHz)
    tau = 1 / (2 * math.pi * 20e3)
    vpk = q * R / tau
    p('  relay coil switching, charge %.0f pC into %3.0f ohm: band-limited peak %.3f mV [CALC, PH]' % (q * 1e12, R, vpk * 1e3))
p('  relay contact closure/opening onto a muted leg: step = leg DC offset (<= %.1f / %.1f mV worst, bounded by the offset limit, not pop);'
  ' contact bounce repeats the same step (no excursion beyond it) -> pop beyond the step 0 mV [CALC]' % (Vos[0] * 1e3, Vos[1] * 1e3))
Zout_hf = 5.0
for R in Rhp:
    di = Vos[1] / R
    p('  leg load step at closure into %3.0f ohm: %.2f mA x Zout(MHz) %.0f ohm = %.2f mV for < 1 us -> < 0.01 mV in band [CALC]' % (R, di * 1e3, Zout_hf, di * Zout_hf * 1e3))
p('  DAC reset/soft-start step (18-35 mV at the leg, v0.8) and the MCLK-stop frozen-code step (R8-D1) happen with the relay open -> 0 at the jack.')
p('  Rate / family change with the relay closed: volume and soft mute act before the ASRC (ESS block diagram p.2); with the volume at'
  ' -127.5 dB confirmed (GPIO2 cfg 4\'d2) the ASRC is fed zeros, MCLK never stops and soft_start stays 1 (output centred at AVCC/2)'
  ' -> no DC step expected; output during lock loss is NOT specified by ESS -> [MEAS] with the designed-in fallback: firmware opens'
  ' the relay around family (and, if needed, rate) changes.')
p('  NEVER while the relay can be closed: soft_start = 0 or soft_start_on_lock = 1 (ramp to ground = common-mode step of 1.65 V;'
  ' through the 3 %% pair-gain mismatch x g 0.97 -> %.0f mV DC step at the leg) and RESETB low (reset-state step 18-35 mV).' % (1.65 * 0.03 * 0.975 * 1e3))
open(os.path.join(OUT, 'dac_timing_pop_r1.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
