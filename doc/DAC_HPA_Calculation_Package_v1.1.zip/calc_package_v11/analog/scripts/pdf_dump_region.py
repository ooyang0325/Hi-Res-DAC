"""Dump words, curves and long grid lines in a region of a PDF page (pdfplumber),
used to locate plot frames/tick labels before digitizing vector figures."""
import sys, json, pdfplumber
pdf_path, page_no = sys.argv[1], int(sys.argv[2])
x0, x1, y0, y1 = map(float, sys.argv[3:7])
p = pdfplumber.open(pdf_path).pages[page_no]
for w in p.extract_words():
    if y0 < w['top'] < y1 and x0 < w['x0'] < x1:
        print('W', round(w['x0'], 1), round(w['top'], 1), w['text'])
for c in p.curves:
    xs = [q[0] for q in c['pts']]; ys = [q[1] for q in c['pts']]
    if min(ys) > y0 and max(ys) < y1 and min(xs) > x0 and max(xs) < x1:
        print('C', len(c['pts']), round(min(xs), 1), round(max(xs), 1), round(min(ys), 1), round(max(ys), 1),
              c.get('stroking_color'), round(c.get('linewidth') or 0, 3))
for l in p.lines:
    if l['top'] > y0 and l['bottom'] < y1 and l['x0'] > x0 and l['x1'] < x1 and (l['x1'] - l['x0'] > 60 or l['bottom'] - l['top'] > 60):
        print('L', round(l['x0'], 1), round(l['x1'], 1), round(l['top'], 1), round(l['bottom'], 1), l.get('stroking_color'))
