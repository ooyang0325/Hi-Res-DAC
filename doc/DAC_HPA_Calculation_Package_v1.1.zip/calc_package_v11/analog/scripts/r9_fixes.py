"""R9 (decisions_r9.md): analog items E-8 (C442/C443 reverse bias), E-6 (Default need: guaranteed vs engineering),
E-3 (leg-tap bound until protection's detector values are known), E-4 summary (offset split, from analog_budget.txt).
Output: ../out/r9_fixes.txt"""
import math, os

OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
L = []
def p(s=''):
    L.append(s)

# ------------------------------------------------------------------ E-8 reverse bias of the polarised I/V reservoirs
p('=' * 100); p('E-8  C442/C443 (AVX TAJD227K010RNJ, 10 V MnO2) REVERSE BIAS DURING LM27762 START/OFF, WITH D413/D414 [CALC]'); p('=' * 100)
VR = 10.0
bat54 = [(0.1e-3, 0.240), (1e-3, 0.320), (10e-3, 0.400), (30e-3, 0.500), (100e-3, 0.800)]   # VF max 25 C [DS Nexperia BAT54]
def vf_bat54(i):
    for (i1, v1), (i2, v2) in zip(bat54, bat54[1:]):
        if i <= i2:
            return v1 + (v2 - v1) * math.log(i / i1) / math.log(i2 / i1)
    return bat54[-1][1]
I_REV = 4 * 3.25e-3          # only current that can pull an unpowered I/V node past 0 V: OPA2210 supply current, 4 ch x 3.25 mA max [DS]
v25 = vf_bat54(I_REV)
tc_cold, tc_hot = 1.8e-3, 1.5e-3   # |dVF/dT| bounds [DS-typ curves / ASSUMP]: larger slope for the cold rise, smaller for the hot fall
def lim(T):                   # MnO2 transient reverse-voltage rule 10 % VR at 25 C, 3 % at 85 C, 1 % at 125 C [AVX TAJ rule, ASSUMP not re-read]
    if T <= 25: return 0.10 * VR
    if T <= 85: return (0.10 - 0.07 * (T - 25) / 60) * VR
    return (0.03 - 0.02 * (T - 85) / 40) * VR
p('Argument: C442 sits between N4_VPOS_IV (+) and GND, C443 between GND (+) and N4_VNEG_IV. D411/D412 conduct only in the charging direction, so')
p('a wrong-polarity excursion of VPOS or VNEG (LM27762 off or starting) reverse-biases D411/D412 and cannot reach the reservoirs. The only current that')
p('can drive an I/V node past 0 V is the OPA2210 supply current flowing V+ -> V- while one I/V rail is unpowered: <= %.1f mA [DS 4 x 3.25 mA]; D413/D414 carry it.' % (I_REV * 1e3))
p('(Op-amp input ESD paths from VREF/DAC pins can only pull the nodes toward the correct polarity.)')
for T in (0, 25, 50, 60):
    v = v25 + (25 - T) * (tc_cold if T < 25 else tc_hot)
    p('  T %3d C: BAT54 VF at %.1f mA <= %.3f V (%.1f %% of VR) vs reverse limit %.2f V -> margin %.2f V %s'
      % (T, I_REV * 1e3, v, 100 * v / VR, lim(T), lim(T) - v, 'OK' if v < lim(T) else 'FAIL'))
p('  typical case: when VPOS/VNEG are held near 0 V, D411/D412 (PMEG2010AEH, <= 0.30 V) clamp first.')
p('  duration: start/stop transients only (ms), current <= 13 mA -> the "small excursion" category of the rule; C442/C443 DC leakage unaffected.')
p('  RESULT: open item O15 / R9-A5 closed by calculation; no dependence on the LM27762 off-state behaviour.')

# ------------------------------------------------------------------ E-6 Default need, guaranteed vs engineering
p(); p('=' * 100); p('E-6  DEFAULT NEED (3.5 mm 32 ohm 38 mW, instantaneous 5V_ANA peak) - CLASSES [CALC from out/r2_power.txt]'); p('=' * 100)
import re
with open(os.path.join(OUT, 'r2_power.txt')) as fh:
    R2 = fh.read()
m475 = float(re.search(r'R509 4\.75 k 180\.1 mA -> ([+-][0-9.]+) mA', R2).group(1))
need_G = (180.1 - m475 - 0.038) * 1e-3                                # includes protection block 6 with R9 E-3 (2.51 / 2.65 mA)
q_G = float(re.search(r'5V_ANA = I\+ .*?= ([0-9.]+) mA', R2).group(1)) * 1e-3
q_C = float(re.search(r'quiescent set C.*?5V_ANA ([0-9.]+) mA', R2).group(1)) * 1e-3   # 25 C max x DS-typ ratio at 50 C
need_E = need_G - (q_G - q_C)
p('  need with DS maxima over -40..125 C (op-amp IQ, comparators, leakage bounds): %.2f mA  [G, except LM27762 IQ 1.0 mA (390 uA typ, no max) and CP 1.03 = E]' % (need_G * 1e3))
p('  need with 25 C maxima x typical 50 C ratio (set C, quiescent %.2f instead of %.2f mA): %.1f mA  [E, engineering estimate for 0-50 C]' % (q_C * 1e3, q_G * 1e3, need_E * 1e3))
for r509, ios in (('4.75 k', 180.1e-3), ('4.78 k', 179.0e-3), ('4.81 k', 177.9e-3), ('4.87 k', 175.9e-3)):
    p('  R509 %s -> IOS min %.1f mA: margin G %+.2f mA, E %+.1f mA (power adds ANA_SENSE 0.038 mA)' % (r509, ios * 1e3, (ios - need_G - 38e-6) * 1e3, (ios - need_E - 38e-6) * 1e3))
p('  Conservatism of the G figure: OPA1622/OPA2210 IQ at the -40..125 C maxima (4.2 / 3.25 mA/ch) instead of 25 C maxima (3.3 / 2.5 mA/ch);')
p('  reservoir DCL x10 at 85 C; clamp leakage x2 per 10 K to 60 C.  No analog change widens the G margin without a performance cost.')

# ------------------------------------------------------------------ E-3 leg-tap bound (before protection's values)
p(); p('=' * 100); p('E-3  LEG TAP BOUND FOR THE NEW LARGE-DC DETECTOR (until protection gives values) [CALC]'); p('=' * 100)
VLEG_DEF = 1.572             # leg peak at the 3.5 mm 32 ohm Default target [r2_power.txt]
for R in (20e3, 47e3, 100e3, 1e6):
    d5 = 2 * VLEG_DEF / R * (1 + 1.03)     # two legs source from V+, two sink into V- at the peak (all four legs swing, SE or balanced)
    p('  resistive tap %6.0f k to a ~0 V node on each LEG_xx: extra peak 5V_ANA %.3f mA (reduces any Default margin by that); load at 600 ohm %+.2f %%'
      % (R / 1e3, d5 * 1e3, -100 * 600 / (R + 600)))
p('  offset: closed-loop Zout 0.33 mOhm -> DC shift < 1 uV for any tap current; noise: resistor noise current x Zout, negligible;')
p('  THD: the OPA1622 load changes by < 3 % at 600 ohm; CM (I/V-side window): no effect; pop: none unless the tap holds charge on LEG_xx.')
p('  stability: capacitance behind >= 20 k is isolated (resistive at HF); capacitance directly on LEG_xx counts in the 0-1 nF family incl. the switch COFF path.')
p('  Recommendation: R_tap >= 100 k (<= 0.07 mA on the Default need) -> analog checks pass without re-running the stability family.')
p('  PROTECTION DESIGN (R9 17:18): two 1.487 M dividers (487 k + 1.00 M, 0.1 %) per LEG_xx, one returning to VPOS (<= 2.7 uA into the leg):')
Req = 1.487e6 / 2
p('    AC load %.3f M per leg -> Default need +%.4f mA (in r2_power via R_E3_TAP); DC injection 2.7 uA x Zout 0.33 mOhm = %.1f nV offset'
  % (Req / 1e6, 2 * VLEG_DEF / Req * 2.03 * 1e3, 2.7e-6 * 0.33e-3 * 1e9))
p('    noise: sqrt(4kT/1.487M) = %.2f pA/rtHz per divider x Zout -> < 1e-15 V/rtHz; THD: linear 0.1 %% thin film, divider node stays between LEG and VPOS'
  % (math.sqrt(1.656e-20 / 1.487e6) * 1e12))
p('    (inside the comparator input range, no clamp conduction), comparator input C isolated by >= 487 k; CM (I/V-side window) unaffected;')
p('    pop: with the switch open the taps do not reach the jack; with it closed the leg is regulated (nV).  -> CONFIRMED: no effect on THD, noise, CM, pop or stability.')
# final interface (protection 17:23): R900-R915; VPOS-returned tap sources (VPOS - LEG)/1.487 M = 2.55-2.70 uA; <= 1 pF added per LEG_xx
r_leg_off = 6.8e3 + 1 / (1 / 5.1e3 + 1 / 16.9e3)     # leg node to its DC-sense source while the OPA1622 is below minimum supply
dv_off = 2.7e-6 * r_leg_off
p('  FINAL (R900-R915): VPOS-returned tap sources <= 2.7 uA into LEG_xx.  Regulated leg: offset < 1 nV (DC loop gain >> 1 kHz value).')
p('    VPOS ramp, switch open, OPA1622 below minimum supply: leg held by the DC-sense path (%.1f k) -> extra shift <= %.0f mV; through COFF 1 nF'
  % (r_leg_off / 1e3, dv_off * 1e3))
p('    at 300 ohm: <= %.2f mV even as an edge (20 kHz band), far less for the ms rail ramp; not coincident with the AVCC_EN step (separate event).'
  % (300 * 1e-9 * dv_off * 2 * math.pi * 20e3 * 1e3))
p('    stability: <= 1 pF added directly on each LEG_xx vs the 0-1 nF load family -> no change.  -> CONFIRMED negligible (offset, pop, stability).')

# ------------------------------------------------------------------ E-4 summary
p(); p('=' * 100); p('E-4  OFFSET 0-50 C: GUARANTEED vs QUALIFIED (numbers from out/analog_budget.txt section 5)'); p('=' * 100)
try:
    with open(os.path.join(OUT, 'analog_budget.txt')) as fh:
        for line in fh:
            if 'Leg resistors' in line or 'E-4 split' in line or '=> unbalanced' in line or 'screening' in line:
                p('  ' + line.rstrip())
except OSError as e:
    p('  (analog_budget.txt not readable: %s)' % e)

# ------------------------------------------------------------------ E-9 digital's canonical order (firmware_sequences_output.txt 15)
p(); p('=' * 100); p('E-9  POP PER STEP OF THE CANONICAL POWER-DOWN ORDER S1-S7 (switch open from S2; COFF 1 nF, 300 ohm, 20 kHz band) [CALC]'); p('=' * 100)
VREF_HI, G = 1.706, 2000.0 / 1980.0
def v_reset(delta, eps_sum=0.001625 + 0.00075):      # reset-state leg step: DAC pin mismatch + CM leakage (mixed network, R9 E-4)
    rn, rp = 806 * (1 - delta / 2), 806 * (1 + delta / 2)
    return G * VREF_HI * 698 * (1 / rn - 1 / rp) + eps_sum * 3.37
def pop(dv, tr, C=1e-9, R=300.0):                      # same model as r3_fixes.pop
    return R * C * dv * min(2 * math.pi * 20e3, 1.0 / tr)
p('  S1 fade + soft mute, S2 RELAY_EN low + 1.1 ms: legs at the offset only; the switch opens on a muted leg -> no step')
p('  S3 reg 14 = 0x03 ramp (0.819 ms) + 1.1 ms: 0.126 mV (R3.6; the ramp ends in the ground/reset state)')
p('  S4 MCLK off, S5 PA8 high (RESETB low): DAC already in the ramped (ground) state -> no step [E: ESS ramp end state = reset state, not published]')
for d in (0.03, 0.22):
    p('  S6 AVCC_EN + AUD_EN (DAC in reset): reset-state leg voltage %.3f V (%.0f %% pin mismatch) collapses with 3V3A (tau >= 70 us): %.2f mV'
      % (v_reset(d), d * 100, pop(v_reset(d), 70e-6) * 1e3))
p('  S7 ANA_EN low after 0.53 ms: 3V3A <= 3.3 V x exp(-530/90) = %.3f V (< 0.3 V); I/V held by D411/D412; legs ~0 V -> negligible' % (3.3 * math.exp(-530 / 90)))
p('  => every controlled exit <= %.2f mV at 300 ohm (22 %% assumption), <= 5 mV; I2C double fault = fallback (<= 12.0 / 2.0 mV, logged fault)' % (pop(v_reset(0.22), 70e-6) * 1e3))

with open(os.path.join(OUT, 'r9_fixes.txt'), 'w') as fh:
    fh.write('\n'.join(L) + '\n')
print('\n'.join(L))
