"""Vectorised op-amp macro-models (see opamp_models.py for the derivation notes).

OPA1622 'CAL': A(f) = digitized SBOS727B Fig. 10 open-loop gain/phase, times an extra pole px, and an
  effective output impedance Zo = R0 + (R1 || s L1); px, R1, L1 fitted to the 14 points of Fig. 24
  (phase margin vs capacitive load, G=+1 and G=-1) by calibrate_opa1622.py (max error 2.3 deg).
OPA1622 'PHYS': Fig. 10 gain/phase + Fig. 40 |Zo| fitted with a minimum-phase R-L network
  (optimistic at CL >= 300 pF versus Fig. 24, kept only as a cross-check).
OPA2210: 3-pole model from SBOS924H tabulated specs (A0 132 dB typ, GBW 18 MHz typ, PM 80 deg typ at
  G=+1, RL 10 k, CL 25 pF), p2 fitted per assumed Zo shape (Fig. 6-15 not readable as text).
All models are TYPICAL (25 C).  gbw_scale scales the frequency axis of A(f) (process spread study).
"""
import json, math, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DIG = json.load(open(os.path.join(HERE, '..', 'ds', 'opa1622_digitized.json')))
CAL = json.load(open(os.path.join(HERE, '..', 'ds', 'opa1622_calibrated.json')))


class OPA1622v:
    A0_DB = 136.0
    CIN_DIFF = 0.8e-12
    CIN_CM = 0.9e-12

    def __init__(self, kind='CAL', gbw_scale=1.0):
        g = np.array(sorted(DIG['fig10']['gain'])); p = np.array(sorted(DIG['fig10']['phase']))
        self.gf, self.gd = g[:, 0], g[:, 1]
        self.pf, self.pd = p[:, 0], p[:, 1] - 180.0
        self.f_lo = max(self.gf[0], self.pf[0]); self.f_hi = min(self.gf[-1], self.pf[-1])
        g_lo = np.interp(np.log10(self.f_lo), np.log10(self.gf), self.gd)
        self.fp1 = self.f_lo / math.sqrt(10 ** ((self.A0_DB - g_lo) / 10) - 1)
        f1 = self.f_hi / 3.16
        self.slope_hi = (np.interp(np.log10(self.f_hi), np.log10(self.gf), self.gd)
                         - np.interp(np.log10(f1), np.log10(self.gf), self.gd)) / 0.5
        self.kind = kind
        self.k = gbw_scale
        if kind == 'CAL':
            self.px, self.R0, self.R1, self.L1 = CAL['px'], CAL['R0'], CAL['R1'], CAL['L1']
        else:
            self.px = 150e6
            # Fig. 40 fit (opamp_models.OPA1622._fit_zo result, reproduced here)
            self.R0, self.R1, self.L1, self.R2, self.L2 = 5.47, 27.5, 1.47e-7, 20.0, 1.78e-8

    def A(self, f):
        fe = np.asarray(f, float) / self.k
        lf = np.log10(np.clip(fe, self.f_lo, self.f_hi))
        gdb = np.interp(lf, np.log10(self.gf), self.gd)
        ph = np.interp(lf, np.log10(self.pf), self.pd)
        hi = fe > self.f_hi
        gdb = np.where(hi, np.interp(np.log10(self.f_hi), np.log10(self.gf), self.gd)
                       + self.slope_hi * np.log10(np.maximum(fe, 1) / self.f_hi), gdb)
        a = 10 ** (gdb / 20) * np.exp(1j * ph * np.pi / 180)
        lo = fe <= self.f_lo
        a = np.where(lo, 10 ** (self.A0_DB / 20) / (1 + 1j * fe / self.fp1), a)
        if self.kind == 'CAL':
            a = a / (1 + 1j * fe / self.px)
        else:
            a = np.where(hi, a / (1 + 1j * fe / self.px) * (1 + 1j * self.f_hi / self.px), a)
        return a

    def Zo(self, f):
        s = 2j * np.pi * np.asarray(f, float)
        z = self.R0 + self.R1 * s * self.L1 / (self.R1 + s * self.L1)
        if self.kind != 'CAL':
            z = z + self.R2 * s * self.L2 / (self.R2 + s * self.L2)
        return z


class OPA2210v:
    A0_DB = 132.0
    GBW = 18e6
    CIN_DIFF = 9e-12
    CIN_CM = 0.5e-12
    ZO_SHAPES = {'R20': (20.0, 0.0, 1.0, 0.0), 'R50': (50.0, 0.0, 1.0, 0.0), 'R100': (100.0, 0.0, 1.0, 0.0),
                 'CE700': (30.0, 700.0, 3e4, 0.0), 'CE300_L100n': (15.0, 300.0, 1e5, 100e-9)}

    def __init__(self, zo_shape='R50', gbw_scale=1.0, pm_target=80.0, a0_db=None):
        self.zo_shape = zo_shape
        self.gbw = self.GBW * gbw_scale
        self.a0 = 10 ** ((a0_db or self.A0_DB) / 20)
        self.fp1 = self.gbw / self.a0
        self.p3_ratio = 3.0
        self.p2 = None
        self._fit(pm_target)

    def Zo(self, f):
        rh, rl, fc, ls = self.ZO_SHAPES[self.zo_shape]
        f = np.asarray(f, float)
        return rh + rl / (1 + 1j * f / fc) + 2j * np.pi * f * ls

    def A(self, f):
        f = np.asarray(f, float)
        return self.a0 / ((1 + 1j * f / self.fp1) * (1 + 1j * f / self.p2) * (1 + 1j * f / (self.p3_ratio * self.p2)))

    def _pm_follower(self):
        from mna_v import Circuit, margins
        fr = np.logspace(3, 9.5, 700)
        c = Circuit()
        c.OPAMP('U', 'inp', 'out', 'out', self.A, self.Zo)
        c.R('inp', '0', 1.0); c.R('out', '0', 10e3); c.C('out', '0', 25e-12); c.C('inp', 'out', self.CIN_DIFF)
        return margins(fr, c.loop_gain(fr, 'U'))['pm']

    def _fit(self, target):
        lo, hi = 20e6, 20e9
        for _ in range(45):
            self.p2 = math.sqrt(lo * hi)
            pm = self._pm_follower()
            if pm is None or pm < target: lo = self.p2
            else: hi = self.p2
        self.p2 = math.sqrt(lo * hi)
        self.pm_fit = self._pm_follower()
