"""AC stability of each OPA2210 I/V converter (one amplifier per ES9018K2M output pin).

Circuit: DAC pin node N = inverting input.  DAC source: Rs (806 ohm +-11 %) to AC ground in parallel
with Cdac (not specified by ESS -> 0/5/15 pF swept), stray 2..5 pF, optional pin clamp 0/20 pF
(v0.8 BAT54S, for comparison).  Feedback Rf || Cf (+ optional series Rser, v0.8 had 10 ohm).
Non-inverting input on the shared VREF node: divider Thevenin (Rth) with C421 (33 pF) + 5 pF stray.
Output load: two leg T-network inputs (R1a 1.30 k -> Ct 1.8 nF || R1b 680 -> OPA1622 input; round 1 1.33 k / 665), output
clamp capacitance 0/10 pF, trace 5 pF.  OPA2210 model family (Zo shapes x GBW spread x PM-fit 80/65 deg).
Loop gain by breaking the OPA2210 VCVS; closed-loop transimpedance peaking from a current injection.
Output: ../out/stability_iv.txt"""
import os, sys, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA2210v

OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
FR = np.logspace(3, 9.3, 900)


def build(op, Rs, Cdac, Cstray, Cpin, Rf, Cf, Rser, Rth, Cclamp_out, legs=True, cm=False):
    c = Circuit()
    c.R('N', '0', Rs); c.C('N', '0', Cdac + Cstray + Cpin + op.CIN_CM)
    if Rser:
        c.R('N', 'OUT', Rf); c.R('N', 'nf', Rser); c.C('nf', 'OUT', Cf)
    else:
        c.R('N', 'OUT', Rf); c.C('N', 'OUT', Cf)
    c.R('P', '0', Rth); c.C('P', '0', 33e-12 + 5e-12 + op.CIN_CM)
    c.C('P', 'N', op.CIN_DIFF)
    c.OPAMP('U', 'P', 'N', 'OUT', op.A, op.Zo)
    c.C('OUT', '0', 5e-12 + Cclamp_out)
    if cm:   # round 2: protection CM summing R653-R656 100 k to N6_CMx (10 nF) + 5 pF trace to block 6
        c.R('OUT', 'cmn', 100e3); c.C('cmn', '0', 10e-9); c.C('OUT', '0', 5e-12)
    if legs:
        for k in ('a', 'b'):
            c.R('OUT', 'm' + k, 1300.0); c.C('m' + k, '0', 1.8e-9); c.R('m' + k, 'i' + k, 680.0)   # round 2: 1.30 k + 680 (round 1 1.33 k + 665)
            c.R('i' + k, '0', 2000.0 / 2)  # OPA1622 input node: ~R2||R4 path to (virtual) ground, 2k/2
            c.C('i' + k, '0', 12e-12)
    return c


def transimpedance_peaking(op, *args):
    c = build(op, *args)
    c.I('0', 'N', 1.0)  # 1 A into node N (the DAC current)
    v = c.solve(FR)
    z = np.abs(v('OUT'))
    z0 = z[np.searchsorted(FR, 1e3)]
    return 20 * np.log10(np.max(z) / z0), FR[np.argmax(z)], 20 * np.log10(z[np.searchsorted(FR, 2e4)] / z0)


ZO = ['R20', 'R50', 'R100', 'CE700', 'CE300_L100n']
GBW = [0.7, 1.0, 1.3]
PMFIT = [80.0, 65.0]
models = {}
for zo, g, pmf in itertools.product(ZO, GBW, PMFIT):
    models[(zo, g, pmf)] = OPA2210v(zo, g, pmf)

lines = ['OPA2210 model family: p2 fitted to G=+1 PM (10 k || 25 pF):']
for k, m in models.items():
    if k[1] == 1.0:
        lines.append('  Zo %-12s PMfit %.0f: p2 = %.1f MHz (achieved %.1f deg)' % (k[0], k[2], m.p2 / 1e6, m.pm_fit))

CASES = {
    'v0.9 R8 round 2 (as below + CM summing 100 k / 10 nF and 5 pF trace to block 6)': dict(Rf=698.0, Cf=820e-12, Rser=0, Cpin=0, Cclamp_out=20e-12, cm=True),
    'v0.9 (Rf 698, Cf 820p, no Rser, BAT54S at the output: 2 x 10 pF)': dict(Rf=698.0, Cf=820e-12, Rser=0, Cpin=0, Cclamp_out=20e-12),
    'v0.9 without output clamp': dict(Rf=698.0, Cf=820e-12, Rser=0, Cpin=0, Cclamp_out=0),
    'v0.9 with Rser 10 ohm (v0.8 style)': dict(Rf=698.0, Cf=820e-12, Rser=10.0, Cpin=0, Cclamp_out=20e-12),
    'v0.8 (836 ohm, 660p, 10 ohm, BAT54S pin clamps 20 pF)': dict(Rf=836.0, Cf=660e-12, Rser=10.0, Cpin=20e-12, Cclamp_out=0),
}
for name, cs in CASES.items():
    worst = None; allpm = []
    for key, op in models.items():
        for Rs, Cdac, Cstray in itertools.product((717.0, 806.0, 895.0), (0.0, 5e-12, 15e-12), (2e-12, 5e-12)):
            for Cf in (cs['Cf'] * 0.95, cs['Cf'] * 1.05):
                c = build(op, Rs, Cdac, Cstray, cs['Cpin'], cs['Rf'], Cf, cs['Rser'], 5170.0, cs['Cclamp_out'], cm=cs.get('cm', False))
                m = margins(FR, c.loop_gain(FR, 'U'))
                pm = m['pm_worst'] if m['pm_worst'] is not None else -99
                allpm.append(pm)
                if worst is None or pm < worst[0]:
                    worst = (pm, key, Rs, Cdac, Cstray, Cf, m['fc'], m['gm'])
    nomop = models[('R50', 1.0, 80.0)]
    cn = build(nomop, 806.0, 5e-12, 3e-12, cs['Cpin'], cs['Rf'], cs['Cf'], cs['Rser'], 5170.0, cs['Cclamp_out'], cm=cs.get('cm', False))
    mn = margins(FR, cn.loop_gain(FR, 'U'))
    pk, fpk, r20 = transimpedance_peaking(nomop, 806.0, 5e-12, 3e-12, cs['Cpin'], cs['Rf'], cs['Cf'], cs['Rser'], 5170.0, cs['Cclamp_out'])
    lines.append('')
    lines.append('Case: %s' % name)
    lines.append('  nominal (Zo R50, GBW x1, PMfit 80, Rs 806, Cdac 5 pF): PM %.1f deg at %.2f MHz, GM %s dB; '
                 'transimpedance peaking %+.2f dB at %.2f MHz; response at 20 kHz %+.4f dB'
                 % (mn['pm'], mn['fc'] / 1e6, 'n/a' if mn['gm'] is None else '%.1f' % mn['gm'], pk, fpk / 1e6, r20))
    lines.append('  worst over %d corners: PM %.1f deg (model %s, Rs %.0f, Cdac %.0f pF, stray %.0f pF, Cf %.0f pF, fc %.2f MHz, GM %s)'
                 % (len(allpm), worst[0], worst[1], worst[2], worst[3] * 1e12, worst[4] * 1e12, worst[5] * 1e12,
                    (worst[6] or 0) / 1e6, 'n/a' if worst[7] is None else '%.1f dB' % worst[7]))
    lines.append('  PM distribution: min %.1f / 5th pct %.1f / median %.1f deg' % (min(allpm), np.percentile(allpm, 5), np.median(allpm)))
open(os.path.join(OUT, 'stability_iv.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
