"""Choose the leg input 'T' filter: R1 = R1a + R1b with Ct from the midpoint to GND (same on R3),
no feedback capacitor.  HF noise gain = 1 + R2/R1b; LF noise gain = 1 + R2/(R1a+R1b) = 2.
Sweep splits/capacitors; report worst PM and sensitivity peak Ms over all loads and model spreads,
passband droop at 20 kHz and attenuation at 1 MHz and 5 MHz (ultrasonic filtering).
Output: ../out/stability_legs_T.txt"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA1622v
FR = np.logspace(3, 8.7, 900)
OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)


def build_T(R1a, R1b, Ct, load, CL, op, relay, cable, R2=2000.0):
    c = Circuit()
    c.R('sA', '0', 20.0); c.R('sB', '0', 20.0)
    c.R('sA', 'mA', R1a); c.R('mA', 'N', R1b); c.C('mA', '0', Ct)
    c.R('sB', 'mB', R1a); c.R('mB', 'P', R1b); c.C('mB', '0', Ct)
    c.R('N', 'OUT', R2); c.R('P', '0', R2)
    c.OPAMP('U', 'P', 'N', 'OUT', op.A, op.Zo)
    c.C('P', 'N', op.CIN_DIFF); c.C('P', '0', op.CIN_CM + 1.5e-12); c.C('N', '0', op.CIN_CM + 1.5e-12)
    c.L('OUT', 'LEG', 5e-9); c.R('LEG', '0', 15e3); c.R('LEG', '0', 100e3)
    if relay:
        c.R('LEG', 'k', 0.1); c.L('k', 'JACK', 10e-9)
    else:
        c.L('LEG', 'JACK', 5e-9)
    c.C('JACK', '0', 12e-12)
    if load != 'open':
        if CL: c.C('JACK', '0', CL)
        if cable:
            prev = 'JACK'
            for i in range(3):
                c.R(prev, 'cr%d' % i, 0.2); c.L('cr%d' % i, 'cn%d' % i, 0.6e-6); c.C('cn%d' % i, '0', 100e-12)
                prev = 'cn%d' % i
            c.R(prev, 'hp', load); c.L('hp', '0', 30e-6)
        else:
            c.R('JACK', '0', load)
    return c


def response(R1a, R1b, Ct, op):
    c = build_T(R1a, R1b, Ct, 300, 0, op, True, False)
    c.el = [e for e in c.el if not (e[0] == 'Z' and e[1] in ('sA', 'sB') and e[2] == '0')]
    c.R('sA', 'dA', 20.0); c.R('sB', 'dB', 20.0); c.V('VA', 'dA', '0', -0.5); c.V('VB', 'dB', '0', 0.5)
    v = c.solve(FR)
    h = np.abs(v('JACK')); h0 = h[np.searchsorted(FR, 1e3)]
    at = lambda fq: 20 * np.log10(h[np.searchsorted(FR, fq)] / h0)
    return at(2e4), at(4e4), at(1e6), at(5e6)


if __name__ == '__main__':
    LOADS = [('open', 0, False)] + [(rl, cl, False) for rl in (16, 32, 300, 600) for cl in (0, 220e-12, 470e-12, 1e-9)] \
            + [(32, 1e-9, True), (300, 1e-9, True), (600, 1e-9, True), (300, 2e-12, True)]
    LOADS2 = [(rl, 2e-9, False) for rl in (16, 32, 300, 600)]
    MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]
    VARIANTS = [(1000, 1000, 1.5e-9), (1000, 1000, 1.0e-9), (1210, 787, 1.5e-9), (1330, 665, 1.8e-9), (1500, 499, 2.0e-9), (1500, 499, 1.5e-9), (1650, 348, 2.7e-9)]
    lines = ['Leg T-filter variants (typical OPA1622 models CAL/PHYS, GBW x0.8..1.25); loads: open, 16-600 ohm with 0-1 nF '
             'to GND at the jack, 3 m cable + 1 nF; stress: 2 nF (1 nF across a balanced pair, differential mode)', '']
    for (R1a, R1b, Ct) in VARIANTS:
        worst = (999, None); worst2 = (999, None); msmax = 0
        for (mk, gs) in MODELS:
            op = OPA1622v(mk, gs)
            for relay in (True, False):
                for (load, CL, cable) in LOADS:
                    m = margins(FR, build_T(R1a, R1b, Ct, load, CL, op, relay, cable).loop_gain(FR, 'U'))
                    pmw = m['pm_worst'] if m['pm_worst'] is not None else -99
                    if pmw < worst[0]: worst = (pmw, (mk, gs, relay, load, CL, cable, m['gm']))
                    msmax = max(msmax, 1 / m['vector_margin'])
                for (load, CL, cable) in LOADS2:
                    m = margins(FR, build_T(R1a, R1b, Ct, load, CL, op, relay, cable).loop_gain(FR, 'U'))
                    pmw = m['pm_worst'] if m['pm_worst'] is not None else -99
                    if pmw < worst2[0]: worst2 = (pmw, (mk, gs, relay, load, CL, cable))
        r20, r40, r1M, r5M = response(R1a, R1b, Ct, OPA1622v('CAL', 1.0))
        fp = (R1a + R1b) / (2 * np.pi * Ct * R1a * R1b)
        lines.append('R1a=%4d R1b=%4d Ct=%.2f nF: NG(HF)=%.2f pole %.0f kHz | worst PM (<=1 nF, cable) %.1f deg %s | Ms max %.2f (%.1f dB) | '
                     'worst PM 2 nF %.1f deg | resp 20k %+.3f dB, 40k %+.3f dB, 1M %.1f dB, 5M %.1f dB'
                     % (R1a, R1b, Ct * 1e9, 1 + 2000 / R1b, fp / 1e3, worst[0], worst[1], msmax, 20 * np.log10(msmax), worst2[0], r20, r40, r1M, r5M))
    open(os.path.join(OUT, 'stability_legs_T.txt'), 'w').write('\n'.join(lines) + '\n')
    print('\n'.join(lines))
