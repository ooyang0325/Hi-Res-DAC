#!/bin/sh
# Regenerates every analog-stream output (order matters: digitize -> calibrate -> studies -> budgets -> netlist/BOM).
# Round 2 (R8 follow-up, 25 Sep 2026) additions are marked R2; round-1 scripts whose results are superseded are kept for traceability.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
cd "$D"
# scripts are called by absolute path so that __file__ (and every relative import/output path) does not depend on the cwd
python3 "$D/digitize_opa1622.py"
python3 "$D/digitize_opa1622_b.py"
python3 "$D/calibrate_opa1622.py"
python3 "$D/validate_opa1622.py"
python3 "$D/stability_legs.py"
python3 "$D/stability_legs_T.py"
python3 "$D/stability_legs_T2.py"
python3 "$D/stability_legs_lead.py"
python3 "$D/stability_final.py"          # round 1 (relay placeholder path) - superseded by stability_switch.py
python3 "$D/stability_switch.py"         # R2: TLP3545A closed / open, 37-case family
python3 "$D/stability_iv.py"             # R2: + CM summing load case
python3 "$D/analog_budget.py"            # R2: rails D-6, switch; power moved to r2_power.py
python3 "$D/r2_power.py"                 # R2: quiescent, Default need, power tables, headroom (writes power_table.csv)
python3 "$D/r2_switch.py"                # R2: output impedance, L/R mismatch, crosstalk, THD bound of the switch
python3 "$D/dac_pin_safety.py"           # R2: rails D-6, unplug exposure
python3 "$D/unplug_model.py"             # round 1 (superseded by unplug_model_r2.py; slow, pure-Python loop)
python3 "$D/unplug_model_r2.py"          # R2: D-17 options (vectorised)
python3 "$D/dac_timing_pop_r1.py"        # round 1 (80 MHz, relay) - superseded
python3 "$D/dac_timing_pop.py"           # R2: 75 MHz, photorelay pop, firmware steps
python3 "$D/stress_table.py"             # R2
python3 "$D/unplug_model_r3.py"          # R3: X-8 I/V supply hold-up (vectorised)
python3 "$D/r3_fixes.py"                 # R3: X-8 headroom/start-up, X-7 R305, B-07 resonance, F4 trims, F2 pop, F5 bead
python3 "$D/r9_fixes.py"                 # R9: E-8 reverse bias, E-6 need classes, E-3 tap bound, E-4 offset split
python3 "$D/r10_fixes.py"                # R10: F-5 uncalibrated/calibrated leg peaks, trim range, post-cal drift; F-2 class sensitivities
python3 "$D/gen_netlist_bom.py"          # R2/R3: net names, jack wiring, X-7/X-8/X-10 parts
