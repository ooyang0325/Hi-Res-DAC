"""Round 2 (D-17, time-boxed): hot-unplug behavioural model with the R8 power tree and four candidate hardware/firmware
changes that would keep the I/V supplies alive until 3V3A < 0.3 V (or make 3V3A collapse first).

Tree after VBUS removal (t = 0): 5V_SYS and 5V_ANA treated as one node (TPS2596 single FET: its body diode conducts
OUT -> IN, no reverse blocking [ASSUMP from SLVSET8A: no reverse-blocking feature listed]; worst case for the rails),
digital load constant current above 3.4 V then resistive, LP5907 3V3A follows 5V_SYS - 20 mV in dropout (no reverse
blocking: 3V3A <= 5V_SYS + 0.6 V), 3V3A load resistive 163 ohm (20.2 mA at 3.3 V) plus the back-feed of the five
DC-sense/reference 4.7 uF nodes (1.61 V) through 5.1 k [protection 6], LM27762 regulates 3.852 / 3.721 V, drops out
(V+ = VIN - 0.05 V, |V-| = VIN - 0.03 V - I x 3 ohm), UVLO at VIN 2.4 V falling [DS-typ] (2.2-2.6 V swept), then the
rails decay with the analog load and, optionally, the LM27762 active output discharge in shutdown [DS 6.3.4, strength
not specified: 300 ohm assumed].
Corners: C_sys+ana 8-20 uF, digital 0.15-0.30 A, 3V3A 4.8-9.0 uF, rails 15-45 uF, headphone 0/80 mA, UVLO 2.2/2.4/2.6 V,
active discharge off/on, back-feed on/off -> 2592 corners per option, vectorised.
Metric 1 (round-1 definition): window = t(I/V supply V+ + |V-| < 4.5 V) - t(3V3A < 0.3 V); negative = the I/V stops first.
Metric 2: worst DAC-pin excursion above AVCC while the OPA2210 is outside its CM / supply range (unclamped and clamped),
pin = w x 0.962 AVCC + (1 - w) x Vout, Vout = min(V+, AVCC + VF) [same bound as round 1].
Output: ../out/unplug_model_r2.txt"""
import os, itertools
import numpy as np
OUT = os.path.join(os.path.dirname(__file__), '..', 'out')

DT = 0.5e-6; TEND = 8e-3
W = (698 / (717 + 698), 698 / (895 + 698))


def corners():
    g = list(itertools.product((8e-6, 12e-6, 20e-6), (0.15, 0.22, 0.30), (4.8e-6, 6.9e-6, 9.0e-6), (15e-6, 30e-6, 45e-6),
                               (0.0, 0.08), (2.2, 2.4, 2.6), (False, True), (False, True)))
    a = np.array([[c[0], c[1], c[2], c[3], c[4], c[5], float(c[6]), float(c[7])] for c in g])
    return a


def run(opt='base', clamp_vf=None):
    """opt: 'base' | 'schottky_CXX' (I/V rails through a Schottky + XX uF) | 'rc_R_C' (R ohm + C uF RC hold-up) |
    'fw_brownout' (AVCC_EN low at the VBUS_SENSE watchdog, latest trip 3.771 V: tau 0.32 ms filter, 20 us ISR, 89 us gate, 10 ohm discharge) |
    'hw_crowbar' (5V_SYS supervisor at 4.10 V -1.5 %, 30 us delay, 1 ohm crowbar on 3V3A)."""
    c = corners(); n = len(c)
    C5, Idig, C3a, Cr, hp, uvlo, actdis, backfeed = c.T
    v5 = np.full(n, 5.0); v3a = np.full(n, 3.3); vp = np.full(n, 3.852); vn = np.full(n, 3.721)
    on = np.ones(n, bool)
    vsense = np.full(n, 5.0 * 0.3197)       # VBUS_SENSE node (C103, tau 0.32 ms)
    vnode = np.full(n, 1.61)                # DC-sense 4.7 uF nodes
    t_det = np.full(n, np.inf)
    ivp = vp.copy(); ivn = vn.copy()        # I/V local rails (options)
    vf_s = 0.40                             # Schottky at ~17 mA, 0 C [ASSUMP BAT54-class, Nexperia Table 7 + 50 mV]
    if opt.startswith('schottky'):
        civ = float(opt.split('_C')[1]) * 1e-6
        ivp = vp - vf_s; ivn = vn - vf_s
    if opt.startswith('rc'):
        rr, cc = opt.split('_')[1:]; rr = float(rr); civ = float(cc) * 1e-6
        ivp = vp - 0.017 * rr; ivn = vn - 0.017 * rr
    t3a = np.full(n, np.inf); tsup = np.full(n, np.inf)
    worst = np.full(n, -9.0); worst_c = np.full(n, -9.0); texp = np.zeros(n); texp5 = np.zeros(n)
    t = 0.0; k = 0
    while t < TEND:
        # ---- 5V_SYS / 5V_ANA node
        idig = np.where(v5 > 3.4, Idig, Idig * v5 / 3.4)
        iana = np.where(on, 0.0703 + hp, 0.0)
        i3a_in = np.where(v5 > v3a, v3a / 163.0, 0.0)
        v5 = np.maximum(0.0, v5 - (idig + iana + i3a_in) / C5 * DT)
        # ---- brown-out detection (firmware option)
        vsense += (v5 * 0.3197 - vsense) * DT / 0.32e-3
        if opt == 'fw_brownout':
            newly = np.isinf(t_det) & (vsense < 3.771 * 0.3197)   # latest trip of the 4.00 V watchdog band [power c09]
            t_det[newly] = t + 20e-6 + 89e-6
        if opt == 'hw_crowbar':
            newly = np.isinf(t_det) & (v5 < 4.10 * 0.985)
            t_det[newly] = t + 30e-6
        dis = (t >= t_det)
        # ---- 3V3A
        i_load = v3a / 163.0
        i_bf = np.where(backfeed > 0, np.maximum(vnode - v3a, 0) * 5 / 5.1e3, 0.0)
        vnode -= (np.maximum(vnode - v3a, 0) * 5 / 5.1e3 * backfeed + vnode / 16.9e3 * 5) / (5 * 4.7e-6) * DT
        r_dis = 10.0 if opt == 'fw_brownout' else (1.0 if opt == 'hw_crowbar' else np.inf)
        i_dis = np.where(dis, v3a / r_dis, 0.0)
        target = np.minimum(3.3, np.maximum(0.0, v5 - 0.02))
        free = v3a - (i_load + i_dis - i_bf) / C3a * DT
        v3a = np.where(dis | (v3a > target), np.maximum(free, 0.0), target)
        v3a = np.minimum(v3a, v5 + 0.6)
        # ---- LM27762
        on = on & (v5 >= uvlo)
        irail = 0.034
        vp_reg = np.minimum(3.852, np.maximum(0.0, v5 - 0.05))
        vn_reg = np.minimum(3.721, np.maximum(0.0, v5 - 0.03 - (irail + hp) * 3.0))
        idis_r = np.where(actdis > 0, 1 / 300.0, 0.0)
        vp_off = np.maximum(0.0, vp - ((irail + hp) * np.minimum(1, vp / 1.5) + vp * idis_r) / Cr * DT)
        vn_off = np.maximum(0.0, vn - ((irail + hp) * np.minimum(1, vn / 1.5) + vn * idis_r) / Cr * DT)
        vp = np.where(on, vp_reg, vp_off); vn = np.where(on, vn_reg, vn_off)
        # ---- I/V local rails
        if opt.startswith('schottky'):
            ivp = np.where(vp - vf_s > ivp, vp - vf_s, np.maximum(0, ivp - 0.0164 * np.minimum(1, ivp / 1.5) / civ * DT))
            ivn = np.where(vn - vf_s > ivn, vn - vf_s, np.maximum(0, ivn - 0.0138 * np.minimum(1, ivn / 1.5) / civ * DT))
        elif opt.startswith('rc'):
            ivp += ((vp - ivp) / rr - 0.0164 * np.minimum(1, np.maximum(ivp, 0) / 1.5)) / civ * DT
            ivn += ((vn - ivn) / rr - 0.0138 * np.minimum(1, np.maximum(ivn, 0) / 1.5)) / civ * DT
        else:
            ivp, ivn = vp, vn
        # ---- metrics
        t3a = np.where(np.isinf(t3a) & (v3a < 0.3), t, t3a)
        tsup = np.where(np.isinf(tsup) & ((ivp + ivn) < 4.5), t, tsup)
        vref = 0.50607 * v3a
        loose = (vref > ivp - 1.5) | ((ivp + ivn) < 4.5)
        valid = v3a > 0.05
        texp += np.where(loose & valid & ((ivp > v3a + 0.25) | (ivn > 0.25)), DT, 0.0)
        texp5 += np.where(loose & valid & ((ivp > v3a + 0.5) | (ivn > 0.5)), DT, 0.0)
        for w in W:
            vout = np.maximum(ivp, 0)
            pin = np.where(loose, w * 0.962 * v3a + (1 - w) * vout, vref)
            worst = np.where(valid, np.maximum(worst, pin - v3a), worst)
            if clamp_vf is not None:
                voc = np.minimum(vout, v3a + clamp_vf)
                pinc = np.where(loose, w * 0.962 * v3a + (1 - w) * voc, vref)
                worst_c = np.where(valid, np.maximum(worst_c, pinc - v3a), worst_c)
        t += DT; k += 1
    t3a = np.where(np.isinf(t3a), TEND, t3a); tsup = np.where(np.isinf(tsup), TEND, tsup)
    return tsup - t3a, worst, worst_c, c, texp, texp5


L = [__doc__.split('\n')[0], '']
res = {}
for opt, label in [('base', 'as designed (D405-D408 clamps; no change)'),
                   ('schottky_C22', 'A1: I/V rails via Schottky + 22 uF per rail'),
                   ('schottky_C47', 'A1: I/V rails via Schottky + 47 uF per rail'),
                   ('schottky_C100', 'A1: I/V rails via Schottky + 100 uF per rail'),
                   ('rc_10_100', 'A2: I/V rails via 10 ohm + 100 uF per rail (RC hold-up, no diode)'),
                   ('fw_brownout', 'B1: firmware RELAY_EN + AVCC_EN low at the VBUS_SENSE watchdog (4.00 V nominal, latest 3.771 V; existing parts, 10 ohm discharge)'),
                   ('hw_crowbar', 'B2: 5V_SYS supervisor 4.10 V -> LP5907 off + 1 ohm crowbar on 3V3A (new parts)')]:
    win, exc, excc, c, texp, texp5 = run(opt, clamp_vf=0.74)
    res[opt] = (win, exc, excc, texp, texp5)
    L.append('%s:' % label)
    L.append('  window I/V supply < 4.5 V -> 3V3A < 0.3 V: worst %+.3f ms (median %+.3f ms; %.0f %% of corners with the I/V outliving 3V3A)'
             % (win.min() * 1e3, np.median(win) * 1e3, 100 * np.mean(win >= 0)))
    L.append('  worst pin above AVCC while the OPA2210 is out of range: unclamped %+.3f V, with the BAT54S upper clamp (VF 0.74 V, 65 mA, 0 C) %+.3f V'
             % (exc.max(), excc.max()))
    L.append('  clamp exposure (OPA2210 out of range while its output can pass a clamp threshold: V+ > AVCC + 0.25 V or |V-| > 0.25 V): worst %.3f ms, median %.3f ms'
             % (texp.max() * 1e3, np.median(texp) * 1e3))
    L.append('  significant clamp exposure (same with 0.5 V: clamp current can exceed ~1 mA): worst %.3f ms, median %.3f ms' % (texp5.max() * 1e3, np.median(texp5) * 1e3))
    i = np.argmin(win)
    L.append('  worst corner: C5 %.0f uF, Idig %.2f A, C3A %.1f uF, Crail %.0f uF, hp %.2f A, UVLO %.1f V, active discharge %s, back-feed %s'
             % (c[i, 0] * 1e6, c[i, 1], c[i, 2] * 1e6, c[i, 3] * 1e6, c[i, 4], c[i, 5], bool(c[i, 6]), bool(c[i, 7])))
L.append('')
L.append('Headroom / performance cost of each option (analog_budget.txt section 2 margins: OPA2210 CM 0.583 V, reset-state swing 0.174 V,')
L.append('untrimmed-0-dBFS swing 0.328 V, all at V+min 3.789 V):')
L.append('  A1 Schottky (VF 0.35-0.45 V at 17 mA, 0-50 C): CM margin -> 0.13-0.23 V; reset-state margin -> -0.28 ... -0.18 V (I/V saturates in reset);'
         ' untrimmed 0 dBFS -> -0.12 ... -0.02 V (clips); plus 2 x 22-100 uF MLCC, 2 diodes -> REJECTED (performance cost)')
L.append('  A2 RC 10 ohm (16.4 mA -> 0.16 V drop, signal-dependent +-3 mA -> +-30 mV supply modulation): reset-state margin -> 0.01 V; does not'
         ' hold the rail (the reservoir discharges into the collapsing rail) -> REJECTED')
L.append('  B1 firmware brown-out rule (RELAY_EN and AVCC_EN low in the watchdog ISR, no 1.1 ms wait): no parts, no performance cost; the VBUS_SENSE'
         ' filter (0.32 ms) + ISR + gate (0.11 ms) + discharge (tau ~70 us) still loses the race by up to 0.38 ms, so the clamps stay necessary,'
         ' but the clamp exposure falls from <= 4.9 ms to <= 0.62 ms -> ADOPTED as a firmware rule (not a hardware fix)')
L.append('  B2 supervisor + crowbar: new supervisor IC, FET and logic in the power stream\'s U302 enable path; must not trip at the 4.30 V operating'
         ' minimum (0.2 V margin incl. USB droop) -> false DAC-reference collapses during playback at low VBUS = performance risk -> REJECTED')
open(os.path.join(OUT, 'unplug_model_r2.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
