"""AC stability of the OPA1622 output legs (difference amplifier) with every load corner.

Loop gain by breaking the OPA1622 ideal VCVS (mna_v).  Networks studied:
  C330      : v0.8 network, 4 x 2.00 k, 330 pF across R2 and R4 (HF noise gain -> 1)
  C0        : leg capacitors removed (noise gain 2 at all frequencies)
  C330_Zxx  : v0.8 network + output snubber (Zobel) Rz + Cz at the amplifier output
  T         : 'T' input filter (R1 = 1k + 1k with C to GND at the midpoint, same on R3), no feedback C
Loads (at the jack, after the relay contact for + legs): open (relay open), 16/32/300/600 ohm,
CL = 0..2 nF to GND (2 nF = differential-mode equivalent of 1 nF across a balanced pair),
and a 3 m cable (3 lumped sections, 0.2 ohm + 0.6 uH + 100 pF per metre) with 1 nF at the jack.
OPA1622 models: CAL (fitted to Fig. 24, primary) and PHYS, GBW x0.8 / x1.25 spread.
Parasitics: relay contact 0.1 ohm + 10 nH, trace 5 nH, ESD 12 pF at the jack, 1.5 pF at each input,
DC-sense 15 k and detector 100 k at the leg node, I/V source impedance 20 ohm.
Output: ../out/stability_legs.txt, ../out/stability_legs.csv
"""
import os, sys, itertools, csv
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA1622v

OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
FR = np.logspace(3, 8.7, 900)


def build(net, load, CL, op, relay=True, cable=False, rsrc=20.0):
    c = Circuit()
    c.R('sA', '0', rsrc); c.R('sB', '0', rsrc)
    R = 2000.0
    if net['kind'] == 'T':
        c.R('sA', 'mA', R / 2); c.R('mA', 'N', R / 2); c.C('mA', '0', net['Ct'])
        c.R('sB', 'mB', R / 2); c.R('mB', 'P', R / 2); c.C('mB', '0', net['Ct'])
    else:
        c.R('sA', 'N', R); c.R('sB', 'P', R)
    c.R('N', 'OUT', R); c.R('P', '0', R)
    if net.get('Cf'):
        if net.get('Rc'):
            c.R('N', 'nc', net['Rc']); c.C('nc', 'OUT', net['Cf'])
            c.R('P', 'pc', net['Rc']); c.C('pc', '0', net['Cf'])
        else:
            c.C('N', 'OUT', net['Cf']); c.C('P', '0', net['Cf'])
    c.OPAMP('U', 'P', 'N', 'OUT', op.A, op.Zo)
    c.C('P', 'N', op.CIN_DIFF); c.C('P', '0', op.CIN_CM + 1.5e-12); c.C('N', '0', op.CIN_CM + 1.5e-12)
    # output path
    c.L('OUT', 'LEG', 5e-9)
    c.R('LEG', '0', 15e3); c.R('LEG', '0', 100e3)
    if net.get('Rz'):
        c.R('LEG', 'z', net['Rz']); c.C('z', '0', net['Cz'])
    if relay:
        c.R('LEG', 'k', 0.1); c.L('k', 'JACK', 10e-9)
    else:
        c.L('LEG', 'JACK', 5e-9)
    c.C('JACK', '0', 12e-12)
    if load == 'open':
        return c
    if CL: c.C('JACK', '0', CL)
    if cable:
        prev = 'JACK'
        for i in range(3):
            c.R(prev, 'cr%d' % i, 0.2); c.L('cr%d' % i, 'cn%d' % i, 0.6e-6); c.C('cn%d' % i, '0', 100e-12)
            prev = 'cn%d' % i
        c.R(prev, 'hp', load); c.L('hp', '0', 30e-6)  # driver: R + 30 uH voice-coil inductance
    else:
        c.R('JACK', '0', load)
    return c


def closed_loop_peaking(net, load, CL, op, relay, cable):
    c = build(net, load, CL, op, relay, cable)
    # replace the source resistors' ground with a differential drive: add sources in series
    c2 = Circuit(); c2.el = [e for e in c.el if not (e[0] == 'Z' and e[1] in ('sA', 'sB') and e[2] == '0')]
    c2.R('sA', 'dA', 20.0); c2.R('sB', 'dB', 20.0)
    c2.V('VA', 'dA', '0', -0.5); c2.V('VB', 'dB', '0', 0.5)
    v = c2.solve(FR)
    h = np.abs(v('JACK'))
    h0 = h[np.searchsorted(FR, 1e3)]
    pk = 20 * np.log10(np.max(h[FR > 1e4]) / h0) if h0 > 0 else float('nan')
    fpk = FR[FR > 1e4][np.argmax(h[FR > 1e4])]
    return pk, fpk, 20 * np.log10(h[np.searchsorted(FR, 2e4)] / h0)


NETS = {
    'C330': dict(kind='std', Cf=330e-12),
    'C0': dict(kind='std'),
    'C330_Z10_22n': dict(kind='std', Cf=330e-12, Rz=10.0, Cz=22e-9),
    'C330_Z4.7_47n': dict(kind='std', Cf=330e-12, Rz=4.7, Cz=47e-9),
    'C0_Z10_22n': dict(kind='std', Rz=10.0, Cz=22e-9),
    'T_1n5': dict(kind='T', Ct=1.5e-9),
}
LOADS = [('open', 0, False), (16, 0, False), (32, 0, False), (300, 0, False), (600, 0, False)]
for rl in (16, 32, 300):
    for cl in (100e-12, 220e-12, 470e-12, 1e-9, 2e-9):
        LOADS.append((rl, cl, False))
for cl in (1e-9, 2e-12):  # cable with and without 1 nF at the jack
    LOADS.append((32, cl, True)); LOADS.append((300, cl, True))
LOADS.append((600, 2e-9, False))
MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]

rows = []
for netname, net in NETS.items():
    for (mk, gs) in MODELS:
        op = OPA1622v(mk, gs)
        for relay in (True, False):
            for (load, CL, cable) in LOADS:
                c = build(net, load, CL, op, relay, cable)
                m = margins(FR, c.loop_gain(FR, 'U'))
                pk = fpk = r20 = float('nan')
                if mk == 'CAL' and gs == 1.0:
                    pk, fpk, r20 = closed_loop_peaking(net, load, CL, op, relay, cable)
                rows.append(dict(net=netname, model=mk, gbw=gs, relay=relay, load=load, CL_pF=CL * 1e12, cable=cable,
                                 fc_MHz=(m['fc'] or 0) / 1e6, pm=m['pm'], pm_worst=m['pm_worst'], gm=m['gm'],
                                 vm=m['vector_margin'], peak_dB=pk, fpeak_MHz=fpk / 1e6, resp20k_dB=r20))

with open(os.path.join(OUT, 'stability_legs.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

lines = ['OPA1622 leg stability (typical models; worst over relay/no-relay path and loads)', '']
for netname in NETS:
    lines.append('Network %s' % netname)
    for (mk, gs) in MODELS:
        sel = [r for r in rows if r['net'] == netname and r['model'] == mk and r['gbw'] == gs]
        worst = min(sel, key=lambda r: (r['pm_worst'] if r['pm_worst'] is not None else -999))
        lines.append('  model %s gbw x%.2f: worst PM %.1f deg at load %s CL %.0f pF cable %s relay %s (fc %.2f MHz, GM %s dB, vector margin %.2f)'
                     % (mk, gs, worst['pm_worst'] if worst['pm_worst'] is not None else float('nan'), worst['load'], worst['CL_pF'],
                        worst['cable'], worst['relay'], worst['fc_MHz'],
                        'n/a' if worst['gm'] is None else '%.1f' % worst['gm'], worst['vm']))
    sel = [r for r in rows if r['net'] == netname and r['model'] == 'CAL' and r['gbw'] == 1.0 and r['relay']]
    lines.append('  CAL x1.00, + leg (relay path): load / CL / PM / worst-PM / peaking dB @ MHz / response at 20 kHz dB')
    for r in sel:
        lines.append('    %6s %6.0f pF cable=%-5s PM %6.1f  worst %6.1f  peak %+6.2f dB @ %6.2f MHz  20k %+6.3f dB'
                     % (r['load'], r['CL_pF'], r['cable'], r['pm'] if r['pm'] is not None else float('nan'),
                        r['pm_worst'] if r['pm_worst'] is not None else float('nan'), r['peak_dB'], r['fpeak_MHz'], r['resp20k_dB']))
    lines.append('')
open(os.path.join(OUT, 'stability_legs.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
