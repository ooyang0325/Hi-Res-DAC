"""Small complex-valued MNA (modified nodal analysis) AC solver for stability work.

Elements (all frequency-domain, evaluated at s = j*2*pi*f):
  R(a, b, value)                       resistor
  C(a, b, value)                       capacitor
  L(a, b, value)                       inductor
  Z(a, b, func)                        arbitrary impedance, func(f) -> complex ohms
  V(name, a, b, value)                 independent voltage source (a = +)
  I(a, b, value)                       independent current source, flows from a to b through the source
  OPAMP(name, inp, inn, out, A, Zo)    op-amp macro-model: internal ideal VCVS
                                       Vint = A(f) * (V(inp) - V(inn)) followed by Zo(f) to 'out'.
Node '0' is ground.  Loop gain of an op-amp is obtained by replacing its VCVS with a unit
independent source at the internal node ("break at the ideal VCVS"): T = -A(f) * (V(inp)-V(inn)).
Because the VCVS is ideal (zero output impedance, infinite input impedance) the break is exact.
"""
import numpy as np


class Circuit:
    def __init__(self):
        self.el = []
        self.nodes = {'0': -1}

    def _n(self, name):
        if name not in self.nodes:
            self.nodes[name] = len(self.nodes) - 1
        return self.nodes[name]

    def R(self, a, b, v):
        self.el.append(('Z', a, b, lambda f, v=v: complex(v)))

    def C(self, a, b, v):
        if v > 0:
            self.el.append(('Z', a, b, lambda f, v=v: 1.0 / (2j * np.pi * f * v)))

    def L(self, a, b, v):
        self.el.append(('Z', a, b, lambda f, v=v: 2j * np.pi * f * v + 1e-9))

    def Z(self, a, b, func):
        self.el.append(('Z', a, b, func))

    def V(self, name, a, b, v):
        self.el.append(('V', name, a, b, v))

    def I(self, a, b, v):
        self.el.append(('I', a, b, v))

    def OPAMP(self, name, inp, inn, out, A, Zo):
        self.el.append(('OA', name, inp, inn, out, A, Zo))

    def solve(self, f, broken=None, vtest=1.0):
        """Solve at frequency f.  broken = name of op-amp whose VCVS is replaced by an
        independent source of value vtest (loop-gain measurement)."""
        for e in self.el:  # register nodes
            if e[0] == 'Z':
                self._n(e[1]); self._n(e[2])
            elif e[0] == 'V':
                self._n(e[2]); self._n(e[3])
            elif e[0] == 'I':
                self._n(e[1]); self._n(e[2])
            elif e[0] == 'OA':
                for nn in (e[2], e[3], e[4], e[1] + '#int'):
                    self._n(nn)
        N = len(self.nodes) - 1
        vs = [e for e in self.el if e[0] in ('V', 'OA')]
        M = N + len(vs)
        Y = np.zeros((M, M), dtype=complex)
        rhs = np.zeros(M, dtype=complex)

        def stamp_y(a, b, y):
            ia, ib = self.nodes[a], self.nodes[b]
            if ia >= 0: Y[ia, ia] += y
            if ib >= 0: Y[ib, ib] += y
            if ia >= 0 and ib >= 0:
                Y[ia, ib] -= y; Y[ib, ia] -= y

        for e in self.el:
            if e[0] == 'Z':
                stamp_y(e[1], e[2], 1.0 / e[3](f))
            elif e[0] == 'I':
                ia, ib = self.nodes[e[1]], self.nodes[e[2]]
                if ia >= 0: rhs[ia] -= e[3]
                if ib >= 0: rhs[ib] += e[3]
            elif e[0] == 'OA':
                stamp_y(e[1] + '#int', e[4], 1.0 / e[6](f))
        k = N
        for e in vs:
            if e[0] == 'V':
                ia, ib = self.nodes[e[2]], self.nodes[e[3]]
                if ia >= 0: Y[ia, k] += 1; Y[k, ia] += 1
                if ib >= 0: Y[ib, k] -= 1; Y[k, ib] -= 1
                rhs[k] = e[4]
            else:
                name, inp, inn, A = e[1], e[2], e[3], e[5]
                ii = self.nodes[name + '#int']
                Y[ii, k] += 1; Y[k, ii] += 1
                if broken == name:
                    rhs[k] = vtest
                else:
                    a = A(f)
                    ip, im = self.nodes[inp], self.nodes[inn]
                    if ip >= 0: Y[k, ip] -= a
                    if im >= 0: Y[k, im] += a
            k += 1
        x = np.linalg.solve(Y, rhs)
        return lambda node: 0j if node == '0' else x[self.nodes[node]]

    def loop_gain(self, f, name):
        e = [x for x in self.el if x[0] == 'OA' and x[1] == name][0]
        v = self.solve(f, broken=name)
        return -e[5](f) * (v(e[2]) - v(e[3]))


def margins(freqs, T):
    """Phase margin at the first unity crossing from above, gain margin at the first -180 deg
    crossing after unity, and the unity frequency.  Phase is unwrapped from low frequency."""
    mag = np.abs(T)
    ph = np.unwrap(np.angle(T)) * 180 / np.pi
    # normalise so that low-frequency phase of a negative-feedback loop gain is ~0 deg
    ph = ph - 360 * np.round(ph[0] / 360)
    fc = pm = None
    for i in range(len(freqs) - 1):
        if mag[i] >= 1 > mag[i + 1]:
            t = np.log(mag[i]) / (np.log(mag[i]) - np.log(mag[i + 1]))
            fc = freqs[i] * (freqs[i + 1] / freqs[i]) ** t
            phc = ph[i] + t * (ph[i + 1] - ph[i])
            pm = 180 + phc
            break
    # all unity crossings (secondary crossings reveal resonant peaking)
    crossings = []
    for i in range(len(freqs) - 1):
        if (mag[i] - 1) * (mag[i + 1] - 1) < 0:
            t = np.log(mag[i]) / (np.log(mag[i]) - np.log(mag[i + 1]))
            fx = freqs[i] * (freqs[i + 1] / freqs[i]) ** t
            crossings.append((fx, 180 + ph[i] + t * (ph[i + 1] - ph[i])))
    gm = None
    for i in range(len(freqs) - 1):
        if (ph[i] + 180) * (ph[i + 1] + 180) <= 0 and (fc is None or freqs[i] >= fc * 0.999):
            t = (-180 - ph[i]) / (ph[i + 1] - ph[i]) if ph[i + 1] != ph[i] else 0
            m = mag[i] * (mag[i + 1] / mag[i]) ** t
            gm = -20 * np.log10(m)
            break
    pm_min = min([c[1] for c in crossings]) if crossings else pm
    return dict(fc=fc, pm=pm, gm=gm, crossings=crossings, pm_worst=pm_min)
