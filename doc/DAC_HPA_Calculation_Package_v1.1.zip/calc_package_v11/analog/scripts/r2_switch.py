"""Round 2: effects of the Toshiba TLP3545A(TP1,F) output switch (D-1; K601-K604, one per leg, A connection pins 4-6,
pin 5 open) on the analog specifications: output impedance (3.5 mm one switch, 4.4 mm two in series), L/R mismatch,
crosstalk, open-switch isolation, THD contribution bound (protection p01 method checked and re-run with TLP3545A data).
Datasheet (Toshiba TLP3545A, 2020-03-17 / 2023-05-26): RON 35 typ / 60 max mOhm (A connection, ION 3 A, IF 5 mA, 25 C);
COFF 640 pF typ (0 V, 1 MHz); CS 0.8 pF typ (input-output); IOFF 0.01 uA typ at 60 V; tON <= 5 ms / tOFF <= 0.5 ms (IF 5 mA);
PO 700 mW derated 7.0 mW/K above 25 C (-> 143 K/W to Tj 125 C) [DS].  RON x 1.35 at 60 C [DEC D-1 / ASSUMP].
Output: ../out/r2_switch.txt"""
import os, sys, math
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from r2_common import *

OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
L = []; p = L.append

# ------------------------------------------------------------------ 1 output impedance
p('1. OUTPUT IMPEDANCE AT 1 kHz (requirement <= 0.5 ohm incl. contacts and the switch) [CALC]')
for lab, ron in (('60 C, RON max x 1.35', RON_HOT), ('25 C, RON max', RON25_MAX), ('typical', RON_TYP)):
    se = ZO_CL + R_LINK + ron + R_TRACE_SE + 2 * R_CONTACT
    bal = 2 * ZO_CL + 2 * R_LINK + 2 * ron + R_TRACE_BAL + 2 * R_CONTACT
    p('  %-22s: 3.5 mm (OPA1622 %.2f mOhm + link %.3f + switch %.3f + trace %.3f + tip/sleeve 2 x %.3f) = %.3f ohm;'
      ' 4.4 mm (2 x OPA1622 + 2 links + 2 switches %.3f + traces %.3f + 2 contacts) = %.3f ohm'
      % (lab, ZO_CL * 1e3, R_LINK, ron, R_TRACE_SE, R_CONTACT, se, 2 * ron, R_TRACE_BAL, bal))
p('  -> worst 0.251 / 0.383 ohm (margins 0.249 / 0.117 ohm); round-1 0.27 / 0.32 ohm (relay placeholder 0.1 ohm, one contact) superseded.')
p('  20 kHz: OPA1622 6.7 mOhm closed loop + path inductance (switch 5-15 nH + trace 10 nH: <= 3 mOhm) -> < 0.26 / 0.39 ohm.')

# ------------------------------------------------------------------ 2 L/R mismatch
p(''); p('2. L/R MISMATCH FROM THE SWITCHES (RON min not specified -> bound 0 ... %.3f ohm per switch) [CALC]' % RON_HOT)
for jack, R, bal in (('3.5 mm', 16, False), ('3.5 mm', 32, False), ('3.5 mm', 300, False), ('4.4 mm', 32, True), ('4.4 mm', 60, True), ('4.4 mm', 300, True)):
    dr = (2 if bal else 1) * RON_HOT
    rs = RSER_BAL if bal else RSER_SE
    d = 20 * math.log10((R + rs) / (R + rs - dr))
    p('  %s %3d ohm: dR <= %.3f ohm -> level mismatch <= %.3f dB (requirement channel balance <= 0.3 dB after the +-0.05 dB trim)' % (jack, R, dr, d))
p('  -> worst 0.044 dB (16 ohm SE / 32 ohm balanced); after the per-channel trim (+-0.05 dB, calibrated at one load) <= 0.094 dB.')

# ------------------------------------------------------------------ 3 crosstalk and open-switch isolation
p(''); p('3. CROSSTALK AND OPEN-SWITCH ISOLATION [CALC]')
for rg in (2e-3, 5.7e-3):
    p('  3.5 mm shared return %.1f mOhm into 32 ohm: %.1f dB (req <= -75 dB); the switches sit in the hot legs, not in the shared return -> unchanged' % (rg * 1e3, 20 * math.log10(rg / 32)))
zv = ZO_CL + R_LINK + RON_HOT
for cc in (0.3e-12,):
    x = 20 * math.log10(2 * math.pi * 20e3 * cc * zv)
    p('  switch-to-switch coupling (separate DIP6 packages, layout rule <= %.1f pF between a JACK/LEG net of one channel and the other) into a closed'
      ' switch (victim source %.3f ohm): %.0f dB at 20 kHz (32 and 300 ohm alike)' % (cc * 1e12, zv, x))
p('  LED strings (K601+K602 = L, K603+K604 = R) carry DC only while the switch is closed; LED-current noise through CS 0.8 pF into a %.3f ohm'
  ' victim is < -200 dB -> no contribution; balanced -100 dB rule (<= 0.3 pF at 300 ohm) unchanged' % zv)
for R in (32, 300):
    for f in (1e3, 20e3):
        att = 20 * math.log10(R / abs(R + 1 / (2j * math.pi * f * COFF_TYP)))
        p('  open switch (COFF %.0f pF typ) leg -> %3d ohm headphone at %5.0f Hz: %.0f dB (not a requirement: open only for DC faults, muted transitions)'
          % (COFF_TYP * 1e12, R, f, att))

# ------------------------------------------------------------------ 4 THD bound
p(''); p('4. THD CONTRIBUTION OF THE CONDUCTING SWITCH (protection p01 method, re-derived and re-run) [CALC on ASSUMP]')
p('  Check of the method: A connection = two identical MOSFETs in anti-series.  In the triode region I = k[(Vov)V - V^2/2]; the forward device')
p('  sees V1 = v + v^2/(2Vov) + v^3/(2Vov^2), the reverse device (its effective Vgs rises by |V2|) V2 = v - v^2/(2Vov) + v^3/(2Vov^2), v = I/(k Vov):')
p('  even orders cancel, V1 + V2 = 2v + v^3/Vov^2 -> HD3 = Vsw^3/(32 Vov^2) with Vsw = I RON (p01 formula confirmed).  Self-heating: P(2f) = I^2 RON/2,')
p('  dT = P |Zth(2f)|, R(t) = R0(1 + a dT cos 2wt) -> HD3 = Vsw a dT/2 (p01 formula confirmed; the DC Rth as |Zth(2f)| bound is conservative).')
VOV = 3.0                       # gate overdrive [ASSUMP, not in the datasheet; photovoltaic drive at IF 5 mA]
ALPHA = (RON_TC - 1) / 35.0     # 1 %/K implied by x1.35 at 60 C
p('  Inputs: RON %.3f ohm (60 C), Vov >= %.0f V [ASSUMP], a = %.1f %%/K [DEC D-1 x1.35], |Zth(2f)| <= Rth %.0f K/W [DS-derived from the PO derating]'
  % (RON_HOT, VOV, ALPHA * 100, RTH_SW))
worst300 = -400
for lab, R, nsw, vpk in (('3.5 mm SE 32 ohm', 32, 1, VFS), ('3.5 mm SE 16 ohm (not rated)', 16, 1, VFS), ('4.4 mm bal 32 ohm (not rated)', 32, 2, 2 * VFS),
                         ('4.4 mm bal 60 ohm', 60, 2, 2 * VFS), ('3.5 mm SE 300 ohm', 300, 1, VFS), ('4.4 mm bal 300 ohm (THD+N requirement point)', 300, 2, 2 * VFS)):
    i = vpk / R
    vsw = i * RON_HOT
    hd_ch = nsw * vsw ** 3 / (32 * VOV ** 2)
    dT = i * i * RON_HOT / 2 * RTH_SW
    hd_th = nsw * vsw * ALPHA * dT / 2
    tot = 20 * math.log10((hd_ch + hd_th) / vpk)
    if R == 300: worst300 = max(worst300, tot)
    p('  %-46s I %6.1f mA pk, Vsw %5.2f mV/switch: channel HD3 %5.0f dB, self-heating HD3 <= %5.0f dB (dT(2f) <= %.1f mK) -> <= %.0f dB'
      % (lab, i * 1e3, vsw * 1e3, 20 * math.log10(hd_ch / vpk), 20 * math.log10(hd_th / vpk), dT * 1e3, tot))
p('  -> at the THD+N requirement point (300 ohm, 1 kHz, calibrated 0 dBFS) the switch adds <= %.0f dB (requirement -105 dB, budget -112.9 dB typ unchanged);'
  ' rated low-impedance loads <= -128 dB; the weakest bound is 32 ohm balanced (not rated) at -111 dB near 20 Hz.' % worst300)
p('  Body diodes: Vsw <= 16 mV (0.2 A x 0.081 ohm) << 0.5 V -> never conduct.  Jack-side ESD diode (12 pF, C(V) symmetric, bidirectional): the nonlinear'
  ' current (<= 10 %% of 2 pi 20 kHz x 12 pF x 3.1 V = %.2f uA) flows through RON -> %.0f dB.  [MEAS] THD+N at LEG_xx vs JACK_xx with the same load (protection 12).'
  % (0.1 * 2 * math.pi * 20e3 * 12e-12 * 3.1 * 1e6, 20 * math.log10(0.1 * 2 * math.pi * 20e3 * 12e-12 * 3.1 * RON_HOT / 3.1)))

# ------------------------------------------------------------------ 5 interface facts
p(''); p('5. OTHER SWITCH FACTS USED BY THIS STREAM')
p('  Voltage stress: open switch sees <= |leg| 3.92 V + jack TVS clamp 16 V (ESD event) = 20 V << 60 V [DS]; closed: <= 0.25 A (rail-stuck into 16 ohm) << 3.0 A at 50 C.')
p('  Off-state leakage 0.01 uA typ (max not legible [not verified]) -> JACK node DC with no headphone set by the TVS leakage (<= 1 uA); no effect with a headphone.')
p('  Gate-drive charge injection: A connection with a floating photovoltaic gate drive is symmetric -> no net charge into either output terminal to first order'
  ' (island charge conservation); residual from device mismatch only.  LED edge coupling through CS: see dac_timing_pop.txt.')
open(os.path.join(OUT, 'r2_switch.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
