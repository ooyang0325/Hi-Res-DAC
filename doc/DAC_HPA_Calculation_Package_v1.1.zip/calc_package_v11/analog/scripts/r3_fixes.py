"""Round 3 (review fixes, decisions_r8c.md): X-8 I/V supply hold-up headroom and start-up numbers, X-7 R305 pull-up,
X-10 bead/2.2 uF resonance (B-07), VREF trim table (F4), 3V3A capacitance vs the LP5907 limit and the power-up pop
(F2 / states #8), power-down pop with the I2C ramp retry, R417-R420 ferrite-bead alternate (F5): output impedance and
leg stability.  Labels: [DS] [DS-typ] [CALC] [ASSUMP] [DEC].  Output: ../out/r3_fixes.txt"""
import os, sys, math, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mna_v import Circuit, margins
from models_v import OPA1622v

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'out')
L = []; p = L.append
VPOS_MIN, VNEG_MIN = 3.789, 3.661
VREF_HI, VREF_LO = 1.7062, 1.6340
CAL_HI = 2.802; UNTRIM_HI = 3.221; RESET = (2.907, 3.369)     # [CALC analog_budget.txt 2]
HR_600 = 0.6; HR_TYP_4MA = 0.246                               # (V+) - 0.6 V at 600 ohm [DS 25 C]; interpolated at 4.1 mA [CALC]

# ------------------------------------------------------------------ 1 X-8 headroom
p('1. X-8 SEPARATE I/V SUPPLIES (D411/D412 PMEG2010AEH-class Schottky, C442/C443 220 uF MnO2 tantalum KEMET T495D227K010ATE100, R3.12) - headroom [CALC]')
for vf, lab in ((0.30, 'VF max 0.30 V (0 C, 30 mA) [ASSUMP]'), (0.20, 'VF 0.20 V (typ 25 C, 20 mA) [ASSUMP]')):
    vp = VPOS_MIN - vf; vn = VNEG_MIN - vf
    lim = vp - HR_600; lim_t = vp - HR_TYP_4MA
    p('  %s: VPOS_IV >= %.3f V, |VNEG_IV| >= %.3f V; 600 ohm row limit %.3f V (typical %.3f V)' % (lab, vp, vn, lim, lim_t))
    d45 = VREF_HI + (UNTRIM_HI - VREF_HI) * 10 ** (-4.5 / 20)
    p('    calibrated full scale %.3f V -> margin %+.3f V (typ %+.3f V); -4.5 dB pre-calibration default %.3f V -> %+.3f V; untrimmed 0 dBFS (trim AND default lost) %.3f V -> %+.3f V'
      % (CAL_HI, lim - CAL_HI, lim_t - CAL_HI, d45, lim - d45, UNTRIM_HI, lim - UNTRIM_HI))
    p('    reset state %.3f..%.3f V -> %+.3f V (saturates: pin = Vsat Rs/(Rs+Rf) = %.3f..%.3f V inside 0..AVCC, input differential <= %.3f V, switch open, CM window trips at CM >= %.3f V)'
      % (RESET[0], RESET[1], lim - RESET[1], lim * 717 / (717 + 698), lim * 895 / (895 + 698), VREF_HI - lim * 717 / (717 + 698), min(RESET[0], lim)))
    p('    OPA2210 CM upper limit VPOS_IV - 1.5 V = %.3f V vs VREF %.3f V -> margin %.3f V (round 2: 0.583 V); lower side and V- swing unaffected (|VNEG_IV| >= %.2f V)'
      % (vp - 1.5, VREF_HI, vp - 1.5 - VREF_HI, vn))
p('  Hold-up (unplug_model_r3.txt, 1,944 corners): with 176 uF effective per rail (conservative: the T495 220 uF +-10 % gives >= 198 uF, no DC-bias loss) the OPA2210 stays powered and inside its CM')
p('  range until 3V3A < 0.3 V in every corner: clamp exposure 0 ms, DAC pins <= AVCC - 0.025 V (60 / 80 / 120 uF effective: 3.6 / 2.2 / 0 ms CM-violation exposure).')
for cn, cm in (('min', 176e-6), ('max', 264e-6)):
    qp = cm * 3.915; qn = cm * 3.781
    p('  start-up charge per reservoir (%s %.0f uF): VPOS_IV %.2f mC, VNEG_IV %.2f mC -> extra 5V_ANA current for a rail ramp of 10/20/40 ms: %.0f / %.0f / %.0f mA (I+ + 1.03 I-)'
      % (cn, cm * 1e6, qp * 1e3, qn * 1e3, (qp + 1.03 * qn) / 10e-3 * 1e3, (qp + 1.03 * qn) / 20e-3 * 1e3, (qp + 1.03 * qn) / 40e-3 * 1e3))
rd = 1.05 * 0.02585 / 0.0174
p('  steady state: diode dissipation <= 0.30 V x 17.4 mA = %.1f mW; dynamic resistance %.1f ohm with 176 uF -> %.0f Hz low-pass on the I/V supply (PSRR improves);'
  ' quiescent unchanged; reverse voltage in hold-up <= 3.9 V vs 20 V; start-up peak current <= C dV/dt (264 uF x 3.9 V / 5 ms = %.0f mA) vs 1 A'
  % (0.30 * 17.4, rd, 1 / (2 * math.pi * rd * 176e-6), 264e-6 * 3.9 / 5e-3 * 1e3))

# ------------------------------------------------------------------ 2 X-7 R305
p(''); p('2. X-7 R305 10 kOhm pull-up DAC_RESETB -> DVCC, Q207 open-drain (digital) [CALC]')
dvcc_min = 3.3 * 0.99 - 14.2e-3 * 0.45
vih = dvcc_min / 2 + 0.4
ileak = 1e-6 + 10e-6
p('  VIH >= DVCC/2 + 0.4 V = %.2f V [DS ESS p.29] (DVCC >= %.3f V: TLV767 -1 %% minus FB301 drop); released level >= DVCC - %.0f uA x 10 k = %.3f V (Q207 IDSS 1 uA [ASSUMP] + RESETB leakage 10 uA [ASSUMP, not in ESS DS])'
  % (vih, dvcc_min, ileak * 1e6, dvcc_min - ileak * 1e4))
p('  VIL <= 0.4 V: Q207 on sinks %.2f mA -> VOL <= %.1f mV with RDS(on) <= 10 ohm at VGS >= 3.0 V [ASSUMP, digital part]; rise 10-90 %% = 2.2 x 10 k x (5 pF CIN + 10 pF Coss + 3 pF) = %.2f us (no ESS slew limit; reset pulse >= 10 ns)'
  % (3.3 / 10e3 * 1e3, 3.3 / 10e3 * 10 * 1e3, 2.2 * 10e3 * 18e-12 * 1e6))
p('  DVCC load 0.33 mA only while Q207 holds reset; 3V3D off -> RESETB = 0 V (no back-power, states #17); MCU in reset -> PA8 pulled up -> Q207 on -> DAC in reset')

# ------------------------------------------------------------------ 3 bead + 2.2 uF resonance
p(''); p('3. B-07 FB301/FB302 (Sunlord GZ1608D601TF, DCR 0.45 ohm max, L not published) with 100 nF, before/after adding 2.2 uF [CALC, L ASSUMP 0.5-3 uH]')
for lab, cs in (('round 2: 100 nF only', [(0.1e-6 * 0.9 * 0.85, 0.1e-6 * 1.1 * 0.95)]), ('round 3: + 2.2 uF (C439 / C440)', [(0.1e-6 * 0.9 * 0.85 + 2.2e-6 * 0.9 * 0.6, 0.1e-6 * 1.1 * 0.95 + 2.2e-6 * 1.1 * 0.85)])):
    rows = []
    for (cmin, cmax) in cs:
        for Lb in (0.5e-6, 1e-6, 2e-6, 3e-6):
            for C in (cmin, cmax):
                for R in (0.20, 0.45):
                    f0 = 1 / (2 * math.pi * math.sqrt(Lb * C)); z0 = math.sqrt(Lb / C); q = z0 / (R + 0.01)
                    rows.append((f0, z0, q))
    p('  %-32s f0 %.0f..%.0f kHz, Z0 %.2f..%.2f ohm, Q %.1f..%.1f (peak gain <= %.1f dB); 5 mA DVCC step rings <= %.1f mV'
      % (lab, min(r[0] for r in rows) / 1e3, max(r[0] for r in rows) / 1e3, min(r[1] for r in rows), max(r[1] for r in rows),
         min(r[2] for r in rows), max(r[2] for r in rows), 20 * math.log10(max(max(r[2] for r in rows), 1)), 5e-3 * max(r[1] for r in rows) * 1e3))
p('  -> with the 2.2 uF the resonance moves to 63-200 kHz and Q drops from <= 29.8 to <= 7.3 (<= 3.4 at the maximum DCR 0.45 ohm); ringing on a 5 mA step <= 7.7 mV;'
  ' the residual peak (<= 17 dB only if the bead DCR is at its unspecified low end) acts on microvolt-level 3V3A/3V3D noise; ramps/discharges change by < 5 us (DCR x C).')

# ------------------------------------------------------------------ 4 VREF trim table
p(''); p('4. F4 VREF trim footprints R446 (parallel to R431 9.76 k: raises VREF) and R447 (parallel to R432 10.0 k: lowers VREF) [CALC]')
k0 = 10.0 / (9.76 + 10.0)
p('  untrimmed VREF/3V3A = %.5f (1.670 V at 3.300 V)' % k0)
for rt in (237e3, 332e3, 487e3, 1.0e6, 2.0e6):
    rtop = 1 / (1 / 9760 + 1 / rt); kup = 10000 / (rtop + 10000)
    rbot = 1 / (1 / 10000 + 1 / rt); kdn = rbot / (9760 + rbot)
    p('  R_trim %5.0f k: on R446 -> k %.5f (%+.2f %%, %+.1f mV); on R447 -> k %.5f (%+.2f %%, %+.1f mV)'
      % (rt / 1e3, kup, (kup / k0 - 1) * 100, (kup - k0) * 3300, kdn, (kdn / k0 - 1) * 100, (kdn - k0) * 3300))
p('  Use: the dominant unguaranteed offset term is g x (DAC pair mismatch) x (VREF - Vnull), with Vnull common to all four pins; the 25 C screen measures each leg,'
  ' firmware/production picks one trim resistor to move VREF toward the null (up to +-35.6 mV = the whole |VREF - Vnull| range with 237/243 k). A trim keeps VREF/3V3A inside'
  ' 0.4958..0.5175; protection p04 verified 0.50526..0.50689 -> fitting a trim needs protection change control (their original window covered 0.500..0.516: trims >= 487 k stay inside).')
p('  Trim resistor tolerance/TCR barely matter: R_trim >= 237 k in parallel with 10 k carries <= 4 % weight (1 %/100 ppm thick film adds <= 0.04 % / 4 ppm to the ratio).')

# ------------------------------------------------------------------ 5 3V3A capacitance vs LP5907 and power-up pop
p(''); p('5. 3V3A capacitance (LP5907 COUT 0.7-10 uF effective [DS]) and the power-up pop through COFF [CALC]')
parts = [('C302 2.2 uF 16 V (power)', 2.2e-6, 0.60, 0.85), ('C303 2.2 uF (AVCC_L via 2.2 ohm)', 2.2e-6, 0.60, 0.85), ('C304 2.2 uF (AVCC_R via 2.2 ohm)', 2.2e-6, 0.60, 0.85),
         ('C440 2.2 uF (VCCA via FB302, new)', 2.2e-6, 0.60, 0.85), ('C305/C306/C307 3 x 100 nF X7R', 0.3e-6, 0.85, 0.95)]
cmin = sum(c * 0.9 * a for _, c, a, b in parts); cmax = sum(c * 1.1 * b for _, c, a, b in parts)
c441 = (1e-6 * 0.9 * 0.80, 1e-6 * 1.1 * 0.95)
p('  effective (tol -10/+10 %%, DC bias at 3.3 V 0.60..0.85 for 2.2 uF 16 V 0603, 0.80..0.95 for 1 uF 50 V, 0.85..0.95 for X7R [ASSUMP]): %.2f..%.2f uF; with DNF C441 1 uF fitted %.2f..%.2f uF (limit 10 uF)'
  % (cmin * 1e6, cmax * 1e6, (cmin + c441[0]) * 1e6, (cmax + c441[1]) * 1e6))
p('  power stream counting (no DC-bias credit, 2.53 uF per 2.2 uF part, report R2.x: 7.59 uF): with C440 10.12 uF, with C441 11.27 uF -> above 10 uF on that basis; C440 sits behind')
p('  FB302 (>= 10 ohm above ~1 MHz [ASSUMP]) and is isolated at the LDO loop frequencies -> power stream to confirm the LP5907 limit; C441 is DNF and fitted only after that confirmation.')
ISC_MAX = 0.75
def pop(dv, tr, C, R):
    return R * C * dv * min(2 * math.pi * 20e3, 1.0 / tr)
def v_reset(delta):
    G = 2000.0 / 1980.0
    rn, rp = 806 * (1 - delta / 2), 806 * (1 + delta / 2)
    return G * VREF_HI * 698 * (1 / rn - 1 / rp) + 2 * 0.001625 * 3.37
for lab, c in (('as fitted', cmin), ('with DNF C441 fitted', cmin + c441[0])):
    tr = c * 3.3 / ISC_MAX
    s = '  %-22s: 3V3A rise >= %.1f us (C_eff min %.2f uF, LP5907 current limit <= 0.75 A [ASSUMP 1.5 x 500 mA typ])' % (lab, tr * 1e6, c * 1e6)
    p(s)
    for delta in (0.03, 0.22):
        dv = v_reset(delta)
        p('     pin mismatch %2.0f %%: step %.3f V -> 300 ohm %.2f mV (COFF 1 nF) / %.2f mV (960 pF) / %.2f mV (640 pF typ); 32 ohm %.2f mV; margin to 5 mV at 1 nF %+.0f %%'
          % (delta * 100, dv, pop(dv, tr, 1e-9, 300) * 1e3, pop(dv, tr, 0.96e-9, 300) * 1e3, pop(dv, tr, 0.64e-9, 300) * 1e3, pop(dv, tr, 1e-9, 32) * 1e3,
             (5e-3 / pop(dv, tr, 1e-9, 300) - 1) * 100))
p('  typical (640 pF, 3 %% mismatch, LP5907 typical rise 40-75 us): <= %.2f mV' % (pop(v_reset(0.03), 40e-6, 0.64e-9, 300) * 1e3))

# ------------------------------------------------------------------ 6 power-down pop with the I2C retry
p(''); p('6. Power-down pop (switch already open) with the I2C ramp-to-ground and its retry [CALC]')
t_ramp = 4096 * 2 ** 4 / 80e6
p('  normal: reg 14 = 0x03 ramp %.3f ms -> 300 ohm %.3f mV (22 %%)' % (t_ramp * 1e3, pop(v_reset(0.22), t_ramp, 1e-9, 300) * 1e3))
p('  write NACKed, retry once (decisions_r8c firmware): same result when the retry succeeds')
p('  both writes fail -> firmware fallback order (proposed to digital): MCLK off -> AVCC_EN low FIRST (DAC not in reset, silent stream = null code; 3V3A discharge tau >= 70 us)'
  ' -> RESETB low only after 3V3A < 0.1 V -> AUD_EN low.  The legs move only by the CM leakage + null terms (<= 2.56 + 7.9 mV at 22 %%) over >= 70 us: 300 ohm %.3f mV'
  % (pop(10.5e-3, 70e-6, 1e-9, 300) * 1e3))
p('  (without the fallback order, RESETB low as an edge would couple %.1f mV (22 %%) / %.1f mV (3 %%) at 300 ohm)' % (pop(v_reset(0.22), 0.5e-6, 1e-9, 300) * 1e3, pop(v_reset(0.03), 0.5e-6, 1e-9, 300) * 1e3))
# re-evaluation after digital R3 (09:01): X-6 U605B pulls AUD_EN low at 3V3A < 3.10 V, so DVCC/DVDD collapse together with 3V3A
k_trip = 3.125 / 3.366   # protection R3: U605B/Q620 trip at 3V3A 3.006-3.125 V, AUD_EN low <= 1.04 ms later
p('  RE-EVALUATION (digital R3, X-6 U605B): AUD_EN is pulled low (U605B/Q620, protection R3) <= 1.04 ms after 3V3A < 3.006-3.125 V, so DVCC/DVDD may collapse (3V3D tau 74-152 us,'
  ' power c06) while 3V3A (tau 70-90 us) is still near 3.1 V.  The ES9018K2M output state on a DVCC/DVDD collapse under live AVCC is not specified'
  ' (reset/ground state or a frozen modulator code), and without the ramp the MCLK stop itself freezes an unspecified instantaneous code.  Worst case = the reset step at'
  ' VREF(3V3A 3.125 V) as an edge: 300 ohm %.1f mV (22 %%) / %.1f mV (3 %%); 0.045 mV holds only if 3V3A has decayed before the DAC digital stops.  Order "RESETB first" gives'
  ' %.1f / %.1f mV, so the fallback order is never worse; the double-I2C-failure path is a logged fault, not a controlled transition.'
  % (pop(v_reset(0.22) * k_trip, 0.5e-6, 1e-9, 300) * 1e3, pop(v_reset(0.03) * k_trip, 0.5e-6, 1e-9, 300) * 1e3,
     pop(v_reset(0.22), 0.5e-6, 1e-9, 300) * 1e3, pop(v_reset(0.03), 0.5e-6, 1e-9, 300) * 1e3))
# X-8 start-up: I/V rails vs T_START (digital R3 question)
p('')
p('6b. X-8 start-up vs the digital T_START: VPOS_IV/VNEG_IV follow VPOS/VNEG minus VF (<= 0.30 V) with a lag of r_d x C = 1.6 ohm x 264 uF = %.2f ms;'
  ' charging current at a 40 ms ramp 264 uF x 3.9 V / 40 ms = %.0f mA (+17 mA load) << the 250 mA LM27762 LDO rating -> VPOS_IV/VNEG_IV >= +-2.25 V within 0.5 ms'
  ' after the main rails pass +-2.55 V, and at their final values <= 1 ms after the rails are good.  T_START >= (rails-good time) + 1 ms is sufficient; the digital'
  ' T_START = max(20 ms, 1.25 x c11) has >= 9 ms margin for a >= 40 ms ramp.' % (1.6 * 264e-6 * 1e3, 264e-6 * 3.9 / 40e-3 * 1e3))

# ------------------------------------------------------------------ 7 R417-R420 bead alternate
p(''); p('7. F5 R417-R420 approved alternate: Murata BLM15PX330SN1D (0402, 33 ohm +-25 % at 100 MHz, 3 A, DCR <= 0.022 ohm [DS Murata]) [CALC]')
Lb, Rp = 33.0 / (2 * math.pi * 100e6), 40.0
for f in (1e3, 20e3):
    z = 0.022 + (1j * 2 * math.pi * f * Lb * Rp) / (Rp + 1j * 2 * math.pi * f * Lb)
    p('  |Z| at %5.0f Hz = %.4f ohm (0 ohm link budget 0.050 ohm) -> 3.5 mm output impedance %.3f ohm, 4.4 mm %.3f ohm (req <= 0.5)' % (f, abs(z), 0.251 - 0.05 + abs(z), 0.383 - 0.10 + 2 * abs(z)))
p('  ESD with the switch closed: TVS clamp <= 16 V, OPA1622 output diode path at ~4.5 V -> op-amp current <= (16 - 4.5 V)/(33 ohm x 0.75) = %.2f A for the ns-scale event vs OPA1622 HBM 4 kV (~2.7 A) [CALC]'
  % ((16 - 4.5) / (33 * 0.75)))
FR = np.logspace(3, 8.7, 600)
def build(load, CL, op, cable, bead, Ct=1.8e-9, Cl=10e-12):
    c = Circuit()
    c.R('sA', '0', 20.0); c.R('sB', '0', 20.0)
    c.R('sA', 'mA', 1300.0); c.R('mA', 'N', 680.0); c.C('mA', '0', Ct)
    c.R('sB', 'mB', 1300.0); c.R('mB', 'P', 680.0); c.C('mB', '0', Ct)
    c.R('N', 'OUT', 2000.0); c.C('N', 'OUT', Cl); c.R('P', '0', 2000.0); c.C('P', '0', Cl)
    c.OPAMP('U', 'P', 'N', 'OUT', op.A, op.Zo)
    c.C('P', 'N', op.CIN_DIFF); c.C('P', '0', op.CIN_CM + 1.5e-12); c.C('N', '0', op.CIN_CM + 1.5e-12)
    if bead:
        c.R('OUT', 'b1', 0.022); c.L('b1', 'LEGx', Lb); c.R('b1', 'LEGx', Rp); c.C('b1', 'LEGx', 0.3e-12); c.L('LEGx', 'LEG', 3e-9)
    else:
        c.R('OUT', 'lk', 0.05); c.L('lk', 'LEG', 5e-9)
    c.R('LEG', '0', 6.8e3); c.C('LEG', '0', 6e-12)            # R10 F-1 leg taps (was R601-R604 105 k to AC ground, 5 pF)
    c.R('LEG', 'tor', 330e3); c.C('tor', '0', 1e-9 + 4e-12); c.R('LEG', 'tlp', 1.0e6); c.C('tlp', '0', 3.3e-9 + 4e-12)
    c.R('LEG', 'k', 0.081); c.L('k', 'JACK', 15e-9); c.C('JACK', '0', 15e-12)
    if load != 'open':
        if CL: c.C('JACK', '0', CL)
        if cable:
            prev = 'JACK'
            for i in range(3):
                c.R(prev, 'cr%d' % i, 0.2); c.L('cr%d' % i, 'cn%d' % i, 0.6e-6); c.C('cn%d' % i, '0', 100e-12); prev = 'cn%d' % i
            c.R(prev, 'hp', load); c.L('hp', '0', 30e-6)
        else:
            c.R('JACK', '0', load)
    return c
MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]
OPS = {m: OPA1622v(*m) for m in MODELS}
LOADS = [('open', 0, False)] + [(r, c, False) for r in (16, 32, 60, 300, 600) for c in (0, 100e-12, 220e-12, 470e-12, 1e-9)] \
        + [(r, 1e-9, True) for r in (16, 32, 300, 600)] + [(r, 2e-12, True) for r in (32, 300)] + [(r, 2e-9, False) for r in (16, 32, 300, 600)]
for bead in (False, True):
    pm_m, gm_m, pm_s = 999, 999, 999
    for (load, CL, cable) in LOADS:
        for mk in MODELS:
            for dct, dcl in ((1, 0), (0.95, -0.5e-12), (1.05, 0.5e-12)):
                m = margins(FR, build(load, CL, OPS[mk], cable, bead, Ct=1.8e-9 * dct, Cl=10e-12 + dcl).loop_gain(FR, 'U'))
                pm = m['pm_worst'] if m['pm_worst'] is not None else 999
                if CL <= 1e-9:
                    pm_m = min(pm_m, pm)
                    if m['gm'] is not None: gm_m = min(gm_m, m['gm'])
                else:
                    pm_s = min(pm_s, pm)
    p('  leg stability, switch closed (RON 0.081 ohm, 15 nH), %-26s: worst PM %.1f deg, min GM %.1f dB (0-1 nF + cable); 2 nF stress %.1f deg'
      % ('0 ohm link (R417-R420)' if not bead else 'BLM15PX330SN1D bead', pm_m, gm_m, pm_s))
open(os.path.join(OUT, 'r3_fixes.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
