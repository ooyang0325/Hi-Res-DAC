"""Validate the OPA1622 macro-model against TI SBOS727B Fig. 24 (phase margin vs capacitive load,
G = +1 and G = -1, typical, +-18 V, RL = 2 kOhm assumed from the Typical Characteristics header).
Writes ../out/validate_opa1622.txt"""
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna import Circuit, margins
from opamp_models import OPA1622, DIG

OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
fr = np.logspace(3, 8.6, 700)


def pm_config(op, gain, CL, RL=2e3, Rf=1e3):
    T = []
    for f in fr:
        c = Circuit()
        if gain == 1:
            c.OPAMP('U', 'inp', 'out', 'out', op.A, op.Zo)
            c.R('inp', '0', 50.0)
        else:  # inverting G = -Rf/Rin with Rin = Rf, source grounded
            c.OPAMP('U', 'inp', 'inn', 'out', op.A, op.Zo)
            c.R('inp', '0', 1.0)
            c.R('inn', '0', Rf); c.R('inn', 'out', Rf)
        c.C('inp', '0', op.CIN_CM)
        c.R('out', '0', RL); c.C('out', '0', CL)
        T.append(c.loop_gain(f, 'U'))
    return margins(fr, np.array(T))


lines = []
op = OPA1622()
lines.append('OPA1622 model: fp1 = %.2f Hz, A0 = %.0f dB, Zo fit R0=%.2f R1=%.2f L1=%.3g R2=%.2f L2=%.3g (rms fit error %.1f %%)'
             % (op.fp1, op.A0_DB, *op.zo_par, op.zo_fit_rms_pct))
for fq in [1e3, 1e5, 1e6, 4e6, 7.6e6, 1e7, 2e7, 5e7, 1e8]:
    z = op.Zo(fq)
    lines.append('  Zo(%8.3g Hz) = %6.2f ohm  angle %5.1f deg' % (fq, abs(z), np.angle(z, deg=True)))
ref = {k: v for k, v in DIG['fig24'].items()}
cols = list(ref.keys())
lines.append('Fig. 24 check (digitized TI typical vs model), RL = 2 kOhm:')
lines.append('   CL(pF)   TI G=+1   model G=+1   TI G=-1   model G=-1')
res = []
for CLp in [10, 30, 50, 91, 300, 500, 1000]:
    m1 = pm_config(op, 1, CLp * 1e-12)['pm_worst']
    m2 = pm_config(op, -1, CLp * 1e-12)['pm_worst']
    t1 = np.interp(CLp, [a for a, b in ref[cols[0]]], [b for a, b in ref[cols[0]]])
    t2 = np.interp(CLp, [a for a, b in ref[cols[1]]], [b for a, b in ref[cols[1]]])
    res.append((CLp, t1, m1, t2, m2))
    lines.append('   %6d   %7.1f   %10.1f   %7.1f   %10.1f' % (CLp, t1, m1, t2, m2))
err1 = max(abs(r[1] - r[2]) for r in res if r[0] <= 500)
err2 = max(abs(r[3] - r[4]) for r in res)
lines.append('max |error| G=+1 (<=500 pF) = %.1f deg ; G=-1 = %.1f deg' % (err1, err2))
open(os.path.join(OUT, 'validate_opa1622.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
