import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '../..'))
"""Digitize vector curves of TI OPA1622 datasheet (SBOS727B, external/input/opa1622.pdf).
Frames/tick positions were located with pdf_dump_region.py; mapping is linear or log per axis.
Output: ../ds/opa1622_digitized.json and a printed summary. Typical curves (25 C) only."""
import json, math, pdfplumber
PDF = _PKG_ROOT + '/external/input/opa1622.pdf'
pdf = pdfplumber.open(PDF)

def curves_in(page, x0, x1, y0, y1):
    res = []
    for c in pdf.pages[page].curves:
        xs = [q[0] for q in c['pts']]; ys = [q[1] for q in c['pts']]
        if min(ys) >= y0 and max(ys) <= y1 and min(xs) >= x0 and max(xs) <= x1 and (c.get('linewidth') or 0) > 0.5:
            res.append((str(c.get('stroking_color')), c['pts']))
    return res

def lin(v, p0, v0, p1, v1):
    return v0 + (v - p0) * (v1 - v0) / (p1 - p0)

def logm(v, p0, v0, p1, v1):
    return 10 ** (math.log10(v0) + (v - p0) * (math.log10(v1) - math.log10(v0)) / (p1 - p0))

out = {}
# Figure 10: open-loop gain (black) and phase (red) vs frequency, page index 7
# x: 346.0 -> 1 Hz, 517.7 -> 100 MHz (log); gain y: 296.7 -> 140 dB, 420.1 -> -20 dB; phase y: 296.7 -> 225, 420.1 -> 45
f10 = {'gain': [], 'phase': []}
for col, pts in curves_in(7, 340, 520, 290, 425):
    for (x, y) in pts:
        f = logm(x, 346.0, 1, 517.7, 1e8)
        if col == '0.0':
            f10['gain'].append((f, lin(y, 296.7, 140, 420.1, -20)))
        else:
            f10['phase'].append((f, lin(y, 296.7, 225, 420.1, 45)))
for k in f10: f10[k].sort()
out['fig10'] = f10
# Figure 24: phase margin vs capacitive load, page 9; x: 355.8 -> 0 pF, 538.4 -> 1000 pF; y: 607.2 -> 0 deg, 482.9 -> 90 deg
f24 = {}
for col, pts in curves_in(9, 350, 545, 478, 612):
    f24[col] = sorted((lin(x, 355.8, 0, 538.4, 1000), lin(y, 607.2, 0, 482.9, 90)) for (x, y) in pts)
out['fig24'] = f24
json.dump(out, open(_PKG_ROOT + '/analog/ds/opa1622_digitized.json', 'w'), indent=1)

def interp(data, xq):
    for (xa, ya), (xb, yb) in zip(data, data[1:]):
        if xa <= xq <= xb:
            return ya + (yb - ya) * (xq - xa) / (xb - xa)
    return None
g = f10['gain']; ph = f10['phase']
print('Fig10 gain range f=%.3g..%.3g Hz' % (g[0][0], g[-1][0]))
for fq in [2e4, 1e5, 3e5, 1e6, 2e6, 4e6, 6e6, 8e6, 1e7, 1.5e7, 2e7, 3e7]:
    print('  f=%8.3g Hz  gain=%6.2f dB  phase=%6.1f deg' % (fq, interp(g, fq) or float('nan'), interp(ph, fq) or float('nan')))
# unity crossing
for (fa, ga), (fb, gb) in zip(g, g[1:]):
    if ga >= 0 > gb:
        fc = fa * (fb / fa) ** (ga / (ga - gb)); print('  0 dB crossing ~ %.3g Hz, phase there %.1f deg' % (fc, interp(ph, fc)))
for col, d in f24.items():
    print('Fig24 curve', col, ['(%.0f pF, %.1f deg)' % p for p in d])
