"""Vectorised (over frequency) complex MNA AC solver.

Circuit elements take functions of a numpy frequency array f (Hz) returning complex arrays:
  R(a,b,v)  C(a,b,v)  L(a,b,v)  Z(a,b,func)  V(name,a,b,value)  I(a,b,value)
  OPAMP(name, inp, inn, out, A, Zo)  -> internal ideal VCVS  Vint = A(f)*(V(inp)-V(inn)),  then Zo(f) to out.
Node '0' is ground.  loop_gain(f, name) breaks the named op-amp at its ideal VCVS (exact, because the
VCVS has zero output and infinite input impedance) and returns T = -A*(V(inp)-V(inn))/Vtest.
"""
import numpy as np


class Circuit:
    def __init__(self):
        self.el = []
        self.nodes = {'0': -1}

    def _n(self, name):
        if name not in self.nodes:
            self.nodes[name] = len(self.nodes) - 1
        return self.nodes[name]

    def R(self, a, b, v):
        self.el.append(('Z', a, b, lambda f, v=v: np.full(f.shape, complex(v))))

    def C(self, a, b, v):
        if v and v > 0:
            self.el.append(('Z', a, b, lambda f, v=v: 1.0 / (2j * np.pi * f * v)))

    def L(self, a, b, v):
        self.el.append(('Z', a, b, lambda f, v=v: 2j * np.pi * f * v + 1e-6))

    def Z(self, a, b, func):
        self.el.append(('Z', a, b, func))

    def V(self, name, a, b, v):
        self.el.append(('V', name, a, b, v))

    def I(self, a, b, v):
        self.el.append(('I', a, b, v))

    def OPAMP(self, name, inp, inn, out, A, Zo):
        self.el.append(('OA', name, inp, inn, out, A, Zo))

    def solve(self, f, broken=None, vtest=1.0):
        f = np.asarray(f, dtype=float)
        for e in self.el:
            if e[0] == 'Z': self._n(e[1]); self._n(e[2])
            elif e[0] == 'V': self._n(e[2]); self._n(e[3])
            elif e[0] == 'I': self._n(e[1]); self._n(e[2])
            elif e[0] == 'OA':
                for nn in (e[2], e[3], e[4], e[1] + '#int'): self._n(nn)
        N = len(self.nodes) - 1
        vs = [e for e in self.el if e[0] in ('V', 'OA')]
        M = N + len(vs)
        nf = f.size
        Y = np.zeros((nf, M, M), dtype=complex)
        rhs = np.zeros((nf, M), dtype=complex)

        def sy(a, b, y):
            ia, ib = self.nodes[a], self.nodes[b]
            if ia >= 0: Y[:, ia, ia] += y
            if ib >= 0: Y[:, ib, ib] += y
            if ia >= 0 and ib >= 0:
                Y[:, ia, ib] -= y; Y[:, ib, ia] -= y

        for e in self.el:
            if e[0] == 'Z':
                sy(e[1], e[2], 1.0 / e[3](f))
            elif e[0] == 'I':
                ia, ib = self.nodes[e[1]], self.nodes[e[2]]
                if ia >= 0: rhs[:, ia] -= e[3]
                if ib >= 0: rhs[:, ib] += e[3]
            elif e[0] == 'OA':
                sy(e[1] + '#int', e[4], 1.0 / e[6](f))
        k = N
        for e in vs:
            if e[0] == 'V':
                ia, ib = self.nodes[e[2]], self.nodes[e[3]]
                if ia >= 0: Y[:, ia, k] += 1; Y[:, k, ia] += 1
                if ib >= 0: Y[:, ib, k] -= 1; Y[:, k, ib] -= 1
                rhs[:, k] = e[4]
            else:
                name, inp, inn, A = e[1], e[2], e[3], e[5]
                ii = self.nodes[name + '#int']
                Y[:, ii, k] += 1; Y[:, k, ii] += 1
                if broken == name:
                    rhs[:, k] = vtest
                else:
                    a = A(f)
                    ip, im = self.nodes[inp], self.nodes[inn]
                    if ip >= 0: Y[:, k, ip] -= a
                    if im >= 0: Y[:, k, im] += a
            k += 1
        x = np.linalg.solve(Y, rhs[..., None])[..., 0]
        nodes = self.nodes
        return lambda node: np.zeros(nf, complex) if node == '0' else x[:, nodes[node]]

    def loop_gain(self, f, name):
        e = [x for x in self.el if x[0] == 'OA' and x[1] == name][0]
        v = self.solve(f, broken=name)
        return -e[5](np.asarray(f, float)) * (v(e[2]) - v(e[3]))


def margins(freqs, T):
    mag = np.abs(T)
    ph = np.unwrap(np.angle(T)) * 180 / np.pi
    ph = ph - 360 * np.round(ph[0] / 360)
    crossings = []
    for i in range(len(freqs) - 1):
        if (mag[i] - 1) * (mag[i + 1] - 1) < 0:
            t = np.log(mag[i]) / (np.log(mag[i]) - np.log(mag[i + 1]))
            fx = freqs[i] * (freqs[i + 1] / freqs[i]) ** t
            crossings.append((fx, 180 + ph[i] + t * (ph[i + 1] - ph[i])))
    fc, pm = (crossings[0] if crossings else (None, None))
    gm = None
    start = 0
    if fc is not None:
        start = int(np.searchsorted(freqs, fc))
    for i in range(start, len(freqs) - 1):
        if (ph[i] + 180) * (ph[i + 1] + 180) <= 0:
            t = (-180 - ph[i]) / (ph[i + 1] - ph[i]) if ph[i + 1] != ph[i] else 0
            m = mag[i] * (mag[i + 1] / mag[i]) ** t
            gm = -20 * np.log10(m)
            break
    pm_worst = min([c[1] for c in crossings]) if crossings else None
    # smallest distance of T from -1 (vector margin), a robust single stability number
    vm = float(np.min(np.abs(1 + T)))
    return dict(fc=fc, pm=pm, gm=gm, crossings=crossings, pm_worst=pm_worst, vector_margin=vm)
