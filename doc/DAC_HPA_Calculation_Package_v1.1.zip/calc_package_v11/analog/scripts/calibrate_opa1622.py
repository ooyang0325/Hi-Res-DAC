"""Calibrate an 'effective' OPA1622 macro-model to TI SBOS727B Fig. 24 (PM vs CL, G=+1 and G=-1).
The Fig. 10 / Fig. 40 physical model is ~5 deg optimistic at low CL and much more at 0.5-1 nF,
so an extra pole px and an effective output network Zo = R0 + (R1 || s*L1) are fitted to the 14
Fig. 24 points (R0 = 5.47 ohm kept from Fig. 40).  Output: ../out/calibrate_opa1622.txt and
../ds/opa1622_calibrated.json (used by stability_legs.py as the 'CAL' model)."""
import os, sys, json, math, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna import Circuit, margins
from opamp_models import OPA1622, DIG

OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
fr = np.logspace(4, 8.5, 260)
base = OPA1622(extra_pole_hz=None)
A_tab = np.array([base.A(f) for f in fr])
ref = list(DIG['fig24'].items())
pts = []
for col, d in ref:
    g = 1 if col == '0.0' else -1
    for (cl, pm) in d:
        pts.append((g, cl, pm))

def pm_of(px, R1, L1, g, CLp):
    T = []
    for i, f in enumerate(fr):
        A = (lambda ff, a=A_tab[i], px=px: a / (1 + 1j * ff / px))
        Zo = (lambda ff, R1=R1, L1=L1: 5.47 + (R1 * 2j * math.pi * ff * L1) / (R1 + 2j * math.pi * ff * L1))
        c = Circuit()
        if g == 1:
            c.OPAMP('U', 'inp', 'out', 'out', A, Zo); c.R('inp', '0', 50.0)
        else:
            c.OPAMP('U', 'inp', 'inn', 'out', A, Zo); c.R('inp', '0', 1.0)
            c.R('inn', '0', 1e3); c.R('inn', 'out', 1e3)
        c.R('out', '0', 2e3); c.C('out', '0', CLp * 1e-12)
        T.append(c.loop_gain(f, 'U'))
    m = margins(fr, np.array(T))
    return m['pm_worst'] if m['pm_worst'] is not None else -90.0

best = None
for px in [40e6, 60e6, 80e6, 100e6, 140e6]:
    for R1 in [20, 40, 80, 150, 300]:
        for L1 in [0.15e-6, 0.25e-6, 0.4e-6, 0.6e-6, 0.9e-6]:
            err = 0.0
            for (g, cl, pm) in pts:
                if cl < 20: continue
                e = pm_of(px, R1, L1, g, cl) - pm
                err += e * e * (2.0 if (g == 1 and cl >= 300) else 1.0)
            if best is None or err < best[0]:
                best = (err, px, R1, L1)
# local refinement
err0, px, R1, L1 = best
for it in range(3):
    for dpx, dR, dL in itertools.product([0.85, 1, 1.18], [0.8, 1, 1.25], [0.85, 1, 1.18]):
        cand = (px * dpx, R1 * dR, L1 * dL)
        err = 0.0
        for (g, cl, pm) in pts:
            if cl < 20: continue
            e = pm_of(*cand, g, cl) - pm
            err += e * e * (2.0 if (g == 1 and cl >= 300) else 1.0)
        if err < err0:
            err0, (px, R1, L1) = err, cand
lines = ['Calibrated effective OPA1622 model: extra pole px = %.1f MHz, Zo = 5.47 + (%.1f ohm || %.3f uH)' % (px / 1e6, R1, L1 * 1e6),
         '   CL(pF)  G   TI PM   model PM']
for (g, cl, pm) in pts:
    lines.append('   %6.0f %2d  %6.1f   %6.1f' % (cl, g, pm, pm_of(px, R1, L1, g, cl)))
open(os.path.join(OUT, 'calibrate_opa1622.txt'), 'w').write('\n'.join(lines) + '\n')
json.dump({'px': px, 'R0': 5.47, 'R1': R1, 'L1': L1}, open(os.path.join(os.path.dirname(__file__), '..', 'ds', 'opa1622_calibrated.json'), 'w'))
print('\n'.join(lines))
