"""ES9018K2M timing used by the firmware sequences (MCLK 80.000 MHz, Kyocera KC2520K80.0000C1GE00, D-3 revised 25 Sep 2026)
and pop bounds with the photorelay output switch (TLP3545A x 4, D-1; D-19: every MCLK stop also opens the switch in hardware).
Round 2; the round-1 relay-placeholder version is kept as dac_timing_pop_r1.py.

ESS ES9018K2M v3.7: soft-mute ramp rate 0.0078125 * fs / 2^(vol_rate-5) dB/s (p.6, reg 6 vol_rate default 2);
soft start time 4096 * 2^(soft_start_time+1) / MCLK (reg 14, p.19); DPLL/ASRC lock after stop_div FSR edges, stop_div = 0
-> 16384 edges, required for FSR > 96 kHz (reg 10, p.16); FSR = DPLL_NUM x F_MCLK / 2^32 (reg 66-69, p.24);
MCLK > 192 x FSR in PCM normal mode (p.7); external DVDD when MCLK > 50 MHz or FSR > 192 kHz (p.7); DVDD 50 mA nominal
at 192 kHz / 80 MHz, VCCA 0.8 mA nominal at MCLK 22 MHz (p.28 notes 1, 4).
Pop definition (brief 4): transient beyond the settled DC step, 20 Hz-20 kHz, AC coupled; <= 5 mV controlled transitions.
Band-limited peak of a charge Q injected into a load R (R C << 8 us): Q R 2 pi 20 kHz (single-pole 20 kHz measurement,
conservative vs a brick-wall filter: Q R 2 x 20 kHz).  Coupled leg step dV through COFF into R: R COFF dV/dt, band-limited
<= R COFF dV min(2 pi 20 kHz, 1/t_ramp).  Output: ../out/dac_timing_pop.txt"""
import os, math, sys
sys.path.insert(0, os.path.dirname(__file__))
from r2_common import COFF_TYP, COFF_BOUND, CS_IO_TYP, CS_IO_BOUND, VREF_HI, RF, G_LEG
OUT = os.path.join(os.path.dirname(__file__), '..', 'out'); os.makedirs(OUT, exist_ok=True)
L = []; p = L.append
MCLK = 80.0e6   # D-3 revised: Kyocera KC2520K80 (the Epson 75 MHz part is end-of-life)
RATES = [44.1e3, 48e3, 88.2e3, 96e3, 176.4e3, 192e3, 352.8e3, 384e3]
vol_rate = 2
W20 = 2 * math.pi * 20e3
p('A. ES9018K2M timing at MCLK = 80.000 MHz (Kyocera KC2520K80.0000C1GE00, D-3 revised)')
p('   fs (kHz)   ramp rate (dB/s)   ramp time (ms)   lock 16384/fs (ms)   firmware timeout mute (ms) / lock (ms)   MCLK/FSR (> 192)')
for fs in RATES:
    rate = 0.0078125 * fs / 2 ** (vol_rate - 5)
    t_ramp = 127.5 / rate
    t_lock = 16384 / fs
    p('   %7.1f   %14.0f   %12.1f   %16.1f        %6.0f / %6.0f                         %7.1f'
      % (fs / 1e3, rate, t_ramp * 1e3, t_lock * 1e3, math.ceil(1.5 * t_ramp * 1e3), math.ceil(1.5 * t_lock * 1e3 + 10), MCLK / fs))
t_ss = 4096 * 2 ** (10 + 1) / MCLK
p('Soft start (reg 14 soft_start_time = 10): %.1f ms [DS formula] (same as round 1; the interim 75 MHz value 111.8 ms is withdrawn); switch may close only after'
  ' %.1f ms (x1.2) after the I2C init -> the digital sequence constant 126 ms stays [CALC]' % (t_ss * 1e3, t_ss * 1.2e3))
for sst in (2, 3, 4):
    p('  soft_start_time = %d -> ramp %.3f ms (used for the power-down ramp to ground, section C)' % (sst, 4096 * 2 ** (sst + 1) / MCLK * 1e3))
p('MCLK/FSR at 384 kHz = %.1f > 192 (+%.1f %%, >> the +-100 ppm combined oscillator tolerance) [DS p.7]; period %.2f ns >= 10 ns; high/low at'
  ' 45:55 >= %.3f ns (>= 5.5 ns with the 4.5 ns edges, D-3) >= 4.5 ns [DS p.30]' % (MCLK / 384e3, (MCLK / 384e3 / 192 - 1) * 100, 1e9 / MCLK, 0.45e9 / MCLK))
p('Rate detection: FSR = DPLL_NUM x 80.000 MHz / 2^32 (reg 66-69).')
p('External DVDD required (80 MHz > 50 MHz, FSR up to 384 kHz) [DS p.7]; DVDD current 50 mA nominal is specified at exactly 80 MHz/192 kHz [DS-typ note 4];'
  ' the 60 mA [PH] budget stays (x1.2 on a nominal value).')
p('VCCA feeds the XI buffer: 0.8 mA nominal is specified at MCLK 22 MHz [DS note 1]; proportional scaling gives <= %.1f mA at 80 MHz [ASSUMP] ->'
  ' power stream: use 2.9 mA for VCCA in the 3V3A budget (+2.1 mA vs D-10) unless measured [MEAS].' % (0.8 * 80 / 22))
p('Level / trim: unaffected (current-mode output amplitude = f(AVCC, Rs), not MCLK); pre-calibration default -4.5 dB (brief 4) and master trim range unchanged.')

p(''); p('B. Pop bounds with the photorelay switch (req <= 5 mV peak, 32 and 300 ohm; 600 ohm shown for information)')
Rhp = (16.0, 32.0, 300.0, 600.0)
for cs, lab in ((CS_IO_TYP, 'CS 0.8 pF typ [DS-typ]'), (CS_IO_BOUND, 'CS bound 2 pF [ASSUMP]')):
    q = cs * 5.55
    p('  LED edge at switch turn-on/off (LED node step <= 5V_SYS max 5.55 V), %s, charge %.1f pC into the jack node (switch open): '
      % (lab, q * 1e12) + ', '.join('%3.0f ohm %.3f mV' % (R, q * R * W20 * 1e3) for R in Rhp) + ' [CALC]')
p('  -> the closed-switch edge (turn-off) lands on a 0.13 ohm source: < 1 uV.  Switch closure/opening onto a muted leg: the step equals the leg DC offset'
  ' (<= 6.24 mV worst, excluded by definition); MOSFET turn-on takes 0.5-5 ms (no bounce) -> nothing beyond the step.')
p('  COFF coupling of leg steps while the switch is OPEN (new with the photorelay; the relay had ~1 pF):')
def pop(dv, tr, C, R):
    return R * C * dv * min(W20, 1.0 / tr) if tr > 0 else R * C * dv * W20
def v_reset(delta):
    """Reset-state leg DC for a DAC pin-to-pin output-resistance mismatch delta: G VREF Rf (1/Rs_N - 1/Rs_P), Rs 806 ohm,
    plus the difference-amplifier CM leakage 2 eps x 3.37 V (0.1 % / 25 ppm alternate parts, worst)."""
    rn, rp = 806 * (1 - delta / 2), 806 * (1 + delta / 2)
    return G_LEG * VREF_HI * RF * (1 / rn - 1 / rp) + 2 * 0.001625 * 3.37
T3A = 3.3 * 4.8e-6 / 0.75    # fastest plausible 3V3A rise: >= 4.8 uF effective, LP5907 current limit <= 1.5 x 500 mA typ [ASSUMP]
for delta in (0.03, 0.11, 0.22):
    dv = v_reset(delta)
    s = '    AVCC_EN with RESETB low: reset-state leg step %.3f V (DAC pin mismatch %2.0f %% [ASSUMP; ESS gives no match]), 3V3A rise >= %.0f us [ASSUMP]: ' % (dv, delta * 100, T3A * 1e6)
    s += ', '.join('%3.0f ohm %.2f mV' % (R, pop(dv, T3A, COFF_BOUND, R) * 1e3) for R in (32.0, 300.0, 600.0))
    s += ' (COFF 1 nF); 300 ohm %.2f mV with 640 pF' % (pop(dv, T3A, COFF_TYP, 300.0) * 1e3)
    p(s)
dv = v_reset(0.22)
p('    same step as an instantaneous edge (worst, not physical for an LDO start-up): 300 ohm %.1f mV (22 %%), %.1f mV (3 %%) -> [MEAS] JACK_xx at 300/600 ohm during power-up'
  % (pop(dv, 0, COFF_BOUND, 300.0) * 1e3, pop(v_reset(0.03), 0, COFF_BOUND, 300.0) * 1e3))
p('    RESETB high + soft start (%.1f ms ramp from the reset state to the null state): 300 ohm %.4f mV' % (t_ss * 1e3, pop(dv, t_ss, COFF_BOUND, 300.0) * 1e3))
p('    RAIL_EN (rails ramp with 3V3A off, VREF = 0, DAC unpowered): legs stay at the offset (<= 6.2 mV) -> <= %.2f mV even as an edge; the OPA1622/OPA2210'
  ' behaviour below their minimum supply is not specified -> [MEAS] (same bring-up capture)' % (pop(6.24e-3, 0, COFF_BOUND, 300.0) * 1e3))
t_ramp_pd = 4096 * 2 ** (3 + 1) / MCLK
p('    Power-down with RESETB pulled low directly (switch already open): reset step as an edge -> 300 ohm %.1f mV (22 %%) / %.1f mV (3 %%): NOT acceptable as a bound'
  % (pop(dv, 1e-6, COFF_BOUND, 300.0) * 1e3, pop(v_reset(0.03), 1e-6, COFF_BOUND, 300.0) * 1e3))
p('    Power-down with the ESS ramp to ground first (reg 14 = 0x03: soft_start 0, soft_start_time 3 = %.3f ms), then RESETB low: 300 ohm %.3f mV (22 %%)'
  % (t_ramp_pd * 1e3, pop(dv, t_ramp_pd, COFF_BOUND, 300.0) * 1e3))
p('    AVCC_EN low (3V3A discharge tau >= 70 us, 10 ohm + FET, power c06) from the reset state: 300 ohm %.2f mV (22 %%)' % (pop(dv, 70e-6, COFF_BOUND, 300.0) * 1e3))
p('  -> controlled transitions <= %.1f mV at 300 ohm (<= %.1f mV at 32 ohm) + the DC step, with the firmware steps of section C (requirement 5 mV).'
  % (max(pop(v_reset(0.22), T3A, COFF_BOUND, 300.0), CS_IO_BOUND * 5.55 * 300 * W20) * 1e3, pop(v_reset(0.22), T3A, COFF_BOUND, 32.0) * 1e3))
p('  Rate / family change with the switch closed: unchanged from round 1 (soft mute before the ASRC; MCLK never stops; output during lock loss NOT specified'
  ' by ESS -> [MEAS], fallback: firmware opens the switch around the change).')

p(''); p('C. Firmware steps (analog view), register values at 80 MHz')
p('  Init: reg 1 = 0x80, reg 10 = 0x00 (stop_div 16384), reg 14 = 0xAA (soft_start 1, soft_start_on_lock 0, mute_on_lock 1, soft_start_time 10 = %.1f ms),'
  ' reg 7 mute = 11, master trim from flash or 0x4C3EA838 (-4.5 dB pre-calibration default, brief 4), reg 8 = 0x10 (GPIO2 = lock).' % (t_ss * 1e3))
p('  Power-up (switch open): ... RESETB high -> I2C init -> wait %.0f ms (soft start x 1.2) -> protection pre-close checks (DC_PERMIT_N low) -> RELAY_EN -> wait 10 ms'
  ' (tON <= 5 ms at IF 5 mA; protection R2 rule) -> unmute (volume ramp).' % (t_ss * 1.2e3))
p('  Controlled power-down / suspend: mute (wait GPIO2 4\'d2 if time allows) -> RELAY_EN low -> wait 1.1 ms -> reg 14 = 0x03 (ramp to ground %.3f ms) -> wait 1.1 ms'
  ' -> MCLK_EN/MCLK_PERMIT low -> RESETB low -> AUD_EN + AVCC_EN low -> rails.  Suspend: the mute is skipped (no SOF = FIFO outputs zeros); I2C write 0.30 ms at 100 kHz + 1.1 ms'
  ' -> suspend current at 4.16 ms after the last SOF (digital R2, margin 5.84 ms); no ACK within 0.5 ms -> continue (switch already open).'
  ' D-19: the MCLK stop itself (N2_MCLK_OE low) also holds the switch open in hardware.' % (t_ramp_pd * 1e3))
p('  Brown-out / unplug (VBUS_SENSE watchdog): RELAY_EN low AND AVCC_EN low in the same ISR (no 1.1 ms wait; unplug pop is a target only) -> 3V3A discharge'
  ' shortens the DAC-pin clamp exposure from <= 4.9 ms to <= 0.62 ms (unplug_model_r2.txt); with D-19 AVCC_EN low alone also opens the switch (U206 -> Q616).')
p('  Never while the switch can be closed: soft_start = 0, soft_start_on_lock = 1, RESETB low (DC steps of %.0f mV / reset step).' % (1.65 * 0.03 * 0.975 * 1e3))
open(os.path.join(OUT, 'dac_timing_pop.txt'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
