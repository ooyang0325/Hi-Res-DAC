"""Component stress table for the analog-stream parts (worst operating state, 0-50 C ambient, rails 3.789-3.915 /
-3.661..-3.781 V (D-6, round 2), 3V3A 3.3 V +-2 %, MCLK 80 MHz (D-3 revised), TLP3545A output switches).  Writes ../out/stress_analog.csv and prints it.  Also prints the ES9018K2M
register values used by the firmware steps (master trim for the -4.5 dB pre-calibration default, brief 4)."""
import os, csv, math
OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
Vs = 3.915 + 3.781   # round 2 (D-6); round 1: 4.014 + 3.828 = 7.84 V
rows = []
def r(ref, part, param, worst, rating, state, src):
    rows.append(dict(refs=ref, part=part, parameter=param, worst_case=worst, rating=rating, state=state, source=src))
# ES9018K2M
r('U301', 'ES9018K2M', 'AVCC_L/R, VCCA, DVCC', '3.366 V (3V3A/3V3D +2 %)', '4.7 V abs max; 3.3 V +-5 % rec.', 'all', 'ESS p.28')
r('U301', 'ES9018K2M', 'DVDD', '1.365 V (1V3 +5 %, power stream)', '1.8 V abs max; 1.3 V +-5 % rec.', 'all', 'ESS p.28')
r('U301', 'ES9018K2M', 'DAC pins', 'VREF 1.634-1.706 V (controlled); -0.42 V .. AVCC+0.42 V, <= 0.61 mA (faults and EVERY hot unplug, <= 0.62 ms with the firmware brown-out rule, <= 4.9 ms without)', 'GND < Vout < AVCC (no margin)', 'normal / fault / unplug', 'ESS p.28; dac_pin_safety.txt; unplug_model_r2.txt')
r('U301', 'ES9018K2M', 'digital inputs', '<= DVCC + 0.3 V required (firmware/digital rule)', '-0.3 .. DVCC+0.3 V', 'domain off', 'ESS p.28')
r('U301', 'ES9018K2M', 'dissipation / TJ', '~0.16 W (3.3 V x 33 mA incl. VCCA <= 2.9 mA at 80 MHz + 1.3 V x 60 mA)', 'TJ 125 C; operating TA -20..70 C', '50 C amb', 'ESS p.28 (currents nominal)')
# OPA2210
r('U403, U404', 'OPA2210IDR', 'supply', '%.2f V' % Vs, '40 V abs max; 4.5-36 V rec.', 'all', 'SBOS924H 6.1/6.3')
r('U403, U404', 'OPA2210IDR', 'input CM', 'VREF <= 1.706 V vs (V+min 3.789)-1.5 = 2.289 V (margin 0.583 V, unchanged by D-6)', '(V-)+1.5 .. (V+)-1.5 V', 'normal', 'SBOS924H 6.6')
r('U403, U404', 'OPA2210IDR', 'input differential / current', '< 0.1 V (reset/saturation); < 0.6 mA (faults)', 'back-to-back diodes, 10 mA', 'reset / fault', 'SBOS924H 6.1, 7.3.2')
r('U403, U404', 'OPA2210IDR', 'output current', '4.1 mA (reset state); <= 65 mA into a clamp (fault)', 'ISC +-65 mA typ, continuous short (1 amp/pkg)', 'reset / fault', 'SBOS924H 6.1/6.6')
r('U403, U404', 'OPA2210IDR', 'dissipation / TJ', '2 x 3.25 mA x %.2f V + 2 x 4 mA x 3.4 V = %.0f mW -> +%.0f C (126 C/W) -> TJ <= %.0f C' % (Vs, (2 * 3.25e-3 * Vs + 2 * 4e-3 * 3.4) * 1e3, (2 * 3.25e-3 * Vs + 2 * 4e-3 * 3.4) * 126, 50 + (2 * 3.25e-3 * Vs + 2 * 4e-3 * 3.4) * 126), 'TJ 150 C', '50 C amb', 'SBOS924H 6.5')
# OPA1622
p_leg = 2 * 3.915 * 0.092 / math.pi - 1.467 * 0.092 / 2   # 3.5 mm 16 ohm High, 67.3 mW -> 92 mA pk (r2_power.txt)
p_q = 2 * 4.2e-3 * Vs
r('U401, U402', 'OPA1622IDRCR', 'supply', '%.2f V' % Vs, '40 V abs max; 4-36 V rec.', 'all', 'SBOS727B 6.1/6.3')
r('U401, U402', 'OPA1622IDRCR', 'EN pin', 'EN = V+ (3.789-3.915 V) -> >= 0.95 V above GND pin', '(V-)-0.5 .. (V+)+0.5 V; VIH <= 0.95 V', 'all', 'SBOS727B 6.1/6.5/7.3.3')
r('U401, U402', 'OPA1622IDRCR', 'dissipation (3.5 mm 16 ohm High, 92 mA pk)', '%.0f mW -> +%.0f C (47.6 C/W) -> TJ %.0f C' % ((p_leg + p_q) * 1e3, (p_leg + p_q) * 47.6, 50 + (p_leg + p_q) * 47.6), 'TJ 200 C abs; shutdown 175 C', '50 C amb, High', 'SBOS727B 6.4')
p_bal = 2 * (2 * 3.915 * 0.078 / math.pi - 1.25 * 0.078 / 2) + p_q   # 4.4 mm 32 ohm High (not rated), 97.7 mW current-limited, 78 mA pk, both amplifiers
r('U401, U402', 'OPA1622IDRCR', 'dissipation (4.4 mm 32 ohm High, 78 mA pk, both amplifiers)', '%.0f mW -> +%.0f C (47.6 C/W) -> TJ %.0f C' % (p_bal * 1e3, p_bal * 47.6, 50 + p_bal * 47.6), 'TJ 200 C abs; shutdown 175 C', '50 C amb, High', 'SBOS727B 6.4')
p_sc = 3.915 * 0.145 + p_q
r('U401, U402', 'OPA1622IDRCR', 'dissipation (one output shorted, DC, 145 mA)', '%.0f mW -> TJ %.0f C' % (p_sc * 1e3, 50 + p_sc * 47.6), 'continuous short, one amp/package', 'adapter / short', 'SBOS727B 6.1 note 2, Fig. 37')
# passives
r('R401-R416, R438-R445', 'thin film 0603', 'power', '(3.92 + 0.85)^2 / 2 k = 11 mW (R2, rail-stuck leg)', '100 mW at 70 C', 'fault', 'YAGEO RT')
r('R423-R426', 'thin film 0603', 'power', '(2.4 mA)^2 x 698 = 4 mW', '100 mW', 'reset', 'YAGEO RT')
r('R431, R432', 'thin film 0603', 'power', '0.28 mW', '100 mW', 'all', 'YAGEO RT')
r('R301, R302', 'thick film 0805', 'power', '(8 mA)^2 x 2.2 = 0.14 mW', '125 mW', 'all', 'UNI-ROYAL')
r('C401-C408, C417-C420, C421, C431-C438', 'C0G 50 V', 'voltage', '<= 7.7 V (VPOS-VNEG across none; max node swing 4.8 V)', '50 V', 'all', 'maker')
r('C303, C304, C310', 'X5R 16 V 0603', 'voltage / temperature', '3.37 V / 50 C (+ self-heating ~0)', '16 V; X5R -55..85 C', 'all', 'Samsung CL10A225KO8NNNC')
r('C305-C309, C409-C412, C423-C426', 'X7R 16 V 0402', 'voltage', '3.92 V (VPOS) / 3.78 V (VNEG)', '16 V', 'all', 'Samsung CL05B104KO5NNNC')
r('C413-C416', 'X5R 25 V 0805', 'voltage', '3.92 / 3.78 V', '25 V; X5R 85 C', 'all', 'Samsung CL21A106KAYNNNE')
r('D405-D408', 'BAT54S,215', 'reverse voltage / forward current / power', 'VR <= 3.4 V; IF <= 65 mA (fault, ms); P <= 65 mA x 0.74 V = 48 mW', '30 V; 200 mA; 250 mW', 'fault', 'Nexperia BAT54S v.6')
r('D701-D704', 'LESD5D5.0CT1G (bidirectional)', 'working voltage / ESD', '<= +-3.92 V on JACK_xx (rail-stuck leg through a closed switch); IEC 61000-4-2 8 kV contact clamped <= 16 V (7 A 8/20 us)', 'VRWM 5 V, VBR 7 V (>= 6 V); VC 16 V at 7 A; 100 W', 'fault / ESD', 'GOODWORK DS (bidirectional V-I) + LCSC/JLCPCB/DigiKey listing')
r('FB301, FB302', 'GZ1608D601TF', 'current', '14.2 mA / <= 2.9 mA (VCCA at 80 MHz, ASSUMP)', '200 mA', 'all', 'Sunlord')
r('J701', 'GT-3321667P-01', 'current / voltage / temperature', '<= 0.25 A (rail-stuck into 16 ohm, until the switch opens); 3.92 V; 50 C', '500 mA; 30 V; -20..70 C', 'fault', 'LCSC C2762984')
r('J702', 'PJ-332A-6A', 'current', '<= 0.25 A', '1 A (v0.8 record)', 'fault', 'LCSC C2848643')
with open(os.path.join(OUT, 'stress_analog.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
for x in rows:
    print(' | '.join(str(v) for v in x.values()))
full = 2 ** 31 - 1
for db in (-4.5,):
    v = int(round(full * 10 ** (db / 20)))
    print('ES9018K2M master trim for %.1f dB: 0x%08X (reg 20..17 = %02X %02X %02X %02X)' % (db, v, v >> 24 & 255, v >> 16 & 255, v >> 8 & 255, v & 255))
print('reg 14 = 0x%02X (soft_start 1, soft_start_on_lock 0, mute_on_lock 1, soft_start_time 10 = 104.9 ms at 80 MHz); power-down ramp reg 14 = 0x03 (0.819 ms)' % (0x80 | 0x20 | 10))
