"""T network plus a small lead capacitor Cl across R2 and R4 (same value both sides for CMRR).
Output: ../out/stability_legs_lead.txt"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA1622v
from stability_legs_T import build_T, FR, OUT

MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]
LOADS = [('open', 0, False)] + [(rl, cl, False) for rl in (16, 32, 300, 600) for cl in (0, 470e-12, 1e-9)] \
        + [(16, 1e-9, True), (300, 1e-9, True), (600, 1e-9, True)]
LOADS2 = [(rl, 2e-9, False) for rl in (16, 32, 300, 600)]
lines = []
for (R1a, R1b, Ct) in [(1000, 1000, 1.5e-9), (1210, 787, 1.5e-9), (1330, 665, 1.8e-9)]:
    for Cl in (0, 4.7e-12, 10e-12, 22e-12, 33e-12):
        w1 = 999; w2 = 999; nom = 999; gmin = 999
        for (mk, gs) in MODELS:
            op = OPA1622v(mk, gs)
            for relay in (True, False):
                for (load, CL, cable) in LOADS + LOADS2:
                    c = build_T(R1a, R1b, Ct, load, CL, op, relay, cable)
                    if Cl:
                        c.C('N', 'OUT', Cl); c.C('P', '0', Cl)
                    m = margins(FR, c.loop_gain(FR, 'U'))
                    pm = m['pm_worst'] if m['pm_worst'] is not None else -99
                    if CL <= 1e-9:
                        w1 = min(w1, pm)
                        if mk == 'CAL' and gs == 1.0: nom = min(nom, pm)
                        if m['gm'] is not None: gmin = min(gmin, m['gm'])
                    else:
                        w2 = min(w2, pm)
        lines.append('T %4d/%4d Ct %.1f nF + Clead %4.1f pF: worst PM <=1 nF %.1f (nominal CAL %.1f), min GM %.1f dB, worst PM 2 nF %.1f'
                     % (R1a, R1b, Ct * 1e9, Cl * 1e12, w1, nom, gmin, w2))
        print(lines[-1], flush=True)
open(os.path.join(OUT, 'stability_legs_lead.txt'), 'w').write('\n'.join(lines) + '\n')
