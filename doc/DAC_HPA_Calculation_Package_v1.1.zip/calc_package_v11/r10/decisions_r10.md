# R10 decisions — binding (orchestrator, 26 Sep 2026)

Sources:
- r10/reviews_r10.md: digest of reviews R10-A, R10-B and R10-C.
- r10/history_check.py and r10/railstuck_check.py, with their _out.txt files: orchestrator reproductions.

Owner rules unchanged:
- flawless operation, every requirement met worst case, least cost;
- no spares; JLCPCB Standard PCBA, top side;
- owner-fitted special parts;
- the budget is not a constraint, and cost is reported for information.

New versions after this round:
- Spec v1.1;
- Notes v1.0;
- Parts List v0.9;
- calculation package v1.1.

The previous versions stay untouched.

## Facts checked by the orchestrator
1. The leg-window model starts every fault from rest.
   - p03 step_time() is a zero-state unit-step response.
   - frozen_pm_x() sweeps x from 1.02 × trip.
   - p18 t_old() inherits both.
2. The R10-A counterexample reproduces. Simplified model: leg windows at the slowest corner, 1 pole, τ 282.2 ms, trip 0.320 V, plus the 1.98 ms allowance. Results:
   | Case | Removal | 16 Ω balanced | 32 Ω balanced |
   |---|---|---|---|
   | x = 0.97 V/leg after one 20 Hz negative half-cycle of 1.5 V pk (filter −81 mV) | 137.6 ms | 32.4 mJ (limit 30) | 16.2 mJ (limit 15) |
   | Filter pre-charged to −0.320 V by sub-threshold DC | 195 ms | 46.0 mJ | 23.0 mJ |
   | From rest, just above the trip (1.005 / 1.01 × trip) | 1.30–1.50 s | 34–39 mJ | — |
   The 1.02 × trip starting point of the package sweep hides the last row.
3. **A second hole, found by the orchestrator.** Take a single leg stuck at the rail (3.789–3.915 V) while the partner leg of its pair still plays full-scale content at ≥ 50 Hz. The pair difference falls to 1.56–1.69 V each cycle, below V_L, so the pair detector's timer resets every cycle and never trips. That leaves the leg windows alone:
   | Starting state | Removal | 16 Ω SE | 32 Ω SE |
   |---|---|---|---|
   | Rest | 26.0–26.9 ms | 24.1–24.9 mJ | — |
   | After one 20 Hz negative half-cycle | 31.8–32.8 ms | 29.5–30.5 mJ | — |
   | Pre-charged to −0.32 V | 48–50 ms | 44.6–46.2 mJ | 22.3–23.1 mJ |
4. Spec v1.0 states the hardware requirement as follows: "DC ≥ 2 V on any leg removed within 100 ms and ≥ 1 V within 250 ms, worst case, without firmware; ≤ 30 mJ at 16 Ω and ≤ 15 mJ at 32 Ω for a rail-stuck output (High mode) and for a balanced ±x failure; no false trip for full-scale sines ≥ 20 Hz". The firmware requirement: tiers remove DC ≥ 0.2 V within 3 s, and every sub-hardware case stays ≤ 30 / 15 mJ.
5. Stale protection rails. pcommon has VPOS 3.789 / 3.900 / 4.014 V and |VNEG| 3.618 / 3.722 / 3.828 V. The released dividers give VPOS 3.789–3.915 V and |VNEG| 3.661–3.781 V. The R501 232 k fallback gives VPOS 3.919–4.049 V.
6. Unshipped inputs. p19_r9_bom.py reads bom_rows_ve.csv.bak and netlist_ve.csv.bak, which are not in the package.
7. Stale power calculation. power/calc/c21_r9_checks.py, its out.txt and c21_results.json still use R509 4.81 k, 490.80 mA and 177.9 mA.
8. Evidence class. analog r9_fixes.py labels the Default need "G, except LM27762 IQ (no max) and CP 1.03 = E". The register lists R-13 as G.
9. Default-margin budget. The margin is +1.23 mA at 5V_ANA (need 178.82 mA, IOS minimum 180.05 mA).
   - Any new load on VPOS/VNEG raises the need by ≈ I+ + 1.03·I−, about 2.03 mA per +1 mA on both rails.
   - A new circuit on those rails must therefore add ≪ 1.2 mA at 5V_ANA; ≤ 0.3 mA is preferred, so the margin stays ≥ 0.9 mA.
   - Alternatively, supply it from a rail outside the eFuse. It then adds to S3: 493.45 mA with the Kyocera, 497.95 mA with the NDK, limit ≤ 500 mA.
   - Changing R509 is not available: 4.70 k would push S3 with the NDK over 500 mA.

## Decisions
**F-1 (R10-A1, High): history-robust hardware protection. Protection leads; digital does the firmware parts; analog checks the leg loading and pop.**
(a) Define the reachable pre-fault states:
   - every leg-window filter node anywhere strictly inside its trip levels, of either polarity, whether reached from legitimate content or from sub-threshold DC;
   - the pair-detector timer nodes anywhere below V_T, including an incomplete reset;
   - the CM-window and DC-sense filter states, likewise;
   - prior sine phases, bursts, polarity reversals and recent near-trips;
   - during a single-leg fault, any full-scale content ≥ 20 Hz on the partner leg.
(b) Re-run the hardware-only energy and time sweeps over that set, starting just above each trip level (no 1.02 × start). Cover:
   - balanced ±x at every level up to the swing limit;
   - rail-stuck of either polarity over the released rail range, plus the R501 fallback;
   - single-leg faults with arbitrary partner-leg content.
   Include the real switch-opening delay. Show the two counterexamples in fact 2 and fact 3 explicitly.
(c) Design the least-cost change so that the hardware requirement holds from every reachable state.
   - A level/time detector cannot bound energy arbitrarily close to its own threshold. If physics forces a level floor, state it precisely in the requirement. The region below the floor then belongs to the firmware tiers.
   - Show that the firmware tiers are history-robust too, since they read filtered DC-sense nodes, or make them so in firmware.
   - Directions to evaluate (your choice, least cost):
     - a history-independent low-level pair persistence stage: its timer resets whenever the level condition is false; T_P2 minimum > 25 ms, so no sine ≥ 20 Hz of any amplitude can trip it; T_P2 maximum set by the energy limit; wide tolerances are fine, so cheap parts;
     - a per-leg over-range detector (|leg| above the calibrated full-scale peak plus margin, short persistence) for the rail-stuck faults the pair detector cannot see;
     - nanopower comparators, or comparators on a rail outside the eFuse (fact 9);
     - fewer parts where an existing channel can be reused.
   - Mind the Z7 fill, now 59 % of 60 %. Z4 next door is at 18 %.
(d) Re-run every no-false-trip check:
   - sines ≥ 20 Hz at any amplitude up to the calibrated full scale, and at the −4.5 dB uncalibrated default for the highest-gain unit (F-5);
   - squares: the boundary must not get worse than 21.5 / 25.6 Hz;
   - bursts, asymmetric content and polarity reversals.
   State plainly any new content boundary, for example sustained sub-20 Hz content.
(e) Deliver:
   - BOM/netlist rows for the new parts;
   - boot self-test coverage of every new channel;
   - bring-up tests;
   - the loads per rail;
   - a list for parts.
**F-2 (R10-A2, Medium): evidence classes propagate. Integration leads; analog, power and protection give their dependencies.**
- A result is G only if every input is a datasheet limit or a G result. Any assumption, typical value or reconstructed model makes it E. Anything that rests on a measurement is Q.
- Q rows are open qualification obligations: none has passed, since no board exists. Say so in the register and in the documents.
- Known changes:
  - R-13 → E, because the LM27762 IQ has no maximum and the CP factor 1.03 is estimated.
  - The stability rows → E, because they rest on reconstructed or typical models.
- Walk all rows with this rule.
**F-3 (R10-A3 and R10-C, Medium): reproducibility.**
- Power:
  - regenerate c21 with R509 4.75 k, including its out.txt and json;
  - fix or mark superseded every current-looking 4.81 k / 490.80 / 177.9 mA text in power/report.md;
  - align the state narratives to the final c17 run: S2 344.17, S3f 359.50, S5 352.31 mA, and so on.
- Protection:
  - take the pcommon rails from the released dividers, naming the R501 fallback case; or keep a documented conservative bound and say which detector it favours;
  - make p19 self-contained, or move it to the historical generators.
- Integration:
  - add one documented release-verification command at the package root. It runs every release calculation with its inputs included and compares the results with the shipped outputs.
  - split INDEX into release calculations (verified by that command) and historical generators (kept for traceability, not guaranteed to re-run).
**F-4 (R10-A4): latch wording. Protection.**
- Replace "however short" with the implemented condition: a trip that pulls node H below HREF clears the latch within the clear-path time, and a disturbance that never reaches HREF cannot open the switch.
- List the latch tests as qualification obligations.
**F-5 (R10-B): calibration rule. Digital leads; analog and protection contribute.**
- The detectors' content boundaries are guaranteed only at or below the calibrated full-scale level.
- An uncalibrated board, one with no valid calibration record, runs at the −4.5 dB default.
- The firmware never sets a digital gain above the calibrated level.
- Analog: confirm the peak per leg of the uncalibrated highest-gain unit at 0 dBFS and at −4.5 dB.
- Protection: give the margins at both levels.
**F-6: cost wording.** The cost stays an estimate until the supplier orders and the JLCPCB quote exist.
**F-7: releases.** Documents and the calculation package get new versions only after the independent re-check of F-1.

## Orchestrator decisions after the F-1 results (26 Sep 2026, ~07:50 UTC); binding
- **F-8 (the 32 Ω balanced frozen full-scale case, protection p22).** Option A is adopted by default: a stated E item plus a bring-up Q test.
  - The case: E-3 alone keeps ≤ 15 mJ up to 2.175 V/leg. With the typical OPA1622 swing credit it gives 13.67 mJ (released) and 14.87 mJ (R501 fallback). Without the credit: 15.23 / 15.77 / 17.14 mJ at 2.192 / 2.230 / 2.325 V/leg.
  - Physics floor: 14.55 mJ at 2.325 V/leg with the FS-square boundary kept at 25.6 Hz.
  - The Q test: a CPLD frozen 0 dBFS code at the calibrated level into a 32 Ω balanced dummy; the energy until the switch opens must be ≤ 15 mJ; log the leg swing.
  - Option B (calibrated FS −0.6 dB, 1.55 → 1.45 Vrms per leg, default −5.1 dB, 0 parts) is offered to the owner but is not free.
    - It breaks the 300 Ω output-power targets. R-12 (High 300 Ω 30 mW) and the 300 Ω target of R-14 (Default 30 mW) need 2.124 V pk/leg. The calibrated −0.1 dB level would fall from 2.167 V to ≈ 2.022 V, which gives ≈ 27 mW.
    - It cuts every other power-target margin from ≥ 0.78 dB to ≥ 0.18 dB.
    - It lowers the maximum output by 0.6 dB.
  - The H stage (option C) is rejected: FS squares would mute up to 50 Hz. A precision persistence stage (option D) is not feasible, because it needs a timer spread ≤ 3.4 %.
  - In Default mode the eFuse limit (IOS max 222.6 mA, DS) caps a balanced frozen code at 32 Ω to ≈ 1.17 V/leg (≈ 4.4 mJ). The open item exists only in High mode. Protection is to confirm this before the documents state it.
- **F-9 (defaults, stated to the owner):**
  - boot self-test with full coverage, 3.68 s; 2.96 s rotating is the alternative;
  - LPW content boundary adopted (A-44);
  - hardware requirement worded with the level floor (R-74: |leg| ≥ 0.324 V, |pair| ≥ 0.648 V; below it the firmware tiers keep ≤ 15.8 / 7.9 mJ);
  - block 6 budgeted at the conservative bound 2.738 / 2.566 mA against the design's 2.714 / 2.542 mA.
- **F-10 (cost):** the R10 parts change the cost; parts gives the prices and integration rebuilds. It is still an estimate until the supplier and JLCPCB quotes.
- **F-11 (definition of fault energy; the R-22 open item).** The Spec definition is kept: fault energy E = V_DC²/R × removal time, where V_DC is the fault DC at the load. Under it every case meets 30 / 15 mJ.
  - Also published, for information: the total terminal energy when a balanced load has one leg stuck and full-scale content on the partner leg.
    | Case | Total terminal energy |
    |---|---|
    | 32 Ω balanced, High mode | 24.1–24.7 mJ (exceeds 15 mJ) |
    | 16 Ω balanced, High mode (U503 cap, no ISC credit) | ≤ 23.85 mJ |
    | Default mode | ≤ 11.3 mJ |
    | SE loads | equals the DC energy |
  - The fast high over-range stage (p22 §7) is rejected. The V_H window is 2.45–2.80 V, but the loaded stuck leg sags to 2.82 V (32 Ω) or 0.25 V (16 Ω) at the eFuse minimum. It would need 16 parts plus a test provision, and Z4 would reach about 60 %.
- **F-12 (self-test coverage).** Option A: pairwise coverage stated as a limitation, with per-channel coverage at the production per-leg injection. The firmware tiers still cover single-leg faults. Options B (4.65 s, one CPLD line) and C (≈ 5.9 s) go to the owner.
- **F-13.** Q623–Q627 move to onsemi MMBT3904LT1G (C81464, Extended), whose datasheet gives VCE(sat) ≤ 0.2 V at 10 mA / 1 mA. A-46 stays E because of the µA extrapolation, with a Q test of the reset level. Cost about +US$ 1.7 per order.
- **F-14.** The E-3 self-test word is ±0.55 FS on calibrated boards (+250 mV) and ±0.85 FS at the default.
- **F-15.** The hardware level floor is |leg| ≥ 0.34 V, |pair| ≥ 0.68 V (R-74, E). Below it the firmware tiers keep ≤ 17.4 / 8.7 mJ (pair) and ≤ 14.5 / 7.3 mJ (leg).
- **F-16.** R-26 and A-31 stay E, with the calibrated level as SCOPE at a +1.16 dB margin. R-57 is Q.
- **Amendments (after protection's confirmations).**
  - F-8, Default mode: protection's confirmed bound replaces the ≈ 1.17 V / ≈ 4.4 mJ estimate. U503's 222.6 mA limit (IOS max, DS) keeps the legs ≤ 1.781 V. The worst case is 11.10 mJ (26 % margin; E), taking no swing, dropout or UVLO credit; the typical case is 5.0 mJ. The open item applies to High mode only.
  - F-9: F-15 supersedes the floor wording (0.34 / 0.68 V; firmware region ≤ 17.4 / 8.7 mJ pair, 14.5 / 7.3 mJ leg).
  - F-9: the firmware tier deadlines are stated for the swept history set, which includes bursts, polarity reversals and short opposite pulses: T1 218 ms, T2 603 ms, T3 2.36 s. Never write "from any state" for the exact figures. Safety conclusion: DC ≥ 0.2 V removed well within 3 s.
- **Amendment after the independent summary check (26 Sep, ~10:45 UTC).**
  - F-11 wording: "Under it every calculated case meets 30 / 15 mJ under the stated E assumptions. The High-mode 32 Ω balanced frozen full-scale case meets 15 mJ only with the typical output-swing credit (A-45). It remains an owner item with a bring-up energy test."
  - **Headline rule.** Where a claim holds "from any reachable state" without a calibration input, use the rail-bounded values (p21 b3):
    - DC ±2 V removed in ≤ 27.2 ms; DC ±1 V in ≤ 102.7 ms;
    - rail-stuck 26.48 / 13.24 mJ (4.049 V) and 24.78 / 12.39 mJ (3.915 V);
    - balanced 16 Ω 26.08 mJ at 1.008 V/leg (102.7 ms);
    - 32 Ω balanced 13.67 / 14.87 mJ, unchanged (E-3 path).
    The content-bounded values (27.1 / 101.3 ms, 26.40 / 13.20 mJ, 25.70 mJ) may be quoted only as the case with pre-fault content at or below the calibrated ceiling.
  - Frozen codes: |pair| > 2.016 V is removed in ≤ 25.4 ms; 0.34 V ≤ |leg| ≤ 1.008 V in ≤ 118.8 ms (bound at the floor).

## Schematic-capture review (schematic engineer, 26 Sep 2026): decisions SE-1…SE-8, binding
Source: the owner's message of 26 Sep (connector soldering process hold; connector pin-map review, capture v1.0) and the capture PDF (9 sheets, "Schematic capture v1.0", built from Spec v1.0 / Notes v0.9 / Parts List v0.8).
Checked by the orchestrator:
- The GCT USB4105 drawing text lists 12 lands (A1/B12, A4/B9, B8, A5, B7, A6, A7, B6, A8, B5, B4/A9, B1/A12), 4 stake slots and 2 × Ø0.65 locating holes.
- The JLCPCB stencil standard (section 5): through-hole pads get no paste opening unless designed on the paste layer or remarked.
- JLCPCB lists C2848643 as "SMT Assembly, Economic and Standard, difficulty High, Mounting Surface Mount, TRRS".
- Our own layout package already prescribes pin-in-paste on the USB4105 stakes, but gives no aperture geometry and has no JLCPCB approval.
- The J701/J702 maps were already provisional in our set (R8-A10, gate G-2).
- The capture is on the R9 design: sheet 6 still has U601/U602, R601 and C601, and none of U611–U620, Q627 or R951.
- The HRO drawing and the JLCPCB CAD could not be opened here (image-only or not fetchable). The J702 facts are the engineer's scan, stated as such.

- **SE-1. J101 shell stakes S1–S4: accepted.**
  - No F.Paste on S1–S4 until JLCPCB confirms, in writing:
    - pin-in-paste for the USB4105-GF-A on a top-side Standard PCBA order;
    - the aperture geometry, or an order remark.
  - This becomes a G-6 order-release item.
  - Fallback, no part change and no cost: JLCPCB reflows the 12 surface lands, and the owner hand-solders S1–S4 from L4 before the first plug-in. L4 has no parts. The stakes carry the shell (N1_SHIELD) and the mechanical retention, so the board is never used with the stakes unsoldered.
  - A JLCPCB manual-solder step, if JLCPCB proposes one, is priced from their quote.
- **SE-2. J702 pads 1/2: accepted.**
  - Per the JLCPCB CAD, J702 has four surface lands (3–6) and two 0.6 × 1.5 mm plated slot terminals (1/2). Call it "SMD with two plated slot terminals", not "SMD".
  - JLCPCB's SMT listing does not establish how the slots are soldered.
  - G-6 item: JLCPCB confirms how pads 1/2 are soldered, with apertures or a remark.
  - Fallback: the owner hand-solders pads 1/2 from L4 (2 joints).
  - If JLCPCB cannot solder the part at all, J702 becomes owner-fitted, bought in the owner's LCSC order.
- **SE-3. J101 pad IDs: accepted.**
  - The netlist keeps the 12 composite GCT land labels plus S1–S4.
  - The provisional KiCad footprint (DAC_HPA:J101_USB4105-GF-A_12lands_4stakes) has the 16 JLC pad IDs: each shared land is two touching pads on one net. It also has S1–S4 and two unnumbered NPTH Ø0.65 mm holes.
  - The Notes state the label ↔ pad mapping.
  - G-1 (two-sample continuity) and G-3 (1:1 overlay) decide.
- **SE-4. J701 map: accepted, owner-approved 26 Sep 2026.** It follows the JLC/G-Switch 12-pad map:
  | Pad | Net |
  |---|---|
  | 1 | GND (the dedicated sleeve return, ≥ 4 vias) |
  | 2, 3 | JACK_RN |
  | 4, 5 | JACK_RP |
  | 6 | JACK_LN |
  | 7, 8 | JACK_LP |
  | 9 SWITCH, 10 DETECT | no connection (no detect circuit) |
  | 11, 12 ("ep" in the JLC symbol) | no connection until their role is confirmed |
  - The footprint is JLC_Imported:AUDIO-TH_GT-3321667P-01.
  - This replaces the seven-pin map, whose pad 1 = JACK_LP was wrong, and the earlier "pin 2 → JACK_LN, pin 4 → JACK_RN" wording.
  - Before schematic freeze, G-2 on two samples confirms the map and the role of pads 11/12, and measures the hole and peg sizes.
  - J701 stays owner-fitted: 12 THT joints (10 contact pins + 2 "ep" pads), to be confirmed at G-2.
- **SE-5. J702 contact map: accepted, provisional until G-2.**
  - The drawing shows a six-terminal contact/switch network (A variant) and does not identify pins 5/6 as GND-only mounting pads.
  - Our rule: J702 pins 5/6 carry NO net (NC) until G-2 establishes their role. This is safe either way: the sleeve GND is on pin 4, and the pads are still soldered.
    - A normally-closed switch contact tied to GND would short JACK_LP/JACK_RP to GND whenever the 3.5 mm jack is empty.
    - Those nets are shared with the 4.4 mm jack, so the balanced output would be shorted.
  - Pin 3 (ring 2 → GND) stays as the design intent, marked role unconfirmed.
  - No routing from the provisional map. Nets are revised from the G-2 record.
- **SE-6. No manufacturing data from provisional connector assignments: accepted.** It is stated in the stage table (routing and order rows).
- **SE-7. G-2 record procedure: accepted.**
  - Label the physical terminals from the JLC footprint top view.
  - Record continuity from every terminal to tip, each ring, the sleeve and any metal shell:
    - with no plug;
    - with the plug fully inserted;
    - while slowly inserting and removing the plug (switch and detect contacts).
  - J702 is tested with TRS and with any allowed TRRS plug.
  - Record internally common terminals.
  - The table sets the final symbol pin names, nets and pad assignments.
- **SE-8. Register and wording.**
  - R-70 ("no JLCPCB-placed part at a process limit", G) becomes an open process item until JLCPCB confirms SE-1/SE-2.
  - R-47 gains the J701 approved-map note, the J702 pins 5/6 NC rule and the G-2 record.
  - The layout sentence "no THT part in the JLCPCB order" becomes: "no THT-only part in the JLCPCB order; J101 (four plated shell stakes) and J702 (two plated slot terminals) mix SMT lands and plated terminations, whose soldering JLCPCB must confirm (G-6)".
  - Exposed L4 copper adds the J702 slot rings.
- **Capture note for the engineer.** Recapture sheet 6 to Parts List v0.9 (the R10 protection changes), and sheet 7 J702 pins 5/6 to NC. The other sheets change only where Parts List v0.9 "Changes vs v0.8" lists them.
- **Stage table.**
  | Stage | Verdict |
  |---|---|
  | Capture | GO: update to Parts List v0.9 |
  | Provisional placement | GO |
  | Freeze | HOLD for G-1…G-4, including the J701 pads 11/12 role and the J702 contact map |
  | Routing | HOLD; no manufacturing data from provisional connector assignments |
  | Order | HOLD for the layout review and G-5/G-6, including JLCPCB's written confirmation of the J101 S1–S4 and J702 pads 1/2 soldering (or the owner fallback) and the 2416 film-capacitor reflow |

## Maker drawings supplied by the owner (26 Sep 2026, ~15:15 UTC): SE-9, SE-10 (binding; they supersede SE-4/SE-5 where they differ)
Sources:
- HRO drawing "PHONE JACKES PJ-332A" (Rev A, 2021-06-03), with the PJ-332A-A schematic, PCB layout (top view) and bottom view;
- the JLCPCB/EasyEDA symbol and footprint for C2848643;
- G-Switch customer drawing C-GT03321667P-01 (GT-3321667P-01, Rev A0, 2020-07-10), with its schematic, recommended PCB layout, 3D view and BOM;
- the JLCPCB/EasyEDA symbol and footprint for C2762984.

Symbol convention, verified on the G-Switch drawing whose contacts are labelled: the rectangle is the sleeve. The hook nearest the rectangle is the contact nearest the entrance. The farthest hook is the tip: J701 hooks, nearest to farthest, are R− (ring 3), R+ (ring 2), L− (ring 1), L+ (tip), matching the 4.4 mm standard.

- **SE-9. J702 (HRO PJ-332A-6A) map, from the maker drawing. The stored map was wrong in 4 of 6 pins.**
  - PJ-332A-A schematic:
    - pin 1 goes to the sleeve rectangle;
    - pin 2 is a spring contact without a switch, its hook nearest the sleeve;
    - pin 3 is a spring contact; pin 5 is a break contact touching it;
    - pin 4 is a spring contact, its hook farthest; pin 6 is a break contact touching it.
  - Terminal positions along the axis, from the body front edge (PCB layout): pins 1/2 at 2.15 mm, pin 3 at 5.50, pin 4 at 9.30, pins 5/6 at 11.00/11.50. The bottom view puts pins 1/2 next to the nose.
  - Both lines of evidence agree:
    | Pin | Contact | Net |
    |---|---|---|
    | 1 | Sleeve | GND |
    | 2 | Ring 2 | GND (a TRS plug's sleeve spans it; ring 2 to GND is the design intent) |
    | 3 | Ring 1 | JACK_RP |
    | 4 | Tip | JACK_LP |
    | 5 | Break contact of ring 1 (closed to pin 3 with no plug) | NC |
    | 6 | Break contact of the tip (closed to pin 4 with no plug) | NC |
  - The old map (1 JACK_LP, 2 JACK_RP, 3 GND, 4 GND) would have put both driven legs on the plug's sleeve contacts, shorting JACK_LP to JACK_RP through any inserted plug, and grounded the tip and ring. The board would have had no sound, and the protection would have tripped.
  - Pins 5/6 must stay NC. Tied to GND, they short JACK_LP and JACK_RP (shared with J701) whenever J702 is empty.
  - Pads: pins 1/2 are the plated slots, 0.60 × 1.5 mm holes in 1.00 × 1.9 mm pads. These are the two GND terminals, so the slot-soldering question in SE-2 concerns only ground and mechanical retention. Pins 3–6 are 1.6 × 1.5 mm surface lands. Two locating pegs, Ø1.20 (side view); the hole comes from the JLCPCB footprint, confirmed at the G-3 overlay.
  - The per-net pin counts are unchanged.
  - The map is now documented, no longer unknown. G-2 still confirms it on two samples: continuity of tip, ring 1, ring 2 and sleeve, and the break contacts opening on insertion.
  - The drawing gives no reflow rating (housing PPA). The existing reflow-rating check with JLCPCB stays open.
- **SE-10. J701 (G-Switch GT-3321667P-01): the maker drawing confirms the owner-approved map (SE-4).**
  | Pin | Contact |
  |---|---|
  | 1 | GND (sleeve) |
  | 2, 3 | R− |
  | 4, 5 | R+ |
  | 6 | L− |
  | 7, 8 | L+ |
  | 9 | SWITCH |
  | 10 | DETECT |
  - Pads 11/12 ("ep") are the two tabs of BOM item 11, "Contact H": phosphor bronze, Ni-plated, not a gold contact. The maker schematic does not show them. They are mounting or retention tabs.
  - Pads 11/12 stay NC, but soldered. G-2 checks whether they are common with the sleeve or the bushing (item 12, "Socket"). If they are, they may be tied to GND in a later revision; NC is safe either way.
  - Holes, from the drawing: 12 plated slots of 0.50 (+0.10/0) × 1.40 (+0.10/0) mm in 1.00 × 1.90 mm pads, and two Ø1.20 mm locating holes for the Ø1.00 ± 0.05 mm pegs. The G-2 "measure the hole and peg sizes" step becomes a G-3 overlay confirmation.
  - 12 THT joints, owner-fitted.
- **Stage table.** Freeze stays on HOLD for G-1…G-4, but no connector contact map is unknown any more:
  - J701 and J702 are documented from the maker drawings;
  - G-2 confirms both on two samples, including J701 pads 11/12 and the J702 break contacts;
  - J101 confirmation is G-1.
- **Capture note.** In the engineer's capture, sheet 7 uses the old J702 map (Tip on pin 1, Sleeve on pin 4, Mount on 5/6). It must take the SE-9 map.

## Owner decisions, 27 Sep 2026 (binding)
Owner: Diego Yang. They settle the two points left open by the SE-9 / SE-10 integration pass (consistency_log §11, SE9-C5 and SE9-C6).
- **Slot-pad copper ring (SE9-C5): stays an open point for the owner; no pad size change.** It is also listed in the Spec and the Parts List. Wording: "Open point for the owner, to decide before the G-3 overlay: the maker-drawing slot pads leave a copper ring of 0.20 mm on J702 (0.60 mm slots in 1.00 mm pads) and 0.25 mm on J701 (0.50 mm slots in 1.00 mm pads; 0.20 mm at the +0.10 mm slot tolerance) — above JLCPCB's 0.18 mm minimum, at or below its 0.25 mm recommendation, and below this design's 0.30 mm rule. Until the owner decides, the pads stay as the maker drawings give them."
- **R-15 contact resistance (SE9-C6): the owner keeps the assumption.** In R-15 the input "ASSUMP: J701/J702 contact and 0 ohm link resistances (contact maxima from the drawings would make those terms G)" becomes "ASSUMP: J701/J702 contact resistance 50 mOhm per contact and 0 ohm links 50 mOhm each; the maker drawings give no contact-resistance maximum, so the owner kept this assumption (27 Sep 2026); these terms stay E until the bring-up output-impedance measurement". Class stays E; 3.5 mm 0.251 ohm / 4.4 mm 0.383 ohm, margins 0.249 / 0.117 ohm to the 0.5 ohm limit, unchanged (analog/report.md R2.2.1, 50 mOhm assumption).
