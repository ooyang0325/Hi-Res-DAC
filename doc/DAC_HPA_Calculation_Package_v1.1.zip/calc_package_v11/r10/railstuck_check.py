# Rail-stuck single leg (SE load on the stuck leg) while the partner leg of the pair still carries full-scale content:
# does the pair-difference detector ever see |Vd| >= its level long enough, and what do the leg windows give from history?
import numpy as np
VL_MIN, VL_MAX = 1.8020, 1.9985     # pair level (R9 check reproduction)
TP_MIN = 19.50e-3
A = 2.228                           # calibrated full-scale peak per leg
for vr in (3.789, 3.915):           # stuck at the VPOS minimum / maximum of the released divider
    for f in (20, 50, 100):
        t = np.arange(0, 0.2, 1e-5)
        vd = vr + A*np.sin(2*np.pi*f*t)          # LP stuck at +vr, LN = -s(t)  ->  Vd = vr + s(t)
        above = vd > VL_MAX
        # longest continuous time above the level
        run = best = 0
        for a in above:
            run = run + 1 if a else 0; best = max(best, run)
        print(f'stuck {vr:.3f} V, partner FS {f:3d} Hz sine: min Vd {vd.min():.3f} V; longest run above {VL_MAX:.3f} V = {best*1e-2:.1f} ms '
              f'-> pair detector {"trips" if best*1e-5 >= TP_MIN else "never trips (timer reset every cycle)"}')
# leg windows alone (slowest corner), SE load on the stuck leg
R = 115e3*(1+0.01+100e-6*40); C = 2.42e-6; tau = R*C; VT = 0.320; TX = 1.98e-3
for vr in (3.789, 3.915):
    for y0, lab in ((0.0, 'zero state'), (-0.081, 'after a 20 Hz negative half-cycle'), (-0.320, 'pre-charged to -0.32 V')):
        T = tau*np.log((vr - y0)/(vr - VT)) + TX
        print(f'  leg windows, stuck {vr:.3f} V, {lab:36s}: removal {T*1e3:5.1f} ms; SE 16 ohm {vr**2*T/16*1e3:5.1f} mJ (30), 32 ohm {vr**2*T/32*1e3:5.1f} mJ (15)')
