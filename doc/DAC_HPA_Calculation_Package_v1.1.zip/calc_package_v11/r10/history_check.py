# Independent quick check of R10-A finding 1 with the package's leg-window model (1-pole RC, slow corner).
import numpy as np
R = 115e3*(1+0.01+100e-6*40); C = 2.42e-6; tau = R*C          # slowest filter corner (p03: 282.2 ms)
VT = 0.320                                                   # highest trip level at the leg (p03 output)
TX = 1.98e-3                                                 # H fall + photorelay tOFF allowance (p03)
def run(u_hist, x, h=2e-5):
    y = 0.0
    for u in u_hist: y += (u - y) * h / tau                  # prior content
    y0 = y; t = 0.0
    while y < VT and t < 5.0:
        y += (x - y) * h / tau; t += h
    return y0, t + TX
h = 2e-5
f = 20.0; tt = np.arange(0, 0.025, h)
neg_half = -1.5*np.sin(2*np.pi*f*tt)                          # first negative half-cycle, 1.5 V peak per leg
for label, hist in [('zero state', np.array([])),
                    ('after one 20 Hz negative half-cycle (1.5 V pk)', neg_half),
                    ('filter pre-charged to -0.320 V (just below the opposite trip)', None)]:
    for x in (0.97, 0.99):
        if hist is None:
            y = -VT; t = 0.0
            while y < VT: y += (x - y)*h/tau; t += h
            y0, T = -VT, t + TX
        else:
            y0, T = run(hist, x)
        for Rl, lim in ((16.0, 30e-3), (32.0, 15e-3)):
            E = (2*x)**2 * T / Rl
            print(f'{label:62s} x={x:.2f} V/leg  start {y0*1e3:7.1f} mV  removal {T*1e3:6.1f} ms  {Rl:.0f} ohm bal {E*1e3:5.1f} mJ (limit {lim*1e3:.0f})')
# zero-state sweep from just above the trip (the package sweep starts at 1.02 x trip)
print('zero state, just above the trip:')
for k in (1.005, 1.01, 1.02, 1.05):
    x = k*VT; T = tau*np.log(x/(x-VT)) + TX
    print(f'  x = {k:.3f} x trip = {x:.3f} V/leg: removal {T*1e3:7.1f} ms, 16 ohm bal {(2*x)**2*T/16*1e3:5.1f} mJ, 32 ohm bal {(2*x)**2*T/32*1e3:5.1f} mJ')
