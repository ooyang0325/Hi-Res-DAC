# Digital stream — R8 review fixes (round 3) progress log

Session start: 2026-09-25 08:30 UTC. Scope: X-7, X-6 (digital parts), X-1, X-5, X-10, firmware list, report/BOM/netlist/scripts, check_design.

| Step | Status | Notes |
|---|---|---|
| 0. Read decisions_r8c / r8b / review evidence | in progress | |
| 0. Read decisions_r8c / r8b / review evidence | done 08:40 | Key finding: ESS vol_rate fastest = 0 -> 0.25*fs dB/s -> 127.5 dB mute takes 11.6 ms at 44.1 kHz: binding suspend order cannot meet 10 ms at fs <= 96 kHz full volume -> need bounded wait + CPLD fade (to document). Q207 = AO3400A (C20917, Basic, same as Q502-Q506/Q616/Q617). |
| 0b. Sources | done 08:47 | 74LVC3G34 Nexperia Rev 16 (12 Aug 2024): DC/DP pinout 1 1A,2 3Y,3 2A,4 GND,5 2Y,6 3A,7 1Y,8 VCC; tpd 0.5/2.2/4.1 ns (3.0-3.6 V, -40..85); IOFF +-2 uA; LCSC C548774 74LVC3G34DC,125 VSSOP-8, 1,604 stock, $0.7647. Type-C sink CC table: ST AN5225 Table 7 (cites Type-C R2.0 Aug 2019 as [22]): vRa -0.25/0.15 thr 0.2; vRd-USB 0.25/0.61 thr 0.66; vRd-1.5 0.70/1.16 thr 1.23; vRd-3.0 1.31/2.04; Rd +-10 % needed to detect capability. USB-IF R2.5 (Apr 2026) is a zip; not opened (no shell internet). |
| 1. Netlist/BOM (X-7, X-6, X-1, X-5, X-10 digital parts) | done 08:58 | gen_netlist_bom.py edited + rerun OK: U208 74LVC3G34DC C548774 (+C224 100 nF, outside the R236-R241 allocation, digital C2xx range), Q207 AO3400A, R236 10k, R237 4.7k, R238/R239 10k JTAG, R240 100k Q207 gate pull-up, R241 DNF 0R J201-1 (N2_J201_3V3); R233 retired; PA0 = ANA_SENSE; PB8 spare; 2520-only lands; U206 6-pin note. Backups *_r2_backup.* kept. 276 rows, 75 parts, 31 BOM lines, 12.06 USD. |
| 2. LED polarity | in progress | |
| 2. LED polarity | done 09:03 (NOT confirmed) | KENTO drawings not retrievable (LCSC cookie-gated viewer, no shell internet); netlist note says so; stays open (overlay before layout). |
| 3. Link timing | done 09:05 | clock_timing.py 3/3a: MISO loop +U208 4.1 ns -> 9 MHz margin +36.6 ns; 36 MHz writes: setup +1.13 ns, hold +4.30 ns with skew bound 3.6 ns (tpd range). |
| 4. firmware_sequences.py | in progress | |
| 4a. firmware_sequences.py s1/s2/s3/s4/s6/s8 | done 09:12 | IWDG /4 x 240 = 16.0-38.4 ms (margin 13.6 ms to 53 ms); RTC-alarm wake every 720 LSI = 12.0-28.8 ms; suspend: FADE (CPLD RTL) + mute vol_rate 0 + bounded wait (deadline 3.91 ms) -> <= 8.50 ms, margin 1.50 ms; binding order alone = 16.2 ms at 44.1 kHz (stated). Programming mode after SET_CONFIGURATION. Rate change with switch open. Backup firmware_sequences_r2_backup.py. |
| 4b. firmware_sequences.py s10-12 | done 09:15 | wake average <= 189 uA [ASSUMP-based] for the power suspend budget; Type-C table + downgrade <= 28.8 ms < tSinkAdj 60 ms (from memory); boot self-test a-d. |
| 5. ADC ANA_SENSE slot 9 + Type-C source | done 09:18 (text polish pending) | adc_settings.py runs, asserts pass; 9-slot scan 40.5 us/50 us, 20 kHz/ch. |
| 6. report.md R3 section | done 09:24 | inserted above R2; SOT-353 text fixed. |
| 7. check_design + ADC polish + pin_tables | done 09:28 | check: only RAIL_EN (power R507) and ANA_SENSE (power divider pending) - both power's pending edits. |
| 8. Final report notes | done 09:31 | all files saved; task complete except the items stated as not verified. |
| 9. Msg from r9-analog 08:55 | in progress | DIGITAL item: I2C-ramp double-failure fallback MCLK off -> AVCC_EN low -> 3V3A < 0.1 V -> PA8 high -> AUD_EN low (0.045 mV). Conflict: U605B (X-6) forces AUD_EN low at 3V3A < ~3.1 V. Also X-8 rail ramp >= 40 ms breaks the 20 ms RAILS_OK_N validity window. |
| 9b. Analog msg applied | done 09:05 (clock per msg) | fallback order in R3.2 Always-7 + fw §2 (2.84 <= 3.14 ms); U605B conflict flagged; T_START parametric (60 ms PH); wake alternative (+3.4 uA) for decision since power S6 is negative. |
| 9c. Messages sent | done | r9-analog (fallback conflict, T_START, I/V reservoirs), r11-power (T_START c11 time, S6 wake alternative, loads), r11-protection (U605 sink currents, self-test criteria, PB8 hook, pre-close limits). Awaiting replies. |
| 10. check_design re-run | done | only checker-list flags remain (ANA_SENSE not in IFACE; RAIL_EN absent) - integration to update check_design.py. |
| 11. Orchestrator DX-1..DX-3 (09:02) | in progress | DX-2: suspend IWDG <= 1.6 s -> /16 x 2500 = 40,000 LSI (0.67-1.60 s); wake must be shorter at the same LSI -> RTC 30,000 cycles (0.50-1.20 s), not 0.67-1.6 s. Tasks: firmware list, currents.py re-run. |
| 11a. firmware_sequences DX-2 | done | suspend IWDG /16 x 2500 (0.667-1.600 s), RTC 30,000 cycles (0.50-1.20 s); wake avg printed. |
| 11b. currents.py r3 + report DX-1..3 | done | currents re-run: S2/S3 digital 81.13 + 73.33 mA; S6 1.90 mA + 4.5 uA; U208 2.52 mA vs power 1.667 -> S3 margin breaks by ~1 mA (tell power). |
| 12. Final | done | power messaged (U208 +0.86 mA, JTAG +0.167 mA, S6 wake 4.5 uA). All files saved. |
| 13. Protection requests PB8/PA12/PB9 netted; IWDG RLR 239/2499; self-test per protection R3.9 | done | |
| 14. Analog reply 09:12 | done | Always-7 relabelled as the logged I2C-fault path (11.9/1.9 mV at 300 ohm, order kept); T_START confirmed, no extra I/V wait. |
| 15. Protection msg 09:13 | done | nets already added; R3.9 rules (EXTI priority, IRQ mask <= 1 ms, RELAY_EN latch, no MCLK stop for rate changes) in Always-3a; X201 load 14.4 pF incl. R665 tap, clock_timing re-run OK; DX-2 supersedes protection's suspend-wake option (noted). |
| 16. Protection answers 09:16 | done | uncalibrated leg-test windows + ramp note, as-built U605/U606 mapping, refusal thresholds 126/152 mV added; everything else already matched. |
| 17. Protection msg 09:19 | noted, no digital change | R3.9 now references DX-2; switch open <= 6.32 ms after the last SOF (5.31 + 1.008 ms), consistent with R3.2 C; R501/R672 fallback pairing is power/protection only. |
| 18. DZ-1/DZ-2/DZ-6 (10:11) | in progress | unfrozen for R242-R246, I2C 10k, post-CPLD stream guard |
| 18. DZ-1/DZ-2/DZ-6 | done | R242-R246 + nets, I2C 10k (257/428/856 ns), ADC settling OK (+0.42 mV), post-CPLD guard (4.0 % CPU at 384 kHz; 24.576 MHz capture [MEAS]); report R3.6; checker re-run. |
| 19. DY-2 + ANA_SENSE 1.226 V (10:17) | done | T_START 40 ms everywhere (RELAY_EN high 440.8 ms); ANA_SENSE < 1.226 V = code 1522; checker: no issues. |
| 20. Protection R3.17 T3 pair 0.120 V, refusal 129/155 mV (10:18) | done | firmware_sequences s9 constants + asserts; report R3.2 B.6/G and R2.5 G.3 marker. All queued items saved. |
| VE-0. VE round start (10:57) | in progress | reading ve/brief_ve.md |
| VE-0 | done 11:00 | brief read: O-1..O-4; digital candidates X202/X203, X201 (keep unless drop-in), U208; also check Economic blockers (U202 0.4 mm pitch, reflow ratings). |
| VE-1 | in progress | U208 -> TI SN74LVC3G34DCUR C130024 (VSSOP-8 same pinout, US$0.20 @5); X202/X203 -> Kyocera KC2520K49.152/45.1584 (6 mA run, 5 uA stby, 2520) under check |
| VE-1 U208 | done 11:17 | TI SN74LVC3G34DCUR C130024 adopted (US$0.2012 vs 0.7647): pinout identical, skew bound 2.7 ns (setup margin up), Ioff 10 uA; scripts re-run. |
| VE-2 X201/X202/X203/U205 | done 11:21 | X201 keep (D-3 search); X202/X203 keep NDK (Kyocera KC2520K45.1584 no authorized distributor; SiT8008 2520 standby not at LCSC and costlier); U205 keep (TI 1G3157 is an analog switch, 17 pF > NDK 15 pF load). |
| VE-3 report VE section + checker | done 11:25 | |
| VE-4 power follow-ups (11:10) | in progress | ANA_SENSE 1.279 V/1587; TSIGATT chain |
| VE-4 | done 11:16 | ANA_SENSE 1.279 V/1587, 32.0 k source settles (residual 9 mV at threshold); TSIGATT <= 79.2 ms (margin 20.8 ms), max acceptable 5V_SYS-up 71.1 ms; checker no issues. |
| OD-0. OD-1/OD-2 round start (14:00) | in progress | reading ve/brief_od.md, DZ-11/DZ-12 |
| OD-1a. OD-2 design | done 14:12 | EXTI9 on DAC_LOCK (20 us confirm) -> open <= 1.04 ms; Poll A 10 ms (reg64-65 + reg14 sentinel) -> <= 12.8 ms (stuck bus 13.8); Poll B 100 ms (reg0-20 + DPLL) -> <= 106.8 ms; GPIO2 forced low/high self-test; message sent to protection (times + OD-1 constants question). |
| OD-2 firmware_sequences s14 | done 14:15 | bus load 11.6 %, detection (a) 1.04 / (b,c) 12.85 / (c') 13.85 / (d) 106.8 ms switch open; self-test 2.3 ms. |
| OD report section (OD-2 complete, OD-1 framework) | saved 14:18 | waiting for protection OD-1 constants |
| OD-3 report final (OD-1 rule impl + OD-2 revised times 16.45/17.45/102.4 ms, bus 27.4 %) | done 14:30 | script rebuilt after a duplicate-block bug (backup-based, verified single sections) |
| OD-4 | done 14:32 | final times sent to protection; all files saved; checker no issues. |
| OD-5 protection 14:08 msg (crossed) | done | N = ceil(0.022 fs), exposure 23.6 <= 24 ms added; one reply to protection with RELAY_EN-low times. |
| OD-6 protection final rule (14:10) | done | P2 0.25 FS, P4 CIC2 2x150 ms >= 0.15 FS added (block sums, 12.5 KB RAM both guards, CPU unchanged); energies 13.8/25.3 mJ bal, 3.6/6.9 SE in report. |
| OD-7 | done | P2/P4 content consequence stated; all saved. |
| OD-8 protection 14:13 | noted, no change | constants P1-P4 match s13; protection uses the final s14 file values 16.45/17.45/102.43 ms (energies <= 10.1 mJ) - they are final, no reply needed. |
| R9-0. R9 round start (16:59) | in progress | reading r9/reviews_r9.md, r9/decisions_r9.md |
| R9-0 | done 17:02 | read decisions E-1..E-15; digital: E-2 fw re-arm, E-9 lead, E-10, E-11, E-12, E-5 fw |
| R9-1 E-11 calc + msg to protection | done 17:12 | R665 330R OK (<=14.23 pF) only with MCLK trace <=10 mm rule; asked protection for E-2/E-3 pin + re-arm timing |
| R9-2 E-10 | done 17:18 | GPIO2 = lock permanently; GPIO1 (NC pin) = min-volume flag read via reg 65 b0 (reg 64 has no min-volume bit - ESS DS); reg 8 = 0x12; suspend <= 8.45 ms (deadline 5.31 ms kept); self-test regs 0x72/0xF2/0x12 |
| R9-3 E-9/E-12/E-5 sections in firmware_sequences (15-17) | done 17:25 | canonical S1-S8 table + 10 exits; ENGINE_RST sequence (RTL) + CPLD_NRST fallback; suspend pin states 0 A + 4.5 uA wake |
| R9-4 report R9 section | saved 17:29 | E-10/E-11/E-12/E-9/E-2/E-5 rows |
| R9-5 messages | done 17:31 | power (E-9 rows, E-5 divider table, PB0 offer), analog (E-9 rows, GPIO2 note) |
| R9-6 power reply (17:13) | done | E-9 corrections adopted (S6 bounds 0.472/0.63 ms, C441 -> >= 0.75 ms; DVDD <= DVCC wording; brown-out ISR adds AUD_EN; Q502/Q503 in reset row); E-5: x1.5 rejected by power, PB0 not netted, owner option (a)/(b) noted |
| R9-7 E-11 answer + PB0 netted (N6_ARM_MCU) | done 17:40 | load 14.2 pF (10 mm rule, full tap 2.4 pF), XI >= 5.49 ns; MCU 47 used, 2 spare (PC14/PC15) |
| R9-8 E-2 re-arm + report rows | done 17:44 | PB0 N6_ARM_MCU; DC_PERMIT_N low >= 150 ms; power-up close 540.8 ms, family worst 972 ms |
| R9-9 replies | done 17:46 | protection (E-11 answer, E-2 done), power FYI (PB0 taken, PC14 for option a); checker no issues |
| R9-10 E-16 start | in progress | PC14 -> N5_U102_OFF (high = U102 off); asked power for T_DOM_OFF after S7 (budget 1.45 ms) |
| R9-11 E-16 fw + report + currents | done (T_DOM_OFF placeholder 1.45 ms, awaiting power) | PC14 N5_U102_OFF; S9/R0 in E-9 table; U102 off 9.80 ms, Stop 9.90 ms; fallback deadline 4.31 ms proposed |
| R9-12 | done | checker: only N5_U102_OFF single-pin (power's NMOS pending); awaiting power T_DOM_OFF |
| R9-13 analog E-9 confirmation (17:19) | done | S1-S7 confirmed (<= 1.46 mV); S4/S5 bring-up condition + S5-after-S6 fallback; MCU-reset click (L-4) noted |
| R9-14 protection self-test a'/e (17:20) | done | a' +-0.35 FS 80-165 ms, e +-0.5 FS 18-26 ms; self-test <= 7.1 s (owner-visible ~7 s first audio after attach) |
| R9-15 power E-16 facts (17:21) | done | net N1_U102_OFF (Q507/R537); U102 off at 8.35 ms, Stop 8.45 ms; resume >= 4.0 V/60 ms; brown-out dropout fact + [MEAS] 3V3M <= 50 mA; VREFINT option proposed |
| R9-16 protection answers (17:23) | done | E-11 330R adopted by protection; re-arm: RELAY_EN low >= 1 ms + DC_PERMIT_N low continuously >= 150 ms; E-3 no MCU pin/tap |
| R9-17 follow-ups (17:25) | in progress | (1) self-test <= 3 s; (2) VREFINT cross-check |
| R9-18 follow-ups | done (R pending protection) | self-test 1.27 s + 8R (<= 3 s if R <= 216 ms); VREFINT not adopted (ADC scan budget), PVD on 3V3M adopted |
| R9-19 power 17:29 | done | option (a) dropped (no change); attach: VBUS_SENSE = 0 in early boot ignored, AWD after 5V_SYS good (60 ms); TSIGATT now <= 23.9 ms |
| R9-20 net-name mismatch | open (power) | power netlist Q507/R537 on N5_U102_OFF vs its message N1_U102_OFF; digital keeps N1_ (block 1), asked power to rename |
| R9-21 power 17:30 | done | net N5_U102_OFF (power's name) - checker no issues; S9 = S7 + 0.1 ms; suspend current <= 8.75 ms (margin 1.25 ms), Stop 8.55 ms |
| R9-22 protection self-test p20 (17:31) | done | a' +-0.39 FS (70-140 ms, default +-0.65 FS), R <= 209 ms -> self-test 2.84 s <= 3 s |
| R9-23 protection R per type (17:32) | noted | a' 209 / e 207 / b 208 / c 206 ms -> 2.75 s exact, 2.84 s conservative kept |
| R9-24 power 17:34 | confirmed | N5_U102_OFF everywhere (no N1_ left in report/scripts/netlist) |
