#!/usr/bin/env python3
"""Timing numbers behind the merged firmware sequences (report section 8A).

Inputs and their sources:
  switch (photorelay) tON <= 5 ms at IF 5 mA, tOFF <= 0.5 ms [DS Toshiba TLP3545A s.15, 25 C]; design over 0-60 C: tON 10 ms,
    switch open <= 1.01 ms after RELAY_EN low incl. the driver [protection/report.md R2.4]
  X201 Kyocera KC2520K80.0000C1GE00 80 MHz (D-3 revised): t_sta, t_ena <= 2 ms [DS spec] (3 ms catalogue/D-3), t_dis <= 200 ns;
    conditional 2nd source NDK NSC5338D-80M: start-up <= 4 ms [parts FU-3]
  NDK NZ2520SDA start-up <= 4 ms [DS]; SiT8008 start-up/resume <= 5 ms [DS]
  WCH CH32V307: HSI accuracy +-2.2 % over temperature (Tab 4-14), LSI 25..60 kHz (Tab 4-15), PLL lock <= 200 us
    (Tab 4-16), HSE start-up <= 4 ms (Tab 4-12), Stop wake-up 76.7 us typ with the LP regulator (Tab 4-19)
  power stream: SOF-loss rule 1.0 ms; ANA_EN -> RAIL_EN >= 5 ms; RAILS_OK_N valid >= 20 ms after RAIL_EN;
    AVCC_EN -> AUD_EN >= 1 ms; discharge 3V3A <= 0.35 ms, 3V3D <= 0.525 ms, 1V3 <= 0.21 ms; suspend <= 10 ms
  analog stream: MCLK >= 2 ms after 1V3; RESETB >= 1 ms after supplies + MCLK stable; soft start x 1.2 (104.9 ms at 80 MHz
    -> 125.8 ms, clock_timing.py 5);
    mute-ramp timeout 1.5 x ramp; lock timeout 1.5 x 16384/fs + 10 ms; +10 ms after lock;
    power-down ramp-to-ground step (analog R2, COFF coupling): reg 14 = 0x03 (soft_start 0, soft_start_time 3) after the switch
    is open, wait 1.1 ms, then MCLK stop and RESETB low; brown-out ISR: RELAY_EN and AVCC_EN low together, no wait
  protection stream: pre-close checks need DC_PERMIT_N low and valid DC readings for >= 50 ms and V3A_MON in window
    >= 150 ms; DC_PERMIT_N reads 'permitted' <= 205 ms after the CM window clears (end of the DAC soft start, taken at the
    analog x1.2 allowance because ESS does not fix the ramp start), CM/clock-fault timeout 300 ms after it [protection R2.7]; IWDG <= 100 ms;
    DC_PERMIT_N rising -> RELAY_EN low <= 50 us; retry 2 s; 3 trips in 10 s -> lock-out; overload ceiling -3 dB steps
Run: python3 firmware_sequences.py > firmware_sequences_output.txt
"""
import math

T_SW_ON = 10.0e-3                      # volume ramp after RELAY_EN high: TLP3545A tON 5 ms x2 over 0-60 C [protection R2.4]
T_SW_OFF_DS = 0.5e-3
T_SW_OFF_BOUND = 1.01e-3
T_SW_OFF_WAIT = 1.1e-3
assert T_SW_OFF_WAIT >= T_SW_OFF_BOUND >= T_SW_OFF_DS

print("1. Firmware constants")
print(f"   switch: wait {T_SW_ON*1e3:.1f} ms after RELAY_EN high before the volume ramp (tON max); wait "
      f"{T_SW_OFF_WAIT*1e3:.1f} ms after RELAY_EN low before any analog-state change (>= protection bound "
      f"{T_SW_OFF_BOUND*1e3:.2f} ms; photorelay tOFF alone {T_SW_OFF_DS*1e3:.1f} ms)")
hsi_acc = 0.022
t_low = 5e-3 / (1 - hsi_acc)
print(f"   low-clock phase after reset: >= 5 ms real time timed on HSI (+-2.2 %) -> program {math.ceil(t_low*1e4)/10:.1f} ms")
lsi_min, lsi_max, presc = 25e3, 60e3, 4
reload = 239                                   # round 3: RLR 239 -> (RLR+1) x 4 = 960 LSI cycles (aligned with protection R3.9)
t_iwdg_min, t_iwdg_max = (reload + 1) * presc / lsi_max, (reload + 1) * presc / lsi_min
T_PERMIT_RECOVER_MIN = 53e-3                   # protection: H can re-close >= 53 ms after a trip clears (states #6)
print(f"   IWDG: prescaler /{presc}, RLR {reload} ({(reload+1)*presc} LSI cycles, (RLR+1) convention; RLR x presc would give 956) -> timeout {t_iwdg_min*1e3:.1f} .. {t_iwdg_max*1e3:.1f} ms "
      f"(LSI 25-60 kHz [DS Tab 4-15]); refresh from the main loop every <= 5 ms, only when all tasks report alive")
print(f"   hung MCU: reset <= {t_iwdg_max*1e3:.1f} ms + switch open <= {T_SW_OFF_BOUND*1e3:.2f} ms = {(t_iwdg_max+T_SW_OFF_BOUND)*1e3:.1f} ms "
      f"< {T_PERMIT_RECOVER_MIN*1e3:.0f} ms (earliest hardware re-close) -> margin {(T_PERMIT_RECOVER_MIN-t_iwdg_max-T_SW_OFF_BOUND)*1e3:.1f} ms")
assert t_iwdg_max <= 0.040 and t_iwdg_max + T_SW_OFF_BOUND < T_PERMIT_RECOVER_MIN
# DX-2 (orchestrator, 25 Sep 2026): <= 40 ms whenever RELAY_EN may be high or any switched domain is on; in suspend (RELAY_EN low,
# all switched domains off, MCU in Stop) the IWDG is lengthened to <= 1.6 s with a periodic RTC-alarm wake that refreshes it.
PRESC_S, RELOAD_S = 16, 2499                    # suspend IWDG: (RLR+1) x 16 = 40,000 LSI cycles
RTC_TICK = 30_000                               # RTC PRL = 29,999 (permanent; the RTC is only the wake timer); ALR += 1 per wake
ti_s_min, ti_s_max = PRESC_S * (RELOAD_S + 1) / lsi_max, PRESC_S * (RELOAD_S + 1) / lsi_min
t_wk_min, t_wk_max = RTC_TICK / lsi_max, RTC_TICK / lsi_min
print(f"   suspend IWDG (DX-2): /{PRESC_S}, RLR {RELOAD_S} -> {PRESC_S*(RELOAD_S+1)} LSI cycles = {ti_s_min:.3f} .. {ti_s_max:.3f} s (<= 1.6 s); RTC-alarm")
print(f"   wake every {RTC_TICK} LSI cycles = {t_wk_min:.2f} .. {t_wk_max:.2f} s (same LSI as the IWDG -> margin {PRESC_S*(RELOAD_S+1)-RTC_TICK} cycles ="
      f" {(PRESC_S*(RELOAD_S+1)-RTC_TICK)/lsi_max:.2f} .. {(PRESC_S*(RELOAD_S+1)-RTC_TICK)/lsi_min:.2f} s, no tolerance stack).")
print("   (A 0.67-1.6 s wake cannot sit inside a <= 1.6 s timeout on the same LSI: the wake is set to 75 % of the timeout.)")
assert ti_s_max <= 1.6 + 1e-12 and RTC_TICK < PRESC_S * (RELOAD_S + 1)
print("   order: entry - after PC10/PC11 low, write the suspend PR/RLR during the 0.53 ms discharge wait (PVU/RVU <= 5 LSI cycles")
print("   = 0.2 ms, inside the wait), then ANA_EN low, refresh (long timeout starts), Stop -> the suspend bound is unchanged;")
print("   exit - first action after the Stop exit: write /4, RLR 239, wait PVU/RVU (<= 0.2 ms), refresh -> 16.0 .. 38.4 ms BEFORE any")
print("   domain (ANA_EN) is enabled; every run state (attach, configured, programming) uses the short timeout.")
T_STR_X201 = 3e-3                      # Kyocera t_sta/t_ena <= 2 ms [DS spec], 3 ms [catalogue, D-3]
T_MCLK_SETTLE = 6e-3                   # firmware wait after the enable edge: NDK 4 ms x 1.5 (Kyocera 3 ms x 2)
T_RESETB = T_MCLK_SETTLE + 1e-3        # ESS: RESETB >= 1 ms after MCLK stable -> 7 ms after MCLK_EN/MCLK_PERMIT
F_MCLK = 80e6                          # firmware build constant (D-3 revised)
t_x201 = T_MCLK_SETTLE
print(f"   X201: MCLK stable <= {T_STR_X201*1e3:.0f} ms (Kyocera; 2 ms spec) / 4 ms (NDK) after INH high -> firmware waits "
      f"{T_MCLK_SETTLE*1e3:.0f} ms, RESETB high >= {T_RESETB*1e3:.0f} ms after MCLK_EN/MCLK_PERMIT")
print("   X201 stop: MCLK_PERMIT low -> U206 <= 4.9 ns -> Kyocera stand-by <= 200 ns [DS]; PB1 readback must read 0 within 10 us;")
print("   the same U206 output gates the output switch (Q616 via R645, D-19)")
print(f"   F_MCLK = {F_MCLK/1e6:.0f} MHz build constant: soft-start wait {1.2*4096*2**11/F_MCLK*1e3:.1f} ms, DPLL table at 80 MHz; the first lock")
print("   checks FSR x 2^32 / DPLL_NUM within +-0.1 % of F_MCLK")
t_osc = 10e-3
print(f"   family oscillator: enable -> use >= {t_osc*1e3:.0f} ms (NDK 4 ms x 2.5; SiT8008 5 ms x 2)")

print()
print("2. Suspend / bus reset / disconnect timeline from the last SOF (USB 2.0 7.1.7.6: suspend current <= 10 ms)")
spi_word = 32 / 9e6                          # one REG_WRITE (16-bit header + 16-bit data) at 9 MHz
i2c_w = 30 / 100e3                           # ES9018K2M single register write at 100 kHz ~ 30 bit times
i2c_burst2 = 30 / 100e3                      # R9 E-10: reg 7 = 0x83 (mute) only; reg 8 = 0x12 permanent (GPIO2 = lock, GPIO1 = min volume)
T_RAMP_GND = 4096 * 2 ** (3 + 1) / F_MCLK    # reg 14 = 0x03: soft_start 0, soft_start_time 3 -> ramp to ground [DS reg 14]
assert abs(T_RAMP_GND - 0.8192e-3) < 1e-6
T_RAMP_WAIT = 1.1e-3                         # >= 0.819 ms ramp + margin (analog R2)
VOL_RATE = 0                                 # fastest: 0.0078125 x fs / 2^(vol_rate-5) dB/s [DS reg 6] = 0.25 x fs dB/s; kept at init


def mute_time(fs, att_db=0.0):
    """ESS soft mute from the present attenuation to -inf: (127.5 - att) dB + one 0.5 dB step at 0.25 fs dB/s."""
    return (127.5 - att_db + 0.5) / (0.0078125 * fs / 2 ** (VOL_RATE - 5))


T_DET = 1.02e-3                              # SOF-loss timer 1.0 ms (D-16) + ISR 20 us [ASSUMP]
T_FLAG = 2 * 39 / 100e3                      # R9 E-10: min-volume flag read over I2C (reg 65 bit 0 = GPIO1 pin), back-to-back 0.39 ms reads -> <= 2 reads
T_CPLD_FADE = 1.0e-3                         # RTL requirement (round 3): FADE command -> linear 1 ms ramp to digital zero
T_DAC_PIPE = 1.0e-3                          # ESS filter/pipeline delay bound [ASSUMP: ~40 samples at 44.1 kHz]
post = [("RELAY_EN low; wait T_SW_OFF_WAIT (switch open <= 1.01 ms)", T_SW_OFF_WAIT),
        ("I2C reg 14 = 0x03 (ramp to ground; NACK -> retry once, then continue and log)", i2c_w),
        ("wait for the ramp (1.1 ms); MCLK still running", T_RAMP_WAIT),
        ("MCLK_PERMIT low (X201 stopped <= 0.2 us, Q616 off), PB1 = 0; SPI CLOCK_CTRL = 0, I2S_CTRL = 0", 1e-6 + 2 * spi_word),
        ("PA8 HIGH (Q207 on -> DAC reset); N2_LINK_*_MCU low (before AUD_EN, states #17)", 0.2e-6),
        ("PC10 (AUD_EN) + PC11 (AVCC_EN) low in one GPIOC write; wait 3V3D discharge bound 0.53 ms", 0.53e-3),
        ("ANA_EN low (X-1: rails stop with 5V_ANA_F), ILIM_HI low, LEDs off", 1e-6),
        ("enter Stop (USBHS PHY suspended) [ASSUMP 0.1 ms]", 0.1e-3)]
t_post = sum(d for _, d in post)
T_3V3A_DIS = 0.35e-3                          # 3V3A EN-derived discharge bound (power)
post_fb = [("RELAY_EN low; wait T_SW_OFF_WAIT", T_SW_OFF_WAIT), ("reg 14 = 0x03 write, NACK", i2c_w), ("retry, NACK", i2c_w),
           ("fallback (analog): MCLK_PERMIT low + CLOCK_CTRL/I2S_CTRL = 0 (MCLK off)", 1e-6 + 2 * spi_word),
           ("PC11 AVCC_EN low -> U605B pulls AUD_EN low at 3V3A < ~3.1 V (X-6): 3V3D/1V3 decay in parallel; wait 3V3A < 0.1 V "
            "(V3A_MON, bound 0.35 ms + margin)", 0.5e-3),
           ("PA8 HIGH (RESETB low), link pins low, PC10 low; wait the rest of the 3V3D bound (0.53 ms, counted in full)", 0.53e-3),
           ("ANA_EN low, ILIM_HI low, LEDs off", 1e-6), ("enter Stop", 0.1e-3)]
t_post_fb = sum(d for _, d in post_fb)
assert t_post_fb <= t_post, "fallback path must not lengthen the suspend timeline"
MARGIN = 1.5e-3
T_MUTE_DEADLINE = 5.31e-3 - (T_DET + i2c_burst2)   # DX-1: deadline anchored at 5.31 ms after the last SOF (unchanged by E-10)
print(f"   {T_DET*1e3:6.3f} ms  SOF-loss timer (1.0 ms, D-16) + ISR; SPI FADE command to the CPLD (RTL: 1 ms linear ramp to zero)")
print(f"   {(T_DET+i2c_burst2)*1e3:6.3f} ms  I2C: reg 7 = 0x83 (soft mute, vol_rate 0 kept since init); reg 8 = 0x12 stays (GPIO2 = lock, GPIO1 = min vol)")
print(f"            poll reg 65 bit 0 (GPIO1 = minimum volume) back-to-back over I2C (<= {T_FLAG*1e3:.2f} ms detection), bounded by the deadline 5.31 ms after the last SOF")
print(f"   then the round-2 power-down order ({t_post*1e3:.2f} ms):")
for n, d in post:
    print(f"            +{d*1e3:5.3f} ms  {n}")
print(f"   mute ramp (vol_rate 0 = 0.25 x fs dB/s) from 0 dB attenuation, and the resulting suspend-current time:")
print(f"   {'fs':>7} {'ramp':>8} {'status by':>10} {'suspend at':>10} {'margin':>7}  att. needed for status  level at deadline")
rows_s = []
for fs in (44_100, 48_000, 88_200, 96_000, 176_400, 192_000, 352_800, 384_000):
    tr = mute_time(fs)
    t_wait = min(tr, T_MUTE_DEADLINE)
    t_s = min(T_DET + i2c_burst2 + tr + T_FLAG, 5.31e-3) + t_post   # flag path or the SOF-anchored deadline, whichever first
    att_need = max(0.0, 128.0 - 0.25 * fs * T_MUTE_DEADLINE)
    lvl = -min(128.0, 0.25 * fs * T_MUTE_DEADLINE)
    rows_s.append((fs, tr, t_s))
    print(f"   {fs:7d} {tr*1e3:6.2f} ms {'status' if tr <= T_MUTE_DEADLINE else 'deadline':>10} {t_s*1e3:8.2f} ms {(10e-3-t_s)*1e3:5.2f} ms"
          f"  >= {att_need:5.1f} dB             {lvl:6.1f} dB (DAC ramp alone)")
    assert t_s <= 10e-3 - MARGIN + 1e-9
t_susp = max(r[2] for r in rows_s)
t_zero = T_DET + spi_word + T_CPLD_FADE + T_DAC_PIPE
print(f"   -> suspend current reached <= {t_susp*1e3:.2f} ms after the last SOF at every fs and volume; margin >= {(10e-3-t_susp)*1e3:.2f} ms [CALC]")
print(f"   The binding order alone (wait for the status with no deadline) needs {(T_DET+i2c_burst2+mute_time(44_100)+T_FLAG+t_post)*1e3:.1f} ms at 44.1 kHz")
print(f"   and 0 dB attenuation (> 10 ms): at fs <= 96 kHz the status can come after the deadline. The CPLD FADE makes the")
print(f"   deadline pop-free: digital zero at the DAC output <= {t_zero*1e3:.2f} ms after the last SOF (< deadline "
      f"{(T_DET+i2c_burst2+T_MUTE_DEADLINE)*1e3:.2f} ms), so the switch opens on the muted/zero-code output at every fs.")
assert t_zero < T_DET + i2c_burst2 + T_MUTE_DEADLINE
print(f"   (FIFO content at SOF loss, 11.61 ms max at 44.1 kHz, is faded by the CPLD, not truncated.)")
print(f"   I2C double failure (reg 14 NACK twice): analog fallback order MCLK off -> AVCC_EN low -> 3V3A < 0.1 V -> PA8 high ->")
print(f"   PC10 low takes {t_post_fb*1e3:.2f} ms after the status (normal path {t_post*1e3:.2f} ms) -> the suspend bound is unchanged.")
print(f"   Logged I2C-fault path, NOT a controlled transition: with X-6, U605B collapses DVCC/DVDD 75-240 us after AVCC_EN low")
print(f"   (3V3A still ~3.1 V); analog worst case 11.9 mV (22 % mismatch) / 1.9 mV (3 %) at 300 ohm vs 12.9 / 2.1 mV PA8-first -> order kept.")
print(f"   Hung-at-suspend: IWDG resets <= {t_iwdg_max*1e3:.1f} ms after the last refresh -> switch open, ENs to pull-downs; the")
print(f"   <= 10 ms deadline itself is firmware-only (states #21 residual).")

print()
print("3. Power-up after SET_CONFIGURATION (t = 0), relay open until the pre-close checks pass")
T_RAILS_GOOD = 18.8e-3         # power c18 (DY-2): rails good <= 18.8 ms after ANA_EN with C514 10 nF
T_START = 40e-3                # DY-2: start-up window - RAILS_OK_N and ANA_SENSE judged, AVCC_EN allowed, only after ANA_EN = 1 for 40 ms
ANA_TH_PIN = 4.0 * 47 / 147     # power VE: R535/R536 100 k/47 k -> 1.279 V at 5V_ANA_F = 4.0 V (1587 counts)
ANA_TH_CODE = round(ANA_TH_PIN / 3.3 * 4096)
print(f"   start-up window T_START = {T_START*1e3:.0f} ms (DY-2): rails good <= {T_RAILS_GOOD*1e3:.1f} ms (power c18), I/V rails final <= +1 ms (analog)")
print(f"   -> margin {(T_START-T_RAILS_GOOD-1e-3)*1e3:.1f} ms. ANA_SENSE fault threshold {ANA_TH_PIN:.3f} V at the pin (5V_ANA_F 4.0 V, power divider) = ADC")
print(f"   code < {ANA_TH_CODE} at VDDA 3.30 V (VDDA = 3V3M +-1.5 % moves the 5V_ANA_F equivalent by +-1.5 %: 3.94..4.06 V) [CALC]")
assert T_START >= T_RAILS_GOOD + 1e-3 and T_START >= 20e-3
T_CFG_TYP, T_CFG_MAX = 10e-3, 100e-3        # CPLD configuration: not published -> typical placeholder / ID-poll timeout
i2c = (5 * 29 + 56) / 100e3                  # 5 single-byte writes + one 4-byte master-trim burst at 100 kHz
for label, t_cfg in (("CPLD config 10 ms [ASSUMP]", T_CFG_TYP), ("CPLD config 100 ms (timeout)", T_CFG_MAX)):
    ev = {}
    ev["ANA_EN"] = 0.0
    ev["rails good valid (X-1: RAILS_OK_N valid with ANA_EN = 1 >= T_START)"] = ev["ANA_EN"] + T_START
    ev["AVCC_EN"] = ev["rails good valid (X-1: RAILS_OK_N valid with ANA_EN = 1 >= T_START)"]
    ev["AUD_EN"] = ev["AVCC_EN"] + 1e-3        # PC10 high; U605B releases AUD_EN only once 3V3A is good (X-6)
    ev["CPLD ID ok"] = ev["AUD_EN"] + t_cfg
    ev["family osc on"] = ev["CPLD ID ok"]
    ev["MCLK_PERMIT, MCLK_EN"] = max(ev["CPLD ID ok"], ev["AUD_EN"] + 3e-3)
    ev["MCLK self-test (PB1 = 0 with PERMIT low, 1 with PERMIT high)"] = ev["MCLK_PERMIT, MCLK_EN"]
    ev["RESETB high"] = ev["MCLK_PERMIT, MCLK_EN"] + T_RESETB
    ev["I2C init done"] = ev["RESETB high"] + i2c
    ev["I2S_RUN (osc settled)"] = max(ev["I2C init done"], ev["family osc on"] + t_osc)
    ev["soft-start end, taken at the analog x1.2 allowance (104.9 ms x 1.2 after I2C init)"] = ev["I2C init done"] + 1.2 * 4096 * 2 ** 11 / F_MCLK
    ev["DC_PERMIT_N low (<= 205 ms after the soft-start end; CM/clock fault at 300 ms)"] = ev["soft-start end, taken at the analog x1.2 allowance (104.9 ms x 1.2 after I2C init)"] + 205e-3
    ev["pre-close checks (DC_PERMIT_N low >= 150 ms after a trip - R9 E-2 re-arm; the soft-start CM trip counts)"] = ev["DC_PERMIT_N low (<= 205 ms after the soft-start end; CM/clock fault at 300 ms)"] + 150e-3
    ev["V3A_MON in window >= 150 ms"] = ev["AVCC_EN"] + 0.2e-3 + 150e-3
    ev["RELAY_EN high (fresh low->high edge; PB0 = armed within 1 ms)"] = max(ev["pre-close checks (DC_PERMIT_N low >= 150 ms after a trip - R9 E-2 re-arm; the soft-start CM trip counts)"], ev["V3A_MON in window >= 150 ms"])
    print(f"   {label}:")
    for k, v in sorted(ev.items(), key=lambda kv: kv[1]):
        print(f"      {v*1e3:7.1f} ms  {k}")
    for fs in (44_100, 48_000, 384_000):
        lock = ev["I2S_RUN (osc settled)"] + 16384 / fs + 10e-3
        unmute = max(ev["RELAY_EN high (fresh low->high edge; PB0 = armed within 1 ms)"] + T_SW_ON, lock)
        print(f"      fs {fs:6d}: lock + 10 ms at {lock*1e3:6.1f} ms -> unmute (volume ramp starts) at {unmute*1e3:6.1f} ms")

print()
print("4. Rate / family change - round 3: with the output switch OPEN (states #9: mute -> RELAY_EN low -> change/relock ->")
print("   pre-close checks -> close -> ramp); the table below is the mute/lock part, the switch-open total follows it")


def ramp(fs):
    return 127.5 / (0.0078125 * fs / 2 ** (2 - 5))    # vol_rate = 2 (default) [DS p.6]


print(f"   {'old fs':>7} {'new fs':>7} {'mute ramp':>10} {'timeout':>8} {'lock':>8} {'timeout':>8} {'total':>8}")
worst = 0
for old, new, fam in ((48_000, 44_100, True), (44_100, 48_000, True), (384_000, 44_100, True), (44_100, 88_200, False),
                      (192_000, 384_000, False), (352_800, 384_000, True)):
    t_m = ramp(old)
    t_lock = 16384 / new
    total = t_m + 0.1e-3 + (t_osc if fam else 0) + 0.1e-3 + t_lock + 10e-3 + ramp(new)
    worst = max(worst, total)
    print(f"   {old:7d} {new:7d} {t_m*1e3:8.1f} ms {1.5*t_m*1e3:6.1f} ms {t_lock*1e3:6.1f} ms "
          f"{(1.5*t_lock+10e-3)*1e3:6.1f} ms {total*1e3:6.1f} ms{'  (family change)' if fam else ''}")
print(f"   -> worst case {worst*1e3:.0f} ms with the default vol_rate 2 (round-2 table, kept for reference)")
worst_open = 0
for old, new, fam in ((48_000, 44_100, True), (44_100, 48_000, True), (384_000, 44_100, True), (44_100, 88_200, False),
                      (192_000, 384_000, False), (352_800, 384_000, True)):
    t_tot = (1.5 * mute_time(old) + T_FLAG + T_SW_OFF_WAIT + 0.1e-3 + (t_osc if fam else 0) + 0.1e-3 + 1.5 * 16384 / new + 10e-3
             + 205e-3 + 150e-3 + T_SW_ON + mute_time(new))   # R9 E-2: >= 150 ms DC_PERMIT_N low if a trip occurred (conservative: always)
    worst_open = max(worst_open, t_tot)
print(f"   switch-open sequence (mute timeout 1.5 x ramp at vol_rate 0, 1.1 ms open, osc 10 ms, lock timeout 1.5 x 16384/fs + 10 ms,")
print(f"   DC_PERMIT_N re-grant <= 205 ms + 50 ms pre-close, close, 10 ms, unmute ramp): worst {worst_open*1e3:.0f} ms [CALC]; MCLK is never touched")

print()
print("4a. Attach: D+ pull-up within TSIGATT <= 100 ms of VBUS valid (USB 2.0 7.1.7.3); t = 0 at plug-in (VBUS valid)")
T_5VSYS = 0.0            # R9 E-16: U502 TPS70933 is fed from VBUS -> the MCU no longer waits for U102 (5V_SYS up <= 55.3 ms runs in parallel)
T_LDO = 1.15e-3          # power: TPS7A20 (U502) start-up to 3V3M
T_NRST = 10e3 * 1.01 * 100e-9 * 1.1 * math.log(1 / (1 - 0.7))   # R201 10 k x C212 100 nF (+10 %) to VIH 0.7 VDD [ASSUMP VIH]
T_POR = 10e-3            # CH32V307 POR/reset temporization + flash-to-zero-wait-SRAM load at boot [ASSUMP <= 10 ms, as power c20 b; not in the retrieved DS text]
T_FW = [("low-clock phase on HSI (attach current rule, power I3c)", 5.2e-3), ("HSE start-up <= 4 ms [DS Tab 4-12]", 4e-3),
        ("PLL lock <= 0.2 ms [DS]", 0.2e-3), ("USBHS PHY PLL [ASSUMP]", 1e-3), ("USB core init, D+ pull-up enabled [ASSUMP]", 1e-3)]
t = T_5VSYS + T_LDO + max(T_NRST, 0) + T_POR
print(f"   {T_5VSYS*1e3:6.2f} ms  VBUS valid; U502 (TPS70933, on VBUS since E-16) starts at once; 5V_SYS (U102) comes up <= 55.3 ms later, in parallel")
print(f"   {(T_5VSYS+T_LDO)*1e3:6.2f} ms  3V3M up (LDO start-up 1.15 ms [ASSUMP, as the TPS7A20 figure])")
print(f"   {t*1e3:6.2f} ms  MCU out of reset: NRST RC {T_NRST*1e3:.2f} ms (R201/C212, VIH 0.7 VDD) + POR/boot load {T_POR*1e3:.0f} ms [ASSUMP]")
for n, d in T_FW:
    t += d
    print(f"   {t*1e3:6.2f} ms  {n}")
T_SIGATT = t
TSIGATT_MAX = 100e-3
print(f"   -> D+ pull-up (attach signalled) <= {T_SIGATT*1e3:.1f} ms after VBUS valid; TSIGATT 100 ms -> margin {(TSIGATT_MAX-T_SIGATT)*1e3:.1f} ms [CALC on ASSUMP]")
print("      The CC classification (100 ms stable window) and ADC start run in parallel and do not delay the pull-up; High mode waits for them.")
print("      E-16: the U102 switch-on delay (<= 55.3 ms) no longer affects TSIGATT; it only delays the audio power-up (5V_SYS good first).")
assert T_SIGATT < TSIGATT_MAX

print()
print("5. Resume from suspend (host resume; remote wake-up not used)")
t_wake = 76.7e-6 + 4e-3 + 200e-6 + 1e-3
print(f"   Stop exit 76.7 us [DS-typ] + HSE <= 4 ms [DS] + PLL <= 0.2 ms [DS] + USBHS PHY PLL <= 1 ms [ASSUMP] = "
      f"{t_wake*1e3:.2f} ms before the USB core is clocked")
print("   USB: host drives resume >= 20 ms and the device must respond 10 ms after it ends [USB 2.0, values not re-read]")
print(f"   -> margin >= {30-t_wake*1e3:.1f} ms; the audio power-up (section 3) runs after the bus is active again")

print()
print("6. MCU reset / IWDG (hardware only; firmware absent)")
for t_, e in ((0.0, "NRST low, PDR, or IWDG expiry: every GPIO becomes a floating input"),
              (0.19e-6, "MCLK_PERMIT < 0.8 V via R234 -> U206 Y low (4.9 ns)"),
              (0.39e-6, "X201 stand-by, oscillation stopped (Kyocera t_dis <= 200 ns) -> XI < 0.4 V after <= 0.28 us more (R227); Q616 off ~1.3 us"),
              (24.7e-6, "earliest 3V3A discharge start (AVCC_EN via R303 -> Q502/Q503)"),
              (0.53e-3, "3V3D < 0.1 V (AUD_EN -> R508 10k), 1V3 first; ANA_EN falls to R513 (X-1: rails stop with 5V_ANA_F); PA8 floats -> R240 -> Q207 on -> DAC reset (tens of us)"),
              (1.01e-3, "output switch open (RELAY_EN -> R646; LED strings off)")):
    print(f"   {t_*1e3:8.4f} ms  {e}")
print("   after reset: >= 5.2 ms on HSI at low clock (attach current), IWDG restarted, USB re-enumerates, full power-up from S1")

print()
print("7. Brown-out / unplug")
print("   AWD ADC1 IN1 < 1587 codes (5V_SYS 4.00 V, band 3.77..4.23 V): a 5.0 -> 3.5 V step is flagged 0.35 ms later (C103 tau 0.32 ms)")
print("   ISR (highest priority, analog R2; R9 power c14 b): RELAY_EN (PA11, GPIOA) then AVCC_EN + AUD_EN (PC11 + PC10, one GPIOC write) low back-to-back (< 0.1 us")
print("   apart; different ports), no 1.1 ms wait -> X201 stops <= 0.2 us later via U206 input B (and Q616 off, D-19), 3V3A discharges")
print("   <= 0.35 ms (DAC-pin clamp exposure <= 0.62 ms instead of <= 4.9 ms); then MCLK_PERMIT/MCLK_EN low, RESETB low, AUD_EN low,")
print("   rails low after 0.53 ms if 3V3M still holds.  Exception by analog request: AVCC changes while the switch may still be")
print("   closed for <= 1.01 ms (unplug pop stays a [MEAS] target); RESETB is still never pulled low before the switch is open.")
print("   hard unplug: 5V_SYS collapses in tens of us -> photorelay LEDs drop out (switch open <= 1 ms), 3V3M falls below the MCU")
print("   PDR -> section 6 applies (X201 stopped by R234).  Unplug pop is the analog stream's [MEAS] target (<= 20 mV).")

print()
print("8. Programming mode (D-15; round 3: only AFTER SET_CONFIGURATION with 500 mA granted, states #20)")
steps = [("ILIM_HI low (Default), RELAY_EN low, MCLK_PERMIT low, DAC_RESETB low, link pins low", 0.0),
         ("SET_CONFIGURATION received (500 mA granted); until then the 3V3M-only state (<= 100 mA)", 0.0),
         ("ANA_EN", 0.0), ("rails good valid (RAILS_OK_N low with ANA_EN = 1 >= T_START = 40 ms; ANA_SENSE >= 1.279 V)", T_START),
         ("AVCC_EN", T_START), ("PC10 -> AUD_EN (>= 1 ms after AVCC_EN; U605B gate)", T_START + 1e-3),
         ("CPLD_NRST released; J202 JTAG may program the CPLD", T_START + 1e-3)]
for n, t_ in steps:
    print(f"   {t_*1e3:6.1f} ms  {n}")
print("   MCLK stays off in hardware (MCLK_PERMIT low -> U206 Y low regardless of CPLD ISP pull-ups); RESETB low (DAC in reset);")
print("   switch open twice over (RELAY_EN low and Q616 off via N2_MCLK_OE, D-19); DC_PERMIT_N reads high (DAC in reset -> CM")
print("   window tripped) - expected here, not a fault; red LED blinks; exit only by MCU reset.")

print()
print("9. Fault timing (protection 8-10, merged)")
print("   DC_PERMIT_N rising (EXTI3, highest priority): RELAY_EN low <= 50 us; switch open <= 1.01 ms after RELAY_EN (<= 1.22 ms")
print("   after a comparator trip in hardware); then 1.1 ms -> MCLK off -> shutdown order; retry after 2 s through the full")
print("   pre-close checks; 3 DC/CM trips within 10 s -> locked until USB replug (red LED).  Controlled/fault power-down with the")
print("   rails up uses the section-2 order from RELAY_EN low on (incl. the reg 14 = 0x03 ramp); if the rails already collapsed,")
print("   AVCC_EN low at once.")
print("   Tiers every 1.000 ms (20 new samples per channel at 20.000 kHz, averaged in pairs to the protection's 10 kHz stream):")
print("   T1 100 ms / T2 300 ms / T3 1.2 s windows = 1000 / 3000 / 12000 pair-averages (2000 / 6000 / 24000 raw samples).")
TIERS = {"T1": (0.900, 0.900, 100e-3), "T2": (0.240, 0.230, 300e-3), "T3": (0.110, 0.120, 1.2)}   # (leg V, pair V, window)
PRECLOSE = (0.070, 0.090)             # |leg|, |pair| 50 ms average (protection R3.9, unchanged by R3.17)
REFUSE = (0.129, 0.155)               # closure guaranteed refused above (protection R3.17 after DZ-1; was 0.126/0.152)
assert TIERS["T3"][1] == 0.120        # protection R3.17: pair 0.118 -> 0.120 V (no-trip level vs the 20 mV offset spec)
for k, (lg, pr, w) in TIERS.items():
    print(f"   {k}: leg {lg:.3f} V / pair {pr:.3f} V, window {w*1e3:.0f} ms")
print(f"   pre-close |leg| <= {PRECLOSE[0]:.3f} V, |pair| <= {PRECLOSE[1]:.3f} V (50 ms average); closure guaranteed refused above "
      f"{REFUSE[0]*1e3:.0f} mV leg / {REFUSE[1]*1e3:.0f} mV pair (protection R3.17, includes the DZ-1 330 R)")
assert PRECLOSE[0] < REFUSE[0] and PRECLOSE[1] < REFUSE[1]
print("   RAILS_OK_N high (valid) or ANA_FAULT_N low with ANA_EN high: RELAY_EN low, controlled shutdown, ceiling -3 dB per event")
print("   down to -12 dB, retry >= 1 s; counts toward the 3-strike limit only at -12 dB.")
print()
print(f"Summary: suspend at {t_susp*1e3:.2f} ms; worst rate/family change (switch open) {worst_open*1e3:.0f} ms; IWDG {t_iwdg_min*1e3:.0f}-"
      f"{t_iwdg_max*1e3:.0f} ms. All firmware-sequence assertions passed.")

print()
print("10. Suspend budget: average current of the periodic Stop wake (IWDG refresh), for the power stream's suspend budget")
T_WAKEUP = 0.2e-3          # Stop exit incl. regulator + HSI start: 76.7 us typ [DS Tab 4-19]; no max published -> 0.2 ms [ASSUMP]
T_CODE = 30e-6             # ISR: IWDG reload, clear EXTI17/ALRF, CNF=1, ALR += 1, CNF=0, check USB resume flags [ASSUMP at HSI 8 MHz]
N_RTOFF = 3                # wait RTOFF = 1 after the ALR write: <= 3 RTCCLK periods [ASSUMP: STM32F1-compatible RTC, V3x RM not retrieved]
I_RUN_HSI = 10e-3          # MCU at HSI 8 MHz [ASSUMP, L-1 style conservative; WCH current tables not retrieved]
I_STOP = 1.9e-3            # L-1 conservative Stop current (already in the budget)


def wake_avg(tick):
    return max((I_RUN_HSI - I_STOP) * (T_WAKEUP + T_CODE + N_RTOFF / f) / (tick / f) for f in (lsi_min, 40e3, lsi_max))


worst_i = wake_avg(RTC_TICK)
for f_lsi in (lsi_min, 40e3, lsi_max):
    t_act = T_WAKEUP + T_CODE + N_RTOFF / f_lsi
    print(f"   LSI {f_lsi/1e3:4.0f} kHz: active {t_act*1e6:5.0f} us every {RTC_TICK/f_lsi:5.2f} s -> "
          f"+{(I_RUN_HSI-I_STOP)*t_act/(RTC_TICK/f_lsi)*1e6:5.2f} uA average above Stop")
print(f"   -> adopted (DX-2): add <= {worst_i*1e6:.1f} uA [CALC on ASSUMP] to the S6 suspend budget; superseded <= 30 ms scheme "
      f"(720-cycle wake): {wake_avg(720)*1e6:.0f} uA")
print("      USB 2.0 treats the suspend limit as an average (averaging window not re-read here); measure in production (L-1).")
assert worst_i < 10e-6
print()
print("11. Type-C current advertisement (states #11). Source of the thresholds: USB Type-C Cable and Connector Specification")
print("    Release 2.0 (Aug 2019), table 'Voltage on Sink CC Pins (Multiple Source Current Advertisements)' as reproduced in")
print("    ST AN5225 Table 7 (ST cites Type-C R2.0 as its reference [22]); Rd 5.1 k +-10 % needed to detect the capability")
print("    (AN5225 Table 6). Release 2.5 (Apr 2026) was not opened (zip-only download).")
SPEC = {"vRa": (-0.25, 0.15, 0.2), "vRd-USB": (0.25, 0.61, 0.66), "vRd-1.5": (0.70, 1.16, 1.23), "vRd-3.0": (1.31, 2.04, None)}
for k, (lo, hi, th) in SPEC.items():
    print(f"    {k:8s} {lo:5.2f} .. {hi:4.2f} V" + (f", threshold to the next class {th:.2f} V" if th else ""))
ERR_CC = 0.043             # CC measurement error bound, adc_settings.py section 6 [CALC]
g_up = min(0.66 - 0.61, 1.23 - 1.16)      # a lower class can never read as a higher one (safety direction)
g_dn = min(0.70 - 0.66, 1.31 - 1.23)
print(f"    upward guard {g_up*1e3:.0f} mV > error {ERR_CC*1e3:.0f} mV: a Default source never reads as >= 1.5 A [CALC]; downward guard")
print(f"    {g_dn*1e3:.0f} mV: a 1.5 A source exactly at vRd-1.5 min (0.70 V) may read Default at the worst error -> no High (safe side)")
assert g_up > ERR_CC
T_SINKADJ = 60e-3          # tSinkAdj max [Type-C spec value from memory, NOT re-read]
T_DEB = 10e-3              # 10 consecutive 1-ms CC averages below 0.66 V
t_dn = T_DEB + 1e-3 + i2c_w + 1.5 * mute_time(44_100) + 0.1e-3
print(f"    live downgrade (High -> Default): debounce {T_DEB*1e3:.0f} ms -> soft mute (vol_rate 0, timeout {1.5*mute_time(44_100)*1e3:.1f} ms at")
print(f"    44.1 kHz) -> ILIM_HI low -> 5 ms settle -> Default volume ceiling -> unmute; load reduced <= {t_dn*1e3:.1f} ms < tSinkAdj "
      f"{T_SINKADJ*1e3:.0f} ms")
assert t_dn < T_SINKADJ
print(f"    hung firmware with ILIM_HI high: IWDG <= {t_iwdg_max*1e3:.1f} ms -> R511 -> Default (< tSinkAdj) [HW backstop]")

print()
print("12. Boot self-test at every attach, before the first switch closure (switches open; criteria: protection R3.9)")
print("    0) U206/R234 (digital): PB14 floating input (R234 holds it low) -> PB1 = 0; PB14 high with MCLK_EN = 0 -> PB1 = 0;")
print("       MCLK_EN = 1 -> PB1 = 1 (X201 runs); each readback within 10 us.")
print("    a') OLD leg windows (R9 protection p20): digital DC +0.39 FS on L, then -0.39 FS, then R (0.869 V/leg, pair 1.74 V < E-3 V_L min 1.80 V):")
print("       DC_PERMIT_N high 77-131 ms after the DC reaches the legs (pass 70-140 ms); at the -4.5 dB default trim use +-0.65 FS")
print("    e) NEW E-3 detector: +0.5 FS on L, then -0.5 FS (c+ and c- channels separately), then R: DC_PERMIT_N high 19.8-23.2 ms")
print("       (pass 18-26 ms); at the -4.5 dB default trim use +-0.85 FS. Recovery after each run <= 700 ms (as before)")
print("    b) MCLK alive (permit present >= 50 ms): PB14 low -> PB1 low <= 10 us and DC_PERMIT_N high 0.06-1.25 ms (pass <= 2.0 ms);")
print("       PB14 high -> DC_PERMIT_N low 64-208 ms (pass <= 250 ms).")
print("    c) 1V3 good: PB8 (N6_V13_TEST, open drain) low 5 ms -> DC_PERMIT_N high within 0.87 ms (pass <= 2.0 ms); release ->")
print("       low 61-205 ms (pass <= 250 ms).")
print("    d) 3V3A good: before AVCC_EN, PA12 and PB9 read high; >= 2 ms after V3A_MON >= 3.20 V both read low. Optional (protection):")
print("       with 3V3A off, PC10 high for 1 ms must leave the I2C lines low (Q620 holds 3V3D off). U606 ch3 and Q619: production test.")
t_a = 4 * (0.165 + 0.700)
t_e = 4 * (0.026 + 0.700)
t_boot = t_a + t_e + 2.0e-3 + 0.25 + 5e-3 + 0.25 + 0.25
# R9 follow-up (orchestrator): self-test <= 3 s. The digital DC is cleared IN the DC_PERMIT_N EXTI handler (held only until the trip);
# (0) U206/PB1 and (d) 3V3A-good run inside the power-up (0 s); the E-2 clear path (PB0 low) is read at every trip (0 s).
def t_selftest(r_rec):
    return 4 * 0.140 + 4 * 0.026 + 8 * r_rec + 2 * (0.002 + 0.250)
print("    R9 cut (<= 3 s): DC cleared at the trip (EXTI handler), so each run holds the DC <= its trip time; (0), (d) and the PB0 clear-path")
print("    checks run in parallel (power-up / every trip). Total = 4 x 140 ms + 4 x 26 ms + 8 x R + 2 x 252 ms (b, c) = 1.17 s + 8 R:")
for r_rec in (0.209,):
    print(f"       R = {r_rec*1e3:3.0f} ms -> {t_selftest(r_rec):.2f} s {'<= 3 s' if t_selftest(r_rec) <= 3.0 else '> 3 s'}")
print("    R <= 209 ms (protection p20: DAC removal <= 1 ms + comparator release <= 3 ms + H recovery <= 205 ms; same after b/c)")
assert t_selftest(0.209) <= 3.0
print(f"    total added to the first start <= {t_boot:.2f} s (a' {t_a:.2f} s + e {t_e:.2f} s dominate; each run ends with the <= 700 ms recovery)")
print("    [CALC from protection's pass limits]; owner-visible: the first audio after an attach can start ~7 s later (tests run after")
print("    SET_CONFIGURATION, in parallel with the host's own start-up; later closures do not repeat them)")
print("    after every self-test trip PB0 (N6_ARM_MCU) must read low (E-2 clear path), and the re-arm sequence (section 18) precedes the first closure")
print("    Any failure -> no RELAY_EN, red LED, log.")

print()
print("13. Stream guards - OD-1 rule (DZ-11, protection p15), identical in the USB-side guard (decoded PCM, per microframe) and the")
print("    post-CPLD guard (I2S2 capture PB12/13/15, 32-bit frames, circular DMA, 0.5 ms half-blocks); per channel, every rate")
L_P1, T_P1 = 0.30, 22.0e-3
print(f"    P1 (new) level persistence: every sample of the last {T_P1*1e3:.1f} ms >= +{L_P1} FS, or every sample <= -{L_P1} FS (run counter")
print("       reset by any sample inside +-L or a sign change); implemented per block: block min/max (shared with P3) extend the run when")
print("       the whole block qualifies, otherwise a backward scan from the block end gives the exact trailing run (sample-exact rule)")
print("    P2 CIC2 (two cascaded 50 ms boxcars) |D| >= 0.25 FS (protection final: was 0.30); P3 flat: range <= 1e-3 FS over 26 ms and")
print("       |mean| >= 0.02 FS (unchanged); P4 (new) CIC2 (two cascaded 150 ms boxcars, N = 0.15 x fs) |D| >= 0.15 FS")
print("    P2/P4 implementation: per-sample block sums shared with P1/P3; boxcars as running sums of 0.5 ms block values (50 ms = 100,")
print("       150 ms = 300 blocks; stage 1 exact, stage 2 sampled per block -> <= 0.5 ms timing difference, inside the 1 ms latency);")
ram = (100 + 300) * 2 * 2 * 4
print(f"       RAM {ram/1024:.1f} KB per guard ({2*ram/1024:.1f} KB for both; 32-bit means) [CALC]; CPU per block negligible (P4 adds no per-sample work)")
print("    action: USB-side -> zero the pair with a 1 ms ramp + log (release |D| < 0.05 FS for 1 s); post-CPLD -> RELAY_EN low")
print("       (switch open <= 1.008 ms) + zero + log, re-close only through the pre-close sequence (strike counted)")
BLK_PC, BLK_USB = 0.5e-3, 125e-6
t_dec_pc = BLK_PC + 0.1e-3
t_dec_usb = BLK_USB + 0.1e-3
print(f"    decision latency (protection limit <= 1 ms): post-CPLD <= {t_dec_pc*1e3:.2f} ms (0.5 ms block + 0.1 ms), USB-side <= {t_dec_usb*1e3:.3f} ms")
assert t_dec_pc <= 1e-3 and t_dec_usb <= 1e-3
for fs in (44_100, 384_000):
    print(f"    fs {fs:6d}: P1 trips {T_P1*1e3:.0f} ms + <= {t_dec_pc*1e3:.1f} ms after a >= 0.30 FS one-sided run starts; P3 26 ms; P2 <= 100 ms; P4 <= 300 ms (+ latency)")
print("    (USB-side: the CPLD FIFO latency delays both the DC and the zeroing equally -> DAC-output exposure = T_P + T_DEC + T_ACT)")
for fs in (44_100, 48_000, 384_000):
    print(f"    N = ceil(0.022 x fs) = {math.ceil(0.022*fs)} samples at {fs} Hz")
t_exp = T_P1 + t_dec_pc + 1.008e-3
print(f"    exposure P1 = {T_P1*1e3:.1f} + {t_dec_pc*1e3:.2f} + 1.008 (switch open; >= the 1 ms zero ramp) = {t_exp*1e3:.2f} ms <= 24 ms (protection energy basis)")
assert t_exp <= 24e-3
CYC_BASE, CYC_P1_TYP, CYC_P1_WORST = 15, 3, 10     # per stereo frame [ASSUMP ~1 IPC]: P2 sums + P3 min/max; P1 typical / worst (second pass)
f_cpu = 144e6
for fs in (192_000, 384_000):
    typ = fs * (CYC_BASE + CYC_P1_TYP) / f_cpu
    wst = fs * (CYC_BASE + CYC_P1_WORST) / f_cpu
    print(f"    CPU at {fs/1e3:.0f} kHz: {typ*100:.1f} % typical / {wst*100:.1f} % worst per guard -> both guards {2*typ*100:.1f} % / {2*wst*100:.1f} % of 144 MHz;"
          f" capture DMA {fs*4/1e6:.3f} M half-words/s")
    assert 2 * wst < 0.20
print("    384/352.8 kHz post-CPLD capture needs the I2S2 slave at 24.576/22.579 MHz BCLK (bring-up [MEAS], recorded; R-5 residual if not)")
L1 = L_P1
import math as _m
f_sine = (_m.pi - 2 * _m.asin(L1)) / (2 * _m.pi * T_P1)
print(f"    content boundary (protection p15): full-scale sine never triggers P1 above {f_sine:.2f} Hz (20 Hz run {(_m.pi-2*_m.asin(L1))/(2*_m.pi*20)*1e3:.2f} ms < 22 ms);")
print(f"    a full-scale (>= 0.30 FS) square wave below {1/(2*T_P1):.1f} Hz, or one-sided DC-offset content >= 0.30 FS held 22 ms, mutes (owner-accepted, DZ-11)")

print()
print("14. OD-2 (DZ-12): DAC plausibility check (firmware only; DAC_LOCK = U301 GPIO2 on PC9, already wired)")
T_SWO = 1.008e-3          # switch open after RELAY_EN low (protection R3)
BIT = 1 / 100e3           # I2C bit time, 100 kHz standard mode (DZ-2)
t_rd2 = (1 + 9 + 9 + 1 + 9 + 2 * 9 + 1) * BIT     # reg 64-65 burst read (S, addr W, reg, Sr, addr R, 2 bytes, P)
t_rd1 = (1 + 9 + 9 + 1 + 9 + 9 + 1) * BIT         # single-register read (reg 14 sentinel)
t_cfg = (1 + 9 + 9 + 1 + 9 + 21 * 9 + 1) * BIT    # reg 0-20 burst read-back
t_dpll = (1 + 9 + 9 + 1 + 9 + 4 * 9 + 1) * BIT    # reg 66-69 DPLL ratio
T_A, T_B = 10e-3, 100e-3
t_abort = 0.1e-3          # a priority write (mute/fault/suspend) aborts a poll at the next byte boundary
t_poll_a = t_rd2 + t_cfg  # every 10 ms: reg 64-65 status + the full reg 0-20 read-back (reg 14 = 0xAA sentinel inside it)
load = (t_poll_a / T_A) + t_dpll / T_B
print(f"   Poll A every {T_A*1e3:.0f} ms ({t_poll_a*1e3:.2f} ms): reg 64-65 burst ({t_rd2*1e3:.2f} ms): lock_status = 1, automute_status = 0 (automute")
print(f"      disabled: reg 4 = 0x00), chip_id = 4, GPIO2 pin (reg 65 bit 1) = PC9 = lock; + reg 0-20 read-back vs the shadow copy ({t_cfg*1e3:.2f} ms)")
print("      incl. the reg 14 = 0xAA sentinel (reset default 0x8A) -> a DAC reset or any register corruption is seen at the next poll")
print(f"   Poll B every {T_B*1e3:.0f} ms: DPLL ratio reg 66-69 ({t_dpll*1e3:.2f} ms) within +-0.1 % of FSR x 2^32 / 80 MHz; DPLL_NUM bit-identical")
print("      over 5 reads = advisory log only [MEAS at bring-up]")
print(f"   I2C bus load {load*100:.1f} % at 100 kHz; host volume writes queue behind a poll (<= {t_poll_a*1e3:.2f} ms); priority writes abort a")
print(f"   poll <= {t_abort*1e3:.1f} ms (suspend deadline anchored to the last SOF, DX-1 numbers unchanged); CPU < 0.5 % (interrupt-driven);")
print("   the analog noise floor with polling active is a bring-up [MEAS] (fallback: poll period 20 ms -> detection times x ~2)")
det = {
    "(a) DPLL lock lost -> GPIO2 falling on PC9 (EXTI9, priority 2; 20 us confirm re-read)": 30e-6,
    "(b) poll A: lock_status 0 / automute 1 / chip_id / GPIO2 != PC9 / any reg 0-20 mismatch incl. reset (confirm re-read)": T_A + 2 * t_poll_a + t_abort,
    "(c) poll A: DAC I2C NACK (one retry)": T_A + 2 * t_poll_a + t_abort,
    "(c') bus stuck low (1 ms timeout, then 9-clock recovery)": T_A + 2 * t_poll_a + t_abort + 1e-3,
    "(d) poll B: DPLL ratio out of range (confirm re-read)": T_B + 2 * t_dpll + t_abort,
}
for k, v in det.items():
    print(f"   {k}: RELAY_EN low <= {v*1e3:7.2f} ms -> switch open <= {(v+T_SWO)*1e3:7.2f} ms")
assert det["(a) DPLL lock lost -> GPIO2 falling on PC9 (EXTI9, priority 2; 20 us confirm re-read)"] + T_SWO <= 1.05e-3
print("   masked: start-up until the first closure, rate/family changes (lock loss expected) and suspend (clocks stop); R9 E-10: GPIO2 =")
print("   lock permanently (reg 8 = 0x12, GPIO1 = min-volume flag read via reg 65 bit 0); action: RELAY_EN low, log, I2C 9-clock recovery, PA8 high >= 1 ms, full DAC re-init, lock, pre-close")
print("   checks, re-close; counts as a strike (3 in 10 s -> locked until replug).")
print("   self-test at every start (switch open, after the first lock): reg 8 = 0x72 (GPIO2 low) -> PC9 = 0, reg 65 b1 = 0, EXTI9 flag set;")
print("   reg 8 = 0xF2 (high) -> PC9 = 1; reg 8 = 0x12 -> PC9 = reg 64 b0 = 1, and reg 65 b0 = 1 while muted (GPIO1 min-volume path); 3 writes + 3 reads = "
      f"{(3*30*BIT + 3*t_rd2)*1e3:.1f} ms. Residual (documented limitation): a DAC-core hang that keeps lock = 1 and answers I2C")
print("   with correct registers - covered only by the leg windows (protection).")


print()
print("15. R9 E-9: CANONICAL POWER-DOWN ORDER (one table for every exit; digital owns it, power/analog confirm their rows)")
STEPS = [("S1", "mute: CPLD FADE (1 ms to zero) + DAC soft mute (reg 7 = 0x83, vol_rate 0); wait min-volume (reg 65 b0) or deadline"),
         ("S2", "RELAY_EN low; wait 1.1 ms (switch open <= 1.008 ms)"),
         ("S3", "DAC ramp to ground: reg 14 = 0x03 (NACK -> retry once); wait 1.1 ms (MCLK running)"),
         ("S4", "MCLK off: MCLK_PERMIT (PB14) low -> X201 stand-by, Q616 off; SPI CLOCK_CTRL = 0, I2S_CTRL = 0"),
         ("S5", "DAC reset: PA8 high (Q207 on); link pins N2_LINK_*_MCU low; I2C pins released (not driven)"),
         ("S6", "domains: PC11 AVCC_EN and PC10 AUD_EN low in ONE GPIOC write; wait >= 0.53 ms (3V3A < 0.1 V <= 0.472 ms with C440; C441 fitted -> wait >= 0.75 ms);"),
         ("  ", "   3V3D < 0.1 V <= 0.63 ms (covered by the >= 1 ms re-enable rule); DVDD <= DVCC throughout (U303 regulates ~90 us, then UVLO, Q506 ends); U605B/Q620 force AUD_EN low <= 1.04 ms after 3V3A < 3.006 V anyway"),
         ("S7", "ANA_EN low (5V_ANA_F collapses -> LM27762 stops at UVLO; I/V rails held by D411/D412 reservoirs until 3V3A < 0.3 V)"),
         ("S8", "ILIM_HI low, LEDs off"),
         ("S9", "suspend only (E-16): S7 + 0.1 ms (ANA_EN, AVCC_EN, AUD_EN all low) -> PC14 = N5_U102_OFF high = U102 off (tOFF <= 0.3 ms; VBUS_SENSE ignored);"),
         ("  ", "   IWDG long (DX-2), ADC/TIM4/PVD/VREFINT off, USBHS PHY suspend, Stop"),
         ("R0", "resume / any wake to run (E-16): IWDG short -> clocks/USB (3V3M from U502 TPS70933 on VBUS) -> PC14 low (U102 on) -> 5V_SYS good"),
         ("  ", "   (VBUS_SENSE >= 4.0 V for 5 ms, timeout 60 ms - power) -> arm the brown-out AWD -> only then any domain (B)")]
for k, v in STEPS:
    print(f"   {k}  {v}")
EXITS = [("host stop (alt 0 / stream end)", "S1 (no deadline; timeout 1.5 x ramp) -> S2; domains stay up (configured idle); a later power-down continues S3-S8"),
         ("suspend (SOF loss 1 ms)", "S1 (deadline 5.31 ms after the last SOF) -> S2 ... S8 -> S9 (U102 off); suspend current at U102 off, see section 19"),
         ("resume / bus reset in suspend", "R0 first (U102 on, 5V_SYS good, AWD armed), then power-up B; USB answers on 3V3M before 5V_SYS is up"),
         ("rate / family change", "S1 (timeout 1.5 x ramp) -> S2; no power-down; I2S_RUN = 0 -> [family: E-12 engine reset around the U205 switch] -> relock -> pre-close -> close -> ramp"),
         ("fault shutdown (DC_PERMIT_N, tiers, OD-1 post-CPLD, OD-2, overload)", "S2 FIRST (no mute wait) with S1 in parallel -> DC/CM/OD-2: domains stay up for retry (re-init per policy); overload/supply fault: S3 -> ... -> S7"),
         ("brown-out (AWD, 5V_SYS < 4.00 V)", "RELAY_EN (GPIOA) then AVCC_EN + AUD_EN (one GPIOC write) back-to-back, no wait (power c14 case b) -> S4 -> S5 after >= 1.01 ms -> ANA_EN low after >= 0.53 ms"),
         ("hard unplug", "hardware-defined: LED strings drop out (switch open <= 1 ms) -> MCU PDR -> MCU-reset row"),
         ("I2C double fault (reg 14 NACK twice)", "S1, S2, S3 fails -> S4 -> AVCC_EN low -> wait 3V3A < 0.1 V (0.5 ms) -> S5 -> AUD_EN low -> S7 (logged fault path, not controlled)"),
         ("MCU reset / IWDG", "hardware-defined: RELAY_EN -> R646 (switch open <= 1.01 ms); PB14 -> R234 (X201 stop <= 0.39 us); PA8 -> R240 -> Q207 (DAC reset);"),
         ("", "   ENs -> R303/R508/R513 (discharges on: Q502 -> N5_DIS_A -> Q503 for 3V3A; Q504 -> N5_DIS_D -> Q505/Q506 for 3V3D/1V3); ILIM_HI -> R511 (Default)"),
         ("programming mode exit", "only by MCU reset -> MCU-reset row")]
for k, v in EXITS:
    print(f"   {k:62s} {v}")

print("   analog (R9): S1/S2 no step, S3 0.126 mV, S6 0.23 / 1.46 mV (3 / 22 % mismatch), S7 negligible at 300 ohm -> every controlled exit")
print("   <= 1.46 mV. Condition [MEAS]: S4/S5 are step-free only if the ESS ramp ends in the reset (ground) state (not published): with the")
print("   switch open, leg DC before/after PA8 high must differ < 10 mV at bring-up; otherwise move S5 after S6 (firmware only).")
print("   MCU reset/IWDG row: a click up to the reset-state leg voltage (0.05-0.34 V) can pass before the switch opens (L-4, owner fault case).")

print()
print("16. R9 E-12: family switch with a CPLD engine reset around the U205 mux change (switch already open, see section 4)")
FAM = ["I2S_RUN = 0 (SPI register domain, LINK_SCK clock)", "new oscillator on (OSC48_EN or OSC44_EN), wait >= 10 ms (NDK start-up 4 ms)",
       "ENGINE_RST = 1 (new RTL register bit: asynchronous assert into the FAM_CLK domain - I2S engine, divider, FIFO read side)",
       "switch U205 (OSC44_EN selects S); any runt FAM_CLK pulse now hits only reset flip-flops", "old oscillator to stand-by",
       "wait >= 2 us (>= 90 FAM_CLK cycles)", "ENGINE_RST = 0 (2-FF synchroniser: synchronous release in the new FAM_CLK)",
       "FIFO flush/prime, divider/format registers kept (register domain untouched), I2S_RUN = 1 -> relock -> pre-close -> close -> ramp"]
for i, t in enumerate(FAM, 1):
    print(f"   {i}. {t}")
print("   fallback without the new bit: CPLD_NRST (PC5) low >= 1 ms around the switch + full register rewrite (existing error path, ~0.2 ms SPI)")

print()
print("17. R9 E-5 (digital part): suspend pin/peripheral states - digital adds 0 A beyond the MCU Stop planning value (1.9 mA, L-1) + wake")
PINS = [("PA8 high (R240 0 A), PB14/PC10-12/PA11/PA15 low (pull-downs 0 A)", 0.0), ("link pins low -> U208 Ioff (3V3D off) 0 A", 0.0),
        ("PB10/PB11 I2C released (10 k to dead 3V3D; never driven high)", 0.0), ("PB8 Hi-Z; PA12/PB9 inputs at the U605 output (3V3M) 0 A", 0.0),
        ("spares PC14/PC15/PB0 analog; PA0/PC0-PC4 analog (domains off)", 0.0), ("ADC1/ADC2 ADON = 0, TIM4 off, PVD off, VREFINT/TS off before Stop", 0.0),
        ("IWDG/RTC wake (DX-2)", I_WAKE if 'I_WAKE' in dir() else 4.54e-6)]
for n, i in PINS:
    print(f"   {n:78s} {i*1e6:5.1f} uA")
print("   -> no further firmware saving exists; the >= 0.2 mA margin (E-5) must come from power/protection loads (VBUS divider,")
print("      clamps, U605 dividers) - see adc_settings section 9 for the VBUS divider options and their ADC/brown-out limits.")

print()
print("18. R9 E-2: firmware re-arm of the hardware latch (protection U608 74LVC1G74 on 3V3D; readback PB0 = N6_ARM_MCU via R695 100 k)")
REARM = ["after ANY trip (DC_PERMIT_N went high since the last closure, incl. the soft-start CM trip and every self-test trip): RELAY_EN low",
         "wait DC_PERMIT_N low CONTINUOUSLY >= 150 ms (protection: H may need <= 80 ms after DC_PERMIT_N low to pass HREF 3.11 V; replaces the pre-close 50 ms), then the full pre-close checks (R3.2 B.6, OD-2 status, lock); RELAY_EN has been low >= 1 ms (latch needs ns)",
         "RELAY_EN low -> high (a fresh edge clocks the latch; RELAY_EN held high can never re-arm it)",
         "read PB0 high within 1 ms (armed); otherwise RELAY_EN low, retry after 20 ms, max 3 tries, then fault (red LED, log, no audio)",
         "self-test: after each self-test trip (a-d, section 12) PB0 must read low (latch cleared) -> tests the clear path at every attach",
         "IWDG hang with RELAY_EN static high: any trip clears the latch -> the switch stays open until the reset (<= 38.4 ms) and a new edge"]
for i, t in enumerate(REARM, 1):
    print(f"   {i}. {t}")
print("   power-up: RELAY_EN high moves by +100 ms (DC_PERMIT_N low 150 ms instead of 50 ms, section 3); rate/family worst includes it (section 4)")

print()
print("19. R9 E-16 (owner): suspend power cut - U102 off in Stop (MCU on the new VBUS-fed low-IQ LDO for 3V3M, power)")
T_S7 = 5.31e-3 + T_SW_OFF_WAIT + i2c_w + T_RAMP_WAIT + 1e-6 + 2 * spi_word + 0.2e-6 + 0.53e-3   # S7 (ANA_EN low) on the deadline path
T_DOM_OFF = 0.1e-3    # power (R9 E-16): U102 off 0.1 ms after ANA_EN low (U503 off ~12 us typ, margin); nothing has to decay first
T_U102_OFF = 0.3e-3   # power: U102 tOFF <= 0.3 ms -> USB current at the suspend level
t_u102_off = T_S7 + 1e-6 + T_DOM_OFF
t_stop = t_u102_off + 0.1e-3
print(f"   S7 ANA_EN low at {T_S7*1e3:.2f} ms after the last SOF (deadline path); S9 at S7 + 0.1 ms (power); PC14 = N5_U102_OFF high")
print(f"   at {t_u102_off*1e3:.2f} ms; U102 tOFF <= 0.3 ms -> USB current at the suspend level <= {(t_u102_off+T_U102_OFF)*1e3:.2f} ms (limit 10 ms, margin {(10e-3-t_u102_off-T_U102_OFF)*1e3:.2f} ms); Stop at {t_stop*1e3:.2f} ms")
print("   5V_SYS then falls ~12 mV/ms (<= 43 uA on 3.6 uF), U503 keeps VIN > VOUT; later reversal clamped by D105 <= 0.24 V (X-4 holds, power)")
assert t_u102_off + T_U102_OFF <= 9.9e-3
print("   rules: U102 off only after every domain is off; while U102 is commanded off (and until 5V_SYS is good after resume) VBUS_SENSE")
print("   reads ~0 and is IGNORED - the brown-out AWD is disarmed and no unplug/brown-out action is taken; a real unplug removes VBUS")
print("   from U502 -> MCU PDR -> reset (hardware-defined row). PC14 high draws <= 3.34 uA into R537 1 M (3V3M 3.207-3.343 V, power).")
T_U102_ON = 55.3e-3   # U102 turn-on after EN release: R109/C104 RC (power c20 b), EN node discharged by the NMOS in suspend
t_r0 = 5.28e-3 + T_U102_ON + 5e-3
print(f"   resume: Stop exit + HSE + PLL + PHY 5.28 ms (USB answers on 3V3M, TRSMRCY 10 ms met without 5V_SYS); PC14 low -> U102 on")
print(f"   <= {T_U102_ON*1e3:.1f} ms (R109 x C104 + tON 7.3 ms) -> 5V_SYS good (VBUS_SENSE >= 4.0 V for 5 ms; timeout 60 ms -> fault, USB-only, red LED)")
print(f"   -> AWD armed -> power-up B starts <= {t_r0*1e3:.1f} ms after the wake (audio restarts ~0.55 s later, section 3)")
print("   attach: U102 default on (PC14 floats at reset -> R537); firmware drives PC14 low at GPIO init; programming mode: low. The MCU")
print("   boots on 3V3M (VBUS) before U102 is on, so VBUS_SENSE = 0 during early boot is IGNORED: the AWD is armed only after 5V_SYS good")
print("   (VBUS_SENSE >= 4.0 V for 5 ms, timeout 60 ms after reset -> fault, stay USB-only, report). The D+ pull-up does NOT wait for it.")
print("   brown-out (power R9): the AWD trip is ratiometric to VDDA = 3V3M; U502 TPS70933 dropout <= 650 mV at 50 mA -> the 4.00 V trip is")
print("   guaranteed while the 3V3M load <= 50 mA (MCU typ 22 mA); on the 80 mA planning value 3V3M may leave regulation below VBUS ~4.25 V")
print("   and the trip is then not guaranteed. The unplug stays compliant without firmware (X-8). Qualification [MEAS]: 3V3M load <= 50 mA in")
print("   S3 at bring-up. VREFINT cross-check NOT adopted: the 9-slot scan leaves 9.5 us idle per 50 us, a VREFINT conversion needs >= 17 us")
print("   sampling (~21 us) [ASSUMP STM32F1-class; WCH value not retrieved] -> it would drop one protection scan per read (exact 20 kHz /")
print("   20-scan DMA blocks break; T3 itself is time-based). ADOPTED instead (firmware only, no ADC time): PVD on VDD = 3V3M at its highest")
print("   level (>= 2.9 V [ASSUMP level table]) -> EXTI16 -> the same brown-out ISR. It fires when U502 leaves regulation (dropout), i.e. at")
print("   5V_SYS ~3.5-3.9 V instead of 4.00 V, so a brown-out is always handled before the MCU loses regulation. The AWD stays exact while")
print("   3V3M regulates. PVD off in Stop (suspend checklist).")
