import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '../..'))
"""Single source of truth for the analog stream's parts: writes ../netlist.csv and ../bom_rows.csv and
checks them (every pin present once, pin counts per package, net names legal, no single-pin internal nets,
designators unique, retired designators not reused).  Output also ../out/netlist_check.txt"""
import csv, os, re, collections

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, '..')
IFACE = set('''VBUS 5V_SYS GND 3V3M 3V3D 1V3 3V3A 5V_ANA 5V_ANA_F VPOS VNEG MCLK MCLK_EN BCLK LRCLK SDATA I2C_SCL I2C_SDA
DAC_RESETB DAC_LOCK DACL DACLB DACR DACRB VREF AVCC_L AVCC_R VCCA DVCC LEG_LP LEG_LN LEG_RP LEG_RN JACK_LP JACK_RP
JACK_LN JACK_RN NC'''.split())
RETIRED = {'R306', 'R421', 'R427', 'R428', 'R429', 'R430', 'R433', 'R434', 'R435', 'R436',
           'R437', 'C427', 'C428', 'C429', 'C430', 'D409', 'D410'}
PINCOUNT = {'QFN28EP': 29, 'VSON10EP': 11, 'SOIC8': 8, 'SOT23': 3, '2PIN': 2, 'J701': 7, 'J702': 6}
net = []   # rows: refdes, pin, pin_name, net, note
pkg = {}

def part(ref, package, pins):
    pkg[ref] = package
    for (pin, name, n, note) in pins:
        net.append(dict(refdes=ref, pin=str(pin), pin_name=name, net=n, note=note))

def two(ref, n1, n2, note='', names=('1', '2')):
    part(ref, '2PIN', [(1, names[0], n1, note), (2, names[1], n2, '')])

# ------------------------------------------------------------------ U301 ES9018K2M (ESS v3.7 pin table p.4)
dac = [(1, 'DGND', 'GND', ''), (2, 'N.C.', 'GND', 'no internal connection; grounded for pad strength (ESS p.4)'),
       (3, 'SCL', 'I2C_SCL', 'pull-up on 3V3D by digital stream; input <= DVCC+0.3 V'),
       (4, 'SDA', 'I2C_SDA', 'pull-up on 3V3D by digital stream'),
       (5, 'ADDR', 'GND', 'direct to DGND: address 0x90/0x48 (R306 retired)'),
       (6, 'XO', 'NC', 'crystal output unused with external MCLK (ESS p.4: floating)'),
       (7, 'XI (MCLK)', 'MCLK', 'from X201 (Kyocera KC2520K80, 80.000 MHz, D-3 revised) via series R (digital); XI buffer powered from VCCA: MCLK only while VCCA up'),
       (8, 'AGND', 'GND', ''), (9, 'DACR', 'DACR', 'only to U404A -IN, Rf R425, Cf C419'),
       (10, 'DACRB', 'DACRB', 'only to U404B -IN, R426, C420'), (11, 'AGND_R', 'GND', ''), (12, 'AGND_L', 'GND', ''),
       (13, 'DACL', 'DACL', 'only to U403A -IN, R423, C417'), (14, 'DACLB', 'DACLB', 'only to U403B -IN, R424, C418'),
       (15, 'AVCC_L', 'AVCC_L', 'R301 2.2 ohm from 3V3A; C303 2.2 uF + C305 100 nF'),
       (16, 'AVCC_R', 'AVCC_R', 'R302 2.2 ohm from 3V3A; C304 + C306'),
       (17, 'VCCA', 'VCCA', 'FB302 from 3V3A; C307 100 nF'), (18, 'DVCC', 'DVCC', 'FB301 from 3V3D; C308 100 nF'),
       (19, 'N.C.', 'GND', 'grounded (ESS p.4)'), (20, 'DGND', 'GND', 'internally connected to EP'),
       (21, 'DVDD', '1V3', 'external 1.3 V (required: MCLK 80 MHz > 50 MHz, FSR > 192 kHz, ESS p.7); C310 2.2 uF + C309 100 nF'),
       (22, 'N.C.', 'GND', 'grounded (ESS p.4)'), (23, 'GPIO2', 'DAC_LOCK', 'DPLL lock only (OD-2 interrupt; R9 E-10)'),
       (24, 'GPIO1', 'NC', 'unconnected; reg 8 = 0x12 makes it the minimum-volume flag, read over I2C via reg 65 bit 0 (R9 E-10)'), (25, 'DATA2', 'SDATA', ''), (26, 'DATA1', 'LRCLK', ''),
       (27, 'DATA_CLK', 'BCLK', ''), (28, 'RESETB', 'DAC_RESETB', 'X-7: open-drain Q207 (digital) to GND + R305 10 k pull-up to DVCC here; low = reset (Q207 on while the MCU is in reset)'),
       ('EP', 'DGND (exposed pad)', 'GND', 'must connect to digital ground (ESS p.4)')]
part('U301', 'QFN28EP', dac)
two('R301', '3V3A', 'AVCC_L', '2.2 ohm AVCC_L branch'); two('R302', '3V3A', 'AVCC_R', '2.2 ohm AVCC_R branch')
two('C303', 'AVCC_L', 'GND', '2.2 uF'); two('C304', 'AVCC_R', 'GND', '2.2 uF')
two('C305', 'AVCC_L', 'GND', '100 nF at pin 15'); two('C306', 'AVCC_R', 'GND', '100 nF at pin 16')
two('C307', 'VCCA', 'GND', '100 nF at pin 17'); two('C308', 'DVCC', 'GND', '100 nF at pin 18'); two('C309', '1V3', 'GND', '100 nF at pin 21')
two('C439', 'DVCC', 'GND', 'X-10/B-07: 2.2 uF after FB301 (damps the bead-100 nF resonance)'); two('C440', 'VCCA', 'GND', 'X-10/B-07: 2.2 uF after FB302 (damps the bead-100 nF resonance)')
two('C310', '1V3', 'GND', '2.2 uF at pin 21')
two('R305', 'DAC_RESETB', 'DVCC', 'X-7: pull-UP to DVCC for the Q207 open-drain driver (Q207 on = reset); no back-power when 3V3D is off')
two('FB301', '3V3D', 'DVCC', 'ferrite, DVCC branch'); two('FB302', '3V3A', 'VCCA', 'ferrite, VCCA (XI buffer) branch')
# ------------------------------------------------------------------ I/V converters (OPA2210 SBOS924H pin table: 1 OUTA 2 -INA 3 +INA 4 V- 5 +INB 6 -INB 7 OUTB 8 V+)
for u, (pa, pb), (oa, ob) in [('U403', ('DACL', 'DACLB'), ('N4_IVL_P', 'N4_IVL_N')), ('U404', ('DACR', 'DACRB'), ('N4_IVR_P', 'N4_IVR_N'))]:
    part(u, 'SOIC8', [(1, 'OUT A', oa, '%s I/V output (D-12 name); protection R653-R656 100 k to the CM node connect here' % pa), (2, '-IN A', pa, 'DAC pin (virtual ground)'),
                      (3, '+IN A', 'VREF', ''), (4, 'V-', 'N4_VNEG_IV', 'X-8: separate I/V supply (VNEG_IV) behind D412 + C443 hold-up'),
                      (5, '+IN B', 'VREF', ''), (6, '-IN B', pb, 'DAC pin (virtual ground)'), (7, 'OUT B', ob, '%s I/V output (D-12 name)' % pb), (8, 'V+', 'N4_VPOS_IV', 'X-8: separate I/V supply (VPOS_IV) behind D411 + C442 hold-up')])
for r, c, pin, o in [('R423', 'C417', 'DACL', 'N4_IVL_P'), ('R424', 'C418', 'DACLB', 'N4_IVL_N'), ('R425', 'C419', 'DACR', 'N4_IVR_P'), ('R426', 'C420', 'DACRB', 'N4_IVR_N')]:
    two(r, pin, o, 'Rf 698 ohm'); two(c, pin, o, 'Cf 820 pF C0G')
two('R431', '3V3A', 'VREF', 'VREF top 9.76 k'); two('R432', 'VREF', 'GND', 'VREF bottom 10.0 k'); two('C421', 'VREF', 'GND', '33 pF C0G')
two('R446', '3V3A', 'VREF', 'DNF VREF trim (X-10/F4): in parallel with R431, raises VREF (237 k: +2.1 %)'); two('R447', 'VREF', 'GND', 'DNF VREF trim (X-10/F4): in parallel with R432, lowers VREF (243 k: -2.1 %)')
two('C441', '3V3A', 'GND', 'DNF 1 uF (X-10/F2): slower 3V3A rise for power-up pop margin; keeps 3V3A <= 10 uF effective with C440 (LP5907 limit)')
for d, o, av in [('D405', 'N4_IVL_P', 'AVCC_L'), ('D406', 'N4_IVL_N', 'AVCC_L'), ('D407', 'N4_IVR_P', 'AVCC_R'), ('D408', 'N4_IVR_N', 'AVCC_R')]:
    part(d, 'SOT23', [(1, 'A1', 'GND', 'lower diode anode to GND (at the DAC AGND)'),
                      (2, 'K2', av, 'upper diode cathode to %s at its decoupling capacitor' % av),
                      (3, 'K1/A2', o, 'common node on the I/V output (NOT on the DAC pin)')])
for c, u, n in [('C423', 'U403', 'N4_VPOS_IV'), ('C424', 'U403', 'N4_VNEG_IV'), ('C425', 'U404', 'N4_VPOS_IV'), ('C426', 'U404', 'N4_VNEG_IV')]:
    two(c, n, 'GND', '100 nF at %s %s' % (u, n))
# X-8 I/V supply hold-up: low-VF Schottky + MnO2 tantalum reservoir per rail (SOD123F: pin 1 cathode, pin 2 anode)
part('D411', '2PIN', [(1, 'K', 'N4_VPOS_IV', 'X-8: VPOS -> VPOS_IV (blocks reverse flow when VPOS collapses)'), (2, 'A', 'VPOS', '')])
part('D412', '2PIN', [(1, 'K', 'VNEG', 'X-8: VNEG_IV -> VNEG (blocks when VNEG collapses)'), (2, 'A', 'N4_VNEG_IV', '')])
part('C442', '2PIN', [(1, '+', 'N4_VPOS_IV', 'X-8: 220 uF tantalum reservoir, + to VPOS_IV (polarity band = +)'), (2, '-', 'GND', '')])
part('C443', '2PIN', [(1, '+', 'GND', 'X-8: 220 uF tantalum reservoir, + to GND, - to VNEG_IV'), (2, '-', 'N4_VNEG_IV', '')])
# DY-3: reverse clamps across the polarised reservoirs (Nexperia BAT54,215 SOT23: pin 1 A, pin 2 n.c., pin 3 K)
part('D413', 'SOT23', [(1, 'A', 'GND', 'DY-3: reverse clamp across C442 (at C442 -)'), (2, 'NC', 'NC', 'no connection (pad only)'), (3, 'K', 'N4_VPOS_IV', 'DY-3: at C442 +')])
part('D414', 'SOT23', [(1, 'A', 'N4_VNEG_IV', 'DY-3: reverse clamp across C443 (at C443 -)'), (2, 'NC', 'NC', 'no connection (pad only)'), (3, 'K', 'GND', 'DY-3: at C443 +')])
# ------------------------------------------------------------------ legs (OPA1622 SBOS727B pins: 1 +INA 2 V+ 3 GND 4 V- 5 +INB 6 -INB 7 OUTB 8 EN 9 OUTA 10 -INA, pad V-)
LEGS = [  # leg, amp, (+IN pin, -IN pin, OUT pin), -input source (DAC+), +input source (DAC-), R1a,R2,R3a,R4, R1b,R3b, CtN,CtP, ClN,ClP
    ('LP', 'U401', ('1', '10', '9'), 'N4_IVL_P', 'N4_IVL_N', 'R401', 'R402', 'R403', 'R404', 'R438', 'R439', 'C431', 'C432', 'C401', 'C402'),
    ('LN', 'U401', ('5', '6', '7'), 'N4_IVL_N', 'N4_IVL_P', 'R405', 'R406', 'R407', 'R408', 'R440', 'R441', 'C433', 'C434', 'C403', 'C404'),
    ('RP', 'U402', ('1', '10', '9'), 'N4_IVR_P', 'N4_IVR_N', 'R409', 'R410', 'R411', 'R412', 'R442', 'R443', 'C435', 'C436', 'C405', 'C406'),
    ('RN', 'U402', ('5', '6', '7'), 'N4_IVR_N', 'N4_IVR_P', 'R413', 'R414', 'R415', 'R416', 'R444', 'R445', 'C437', 'C438', 'C407', 'C408')]
for (lg, u, (pp, pn, po), srcN, srcP, r1a, r2, r3a, r4, r1b, r3b, ctn, ctp, cln, clp) in LEGS:
    leg = 'LEG_' + lg
    tn, tp, inn, inp = 'N4_%s_TN' % lg, 'N4_%s_TP' % lg, 'N4_%s_INN' % lg, 'N4_%s_INP' % lg
    two(r1a, srcN, tn, 'R1a 1.30 k'); two(r1b, tn, inn, 'R1b 680'); two(ctn, tn, 'GND', 'Ct 1.8 nF C0G (T filter)')
    two(r2, inn, 'N4_%s_OUT' % lg, 'R2 2.00 k feedback (from the op-amp output pin)'); two(cln, inn, 'N4_%s_OUT' % lg, 'Clead 10 pF across R2')
    two(r3a, srcP, tp, 'R3a 1.30 k'); two(r3b, tp, inp, 'R3b 680'); two(ctp, tp, 'GND', 'Ct 1.8 nF C0G (T filter)')
    two(r4, inp, 'GND', 'R4 2.00 k'); two(clp, inp, 'GND', 'Clead 10 pF across R4')
LEGPIN = {}
for (lg, u, (pp, pn, po), *_rest) in LEGS:
    LEGPIN.setdefault(u, {})[pp] = ('+IN' + ('A' if pp == '1' else 'B'), 'N4_%s_INP' % lg)
    LEGPIN[u][pn] = ('-IN' + ('A' if pn == '10' else 'B'), 'N4_%s_INN' % lg)
    LEGPIN[u][po] = ('OUT' + ('A' if po == '9' else 'B'), 'N4_%s_OUT' % lg)
for u in ('U401', 'U402'):
    pins = []
    for pn in ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'PAD'):
        if pn in LEGPIN[u]:
            nm, n = LEGPIN[u][pn]; pins.append((pn, nm, n, ''))
        elif pn == '2': pins.append((pn, 'V+', 'VPOS', ''))
        elif pn == '3': pins.append((pn, 'GND', 'GND', 'EN reference; to GND, never to V-'))
        elif pn == '4': pins.append((pn, 'V-', 'VNEG', ''))
        elif pn == '8': pins.append((pn, 'EN', 'VPOS', 'tied to V+ (AMP_EN deleted; TI 7.3.3 allows EN to V+)'))
        elif pn == 'PAD': pins.append((pn, 'thermal pad', 'VNEG', 'connect to V- copper (SBOS727B)'))
    part(u, 'VSON10EP', pins)
for rl, lg in [('R417', 'LP'), ('R418', 'LN'), ('R419', 'RP'), ('R420', 'RN')]:
    two(rl, 'N4_%s_OUT' % lg, 'LEG_' + lg, 'DFT link 0 ohm: remove to drive LEG_%s from a lab source (rail-stuck emulation); LEG_%s -> K60x (TLP3545A) -> JACK_%s' % (lg, lg, lg))
for c, u, n in [('C409', 'U401', 'VPOS'), ('C410', 'U401', 'VNEG'), ('C411', 'U402', 'VPOS'), ('C412', 'U402', 'VNEG')]:
    two(c, n, 'GND', '100 nF at %s' % u)
for c, u, n in [('C413', 'U401', 'VPOS'), ('C414', 'U401', 'VNEG'), ('C415', 'U402', 'VPOS'), ('C416', 'U402', 'VNEG')]:
    two(c, n, 'GND', '10 uF local bulk at %s' % u)
# ------------------------------------------------------------------ jacks and ESD (pin numbers PROVISIONAL: drawings image-only, R8-A10)
PROV = 'PIN NUMBER PROVISIONAL: continuity-test 2 samples before footprint freeze (R8-A10)'
part('J701', 'J701', [(1, 'Tip (L+)', 'JACK_LP', PROV + '; after K601'), (2, 'Ring 1 (L-)', 'JACK_LN', PROV + '; after K602 (D-2: switched, was LEG_LN)'),
                      (3, 'Ring 2 (R+)', 'JACK_RP', PROV + '; after K603'), (4, 'Ring 3 (R-)', 'JACK_RN', PROV + '; after K604 (D-2: switched, was LEG_RN)'),
                      (5, 'Sleeve (GND)', 'GND', PROV + '; dedicated sleeve return, >= 4 vias'),
                      (6, 'Socket/mount', 'GND', PROV), (7, 'Socket/mount', 'GND', PROV)])
part('J702', 'J702', [(1, 'Tip (L+)', 'JACK_LP', PROV), (2, 'Ring 1 (R+)', 'JACK_RP', PROV), (3, 'Ring 2', 'GND', PROV + '; TRRS body with TRS plug'),
                      (4, 'Sleeve (GND)', 'GND', PROV + '; dedicated sleeve return, >= 4 vias'), (5, 'Mount', 'GND', PROV), (6, 'Mount', 'GND', PROV)])
for d, n in [('D701', 'JACK_LP'), ('D702', 'JACK_RP'), ('D703', 'JACK_LN'), ('D704', 'JACK_RN')]:
    two(d, n, 'GND', 'bidirectional ESD at the jack contact, jack side of the switch (D-2); symmetric part, either orientation', names=('1', '2'))

# ------------------------------------------------------------------ checks
issues = []
refs = collections.OrderedDict()
for r in net:
    refs.setdefault(r['refdes'], []).append(r)
for ref, rows in refs.items():
    if ref in RETIRED: issues.append('retired designator reused: %s' % ref)
    if len(rows) != PINCOUNT[pkg[ref]]: issues.append('%s pin count %d != %d' % (ref, len(rows), PINCOUNT[pkg[ref]]))
    if len(set(x['pin'] for x in rows)) != len(rows): issues.append('%s duplicate pin' % ref)
nets = collections.Counter(r['net'] for r in net)
for n, k in nets.items():
    if n not in IFACE and not re.match(r'^N[347]_', n): issues.append('illegal net name %s' % n)
    if re.match(r'^N[347]_', n) and k < 2: issues.append('internal net %s has %d connection' % (n, k))
with open(os.path.join(ROOT, 'netlist.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=['refdes', 'pin', 'pin_name', 'net', 'note']); w.writeheader(); w.writerows(net)

# ------------------------------------------------------------------ BOM
DS = dict(ess='https://www.esstech.com/ (ES9018K2M datasheet v3.7, 22 Apr 2021; local external/input/ES9018K2M_Datasheet_v3_7-3074373.pdf)',
          o2210='https://www.ti.com/lit/ds/symlink/opa2210.pdf (SBOS924H)', o1622='https://www.ti.com/lit/ds/symlink/opa1622.pdf (SBOS727B)',
          yag='https://yageogroup.com/ (RT series thin film)', b54a='https://assets.nexperia.com/documents/data-sheet/BAT54A.pdf',
          lcsc='https://www.lcsc.com/product-detail/%s.html')
B = []
def bom(block, refs_, desc, value, package, rt, mpn, lcsc, cls, stock, fit, leadless, smt, tht, price, ds, note=''):
    B.append(dict(block=block, refs=refs_, qty=len(expand(refs_)), desc=desc, value=value, package=package, rating_tolerance=rt, mpn=mpn,
                  lcsc=lcsc, jlcpcb_class=cls, jlcpcb_stock_or_sourcing=stock, fit=fit, leadless=leadless, smt_pins_per_part=smt,
                  tht_pins_per_part=tht, unit_price_usd=price, datasheet_url=ds, note=note))
def expand(s):
    out = []
    for tok in [t.strip() for t in s.split(',')]:
        m = re.match(r'^([A-Z]+)(\d+)[-–]([A-Z]*)(\d+)$', tok)
        if m:
            out += ['%s%d' % (m.group(1), i) for i in range(int(m.group(2)), int(m.group(4)) + 1)]
        else:
            out.append(tok)
    return out
b3 = '3 DAC (ES9018K2M) and its supplies'; b4 = '4 I/V converters and output legs'; b7 = '7 Outputs (jacks, ESD)'
bom(b3, 'U301', 'DAC, 32-bit stereo, current-mode outputs, I2C; asynchronous (DPLL) mode', 'ES9018K2M', 'QFN-28 5x5 + EP',
    'DNR 127 dB-A, THD+N -120 dB typ (current mode)', 'ESS ES9018K2M', 'C2688377', 'Extended', 'LCSC 724 (v0.8 record); reserve', 'Yes', 'Yes', 29, 0, 3.4678, DS['ess'])
bom(b3, 'R301, R302', 'AVCC_L / AVCC_R feed from 3V3A (separate branches)', '2.2 ohm', '0805', '1 %, 0.125 W', 'UNI-ROYAL 0805W8F220KT5E', 'C17521', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.003, DS['lcsc'] % 'C17521')
bom(b3, 'C303, C304, C310, C439, C440', 'AVCC_L, AVCC_R and DVDD bulk at the DAC pins; C439 DVCC / C440 VCCA after FB301/FB302 (X-10, B-07 resonance damping)', '2.2 uF', '0603', '16 V X5R +-10 %',
    'Samsung CL10A225KO8NNNC', 'C23630', 'Basic', 'JLCPCB 3.2 M (Sep 2026)', 'Yes', 'No', 2, 0, 0.0191, DS['lcsc'] % 'C23630')
bom(b3, 'C305-C309', 'HF decoupling at AVCC_L, AVCC_R, VCCA, DVCC, DVDD pins', '100 nF', '0402', '16 V X7R +-10 %', 'Samsung CL05B104KO5NNNC', 'C1525', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.0045, DS['lcsc'] % 'C1525')
bom(b3, 'R305', 'DAC RESETB pull-UP to DVCC for the Q207 open-drain driver (X-7); 0.33 mA from DVCC only while Q207 holds reset', '10 kOhm', '0402', '1 %', 'UNI-ROYAL 0402WGF1002TCE', 'C25744', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.0033, DS['lcsc'] % 'C25744',
    'VIH >= DVCC/2 + 0.4 V met with >= 3.0 V; VOL <= 7 mV with Q207; rise 0.4 us (10-90 %); was 100 k pull-down to GND (round 2)')
bom(b3, 'FB301, FB302', 'Ferrite beads: 3V3D -> DVCC (FB301, 14.2 mA) and 3V3A -> VCCA (FB302, 0.8 mA at 22 MHz, <= 2.9 mA at 80 MHz [ASSUMP], XI buffer)', '600 ohm @ 100 MHz', '0603',
    '200 mA, 0.45 ohm DCR', 'Sunlord GZ1608D601TF', 'C1002', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.0127, DS['lcsc'] % 'C1002', 'FB302 new (VCCA branch)')
bom(b4, 'U403, U404', 'Op-amp, dual, I/V converters (one amplifier per DAC pin)', 'OPA2210IDR', 'SOIC-8', 'Vos 35 uV, IQ 2.5 mA/ch max, CM (V-)+1.5..(V+)-1.5 V',
    'TI OPA2210IDR', 'C1849415', 'Extended', 'LCSC 16 in stock (25 Sep 2026): order 12 = 10 for 5 boards + attrition (VE O-1: no spares) into the JLCPCB private library; DigiKey 0 (1,626 due 14 Dec 2026), Mouser 0 (9,922 due 23 Nov 2026) [parts FU3]', 'Yes', 'No', 8, 0, 2.6708, DS['o2210'],
    'no fallback part (A9): order before layout release; unit price corrected 25 Sep 2026 by integration (review B-11 / decisions_r8c DZ-5): LCSC C1849415 US$ 2.6708')
bom(b4, 'R423-R426', 'I/V feedback resistor Rf (single part, replaces 1 k || 5.1 k)', '698 ohm', '0603', '0.1 %, 25 ppm/K, thin film', 'YAGEO RT0603BRD07698RL',
    'C861525', 'Extended', 'LCSC 120 in stock (25 Sep 2026, min/multiple 20): order 40 = 20 + attrition, no global sourcing (VE, O-1)', 'Yes', 'No', 2, 0, 0.0254, DS['lcsc'] % 'C861525', 'change control: sets the protection CM window (p04) - change only together with protection')
bom(b4, 'C417-C420', 'I/V feedback capacitor Cf (single part, replaces 2 x 330 pF): 278 kHz with 698 ohm', '820 pF', '0603', '50 V C0G +-5 %',
    'KEMET C0603C821J5GACTU', 'C2169093', 'Extended', 'LCSC 880; alt. Murata GRM1885C1H821JA01D', 'Yes', 'No', 2, 0, 0.0111, DS['lcsc'] % 'C2169093')
bom(b4, 'R431', 'VREF divider top (from 3V3A)', '9.76 kOhm', '0603', '0.1 %, 25 ppm/K, thin film', 'YAGEO RT0603BRD079K76L', 'C861616', 'Extended', 'LCSC ~1,860', 'Yes', 'No', 2, 0, 0.035, DS['lcsc'] % 'C861616',
    'VREF = 0.50607 x 3V3A = 1.670 V: midpoint of the ESS null range 1.65..1.702 V; change control: sets the protection CM window (p04) - change only together with protection')
bom(b4, 'R432', 'VREF divider bottom', '10.0 kOhm', '0603', '0.1 %, 25 ppm/K, thin film', 'YAGEO RT0603BRD0710KL', 'C95204', 'Extended', 'LCSC 498,660', 'Yes', 'No', 2, 0, 0.0331, DS['lcsc'] % 'C95204', 'change control: sets the protection CM window (p04) - change only together with protection')
bom(b4, 'C421', 'VREF HF decoupling (tau 0.19 us: VREF tracks 3V3A)', '33 pF', '0402', '50 V C0G +-5 %', 'FH 0402CG330J500NT', 'C1562', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.002, DS['lcsc'] % 'C1562')
bom(b4, 'R446, R447', 'DNF VREF trim footprints (X-10, signal F4): R446 parallel to R431 raises VREF, R447 parallel to R432 lowers VREF; fitted only if the 25 C offset screen fails', 'DNF (237 k ... 2 M)', '0603',
    '0.1 %, 25 ppm/K thin film when fitted', 'YAGEO RT0603BRD07xxxL (value from the trim table)', 'n/a', 'Extended', 'DNF', 'DNF', 'No', 2, 0, 0.0, DS['yag'],
    'trim table in report R3.4: 237 k -> VREF +2.1 %, 487 k +1.0 %, 243 k -2.1 %, 499 k -1.0 %; change control with protection p04 (VREF/3V3A window)')
bom(b3, 'C441', 'DNF 3V3A capacitor (X-10, signal F2 / states #8): slows a current-limited 3V3A rise for power-up pop margin', '1 uF', '0603', '50 V X5R +-10 %', 'Samsung CL10A105KB8NNNC', 'C15849', 'Basic', 'DNF (JLCPCB stock when fitted)', 'DNF', 'No', 2, 0, 0.0,
    DS['lcsc'] % 'C15849', 'with C440 fitted, 3V3A stays <= 10 uF effective (LP5907) only with DC-bias credit (R3.3); power stream to confirm before fitting')
bom(b4, 'D405-D408', 'DAC-pin protection moved to the I/V outputs: dual series Schottky, common node on each OPA2210 output, lower anode to GND, upper cathode to AVCC_L (D405/D406) or AVCC_R (D407/D408); nothing on the DAC pins (virtual ground)',
    'BAT54S', 'SOT-23', '30 V, 200 mA, IFSM 600 mA, VF <= 0.5 V at 30 mA, Cd <= 10 pF', 'Nexperia BAT54S,215', 'C47546', 'Extended', 'JLCPCB ~230 k, Economic and Standard, MSL 1 (parts FU3, 25 Sep 2026)', 'Yes', 'No', 3, 0, 0.0245,
    'https://assets.nexperia.com/documents/data-sheet/BAT54S.pdf', 'pin 1 A1, pin 2 K2, pin 3 K1/A2 (Nexperia Table 2); replaces JSMSEMI BAT54S C916425 at the DAC pins')
bom(b4, 'C423-C426', 'OPA2210 VPOS_IV and VNEG_IV decoupling (X-8)', '100 nF', '0402', '16 V X7R +-10 %', 'Samsung CL05B104KO5NNNC', 'C1525', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.0045, DS['lcsc'] % 'C1525')
bom(b4, 'D411, D412', 'X-8 I/V supply hold-up diodes: VPOS -> VPOS_IV (D411) and VNEG_IV -> VNEG (D412), low-VF Schottky', 'PMEG2010AEH', 'SOD-123F',
    '20 V, 1 A; VF <= 253 mV at 30 mA, 25 C [DS max]; <= 298 mV at 30 mA and <= 282 mV at the 17.4 mA operating maximum, 0 C [CALC, tempco -1.5...-1.8 mV/K typ] vs 0.30 V used; IR 0.28-0.44 mA at 5 V, 50 C [parts] vs 1 mA in the hold-up model', 'Nexperia PMEG2010AEH,115', 'C110921', 'Extended',
    'LCSC 7,335 in stock (25 Sep 2026, min/multiple 5): JLCPCB/LCSC order, no global sourcing (VE)', 'Yes', 'No', 2, 0, 0.3209, 'https://assets.nexperia.com/documents/data-sheet/PMEG2010AEH.pdf', 'pin 1 cathode, pin 2 anode (SOD123F); OPA2210 then stays powered and inside its CM range until 3V3A < 0.3 V at every hard unplug (R3.1)')
bom(b4, 'C442, C443', 'X-8 I/V supply reservoirs (VPOS_IV, VNEG_IV), MnO2 tantalum (no DC-bias loss): 198-242 uF', '220 uF', '7343-31 (D)', '10 V, +-10 %, ESR <= 0.5 ohm at 100 kHz, DCL <= 22 uA (0.01CV) at 25 C [AVX TAJ rule]', 'Kyocera AVX TAJD227K010RNJ', 'C8024', 'Extended',
    'LCSC 44,987 in stock (25 Sep 2026)', 'Yes', 'No', 2, 0, 0.5257, DS['lcsc'] % 'C8024', 'VE (O-3): replaces KEMET T495D227K010ATE100 (global sourcing, 24-week lead); polarised: C442 + to VPOS_IV, C443 + to GND; applied <= 3.9 V = 39 % of rated; reverse clamped by D413/D414; charging current limited by the LM27762 (no surge); hold-up re-run at 176 uF with VF + ESR drop 0.31 V (VE)')
bom(b4, 'D413, D414', 'DY-3 reverse clamps across the polarised I/V reservoirs: D413 GND -> N4_VPOS_IV (across C442), D414 N4_VNEG_IV -> GND (across C443)', 'BAT54', 'SOT-23',
    '30 V, 200 mA; VF <= 400 mV at 10 mA, <= 500 mV at 30 mA (25 C); IR <= 2 uA at 25 V, 25 C', 'Nexperia BAT54,215', 'C85084', 'Extended', 'JLCPCB stock >> need (same part as power X-4 clamps)', 'Yes', 'No', 3, 0, 0.02,
    'https://assets.nexperia.com/documents/data-sheet/BAT54_SER.pdf', 'pin 1 A, pin 2 n.c. (pad only), pin 3 K; place each within 3 mm of its capacitor; C442/C443 reverse <= 0.47 V (<= 13 mA, 0 C); leakage <= 25 uA per rail at 60 C [ASSUMP] (R3.13)')
bom(b4, 'U401, U402', 'Op-amp, dual, output legs (U401 = L+/L-, U402 = R+/R-); EN tied to V+', 'OPA1622IDRCR', 'VSON-10 3x3 + pad', 'IQ 3.3 mA/ch max (25 C), 4.2 mA/ch (-40..125 C)',
    'TI OPA1622IDRCR', 'C2876559', 'Extended', 'JLCPCB stock (v0.8 record)', 'Yes', 'Yes', 11, 0, 1.7871, DS['o1622'])
bom(b4, 'R401, R403, R405, R407, R409, R411, R413, R415', 'Leg input T network, first half R1a/R3a (round 2: 1.33 k -> 1.30 k, stocked 0.05 %/10 ppm)', '1.30 kOhm', '0603', '0.1 %, 25 ppm/K, thin film, 0.1 W',
    'YAGEO RT0603BRD071K3L', 'C705738', 'Extended', 'LCSC 100 in stock (25 Sep 2026, min/multiple 20): order 60 = 40 + attrition', 'Yes', 'No', 2, 0, 0.0259,
    DS['lcsc'] % 'C705738',
    'VE (O-3): replaces Susumu RG1608N-132-W-T1 0.05 %/10 ppm (US$0.60, global sourcing) -> offset with the R9 E-4 mixed network (0.05 % 2.00 k): 7.73 / 15.47 mV design, 5.61 / 11.21 mV guaranteed, screening 7.83 / 15.67 mV; if LCSC stock < 60 at ordering, fit the Susumu part; earlier: replaces RT0603WRB071K33L (not stocked, MOQ 5,000, 20 weeks); leg gain 2.00/1.98 k - change control: sets the protection CM window (p04) - change only together with protection')
bom(b4, 'R438-R445', 'Leg input T network, second half R1b/R3b (round 2: 665 -> 680 ohm, stocked 0.05 %/10 ppm)', '680 ohm', '0603', '0.1 %, 25 ppm/K, thin film, 0.1 W',
    'YAGEO RT0603BRD07680RL', 'C861519', 'Extended', 'LCSC 8,000 in stock (25 Sep 2026, min/multiple 20)', 'Yes', 'No', 2, 0, 0.0256,
    DS['lcsc'] % 'C861519',
    'VE (O-3): replaces Susumu RG1608N-681-W-T1 0.05 %/10 ppm (US$0.60, global sourcing); offset see R401 line')
bom(b4, 'R402, R404, R406, R408, R410, R412, R414, R416', 'Leg feedback R2 and ground-leg R4', '2.00 kOhm', '0603', '0.05 %, 10 ppm/K, thin film, 0.1 W, AEC-Q200', 'Susumu RG1608N-202-W-T1',
    'n/a', 'Extended (global sourcing)', 'DigiKey 16,746 cut tape (parts FU3, 25 Sep 2026) -> JLCPCB global sourcing; alternate Panasonic ERA-3ARW202V (0.05 %/10 ppm, DigiKey 1,259); no LCSC stock (YAGEO RT0603WRB072KL C864006 out of stock 25 Sep 2026)', 'Yes', 'No', 2, 0, 0.60,
    'https://www.digikey.com/en/products/detail/susumu/RG1608N-202-W-T1/600604',
    'R9 E-4 mixed leg network: 0.05 % 2.00 k (R2/R4) with the 0.1 % T network -> offset guaranteed (published terms) 5.61 / 11.21 mV, design 7.73 / 15.47 mV, tolerates 2.06 x the DAC assumption; VE Panasonic ERA-3AEB202V C193242 (0.1 %) superseded')
bom(b4, 'C431-C438', 'Leg T-network shunt capacitor (pole 199 kHz, HF noise gain 4 for capacitive-load stability)', '1.8 nF', '0603', '50 V C0G +-5 %',
    'Murata GRM1885C1H182JA01D', 'C97878', 'Extended', 'LCSC 750-1,900', 'Yes', 'No', 2, 0, 0.0163, DS['lcsc'] % 'C97878')
bom(b4, 'C401-C408', 'Leg lead capacitor across R2 and across R4 (phase lead; same value both sides for CMRR)', '10 pF', '0603', '50 V C0G +-5 % (+-0.5 pF)',
    'Samsung CL10C100JB8NNNC', 'C1634', 'Basic', 'JLCPCB 1.44 M', 'Yes', 'No', 2, 0, 0.0076, DS['lcsc'] % 'C1634', 'fallback value range 4.7-22 pF on the same footprint')
bom(b4, 'R417-R420', 'DFT link per leg between the OPA1622 output pin and the leg node LEG_xx (protection sense networks, output switch K601-K604 to the jack); removed on the test board for the rail-stuck emulation',
    '0 ohm', '0402', 'jumper, <= 50 mOhm', 'UNI-ROYAL 0402WGF0000TCE', 'C17168', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.002, DS['lcsc'] % 'C17168',
    'kept for DFT (brief 7.2 detector/energy tests); approved alternate (X-10, signal F5): ferrite bead Murata BLM15PX330SN1D (0402, 33 ohm +-25 % at 100 MHz, 3 A, DCR <= 0.022 ohm) for ESD robustness with the switch closed - fit 0 ohm by default')
bom(b4, 'C409-C412', 'OPA1622 V+ and V- decoupling', '100 nF', '0402', '16 V X7R +-10 %', 'Samsung CL05B104KO5NNNC', 'C1525', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.0045, DS['lcsc'] % 'C1525')
bom(b4, 'C413-C416', 'OPA1622 local bulk, V+ and V-', '10 uF', '0805', '25 V X5R +-10 %', 'Samsung CL21A106KAYNNNE', 'C15850', 'Basic', 'JLCPCB stock', 'Yes', 'No', 2, 0, 0.085, DS['lcsc'] % 'C15850')
bom(b7, 'J701', 'Jack, 4.4 mm 5-pole balanced (L+, L-, R+, R-, GND)', '-', 'Through-hole', '30 V, 500 mA, gold, -20..+70 C', 'G-Switch GT-3321667P-01', 'C2762984', 'Extended',
    'owner purchase: LCSC C2762984 (LCSC 724 at the last check), 5 pcs', 'Yes', 'No', 0, 7, 6.906, DS['lcsc'] % 'C2762984', 'owner-fitted (hand-soldered, not placed by JLCPCB) - VE O-4: THT, 7 joints, lands with toes >= 0.3 mm and >= 1.5 mm iron clearance; pin map provisional (R8-A10)')
bom(b7, 'J702', 'Jack, 3.5 mm (TRRS body used with TRS plugs; ring 2 to GND)', '-', 'SMD', 'gold, 1 A', 'HRO PJ-332A-6A', 'C2848643', 'Extended', 'JLCPCB stock (assembly difficulty "high")',
    'Yes', 'No', 6, 0, 0.2921, DS['lcsc'] % 'C2848643', 'pin map provisional (R8-A10); VE: reflow peak rating not verified - parts to confirm >= 260 C for Economic PCBA (an SMD jack cannot be owner-fitted under O-4)')
bom(b7, 'D701-D704', 'ESD diode, bidirectional, one per jack contact on the jack side of the switches (JACK_LP, JACK_RP, JACK_LN, JACK_RN)', '5 V', 'SOD-523',
    'bidirectional (DS V-I figure); VRWM 5 V, VBR 7 V (>= 6 V min), VC <= 16 V at IPP 7 A 8/20 us, CJ 12 pF typ, IR <= 1 uA at 5 V [DS-listing]; IEC 61000-4-2 level 4',
    'GOODWORK LESD5D5.0CT1G', 'C41399463', 'Extended', 'LCSC 13,650 (24 Sep 2026); JLCPCB 131,706 (21 Aug 2026), Economic and Standard', 'Yes', 'No', 2, 0, 0.0155,
    'https://wmsc.lcsc.com/wmsc/upload/file/pdf/v2/lcsc/2412061650_GOODWORK-LESD5D5-0CT1G_C41399463.pdf',
    'legs swing +-3.92 V max (< VRWM 5 V); numeric table of the PDF is an image (values from LCSC/JLCPCB/DigiKey listings); approved alternate: LRC LESD5D5.0CT1G C383211 (bidirectional, VRWM 5 V, VBR 7.8 V, VC 18.6 V at 9.4 A, 15 pF, MSL 3) - order by C number')
bomrefs = [x for b in B for x in expand(b['refs'])]
cnt = collections.Counter(bomrefs)
for r, k in cnt.items():
    if k > 1: issues.append('BOM duplicate ref %s' % r)
for r in refs:
    if r not in cnt: issues.append('netlist ref %s missing from BOM' % r)
for r in cnt:
    if r not in refs: issues.append('BOM ref %s missing from netlist' % r)
with open(os.path.join(ROOT, 'bom_rows.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(B[0].keys())); w.writeheader(); w.writerows(B)
tot = sum(b['qty'] * b['unit_price_usd'] for b in B)
rep = ['parts: %d refdes, %d netlist rows, %d BOM lines, %d placed parts' % (len(refs), len(net), len(B), len(bomrefs)),
       'nets: %d (%s)' % (len(nets), ', '.join(sorted(nets))), 'estimated analog-stream part cost US$ %.2f per board' % tot,
       'SMT joints %d, THT joints %d' % (sum(b['qty'] * b['smt_pins_per_part'] for b in B), sum(b['qty'] * b['tht_pins_per_part'] for b in B)),
       'issues: %s' % ('none' if not issues else '; '.join(issues))]
open(os.path.join(ROOT, 'out', 'netlist_check.txt'), 'w').write('\n'.join(rep) + '\n')
print('\n'.join(rep))
