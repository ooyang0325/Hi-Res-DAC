"""Round 2: OPA1622 leg stability with the Toshiba TLP3545A output switch (D-1) in the path, switch CLOSED and OPEN,
leg T network 1.30 k + 680 ohm (retuned to stocked 0.05 %/10 ppm parts; round 1: 1.33 k + 665 ohm), Ct 1.8 nF, R2 = R4 = 2.00 k, Clead 10 pF,
over the round-1 load family (open; 16/32/60/300/600 ohm x 0/100/220/470/1000 pF; 3 m cable + 1 nF; cable + 2 pF;
2 nF stress) = 37 cases, 4 OPA1622 models (CAL fitted to Fig. 24 at GBW x0.8/1.0/1.25, PHYS from Fig. 40),
Ct 1.8 nF and Clead 10 pF at -5 %/-0.5 pF, nominal, +5 %/+0.5 pF.

Leg node LEG_xx (amplifier side of the switch) now carries the protection networks: DC-sense 6.8 kOhm to a 4.7 uF node
(AC ground) and the detector filter 105 kOhm to 2.2 uF (AC ground) + 5 pF trace.
Switch closed: Ron 0.035 ohm (typ) or 0.081 ohm (0.060 ohm max x 1.35 at 60 C) in series with 5 or 15 nH (DIP6 LF1 leads,
bond wires, trace) [ASSUMP], CS 0.8 pF to the LED side (AC ground) on each terminal [DS-typ].
Switch open: COFF between LEG_xx and JACK_xx = 100 / 330 / 640 (DS typ, 0 V) / 1000 pF (bound) and 1.5 nF (stress).
Jack node: LESD5D5.0CT1G 12 pF typ -> 15 pF used [DS-listing +25 %].
Output: ../out/stability_switch.txt"""
import os, sys, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from mna_v import Circuit, margins
from models_v import OPA1622v

OUT = os.path.join(os.path.dirname(__file__), '..', 'out')
FR = np.logspace(3, 8.7, 700)


def build(load, CL, op, cable, sw, Ct=1.8e-9, Cl=10e-12, R1a=1300.0, R1b=680.0, R2=2000.0, drive=False):
    """sw = ('closed', Ron, Lsw) or ('open', Coff)."""
    c = Circuit()
    if drive:
        c.R('sA', 'dA', 20.0); c.R('sB', 'dB', 20.0); c.V('VA', 'dA', '0', -0.5); c.V('VB', 'dB', '0', 0.5)
    else:
        c.R('sA', '0', 20.0); c.R('sB', '0', 20.0)
    c.R('sA', 'mA', R1a); c.R('mA', 'N', R1b); c.C('mA', '0', Ct)
    c.R('sB', 'mB', R1a); c.R('mB', 'P', R1b); c.C('mB', '0', Ct)
    c.R('N', 'OUT', R2); c.C('N', 'OUT', Cl); c.R('P', '0', R2); c.C('P', '0', Cl)
    c.OPAMP('U', 'P', 'N', 'OUT', op.A, op.Zo)
    c.C('P', 'N', op.CIN_DIFF); c.C('P', '0', op.CIN_CM + 1.5e-12); c.C('N', '0', op.CIN_CM + 1.5e-12)
    c.R('OUT', 'lk', 0.05); c.L('lk', 'LEG', 5e-9)            # R417-R420 link + trace
    c.R('LEG', '0', 6.8e3); c.R('LEG', '0', 105e3); c.C('LEG', '0', 5e-12)
    if sw[0] == 'closed':
        c.R('LEG', 'k', sw[1]); c.L('k', 'JACK', sw[2]); c.C('LEG', '0', 0.8e-12); c.C('JACK', '0', 0.8e-12)
    else:
        c.C('LEG', 'JACK', sw[1]); c.R('JACK', '0', 1e9)
    c.C('JACK', '0', 15e-12)
    if load != 'open':
        if CL: c.C('JACK', '0', CL)
        if cable:
            prev = 'JACK'
            for i in range(3):
                c.R(prev, 'cr%d' % i, 0.2); c.L('cr%d' % i, 'cn%d' % i, 0.6e-6); c.C('cn%d' % i, '0', 100e-12)
                prev = 'cn%d' % i
            c.R(prev, 'hp', load); c.L('hp', '0', 30e-6)
        else:
            c.R('JACK', '0', load)
    return c


def ideal_response(f, Ct=1.8e-9, R1a=1300.0, R1b=680.0, R2=2000.0, Cl=10e-12):
    s = 2j * np.pi * f
    return (R1a + R1b) / (R1a + R1b + s * Ct * R1a * R1b) / (1 + s * R2 * Cl) * R2 / (R1a + R1b)


MODELS = [('CAL', 1.0), ('CAL', 0.8), ('CAL', 1.25), ('PHYS', 1.0)]
OPS = {m: OPA1622v(*m) for m in MODELS}
CAPS = [(1, 0), (0.95, -0.5e-12), (1.05, 0.5e-12)]
LOADS = [('open', 0, False)] + [(r, c, False) for r in (16, 32, 60, 300, 600) for c in (0, 100e-12, 220e-12, 470e-12, 1e-9)] \
        + [(r, 1e-9, True) for r in (16, 32, 300, 600)] + [(r, 2e-12, True) for r in (32, 300)]
STRESS = [(r, 2e-9, False) for r in (16, 32, 300, 600)]
CLOSED = [('closed', 0.035, 5e-9), ('closed', 0.035, 15e-9), ('closed', 0.081, 5e-9), ('closed', 0.081, 15e-9)]
OPEN = [('open', 100e-12), ('open', 330e-12), ('open', 640e-12), ('open', 1e-9)]
OPEN_STRESS = [('open', 1.5e-9)]


def family(sws, loads):
    res = []
    for (load, CL, cable) in loads:
        pmw, gmw, msw, where = 999, 999, 0, None
        for sw in sws:
            for mk in MODELS:
                for dct, dcl in CAPS:
                    m = margins(FR, build(load, CL, OPS[mk], cable, sw, Ct=1.8e-9 * dct, Cl=10e-12 + dcl).loop_gain(FR, 'U'))
                    pm = m['pm_worst'] if m['pm_worst'] is not None else 999
                    if pm < pmw: pmw, where = pm, (sw, mk)
                    msw = max(msw, 1 / m['vector_margin'])
                    if m['gm'] is not None: gmw = min(gmw, m['gm'])
        res.append((load, CL, cable, pmw, gmw, msw, where))
    return res


lines = [__doc__.split('\n')[0], '']
summary = {}
for title, sws, loads in [('SWITCH CLOSED (Ron 0.035/0.081 ohm, 5/15 nH)', CLOSED, LOADS + STRESS),
                          ('SWITCH OPEN (COFF 100/330/640/1000 pF between LEG and JACK)', OPEN, LOADS + STRESS),
                          ('SWITCH OPEN, COFF 1.5 nF stress', OPEN_STRESS, LOADS + STRESS)]:
    lines.append(title)
    lines.append(' load  CL(pF) cable | worst PM (deg) | min GM (dB) | max Ms (dB) | worst corner')
    res = family(sws, loads)
    pm_main = min(r[3] for r in res if r[1] <= 1e-9); gm_main = min(r[4] for r in res if r[1] <= 1e-9)
    ms_main = max(r[5] for r in res if r[1] <= 1e-9); pm_str = min(r[3] for r in res if r[1] > 1e-9)
    for load, CL, cable, pmw, gmw, msw, where in res:
        lines.append(' %5s %6.0f %5s | %8.1f | %8.1f | %8.2f | %s %s' % (load, CL * 1e12, cable, pmw, gmw, 20 * np.log10(msw),
                                                                    '/'.join(str(x) for x in where[0]), '%s x%.2f' % where[1]))
    lines.append('SUMMARY %s: worst PM %.1f deg, min GM %.1f dB, max Ms %.2f dB for 0..1 nF + cable; worst PM %.1f deg at the 2 nF stress'
                 % (title.split(' (')[0], pm_main, gm_main, 20 * np.log10(ms_main), pm_str))
    lines.append('')
    summary[title] = (pm_main, gm_main, ms_main, pm_str)
# closed-loop peaking vs the ideal filter response, switch closed, nominal CAL model
lines.append('Closed-loop response vs ideal T/lead filter (CAL x1, switch closed Ron 0.081 ohm 15 nH):')
for (load, CL, cable) in [(16, 1e-9, False), (300, 1e-9, False), (300, 1e-9, True), (32, 0, False)]:
    v = build(load, CL, OPS[('CAL', 1.0)], cable, ('closed', 0.081, 15e-9), drive=True).solve(FR)
    h = np.abs(v('JACK')) / np.abs(ideal_response(FR)); h0 = h[np.searchsorted(FR, 1e3)]
    sel = FR < 20e6
    lines.append('  %4s ohm %5.0f pF cable %-5s: peaking %+.2f dB at %.2f MHz; |H(20 kHz)| vs 1 kHz %+.4f dB'
                 % (load, CL * 1e12, cable, 20 * np.log10(np.max(h[sel]) / h0), FR[sel][np.argmax(h[sel])] / 1e6,
                    20 * np.log10(np.abs(v('JACK'))[np.searchsorted(FR, 2e4)] / np.abs(v('JACK'))[np.searchsorted(FR, 1e3)])))
open(os.path.join(OUT, 'stability_switch.txt'), 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
