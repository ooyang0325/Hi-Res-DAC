# Protection stream — R8 review fixes (round 3) progress log

Owner: protection engineer. Start 25 Sep 2026 08:30 UTC. Scope: X-6 (priority), X-9, firmware numbers (pre-close, IWDG, boot self-test), report/BOM/netlist/check.

| Time (UTC) | Step | Status | Files |
|---|---|---|---|
| 08:31 | Read decisions_r8c/r8b; started log | done | fix_progress.md |
| 08:50 | Design choices fixed (X-6): U605 = TLV3402 nanopower on 3V3M driving two AO3400A pull-downs (TLV170x VOL 0.6-0.9 V > U206 VIL 0.8 V; 4x100 uA IQ would break the 31 uA S6 suspend margin); U606 = TLV1704 on VPOS/VNEG (1V3 good, MCLK alive, 3V3A-good repeater into N6_H, spare); U607 74AUP1G17 + BAS70-04 pump. Datasheet extracts saved in ds/ (TLV3402, 74AUP1G17) | in progress | ds/TLV3402_ti_*.txt, ds/74AUP1G17_nexperia_extract.txt |
| 08:53 | X-9: p11 candidates; chose R601-R604 115 k (C 2.2 uF kept, aged range 1.79-2.42 uF); p03 constants changed (backup p03_detector_r2.py.bak); p03+p06 re-run started | in progress | p11_x9_filter.py/_out.txt, p03_detector.py |
| 08:58 | X-9 done: p03/p06 re-run with R601-R604 115 k + aged C: FS 20 Hz square no trip down to C -24 % (aged corner -18.6 %, peak margin 6.2 %), square corner 18.7 Hz, sine 11.5 Hz; 1 V 111.0 ms, 2 V 51.2 ms; rail-stuck 25.6/12.8 mJ (15 %), stuck-pin envelope 27.2/13.6 mJ (9 %) | done | p03_detector_out.txt, p06_dcsense_tiers_out.txt, p11 |
| 08:59 | p10_supervisor.py written (X-6 + firmware numbers) | running | p10_supervisor.py |
| 09:00 | p10 run OK: MCLK dead <= 0.421 ms, frozen-code removal <= 2.40 ms / <= 1.38 mJ; U605 thresholds 3.006-3.125 V fall / 3.052-3.168 V rise; input swing at Kyocera 4.5 ns edges NOT provable (stated, fallback) | done | p10_supervisor_out.txt |
| 09:01 | BOM/netlist updated (p12): U605/U606/U607/Q619/Q620/D609/D610/R665-R689/C623-C629; R601-R604 115 k; backups *_r2.csv.bak | done | bom_rows.csv, netlist.csv, p12 |
| 09:04 | report.md: new top section 'R8 review fixes (round 3)' (R3.1-R3.13) inserted; backup report_r2.md.bak | done | report.md |
| 09:05 | check_design re-run: protection issues only the 3 MCU-side single-pin nets (N6_V13_TEST, N6_V3AG_A_MCU, N6_V3AG_B_MCU) pending digital; others not ours (ANA_SENSE naming, RAIL_EN stale list) | done | integration/check_result.json |
| 09:05 | ALL STEPS DONE. Open: digital to add PB8/PA12/PB9 nets + firmware rules; power to take currents (3V3D +3.36 mA, 3V3M +74 uA / +7.6 uA suspend, VPOS/VNEG +0.42 mA); [MEAS] MCLK-tap swing (Kyocera 4.5 ns edge not provable; 0 R fallback); LCSC codes TBC | done | report.md R3.11-R3.13 |
| 09:06 | Analog R3 message received (X-8 adopted: I/V on VPOS/VNEG - 0.30 V Schottky; reset CM >= 2.889 V; C440 on VCCA; I2C-fail fallback order; VREF trims change-controlled with p04) -> checking p04 CM window, fallback vs U605B | in progress | - |
| 09:10 | Analog X-8 impact: p04 re-run (IV_VF 0.30 V): stuck-high 2.89 V trips, <= 10.3/5.2 mJ; reset CM >= 2.889 V (margin 0.738 V); envelope/p06 unchanged; VREF trim window 0.489-0.531; fallback-order conflict with U605B flagged; report R3.14 added | done | p04_cm_monitor.py/_out.txt, report.md |
| 09:11 | Interface message sent to r9-analog, r11-digital, r11-power (X-8 check, VREF trim window, fallback conflict; MCU nets PB8/PA12/PB9 + firmware numbers; new rail loads) | done | - |
| 09:11 | Digital R3 message received (X-6 interface as built; asks VOL, MCLK-alive test limits (they assumed <=1 ms / <=155 ms), leg self-test criteria, PB8 use, pre-close finals) -> adding default-gain self-test windows to p10 | in progress | - |
| 09:13 | report R3.9 (default-gain windows) + R3.15 (digital answers) added | done | report.md, p10_supervisor_out.txt |
| 09:14 | Reply sent to r11-digital (mapping, VOL, corrected MCLK test limits 2.0/250 ms, leg self-test windows, PB8/PA12/PB9 nets, finals) | done | - |
| 09:17 | Digital: PB8/PA12/PB9 netted, R3.9 adopted; asks to reference DX-2 (suspend IWDG <= 1.6 s). Found DX-1 (suspend order, RELAY_EN low by 5.31 ms) and DX-4 (R501 232 k fallback, VPOS +0.13 V) in decisions_r8c (09:02) -> checking impact | in progress | - |
| 09:20 | R3.9 now references DX-2; R3.16 added (digital confirmation, DX-1 suspend switch-open <= 6.32 ms, DX-4 R501 fallback: fit R672 243 k with it; p13 script); p10 re-run | done | report.md, p10, p13 |
| 09:21 | Confirmation sent to r11-digital/r11-power (DX-2 referenced, DX-1 noted, R501 fallback requires R672 243 k). check_design: no protection issues. | done | - |
| 09:25 | Analog reply (VREF trims inside window; fallback kept as logged double-fault path <= 12.0 mV at 300 ohm; block-6 currents budgeted; C442/C443 -> T495 MnO2) recorded in R3.14; no protection change | done | report.md |
| 10:12 | Orchestrator unfreeze for DZ-1/DZ-6 check (330 ohm MCU series on sense nodes; R-5 update) | in progress | - |
| 10:15 | DZ-1: 330 ohm added (p09 R_PIN, p06 leakage + sampling charge): e_leg 57.50 -> 60.30 mV, e_pair 62.70 -> 65.51 mV; T3 pair threshold 0.118 -> 0.120 V (no-trip 22.1 mV >= 20 mV); pre-close 0.070/0.090 V pass healthy board with 7.5/15.9 mV; p10 now reads p06 | done | p06, p09, p10 (+_r3a.bak) |
| 10:17 | report: R3.5 (R-5 = DAC-core hang only; CPLD frozen word bounded like R-2), R3.9 pre-close, R3.17 added, R3.12 superseded list | done | report.md (backup report_r3a.md.bak) |
| 10:18 | Consistency: R3.15 refusal levels -> 129/155 mV. ALL DONE (DZ-1/DZ-6). | done | report.md |
- 10:25 orchestrator: R3.9 line 88 T3 text aligned to R3.17 (0.176/0.192 V).
| 10:58 | VE round started (unfrozen); reading ve/brief_ve.md | in progress | - |
| 11:00 | VE brief read; cost_report shows protection global-sourced lines (TLP3545A x4 +30 % duty, TLV1704 x4, PATT0402 24.9R, YAGEO 0.1 % 121k/115k/5.1k/866k/953k/330k/1M, 22M, 74AUP1G17). Plan: K601-K604 owner-fitted; R641/R642 LCSC 24.9R (p05 check); LCSC stock checks | in progress | - |
| 11:01 | Evidence: TLV3402IDR LCSC C91242 (745 pcs, US$0.68 @10+); TLV1704 LCSC C181596 61 pcs (Jul 2026) $1.25; YAGEO RT0402BRD0724R9L LCSC C852667 19,000 pcs $0.034; DigiKey TLP3545A(TP1,F) 28,529 pcs $3.684 @10+ (18 Sep 2026) | done | - |
| 11:04 | VE BOM/netlist (p14): K601-K604 owner-fitted (DigiKey); R641/R642 -> YAGEO C852667; U605 C91242; TLV1704 C181596 note; R668 1.00 M 1 % C26083 + R669 100 k 1 % (p10 re-run: MCLK dead <= 0.452 ms, margin 0.506 V, frozen code <= 2.43 ms / 1.39 mJ) | done | bom_rows.csv, netlist.csv, p10, p14 |
| 11:05 | report.md: new top section 'VE (value engineering)' (VE-P1..P5 adopted, rejected list, Economic check); check_design no issues | done | report.md |
| 11:06 | Evidence: 470k C25790 Extended (452,700); 22M C407703 Extended but LCSC OUT OF STOCK; BAS70-04,215 C389351 36,430; BAS70,215 C109295 OUT OF STOCK -> D610 to BAS70-04,215 (one half) planned | in progress | - |
| 11:07 | VE-P6: D610 -> BAS70-04,215 C389351 (BAS70,215 out of stock; one type fewer); evidence notes R688/R689 C25790, R679/R686 22M C407703 out of stock, U607 C545626 out of stock; p14 re-run; check_design | done | bom_rows.csv, netlist.csv, p14 |
| 11:07 | report VE section: VE-P6 row, totals (~US$ 83/order Economic), stock findings (22M, U607 out of stock) | done | report.md |
| 11:08 | VE done: adopted P1-P6 (~US$ 16.5/board, ~US$ 83/order Economic); open for parts: 22M and 74AUP1G17 out of stock at LCSC | done | report.md VE, bom_rows.csv, netlist.csv |
| 14:01 | OD round (owner decisions OD-1 stricter stream check, OD-2 DAC lock-status check) started; reading ve/brief_od.md, DZ-11/DZ-12 | in progress | - |
| 14:08 | Rule sent to digital (P1 22 ms / 0.30 FS level persistence + P2/P3 unchanged; post-CPLD -> RELAY_EN low); asked for OD-2 detection times. p15_od_guard.py written | in progress | p15 |
| 14:08 | p15 envelope: with P2 unchanged (50 ms/0.30) the worst digital DC + max 20 Hz content case is 15.0/30.1 mJ (d~0.40 FS, hardware 161 ms) -> at the limit; scanning P2 variants (TH/W) | in progress | p15 |
| 14:10 | p16/p16b scans: adopt P2 TH 0.30 -> 0.25 FS (50 ms) + new P4 CIC^2 2 x 150 ms, TH 0.15 FS: envelope 13.8 mJ (32 bal, 8 %), 25.3 mJ (16 bal, 16 %), SE 3.6/6.9; false-trigger margins sines 36 %/65 %, squares >22.7 Hz 16 %/49 % | done | p16_od_p2_scan*, p16b_od_p4_scan* |
| 14:13 | OD-2 energies with digital's times (fs s14: 1.04 / 16.45 / 17.45 / 102.43 ms) in p15 | done | p15_od_guard_out.txt |
| 14:16 | report.md: new top section 'OD-1/OD-2 (owner decisions)' (rule P1-P4, energies, boundary, OD-2 table, residual text, §10/test changes) | done | report.md (backup report_ve.md.bak) |
| 14:13 | OD done. Digital implemented the final rule (fs s13: P2 0.25, P4 150 ms/0.15, P1 exposure 23.61 ms) and OD-2 times (s14). | done | report.md OD section, p15/p16/p16b |
| 14:15 | Digital's 14:12 message (older times 12.8/13.8/106.8 ms, asked for constants) answered; report OD.4 notes the file values (16.45/17.45/102.43 ms) are used | done | report.md |
| 14:16 | Digital confirmed final OD-2 times (1.04/16.45/17.45/102.4 ms; reg 0-20 read-back every 10 ms; decision latency 0.60/0.225 ms; CPU 13.3 %, I2C 27.4 %) = values already in p15 -> no re-run needed; report OD.4 note updated | done | report.md |
| 14:17 | Digital's reply to the 14:08 questions (30 us / 15.44 / 16.44 / 101.42 ms to RELAY_EN low; P1 latency 0.60/0.225 ms) = same as p15 values (+1.008 ms) -> nothing to change | done | - |
| 15:53 | orchestrator data correction (integration, text fields only) | R601–R604: lcsc TBC -> C25747, class -> Extended (PCBA type Economic and Standard), stock -> JLCPCB 22,543 (May 2026); D609/D610: class Extended (TBC) -> Extended (badge not shown, treated as Extended), stock text + JLCPCB 5,405 at US$ 0.0317 (25 Sep 2026); unit prices unchanged (0.0006 / 0.0962) | bom_rows.csv | done (integration) |
| 16:59 | R9 round started (unfrozen); reading r9/reviews_r9.md and r9/decisions_r9.md | in progress | - |
| 17:03 | R9 read (E-2 re-arm latch, E-3 large-DC detector lead, E-11 R665, U605 alternate, energies/tests). Plan: E-2 = 74LVC1G74 ARM latch (CLK RELAY_EN, D/CLR = H-OK from spare U606 ch4 via 2N7002) + series AO3400A in the LED return; E-3 = second leg window set +-~0.95 V with C0G ~30 ms filters (2 x TLV1704) into N6_H | in progress | - |
| 17:12 | E-3 filter-type windows rejected (p17/p17b: 1-/2-pole RC cannot separate FS 20 Hz sine onset from 2.14 V DC within 23 ms with the threshold spread); adopting pair-difference level-persistence detector (2 x TLV1704 + timers) | in progress | p17*, p17b* |
| 17:14 | p18: E-3 pair-difference persistence detector: V_L 1.80-2.00 V, T_P 19.05-22.77 ms, FS sine margin 3.5 %, squares mute <= 22.0 Hz (may to 26.2 Hz); worst 27.5 mJ 16 bal / 14.2 mJ 32 bal / 12.8 / 6.4 SE -> L-11 closed. E-2 latch numbers (HREF 2.88-3.11 V, clear <= 0.37 ms, re-arm wait 150 ms) | done | p18_r9_e2e3.py/_out.txt |
| 17:15 | E-3 timer cap C0G +-2 % chosen (sine margin 5.5 %, 32 ohm 13.8 mJ); R_D 15 k. E-11: R665 330 ohm makes U607 swing provable (+141 mV at 4.5 ns, CI bound) but MCLK load 14.7 (typ) / 15.5 pF (CI bound) -> adopt with digital confirmation (p19_r9_e11_out.txt) | done | p18/p19 outputs |
| 17:20 | R9 BOM/netlist (p19): E-2 (U608, Q621, Q622, R690-R695, C630; U606 ch4; Q617 S -> N6_M3) and E-3 (U609/U610, R696-R721, C631-C638, D611/D612) | done | bom_rows.csv, netlist.csv (backups *_ve.csv.bak) |
| 17:23 | E-3 resistors renumbered to R900-R925 (R700+ is block 7; free R6xx are retired); check re-run | done | p19, bom_rows.csv, netlist.csv |
| 17:20 | Loads sent to power/analog (block 6 I+ 2.51 / I- 2.65 mA max; leg loading for analog). U605 alternate NCS3402DR2G noted in BOM | done | bom_rows.csv |
| 17:22 | report.md: new top section 'R9 fixes' (E-2, E-3, E-11, E-14 U605 alternate + C617, designators, bring-up tests) | done | report.md (backup report_od.md.bak) |
| 17:24 | Self-test update for E-3 (a' 0.35 FS old windows 88-150 ms; e) +-0.5 FS E-3 19.8-23.2 ms) added to report; message to digital | done | report.md |
| 17:21 | R9 done: E-2 latch, E-3 detector (L-11 closed: 27.5/13.9 mJ), E-11 pending digital, U605 alternate, C617 50 V, self-test update; check_design clean on protection nets | done | report.md R9, bom_rows.csv, netlist.csv, p17-p19 |
| 17:23 | Parts answered (new parts list, zones, courtyard; NCS3402DR2G accepted with conditions); report R9 table updated | done | report.md |
| 17:24 | Analog: E-3 leg interface sent (taps on LEG_xx, 2 x 1.487 M per leg, VPOS-returned tap sources <= 2.7 uA); report updated | done | report.md |
| 17:26 | E-11 adopted (R665 330 ohm own line + digital layout rule; U607 swing +141 mV at 4.5 ns; load <= 14.23 pF); p10/p19 re-run; digital answered (PB0 only; re-arm >= 150 ms DC_PERMIT_N low, RELAY_EN low >= 1 ms; E-3 no ADC/readback) | done | p10, p19, bom_rows.csv, report.md |
| 17:27 | Report E-2 firmware row aligned with digital (RELAY_EN low >= 1 ms; DC_PERMIT_N low >= 150 ms; PB0 only). check_design: no issues. | done | report.md |
| 17:26 | E-16 (owner): 3V3M from a new 30 V low-IQ LDO -> re-check U605/p10 with 3V3M +-2 % | in progress | - |
| 17:28 | E-16 re-check done: U605 fall 2.991-3.141 V / rise 3.036-3.183 V, margin 51 mV to 3V3A min; suspend 7.7 uA on 3V3M; report R9 row added | done | p10_supervisor_out.txt, report.md |
| 17:29 | Digital E-11 confirmation (14.2 pF no credit, XI >= 5.49 ns) and E-2 firmware §18 (close 540.8 ms, rate change 972 ms) recorded; layout rule sent to parts | done | report.md |
| 17:31 | E-16 with power's TPS70933 range (3.207-3.343 V): U605 fall 2.966-3.119 / rise 3.011-3.161 V, margin 73 mV; +60 mV transient allowance OK; LED current min ~5.26 mA; report updated | done | p10, report.md |
| 17:33 | Analog confirmed E-3 leg loading; TLV3404 level-stage variant evaluated (no max delay spec -> margins typ-based ~4 %), not adopted as default; proposed R509 <= 4.78 k to power; report updated | done | report.md |
| 17:34 | Analog final confirmation of the E-3 interface (pop <= 1.09 mV at 300 ohm through COFF during the VPOS ramp) recorded | done | report.md |
| 17:30 | Follow-up: boot self-test 7.1 s -> <= 3 s (protection owns pass windows) | in progress | - |
| 17:33 | p20: a' at 0.39 FS -> pass 70-140 ms; R <= 209 ms; total 2.84 s (<= 3 s) without hardware change | done | p20_r9_selftest_out.txt |
| 17:35 | Self-test <= 3 s: a' 0.39 FS (pass 70-140 ms), R <= 209 ms, total 2.84 s; sent to digital; report updated | done | report.md, p20_r9_selftest_out.txt |
| 17:36 | Per-test recovery R sent to digital (a' 209, e 207, b 208, c 206 ms); p20 output extended | done | p20_r9_selftest_out.txt |
| 17:37 | E-18 (orchestrator): R509 4.75 k owner-fitted, TLV1704 kept (no variant); report row closed | done | report.md |
| 17:38 | Power asked for <= +0.9 mA at 5V_ANA: not achievable (timer channels need >= 4 mA sink; TLV3404 variant still +1.09 mA); pointed to E-18 (R509 4.75 k) | done | - |
| 17:39 | Power confirmed (TLV1704 kept; R509 4.75 k; G +1.21-1.29 mA; USB Default 493.45 mA) - recorded | done | report.md |
| 17:47 | C_T -> Panasonic ECH-U1H223GX5 PPS film 22 nF +-2 % 1210 accepted (p18 re-run: T_P 19.72-22.37 ms, sine margin 6.0 %, 32 ohm 14.0 mJ, 16 ohm 27.5 mJ); BOM/netlist + report updated | done | p18, p19, bom_rows.csv, report.md |
| 17:53 | Parts blocker: YAGEO RT0402 BRD limited to 240 k -> re-pick 28 parts (0603 stocked 1 M/487 k/300 k; re-scale U605 3V3A dividers to 0402 44.2 k/200 k; E-3 R_T -> 487 k 0603 with V_T divider 33.2 k/187 k 0402) | in progress | - |
| 17:57 | RT0402 range blocker resolved: 0603 RT0603BRD 1 M/487 k/300 k (stocked) + re-scaled 0402 dividers (44.2 k/200 k, 33.2 k/187 k); p10/p18/p19 re-run; U605 margin 73 mV, E-3 T_P 20.0-22.2 ms (sine 8.1 %), 13.9/27.5 mJ; report updated | done | p10, p18, p19, bom_rows.csv, netlist.csv, report.md |
| 18:01 | Parts: C_T reflow confirmed (global sourcing, owner-fit fallback) recorded; RT0402 decision re-sent (crossed messages) | done | report.md |
| 18:08 | BOM C-numbers/class for re-picked resistors (44.2 k C705633 Ext; 200 k/187 k/33.2 k global; UNI-ROYAL TC0225 33.2 k approved alternate); check_design clean; report updated | done | p19, bom_rows.csv, report.md |
| 18:10 | R601-R604 datasheet_url fixed (C25747); parts will order the UNI-ROYAL TC0225 alternate for R924 after integration adds the decode pattern (info) | done | p19, bom_rows.csv |
| 19:10 | R9 check fixes started (E-22..E-26); reading r9/review_r9_check.md and decisions_r9.md | in progress | - |
| 19:15 | E-24/E-22 redesign: NPN reset switch (MMBT3904 x4) replaces R_D + clamp diodes (D611/D612 deleted); R_T 110 k, C_T 220 nF PPS 2 %, V_T 69.8 k/100 k; p18: T_P 19.50-23.23 ms incl. 1 uA leakage, sine margin 5.8 %, 32 ohm 14.5 mJ (4 %), 16 ohm 27.5 mJ (8 %) | done | p18 |
| 19:17 | BOM/netlist (p19): D611/D612 deleted; Q623-Q626 MMBT3904 NPN reset switches; R916-R919 -> 330 k base pull-ups; R920-R923 110 k; C631-C634 220 nF PPS 2 %; R924 69.8 k / R925 100 k; level inputs swapped; R696 Q622 gate pull-down (E-23); check_design clean | done | p19, bom_rows.csv, netlist.csv |
| 19:19 | report.md: 'R9 check fixes' subsection added (E-22/E-23/E-24/E-26, self-test coverage, production test, parts list) | done | report.md |
| 19:20 | R9 section header note: superseded parts/numbers pointer | done | report.md |
| 19:22 | Parts told (new/changed/deleted parts); power told (block 6 I+ 2.66 / I- 2.48 mA, 5V_ANA -0.03 mA). R9 check fixes done. | done | - |
| 19:26 | Parts selections applied: C631-C634 ECH-U1H224GX9 (2416, global), R920-R923 C705063 Ext, R924 C852893 global (+Vishay alt), R916-R919 merged into the R660 C25778 Extended line; check clean; report updated | done | p19, bom_rows.csv, report.md |
| 20:07 | orchestrator final consistency pass (integration, text only) | R665: lcsc 'C25104 (to confirm)' -> C25104, class TBC -> Basic, stock 'not verified (R9)' -> 'LCSC 639,200 (parts, 25 Sep 2026); same part as R228–R230/R242–R246'; unit price unchanged | bom_rows.csv | done (integration) |
| 20:19 | Text-only fixes in report.md (CHK-06 stale tests, U606 ch4 spare text) started | in progress | - |
| 20:24 | report.md text fixes: E-2 bring-up list corrected (1/3/10 ms, superseded note), square 21.0 Hz trip / 26 Hz no trip, E-3 2.10 V timing 19.5-23.2 ms, self-test e) 19.5-25.1 ms, U606 ch4 superseded marks (2 places), pre-check E-3 rows and 'Not verified' marked superseded | done | report.md (backup report_r9chk_text.md.bak) |
