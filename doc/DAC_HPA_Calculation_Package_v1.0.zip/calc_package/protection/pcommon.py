"""pcommon - shared operating conditions and datasheet numbers for the protection-stream scripts.

Labels: [DS] datasheet min/max, [DS-typ] typical only, [ASSUMP] assumption, [BRIEF] brief Section 5/6.
"""
import numpy as np

# ---- operating conditions [BRIEF 5] -------------------------------------------------
VPOS_MIN, VPOS_NOM, VPOS_MAX = 3.789, 3.900, 4.014       # V+ rail
VNEG_MIN, VNEG_NOM, VNEG_MAX = 3.618, 3.722, 3.828       # |V-| rail magnitude
V5SYS_MIN, V5SYS_MAX = 4.30, 5.50                        # 5V_SYS range for the switch drive [BRIEF 7.2, D-1]
V5SYS_CLAMP = 5.55                                       # TPS25200 output clamp maximum [power stream DS SLVSCJ0F 5.5]
V3V3_MIN, V3V3_MAX = 3.234, 3.366                        # 3V3M / 3V3A (+-2 %) [Notes 3.6]
TAMB_MIN, TAMB_MAX = 0.0, 50.0
T_LOCAL_MAX = 60.0            # [ASSUMP] local board ambient at the protection parts (50 C + 10 K board rise)

# ---- output level ----------------------------------------------------------------
A_FS = 2.19 * 10 ** (0.15 / 20)   # full-scale sine peak per leg after calibration, +0.1 dB cal + 0.05 dB trim
A_FS_UNTRIM = 3.66                # untrimmed highest-gain unit at 0 dBFS (swing-limited) - only if the -4.5 dB safety fails

# ---- output switch K601-K604: Toshiba TLP3545A(TP1,F) photorelay (decision D-1, round 2) ----------------
# Toshiba TLP3545A/TLP3545AF datasheet EN 2023-05-24 (toshiba.semicon-storage.com, did=60318), sections 8-15,
# Ta = 25 C unless noted [DS]; curves (section 16.1) are typical only ("not guaranteed by production test").
SW_PART = 'Toshiba TLP3545A(TP1,F)'
SW_RON_MAX_25 = 0.060          # ohm, A connection, ION = 3 A, IF = 5 mA, t < 1 s [DS 13]
SW_RON_TYP_25 = 0.035          # [DS-typ]
SW_RON_TC = 1.35               # [ASSUMP] factor 25 C -> 60 C on the max (Fig. 16.1.5 RON-Ta is typical only)
SW_TOFF_MAX_25 = 0.5e-3        # s, IF = 5 mA and IF = 10 mA, RL 200 ohm, VDD 20 V [DS 15]
SW_TOFF_DESIGN = 1.0e-3        # [ASSUMP] 2 x the 25 C maximum for 0-60 C (Fig. 16.1.8 tON/tOFF-Ta is typical only)
SW_TON_MAX = 5.0e-3            # s, IF = 5 mA [DS 15] (3 ms max at IF = 10 mA)
SW_TON_DESIGN = 10.0e-3        # [ASSUMP] 2 x the 25 C maximum for 0-60 C -> firmware wait before the volume ramp
SW_IFT_MAX = 3.0e-3            # trigger LED current max (ION = 1 A) [DS 13]; typ 0.3 mA
SW_IFC_MIN = 0.01e-3           # return LED current min (IOFF = 10 uA) [DS 13]: every unit is off once IF <= 10 uA
SW_IF_REC = (5e-3, 10e-3, 25e-3)   # recommended IF min/typ/max [DS 9]
SW_IF_ABS, SW_IF_DERATE = 30e-3, 0.3e-3    # A, A/K above 25 C [DS 8]
SW_PD_ABS, SW_PD_DERATE = 50e-3, 0.5e-3    # LED power, W, W/K above 25 C [DS 8]
SW_VR_ABS = 6.0                # LED reverse voltage [DS 8] (AQV251GA second source: 5 V)
SW_ION_ABS, SW_ION_DERATE = 4.0, 40e-3     # A connection, A, A/K above 25 C [DS 8]
SW_PO_ABS, SW_PO_DERATE = 0.700, 7e-3      # output power, W, W/K above 25 C [DS 8]
SW_VOFF_ABS = 60.0             # [DS 8]
SW_VF_MIN_10, SW_VF_TYP_10, SW_VF_MAX_10 = 1.50, 1.64, 1.80   # V at IF = 10 mA, 25 C [DS 12]
SW_VF_TC = -2.2e-3             # V/K bound [ASSUMP; GaAs IRED typically -1.5...-2 mV/K; Fig. 16.1.3 is typical only]
SW_VF_MAX_COLD = SW_VF_MAX_10 - SW_VF_TC * (25.0 - TAMB_MIN)  # 1.855 V: bound for any IF <= 10 mA at 0 C
# (VF rises monotonically with IF, so the 10 mA maximum bounds every IF <= 10 mA - physics, not a datasheet line)
SW_ILEAK_TYP = 0.01e-6         # IOFF at VOFF = 60 V [DS-typ]; the max cell is not legible in either extraction
SW_ILEAK_BOUND = 1e-6          # [ASSUMP] design bound (the AQV251GA second source guarantees 1 uA max)
SW_COUT_TYP = 640e-12          # COFF at 0 V, 1 MHz [DS-typ]; falls with VOFF (Fig. 16.1.11) -> 0 V value used as bound
SW_COUT_BOUND = 1.5 * SW_COUT_TYP  # [ASSUMP] allowance for the missing maximum, used for coupling bounds
# Panasonic AQV251GA(X) - conditional second source only (JLCPCB Standard-PCBA reflow peak <= 250 C must be confirmed)
AQV_RON_MAX_25, AQV_VF_MAX_5mA, AQV_VR_ABS, AQV_IFON_MAX = 0.08, 1.50, 5.0, 3.0e-3   # [DS Panasonic ASCTB144E]
# legacy names used by the round-1 scripts (now pointing at the TLP3545A values)
AQV_TOFF_DESIGN = SW_TOFF_DESIGN
AQV_TON_MAX = SW_TON_MAX
AQV_ILEAK_MAX = SW_ILEAK_BOUND
AQV_COUT_TYP = SW_COUT_TYP

# ---- loads ---------------------------------------------------------------------------
LOADS = [16.0, 32.0, 60.0, 300.0]
E_LIMIT = {16.0: 30e-3, 32.0: 15e-3}       # [BRIEF 4]

# OPA1622 short-circuit current, SBOS727B table 6.5: +145 / -130 mA typ at +-18 V, 25 C [DS-typ]; no maximum given.
ISC_SRC_TYP, ISC_SNK_TYP = 0.145, 0.130
ISC_BOUND = 0.190              # [ASSUMP] upper bound used for energies: typ x 1.3 (Fig. 37 rises towards low temperature)
HEADROOM_NOLOAD = 0.80         # OPA1622 swing from rail, no load, typ [DS-typ table 6.5]
ROUT_SWING = 8.0               # ohm, swing drop per ampere (Notes 3.5.2, TI Fig. 38/39) [DS-typ]


def leg_dc_max(x_req, r_leg_equiv, rail):
    """Largest DC a healthy OPA1622 leg can hold when asked for x_req into an effective
    load r_leg_equiv (ohm, per leg), bounded by swing (typ) and the current bound."""
    v_swing = (rail - HEADROOM_NOLOAD) / (1.0 + ROUT_SWING / r_leg_equiv)
    v_ilim = ISC_BOUND * r_leg_equiv
    return min(abs(x_req), v_swing, v_ilim)


def fmt(x, n=3):
    return f'{x:.{n}g}'
