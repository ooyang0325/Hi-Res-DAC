# Calculation package — v1.0 USB DAC + balanced headphone amplifier (R9 final, 25 Sep 2026)

Reproducible calculations behind the design documents (decisions_r9 E-15). Every path below is relative to this folder; run the commands from this folder with Python 3 (numpy/scipy where a script imports them). Scripts write their outputs next to themselves (or to `out/`), so a run overwrites the packaged output with a fresh copy — compare with `git diff` or a copy.

**Not included (external sources):** datasheet PDFs and their text extracts, web caches and quote files (`ds/*.txt`, `web/`, `sources/`); scripts that digitise datasheet figures read `external/input/<file>.pdf`, which is not shipped — their derived data (`analog/ds/*.json`) is included, so every downstream script runs without the PDFs.

## Key claims

| Claim | Script(s) | Output(s) | Run (from the package root) |
|---|---|---|---|
| Hold-up at every hard unplug: I/V supply outlives 3V3A in 1,944 corners (X-8; VE 176 uF case) | `analog/scripts/unplug_model_r3.py` | `analog/out/unplug_model_r3.txt` | `cd analog/scripts && python3 unplug_model_r3.py` |
| Hard-unplug rail ordering, brown-out action before the MCU reset (288 corners) | `power/calc/c14_unplug_order.py` | `power/calc/c14_unplug_order.out.txt` | `cd power/calc && python3 c14_unplug_order.py` |
| Leg stability with the output switch (37 load cases x 4 models; PM >= 51.3 deg) | `analog/scripts/stability_switch.py` | `analog/out/stability_switch.txt` | `cd analog/scripts && python3 stability_switch.py` |
| I/V stability with the CM-summing load (1,080 corners) | `analog/scripts/stability_iv.py` | `analog/out/stability_iv.txt` | `cd analog/scripts && python3 stability_iv.py` |
| Leg stability sweeps (T network, lead capacitor, final) | `analog/scripts/stability_legs.py; stability_legs_T.py; stability_legs_T2.py; stability_legs_lead.py; stability_final.py` | `analog/out/stability_legs*.txt; analog/out/stability_final.txt` | `cd analog/scripts && python3 stability_final.py` |
| OPA1622 macro-model calibration to the datasheet curves | `analog/scripts/calibrate_opa1622.py; validate_opa1622.py` | `analog/out/calibrate_opa1622.txt; analog/out/validate_opa1622.txt; analog/ds/opa1622_calibrated.json` | `cd analog/scripts && python3 calibrate_opa1622.py` |
| DC offset budget 0-50 C (9.23 / 18.45 mV; screen 7.19 / 14.39 mV), levels, swing, reset state | `analog/scripts/analog_budget.py` | `analog/out/analog_budget.txt; analog/out/offset_budget.csv` | `cd analog/scripts && python3 analog_budget.py` |
| Output power tables and LM27762 headroom (Default/High) | `analog/scripts/r2_power.py` | `analog/out/r2_power.txt; analog/out/power_table.csv; analog/out/headroom_table.csv` | `cd analog/scripts && python3 r2_power.py` |
| Pop bounds (power-up 4.70 mV, power-down ramp) | `analog/scripts/dac_timing_pop.py` | `analog/out/dac_timing_pop.txt` | `cd analog/scripts && python3 dac_timing_pop.py` |
| DAC-pin safety / clamp bounds | `analog/scripts/dac_pin_safety.py` | `analog/out/dac_pin_safety.txt` | `cd analog/scripts && python3 dac_pin_safety.py` |
| Switch THD/Zout/crosstalk bounds | `analog/scripts/r2_switch.py; protection/p01_switch_choice.py` | `analog/out/r2_switch.txt; protection/p01_switch_choice_out.txt` | `cd analog/scripts && python3 r2_switch.py` |
| Round-3 / R9 analog fixes (X-8 headroom, R305, trims, bead alternate) | `analog/scripts/r3_fixes.py; r9_fixes.py` | `analog/out/r3_fixes.txt; analog/out/r9_fixes.txt` | `cd analog/scripts && python3 r3_fixes.py` |
| Plug/adapter isolation 24/24 cases (four-leg switch) | `protection/p02_connection_cases.py` | `protection/p02_connection_cases_out.txt` | `cd protection && python3 p02_connection_cases.py` |
| Leg DC windows: thresholds, removal times, energies, false-trip corners (X-9 aged C) | `protection/p03_detector.py; p03b_threshold_scan.py; p11_x9_filter.py` | `protection/p03_detector_out.txt; p03b_threshold_scan_out.txt; p11_x9_filter_out.txt` | `cd protection && python3 p03_detector.py` |
| I/V common-mode window (band, margins, stuck-pin coverage, CM-path energies) | `protection/p04_cm_monitor.py` | `protection/p04_cm_monitor_out.txt` | `cd protection && python3 p04_cm_monitor.py` |
| Photorelay drive, permit node H, switch open/close times | `protection/p05_switch_drive.py` | `protection/p05_switch_drive_out.txt` | `cd protection && python3 p05_switch_drive.py` |
| DC-sense networks, firmware tiers T1-T3, combined energy envelope | `protection/p06_dcsense_tiers.py` | `protection/p06_dcsense_tiers_out.txt` | `cd protection && python3 p06_dcsense_tiers.py` |
| Stream-guard proofs (round 3 rule and OD-1 rules P1-P4; energies 13.8 / 25.3 mJ; no-false-trigger boundary) | `protection/p07_stream_guard.py; p15_od_guard.py; p16_od_p2_scan.py; p16b_od_p4_scan.py` | `protection/p07_stream_guard_out.txt; p15_od_guard_out.txt; p16_od_p2_scan_out.txt; p16b_od_p4_scan_out.txt` | `cd protection && python3 p15_od_guard.py` |
| ADC2 sampling (settling, charge sharing) for the sense channels | `protection/p09_adc_sampling.py` | `protection/p09_adc_sampling_out.txt` | `cd protection && python3 p09_adc_sampling.py` |
| DAC-supply / MCLK supervisor, frozen-code removal, boot self-test windows | `protection/p10_supervisor.py` | `protection/p10_supervisor_out.txt` | `cd protection && python3 p10_supervisor.py` |
| R9 E-3 filter-type windows (rejected): 1- and 2-pole RC cannot separate a FS 20 Hz sine from 2.14 V DC in 23 ms | `protection/p17_r9_e3.py; p17b_r9_e3_2pole.py` | `protection/p17_r9_e3_out.txt; p17b_r9_e3_2pole_out.txt` | `cd protection && python3 p17_r9_e3.py` |
| R9 E-2 re-arm latch (R696, single-fault coverage) and E-3 pair-difference persistence detector after the R9 check (NPN reset, R_T 110 k, C_T 220 nF): T_P 19.5-23.2 ms incl. leakage, sine 5.8 %, squares 21.5/25.6 Hz, worst 27.5 / 14.5 mJ, L-11 closed; U605 with the TPS70933 3V3M | `protection/p18_r9_e2e3.py; p10_supervisor.py` | `protection/p18_r9_e2e3_out.txt; p10_supervisor_out.txt` | `cd protection && python3 p18_r9_e2e3.py` |
| R9 BOM/netlist of the new protection circuits, R665 330 ohm check (E-11), self-test windows | `protection/p19_r9_bom.py` | `protection/p19_r9_bom_out.txt; p19_r9_e11_out.txt; p20_r9_selftest_out.txt` | `cd protection && python3 p19_r9_bom.py` |
| R9 power: E-1 value texts, E-7 OVCSEL, E-8 reverse bias, brown-out margin (c21); E-16 suspend power cut: TPS70933, Q507, attach A 29.6 / B 20.1 uC, S6 2.2755 mA (c22) | `power/calc/c21_r9_checks.py; c22_e16_suspend_cut.py` | `power/calc/c21_r9_checks.out.txt; c22_e16_suspend_cut.out.txt` | `cd power/calc && python3 c22_e16_suspend_cut.py` |
| R9 analog: E-4 offset split (5.61 / 11.21 mV G; 7.73 / 15.47 mV with DAC terms), E-8, E-3 tap checks, E-6 need 178.81 mA | `analog/scripts/r9_fixes.py; analog_budget.py` | `analog/out/r9_fixes.txt; analog/out/analog_budget.txt` | `cd analog/scripts && python3 r9_fixes.py` |
| R9 digital: canonical power-down order (section 15), CPLD engine reset (16), suspend pin states (17), E-2 firmware re-arm (18), suspend <= 8.45 ms, TSIGATT <= 23.9 ms | `digital/firmware_sequences.py` | `digital/firmware_sequences_output.txt` | `cd digital && python3 firmware_sequences.py` |
| USB states S1-S6, U503 limits (IOS 177.9 mA vs need 176.97 mA), Default total 490.80 mA | `power/calc/c17_budget_r3.py; c03_usb_budget_ilim.py` | `power/calc/c17_budget_r3.out.txt; c03_usb_budget_ilim.out.txt` | `cd power/calc && python3 c17_budget_r3.py` |
| Attach inrush regions (USB-IF #45), C104 delay | `power/calc/c02_attach_inrush.py; c16_r3_review_fixes.py` | `power/calc/c02_attach_inrush.out.txt; c16_r3_review_fixes.out.txt` | `cd power/calc && python3 c16_r3_review_fixes.py` |
| VBUS hard-short kick with D102, U102 IOS with R108 100 k, EN delay with R109 470 k, ANA_SENSE divider | `power/calc/c16_r3_review_fixes.py; c20_ve_checks.py; c21_r9_checks.py` | `power/calc/c16_r3_review_fixes.out.txt; c20_ve_checks.out.txt; c21_r9_checks.out.txt` | `cd power/calc && python3 c20_ve_checks.py` |
| Rail start-up with the X-8 reservoirs (rails good <= 18.8 ms; T_START 40 ms) | `power/calc/c18_x8_rail_start.py` | `power/calc/c18_x8_rail_start.out.txt` | `cd power/calc && python3 c18_x8_rail_start.py` |
| Discharge times (3V3A 0.385 ms, 3V3D 0.63 ms, 1V3 0.134 ms) | `power/calc/c06_discharge.py` | `power/calc/c06_discharge.out.txt` | `cd power/calc && python3 c06_discharge.py` |
| Regulator margins, thermal table, VBUS sense band, LM27762 envelopes | `power/calc/c04_regulators.py; c10_thermal.py; c09_vbus_sense.py; c15_lm27762_headroom.py` | `power/calc/c04_regulators.out.txt; c10_thermal.out.txt; c09_vbus_sense.out.txt; c15_lm27762_headroom.out.txt` | `cd power/calc && python3 c10_thermal.py` |
| Clock timing (I2S setup/hold, link timing with U208, MCLK/FSR, jitter) | `digital/clock_timing.py` | `digital/clock_timing_output.txt` | `cd digital && python3 clock_timing.py` |
| Firmware sequences: suspend <= 8.50 ms, power-up, rate/family change, IWDG, guards, OD-2 check | `digital/firmware_sequences.py` | `digital/firmware_sequences_output.txt` | `cd digital && python3 firmware_sequences.py` |
| ADC configuration (dual mode, TS 41.5, 20 kHz, CC classes, ANA_SENSE) | `digital/adc_settings.py` | `digital/adc_settings_output.txt` | `cd digital && python3 adc_settings.py` |
| Digital currents, levels/pull-ups, MCLK gate race, USB feedback values | `digital/currents.py; levels_and_pullups.py; mclk_gate_race.py; usb_feedback.py` | `digital/currents_output.txt; levels_and_pullups_output.txt; mclk_gate_race_output.txt; usb_feedback_output.txt` | `cd digital && python3 usb_feedback.py > usb_feedback_output.txt` |
| Component stress table (FAIL 0) | `parts/stress_calc.py` | `parts/stress_table.csv; parts/stress_calc_out.txt` | `cd parts && python3 stress_calc.py` |
| PCBA class / ordering plan, VE cost model, placement density, value decode (parts) | `parts/pcba_class_scan.py; ve_cost_model.py; placement_density.py; value_decode_check.py` | `parts/pcba_class_scan_out.txt; ve_cost_model_out.txt` | `cd parts && python3 pcba_class_scan.py` |
| USB 90 ohm differential pair geometry (field solver) | `parts/usb_diffpair_impedance.py` | `parts/usb_impedance_out.txt; usb_impedance_out.json` | `cd parts && python3 usb_diffpair_impedance.py` |
| Netlist/BOM consistency incl. the value-decodes-from-MPN check (E-1) | `integration/check_design.py; integration/tests/test_value_decode.py` | `integration/check_result.json` | `python3 integration/check_design.py power protection analog digital` |
| Merged BOM/netlist, changes vs v0.6, cost report (VE basis) | `integration/build_package.py; build_changes.py; cost_calc.py` | `integration/bom_merged.csv; netlist_merged.csv; bom_changes_vs_v06.csv; bom_changes_vs_v09.csv; cost_report.md` | `cd integration && python3 build_package.py && python3 build_changes.py && python3 cost_calc.py` |
| Traceability and evidence register (G/E/Q classes) | `integration/build_evidence_register.py` | `integration/traceability.csv; integration/evidence_register.csv` | `cd integration && python3 build_evidence_register.py` |

## Folder map

| Folder | Content |
|---|---|
| `power/` | power stream report, BOM/netlist, `calc/` scripts `cNN_*.py` with `.out.txt` / `*_results.json` |
| `protection/` | protection report, BOM/netlist, scripts `pNN_*.py` with `*_out.txt` |
| `analog/` | analog report, BOM/netlist, `scripts/` (models, sweeps) with `out/`, derived curve data `ds/*.json` |
| `digital/` | digital report, BOM/netlist, scripts with `*_output.txt` |
| `parts/` | parts report, layout package, stress and PCBA tables, cost/placement scripts |
| `integration/` | checker, merge/cost/evidence scripts, merged BOM/netlist, traceability, evidence register, summary, decisions; `tests/` E-1 self-tests |
| `current/` | Parts List v0.6 CSV (input of the change list) |
| `r9/` | R9 reviews and decisions (inputs of this round) |

## Index check

Every script and output named above is present in the package.
