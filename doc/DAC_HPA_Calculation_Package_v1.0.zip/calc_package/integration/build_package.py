import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""R8 / v0.9 integration: merge the four stream netlists and BOMs, cross-check them, diff against Parts List v0.6.

Outputs (integration folder): netlist_merged.csv, nets_summary.csv, bom_merged.csv, bom_changes_vs_v06.csv,
build_package_out.txt (checks and totals).  Inputs are read-only: <stream>/netlist.csv, <stream>/bom_rows.csv,
current/parts_list_current.csv.
"""
import csv, re, collections, json, os

BASE = _PKG_ROOT + ''
OUT = f'{BASE}/integration'
STREAMS = ['power', 'protection', 'analog', 'digital']

BLOCKS = {
    '1': '1 USB-C input, OVP and sensing',
    '2': '2 USB audio bridge (CH32V307 + AGRV2K CPLD + clocks)',
    '3': '3 DAC (ES9018K2M) and its supplies',
    '4': '4 I/V converters and output legs',
    '5': '5 Power: domains, current limit, +-3.8 V rails, discharge',
    '6': '6 Protection and output switch',
    '7': '7 Outputs, indicators, test',
    '8': '8 PCB and layout items (no part)',
}

# retired designators (never reused) collected from the stream reports and decisions (D-11, brief 3.7)
RETIRED = """D103 D611 D612 R233 R506 R507 R519 R520 R521 R524 R525 R307 R514 R515 R516 R517 R518 R523 C503 C504 Q501
Q601 Q602 Q603 Q604 Q605 Q606 Q607 Q608 Q609 Q610 Q611 R611 R612 R613 R614 R615 R616 R617 R618 R623 R636 R637 R638
C605 C606 C607 D605 D606 Q613 Q615 R664
R306 R308 R421 R427 R428 R429 R430 R433 R434 R435 R436 R437 C427 C428 C429 C430
R214 C216""".split()


def natkey(ref):
    m = re.match(r'^([A-Z]+)(\d+)(.*)$', ref)
    return (m.group(1), int(m.group(2)), m.group(3)) if m else (ref, 0, '')


def pinkey(p):
    m = re.match(r'^(\d+)(.*)$', p)
    return (0, int(m.group(1)), m.group(2)) if m else (1, 0, p)


def expand(refs):
    out = []
    for tok in re.split(r'\s*,\s*', refs.strip()):
        tok = tok.strip()
        if not tok:
            continue
        m = re.match(r'^([A-Z]+)(\d+)\s*[\u2013\-]\s*([A-Z]*)(\d+)$', tok)
        if m:
            p, a, _, b = m.groups()
            out += ['%s%d' % (p, i) for i in range(int(a), int(b) + 1)]
        else:
            out.append(tok)
    return out


def compress(refs):
    """R401, R402, R403 -> R401-R403 (only runs of >= 3 consecutive numbers of the same prefix)."""
    refs = sorted(set(refs), key=natkey)
    out, i = [], 0
    while i < len(refs):
        p, n, s = natkey(refs[i])
        j = i
        while j + 1 < len(refs):
            p2, n2, s2 = natkey(refs[j + 1])
            if p2 == p and n2 == natkey(refs[j])[1] + 1 and not s and not s2:
                j += 1
            else:
                break
        if j - i >= 2:
            out.append(f'{refs[i]}-{refs[j]}')
        else:
            out += refs[i:j + 1]
        i = j + 1
    return ', '.join(out)


def load(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


log = []


TP_PADS = [('TP701', '5V_SYS'), ('TP702', '5V_ANA'), ('TP703', '3V3M'), ('TP704', '3V3D'), ('TP705', '3V3A'),
           ('TP706', '1V3'), ('TP707', 'VPOS'), ('TP708', 'VNEG'), ('TP709', 'VREF'), ('TP710', 'AVCC_L'),
           ('TP711', 'MCLK'), ('TP712', 'FAM_CLK'), ('TP713', 'OSC48_EN'), ('TP714', 'OSC44_EN'), ('TP715', 'BCLK'),
           ('TP716', 'LRCLK'), ('TP717', 'SDATA'), ('TP718', 'RELAY_EN'), ('TP719', 'N2_AVCC_EN_G'), ('TP720', 'AVCC_EN'),
           ('TP721', 'RAILS_OK_N'), ('TP722', 'DC_PERMIT_N'), ('TP723', 'ANA_FAULT_N'), ('TP724', 'N6_H'),
           ('TP725', 'VBUS_SENSE'), ('TP726', 'CC1'), ('TP727', 'CC2'), ('TP728', 'GND'), ('TP729', 'GND'),
           ('TP730', 'GND'), ('TP731', 'GND'), ('TP733', 'N6_CML'), ('TP734', 'N6_CMR'), ('TP735', 'N2_MCLK_OE'),
           ('TP736', 'VBUS'), ('TP737', 'ANA_EN'), ('TP738', 'AUD_EN'), ('TP739', 'ILIM_HI'), ('TP740', 'MCLK_EN'),
           ('TP741', 'GND'), ('TP742', 'GND'), ('TP743', 'N6_EL'), ('TP744', 'N6_ER'), ('TP745', 'N6_EM'),
           ('TP746', 'DAC_RESETB'), ('TP747', 'N6_MCK_RC'), ('TP748', 'N6_V3AG_A'), ('TP749', 'N6_V3AG_B'),
           ('TP750', 'N4_VPOS_IV'), ('TP751', 'N4_VNEG_IV'), ('TP752', 'ANA_SENSE'), ('TP753', 'VBUS')]

C103_OVERRIDE = dict(description='VBUS_SENSE ADC input capacitor at PA1 (tau 3.2 us; RF filtering) - decision D-A: 100 pF C0G fitted',
                     value='100 pF', rating_tolerance='50 V C0G +-5 %', mpn='Samsung CL05C101JB5NNNC', lcsc='C1546',
                     jlcpcb_class='Basic', stock_or_sourcing='JLCPCB Basic part [ASSUMP: confirm stock at order]',
                     unit_price_usd=0.0012, datasheet_url='https://www.lcsc.com/product-detail/C1546.html',
                     note='Decision D-A (orchestrator, 25 Sep 2026): 100 pF C0G 50 V 0402 fitted instead of the D-13 10 nF - brown-out '
                          'action 0.05-0.12 ms after source loss in 96/96 power c14 corners; digital TS 41.5 cycles covers the 32 kOhm '
                          'source (43.5 kOhm allowed). Integration override: the frozen power bom_rows.csv still lists 10 nF CL05B103KB5NNNC (C15195).')


def say(*a):
    s = ' '.join(str(x) for x in a)
    log.append(s)
    print(s)


def main():
    global log
    # ---------------------------------------------------------------- netlist
    pins = []
    for s in STREAMS:
        for r in load(f'{BASE}/{s}/netlist.csv'):
            pins.append(dict(refdes=r['refdes'].strip(), pin=r['pin'].strip(), pin_name=r['pin_name'].strip(),
                             net=r['net'].strip(), note=r['note'].strip(), stream=s))
    # integration override D-A (orchestrator, 25 Sep): C103 = 100 pF C0G 50 V 0402 fitted (stream files frozen at 10 nF)
    for r in pins:
        if r['refdes'] == 'U201' and 'C103 10 nF' in r['note']:
            r['note'] = r['note'].replace('C103 10 nF (power)', 'C103 100 pF C0G (power; decision D-A, integration override)')
    # integration action A-1: the 44 layout-allocated test pads (layout_package.md section 11) as 1-pin pads
    stream_nets = {r['net'] for r in pins}
    tp_missing = []
    for tp, net in TP_PADS:
        if net not in stream_nets:
            tp_missing.append(f'{tp}={net}')
        pins.append(dict(refdes=tp, pin='1', pin_name='TP', net=net,
                         note='test pad, 1.0 mm round on L1, mask open, no paste (layout_package.md section 11; action A-1)',
                         stream='integration (A-1)'))
    pins.sort(key=lambda r: (natkey(r['refdes']), pinkey(r['pin'])))
    with open(f'{OUT}/netlist_merged.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['refdes', 'pin', 'pin_name', 'net', 'note', 'stream'])
        w.writeheader()
        w.writerows(pins)

    IFACE = set("""VBUS 5V_SYS GND 3V3M 3V3D 1V3 3V3A 5V_ANA 5V_ANA_F VPOS VNEG USB_DP USB_DN CC1 CC2 CC1_ADC CC2_ADC VBUS_SENSE
AUD_EN AVCC_EN ANA_EN ILIM_HI ANA_SENSE N2_AVCC_EN_G RELAY_EN DAC_RESETB LED_G LED_R RAILS_OK_N ANA_FAULT_N DC_PERMIT_N CPLD_IRQ
DAC_LOCK LRCLK_FB PROG DC_SENSE_LP DC_SENSE_LN DC_SENSE_RP DC_SENSE_RN V3A_MON LINK_SCK LINK_MOSI LINK_MISO LINK_FRAME I2C_SCL I2C_SDA
SWDIO SWCLK NRST BOOT0 USART_TX USART_RX CPLD_JTMS CPLD_JTCK CPLD_NRST MCLK MCLK_EN FAM_CLK OSC48_EN OSC44_EN BCLK LRCLK SDATA
DACL DACLB DACR DACRB VREF AVCC_L AVCC_R VCCA DVCC LEG_LP LEG_LN LEG_RP LEG_RN JACK_LP JACK_RP JACK_LN JACK_RN""".split())

    nets = collections.OrderedDict()
    for r in pins:
        nets.setdefault(r['net'], []).append(r)
    rows = []
    for net in sorted(nets, key=lambda n: (n == 'NC', not n in IFACE, n)):
        members = nets[net]
        rows.append(dict(net=net, pin_count=len(members),
                         members=' '.join(f"{m['refdes']}.{m['pin']}" for m in members),
                         streams='+'.join(sorted({m['stream'] for m in members})),
                         net_class='interface (brief 5)' if net in IFACE else ('no-connect pins (each isolated)' if net == 'NC' else 'block-internal')))
    with open(f'{OUT}/nets_summary.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['net', 'pin_count', 'members', 'streams', 'net_class'])
        w.writeheader()
        w.writerows(rows)

    refs_net = collections.OrderedDict()
    dup_pin = []
    for r in pins:
        d = refs_net.setdefault(r['refdes'], {})
        if r['pin'] in d:
            dup_pin.append(f"{r['refdes']}.{r['pin']}")
        d[r['pin']] = r['net']
    single = [n for n, m in nets.items() if n != 'NC' and len(m) < 2]
    say('NETLIST: pin rows', len(pins), '| parts', len(refs_net), '| nets', len(nets), '(incl. NC)',
        '| interface nets present', len([n for n in IFACE if n in nets]), 'of', len(IFACE),
        '| NC pins', len(nets.get('NC', [])), '| duplicate pins', len(dup_pin), '| single-pin nets', single)
    missing_iface = sorted(n for n in IFACE if n not in nets)
    say('  interface nets absent:', missing_iface or 'none')
    for s in STREAMS:
        say(f'  {s}: {sum(1 for r in pins if r["stream"] == s)} pin rows, {len({r["refdes"] for r in pins if r["stream"] == s})} parts')

    # ---------------------------------------------------------------- BOM
    COLS = ['block', 'refs', 'qty_per_board', 'description', 'value', 'package', 'rating_tolerance', 'mpn', 'lcsc',
            'jlcpcb_class', 'stock_or_sourcing', 'fit', 'leadless', 'smt_pins_per_part', 'tht_pins_per_part',
            'unit_price_usd', 'datasheet_url', 'note', 'stream']
    bom = []
    ref_owner = {}
    dup_ref = []
    for s in STREAMS:
        for r in load(f'{BASE}/{s}/bom_rows.csv'):
            blk = r['block'].strip()[0]
            refs = expand(r['refs'])
            for d in refs:
                if d in ref_owner:
                    dup_ref.append(f'{d} ({ref_owner[d]} and {s})')
                ref_owner[d] = s
            if int(float(r['qty'])) != len(refs):
                say(f'  QTY MISMATCH {s} {r["refs"]}: qty {r["qty"]} vs {len(refs)} refs')
            bom.append(dict(block=BLOCKS[blk], refs=compress(refs), qty_per_board=len(refs), description=r['desc'],
                            value=r['value'], package=r['package'], rating_tolerance=r['rating_tolerance'], mpn=r['mpn'],
                            lcsc=r['lcsc'], jlcpcb_class=r['jlcpcb_class'], stock_or_sourcing=r['jlcpcb_stock_or_sourcing'],
                            fit=r['fit'].strip(), leadless=r['leadless'].strip(), smt_pins_per_part=int(float(r['smt_pins_per_part'] or 0)),
                            tht_pins_per_part=int(float(r['tht_pins_per_part'] or 0)), unit_price_usd=float(r['unit_price_usd'] or 0),
                            datasheet_url=r['datasheet_url'], note=r['note'], stream=s, _refs=refs))
    for r in bom:
        if r['_refs'] == ['C103'] and r['value'].strip() != '100 pF':
            r.update(C103_OVERRIDE)   # not needed since round 3 (stream BOM = 100 pF C0G); kept as a guard
    bom.sort(key=lambda r: (r['block'], natkey(r['_refs'][0])))

    # layout-only items (no part, not in any stream netlist): layout_package.md sections 5, 11, 12
    tp_layout = [f'TP{n}' for n in range(701, 754) if n != 732]
    extra = [
        dict(block=BLOCKS['8'], refs=compress(tp_layout), qty_per_board=len(tp_layout),
             description='Test pads, 1.0 mm round on L1, mask open, no paste (layout_package.md section 11 allocation); TP732 (PROG) is a netlisted digital-stream pad; TP746-TP753 and the TP719 re-use added in round 3',
             value='-', package='pad', rating_tolerance='-', mpn='No part', lcsc='-', jlcpcb_class='-', stock_or_sourcing='-',
             fit='No part', leadless='No', smt_pins_per_part=0, tht_pins_per_part=0, unit_price_usd=0.0, datasheet_url='',
             note='No BOM part (copper only). Netlisted by integration as 1-pin pads (TPxxx pin 1) in netlist_merged.csv (action A-1 closed 25 Sep); nets per layout_package.md section 11; stream netlists (frozen) do not carry them - add the pad symbols in the schematic',
             stream='parts (layout)', _refs=tp_layout),
        dict(block=BLOCKS['8'], refs='MH, FID', qty_per_board=11,
             description='4 x M3 mounting holes (3.2 mm plated, 6.0 mm GND pad) + 3 global fiducials + 2 local fiducials at U202 + 2 at U201',
             value='-', package='-', rating_tolerance='-', mpn='No part', lcsc='-', jlcpcb_class='-', stock_or_sourcing='-',
             fit='No part', leadless='No', smt_pins_per_part=0, tht_pins_per_part=0, unit_price_usd=0.0, datasheet_url='',
             note='layout_package.md sections 5 and 12; rail fiducials and tooling holes added by JLCPCB', stream='parts (layout)', _refs=[]),
        dict(block=BLOCKS['8'], refs='PCB', qty_per_board=1,
             description='4-layer FR-4 1.6 mm, JLC04161H-7628, 1 oz outer / 0.5 oz inner, ENIG, 90 ohm diff. impedance control, 100 x 80 mm board (R9 E-19; named alternative 100 x 70 mm) + 2 x 5 mm V-cut rails on the 100 mm edges (100 x 90 mm panel), top-side assembly only, exposed-pad thermal vias 0.30 mm unfilled and tented on L4 (VE; no epoxy fill/cap)',
             value='-', package='-', rating_tolerance='-', mpn='JLCPCB', lcsc='-', jlcpcb_class='-', stock_or_sourcing='JLCPCB',
             fit='Yes', leadless='No', smt_pins_per_part=0, tht_pins_per_part=0, unit_price_usd=0.0, datasheet_url='',
             note='price in cost_report.md (not a per-part line)', stream='parts (layout)', _refs=[]),
    ]

    with open(f'{OUT}/bom_merged.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        for r in bom + extra:
            rr = {k: r[k] for k in COLS}
            rr['unit_price_usd'] = ('%.4f' % r['unit_price_usd']).rstrip('0').rstrip('.') if r['unit_price_usd'] else '0'
            w.writerow(rr)

    # totals
    fitted = [r for r in bom if r['fit'].lower().startswith('yes')]
    dnf = [r for r in bom if r['fit'].upper().startswith('DNF')]
    pads = [r for r in fitted if r['mpn'].lower().startswith('pcb pad')]
    components = [r for r in fitted if r not in pads]
    n_fitted_parts = sum(r['qty_per_board'] for r in components)
    n_pad_refs = sum(r['qty_per_board'] for r in pads)
    n_dnf = sum(r['qty_per_board'] for r in dnf)
    smt = sum(r['qty_per_board'] * r['smt_pins_per_part'] for r in components)
    tht = sum(r['qty_per_board'] * r['tht_pins_per_part'] for r in components)
    leadless = [r for r in components if r['leadless'].lower().startswith('yes')]
    n_leadless = sum(r['qty_per_board'] for r in leadless)
    cost_board = sum(r['qty_per_board'] * r['unit_price_usd'] for r in components)
    uniq_fitted = len({(r['mpn'], r['value']) for r in components})
    say('BOM: lines', len(bom), f'(+{len(extra)} no-part/PCB lines)', '| refs', len(ref_owner), '| fitted parts', n_fitted_parts,
        '| fitted copper-pad refs (J201, J202, TP732)', n_pad_refs, '| DNF', n_dnf, f'({compress([d for r in dnf for d in r["_refs"]])})')
    say(f'  unique fitted part numbers (MPN) {len({r["mpn"] for r in components})}; unique fitted lines {len(components)}')
    say(f'  SMT joints per board {smt}; THT joints per board {tht} (J701 7; USB4105 shell stakes 4 = pin-in-paste, counted THT by the stream)')
    say(f'  leadless (X-ray) parts per board {n_leadless}: {", ".join(r["refs"] for r in leadless)}')
    say(f'  fitted parts cost per board (stream unit prices) US$ {cost_board:.2f}')
    for s in STREAMS:
        c = [r for r in components if r['stream'] == s]
        say(f'    {s}: {len(c)} fitted lines, {sum(r["qty_per_board"] for r in c)} parts, US$ {sum(r["qty_per_board"] * r["unit_price_usd"] for r in c):.2f}, '
            f'SMT {sum(r["qty_per_board"] * r["smt_pins_per_part"] for r in c)} / THT {sum(r["qty_per_board"] * r["tht_pins_per_part"] for r in c)}')

    # cross-checks BOM <-> netlist
    bom_refs = set(ref_owner)
    net_refs = set(refs_net)
    tp_refs = {tp for tp, _ in TP_PADS}
    say('CHECKS:')
    say('  BOM refs not in netlist:', sorted(bom_refs - net_refs, key=natkey) or 'none')
    say('  netlist refs not in BOM (component lines or the "No part" test-pad line):',
        sorted(net_refs - bom_refs - tp_refs, key=natkey) or 'none')
    say(f'  test pads netlisted (A-1): {len(tp_refs & net_refs)} of {len(TP_PADS)}; 1 pin each: '
        f'{all(len(refs_net[t]) == 1 for t in tp_refs)}; pads on nets absent from the stream netlists: {tp_missing or "none"}')
    say(f'  stream component parts in netlist: {len(net_refs - tp_refs)}; stream pin rows: {sum(1 for r in pins if r["refdes"] not in tp_refs)}')
    c103 = [r for r in bom if r['_refs'] == ['C103']][0]
    say(f'  C103 (D-A): {c103["value"]} {c103["rating_tolerance"]} {c103["mpn"]} {c103["lcsc"]} fit {c103["fit"]}')
    say('  duplicate designators:', dup_ref or 'none')
    reused = sorted(bom_refs & set(RETIRED), key=natkey)
    say('  retired designators reused:', reused or 'none', f'(checked against {len(RETIRED)} retired designators)')
    pc = []
    for r in bom:
        exp = r['smt_pins_per_part'] + r['tht_pins_per_part']
        for d in r['_refs']:
            got = len(refs_net.get(d, {}))
            if exp and got != exp:
                pc.append(f'{d}: BOM {exp} vs netlist {got}')
    say('  pin-count mismatches BOM vs netlist:', pc or 'none')
    owner_mismatch = [d for d in bom_refs & net_refs
                      if {r['stream'] for r in pins if r['refdes'] == d} != {ref_owner[d]}]
    say('  BOM stream vs netlist stream mismatch:', owner_mismatch or 'none')
    say('  layout-allocated pads (BOM "No part" line, netlisted by integration A-1):', compress(tp_layout))

    # ---------------------------------------------------------------- diff against Parts List v0.6
    old = load(f'{BASE}/current/parts_list_current.csv')
    old_by_ref = {}
    for r in old:
        if r['Fit'].startswith('No part') or r['Designators'] in ('PCB', 'MH, FID'):
            continue
        for d in expand(r['Designators']):
            old_by_ref[d] = r
    new_by_ref = {}
    for r in bom:
        for d in r['_refs']:
            new_by_ref[d] = r
    json.dump(dict(old={d: dict(mpn=r['Part number (MPN)'], value=r['Value'], fit=r['Fit'], lcsc=r['LCSC no.'], package=r['Package'])
                        for d, r in old_by_ref.items()},
                   new={d: dict(mpn=r['mpn'], value=r['value'], fit=r['fit'], lcsc=r['lcsc'], package=r['package'], stream=r['stream'])
                        for d, r in new_by_ref.items()}),
              open(f'{OUT}/_diff_raw.json', 'w'), indent=0, ensure_ascii=False)
    added = sorted(set(new_by_ref) - set(old_by_ref), key=natkey)
    removed = sorted(set(old_by_ref) - set(new_by_ref), key=natkey)
    common = sorted(set(new_by_ref) & set(old_by_ref), key=natkey)
    say(f'DIFF vs v0.6: v0.6 designators {len(old_by_ref)}, v0.7 designators {len(new_by_ref)}; added {len(added)}, removed {len(removed)}, common {len(common)}')
    open(f'{OUT}/build_package_out.txt', 'w').write('\n'.join(log) + '\n')


if __name__ == "__main__":
    main()
