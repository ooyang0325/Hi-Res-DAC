"""E-15 (R9) evidence register: requirement or limit -> value -> class -> evidence -> qualification test.

Class: G = guaranteed by datasheet limits plus worst-case calculation; E = engineering estimate (assumption named);
Q = qualified only by bring-up measurement (planned - no hardware exists yet). 'assumption_flag' marks every row whose
guarantee rests on an assumption (R9-B3). 'r9_status' = provisional for rows touched by the R9 changes (decisions_r9.md
E-1...E-14) until the streams report. Input: traceability.csv (same folder). Output: evidence_register.csv.
"""
import csv, os

HERE = os.path.dirname(os.path.abspath(__file__))
# id: (class, assumption flag ('' = none), qualification test, r9 status)
C = {
    'R-01': ('G', '', 'bit-perfect capture at all 8 rates (bring-up i-11)', 'final'),
    'R-02': ('E', 'host driver behaviour (not provable by calculation)', 'enumeration + playback on Windows/macOS/Linux/Android', 'final'),
    'R-03': ('G', 'minor: board skew 2.22 ns [ASSUMP] vs 14.0 ns margin', 'scope setup/hold at 384 kHz', 'final'),
    'R-04': ('Q', 'X201 duty 45-55 % equals the ESS limit (zero margin)', 'duty/edges at U301 XI (TP711); fallback R203 0 ohm / NDK part', 'final'),
    'R-05': ('E', 'typical-only DAC/op-amp THD data', 'THD+N 1 kHz 0 dBFS 300 ohm, LEG vs JACK', 'provisional (E-3 new taps: analog to confirm THD)'),
    'R-06': ('E', 'typical DAC DR (127 dB-A) and noise densities', 'DR measurement (A-weighted)', 'final'),
    'R-07': ('G', '', 'production calibration to 1.55 Vrms +-0.05 dB', 'final'),
    'R-08': ('G', '', 'check the default trim register on first boot', 'final'),
    'R-09': ('G', 'at VBUS 4.40 V: LM27762 R_NEG typical only (L-3)', 'power at 32 ohm, VBUS 4.60 and 4.40 V (i-12)', 'final'),
    'R-10': ('G', 'at VBUS 4.40 V: LM27762 R_NEG typical only (L-3)', 'power at 60 ohm balanced, VBUS 4.60 and 4.40 V (i-12)', 'final'),
    'R-11': ('G', '', 'power at 120 ohm balanced', 'final'),
    'R-12': ('G', '', 'power at 300 ohm balanced', 'final'),
    'R-13': ('G', 'thin (+0.97 mA IOS); linear interpolation of the power table', 'Default 32 ohm power at the measured U503 limit (i-4)', 'provisional (E-6)'),
    'R-14': ('E', 'integration estimate: round-2 peaks + round-3 quiescent', 'Default power at 60/120/300 ohm', 'provisional (E-6)'),
    'R-15': ('E', 'TLP3545A RON x1.35 at 60 C and contact resistances assumed', 'output impedance at 25/60 C (O12)', 'final'),
    'R-16': ('G', '', 'frequency response 20 Hz-20 kHz', 'final'),
    'R-17': ('E', 'layout return-path target 2 mOhm (not yet routed)', 'crosstalk 3.5 mm 32 ohm / 4.4 mm 300 ohm', 'provisional (E-13 placement)'),
    'R-18': ('G', '', 'channel balance after trim', 'final'),
    'R-19': ('E', 'DAC pair mismatch 3 % / null 1 mV assumed (ESS publishes none); 0-50 C via 25 C screen is conditional (R9-B4/D3)', '100 % DC screen at 25 C + temperature qualification of the prototype lot (E-4)', 'provisional (E-4)'),
    'R-20': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 2 V DC on each leg -> removal time (i-9)', 'provisional (E-2/E-3)'),
    'R-21': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 1 V DC on each leg -> removal time (i-9)', 'provisional (E-2/E-3)'),
    'R-22': ('G', 'tOFF x2 (L-2); OPA1622 current bound', 'rail-stuck injection test (i-9)', 'provisional (E-3)'),
    'R-23': ('E', '22 % DAC pin mismatch for the CM content; tOFF x2 (L-2)', 'CM-window stuck I/V test (i-9)', 'provisional (E-3: L-11 detector)'),
    'R-24': ('G', 'MCU pin leakage 1 uA [ASSUMP] in the error budget', 'tier boundary tests (i-10)', 'final'),
    'R-25': ('G', '', '-', 'final'),
    'R-26': ('G', 'capacitor ageing -5 % assumed in the aged range', 'FS 20 Hz square / sine at the leg -> no trip', 'provisional (E-3 new detector must not false-trip)'),
    'R-27': ('G', '', 'OD-1 content tests (i-17...i-20)', 'final'),
    'R-28': ('G', 'DAC filter delay <= 1 ms [ASSUMP]; tOFF x2 (L-2)', 'flat digital DC tests (i-19)', 'final'),
    'R-29': ('E', 'TLV3402 delay 3 x typical; 74AUP1G17 thresholds scaled from 3.0 V; Kyocera edge 4.5 ns', 'boot self-test (b)/(c) on every board', 'provisional (E-11 R665 330 ohm, E-3)'),
    'R-30': ('E', 'COFF <= 1 nF (640 pF typ x1.5), 22 % DAC pin mismatch, LP5907 current limit <= 0.75 A - all unpublished', 'pop at 300/600 ohm, 5 boards, 0/50 C (O10)', 'provisional (E-9 power-down order, E-3 taps)'),
    'R-31': ('E', 'hold-up model: reservoir >= 176 uF, PMEG VF tempco, LP5907 reverse behaviour, MCU reset thresholds', 'hot-unplug scope at music level (i-13, M11)', 'provisional (E-8)'),
    'R-32': ('E', 'MCU 80 mA planning value (L-1)', 'S1 current on every board (production test)', 'final'),
    'R-33': ('E', 'MCU/CPLD/DVDD planning values (L-1); 9.2 mA to 500 mA', 'S3 current at the U503 limit on every board', 'provisional (E-6)'),
    'R-34': ('G', '', 'Type-C source classes 0.5/1.5/3 A (i-2)', 'final'),
    'R-35': ('G', '', 'USB-IF attach inrush (M1)', 'final'),
    'R-36': ('E', 'MCU Stop 1.9 mA [PH] (L-1); BAT54 leakage estimate ~12 uA vs 10 uA budget; +3.5 uA margin', 'suspend current vs time, legacy cable (M5)', 'provisional (E-5)'),
    'R-37': ('E', 'RthJA values and +10 C local rise assumed; U202 40 mA', '30 min overload / 50 C ambient IR scan', 'final'),
    'R-38': ('G', 'THIN / DATA-GAP rows listed in the stress table', 'stress items per the bring-up plan', 'provisional (parts: rows for the R9 parts)'),
    'R-39': ('G', '', 'impedance coupon / TDR; placement feasibility', 'provisional (E-13)'),
    'R-40': ('G', 'LED VF tempco -2.2 mV/K and hFE at 0 C assumed', 'LED current per string at 0/25/50 C, 4.30 V (i-8)', 'final'),
    'R-41': ('E', 'tOFF 2 x 25 C max (L-2); permit re-close depends on node-H discharge depth (R9-B1)', 'switch timing at 0/50 C; short trip pulses with RELAY_EN held high', 'provisional (E-2)'),
    'R-42': ('G', 'wording: U303 regulates into R530 for ~90 us after AUD_EN falls (R9-A4)', 'discharge scope (M4)', 'provisional (A4 wording)'),
    'R-43': ('E', 'MCU reset thresholds 1.8/2.3 V, LP5907 reverse behaviour (both variants modelled)', 'hard-unplug scope (M11)', 'final'),
    'R-44': ('E', 'MCU reset thresholds; PA1 leakage 1 uA; brown-out margin ~0.17 V at the 4.40 V corner (R9-A8)', 'brown-out ISR timing at a hard unplug (M11)', 'provisional (E-5 may change the VBUS divider)'),
    'R-45': ('E', 'planning values (L-1)', 'S5 current', 'final'),
    'R-46': ('E', 'LM27762 R_NEG typical only (L-3)', 'R_NEG at VIN 4.2 V / 150 mA (O9, M2)', 'final'),
    'R-47': ('Q', 'maker drawings image-only', 'gates G-1/G-2 (two samples each)', 'final (gate, open until measured)'),
    'R-48': ('G', '', 'check_design.py incl. the E-1 value-decode check', 'provisional (E-1: Parts List Value cells to be corrected by parts)'),
    'R-49': ('G', 'gate timing uses TLV3402 delay 3 x typical', 'boot self-test (d); slow 3V3A ramp threshold test', 'final'),
    'R-50': ('G', '', 'link BER test 1e10 bits', 'final'),
    'R-51': ('G', '', '-', 'final'),
    'R-52': ('E', 'cable model 0.25-1.5 uH / 0.05-0.4 ohm assumed', '5V_SYS hard short with D102 fitted (i-9)', 'final'),
    'R-53': ('E', 'documented limitation L-8', 'unplug scope OUT-IN of U302/U503 (D104/D105)', 'final'),
    'R-54': ('G', '', 'ANA_SENSE trip at 1.279 V / 1587 counts', 'final'),
    'R-55': ('E', 'NOT met as stated: node-H recovery 6.1-34.8 ms after a shallow discharge (R9-B1)', 'short comparator pulses with RELAY_EN held high -> switch stays open', 'provisional (E-2)'),
    'R-56': ('G', 'MCU pin leakage 1 uA; offset 9.23/18.45 mV', 'pre-close check with a known DC', 'provisional (E-4 offset)'),
    'R-57': ('G', '', 'boot self-test on every board', 'provisional (E-2/E-3/E-10 add self-test items)'),
    'R-58': ('G', '', 'rate/family change with the switch open', 'provisional (E-10 GPIO2 = lock only, E-12 CPLD reset)'),
    'R-59': ('E', 'OPA2210 600 ohm swing row at 25 C only; PMEG VF from 25 C max + typical tempco', 'I/V swing at calibrated full scale; fallback R501 232 k', 'provisional (E-8)'),
    'R-60': ('-', 'documented limitations', '-', 'provisional (E-3 may remove L-11)'),
    'R-61': ('E', 'limitation L-11 (undetectable DAC-core hang)', 'none possible (fault not inducible)', 'provisional (E-3: hardware large-DC persistence detector)'),
    'R-62': ('G', '', 'unpowered-MCU injection check at attach', 'final'),
    'R-63': ('E', 'ESS VOL ohmic extrapolation from 100 uA', 'SDA VOL at the DAC with 10 k pull-ups', 'final'),
    'R-64': ('Q', 'limitation L-9', 'leg-to-leg short survival test, 30 min', 'final'),
    'R-65': ('G', 'limitation L-10 (out-of-spec source)', '-', 'final'),
    'R-66': ('E', 'I2S2 slave at 22.6/24.6 MHz BCLK not published', 'bit-exact capture at 352.8/384 kHz (i-15)', 'final'),
    'R-67': ('E', 'MCU boot <= 10 ms assumed', 'D+ pull-up time after VBUS valid', 'final'),
    'R-68': ('E', 'attrition, PCB and shipping prices assumed (report only)', 'JLCPCB quote', 'provisional (R9 parts changes)'),
    'R-69': ('-', 'process', 'bring-up checklist', 'final'),
    'R-70': ('G', '', '-', 'final'),
    'R-71': ('E', 'ESS internal lock-loss latency not published', 'DAC_LOCK self-test; forced lock loss', 'provisional (E-10 GPIO2 = lock only)'),
}
# explicit assumption-based bounds (R9-B3 and the summary) not captured as a single requirement row
EXTRA = [
    ('A-01', 'TLP3545A tON/tOFF over 0-60 C', '10 ms / 1.0 ms design (2 x 25 C maxima)', 'E', 'Toshiba DS 25 C maxima; x2 [ASSUMP] (L-2)', 'yes: temperature curves typical only', 'tON/tOFF at 0/50 C (L-2)', 'final'),
    ('A-02', 'TLP3545A RON at 60 C', '0.081 ohm (60 mOhm x 1.35)', 'E', 'DS 25 C max; x1.35 [ASSUMP]', 'yes', 'RON at 60 C (O12)', 'final'),
    ('A-03', 'TLP3545A COFF bound', '<= 1 nF (640 pF typ x 1.5)', 'E', 'DS typical only', 'yes', 'pop test (O10)', 'final'),
    ('A-04', 'TLV3402 propagation delay', '<= 0.9 ms (3 x typical)', 'E', 'TI DS typical 55-300 us, no maximum', 'yes (R9-B3)', 'boot self-test (d) timing', 'final'),
    ('A-05', 'PMEG2010AEH VF at 10-30 mA, 0-50 C', '<= 0.30 V', 'E', '25 C maxima + typical tempco (parts R3.7)', 'yes (R9-B3)', 'VF at 0/50 C (O13)', 'provisional (E-8)'),
    ('A-06', 'BAT54 leakage at 50 C (D103-D105, D413/D414) in the suspend budget', '10 uA budget vs ~12 uA estimate', 'E', 'maker 25 C data only; estimate exceeds the allowance by ~2 uA against a +3.5 uA S6 margin', 'yes (R9-B3/D2)', 'suspend current at 50 C (M5)', 'provisional (E-5)'),
    ('A-07', 'MCU Stop current', '1.9 mA planning value (0.11 mA typ)', 'E', 'WCH publishes typical only (L-1)', 'yes', 'suspend current on the first board (R9-C3)', 'provisional (E-5)'),
    ('A-08', 'MCU / CPLD / DVDD running currents', '80 / 40 / 60 mA planning values', 'E', 'vendor-unpublished (L-1)', 'yes', 'per-rail currents in every state (production)', 'provisional (E-6)'),
    ('A-09', 'VCCA current at 80 MHz', '2.9 mA', 'E', 'ESS 0.8 mA at 22 MHz scaled [ASSUMP]', 'yes', 'VCCA current (O11)', 'final'),
    ('A-10', 'DAC pin-pair mismatch and null offset', '3 % (offset) / 22 % (CM, pop) / 1 mV', 'E', 'ESS publishes no matching', 'yes (R9-B4/D3)', '25 C screen + temperature qualification (E-4)', 'provisional (E-4)'),
    ('A-11', 'LM27762 R_NEG, UVLO, PGOOD, start-up current', 'R_NEG 2.5 ohm typ; UVLO 2.4/2.6 V typ', 'E', 'TI DS typical only', 'yes', 'R_NEG and start into the Default limit (M2, M9)', 'final'),
    ('A-12', 'LP5907 current limit / reverse behaviour / rise time', '<= 0.75 A assumed; both reverse variants modelled', 'E', 'TI DS 500 mA typ, no minimum rise time', 'yes', '3V3A rise and hot-unplug scope', 'final'),
    ('A-13', 'OPA2210 output swing at the I/V load', '(V+) - 0.6 V at 600 ohm, 25 C only', 'E', 'TI DS 600 ohm row at 25 C', 'yes', 'swing at calibrated full scale, 0/50 C', 'provisional (E-8)'),
    ('A-14', 'X201 duty cycle vs ESS', '45-55 % = the ESS limit', 'Q', 'Kyocera DS vs ESS DS (zero margin)', 'yes (zero margin)', 'duty at XI; fallback R203 0 ohm', 'final'),
    ('A-15', 'MCLK-alive tap margin (74AUP1G17 behind R665)', 'not provable with 4.5 ns edges (R9-A9)', 'E', 'VT+/VT- at 3.0 V scaled; CI/CPD unpublished', 'yes', 'boot self-test (b) on every board', 'provisional (E-11 R665 330 ohm)'),
    ('A-16', 'CH32V307 reset thresholds, PA1 leakage, pin injection', '1.8/2.3 V, 1 uA', 'E', 'WCH DS incomplete', 'yes', 'brown-out ISR vs reset at unplug (M11)', 'final'),
    ('A-17', 'C442/C443 reverse bias during LM27762 start/off (open item 6)', 'clamped by D413/D414 (not yet computed)', 'E', 'calculation pending (R9-A5)', 'yes', 'VPOS/VNEG at start (O15)', 'provisional (E-8)'),
    ('A-18', 'Filter capacitor ageing (C601-C604, C608-C611)', '-5 % ageing term', 'E', 'X5R ageing assumed', 'yes', 'FS 20 Hz square no-trip at 0/50 C', 'final'),
    ('A-19', 'VBUS cable model for the hard-short kick', '0.25-1.5 uH, 0.05-0.4 ohm', 'E', 'assumed cable range', 'yes', 'hard-short test at U102 IN', 'final'),
    ('A-20', 'Thermal model', 'RthJA values, +10 C local rise', 'E', 'assumed board conditions', 'yes', '50 C ambient IR scan', 'final'),
    ('A-21', 'Node-H minimum off-time after any trip', 'NOT guaranteed: 6.1-34.8 ms after a shallow discharge (R9-B1) vs the 53 ms claim', 'E', 'p05 recovery computed from a full discharge only', 'yes (claim open)', 'short trip pulses with RELAY_EN held high', 'provisional (E-2)'),
    ('A-22', 'Brown-out threshold margin at the VBUS 4.40 V corner', '~0.17 V effective (R9-A8)', 'G', 'power c09 band 3.756-4.244 V vs 5V_SYS min 4.311 V', 'thin', 'VBUS_SENSE trip at 4.40 V', 'provisional (thin-margin table, E-14)'),
    ('A-23', 'Hardware-window 20 Hz false-trip margin (aged corner)', '6.2 %', 'G', 'protection p11 (ageing -5 % assumed)', 'thin', 'FS 20 Hz square at the leg', 'provisional (thin-margin table, E-14; E-3)'),
    ('A-24', 'Default USB total vs 500 mA', '490.80 mA (9.2 mA)', 'E', 'power c17 with L-1 planning values', 'yes (L-1)', 'S3 current on every board', 'provisional (E-6)'),
    ('A-25', 'ESS lock-loss latency (OD-2 interrupt)', 'not published', 'E', 'ESS DS silent', 'yes', 'forced lock loss (i-22)', 'provisional (E-10)'),
    ('A-26', 'I2S2 slave capture at 22.6/24.6 MHz', 'not published', 'E', 'WCH text silent (digital R3.6)', 'yes', 'bit-exact capture at 352.8/384 kHz (i-15)', 'final'),
]

def norm_flag(cls, note, basis=''):
    """'yes: ...' = the guarantee rests on the named assumption (class E, or Q pending measurement);
    'thin: ...' / 'minor: ...' = G rows with a small or covered assumption; 'no' = none."""
    note = (note or '').strip()
    if cls in ('E', 'Q'):
        return 'yes: ' + (note or basis or 'see evidence')
    if cls == '-':
        return 'n/a' + (f': {note}' if note else '')
    if not note:
        return 'no'
    if note.startswith('thin'):
        return note
    if note.startswith('minor: '):
        note = note[7:]
    return 'minor: ' + note + ' (worst-case margin covers it)'


# ---- R9 final (streams reported 25 Sep 2026 ~18:00): overrides for the rows touched by E-1...E-21
R9 = {
    'R-05': ('E', 'typical-only DAC/op-amp THD data; E-3 taps confirmed without effect (analog R9)', 'THD+N 1 kHz 0 dBFS 300 ohm, LEG vs JACK', 'final (R9)'),
    'R-13': ('G', '', 'Default 32 ohm power at the measured U503 limit (i-4)', 'final (R9 E-18: R509 4.75 k; IOS min 180.05 mA vs need 178.82 mA, G +1.23 mA)'),
    'R-14': ('G', '', 'Default power at 60/120/300 ohm', 'final (R9: need 178.82 mA G covers every Default target)'),
    'R-17': ('E', 'layout return-path target 2 mOhm (routing pending)', 'crosstalk 3.5 mm 32 ohm / 4.4 mm 300 ohm', 'final (R9: placement 100 x 80 mm)'),
    'R-19': ('G', 'DAC matching/drift not published: those terms are Q per board', 'per-board offset test at 0-5 / 25 / 50 C (E-4 procedure, all 5 boards)', 'final (R9 E-4: G 5.61 / 11.21 mV; E 7.73 / 15.47 mV)'),
    'R-20': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 2 V DC on each leg -> removal time (i-9)', 'final (R9)'),
    'R-21': ('G', 'switch tOFF 1.0 ms design = 2 x 25 C max (L-2)', 'inject 1 V DC on each leg -> removal time (i-9)', 'final (R9)'),
    'R-22': ('G', 'tOFF x2 (L-2)', 'rail-stuck injection test (i-9)', 'final (R9)'),
    'R-23': ('E', 'E-3 timer leakage <= 1 uA per node (NPN ICBO hot, C_T, PCB) assumed for the 32 ohm worst case; 22 % DAC pin mismatch for the CM content; tOFF x2 (L-2)', 'E-3 DC injection tests (1.70 V no trip; 2.10 V trip 19.5-23.2 ms + <= 2 ms); timer T_P at 50 C', 'final (R9 check E-22/E-24: 27.5 / 14.5 mJ worst)'),
    'R-26': ('G', 'capacitor ageing -5 % assumed; E-3 T_P from C_T +-2 % PPS film (leakage only slows the timer)', 'FS 20 Hz sine 60 s no trip; FS square 21.0 Hz trips, 26 Hz no trip', 'final (R9 check: sine 5.8 %, squares <= 21.5 / 25.6 Hz)'),
    'R-29': ('G', 'TLV3402 delay 3 x typical (3V3A path only)', 'boot self-test (b)/(c); MCLK-alive with R665 330 ohm', 'final (R9 E-11)'),
    'R-30': ('E', 'COFF <= 1 nF, 22 % DAC pin mismatch, LP5907 current limit - unpublished; E-9 order and E-3 taps checked (<= 1.09 mV)', 'pop at 300/600 ohm, 5 boards, 0/50 C (O10)', 'final (R9)'),
    'R-31': ('E', 'hold-up model assumptions (reservoir >= 176 uF, PMEG tempco, MCU reset thresholds)', 'hot-unplug scope at music level (i-13, M11)', 'final (R9 E-8 closed; c14 re-run)'),
    'R-33': ('E', 'MCU/CPLD/DVDD planning values (L-1); S3 493.45 mA', 'production test per board: S3 <= 480 mA, S1 <= 90 mA (E-17); fallback firmware ceiling (E-21)', 'final (R9 E-17/E-18/E-21)'),
    'R-36': ('E', 'MCU Stop 1.9 mA planning value (L-1); Q507 hot leakage estimated (EN >= 3.18 V at VBUS 4.40 V, 50 C)', 'suspend current on the first board (R9-C3), then every board', 'final (R9 E-16: S6 +224 uA; suspend level <= 8.75 ms)'),
    'R-38': ('G', 'THIN / DATA-GAP rows listed in the stress table (165 current rows, FAIL 0)', 'stress items per the bring-up plan', 'final (R9 stress run)'),
    'R-39': ('G', '', 'impedance coupon / TDR; placement at 100 x 80 mm', 'final (R9 E-19)'),
    'R-41': ('G', 'tOFF 2 x 25 C max (L-2)', 'switch timing at 0/50 C; short trip pulses with RELAY_EN held high', 'final (R9 E-2)'),
    'R-42': ('G', '', 'discharge scope (M4)', 'final (R9 A4 wording)'),
    'R-44': ('E', 'PA1 leakage 1 uA dominates the band; PVD threshold >= 2.9 V assumed (L-12)', 'brown-out ISR timing at a hard unplug and at a slow sag (M11)', 'final (R9)'),
    'R-48': ('G', '', 'check_design.py incl. the value-from-MPN check (116 lines, 0 mismatches)', 'final (R9 E-1)'),
    'R-55': ('G', '', 'short comparator pulses with RELAY_EN held high -> switch stays open, PB0 low', 'final (R9 E-2)'),
    'R-56': ('G', 'MCU pin leakage 1 uA; offset 7.73 / 15.47 mV with DAC terms', 'pre-close check with a known DC', 'final (R9)'),
    'R-57': ('G', '', 'boot self-test on every board (2.84 s; PB0 low after each self-test trip)', 'final (R9)'),
    'R-58': ('G', '', 'rate/family change with the switch open (<= 972 ms)', 'final (R9 E-10/E-12)'),
    'R-59': ('E', 'OPA2210 600 ohm swing row at 25 C only; PMEG VF from 25 C max + typical tempco', 'I/V swing at calibrated full scale; fallback R501 232 k', 'final (R9 E-8)'),
    'R-60': ('-', 'documented limitations', '-', 'final (R9: L-11 closed; L-12, L-13 added)'),
    'R-61': ('E', 'E-3 timer leakage <= 1 uA per node assumed (NPN ICBO, C_T, PCB)', 'E-3 DC injection tests; frozen-code tests; timer T_P at 50 C', 'final (R9 check E-22/E-24: L-11 closed, 27.5 / 14.5 mJ)'),
    'R-68': ('E', 'attrition, PCB (100 x 80 mm, same price tier) and shipping prices assumed (report only)', 'JLCPCB quote', 'final (R9 cost)'),
    'R-71': ('E', 'ESS internal lock-loss latency not published', 'DAC_LOCK self-test; forced lock loss', 'final (R9 E-10)'),
    'R-72': ('G', 'latent single fault: Q622 D-S short (covered by the production test)', 'comparator-path trips >= 1 ms with RELAY_EN held high; production test: latch cleared + RELAY_EN high -> every photorelay open, LED current < 10 uA', 'final (R9 check E-23/E-26)'),
    'R-73': ('E', 'USB <= 500 mA rests on the planning values (L-1)', 'production test S3 <= 480 mA, S1 <= 90 mA; firmware ceiling fallback', 'final (R9 E-17/E-18/E-21)'),
}
C.update(R9)
EXTRA_R9 = {
    'A-05': ('A-05', 'PMEG2010AEH VF at 10-30 mA, 0-50 C', '<= 0.30 V', 'E', '25 C maxima + typical tempco (parts R3.7)', 'yes (R9-B3)', 'VF at 0/50 C (O13)', 'final (R9)'),
    'A-06': ('A-06', 'BAT54 leakage in the suspend budget', 'D103 deleted, D104/D105 unbiased in Stop (E-16) -> 0 in the S6 budget', 'G', 'power c22 (TPS70933 on VBUS, U102 off in Stop)', '', 'suspend current (first board)', 'final (R9 E-16: resolved)'),
    'A-07': ('A-07', 'MCU Stop current', '1.9 mA planning value (0.11 mA typ); S6 margin +224 uA', 'E', 'WCH publishes typical only (L-1)', 'yes', 'suspend current on the first board (R9-C3)', 'final (R9 E-16)'),
    'A-08': ('A-08', 'MCU / CPLD / DVDD running currents', '80 / 40 / 60 mA planning values', 'E', 'vendor-unpublished (L-1)', 'yes', 'production test S3 <= 480 mA, S1 <= 90 mA (E-17)', 'final (R9 E-17)'),
    'A-10': ('A-10', 'DAC pin-pair mismatch and null offset', '3 % (offset) / 22 % (CM, pop) / 1 mV', 'Q', 'ESS publishes no matching (E-4 split)', 'yes (R9-B4/D3)', 'per-board offset test at 0-5 / 25 / 50 C', 'final (R9 E-4)'),
    'A-13': ('A-13', 'OPA2210 output swing at the I/V load', '(V+) - 0.6 V at 600 ohm, 25 C only', 'E', 'TI DS 600 ohm row at 25 C', 'yes', 'swing at calibrated full scale, 0/50 C', 'final (R9)'),
    'A-15': ('A-15', 'MCLK-alive tap margin (74AUP1G17 behind R665 330 ohm)', '+141 mV to VT+max at 2.4 pF (Kyocera 4.5 ns edge)', 'G', 'protection p19 E-11 (VT at 3.0 V scaled)', 'minor: VT+/VT- scaled from 3.0 V', 'boot self-test (b)', 'final (R9 E-11)'),
    'A-17': ('A-17', 'C442/C443 reverse bias (open item 6)', '<= 0.469 V at 0 C (limit 1.00 V); 0.386 V at 50 C (limit 0.71 V)', 'E', 'power/analog E-8: BAT54 maxima, -1 mV/K and the MnO2 reverse-limit rule assumed', 'yes', 'VPOS/VNEG at start (O15)', 'final (R9 E-8: closed)'),
    'A-21': ('A-21', 'Minimum off-time after any trip', 'independent of the node-H discharge depth (E-2 re-arm latch)', 'G', 'protection p18/p19', '', 'short-trip test with RELAY_EN held high', 'final (R9 E-2: resolved)'),
    'A-22': ('A-22', 'Brown-out threshold margin at the VBUS 4.40 V corner', '+52...+98 mV (power c09/c21; R9-A8 quoted 0.17 V)', 'E', 'PA1 leakage 1 uA [ASSUMP] dominates the band', 'yes', 'VBUS_SENSE trip at 4.40 V', 'final (R9: thin margin, L-12 PVD backup)'),
    'A-23': ('A-23', 'Hardware-window 20 Hz false-trip margin (aged corner)', '6.2 % (E-3 detector: 5.8 %)', 'G', 'protection p11/p18 (ageing -5 % assumed)', 'thin', 'FS 20 Hz square/sine at the leg', 'final (R9 check)'),
    'A-24': ('A-24', 'Default USB total vs 500 mA', '493.45 mA (6.55 mA) on the planning values; 497.95 mA (2.05 mA) with the NDK X201 second source (E-27)', 'E', 'power c17/c21 with L-1 planning values', 'yes (L-1)', 'production test S3 <= 480 mA per board', 'final (R9 E-17/E-27)'),
    'A-25': ('A-25', 'ESS lock-loss latency (OD-2 interrupt)', 'not published', 'E', 'ESS DS silent', 'yes', 'forced lock loss (i-22)', 'final (R9 E-10)'),
}
EXTRA = [EXTRA_R9.get(e[0], e) for e in EXTRA] + [
    ('A-27', 'TPS70933 3V3M range (E-16)', '3.207-3.343 V (1 % + line + load) [DS]; dropout <= 650 mV at 50 mA', 'G', 'TI TPS709 DS; power c22', '', '3V3M at 5V_SYS/VBUS corners', 'final (R9)'),
    ('A-28', 'Q507 MMBT3904 off-state leakage at 50 C (U102 EN held high while running)', '<= 0.57 uA hot (from the 25 C maxima ICEX 50 nA / ICBO 100 nA) -> EN >= 3.18 V at VBUS 4.40 V and 50 C (+1.28 V to the 1.9 V threshold)', 'E', 'JSCJ MMBT3904 25 C maxima; hot leakage estimated [ASSUMP] (parts stress row, power c22)', 'yes', 'U102 EN level at 50 C', 'final (R9 check)'),
    ('A-29', 'ECH-U1H224GX9 reflow (C631-C634, 2416, L-13)', 'ECHU series rating 260 C max, <= 95 s above 220 C (not yet confirmed for the 2416 size) vs JLCPCB 45-90 s above melting', 'Q', 'Panasonic ECHU series data vs JLCPCB profile', 'yes (confirmation for the 2416 size)', 'JLCPCB profile confirmation for the 2416 size (order remark), else owner-fit (1.5 mm iron clearance kept)', 'final (R9 check)'),
    ('A-30', 'X201 load with the MCLK-alive tap (E-11)', '<= 14.2 pF vs 15 pF (layout rule XI <= 10 mm, R665 at the XI pin)', 'G', 'digital/protection R9 (XI 10 pF ESS max, tap 2.4 pF bound)', 'thin', 'MCLK edges/duty at XI', 'final (R9)'),
    ('A-31', 'E-3 detector content boundary', 'sines >= 20 Hz never trip (5.8 %); squares mute <= 21.5 Hz, may up to 25.6 Hz', 'G', 'protection p18 R9 check (C_T 220 nF +-2 %, R_T 110 k, divider 0.1 %)', 'minor: T_P 19.5-23.2 ms includes the <= 1 uA leakage bound (A-33, E)', 'E-3 sine/square tests', 'final (R9 check E-24)'),
    ('A-33', 'E-3 timer node leakage bound (per node)', '<= 1 uA total (NPN ICBO at temperature, C_T insulation, PCB surface)', 'E', 'protection R9 check design basis (no hot maxima published for all terms)', 'yes (R9-CHK-03)', 'timer T_P and trip at 50 C on the first boards', 'final (R9 check E-24)'),
    ('A-34', 'E-2 latent single fault (Q622 drain-source short)', 'bypasses the latch; H path and Q616 still act', 'Q', 'protection R9 check E-23', 'yes (not detectable at boot)', 'production test: latch cleared + RELAY_EN high -> every photorelay open, LED current < 10 uA', 'final (R9 check E-23)'),
    ('A-32', 'PVD brown-out backup threshold on 3V3M (L-12)', '>= 2.9 V highest PVD level', 'E', 'WCH PVD level tolerance not published [ASSUMP]', 'yes', 'slow VBUS sag test', 'final (R9)'),
]

rows = list(csv.reader(open(os.path.join(HERE, 'traceability.csv'), encoding='utf-8')))
out = [['id', 'requirement_or_limit', 'value', 'class', 'evidence', 'qualification_test', 'assumption_flag', 'r9_status']]
for r in rows[1:]:
    rid, req, feat, val, margin, label, src, status = r[:8]
    cls, flag, qtest, r9 = C.get(rid, ('?', 'unclassified', '', 'provisional'))
    evidence = f'{label}; {src}; feature: {feat}; margin: {margin}; status: {status}'
    r9 = r9 if not r9.startswith('provisional') else 'final (R9 streams reported; no change)'
    out.append([rid, req, val, cls, evidence, qtest, norm_flag(cls, flag), r9])
for e in EXTRA:   # (id, requirement/limit, value, class, evidence, flag note, qualification test, r9 status)
    note = e[5]
    note = note[5:-1] if note.startswith('yes (') else ('' if note == 'yes' else (note[5:] if note.startswith('yes: ') else note))
    if e[3] in ('E', 'Q') and (note.startswith('R9-') or not note):   # G rows without an assumption stay 'no'
        note = e[4] + (f' ({note})' if note else '')
    st = e[7] if not e[7].startswith('provisional') else 'final (R9 streams reported; no change)'
    out.append([e[0], e[1], e[2], e[3], e[4], e[6], norm_flag(e[3], note, e[4]), st])

# ---- stale-value guard (session 14): superseded values that must never reach the register. The final values live in
# traceability.csv (patched by _work/r9/fix_trace_final.py) and in the tables above; a hit aborts the build.
import re
STALE = [
    (r'390\.4', 'High IOS min is 395.4 mA'), (r'177\.9 mA', 'Default IOS min is 180.05 mA'),
    (r'>= 4\.0 mA', 'Default margin is +1.23 mA'), (r'178\.8[145]', 'Default need is 178.82 mA'),
    (r'\+1\.2[158] mA', 'Default G margin is +1.23 mA'), (r'4\.81 k', 'R509 is 4.75 k'),
    (r'\b8 % / 4 %', 'E-3 energy margins are 8.3 % / 3.5 %'), (r'integration calc|CALC integration', 'write "worst-case calculation"'),
    (r'TPS7A20', 'U502 is the TPS70933'), (r'109 rows|rows 109|150 current', 'stress table: 165 current rows'),
    (r'80 x 60|80 × 60', 'board is 100 x 80 mm (E-19)'), (r'16\.99', 'hard-short kick is 17.08 V'),
    (r'D103-D105|U502/U302/U503', 'D103 deleted; D104/D105 on U302/U503'), (r'\b8\.1 %', 'E-3 sine margin is 5.8 %'),
    (r'ECH-U1H223', 'C_T is ECH-U1H224GX9 (2416)'), (r'3\.006|3\.125 V', 'U605 fall 2.970-3.122 V'),
    (r'126 / 152|0\.118|1\.297', 'round-3 values superseded (R3.17 / VE-14)'), (r'<= 8\.45 ms', 'suspend level <= 8.75 ms'),
    (r'5\.315', 'LED current min ~5.26 mA'), (r'65\.6 / 80\.2|9\.23 / 18\.45', 'E-4 offset 7.73 / 15.47 mV'),
    (r'117 lines', 'value check decodes 116 lines'), (r'758\.11|741\.89|\+112 mA', 'S4 is 760.76 mA'),
    (r'490\.80|342\.28|357\.62|350\.43|2\.4965|493\.42|497\.92|348\.68|364\.05|765\.2\b', 'final S-states (power c17)'),
    (r'45-120 ms', "self-test a' window is 70-140 ms"), (r'x11 at 60 C|at 60 C \(x11\)', 'Q507: 50 C, hot leakage estimated'),
    (r'minor: minor', 'duplicated flag prefix'), (r'T_START 60', 'T_START is 40 ms'),
    (r'rail-stuck SE 12\.8 / 6\.4', 'rail-stuck SE is 25.6 / 12.8 mJ (p03)'), (r'2\.30 mW', 'residual <= 2.31 mW (p06)'),
    (r'6\.7 ohm', 'no clipping up to >= 6.85 ohm (c04 VIN)'), (r'minor: (process|documented)', "class '-' rows carry n/a"),
]
hits = [(x[0], p, why) for x in out[1:] for p, why in STALE if any(re.search(p, str(c)) for c in x)]
assert not hits, 'stale values in the register: ' + '; '.join(f'{i} /{p}/ -> {w}' for i, p, w in hits)
with open(os.path.join(HERE, 'evidence_register.csv'), 'w', newline='', encoding='utf-8') as f:
    csv.writer(f).writerows(out)
n = len(out) - 1
from collections import Counter
print(f'evidence_register.csv: {n} rows; class {dict(Counter(x[3] for x in out[1:]))}; '
      f'rests on an assumption (flag yes) {sum(1 for x in out[1:] if x[6].startswith("yes"))}; thin {sum(1 for x in out[1:] if x[6].startswith("thin"))}; minor {sum(1 for x in out[1:] if x[6].startswith("minor"))}; provisional {sum(1 for x in out[1:] if x[7].startswith("provisional"))}')
missing = [r[0] for r in rows[1:] if r[0] not in C]
assert not missing, missing
