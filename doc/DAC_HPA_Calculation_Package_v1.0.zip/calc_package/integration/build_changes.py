"""bom_changes_vs_v06.csv: every designator added / removed / changed between Parts List v0.6 and the merged v0.7 BOM,
grouped by reason. Uses _diff_raw.json written by build_package.py; asserts that every differing designator is covered."""
import csv, json, re, os
from build_package import expand, compress, natkey, OUT

d = json.load(open(f'{OUT}/_diff_raw.json'))
old, new = d['old'], d['new']

# (change, designators, reason, stream, source)
G = [
    # ---------------- round 3 (decisions_r8c.md X-1..X-10, DX, DY; review fixes)
    ('added', 'C104', 'U102 EN delay capacitor 100 nF with R109 300 k: U102 turns on >= 2.24 ms after attach at every corner - the two USB-IF inrush regions are separated by construction (X-2)', 'power', 'X-2; power c16'),
    ('added', 'D104, D105', 'Nexperia BAT54,215 OUT->IN reverse clamps at input collapse (X-4): D104 U302, D105 U503; L-8 residual 0.40-0.46 V for tens of us; D103 (U502) deleted in R9 E-16 (TPS70933 has reverse-current protection)', 'power', 'X-4, DY-5, E-16; power c14, c22'),
    ('added', 'R535, R536, C516', 'ANA_SENSE divider 68.1 k / 30.1 k + 100 pF C0G from 5V_ANA_F to MCU PA0 (k 0.3065, 5.55 V -> 1.725 V, source 20.9 k): supply-fault rule 5V_ANA_F < 4.0 V in every state (X-5) VE: R535/R536 -> 100 k / 47 k Basic (power VE 3): 4.00 V = 1.279 V = 1587 counts, source 32.0 k', 'power', 'X-5; power c16'),
    ('removed', 'R506, R507', 'LM27762 EN+/EN- tied to VIN (5V_ANA_F); RAIL_EN, R506, R507 deleted (X-1); rails start with the TPS2596 dVdt ramp after ANA_EN', 'power', 'X-1; power R3'),
    ('added', 'U605, R675-R679, R682-R686, R688, R689, Q619, Q620', 'DAC-supply supervisor on 3V3M: TI TLV3402 dual comparator, two independent 3V3A-good channels (> ~3.10 V) gating N2_AVCC_EN_G (MCLK) and AUD_EN (DVCC) via Q619/Q620; 0.1 % dividers, 22 M hysteresis, 470 k readback to PA12/PB9 (X-6)', 'protection', 'X-6; protection p10'),
    ('added', 'U606, R667-R674, R680, R681, R687, C626-C629, D610', 'Permit-node channels on VPOS/VNEG (TLV1704): 1V3-good (> ~1.15 V) and MCLK-alive into N6_H, with references, hysteresis, input filter and the PB8 boot-test injection (D610 BAS70, R674) (X-6)', 'protection', 'X-6; protection p10'),
    ('added', 'U607, R665, R666, C623-C625, D609', 'MCLK activity detector: 1 k tap at the DAC XI net -> 74AUP1G17 on 3V3D -> 100 pF pump -> BAS70-04 -> 82 pF / 1 M hold node: dead detection <= 0.42 ms at any static level, fail-safe with 3V3D off (X-6); frozen-DAC-code cases removed <= 2.40 ms, <= 1.38 mJ', 'protection', 'X-6; protection p10, R3.5'),
    ('added', 'U208, C224', 'Nexperia 74LVC3G34 (Ioff) on 3V3D at the CPLD: 3V3M -> 3V3D crossing of LINK_SCK/LINK_MOSI/LINK_FRAME (X-7) VE: U208 -> TI SN74LVC3G34DCUR C130024 (digital VE 1, drop-in, skew bound 2.7 ns)', 'digital', 'X-7; digital R3'),
    ('added', 'Q207, R240', 'Open-drain DAC_RESETB driver AO3400A (gate N2_RESET_DRV = PA8, R240 100 k pull-up to 3V3M: DAC held in reset whenever the MCU is in reset); PA8 low = released (X-7)', 'digital', 'X-7; digital R3'),
    ('changed', 'R305', 'DAC RESETB 100 k pull-down -> 10 k pull-UP to DVCC at the DAC pin for the Q207 open-drain driver (X-7)', 'analog', 'X-7; analog R3'),
    ('added', 'R236, R237', 'Series resistors so the 3V3A-good supervisor can override the MCU: R236 10 k AVCC_EN -> N2_AVCC_EN_G (U206 input B), R237 4.7 k PC10 (N2_AUD_EN_MCU) -> AUD_EN (X-6)', 'digital', 'X-6; digital R3'),
    ('added', 'R242-R246', 'ADC pin injection limiters 330 ohm 1 % between DC_SENSE_LP/LN/RP/RN, V3A_MON and MCU PC0-PC4 (pin-side nets N2_DCS_*_PIN, N2_V3A_MON_PIN): <= 3.0 mA per pin, <= 15 mA total into an unpowered MCU (WCH IINJ +-5 mA / sum +-25 mA); ADC still settles at 41.5 cycles (+0.42 mV per channel); protection error budget e_leg 60.30 mV (review states #1)', 'digital', 'decisions_r8c DZ-1; digital R3; protection R3.17'),
    ('added', 'R238, R239', 'CPLD JTAG pulls: JTMS 10 k pull-up to 3V3D, JTCK 10 k pull-down (X-10; states #31, pins-b B-05)', 'digital', 'X-10'),
    ('added', 'R241', 'J201 pin 1 link to 3V3M, DNF 0 ohm (WCH-LinkE 3V3 is a power output) (X-10; states #32)', 'digital', 'X-10'),
    ('added', 'C439, C440', '2.2 uF after FB301 (DVCC) and FB302 (VCCA): damps the ferrite/100 nF resonance (X-10; pins-b B-07)', 'analog', 'X-10'),
    ('added', 'D411, D412, C442, C443', 'I/V supply hold-up (X-8/DX-4): U403/U404 on N4_VPOS_IV/N4_VNEG_IV via PMEG2010AEH Schottky + KEMET T495D227K010ATE100 220 uF reservoirs: OPA2210 powered until 3V3A < 0.3 V at every hard unplug VE: C442/C443 -> Kyocera AVX TAJD227K010RNJ C8024 (analog V2); PMEG2010AEH from LCSC C110921 (V4)', 'analog', 'X-8, DX-4; analog R3'),
    ('added', 'D413, D414', 'Reverse clamps BAT54 across the polarised I/V reservoirs (DY-3)', 'analog', 'DY-3; analog R3'),
    ('added', 'R446, R447, C441', 'DNF footprints: VREF trims parallel to R431/R432 (X-10, signal F4) and 3V3A slew/pop capacitor (X-10, signal F2; DY-4 fit condition)', 'analog', 'X-10, DY-4'),
    # ---------------- added
    ('added', 'U102, R108, R109', 'Input OVP: TI TPS25200DRVR clamps 5V_SYS at 5.25-5.55 V for any VBUS < 6.8 V, disconnects above (IN 20 V abs); R108 86.6 k ILIM (IOS 1011/1120/1236 mA), R109 300 k EN from VBUS. Replaces the useless DNF TVS D102 (R8-A1/B9) VE: R108 -> 100 k Basic (IOS 870/970/1077 mA), R109 -> 470 k (U102 on 3.31-55.3 ms after attach) (power VE 1/2)', 'power', 'power D1, c01'),
    ('added', 'U103', 'CC1/CC2 ESD array TPD2E2U06DRLR at J101 (user-touchable pins had no ESD device)', 'power', 'D-8; parts P-M6; power c13'),
    ('added', 'C103', 'VBUS_SENSE capacitor 100 pF C0G 50 V 0402 at PA1 (R8-B4/D6): decision D-A (orchestrator, 25 Sep) - fast brown-out detection (action 0.05-0.12 ms after source loss, 96/96 c14 corners; with 10 nF too late in 30/96), digital TS 41.5 cycles covers the 32 kOhm source, RF filtering kept. Integration override of the frozen power BOM (10 nF)', 'power + integration (D-A)', 'D-13 superseded by D-A; power R2.7, c09, c14; digital R2.3'),
    ('added', 'Q502-Q506, R526-R530', 'Guaranteed switched discharge of 3V3A, 3V3D and 1V3 derived from the regulator enables (AO3400A inverter + discharge FET, 22 k gate pull-ups, 10/10/4.7 ohm): 3V3A <= 0.39 ms, 3V3D <= 0.63 ms, 1V3 <= 0.13 ms; replaces bleeders R524/R525 and the DOM_DIS line (R8-A4)', 'power', 'power D7, R2.9, c06'),
    ('added', 'R531, C513', 'DNF damping footprint (1 ohm + 10 uF across C507) for FB501/LM27762 input, fit only if VIN ripple > 200 mVpp (P-22 fallback)', 'power', 'power D11, c05'),
    ('added', 'U505, C515', 'TI TMUX1101DBVR switches R510 into the TPS2596 ILM pin for High mode (off-leakage 0.2 nA vs a 5 uA MOSFET bound); C515 100 nF VDD decoupling required by TI', 'power', 'D-5; power R2.3, c11'),
    ('added', 'C514', 'TPS2596 dVdt capacitor 10 nF: 3.06-5.57 V/ms, inrush <= 67 mA (129 mA with C513)', 'power', 'power R2.3, c11'),
    ('added', 'R532', '470 k pin-side pull-down on PB4/RAILS_OK_N: keeps the FT pin <= 4.78 V (VIH max 5.0 V) with PGOOD released', 'power', 'D-8; power R2.6, c13'),
    ('added', 'R533, R534', 'TLV75801P feedback 15.0 k / 11.0 k 0.1 % -> 1V3 1.2716-1.3248 V (ESS 1.235-1.365 V)', 'power', 'D-7; power R2.4, c12'),
    ('added', 'C222, C223', '100 nF decoupling for U205 (mux, now fitted) and U206 (MCLK gate)', 'digital', 'digital 12'),
    ('added', 'U206', 'Nexperia 74LVC1G11 3-input AND: X201 stand-by = MCLK_EN AND AVCC_EN AND MCLK_PERMIT -> hardware MCLK stop without firmware/SPI (R8-B3); its output N2_MCLK_OE also gates the output switch (D-19)', 'digital', 'digital R2.0, R2.1.3; D-4, D-19'),
    ('added', 'R227', '10 k XI pull-down: XI held at logic low while X201 is in stand-by (ESS standby rule)', 'digital', 'digital D3'),
    ('added', 'R228-R230', '330 ohm I2S capture taps into the MCU I2S2 slave receiver (on-board bit-perfect test, R8-B10)', 'digital', 'digital D8, 9.1'),
    ('added', 'R231', '10 k CPLD_NRST pull-up (MCU PC5 open-drain retry, R8-D4)', 'digital', 'digital D7, 4A.2'),
    ('added', 'R232', '10 k BOOT1 (PB2) pull-down so the BOOT0 pad selects the system bootloader deterministically', 'digital', 'digital 5.4'),
    ('added', 'R234', '10 k MCLK_PERMIT (PB14) pull-down at U206: X201 stops <= 0.39 us after any MCU reset (27.6 us before 3V3A can move)', 'digital', 'digital R2.1.3, mclk_gate_race'),
    ('added', 'R235', '100 k pull-down on N2_MCLK_OE (U206 output): defines X201 INH, the Q616 gate (via R645) and the PB1 readback while U206 is unpowered', 'digital', 'D-19; digital R2.0 #6'),
    ('added', 'J201, J202, TP732', 'Copper pads (no component): J201 MCU SDI/USART pads, J202 CPLD Compact-JTAG pads, TP732 PROG strap pad; were "No part" lines in v0.6, now carried in the digital BOM/netlist as fitted pads (no cost)', 'digital', 'digital 5.4, 4A.4, R2.0 #5'),
    ('added', 'FB302', 'Ferrite GZ1608D601TF on the VCCA branch: gives the VCCA net and keeps the 80 MHz XI-buffer current off the 3V3A trunk', 'analog', 'analog 0'),
    ('added', 'C431-C438', '1.8 nF C0G at the midpoint of each leg T input network (v0.8 leg network unstable with 1 nF + cable; worst PM now 51.3 deg)', 'analog', 'analog 0, 5.1, R2.2.4'),
    ('added', 'R438-R445', '680 ohm Susumu RG1608N-681-W-T1 (0.05 %, 10 ppm): second resistor of each leg T network (retuned from 665 ohm, not procurable) VE: -> YAGEO RT0603BRD07680RL 0.1 %/25 ppm C861519 (analog V1; offset 9.23/18.45 mV, Susumu = rework fallback)', 'analog', 'analog 0, R2.14'),
    ('added', 'K601-K604', 'Output switch: four Toshiba TLP3545A(TP1,F) photorelays, one per leg (LEG_xx -> JACK_xx): L+/R+-only switching disproved (12/24 plug cases fail), 4 legs isolate 24/24; Ron <= 0.06 ohm, toff <= 0.5 ms; replaces the fault latch and the proposed DPDT relay', 'protection', 'D-1; protection 3.1, R2.2'),
    ('added', 'U603, C618, C619', 'Third TLV1704 for the I/V common-mode window (failed I/V, stuck DAC pin, DAC reset, 3V3A absent) + its V+/V- decoupling (R8-C3, B2)', 'protection', 'protection 5, p04'),
    ('added', 'U604, C622, Q612, Q614, R641-R644, R662, R663', 'Photorelay LED drive: two strings from 5V_SYS, each an OPA2333 low-dropout current sink (MMBT3904 pass, 24.9 ohm 0.1 % sense, 4.7 k base) referenced to RELAY_EN via 100 k/5.1 k: IF 5.315-6.599 mA at 5V_SYS >= 4.17 V', 'protection', 'protection R2.3, p05'),
    ('added', 'Q616, Q617, R645', 'Series permits in the LED return: Q616 gate from N2_MCLK_OE via R645 1 k (any MCLK stop opens the switch, D-19), Q617 gate from permit node H', 'protection', 'D-1, D-19; protection R2.3'),
    ('added', 'Q618, R646, R647, R648, C617', 'Permit node H (R647 100 k to VPOS, C617 1 uF, 12 comparator outputs wired-OR), DC_PERMIT_N readback (Q618 + R648 to 3V3M), RELAY_EN pull-down R646', 'protection', 'protection R2.3, p05'),
    ('added', 'R649-R652', '100 k series resistors between each filter capacitor and the comparator inputs: input clamp current <= 45 uA at rail collapse (R8-B8)', 'protection', 'protection 1 (B8), p03'),
    ('added', 'R653-R656, R657-R660, C620, C621', 'CM window: 100 k 0.1 % summing resistors at the four OPA2210 outputs, 10 nF node capacitors, threshold chain 10.0 k / 6.8 k / 10.0 k from 3V3A + 330 k from VPOS (HI 2.098 V, LO 1.281 V nominal)', 'protection', 'protection 5, p04'),
    ('added', 'R661', '6.8 k 0.1 %: third resistor of the V3A_MON reference network (identical to the DC-sense networks, reading = leg - reference)', 'protection', 'protection 6, p06'),
    # ---------------- removed
    ('changed', 'D102', 'Round 3 (X-3): the useless DNF SMF6.0A (conducts only above the downstream abs max, R8-A1) is replaced by a fitted Littelfuse SMDJ12A VBUS TVS (VRWM 12 V, cathode to VBUS): U102 IN <= 17.0 V at a 5V_SYS hard short with no tIOS credit; U102 remains the OV clamp', 'power', 'decisions_r8c X-3; power R3 (c16)'),
    ('removed', 'R519, R520', '3V3D dropper deleted: TLV76733 dissipates <= 0.5 W itself', 'power', 'power 8'),
    ('removed', 'R521', 'AUD_EN series resistor deleted (TLV767 EN abs max 18 V, independent of VIN)', 'power', 'power 8'),
    ('removed', 'R307', 'AVCC_EN series resistor deleted (latch gone; LP5907 EN abs max 6 V independent of VIN)', 'power', 'power 8'),
    ('removed', 'R524, R525', 'Constant bleeders deleted (switched guaranteed discharge instead, no standing current)', 'power', 'power 8'),
    ('removed', 'C504', 'TLV767 output 1 uF redundant with C512 10 uF', 'power', 'power 8'),
    ('removed', 'C503', 'TLV767 input capacitor deleted: C501 serves U502 and U504 (attach charge 45.5 -> 39.5 uC, 21 % margin)', 'power', 'power R2.0 C10, c02'),
    ('removed', 'R514', 'RILIM series part deleted (single-resistor ILM)', 'power', 'power 8'),
    ('removed', 'R515, R516, R517, R518, R523', 'LM27762 feedback top-resistor combinations replaced by single 0.1 % parts R501/R503 (D-6)', 'power', 'power 8; D-6'),
    ('removed', 'Q501', '2N7002 ILIM switch replaced by U505 TMUX1101 (IDSS bound would shift the Default limit up to 5.2 %)', 'power', 'power R2.11; D-5'),
    ('removed', 'R638, D605, D606', 'TPS2553 FAULT -> latch path deleted (R8-A2 threshold problem moot); FAULT/FLT goes to the MCU only', 'protection', 'protection 0; brief 3.7'),
    ('removed', 'Q601-Q611, R611-R617, R623, C605, C606, C607', 'Hardware fault latch, kill FETs, blanking and interlock networks deleted: the output switch + permit node H need no latch (brief 3.7)', 'protection', 'protection 0, 13'),
    ('removed', 'R618', 'AMP_EN kill resistor deleted (AMP_EN retired, OPA1622 EN tied to VPOS)', 'protection', 'protection 0; D-11'),
    ('removed', 'R636, R637', 'Series threshold resistor parts deleted (single E96 0.1 % dividers R607-R610)', 'protection', 'protection 0'),
    ('removed', 'R306', 'ADDR strap resistor deleted: ADDR pin tied to GND directly (address 0x48)', 'analog', 'analog 0, 16'),
    ('removed', 'R421', 'AMP_EN pull-down deleted (EN pin 8 tied to VPOS, D-11)', 'analog', 'analog 16'),
    ('removed', 'R427-R430', '10 ohm in series with Cf deleted (no stability benefit: 68.2 vs 66.8 deg)', 'analog', 'analog 5.2, 16'),
    ('removed', 'R433', 'VREF option resistor deleted (single 0.1 % VREF divider)', 'analog', 'analog 16'),
    ('removed', 'R434-R437, C427-C430', 'Parallel Rf parts (5.1 k) and second 330 pF Cf deleted: single Rf 698 ohm 0.1 % and Cf 820 pF C0G', 'analog', 'analog 0, 16'),
    ('removed', 'R308', 'RESETB series resistor retired from block 3; the function moved to the MCU-pin side as R233 4.7 k (digital). Not listed as removed by any stream report (integration note, consistency_log)', 'analog/digital', 'digital R2.0 #3; integration'),
    ('removed', 'R214', 'Shared family-clock node pull-down deleted: the 2:1 mux U205 is fitted instead (no contention in any state)', 'digital', 'digital D2'),
    ('removed', 'C216', 'CPLD decoupling retired: the QFN-32 has 3 supply pins (6, 16, 32), covered by C213-C215', 'digital', 'digital 4A.3'),
    # ---------------- changed (part number / value / fit)
    ('changed', 'J101', 'SHOU HAN 16P (5 V rating) -> GCT USB4105-GF-A (48 V / 5 A, SMT + 4 shell stakes, pin-in-paste; pads by contact name)', 'power', 'D-8; parts P-M4; power R2.5'),
    ('changed', 'C102', '1 uF -> 4.7 uF 25 V 0805: cable-inductance kick at U102 IN <= 18.7 V in a hard short (1 uF: 22-30 V > 20 V abs)', 'power', 'power D4, c01'),
    ('changed', 'C301, C302', '1 uF -> 2.2 uF 16 V 0603: LP5907 CIN/COUT >= 0.7 uF effective (was 0.71/0.75 uF)', 'power', 'D-8; parts P-M2'),
    ('changed', 'U303', 'Microne ME6216A13 -> TI TLV75801PDBVR (full datasheet limits, EN = AUD_EN, 1V3 1.2716-1.3248 V)', 'power', 'D-7; power R2.4'),
    ('changed', 'U502', 'Microne ME6211 -> TI TPS7A2033PDBVR (3V3M, IQ <= 15 uA for suspend, +-1.5 %)', 'power', 'power D6'),
    ('changed', 'U504', 'Microne ME6211 + dropper -> TI TLV76733DRVR (3V3D, 1 A, 18 V abs, no dropper; R8-D10 dropout)', 'power', 'power D6'),
    ('changed', 'U503', 'TI TPS2553DBVR -> TI TPS259621DDAR (auto-retry eFuse, ILM +-10.4 %, FLT = thermal/ILM short only)', 'power', 'D-5; power R2.3'),
    ('changed', 'C505', '1 uF -> 100 nF (TPS2596 CIN at pin 4; attach-charge budget)', 'power', 'power 8, R2.11'),
    ('changed', 'R501, R502, R503, R504', 'Single 0.1 % thin-film LM27762 feedback 221 k / 100 k (VPOS 3.789/3.852/3.915 V) and 205 k / 100 k (|VNEG| 3.661/3.721/3.781 V)', 'power', 'D-6; power D11'),
    ('changed', 'R505', '10 k -> 100 k PGOOD pull-up to 5V_ANA_F (55 uA; no latch timing needed)', 'power', 'power 5.5'),
    ('changed', 'R508', '100 k -> 47 k AUD_EN pull-down (TLV767 internal EN pull-up); also holds the U303 EN', 'power', 'power 8, R2.11'),
    ('changed', 'R509', '100 k -> 4.75 k 0.1 % 25 ppm Susumu RG1608P (TPS2596 Default ILM: IOS 180.1/201.3/222.6 mA; 4.87 k if the NDK X201 second source is fitted) VE: 4.81 k 0.1 % KOA RN73R1JTTD4811B25 owner-fitted (DigiKey; power VE 6)', 'power', 'D-5; power R2.2, c03'),
    ('changed', 'R510', '100 k -> 3.83 k 0.1 % (High ILM via U505: IOS 390.4/437.1/483.4 mA)', 'power', 'D-5; power R2.2, c03'),
    ('changed', 'X201', 'SCTF SX3M80 (40 mA, OE only) -> Kyocera KC2520K80.0000C1GE00 80.000 MHz (8.0 mA max loaded over T, stand-by = oscillation stop, t_dis <= 200 ns); combined 2520/3225 land', 'digital', 'D-3 revised; digital R2.1'),
    ('changed', 'X202, X203', '24.576 / 22.5792 MHz -> NDK NZ2520SDA 49.152 / 45.1584 MHz with true stand-by: BCLK by binary division, CPLD PLL not used', 'digital', 'brief 3.5; D-4; digital D1'),
    ('changed', 'U205, R215, R216, R217', 'DNF -> fitted: 74LVC1G157 family-clock mux replaces the shared node (break-before-make no longer safety-relevant)', 'digital', 'digital D2'),
    ('changed', 'C217', '100 nF -> 10 nF HF bypass at the X201 VCC pad (Kyocera: 0.01 uF at the nearest position)', 'digital', 'digital R2.0 #12'),
    ('changed', 'R207, R208', 'I2C pull-ups 2.2 k -> 10 k at 100 kHz (final pass DZ-2: ES9018K2M VOL is specified only at 100 uA; sink <= 0.34 mA; tr 257/428/856 ns at 30/50/100 pF, standard mode; round 2 had 4.7 k)', 'digital', 'decisions_r8c DZ-2; digital R3'),
    ('changed', 'R212, R213, R218', 'Enable pull-downs 2.2 k -> 10 k (no longer safety-critical; 0.34 mA each instead of 1.54 mA, R8-D2)', 'digital', 'digital D10'),
    ('changed', 'C303, C304, C310', '2.2 uF 0402 6.3 V -> 2.2 uF 0603 16 V X5R (less DC-bias loss)', 'analog', 'analog 0'),
    ('changed', 'R423-R426', '1 k (+ 5.1 k in parallel) -> single Rf 698 ohm 0.1 % (lowest-gain unit still reaches 1.55 Vrms; I/V never saturates)', 'analog', 'analog 0'),
    ('changed', 'C417-C420', '2 x 330 pF -> single Cf 820 pF C0G (KEMET)', 'analog', 'analog 0'),
    ('changed', 'R431, R432', '15 k / 15 k (+ 1 k option) -> 9.76 k / 10.0 k 0.1 %: VREF = 0.50607 x 3V3A (midpoint of the ESS null range)', 'analog', 'analog 0'),
    ('changed', 'R401-R416', '2.00 k 0.1 % -> leg T network: odd refs 1.30 k, even refs 2.00 k, all Susumu RG1608N 0.05 % / 10 ppm (stability with 0-1 nF + cable; offset 6.24/12.48 mV); LCSC 0.1 % fallbacks C705738 / C728588 on the same footprint VE: -> YAGEO RT0603BRD071K3L (1.30 k) / Panasonic ERA-3AEB202V (2.00 k) 0.1 %/25 ppm LCSC (analog V1)', 'analog', 'analog 0, R2.14'),
    ('changed', 'C401-C408', '330 pF across R2/R4 -> 10 pF C0G lead capacitors (v0.8 leg network unstable with 1 nF: PM -8.7 deg)', 'analog', 'analog 0, 5.1'),
    ('changed', 'D405-D408', 'JSMSEMI BAT54S on the DAC pins -> Nexperia BAT54S,215 on the four OPA2210 outputs (no leakage/capacitance at the virtual ground; pins bounded -0.42 V ... AVCC + 0.42 V)', 'analog', 'analog 0, 6; D-17'),
    ('changed', 'U601, U602', 'TI LM339DR -> TI TLV1704AIPWR (rail-to-rail inputs, <= 100 uA/ch, IB <= 20 nA; TSSOP-14 LM339 pinout)', 'protection', 'D-9; protection 4.1'),
    ('changed', 'R601-R604', '100 k -> 105 k: single-pole window filter tau 231 ms (194-258 ms) with C601-C604', 'protection', 'protection 4.3'),
    ('changed', 'C601-C604', '1 uF -> 2.2 uF 16 V X5R 0603 (filter tau 231 ms)', 'protection', 'protection 4.3'),
    ('changed', 'R607, R608, R609, R610', 'Window thresholds from single E96 0.1 % 25 ppm dividers 121 k / 115 k over 10.0 k: +-0.298 V nominal, trip +-0.276...+-0.320 V worst case', 'protection', 'protection 4.2'),
    ('changed', 'R624-R635', 'DC-sense networks redesigned: 6.8 k (R_S) / 5.1 k (R_U to 3V3A) / 16.9 k (R_D) 0.1 % 25 ppm, node = 0.4874 x 3V3A + 0.3655 x leg, R_TH 2.49 k', 'protection', 'protection 6, p06'),
    ('changed', 'C608-C611', '2.2 uF 6.3 V 0402 -> 4.7 uF 25 V X5R 0805 (DC-bias robust sense nodes, tau 8.4-12.9 ms)', 'protection', 'protection 6'),
    ('changed', 'R639, R640, C616', '3V3A monitor (10 k / 10 k / 100 nF) -> reference network identical to the sense networks (5.1 k / 16.9 k + R661 6.8 k, 4.7 uF): V3A_MON = 0.4874 x 3V3A, ADC offset cancels in leg - reference', 'protection', 'protection 6'),
]

rows, covered = [], set()
for change, refs, reason, stream, src in G:
    ds = expand(refs)
    for x in ds:
        assert x not in covered, x
        covered.add(x)
    o = [old[x] for x in ds if x in old]
    n = [new[x] for x in ds if x in new]
    def fmt(lst):
        seen = []
        for e in lst:
            s = f"{e['mpn']} ({e['value']}, {e['fit']})" if e['fit'] and not e['fit'].startswith('Yes') else f"{e['mpn']} ({e['value']})"
            if s not in seen:
                seen.append(s)
        return '; '.join(seen)
    rows.append(dict(change=change, designators=compress(ds), qty_per_board=len(ds),
                     v06_part=fmt(o) if o else ('No part (pad)' if change == 'added' and refs.startswith('J201') else '-'),
                     v07_part=fmt(n) if n else '-', reason=reason, stream=stream, source=src))

# no-part / layout lines of the Parts List
rows.append(dict(change='changed', designators='TP701-TP731, TP733-TP753', qty_per_board=52,
                 v06_part='No part: TP701-TP732 (32 pads, Notes 3.8 allocation)', v07_part='No part: 52 pads (layout_package.md section 11; TP746-TP753 round 3); TP732 moved to the digital BOM',
                 reason='Test-pad allocation re-used for retired nets (TP718 RELAY_EN, TP722 DC_PERMIT_N, TP724 N6_H) and extended with TP733-TP745 (CM nodes, N2_MCLK_OE, VBUS, ENs, LED-string currents). Not yet netlisted: add as 1-pin pads (integration action A-1)',
                 stream='parts (layout)', source='layout_package.md 11'))
rows.append(dict(change='changed', designators='MH, FID', qty_per_board=11, v06_part='No part: 4 mounting holes + 3 fiducials',
                 v07_part='No part: 4 mounting holes + 3 global + 4 local fiducials (2 at U202, 2 at U201)',
                 reason='Standard PCBA with 0.4 mm-pitch QFN and 0.5 mm LQFP: local fiducials added; rail fiducials/tooling holes by JLCPCB',
                 stream='parts (layout)', source='layout_package.md 12'))
rows.append(dict(change='changed', designators='PCB', qty_per_board=1, v06_part='4 layers, <= 80 x 60 mm, 90 ohm USB pair',
                 v07_part='4-layer JLC04161H-7628, ENIG, 80 x 60 mm + 2 x 5 mm V-cut rails (80 x 70 mm panel), epoxy-filled/capped EP vias',
                 reason='JLCPCB Standard PCBA top side needs a >= 70 x 70 mm panel with rails and fiducials (D-14)', stream='parts (layout)', source='D-14; layout_package.md 1'))

# coverage check
diff_refs = set()
for x in set(new) | set(old):
    if x not in old or x not in new:
        diff_refs.add(x)
    else:
        o, n = old[x], new[x]
        if o['mpn'].strip() != n['mpn'].strip() or o['fit'][:3] != n['fit'][:3]:
            diff_refs.add(x)
missing = sorted(diff_refs - covered, key=natkey)
extra = sorted(covered - diff_refs - {'J201', 'J202', 'TP732'}, key=natkey)
print('designators with a difference:', len(diff_refs), '| covered:', len(covered & diff_refs), '| missing:', missing, '| covered but unchanged:', extra)
# R9: designators not covered by a hand-written group get an automatic group (reason = the current BOM description)
if missing:
    newrows = {}
    for r in csv.DictReader(open(f'{OUT}/bom_merged.csv', encoding='utf-8')):
        for d in expand(r['refs']) if r['refs'] not in ('PCB', 'MH, FID') else []:
            newrows[d] = r
    auto = {}
    for x in missing:
        chg = 'added' if x not in old else ('removed' if x not in new else 'changed')
        r = newrows.get(x)
        desc = (r['description'] if r else old.get(x, {}).get('mpn', ''))
        key = (chg, desc, (r['stream'] if r else '-'))
        auto.setdefault(key, []).append(x)
    for (chg, desc, stream), ds in auto.items():
        o = [old[x] for x in ds if x in old]; n = [new[x] for x in ds if x in new]
        rows.append(dict(change=chg, designators=compress(ds), qty_per_board=len(ds),
                         v06_part='; '.join(sorted({f"{e['mpn']} ({e['value']})" for e in o})) or '-',
                         v07_part='; '.join(sorted({f"{e['mpn']} ({e['value']})" for e in n})) or '-',
                         reason='R9 (auto from the BOM description): ' + desc, stream=stream, source='r9/decisions_r9.md; stream R9 fixes'))
        covered.update(ds)
    missing = sorted(diff_refs - covered, key=natkey)
assert not missing, missing

order = {'added': 0, 'removed': 1, 'changed': 2}
rows.sort(key=lambda r: (order[r['change']], r['stream'], natkey(expand(r['designators'].replace('MH, FID', 'MH1').replace('PCB', 'PCB1'))[0])))
with open(f'{OUT}/bom_changes_vs_v06.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['change', 'designators', 'qty_per_board', 'v06_part', 'v07_part', 'reason', 'stream', 'source'])
    w.writeheader()
    w.writerows(rows)
tot = {c: sum(r['qty_per_board'] for r in rows if r['change'] == c and r['stream'] != 'parts (layout)') for c in order}
print('rows', len(rows), '| designators added', tot['added'], '(incl. J201, J202, TP732 pads) | removed', tot['removed'], '| changed', tot['changed'])


# ---------------- R9: changes vs the v0.9 document set (bom_merged of 25 Sep 16:06, kept in _work/r3/bom_merged_pre_R9.csv)
V09 = f'{OUT}/_work/r3/bom_merged_pre_R9.csv'
if os.path.exists(V09):
    def by_ref(path):
        m = {}
        for r in csv.DictReader(open(path, encoding='utf-8')):
            if r['refs'] in ('PCB', 'MH, FID') or r['mpn'] == 'No part':
                continue
            for d in expand(r['refs']):
                m[d] = r
        return m
    a09, a10 = by_ref(V09), by_ref(f'{OUT}/bom_merged.csv')
    grp = {}
    for d in set(a09) | set(a10):
        o, n = a09.get(d), a10.get(d)
        if o and n and o['mpn'].strip() == n['mpn'].strip() and o['value'].strip() == n['value'].strip() and o['fit'][:3] == n['fit'][:3] \
                and ('owner' in o['note'].lower()) == ('owner' in n['note'].lower()):
            continue
        chg = 'added' if not o else ('removed' if not n else 'changed')
        key = (chg, (o['mpn'] + ' (' + o['value'] + ')') if o else '-', (n['mpn'] + ' (' + n['value'] + ')') if n else '-', (n or o)['stream'])
        grp.setdefault(key, []).append(d)
    out = []
    for (chg, ov, nv, st), ds in sorted(grp.items(), key=lambda kv: (kv[0][0], natkey(sorted(kv[1], key=natkey)[0]))):
        r = a10.get(ds[0]) or a09.get(ds[0])
        out.append(dict(change=chg, designators=compress(sorted(ds, key=natkey)), qty_per_board=len(ds), v09_part=ov, v10_part=nv,
                        reason=(r['description'][:200] if r else ''), stream=st))
    with open(f'{OUT}/bom_changes_vs_v09.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['change', 'designators', 'qty_per_board', 'v09_part', 'v10_part', 'reason', 'stream'])
        w.writeheader(); w.writerows(out)
    from collections import Counter
    c = Counter()
    for x in out:
        c[x['change']] += x['qty_per_board']
    print(f'vs v0.9 set: rows {len(out)} | designators added {c["added"]} | removed {c["removed"]} | changed {c["changed"]}')
