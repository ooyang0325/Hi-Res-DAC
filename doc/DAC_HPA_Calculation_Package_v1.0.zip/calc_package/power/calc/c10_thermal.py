"""c10 - Thermal table for all power-stream parts (R8 round 2) at VBUS up to 5.5 V (5V_SYS <= 5.5 V; clamp cases noted), 50 C ambient
+ 10 C local board rise [ASSUMP], theta_JA from the datasheets (JEDEC boards; our 4-layer board with pours is similar or better).
Currents from c03_results.json."""
import json, os
from pw_common import *
out = []
P = out.append
R = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c03_results.json")))
TA = TA_MAX + T_LOCAL_RISE
V5 = 5.50
ro = R["RO_S2"]
I_TOT_H = R["T_HIGH"]; I_ANA_H = R["HIGH"][2]; I_ANA_D = R["DEF"][2]
rows = []
def add(ref, part, cond, pd, theta, tjmax, note=""):
    rows.append((ref, part, cond, pd, theta, TA + pd * theta, tjmax, note))
add("U102", "TPS25200", f"{I_TOT_H*1e3:.0f} mA (High) through Ron 99 mOhm", I_TOT_H**2 * TPS25200["RON_MAX"], TPS25200["THETA_JA"], 125)
add("U102", "TPS25200", f"clamp: VBUS 5.50 V, VOUT 5.25 V (clamp min), {I_TOT_H*1e3:.0f} mA", (5.5 - 5.25) * I_TOT_H + I_TOT_H**2 * 0.099,
    TPS25200["THETA_JA"], 125, "in-spec worst")
add("U102", "TPS25200", f"clamp: VBUS 6.79 V (just below OVLO min), {I_TOT_H*1e3:.0f} mA", (6.79 - 5.25) * I_TOT_H, TPS25200["THETA_JA"], 155,
    "out-of-spec source: OTSD2 >= 155 C cycles, self-protected")
add("U502", "TPS7A20", f"5.5 -> 3.25 V, {ro['3V3M']*1e3:.1f} mA", (V5 - 3.25) * ro["3V3M"] + V5 * 0.0006, TPS7A20["THETA_JA"], 125)
add("U504", "TLV767", f"5.5 -> 3.27 V, {ro['3V3D']*1e3:.1f} mA (no relay coil any more)", (V5 - 3.267) * ro["3V3D"] + V5 * 0.0004,
    TLV767["THETA_JA"], 125)
add("U504", "TLV767", "S5 programming: +2nd NDK +0.34 mA, 158.6 mA", (V5 - 3.267) * 0.1586 + V5 * 0.0004, TLV767["THETA_JA"], 125)
add("U302", "LP5907", f"5.5 -> 3.23 V, {ro['3V3A']*1e3:.1f} mA", (V5 - 3.234) * ro["3V3A"] + V5 * 5.5e-5, LP5907["THETA_JA"], 125)
add("U303", "TLV758P", "3.33 -> 1.27 V, 60 mA", (3.333 - 1.2716) * 0.060 + 3.333 * 35e-6, TLV758P["THETA_JA"], 125,
    "<= 85 C keeps the +-1 % accuracy row")
add("U503", "TPS2596", f"High {I_ANA_H*1e3:.0f} mA through 131 mOhm", I_ANA_H**2 * TPS2596["RON_MAX"] + V5 * TPS2596["IQ_ON_MAX"],
    TPS2596["THETA_JA"], 125)
add("U503", "TPS2596", f"Default short on 5V_ANA: 5.55 V x {I_ANA_D*1e3:.0f} mA", 5.55 * I_ANA_D, TPS2596["THETA_JA"], 125,
    "below TSD 157 C typ: sits in limit, FLT not asserted -> firmware rule (c11)")
add("U503", "TPS2596", f"High short on 5V_ANA: 5.55 V x {I_ANA_H*1e3:.0f} mA", 5.55 * I_ANA_H, TPS2596["THETA_JA"], 157,
    "thermal shutdown + auto-retry (FLT low while off)")
add("U501", "LM27762", f"upper bound: {I_ANA_H*1e3:.0f} mA into the lower rail at 5.5 V", I_ANA_H * (5.5 - 3.661) + 5.5 * 390e-6,
    LM27762["THETA_JA"], 125, "overload bound; clean loads lower")
add("U505", "TMUX1101", "<= 0.21 mA through <= 9.5 ohm, IDD 0.65 uA", (0.21e-3)**2 * 9.5 + 3.35 * 0.65e-6, TMUX1101["THETA_JA_DBV"], 125)
add("U103", "TPD2E2U06", "CC shorted to 5.55 V: <= 12.6 uA leakage", 5.55 * 12.6e-6, TPD2E2U06["THETA_JA"], 125, "fault case")
add("FB501", "BLM18PG121SN1D", f"{I_ANA_H*1e3:.0f} mA, 50 mOhm", I_ANA_H**2 * 0.05, 0.0, 125, "2 A rated [DS]")
P(hdr("Thermal table (TA = 50 C + 10 C local)"))
P(f"{'ref':6s} {'part':15s} {'condition':56s} {'Pd W':>7s} {'thJA':>6s} {'TJ C':>7s} {'limit':>6s} {'margin':>7s}  note")
for r in rows:
    if r[5] > r[6] + 40:
        P(f"{r[0]:6s} {r[1]:15s} {r[2]:56s} {r[3]:7.3f} {r[4]:6.1f} {'cycles':>7s} {r[6]:6.0f} {'TSD':>7s}  {r[7]}")
    else:
        P(f"{r[0]:6s} {r[1]:15s} {r[2]:56s} {r[3]:7.3f} {r[4]:6.1f} {r[5]:7.1f} {r[6]:6.0f} {r[6]-r[5]:+7.1f}  {r[7]}")
P("\nResistors (power at 5.5 V / worst):")
P(f"  R105 100k 0402: {5.5**2/100e3*(100/147)**2*1e3:.3f} mW | R106 47k: {(5.5*47/147)**2/47e3*1e3:.3f} mW (rating 62.5 mW)")
P("  R527/R529 10 ohm 0603, R530 4.7 ohm 0603 (discharge): transient only, <= 0.1 mJ per event, peak <= 1.2 W for < 50 us; 0 W"
  " continuous (EN-derived gate: never on with the regulator enabled; U303 EN = AUD_EN)")
P(f"  R505 100k: {5.5**2/100e3*1e3:.2f} mW; R512 100k: {3.35**2/100e3*1e3:.3f} mW (fault only); R532 470k: {4.78**2/470e3*1e3:.3f} mW")
P("  R509/R510 (ILM): <= 0.2 mA x 0.6 V -> < 0.2 mW; R533/R534: < 0.1 mW; C514 dVdt: <= 2.5 V")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
