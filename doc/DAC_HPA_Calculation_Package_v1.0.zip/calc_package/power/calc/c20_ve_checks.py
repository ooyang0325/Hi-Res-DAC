"""c20 - VE round (25 Sep 2026): re-verification of the adopted drop-in value changes.
 (a) R108 86.6 k -> 100 k (Basic C25741): U102 TPS25200 IOS vs the S4 High total, kick/credit effects
 (b) R109 300 k -> 470 k (C25790, same type as R532): C104 turn-on window, EN level at VBUS 4.40 V
 (c) R535/R536 68.1 k/30.1 k -> 100 k/47 k (Basic C25741/C25792, same types as R105/R106): X-5 limits
Labels as in pw_common."""
import json, math, os
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
S = json.load(open(os.path.join(HERE, "c17_results.json")))["S"]
out = []; P = out.append
P(hdr("a) R108 = 100 kOhm (was 86.6 k): TPS25200 current limit [DS Eq.1], R 1 %"))
for rk in (86.6, 100.0):
    mn = tps25200_ios(rk * 1.01)[0]; nm = tps25200_ios(rk)[1]; mx = tps25200_ios(rk * 0.99)[2]
    P(f"  R108 {rk:5.1f} k: IOS {mn*1e3:6.0f} / {nm*1e3:6.0f} / {mx*1e3:6.0f} mA (min uses R +1 %, max R -1 %)")
mn100 = tps25200_ios(100 * 1.01)[0]; mx100 = tps25200_ios(100 * 0.99)[2]
P(f"  vs S4 High total {S['S4']:.1f} mA: margin {mn100*1e3 - S['S4']:+.0f} mA (>= 0 required; round 2 had 1011 mA -> +253 mA) [CALC c17 S4]")
P(f"  Hard-short kick (c16 C): after the interruption U102 passes <= IOS max -> {mx100*1e3:.0f} mA instead of 1236 mA (lower = less stored energy)"
  " -> the D102 clamp result (<= 16.99 V) is unchanged or lower; the worst corner is the steady-state current before the interruption.")
QB = 40.2e-6
P(f"  Attach region B credit (c16 B): Q x (1 - 0.1 A / IOS max) = {QB*(1-0.1/mx100)*1e6:.1f} uC (was 37.0 uC with 1236 mA); no-credit bound 40.2 uC unchanged.")
P(f"  Thermal: U102 in current limit only in a fault; lower IOS -> lower dissipation. TPS25200 RILIM range 33 k..1100 k [DS] -> 100 k inside.")
P(hdr("b) R109 = 470 kOhm (was 300 k), C104 100 nF X7R: U102 EN window [DS 5.5 thresholds 0.6/1.9 V, IEN +-2 uA]"))
def t_cross(vb, i_out, r, c, vth):
    veff = vb + i_out * r
    return float("inf") if veff <= vth else -r * c * math.log(1 - vth / veff)
for r in (300e3, 470e3):
    te = t_cross(5.50, 2e-6, r * 0.99, 100e-9 * 0.9 * 0.85 * 0.95, 0.6)
    tl = t_cross(4.40, -2e-6, r * 1.01, 100e-9 * 1.1 * 1.15, 1.9) + TPS25200["TON_MAX"]
    ven = 4.40 - 2e-6 * r * 1.01
    P(f"  R109 {r/1e3:.0f} k: earliest U102 turn-on {te*1e3:5.2f} ms (>= 1 ms), latest 5V_SYS up {tl*1e3:5.1f} ms, EN steady at VBUS 4.40 V and"
      f" 2 uA into the pin {ven:.2f} V (>= 1.9 V)")
P("  470 k: earliest 3.3 ms (region separation >= 3.0 ms), latest ~55 ms + TPS7A20 1.15 ms + MCU boot -> D+ pull-up < TSIGATT 100 ms"
  " (USB 2.0 7.1.7.3) with >= 30 ms margin [ASSUMP MCU boot <= 10 ms]; 20 V fault: EN Zener current (20 - 6.4)/470 k = 29 uA (TI: >= 300 k).")
P(hdr("c) ANA_SENSE R535/R536 = 100 k / 47 k (was 68.1 k / 30.1 k), 1 %, C516 100 pF C0G"))
r1, r2, tol = 100e3, 47e3, 0.01
kmax = r2 * (1 + tol) / (r2 * (1 + tol) + r1 * (1 - tol)); kmin = r2 * (1 - tol) / (r2 * (1 - tol) + r1 * (1 + tol)); knom = r2 / (r1 + r2)
rth = r1 * r2 / (r1 + r2)
code = 4.00 * knom / 3.3 * 4096
P(f"  k {kmin:.4f} / {knom:.4f} / {kmax:.4f}; 5.55 V -> <= {5.55*kmax:.4f} V (<= 1.8 V, margin {(1.8-5.55*kmax)*1e3:.1f} mV); source {rth/1e3:.1f} k (<= 40 k);"
  f" load {5.55/(r1+r2)*1e6:.1f} uA (was 56.5 uA)")
P(f"  Firmware threshold 4.00 V -> {4.00*knom:.3f} V = {code:.0f} counts (was 1.226 V / 1522); true 5V_ANA_F band at that code"
  f" {3.3*0.985*code/4096/kmax:.2f} .. {3.3*1.015*code/4096/kmin:.2f} V (ADC error ignored); c18 T_START used 4.12 V as the worst reading edge"
  " -> unchanged within 0.01 V; tau 32 k x 112 pF = 3.6 us.")
P("  Default need: ANA_SENSE share 57 -> 38 uA (-0.019 mA) -> R509 4.81 k margin to the need +0.97 -> +0.99 mA; S2-S5 -0.02 mA (c17 not re-run: favourable).")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
