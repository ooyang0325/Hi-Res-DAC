"""c04 - Regulator checks (R8 round 2): 5V_SYS range, LDO dropout at the 4.40 V corner, EN thresholds, output capacitors,
LM27762 single-resistor feedback (0.1 %), peak-current headroom at 4.40 / 4.60 V with the TPS2596 limits (c03_results.json)."""
import json, os
from pw_common import *

out = []
P = out.append
R = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c03_results.json")))
R_TR1, R_TR2 = 0.020, 0.010          # [ASSUMP] PCB copper J101->TPS25200->loads, U503->FB501->LM27762
R_FB = 0.050                         # [DS] BLM18PG121SN1D DC resistance max
R_J101_PATH = 0.040 / 4             # [DS GCT] 40 mOhm max initial per contact; a USB-C plug mates 4 VBUS + 4 GND contacts
R_J101 = 0.0                         # convention (round 1, other streams): VBUS 4.40 V is specified at the J101 pads
I_NONANA = R["NONANA"]
IOS_DEF_MAX, IOS_HIGH_MAX = R["DEF"][2], R["HIGH"][2]
RON_U503 = TPS2596["RON_MAX"]        # [DS] 131 mOhm, VIN > 4 V, -40..125 C

P(hdr("1. 5V_SYS range at the VBUS corners (VBUS at the J101 pads; TPS25200 Ron 99 mOhm + 20 mOhm copper)"))
cases = []
for vb in (VBUS_MIN, VBUS_DES, 5.0, VBUS_MAX):
    for mode, ia in (("Default", IOS_DEF_MAX), ("High", IOS_HIGH_MAX)):
        itot = I_NONANA + ia + R["IQ2596"]
        v5 = min(vb - itot * 2 * R_J101, TPS25200["VOVC_MAX"]) - itot * (TPS25200["RON_MAX"] + R_TR1)
        vin_lm = v5 - ia * (RON_U503 + R_FB + R_TR2)
        cases.append((vb, mode, itot, v5, vin_lm))
        P(f"VBUS {vb:4.2f} V {mode:7s}: I_total {itot*1e3:5.0f} mA -> 5V_SYS {v5:5.3f} V ; LM27762 VIN {vin_lm:5.3f} V (I_ana {ia*1e3:.0f} mA)")
v5min = min(c[3] for c in cases)
ihi = [c for c in cases if c[0] == VBUS_MIN and c[1] == "High"][0][2]
P(f"J101 GCT USB4105: 40 mOhm max initial / 50 mOhm after test per contact [DS]; a plug mates 4 VBUS + 4 GND contacts -> <= "
  f"{2*R_J101_PATH*1e3:.0f} mOhm loop -> <= {2*R_J101_PATH*ihi*1e3:.0f} mV at {ihi*1e3:.0f} mA. Convention kept from round 1: the 4.40 V"
  f" corner is at the J101 pads; if it were before the mated contacts, 5V_SYS min = {v5min - 2*R_J101_PATH*ihi:.3f} V (sensitivity).")
P("Upper bound: 5V_SYS <= 5.50 V in-spec, <= 5.55 V (U102 clamp max) for any VBUS below V(OVLO).")

P(hdr("2. LDO headroom at the minimum 5V_SYS"))
ro = R["RO_S2"]
ldos = [("U502 TPS7A20 3V3M", 3.3 * (1 + TPS7A20["ACC"]), ro["3V3M"], TPS7A20["VDO300_MAX"] * ro["3V3M"] / 0.300,
         "VDO 145 mV max at 300 mA [DS], scaled linearly"),
        ("U504 TLV767 3V3D", 3.3 * (1 + TLV767["ACC"]) + ro["3V3D"] * 0.005 * 3.3, ro["3V3D"],
         TLV767["VDO_1A_MAX_DRV"] * ro["3V3D"], "VDO 1.4 V max at 1 A (DRV) [DS], scaled linearly"),
        ("U302 LP5907 3V3A", 3.3 * (1 + LP5907["ACC"]), ro["3V3A"], LP5907["VDO250_MAX"] * ro["3V3A"] / 0.25,
         "VDO 250 mV max at 250 mA [DS]; +-2 % spec needs VIN >= VOUT + 1 V = 4.30 V")]
for n, vo, io, vdo, note in ldos:
    need = vo + vdo
    P(f"{n:22s} Vout max {vo:5.3f} V at {io*1e3:6.1f} mA, VDO {vdo*1e3:4.0f} mV -> needs {need:5.3f} V; 5V_SYS min {v5min:5.3f} V ->"
      f" margin {v5min-need:+5.3f} V ({note})")
P(f"LP5907 +-2 % accuracy test condition VIN >= 4.30 V; 5V_SYS min {v5min:.3f} V (High, 4.40 V corner) - "
  f"{'inside' if v5min >= 4.30 else 'BELOW (regulation headroom still > 0.9 V; accuracy test condition missed by %.0f mV)' % ((4.30 - v5min)*1e3)}.")
v3d_min = 3.3 * (1 - TLV767["ACC"]) - ro["3V3D"] * 0.005 * 3.3
P(f"U303 TLV758P 1V3 from 3V3D: VIN {v3d_min:.3f}..{3.3*(1+TLV767['ACC']):.3f} V, VOUT <= 1.326 V -> headroom >= {v3d_min-1.326:.2f} V"
  f" vs VDO <= {TLV758P['VDO_500_12_15'][1]*1e3:.0f} mV at 500 mA (1.2 <= VOUT < 1.5 V) [DS] (~50 mV at 60 mA)")

P(hdr("3. Enable / logic thresholds vs drivers (MCU GPIO VOH >= 2.85 V; VOL <= 0.40 V at 8 mA [ASSUMP digital] -> <= 0.05 V at the"
      " <= 0.2 mA EN loads (ohmic scaling) [CALC])"))
VOL_REAL = 0.05
rows = [("U504 TLV767 EN (AUD_EN)", TLV767["VEN_HI_MAX"], TLV767["VEN_LO_MIN"], "R508 47 k vs 0.4 uA typ internal pull-up -> 19 mV"),
        ("U303 TLV758P EN (AUD_EN)", TLV758P["VEN_HI_MAX"], TLV758P["VEN_LO_MIN"], "IEN 10 nA typ; EN abs 6.5 V independent of VIN [DS]"),
        ("U302 LP5907 EN (AVCC_EN)", LP5907["VIH"], LP5907["VIL"], "R303 100 k + internal 1 MOhm pull-down"),
        ("U503 TPS2596 EN/UVLO (ANA_EN) on/off", TPS2596["VUVLO_R_MAX"], TPS2596["VUVLO_F_MIN"],
         "rising 1.18-1.22 V, falling 1.08-1.13 V; EN leakage 0.1 uA x R513 100 k = 10 mV [DS]"),
        ("U503 TPS2596 EN below VSD (lowest ISD, fault reset)", TPS2596["VUVLO_R_MAX"], TPS2596["VSD_MIN"], "VSD 0.53-1.05 V [DS]"),
        ("U505 TMUX1101 SEL (ILIM_HI)", TMUX1101["VIH_3V3"], TMUX1101["VIL_3V3"], "VDD 3V3M; R511 100 k; PA15 = GPIO at reset [digital]"),
        ("U501 LM27762 EN+/EN- (RAIL_EN via R507)", LM27762["VEN_IH"], LM27762["VEN_IL"], "R506 100 k; EN <= VIN rule"),
        ("U502 TPS7A20 EN (tied to 5V_SYS)", TPS7A20["VEN_HI_MAX"], 0.40, "always on"),
        ("U102 TPS25200 EN (300 k from IN)", TPS25200["VEN_ON_MAX"], TPS25200["VEN_OFF_MIN"], "EN >= VIN - 0.6 V"),
        ("AO3400A inverter gates (AVCC_EN / AUD_EN)", 2.5, AO3400A["VTH_MIN"], "Rds(on) <= 48 mOhm at VGS 2.5 V [DS]"),
        ("AO3400A discharge gates (22 k from 3V3M)", 2.5, AO3400A["VTH_MIN"], "VGS = 3V3M >= 3.25 V when EN low")]
for n, vh, vl, note in rows:
    P(f"{n:50s} high >= {vh:4.2f} V (margin {2.85-vh:+.2f} V)  low <= {vl:4.2f} V (margin {vl-VOL_REAL:+.2f} V; {vl-0.40:+.2f} V at"
      f" the 8 mA VOL)  {note}")
P("MCU in reset (pins floating): AUD_EN held by R508 47 k against the TLV767 0.4 uA typ pull-up -> 19 mV < 0.30 V (TLV758P VEN(LO))"
  " and < 0.40 V (TLV767); AVCC_EN/ANA_EN/ILIM_HI/RAIL_EN by 100 k pull-downs (EN leakages <= 0.25 uA -> <= 25 mV).")
P("TPS2596 FLT: open drain, pull-down 11.5 ohm typ when asserted, leakage <= 1 uA at 6 V [DS]; R512 100 k to 3V3M -> VOH >= 3.15 V,"
  " VOL ~0.4 mV; asserted only for thermal shutdown and an ILM short (Table 3) - NOT for current limiting (see c11).")

P(hdr("4. Capacitor requirements (effective values, lower bound = nom x (1-tol) x 0.85 temp x DC-bias factor)"))
def eff(nom, tol, key, v):
    return nom * (1 - tol) * TEMP_X5R * DCBIAS[(key, v)]
F22_16V_0603 = {5.5: 0.62, 3.3: 0.72, 1.3: 0.90}   # [ASSUMP] 2.2 uF 16 V X5R 0603 DC-bias factors (parts P-M2: 1.25 uF at 5.5 V incl. tol/temp/ageing)
c301 = 2.2e-6 * 0.9 * TEMP_X5R * F22_16V_0603[5.5]
c302 = 2.2e-6 * 0.9 * TEMP_X5R * F22_16V_0603[3.3]
c3a_lo = c302 + 2 * 2.2e-6 * 0.9 * TEMP_X5R * F22_16V_0603[3.3] + 3 * eff(0.1e-6, .1, "100n16V0402", 3.3)
c3a_hi = 2.42e-6 + 2 * 2.42e-6 + 3 * 0.11e-6 + 33e-12
P(f"LP5907 IN (C301 2.2 uF 16 V 0603): effective >= {c301*1e6:.2f} uF at 5.5 V (>= 0.7 uF [DS]; parts P-M2 1.25 uF incl. ageing)")
P(f"LP5907 OUT (C302 2.2 uF + AVCC C303/C304 2.2 uF + 3 x 100 nF + C421 via R301/R302 2.2 ohm): effective >= {c3a_lo*1e6:.2f} uF"
  f" (>= 0.7 uF [DS]) .. upper bound {c3a_hi*1e6:.2f} uF (<= 10 uF [DS])")
c3m_lo = eff(1e-6, .1, "1u50V0603", 3.3)
P(f"TPS7A20 (3V3M): C502 alone {c3m_lo*1e6:.2f} uF effective (>= 0.47 uF [DS]); IN: C501 shared with U504, >= 0.47 uF eff. recommended"
  f" [DS]: {eff(1e-6,.1,'1u50V0603',5.5)*1e6:.2f} uF; with MCU caps OUT upper bound 5.83 uF (<= 200 uF)")
c3d_lo = eff(10e-6, .1, "10u25V0805", 3.3)
P(f"TLV767 (3V3D): C512 10 uF nominal (2.2..220 uF nominal [DS]); effective {c3d_lo*1e6:.2f} uF (>= 0.5 uF [DS]); IN: C501 (shared,"
  " <= 3 mm); an input capacitor is not required for stability [DS 9.1.3]")
c1v3_lo = eff(1e-6, .1, "1u50V0603", 3.3) + 2.2e-6 * 0.9 * TEMP_X5R * F22_16V_0603[1.3] + eff(0.1e-6, .1, "100n16V0402", 3.3)
P(f"TLV758P (1V3): C312 1 uF + DAC C310 2.2 uF 16 V + C309 100 nF -> effective >= {c1v3_lo*1e6:.2f} uF (>= 0.47 uF derated, <= 220 uF [DS]);"
  " IN: C311 1 uF (EC test condition CIN = 1 uF)")
c507 = eff(10e-6, .1, "10u25V0805", 5.5)
P(f"LM27762: C507/C509/C510/C511 10 uF 25 V 0805 effective >= {eff(10e-6,.1,'10u25V0805',4.0)*1e6:.2f} uF at 4 V "
  f"({c507*1e6:.2f} uF at 5.5 V) vs EC test conditions 2.2 uF (IN/OUT) and 4.7 uF (CPOUT) [DS]; C508 1 uF 50 V: "
  f"{eff(1e-6,.1,'1u50V0603',5.5)*1e6:.2f} uF effective")
P("TPS2596 (U503): C505 100 nF at IN (0.1 uF recommended [DS 9.2 note]); C506 1 uF at OUT + C507 10 uF behind FB501; COUT is"
  " not a stability requirement of the eFuse (no voltage loop active with OVCSEL open) - see c11.")

P(hdr("5. LM27762 single-resistor feedback, 0.1 % thin film (V = VFB x (1 + Rtop/Rbot)) - unchanged (D-6)"))
def rail(vfb_min, vfb_max, rt, rb, tol):
    lo = vfb_min * (1 + rt * (1 - tol) / (rb * (1 + tol)))
    hi = vfb_max * (1 + rt * (1 + tol) / (rb * (1 - tol)))
    nom = (vfb_min + vfb_max) / 2 * (1 + rt / rb)
    return lo, nom, hi
for n, a, b, rt, rb, t in (("VPOS 221k/100k 0.1% (D-6)", LM27762["VFBP_MIN"], LM27762["VFBP_MAX"], 221, 100, 0.001),
                           ("|VNEG| 205k/100k 0.1% (D-6)", LM27762["VFBN_MIN"], LM27762["VFBN_MAX"], 205, 100, 0.001)):
    lo, nom, hi = rail(a, b, rt, rb, t)
    P(f"{n:32s} {lo:6.3f} .. {nom:6.3f} .. {hi:6.3f} V   PGOOD (95 % of target, typ) {0.95*nom:5.3f} V")
VPmax = rail(LM27762["VFBP_MIN"], LM27762["VFBP_MAX"], 221, 100, 0.001)[2]
VNmax = rail(LM27762["VFBN_MIN"], LM27762["VFBN_MAX"], 205, 100, 0.001)[2]

P(hdr("6. LM27762 peak-current headroom (R_NEG typical-only [DS-typ 2.5 ohm at 5.5 V]) with the TPS2596 limits"))
P("Negative: VIN - I_neg x R_NEG >= |V-|max + I_neg x 0.45 ohm; positive: VIN - V+max >= I_pos x 0.675 ohm [DS-typ x 1.5, ASSUMP]")
ENV = {}
for vb in (VBUS_MIN, VBUS_DES):
    for mode in ("Default", "High"):
        c = [x for x in cases if x[0] == vb and x[1] == mode][0]
        vin = c[4]
        negs = [(vin - VNmax) / (rneg + 0.45) for rneg in (2.5, 3.5, 4.5)]
        ipos = (vin - VPmax) / 0.675
        ENV[(vb, mode)] = (vin, negs, ipos)
        P(f"VBUS {vb:4.2f} {mode:7s} VIN {vin:5.3f} V: I_neg max (R_NEG 2.5/3.5/4.5 ohm) = "
          f"{negs[0]*1e3:5.0f}/{negs[1]*1e3:5.0f}/{negs[2]*1e3:5.0f} mA ; I_pos max = {ipos*1e3:5.0f} mA")
P("(Clean-signal envelopes for the analog stream: peak current on each rail incl. quiescent; they barely move vs round 1"
  " because the TPS2596 Ron (131 mOhm) replaces the TPS2553 (135 mOhm).)")
P(f"Analog round 2 (final): at VBUS 4.40 V in High mode the 32/60 ohm targets keep the negative LDO in regulation only for"
  f" R_NEG <= {ANA_FINAL['RNEG_MAX_32']}/{ANA_FINAL['RNEG_MAX_60']} ohm (R_NEG is 2.5 ohm typical only); no clipping up to"
  f" {ANA_FINAL['RNEG_NOCLIP']} ohm, but PGOOD may dip at peaks -> no VBUS volume ceiling (it would break the 300 ohm target);"
  " firmware must debounce RAILS_OK_N (short dips are not overload). The round-1 fallback 'VBUS-dependent volume ceiling' is withdrawn.")

P(hdr("7. LM27762 dissipation bound"))
Vn_min = rail(LM27762["VFBN_MIN"], LM27762["VFBN_MAX"], 205, 100, 0.001)[0]
Pmax = IOS_HIGH_MAX * (5.50 - Vn_min) + 5.50 * LM27762["IQ_TYP"]
for tl, tr in (("50 C ambient", 0.0), ("50 C + 10 C local", T_LOCAL_RISE)):
    P(f"Upper bound (all U503 High-limit current {IOS_HIGH_MAX*1e3:.0f} mA into the lower rail): P <= {Pmax:.2f} W -> TJ = "
      f"{TA_MAX+tr+LM27762['THETA_JA']*Pmax:5.1f} C ({tl}); limit 125 C op, TSD 150 C typ")

P(hdr("8. TPS25200 current limit (R108 = 86.6 k, 1 %)"))
imin = tps25200_ios(86.6 * 1.01)[0]; inom = tps25200_ios(86.6)[1]; imax = tps25200_ios(86.6 * 0.99)[2]
P(f"IOS min/nom/max = {imin*1e3:.0f}/{inom*1e3:.0f}/{imax*1e3:.0f} mA [DS Eq.1 + 1 % resistor]; High total max {R['T_HIGH']*1e3:.0f} mA ->"
  f" margin {(imin-R['T_HIGH'])*1e3:.0f} mA ({(imin/R['T_HIGH']-1)*100:.0f} %); below the 1.5 A advertisement.")
json.dump(dict(V5MIN=v5min, ENV={f"{k[0]}_{k[1]}": v for k, v in ENV.items()}),
          open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c04_results.json"), "w"), indent=1)
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
