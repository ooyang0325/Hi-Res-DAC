"""c22 - E-16 suspend power cut (owner decision 25 Sep 2026): U502 TPS70933 (30 V, from VBUS) + Q507 on U102 EN.
Attach regions with the new partition, hard-short kick with C102 2.2 uF, surge/thermal on the U502 input, back-feed paths,
S6 inventory (S1-S5 deltas). Labels as in pw_common."""
import json, math, os
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
out = []; P = out.append
TPS709 = dict(VIN_ABS=32.0, VIN_OP=(2.7, 30.0), VEN_ABS=7.0, VEN_OP_MAX=6.5, VOUT_ABS=7.0, ACC=0.01, LINE=0.010, LOAD=0.050,
              VDO_50=0.650, VDO_150=1.400, ICL=(0.200, 0.320, 0.500), IGND0=2.05e-6, IGND150_TYP=350e-6, RTHJA=212.1, COUT_MIN=2.2e-6)  # [DS SBVS186H]
P(hdr("1. U502 TPS70933DBVR from VBUS [DS SBVS186H]"))
vmin = 3.3 * (1 - TPS709["ACC"]) - TPS709["LINE"] - TPS709["LOAD"]; vmax = 3.3 * (1 + TPS709["ACC"]) + TPS709["LINE"]
P(f"  3V3M static {vmin:.3f} .. {vmax:.3f} V (1 % DC + 10 mV line + 50 mV load); EN pin 3 floating = enabled (EN max 6.5 V -> never tie to VBUS);"
  " VOUT abs max 7 V independent of VIN + reverse-current protection -> no OUT->IN clamp needed (D103 deleted).")
i_m = 0.084
vdo = TPS709["VDO_50"] + (TPS709["VDO_150"] - TPS709["VDO_50"]) * (i_m - 0.050) / 0.100
P(f"  Dropout at the 84 mA planning load <= {vdo*1e3:.0f} mV (linear between the 50/150 mA maxima [ASSUMP]) -> regulated while VBUS >= {vmax+vdo:.3f} V;"
  f" at VBUS 4.40 V less the J101 contact drop (4.385 V): headroom +{(4.385-vmax-vdo)*1e3:.0f} mV. At 50 mA: VBUS >= {vmax+0.650:.3f} V.")
P("  Brown-out detection is ratiometric (VDDA = 3V3M): the 4.00 V trip needs 3V3M in regulation at 5V_SYS 4.0 V (VBUS ~4.07 V) -> guaranteed only"
  " while the 3V3M load is <= 50 mA (VDO <= 0.65 V); on the 80 mA planning value it is not (Q: MCU current measured). Unplug compliance does not"
  " need the firmware action (c14 case a with X-8).")
for v, nm in ((5.50, "VBUS 5.50 V (in spec)"), (9.45, "mis-set 9 V source"), (17.0, "hard-short kick peak (TVS clamp, us)")):
    p = (v - 3.3) * i_m
    P(f"  {nm:38s}: U502 dissipation {p*1e3:5.0f} mW -> TJ {60 + p*TPS709['RTHJA']:5.0f} C (212 C/W [DS]); VIN {v:.2f} V vs 30 V op / 32 V abs")
P("  -> in spec TJ <= 99 C; a 9 V source drives U502 into thermal shutdown cycling (survives; U102 is in OVLO anyway); the 17 V kick lasts <= 10 us (<= 12 uJ in U502) - the steady-state TJ figure above does not apply.")
P(hdr("2. Attach (USB-IF CU #45) with the new partition"))
QA_C102 = 2.2e-6 * 1.1 * 5.5; QA_D102 = 10e-9 * 5.5
C3M = 6.05e-6 * 1.0; Q3M = C3M * 3.35 * (1 - 0.100 / TPS709["ICL"][2])
QA = QA_C102 + QA_D102 + Q3M
C5 = 3.63e-6; QB = C5 * 5.55
P(f"  Region A (contact; U502 charges 3V3M at once): C102 2.2 uF +10 % x 5.5 V = {QA_C102*1e6:.1f} uC + D102 {QA_D102*1e6:.2f} uC + 3V3M {C3M*1e6:.2f} uF x 3.35 V"
  f" x (1 - 0.1 A/ICL max 0.5 A) = {Q3M*1e6:.1f} uC -> {QA*1e6:.1f} uC ({(1-QA/50e-6)*100:.0f} % margin)")
P(f"  Region B (U102 soft start >= 3.31 ms): 5V_SYS {C5*1e6:.2f} uF x 5.55 V = {QB*1e6:.1f} uC ({(1-QB/50e-6)*100:.0f} % margin); separation: region A ends"
  " <= ~1.3 ms (ringing 273 us + U502 start <= 1 ms [ASSUMP]) -> gap >= 2 ms.")
P(hdr("3. Hard short on 5V_SYS - kick with C102 2.2 uF (no tIOS credit, D102 SMDJ12A)"))
def kick(C, Lc, Rc, ron, tint, vbr, rd, dt=5e-9, tend=60e-6):
    i0 = 0.5; v = VBUS_MAX - Rc * i0; i = i0; t = 0.0; vpk = v
    while t < tint + tend:
        iout = v / ron if t < tint else min(1.08, v / ron)
        itvs = max(0.0, (v - vbr) / rd)
        i += (VBUS_MAX - Rc * i - v) / Lc * dt; v += (i - iout - itvs) / C * dt; t += dt; vpk = max(vpk, v)
        if t > tint + 3e-6 and i < 1.3 and v < VBUS_MAX + 0.5:
            break
    return vpk
vbr_hot = 14.7 * 1.035; rd = (19.9 - 14.7) / 150.8
worst = 0.0
for C in (1.1e-6, 2.42e-6):
    for Lc in (0.25e-6, 0.5e-6, 1.0e-6, 1.5e-6):
        for Rc in (0.05, 0.1, 0.2, 0.4):
            for ron in (0.045, 0.099):
                worst = max(worst, kick(C, Lc, Rc, ron, 6 * Lc / (Rc + ron) + 5e-6, vbr_hot, rd))
P(f"  C102 effective 1.1 uF (2.2 uF derated) / 2.42 uF: worst U102 IN {worst:.2f} V (<= 18 V target, 20 V abs) - the TVS clamp sets it; U502 IN sees the same"
  " (32 V abs).")
P(hdr("4. Back-feed paths with 5V_SYS off in Stop"))
P("  U101 USBLC6 VBUS pin moved 5V_SYS -> 3V3M (else the D+ J-state level forward-biases its upper diode into the dead 5V_SYS); D104/D105 at 0 V bias;"
  " VBUS_SENSE/ANA_SENSE dividers at 0; U503 FLT (R512 to 3V3M) open-drain, abs 7 V not VIN-referred; U505 on 3V3M, its D/S at the unpowered ILM node"
  " (0 V); TPS70933 blocks OUT->IN. No path from 3V3M into 5V_SYS remains [netlist review].")
P(hdr("5. S6 suspend (legacy A-to-C) with the power cut; S1-S5"))
inv = [("MCU Stop + USB-HS PHY [PH, L-1]", 1.900), ("D+ pull-up into the host 15 k", 0.214), ("legacy Rp 56 k -> Rd 5.1 k", 0.094),
       ("U102 IIN(off) VEN = 0, VIN = 5 V [DS]", 0.005), ("R109 470 k through Q507 (5.55 V / 465 k)", 5.55 / 465.3e3 * 1e3),
       ("Q507 base drive from PC14: (3.35 - 0.7 V) / R537 100 k (R538 share included)", (3.35 - 0.7) / 99e3 * 1e3), ("U502 TPS70933 IGND at ~2 mA load (2.05 uA + 0.2 % [ASSUMP])", 0.006),
       ("D102 SMDJ12A at 5.5 V / 50 C (estimate 3.0, budget)", 0.005), ("D103 deleted; D104/D105 0 V bias", 0.0),
       ("VBUS_SENSE divider, U101, U503, U504, U302 (5V_SYS = 0)", 0.0), ("U505 TMUX1101 IDD + SEL (3V3M)", 0.0007), ("U103 CC ESD", 0.00002),
       ("protection U605 + dividers (3V3A off) [protection R3.7]", 0.0076), ("MCU suspend IWDG wake (DX-2) [digital]", 0.0045)]
tot = sum(i for _, i in inv)
for nm, i in inv:
    P(f"  {nm:62s} {i:7.4f} mA")
P(f"  S6 = {tot:.4f} mA (legacy A-to-C) vs 2.500 mA -> margin +{(2.5-tot)*1e3:.0f} uA (>= 0.2 mA required by E-5); C-to-C (no Rp) {tot-0.094:.4f} mA.")
P("  S1-S5 unchanged (c17 final): the U502 input current moves from 5V_SYS to VBUS (same USB total); TPS70933 IGND <= the TPS7A20 figure at the MCU load"
  " (350 uA typ at 150 mA vs 2 mA max at 300 mA); Q507 off and R537 at 0 V while running; U101 on 3V3M draws only its leakage.")
P(hdr("6. Q507 leakage vs U102 turn-on at VBUS 4.40 V (R9 check; R109 470 k +1 %, TPS25200 IEN 2 uA into the pin, EN on threshold <= 1.9 V [DS])"))
R109 = 470e3 * 1.01
allow = (4.40 - 1.9) / R109 - 2e-6
P(f"  Allowed switch leakage for EN >= 1.9 V: {allow*1e6:.2f} uA")
for nm, ilk in (("AO3400A IDSS <= 1 uA (30 V, 25 C) [DS]", 1e-6), ("AO3400A IDSS <= 5 uA (30 V, 55 C) [DS]", 5e-6),
                ("MMBT3904 ICEX <= 50 nA (30 V, 25 C) [DS class]", 50e-9), ("MMBT3904 at 60 C: x11 (doubling per 10 C) [ASSUMP]", 0.55e-6)):
    v = 4.40 - (2e-6 + ilk) * R109
    P(f"  {nm:52s}: EN = {v:.2f} V -> {'on' if v >= 1.9 else 'NOT guaranteed'}")
P("  -> Q507 = NPN MMBT3904 (C20526, Basic, protection's type): on: IB = (3.3 - 0.75)/100 k - 0.75/100 k = 18 uA for IC <= 14 uA (forced beta < 1,"
  " VCE(sat) << 0.6 V EN-off threshold); off: VBE = 0.55 uA x R538 100 k = 55 mV (no turn-on); Stop cost 26 uA from PC14.")
json.dump(dict(S6=tot, QA=QA, QB=QB, kick=worst, v3m=(vmin, vmax)), open(os.path.join(HERE, "c22_results.json"), "w"), indent=1)
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
