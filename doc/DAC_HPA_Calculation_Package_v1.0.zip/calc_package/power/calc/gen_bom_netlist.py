"""Generates ../bom_rows.csv and ../netlist.csv for the power stream (blocks 1 and 5, U302/U303 with their
capacitors and EN parts, all discharge parts). R8 round 2: J101 GCT USB4105-GF-A (GCT pad labels), U103 TPD2E2U06,
U303 TLV75801P + R533/R534, U503 TPS259621 + C514, U505 TMUX1101 + C515, R509/R510 new values, R532, C301/C302 2.2 uF;
deleted Q501 (-> U505) and C503 (attach charge, c02).
R8 round 3 (decisions_r8c.md): X-1 U501 EN+/EN- = 5V_ANA_F, R506/R507/RAIL_EN deleted; X-2 C104; X-3 D102 SMDJ12A;
X-4 Schottky OUT->IN D103-D107 (per c14 round 3), U303 EN = 3V3D; X-5 R535/R536/C516 (ANA_SENSE); X-10 C103 100 pF C0G, R508 10 k."""
import csv, os
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.dirname(HERE)
LC = lambda c: f"https://www.lcsc.com/product-detail/{c}.html"
TI = lambda p: f"https://www.ti.com/lit/ds/symlink/{p}.pdf"

from gen_sch_part import SCH_REFS, SCH_DESC, SCH_PKG, SCH_RATING, SCH_MPN, SCH_LCSC, SCH_CLASS, SCH_STOCK, SCH_PINS, SCH_PRICE, SCH_URL, SCH_PINMAP, SCH_PAIRS
B1, B3, B5 = "1 USB-C input, OVP and sensing", "3 DAC supplies (power-stream parts)", "5 Power: domains, current limit, rails, discharge"
# columns: block,refs,qty,desc,value,package,rating_tolerance,mpn,lcsc,jlcpcb_class,jlcpcb_stock_or_sourcing,fit,leadless,
#          smt_pins_per_part,tht_pins_per_part,unit_price_usd,datasheet_url,note
bom = [
 (B1, "J101", 1, "USB-C receptacle, USB 2.0, 16 contacts on 12 SMT pads (A1/B12, A4/B9, B4/A9, B1/A12 combined) + 4 THT shell stakes;"
  " 2 NPTH locating pegs; shell to GND via R107", "-", "SMD horizontal top mount, 0.95 mm shell stakes",
  "48 V DC (GCT page; drawing 20 V), VBUS 5 A, GND 6.25 A, others 0.25 A, 40 mOhm max; solder peak 255 C (-0/+5) max 5 s",
  "GCT USB4105-GF-A", "C3020560", "Extended (JLCPCB: Economic and Standard, assembly difficulty high)",
  "LCSC out of stock (14 Sep 2026); DigiKey 127,933 (24 Sep 2026) -> JLCPCB global sourcing", "Yes", "No", 12, 4, 1.09,
  "https://gct.co/connector/usb4105 (drawing text: https://www.mouser.com/datasheet/2/837/USB4105-1948910.pdf)",
  "CHANGED (D-8) from SHOU HAN; pads named by contact per the GCT drawing; Standard PCBA 240 C OK; continuity-check samples (R8-A10)"),
 (B1, "U103", 1, "CC1/CC2 ESD, 2 channels, low capacitance, at J101", "-", "SOT-5X3 (DRL) 5-pin", "VRWM 5.5 V, VBR >= 6.5 V, 10 nA at 2.5 V,"
  " 1.5 pF, IEC +-25 kV", "TI TPD2E2U06DRLR", "C1972959", "Extended (not verified)", "JLCPCB 4,257 (Apr 2025); DigiKey 87,628", "Yes", "No",
  5, 0, 0.22, TI("tpd2e2u06"), "NEW (D-8); pin 1/2 NC, 3 CC1, 4 GND, 5 CC2"),
 (B1, "U102", 1, "Input OVP eFuse: 5.25-5.55 V output clamp, OVLO 6.8-8.45 V, 20 V abs max IN, 99 mOhm max, built-in soft start",
  "-", "WSON-6 2x2 (DRV) + pad", "IOS 0.87-1.08 A with R108 100 k (c20)", "TI TPS25200DRVR", "C128401", "Extended",
  "JLCPCB 19,166 available (Aug 2026)", "Yes", "Yes", 7, 0, 0.44, TI("tps25200"),
  "NEW (R8-A1/B9): VBUS -> 5V_SYS; FAULT (pin 3) not connected; pad to GND"),
 (B1, "R108", 1, "U102 current-limit resistor (IOS 870/970/1077 mA >= S4 758.1 mA; c20)", "100 kOhm", "0402", "1 %, 62.5 mW",
  "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic", "JLCPCB Basic (same type as R105/R303/R511-R513)", "Yes", "No", 2, 0, 0.0033,
  LC("C25741"), "VE: 86.6 k (Extended) -> 100 k Basic (c20 a)"),
 (B1, "R109", 1, "U102 EN pull-up to VBUS (TI: >= 300 k; with C104: U102 on 3.3-55 ms after attach; c20)",
  "470 kOhm", "0402", "1 %, 62.5 mW", "UNI-ROYAL 0402WGF4703TCE", "C25790", "Basic (not verified)", "same type as R532", "Yes", "No", 2, 0,
  0.002, LC("C25790"), "VE: 300 k -> 470 k (one type less; c20 b)"),
 (B1, "C102", 1, "VBUS input capacitor at J101 / U102 IN, also U502 CIN (attach region A <= 29.6 uC with the 3V3M charge; hard-short kick with D102 <= 17 V, c22)", "2.2 uF",
  "0805", "25 V X5R +-10 %", "Samsung CL21A225KAFNNNE", "-", "(not verified)", "LCSC code to be confirmed by parts", "Yes", "No", 2, 0, 0.02,
  "-", "CHANGED (E-16) 4.7 uF -> 2.2 uF (3V3M caps now charge at contact through U502)"),
 (B1, "C104", 1, "U102 EN delay capacitor (EN to GND, with R109 470 k): U102 on 3.31-55.3 ms after attach at every corner (X-2, c16 B, c20 b)", "100 nF",
  "0402", "16 V X7R +-10 %", "Samsung CL05B104KO5NNNC", "C1525", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.0045, LC("C1525"),
  "NEW (X-2, R8 round 3); attach regions separated by >= 1.96 ms"),
 (B1, "D102", 1, "VBUS TVS at J101 (VBUS-GND, unidirectional, cathode to VBUS): U102 IN <= 17.0 V at a 5V_SYS hard short with no tIOS credit"
  " (c16 C); VRWM 12 V so a mis-set 9 V source is below stand-off", "12 V", "DO-214AB (SMC)", "VRWM 12 V, VBR 13.3-14.7 V, VC 19.9 V at 150.8 A,"
  " IR <= 2 uA at 12 V (25 C), 3000 W", "Littelfuse SMDJ12A", "-", "owner-bought (DigiKey)",
  "DigiKey 5,498 (Sep 2026), US$ 1.01 at 10+; LCSC SMDJ12A (MDD C2994091, TSC C3717799) out of stock; LGE C5806873 not adopted (IR/VBR max not verifiable)", "Yes", "No", 2, 0, 1.01,
  "https://www.littelfuse.com/products/overvoltage-protection/tvs-diodes/surface-mount/smdj/smdj12a",
  "owner-fitted (hand-soldered, not placed by JLCPCB); NEW (X-3); fit before the first USB attach; SMC lands with toes +0.3 mm, 1.5 mm iron clearance, <= 5 mm from J101"),
 (B1, "U101", 1, "ESD array D+/D-; VBUS pin (5) tied to 3V3M (E-16: 5V_SYS is off in suspend - on 5V_SYS the D+ pull-up would back-feed it through the upper diode)", "-",
  "SOT-23-6", "IRM <= 150 nA at 5.25 V, 3.5 pF", "ST USBLC6-2SC6", "C7519", "Extended", "as Parts List v0.6", "Yes", "No", 6, 0,
  0.1844, "https://www.st.com/resource/en/datasheet/usblc6-2.pdf", "pin 5 on 3V3M (E-16; was 5V_SYS)"),
 (B1, "R101, R102", 2, "CC1/CC2 Rd pull-down (USB-C sink)", "5.1 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF5101TCE", "C25905", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C25905"), "unchanged"),
 (B1, "R103, R104", 2, "CC1/CC2 series resistor to MCU ADC (CC1_ADC, CC2_ADC)", "10 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF1002TCE",
  "C25744", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C25744"), "unchanged"),
 (B1, "R105", 1, "VBUS_SENSE divider top, from 5V_SYS", "100 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "now on 5V_SYS (after OVP)"),
 (B1, "R106", 1, "VBUS_SENSE divider bottom (k = 0.3197; 5.55 V -> 1.77 V)", "47 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF4702TCE",
  "C25792", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C25792"), "unchanged value"),
 (B1, "C103", 1, "VBUS_SENSE ADC input capacitor at PA1 (tau 3.6 us with R105/R106; brown-out watchdog acts before the MCU reset, c14)", "100 pF", "0402",
  "50 V C0G +-5 %", "Samsung CL05C101JB5NNNC", "C1546", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.002,
  LC("C1546"), "CHANGED (X-10, R8 round 3) 10 nF X7R -> 100 pF C0G"),
 (B1, "R107", 1, "USB-C shell to GND (0 ohm)", "0 Ohm", "0402", "jumper", "UNI-ROYAL 0402WGF0000TCE", "C17168", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C17168"), "unchanged"),
 (B1, "C101", 1, "DNF: shell-to-GND RF capacitor (only if R107 becomes a bleed resistor)", "4.7 nF", "0402", "50 V X7R",
  "FH 0402B472K500NT", "C1538", "Basic", "as Parts List v0.6", "DNF", "No", 2, 0, 0.002, LC("C1538"), "unchanged"),
 # ---------------- block 3 (power-stream owned)
 (B3, "U302", 1, "LDO 3V3A (VCCA, AVCC_L/R, VREF, DC-sense bias), EN = AVCC_EN", "3.3 V, 250 mA", "SOT-23-5", "+-2 %, 6.5 uVrms typ",
  "TI LP5907MFX-3.3/NOPB", "C80670", "Extended", "as Parts List v0.6", "Yes", "No", 5, 0, 0.2104, TI("lp5907"),
  "unchanged; internal 230 ohm discharge not relied on"),
 (B3, "C301", 1, "LP5907 input (5V_SYS); >= 1.04 uF effective at 5.5 V", "2.2 uF", "0603", "16 V X5R +-10 %", "Samsung CL10A225KO8NNNC",
  "C23630", "Basic", "JLCPCB Basic (analog stream uses the same part)", "Yes", "No", 2, 0, 0.012, LC("C23630"), "CHANGED 1 uF -> 2.2 uF (D-8, P-M2)"),
 (B3, "C302", 1, "LP5907 output (3V3A total <= 7.6 uF upper bound <= 10 uF)", "2.2 uF", "0603", "16 V X5R +-10 %", "Samsung CL10A225KO8NNNC",
  "C23630", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.012, LC("C23630"), "CHANGED 1 uF -> 2.2 uF (D-8, P-M2)"),
 (B3, "R303", 1, "AVCC_EN pull-down (LP5907 EN and Q502 gate)", "100 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF1003TCE", "C25741",
  "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "unchanged; R307 deleted"),
 (B3, "U303", 1, "LDO 1V3 (ES9018K2M external DVDD) from 3V3D, adjustable, EN = AUD_EN, internal active discharge (95 ohm typ)",
  "1.300 V (R533/R534)", "SOT-23-5 (DBV)", "VFB 0.55 V +-1 % (TJ <= 85 C), 500 mA, VDO <= 400 mV", "TI TLV75801PDBVR", "C2877852",
  "Extended", "LCSC 113,390 (24 Sep 2026)", "Yes", "No", 5, 0, 0.18, TI("tlv758p"),
  "CHANGED (D-7) from ME6216A13; pin 1 IN, 2 GND, 3 EN, 4 FB, 5 OUT; 1.272-1.325 V incl. line/load (c12)"),
 (B3, "C311", 1, "TLV758P input (3V3D)", "1 uF", "0603", "50 V X5R +-10 %", "Samsung CL10A105KB8NNNC", "C15849", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.006, LC("C15849"), "unchanged part"),
 (B3, "C312", 1, "TLV758P output (1V3)", "1 uF", "0603", "50 V X5R +-10 %", "Samsung CL10A105KB8NNNC", "C15849", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.006, LC("C15849"), "unchanged part"),
 (B3, "R533", 1, "U303 feedback top (OUT -> FB); block-5 number to avoid collisions with the analog block-3 series", "15.0 kOhm", "0603",
  "0.1 %, 25 ppm/C, thin film", "YAGEO RT0603BRD0715KL", "C326733", "Extended (not verified)", "LCSC 209,580 (25 Sep 2026)", "Yes", "No",
  2, 0, 0.0296, LC("C326733"), "NEW (D-7)"),
 (B3, "R534", 1, "U303 feedback bottom (FB -> GND)", "11.0 kOhm", "0603", "0.1 %, 25 ppm/C, thin film", "YAGEO RT0603BRD0711KL", "C728581",
  "Extended (not verified)", "LCSC 2,260 (24 Sep 2026)", "Yes", "No", 2, 0, 0.0499, LC("C728581"), "NEW (D-7)"),
 # ---------------- block 5
 (B5, "U502", 1, "LDO 3V3M, always on (MCU, LEDs), fed from VBUS (E-16 suspend power cut: independent of U102); EN floating = enabled; reverse-current protection",
  "3.3 V, 150 mA", "SOT-23-5", "VIN 2.7-30 V (32 V abs), VOUT 3.207-3.343 V (1 % + 10 mV line + 50 mV load), IGND <= 2.05 uA, VDO <= 650 mV at 50 mA / 1400 mV at 150 mA",
  "TI TPS70933DBVR", "C89347", "Extended (Economic and Standard)", "LCSC 5,280 (Sep 2026); JLCPCB 32,252", "Yes", "No", 5, 0, 0.26,
  TI("tps709"), "CHANGED (E-16, R9) from TPS7A2033PDBVR; pin 1 IN = VBUS, 3 EN not connected (EN max 6.5 V: never tie to VBUS), 5 OUT; place next to U102/C102 (C102 = its CIN)"),
 (B5, "C501", 1, "TLV767 input (5V_SYS; U502 now on VBUS)", "1 uF", "0603", "50 V X5R +-10 %", "Samsung CL10A105KB8NNNC",
  "C15849", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.006, LC("C15849"), "unchanged part; serves U504 only (E-16)"),
 (B5, "C502", 1, "TPS70933 output (3V3M); >= 2.2 uF required by TI", "2.2 uF", "0603", "16 V X5R +-10 %", "Samsung CL10A225KO8NNNC", "C23630", "Basic",
  "JLCPCB Basic", "Yes", "No", 2, 0, 0.012, LC("C23630"), "CHANGED (E-16) 1 uF -> 2.2 uF"),
 (B5, "U504", 1, "LDO 3V3D (CPLD, oscillators, DVCC, 1V3), EN = AUD_EN; 0.32 W at 5.5 V (no dropper)",
  "3.3 V, 1 A", "WSON-6 2x2 (DRV) + pad", "+-1 %, 18 V abs max, VDO 1.4 V max at 1 A", "TI TLV76733DRVR", "C2848334",
  "Extended", "JLCPCB 17,495 (Sep 2026)", "Yes", "Yes", 7, 0, 0.27, TI("tlv767"), "round 1: from ME6211; pad to GND pour; IN cap = C501 (C503 deleted)"),
 (B5, "C512", 1, "TLV767 output (3V3D bulk; TLV767 needs 2.2..220 uF)", "10 uF", "0805", "25 V X5R +-10 %",
  "Samsung CL21A106KAYNNNE", "C15850", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.085, LC("C15850"), "unchanged; C504 deleted"),
 (B5, "R508", 1, "AUD_EN pull-down (AUD_EN fed from PC10 through digital R237 4.7 k; TLV767 EN internal pull-up unbounded -> strong pull-down): high >= 2.18 V, low <= 0.11 V floating (c16 E)", "10 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF1002TCE", "C25744", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C25744"), "CHANGED (X-10, R8 round 3) 47k -> 10k"),
 (B5, "U503", 1, "eFuse / current limit for 5V_ANA (Default/High via ILM), EN/UVLO = ANA_EN, FLT -> ANA_FAULT_N, OVCSEL open,"
  " auto-retry", "-", "HSOIC-8 PowerPAD (DDA) 4.9 x 3.9 mm", "21 V abs, 131 mOhm max, ILIM +-10.4 %, IQ 266 uA, ISD 1.13 uA",
  "TI TPS259621DDAR", "C2155774", "Extended (Economic and Standard)", "JLCPCB 656 (17 Sep 2026); DigiKey 1,377", "Yes", "No", 9, 0, 1.30,
  TI("tps2596"), "CHANGED (D-5) from TPS2553; MSL 2; exposed pad to GND with 9 vias; pin 8 OVCSEL no connection"),
 (B5, "C505", 1, "TPS2596 input (0.1 uF recommended by TI)", "100 nF", "0402", "16 V X7R", "Samsung CL05B104KO5NNNC", "C1525", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.0045, LC("C1525"), "unchanged part"),
 (B5, "C506", 1, "TPS2596 output (5V_ANA)", "1 uF", "0603", "50 V X5R +-10 %", "Samsung CL10A105KB8NNNC", "C15849", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.006, LC("C15849"), "unchanged"),
 (B5, "C514", 1, "TPS2596 dVdt capacitor: 5V_ANA ramp 0->5.5 V in 0.9-1.9 ms; with the X-8 reservoirs rails good <= 18.8 ms (c18); firmware T_START = 40 ms", "10 nF", "0402", "50 V X7R +-10 %",
  "Samsung CL05B103KB5NNNC", "C15195", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C15195"), "NEW (c11); kept 10 nF (DY-2: 470 nF option of DX-4 reverted)"),
 (B5, "R509", 1, "TPS2596 R_ILM Default (IOS 180.05/201.3/222.6 mA; Default need 178.82 mA [G] -> margin +1.23 mA; Default total 493.45 mA <= 500 on the planning values; E-18)",
  "4.75 kOhm", "0603", "0.1 %, 25 ppm/C, thin film", "KOA RN73R1JTTD4751B25", "-", "owner-bought (DigiKey)",
  "DigiKey (KOA RN73R1JTTD4751B25 or an equivalent 0.1 %/25 ppm 0603, e.g. Susumu RG1608P-4751-B-T5)", "Yes", "No", 2, 0, 0.10,
  "https://www.koaspeer.com/products/fixed-resistors/thin-film/rn73r",
  "owner-fitted (hand-soldered, not placed by JLCPCB); CHANGED (E-18, R9) 4.81 k -> 4.75 k; U503 stays off with R509 missing (ILM open = shutdown, DS Table 3) -> fit before the first ANA_EN; 0603 land with toes +0.3 mm, 1.5 mm iron clearance"),
 (B5, "R510", 1, "TPS2596 R_ILM High branch in series with U505 (R509 4.75 k || R510 -> IOS 395.4/442.7/489.7 mA)", "3.74 kOhm", "0603",
  "0.1 %, 25 ppm/C, thin film", "YAGEO RT0603BRD073K74L", "C861382", "Extended", "LCSC 4,320 (Aug 2026), $0.035", "Yes", "No", 2, 0,
  0.035, LC("C861382"), "CHANGED (R8 round 3, c17): 3.83 k -> 3.74 k; VE: LCSC code confirmed (no global sourcing)"),
 (B5, "U505", 1, "SPST precision switch for the High-mode ILM branch (SEL = ILIM_HI, logic high = on)", "-", "SOT-23-5 (DBV)",
  "1.08-5.5 V, Ron <= 9.5 ohm, IOFF <= 0.2 nA (85 C), IDD <= 0.65 uA", "TI TMUX1101DBVR", "C1852057", "Extended (Economic and Standard)",
  "DigiKey 2,865 / Mouser 9,098 (Sep 2026)", "Yes", "No", 5, 0, 0.45, TI("tmux1101"), "NEW (D-5), replaces Q501; pin 1 D, 2 S, 3 GND, 4 SEL, 5 VDD"),
 (B5, "C515", 1, "U505 VDD decoupling (0.1-10 uF required)", "100 nF", "0402", "16 V X7R", "Samsung CL05B104KO5NNNC", "C1525", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.0045, LC("C1525"), "NEW"),
 (B5, "R511", 1, "ILIM_HI pull-down (U505 SEL; Default through reset)", "100 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF1003TCE", "C25741",
  "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "unchanged part"),
 (B5, "R512", 1, "TPS2596 FLT pull-up to 3V3M (ANA_FAULT_N; asserted only at thermal shutdown / ILM short)", "100 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "unchanged part"),
 (B5, "R513", 1, "ANA_EN pull-down (TPS2596 EN/UVLO)", "100 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "unchanged part"),
 (B5, "FB501", 1, "Ferrite 5V_ANA -> 5V_ANA_F (LM27762 VIN)", "120 Ohm @ 100 MHz", "0603", "2 A, 50 mOhm max",
  "Murata BLM18PG121SN1D", "C14709", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.0157, LC("C14709"), "unchanged"),
 (B5, "U501", 1, "Charge pump + LDOs, VPOS/VNEG; EN+/EN- tied to VIN (5V_ANA_F, X-1): rails follow ANA_EN; PGOOD active low", "+3.85 / -3.72 V", "WSON-12 2x3 (DSS) + pad",
  "+-250 mA, VIN abs 5.8 V", "TI LM27762DSSR", "C473398", "Extended", "as Parts List v0.6", "Yes", "Yes", 13, 0, 1.0174,
  TI("lm27762"), "EN+/EN- = VIN (X-1, R8 round 3); RAIL_EN, R506, R507 deleted"),
 (B5, "C507", 1, "LM27762 VIN", "10 uF", "0805", "25 V X5R +-10 %", "Samsung CL21A106KAYNNNE", "C15850", "Basic", "as Parts List v0.6",
  "Yes", "No", 2, 0, 0.085, LC("C15850"), "unchanged"),
 (B5, "C508", 1, "LM27762 flying capacitor C1", "1 uF", "0603", "50 V X5R +-10 %", "Samsung CL10A105KB8NNNC", "C15849", "Basic",
  "as Parts List v0.6", "Yes", "No", 2, 0, 0.006, LC("C15849"), "unchanged"),
 (B5, "C509, C510, C511", 3, "LM27762 CP, OUT+, OUT- capacitors", "10 uF", "0805", "25 V X5R +-10 %", "Samsung CL21A106KAYNNNE",
  "C15850", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.085, LC("C15850"), "unchanged"),
 (B5, "R501", 1, "LM27762 FB+ top, single resistor (VPOS 3.789/3.852/3.915 V with R502)", "221 kOhm", "0603",
  "0.1 %, 25 ppm/C, thin film", "YAGEO RT0603BRD07221KL", "C705748", "Extended (not verified)", "LCSC 4,260 (Feb 2026)", "Yes", "No",
  2, 0, 0.0254, LC("C705748"), "CHANGED (was 100k+100k+15k+10k); R515/R516/R523 deleted; 215k for a 3.78 V option; DX-4 fallback 232 k (VPOS 3.919/3.984/4.049 V) - fit ONLY together with protection R672 237 k -> 243 k (protection R3.16) and re-run p03/p04/p06/p10"),
 (B5, "R502, R504", 2, "LM27762 FB+ / FB- bottom (>= 50 k per TI)", "100 kOhm", "0603", "0.1 %, 25 ppm/C, thin film",
  "YAGEO RT0603BRD07100KL", "C122538", "Extended (not verified)", "LCSC 254,300 (Mar 2026)", "Yes", "No", 2, 0, 0.0223,
  LC("C122538"), "CHANGED to 0.1 % thin film"),
 (B5, "R503", 1, "LM27762 FB- top, single resistor (|VNEG| 3.661/3.721/3.781 V with R504)", "205 kOhm", "0603",
  "0.1 %, 25 ppm/C, thin film", "YAGEO RT0603BRD07205KL", "C861217", "Extended (not verified)",
  "LCSC 900 (Jul 2026) - low stock: order early or JLCPCB global sourcing", "Yes", "No", 2, 0, 0.0316, LC("C861217"),
  "CHANGED (was 100k+100k+5.1k); R517/R518 deleted"),
 (B5, "R505", 1, "PGOOD pull-up to 5V_ANA_F (LM27762 VIN, as TI specifies)", "100 kOhm", "0402", "1 %", "UNI-ROYAL 0402WGF1003TCE",
  "C25741", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "CHANGED 10k -> 100k (no latch timing need)"),
 (B5, "R522", 1, "RAILS_OK_N series resistor into MCU PB4 (FT); node swings to 5V_ANA_F", "10 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF1002TCE", "C25744", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C25744"), "unchanged"),
 (B5, "R532", 1, "PB4 pin-side pull-down: keeps RAILS_OK_N <= 4.78 V (FT VIH max 5.0 V) with PGOOD released at 5.55 V", "470 kOhm", "0402",
  "1 %", "UNI-ROYAL 0402WGF4703TCE", "C25790", "Basic (not verified)", "as used by protection R647", "Yes", "No", 2, 0, 0.002, LC("C25790"),
  "NEW (D-8); verified both states (c13)"),
 (B5, "R535", 1, "ANA_SENSE divider top (5V_ANA_F -> MCU PA0 / ADC_IN0): k 0.3197, 5.55 V -> <= 1.799 V, source 32.0 k (X-5, c20 c)", "100 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic", "JLCPCB Basic (same type as R105)", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "VE: 68.1 k -> 100 k Basic; firmware 4.00 V = 1.279 V (1587 counts)"),
 (B5, "R536", 1, "ANA_SENSE divider bottom (ANA_SENSE -> GND)", "47 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF4702TCE", "C25792", "Basic", "JLCPCB Basic (same type as R106)", "Yes", "No", 2, 0, 0.002, LC("C25792"), "VE: 30.1 k -> 47 k Basic"),
 (B5, "Q507", 1, "NPN pulling U102 EN low in Stop (E-16/E-21): off-state leakage ICEX <= 50 nA at 30 V [DS class] keeps EN >= 3.19 V at VBUS 4.40 V / 60 C (AO3400A IDSS 5 uA bound would not)",
  "MMBT3904", "SOT-23", "40 V, 200 mA, hFE 100-300", "JSCJ MMBT3904 (RANGE:100-300)", "C20526", "Basic", "LCSC 25,800 (same type as protection Q612/Q614)",
  "Yes", "No", 3, 0, 0.0104, LC("C20526"), "NEW (E-16), CHANGED (R9 leakage check) AO3400A -> MMBT3904; pin 1 B, 2 E, 3 C"),
 (B5, "R537", 1, "Q507 base series resistor from N5_U102_OFF (MCU PC14): IB 19 uA -> saturated at IC 14 uA; 26 uA from PC14 in Stop", "100 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "CHANGED (R9) 1 M gate pull-down -> 100 k base series"),
 (B5, "R538", 1, "Q507 base-emitter resistor: default off at reset (PC14 floating); VBE <= 55 mV at 0.55 uA ICBO (60 C)", "100 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF1003TCE", "C25741", "Basic", "JLCPCB Basic", "Yes", "No", 2, 0, 0.0033, LC("C25741"), "NEW (R9)"),
 (B5, "C516", 1, "ANA_SENSE ADC input capacitor at PA0", "100 pF", "0402", "50 V C0G +-5 %", "Samsung CL05C101JB5NNNC", "C1546", "Basic",
  "JLCPCB Basic", "Yes", "No", 2, 0, 0.002, LC("C1546"), "NEW (X-5, R8 round 3); place at the MCU PA0 pin"),
 (B5, SCH_REFS, len(SCH_REFS.split(",")), SCH_DESC, "-", SCH_PKG, SCH_RATING, SCH_MPN, SCH_LCSC, SCH_CLASS, SCH_STOCK, "Yes", "No", SCH_PINS, 0,
  SCH_PRICE, SCH_URL, "NEW (X-4, R8 round 3); anode on the regulator OUT, cathode on its IN; each <= 3 mm from its regulator"),
 (B5, "Q502, Q503, Q504, Q505, Q506", 5, "N-MOSFETs of the EN-derived discharge: Q502/Q504 inverters (gate AVCC_EN / AUD_EN), "
  "Q503/Q505/Q506 discharge 3V3A/3V3D/1V3", "AO3400A", "SOT-23", "30 V, VGS(th) 0.65-1.45 V, Rds(on) <= 48 mOhm at 2.5 V",
  "AOS AO3400A", "C20917", "Basic", "JLCPCB 723,732 (Sep 2026)", "Yes", "No", 3, 0, 0.0853,
  "https://www.aosmd.com/res/datasheets/AO3400A.pdf", "round 1 (R8-A4/B11); Q506/R530 kept in round 2 (TLV758P 95 ohm is typical only, c06/c12)"),
 (B5, "R526, R528", 2, "Discharge-gate pull-ups to 3V3M (on when the EN is low)", "22 kOhm", "0402", "1 %",
  "UNI-ROYAL 0402WGF2202TCE", "C25768", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.002, LC("C25768"), "NEW"),
 (B5, "R527, R529", 2, "Discharge resistors 3V3A (R527) and 3V3D (R529): <= 0.39 / 0.63 ms to < 0.1 V (c06 round 2)", "10 Ohm", "0603",
  "1 %, 0.1 W (pulse <= 0.1 mJ)", "UNI-ROYAL 0603WAF100JT5E", "C22859", "Basic", "as Parts List v0.6", "Yes", "No", 2, 0, 0.003,
  LC("C22859"), "NEW; replace bleeders R524/R525"),
 (B5, "R530", 1, "Discharge resistor 1V3 (<= 0.13 ms, c06 round 2; faster than 3V3D so DVDD <= DVCC; TLV758P internal pull-down 95 ohm typ only)", "4.7 Ohm", "0603", "1 %, 0.1 W",
  "UNI-ROYAL 0603WAF470KT5E", "C23164", "Basic (not verified)", "LCSC 682,400 (Sep 2026)", "Yes", "No", 2, 0, 0.0029, LC("C23164"), "NEW"),
 (B5, "R531", 1, "DNF: damping resistor across C507 (with C513) - fit only if VIN ripple measurement requires", "1 Ohm", "0603",
  "1 %", "UNI-ROYAL 0603WAF100KT5E", "C22936", "Basic (per LCSC CN)", "LCSC 987,900 (Mar 2026)", "DNF", "No", 2, 0, 0.002,
  LC("C22936"), "NEW DNF fallback (P-22)"),
 (B5, "C513", 1, "DNF: damping capacitor in series with R531", "10 uF", "0805", "25 V X5R +-10 %", "Samsung CL21A106KAYNNNE",
  "C15850", "Basic", "as Parts List v0.6", "DNF", "No", 2, 0, 0.085, LC("C15850"), "NEW DNF fallback (P-22)"),
]
hdr = ["block", "refs", "qty", "desc", "value", "package", "rating_tolerance", "mpn", "lcsc", "jlcpcb_class",
       "jlcpcb_stock_or_sourcing", "fit", "leadless", "smt_pins_per_part", "tht_pins_per_part", "unit_price_usd",
       "datasheet_url", "note"]
with open(os.path.join(OUT, "bom_rows.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(hdr)
    for r in bom:
        w.writerow(r)

# ------------------------------------------------------------------------------- netlist
N = []
def two(ref, n1, n2, note=""):
    N.append((ref, "1", "1", n1, note)); N.append((ref, "2", "2", n2, note))
def pins(ref, lst, note=""):
    for p, name, net in lst:
        N.append((ref, str(p), name, net, note))
# J101 GCT USB4105-GF-A: pad labels exactly as on the GCT drawing (pads named by contact; combined pads carry two contacts)
jn = "GCT USB4105 drawing pad label (Recommended PCB Layout); continuity-check samples (R8-A10)"
pins("J101", [("A1/B12", "GND (A1+B12)", "GND"), ("A4/B9", "VBUS (A4+B9)", "VBUS"), ("B8", "SBU2", "NC"), ("A5", "CC1", "CC1"),
              ("B7", "DN2", "USB_DN"), ("A6", "DP1", "USB_DP"), ("A7", "DN1", "USB_DN"), ("B6", "DP2", "USB_DP"),
              ("A8", "SBU1", "NC"), ("B5", "CC2", "CC2"), ("B4/A9", "VBUS (B4+A9)", "VBUS"), ("B1/A12", "GND (B1+A12)", "GND"),
              ("S1", "SHELL stake", "N1_SHIELD"), ("S2", "SHELL stake", "N1_SHIELD"), ("S3", "SHELL stake", "N1_SHIELD"),
              ("S4", "SHELL stake", "N1_SHIELD")], jn)
pins("U103", [(1, "NC", "NC"), (2, "NC", "NC"), (3, "IO1", "CC1"), (4, "GND", "GND"), (5, "IO2", "CC2")],
     "TPD2E2U06 DRL; at J101, own GND via")
pins("U102", [(1, "OUT", "5V_SYS"), (2, "ILIM", "N1_U102_ILIM"), (3, "FAULT", "NC"), (4, "EN", "N1_U102_EN"),
              (5, "GND", "GND"), (6, "IN", "VBUS"), ("PAD", "PowerPAD", "GND")], "TPS25200 DRV pin table 4-1")
two("R108", "N1_U102_ILIM", "GND")
two("R109", "VBUS", "N1_U102_EN")
two("C102", "VBUS", "GND", "place at U102 IN pin / J101")
two("C104", "N1_U102_EN", "GND", "at U102 pin 4 (X-2)")
pins("Q507", [(1, "B", "N5_Q507_B"), (2, "E", "GND"), (3, "C", "N1_U102_EN")], "MMBT3904: U102 off in Stop (E-16); PC14 high = off")
two("R537", "N5_U102_OFF", "N5_Q507_B", "Q507 base series")
two("R538", "N5_Q507_B", "GND", "Q507 base-emitter, default U102 on")
pins("D102", [(1, "K", "VBUS"), (2, "A", "GND")], "SMDJ12A DO-214AB: pin 1 = cathode (band) to VBUS; <= 5 mm from J101 (X-3)")
pins("U101", [(1, "I/O1", "USB_DP"), (2, "GND", "GND"), (3, "I/O2", "USB_DN"), (4, "I/O2", "USB_DN"),
              (5, "VBUS", "3V3M"), (6, "I/O1", "USB_DP")], "USBLC6-2SC6 pinout; pins 1/6 and 3/4 flow-through")
two("R101", "CC1", "GND"); two("R102", "CC2", "GND")
two("R103", "CC1", "CC1_ADC"); two("R104", "CC2", "CC2_ADC")
two("R105", "5V_SYS", "VBUS_SENSE"); two("R106", "VBUS_SENSE", "GND")
two("C103", "VBUS_SENSE", "GND", "at the MCU PA1 pin")
two("R107", "N1_SHIELD", "GND")
two("C101", "N1_SHIELD", "GND", "DNF")
# block 3 power parts
pins("U302", [(1, "IN", "5V_SYS"), (2, "GND", "GND"), (3, "EN", "AVCC_EN"), (4, "N/C", "NC"), (5, "OUT", "3V3A")], "LP5907 DBV")
two("C301", "5V_SYS", "GND"); two("C302", "3V3A", "GND"); two("R303", "AVCC_EN", "GND")
pins("U303", [(1, "IN", "3V3D"), (2, "GND", "GND"), (3, "EN", "3V3D"), (4, "FB", "N3_1V3_FB"), (5, "OUT", "1V3")],
     "TLV75801P DBV (Figure 4-2); EN tied to IN (X-4, R8 round 3)")
two("C311", "3V3D", "GND"); two("C312", "1V3", "GND")
two("R533", "1V3", "N3_1V3_FB", "U303 feedback top, at the FB pin"); two("R534", "N3_1V3_FB", "GND", "U303 feedback bottom")
# block 5
pins("U502", [(1, "IN", "VBUS"), (2, "GND", "GND"), (3, "EN", "NC"), (4, "NC", "NC"), (5, "OUT", "3V3M")], "TPS70933 DBV (Figure 5-1); EN floating = enabled (EN max 6.5 V)")
two("C501", "5V_SYS", "GND"); two("C502", "3V3M", "GND")
pins("U504", [(1, "OUT", "3V3D"), (2, "SNS", "3V3D"), (3, "GND", "GND"), (4, "EN", "AUD_EN"), (5, "GND", "GND"),
              (6, "IN", "5V_SYS"), ("PAD", "Thermal pad", "GND")], "TLV767 DRV fixed; SNS to OUT at C512")
two("C512", "3V3D", "GND"); two("R508", "AUD_EN", "GND")
pins("U503", [(1, "GND", "GND"), (2, "dVdt", "N5_DVDT"), (3, "EN/UVLO", "ANA_EN"), (4, "IN", "5V_SYS"), (5, "OUT", "5V_ANA"),
              (6, "FLT", "ANA_FAULT_N"), (7, "ILM", "N5_ILIM"), (8, "OVCSEL", "NC"), ("PAD", "Thermal pad", "GND")],
     "TPS259621 DDA; pin 8 open = 13.8 V clamp option (never active behind U102)")
two("C505", "5V_SYS", "GND", "at U503 IN"); two("C506", "5V_ANA", "GND"); two("C514", "N5_DVDT", "GND", "dVdt, at pin 2")
two("R509", "N5_ILIM", "GND", "keep the ILM node short"); two("R510", "N5_ILIM", "N5_ILIM_HI")
pins("U505", [(1, "D", "N5_ILIM_HI"), (2, "S", "GND"), (3, "GND", "GND"), (4, "SEL", "ILIM_HI"), (5, "VDD", "3V3M")],
     "TMUX1101 DBV; next to U503")
two("C515", "3V3M", "GND", "U505 VDD decoupling")
two("R511", "ILIM_HI", "GND"); two("R512", "ANA_FAULT_N", "3V3M"); two("R513", "ANA_EN", "GND")
two("FB501", "5V_ANA", "5V_ANA_F")
pins("U501", [(1, "PGOOD", "N5_PGOOD"), (2, "FB+", "N5_FBP"), (3, "VIN", "5V_ANA_F"), (4, "GND", "GND"), (5, "CP", "N5_CP"),
              (6, "OUT-", "VNEG"), (7, "FB-", "N5_FBN"), (8, "EN-", "5V_ANA_F"), (9, "C1-", "N5_C1N"),
              (10, "C1+", "N5_C1P"), (11, "OUT+", "VPOS"), (12, "EN+", "5V_ANA_F"), ("PAD", "Thermal pad", "GND")],
     "LM27762 DSS table 4-1; EN+/EN- tied to VIN at the pins (X-1)")
two("C507", "5V_ANA_F", "GND"); two("C508", "N5_C1P", "N5_C1N"); two("C509", "N5_CP", "GND")
two("C510", "VPOS", "GND"); two("C511", "VNEG", "GND")
two("R501", "VPOS", "N5_FBP"); two("R502", "N5_FBP", "GND"); two("R503", "VNEG", "N5_FBN"); two("R504", "N5_FBN", "GND")
two("R505", "N5_PGOOD", "5V_ANA_F"); two("R522", "N5_PGOOD", "RAILS_OK_N")
two("R532", "RAILS_OK_N", "GND", "at the MCU PB4 pin")
two("R535", "5V_ANA_F", "ANA_SENSE", "X-5 divider top"); two("R536", "ANA_SENSE", "GND", "X-5 divider bottom")
two("C516", "ANA_SENSE", "GND", "at the MCU PA0 pin")
for ref, (a, k) in SCH_PAIRS.items():
    pins(ref, [(pn, nm, a if role == "A" else (k if role == "K" else "NC")) for pn, nm, role in SCH_PINMAP], "Schottky OUT->IN (X-4): anode = regulator OUT, cathode = IN")
two("R531", "5V_ANA_F", "N5_DAMP", "DNF"); two("C513", "N5_DAMP", "GND", "DNF")
# discharge
pins("Q502", [(1, "G", "AVCC_EN"), (2, "S", "GND"), (3, "D", "N5_DIS_A")], "AO3400A inverter for the 3V3A discharge")
two("R526", "3V3M", "N5_DIS_A")
pins("Q503", [(1, "G", "N5_DIS_A"), (2, "S", "GND"), (3, "D", "N5_DIS_A_R")], "AO3400A 3V3A discharge")
two("R527", "3V3A", "N5_DIS_A_R")
pins("Q504", [(1, "G", "AUD_EN"), (2, "S", "GND"), (3, "D", "N5_DIS_D")], "AO3400A inverter for 3V3D/1V3 discharge")
two("R528", "3V3M", "N5_DIS_D")
pins("Q505", [(1, "G", "N5_DIS_D"), (2, "S", "GND"), (3, "D", "N5_DIS_D_R")], "AO3400A 3V3D discharge")
two("R529", "3V3D", "N5_DIS_D_R")
pins("Q506", [(1, "G", "N5_DIS_D"), (2, "S", "GND"), (3, "D", "N5_DIS_13_R")], "AO3400A 1V3 discharge")
two("R530", "1V3", "N5_DIS_13_R")
with open(os.path.join(OUT, "netlist.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["refdes", "pin", "pin_name", "net", "note"])
    for r in N:
        w.writerow(r)

# consistency checks
refs_bom = []
for r in bom:
    for x in r[1].split(","):
        refs_bom.append(x.strip())
refs_net = sorted(set(r[0] for r in N))
missing = sorted(set(refs_bom) - set(refs_net)); extra = sorted(set(refs_net) - set(refs_bom))
qty_ok = all(r[2] == len(r[1].split(",")) for r in bom)
print(f"BOM lines {len(bom)}, parts {len(refs_bom)} (fitted {sum(r[2] for r in bom if r[11]=='Yes')}, DNF "
      f"{sum(r[2] for r in bom if r[11]=='DNF')}); netlist rows {len(N)}; missing in netlist {missing}; extra {extra}; qty ok {qty_ok}")
cost = sum(r[2] * r[15] for r in bom if r[11] == "Yes")
print(f"Fitted part cost (unit prices as listed): US$ {cost:.2f} per board")
from collections import Counter
nets = Counter(r[3] for r in N)
single = [n for n, c in nets.items() if c == 1 and n not in ("NC",)]
print("Nets with a single connection inside this stream (connect to other streams):", sorted(single))
