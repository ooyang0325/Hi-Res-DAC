"""c17 - USB budget round 3 (decisions_r8c.md): new loads of the review fixes added to the c03 round-2 inventory
(c03_results.json), R509/R510 re-selected by the D-5 rule (Default total = non-analog max + IOS max + IQ + ILM current <= 490 mA;
IOS min >= analog need and >= 180 mA if the budget allows; High IOS min >= 390 mA and >= the High need), states S1-S6 recomputed
incl. suspend with the IWDG periodic wake. Labels as in pw_common."""
import json, os
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
R = json.load(open(os.path.join(HERE, "c03_results.json")))
C16 = json.load(open(os.path.join(HERE, "c16_results.json"))) if os.path.exists(os.path.join(HERE, "c16_results.json")) else {}
out = []; P = out.append
P(hdr("1. New loads (maxima; mA) - by rail and state"))
VE3 = float(os.environ.get("C17_BLOCK6_DELTA", str((2.66 - 1.660) + 1.03 * (2.48 - 1.631))))   # protection R9 check final: block 6 I+ <= 2.66 / I- <= 2.48 mA vs R3.7 1.660/1.631
NEW = [  # (name, rail, mA, states where present, label)
 ("protection U605 TLV3402 + dividers + pull-ups on 3V3M, 3V3A good", "3V3M", 0.0742, "S2 S3 S3f S4 S5", "[protection R3.7 p10]"),
 ("protection U605 + dividers on 3V3M, 3V3A off (outputs released)", "3V3M", 0.0076, "S1 S6", "[protection R3.7 p10]"),
 ("protection U605 dividers on 3V3A", "3V3A", 0.0057, "S2 S3 S3f S4 S5", "[protection R3.7]"),
 ("protection U607 74AUP1G17 at 80 MHz + pump (MCLK-alive detector) on 3V3D", "3V3D", 3.36, "S2 S3 S3f S4 S5", "[protection R3.7, CPD 6 pF ASSUMP]"),
 ("analog 5V_ANA quiescent 71.56 mA (block 6 1.660/1.631 mA incl. U606, T495 leakage bound 0.22 mA/rail) vs 70.32", "5V_ANA", 71.56 - 70.32, "S2 S3f S4", "[analog R3.12]"),
 ("analog 5V_ANA quiescent with the DAC in reset 86.29 mA vs 85.01", "5V_ANA", 86.29 - 85.01, "S5", "[analog R3.12]"),
 ("protection R9 check final: block 6 I+ 2.66 / I- 2.48 mA (vs 1.660/1.631) -> +1.00 + 1.03 x 0.849 at 5V_ANA", "5V_ANA", VE3, "S2 S3 S3f S4 S5", "[protection R9 check 19:15]"),
 ("protection R9 E-2 re-arm latch U608 + Q621/Q622 on 3V3D", "3V3D", 0.03, "S2 S3 S3f S4 S5", "[protection R9]"),
 ("digital U208 74LVC3G34 on 3V3D at 384 kHz: 4 uA + (14 + 6 pF) x 3.333 V x (36 + 18 MHz) x 70 % burst", "3V3D", 2.52, "S2 S3 S3f S4 S5", "[digital R3 currents_output]"),
 ("digital R238/R239 JTAG 10 k vs the unpublished AGRV2K internal pulls (typ 0)", "3V3D", 0.167, "S2 S3 S3f S4 S5", "[digital ASSUMP bound]"),
 ("digital R240 100 k Q207 gate pull-up to 3V3M, PA8 low (DAC released)", "3V3M", 3.35 / 100e3 * 1e3, "S2 S3 S3f S4", "[digital R3: 33 uA]"),
 ("digital R233 retired (X-7)", "3V3M", -0.032, "S1 S2 S3 S3f S4 S5", "[digital R3]"),
 ("DAC RESETB pull-up 10 k to DVCC through Q207 (DAC held in reset)", "3V3D", 3.35 / 10e3 * 1e3, "S5", "[ASSUMP value 10 k, analog R305]"),
 ("R237 4.7 k + R508 10 k (AUD_EN high): 0.230 mA, minus the round-2 0.070 mA (47 k)", "3V3M", C16.get("E", {}).get("i_r508", 0.00023) * 1e3 - 0.070, "S2 S3 S3f S4 S5", "[CALC c16 E]"),
 ("R236 10 k (AVCC_EN -> N2_AVCC_EN_G): no DC current with 3V3A good (U206 CMOS input)", "3V3M", 0.0, "-", "[CALC]"),
 ("ANA_SENSE divider R535/R536 100 k/47 k on 5V_ANA_F (VE)", "5V_ANA", 5.55 / 147e3 * 1e3, "S2 S3 S3f S4 S5", "[CALC c20 c]"),
 ("D102 SMDJ12A leakage at 5.5 V / 50 C (VBUS)", "VBUS", 0.005, "S1 S2 S3 S3f S4 S5 S6", "[X-3 target; estimate 3.0 uA c16 C]"),
 ("D103-D107 Schottky reverse leakage, total at 50 C", "5V_SYS", 0.010, "S1 S2 S3 S3f S4 S5 S6", "[X-4 bound]"),
 ("MCU suspend IWDG 0.67-1.60 s, wake every 0.50-1.20 s (DX-2), average above Stop", "3V3M", 0.0045, "S6", "[digital R3 currents_output, DX-2; replaces 0.189 mA]"),
]
for nm, rail, i, st, lab in NEW:
    P(f"  {nm:88s} {rail:7s} {i:7.3f} mA  {st:26s} {lab}")
def add(state, branch):
    return sum(i for nm, rail, i, st, lab in NEW if state in st.split() and ((rail == "5V_ANA") == (branch == "ana")))
P(hdr("2. R509 / R510 re-selection (D-5 rule, TPS2596 +-10.4 % headline, R 0.1 % + 25 ppm x 35 K)"))
NONANA = R["NONANA"] * 1e3 + add("S3", "non")
EXTRA_ANA = add("S3", "ana")
NEED = 176.9 + 5.55 / 147e3 * 1e3 + VE3        # [analog R3.12 final need] + ANA_SENSE (VE: 100 k/47 k) + protection R9 block-6 increase
ILM_I = (R["T_DEF"] - R["NONANA"] - R["DEF"][2] - R["IQ2596"]) * 1e3
P(f"  Non-analog maximum (S3): round 2 {R['NONANA']*1e3:.2f} + {add('S3','non'):.2f} = {NONANA:.2f} mA; Default need {NEED:.3f} mA"
  f" (analog R3.12 final 176.9 mA + ANA_SENSE 0.038 mA + protection R9-check block 6 +1.87 mA; analog basis 178.81 - 0.026 + 0.038 = 178.82 mA); ILM pin current {ILM_I:.2f} mA, IQ 0.266 mA.")
def ios(r):
    return [x * 1e3 for x in tps2596_ios(r, mode="headline")]
chk = ios(4750.0)
P(f"  check vs round 2: 4.75 k -> {chk[0]:.1f}/{chk[1]:.1f}/{chk[2]:.1f} mA (round 2: 180.1/201.3/222.6)")
rows = []
for series, vals in (("E96", [v * 10 for v in e96()]), ("E192", [464, 467, 470, 472, 475, 478, 481, 484, 487, 491, 495, 499, 503, 507])):
    for v in vals:
        r = float(v) if series == "E96" else v * 10.0
        if not (4400 <= r <= 5120):
            continue
        mn, nm_, mx = ios(r)
        tot = NONANA + mx + 0.266 + ILM_I
        rows.append((series, r, mn, nm_, mx, tot))
best = None
for series, r, mn, nm_, mx, tot in sorted(rows, key=lambda x: x[1]):
    ok = tot <= 490.0 and mn >= NEED
    tag = "OK" + (" (>= 180)" if mn >= 180 else "") if ok else ("total > 490" if tot > 490 else "IOS min < need")
    if series == "E96" or 4640 < r < 4870:
        P(f"  {series:4s} R509 {r/1e3:5.3f} k: IOS {mn:6.1f} / {nm_:6.1f} / {mx:6.1f} mA, Default total {tot:6.2f} mA -> {tag}")
    if ok and series == "E96" and (best is None or (mn >= 180 and best[2] < 180) or (mn >= 180) == (best[2] >= 180) and mn > best[2]):
        best = (series, r, mn, nm_, mx, tot)
CONFLICT = False
if best is None:          # no E96 value meets both parts of the rule -> finest standard series (E192, 0.1 % thin film)
    for series, r, mn, nm_, mx, tot in sorted(rows, key=lambda x: -x[2]):
        if series == "E192" and tot <= 490.0 and mn >= NEED:
            best = (series, r, mn, nm_, mx, tot); break
    P("  No E96 value meets 'total <= 490 mA AND IOS min >= need' -> the rule is applied on E192 (same 0.1 % / 25 ppm thin-film family).")
if best is None:          # the two parts of the D-5 rule conflict: keep the requirements (need, USB 500 mA), report the reserve shortfall
    CONFLICT = True
    cand = [x for x in rows if x[2] >= NEED and x[5] <= 500.0]
    best = sorted(cand, key=lambda x: x[5])[0]
    alt = sorted([x for x in rows if x[5] <= 490.0], key=lambda x: -x[2])[0]
    P(f"  RULE CONFLICT: no value meets both 'total <= 490 mA' and 'IOS min >= need'. Chosen: the value that meets the need and the USB 500 mA"
      f" limit with the smallest total: {best[1]/1e3:.2f} k ({best[0]}) -> total {best[5]:.2f} mA (490 mA reserve rule exceeded by {best[5]-490:.2f} mA,"
      f" <= 500 mA by {500-best[5]:.2f} mA), IOS min {best[2]:.1f} mA (need +{best[2]-NEED:.2f}). Alternative meeting the 490 mA rule:"
      f" {alt[1]/1e3:.2f} k -> {alt[5]:.2f} mA, IOS min {alt[2]:.1f} mA ({alt[2]-NEED:+.2f} mA vs the need). DECIDED by the orchestrator (DY-1): 4.81 k / 3.74 k kept, Default total <= 490.8 mA accepted (9.2 mA to 500 mA).")
os.environ.setdefault("C17_R509", "4750")    # E-18 (decisions_r9): R509 4.75 k owner-fitted
os.environ.setdefault("C17_R510", "3740")    # R510 3.74 k kept (High targets hold)
if os.environ.get("C17_R509"):
    rf = float(os.environ["C17_R509"])
    forced = [x for x in rows if abs(x[1] - rf) < 0.5]
    if forced:
        best = forced[0]
        P(f"  R509 FIXED by decision (E-18): {rf/1e3:.2f} k -> IOS {best[2]:.1f}/{best[3]:.1f}/{best[4]:.1f} mA, Default total {best[5]:.2f} mA,"
          f" need margin {best[2]-NEED:+.2f} mA")
r509 = best[1]
P(f"  -> R509 = {r509/1e3:.2f} k ({best[0]}{', rule conflict' if CONFLICT else ', same rule'}): IOS {best[2]:.1f}/{best[3]:.1f}/{best[4]:.1f} mA, Default total {best[5]:.2f} mA"
  f" ({490-best[5]:+.2f} mA to 490, {500-best[5]:+.2f} mA to 500); IOS min - need = {best[2]-NEED:+.2f} mA; >= 180 mA: {'yes' if best[2] >= 180 else 'no'}.")
P(f"  Margins: total {490-best[5]:+.2f} mA to the 490 mA rule, need {best[2]-NEED:+.2f} mA -> BOM value only, same land.")
# High branch
best_h = None
for v in e96():
    r510 = v * 10.0
    if not (3000 <= r510 <= 4500):
        continue
    rp = lambda a, b: a * b / (a + b)
    ron = TMUX1101["RON_MAX_3V3_85"]
    rmin = rp(r509 * 0.9981, r510 * 0.9981); rmax = rp(r509 * 1.0019, r510 * 1.0019 + ron)
    hmin = (903 / rmax + 0.0112) * (1 - 0.104) * 1e3; hmax = (903 / rmin + 0.0112) * 1.104 * 1e3; hnom = (903 / rp(r509, r510) + 0.0112) * 1e3
    if hmin >= 390 and hmin >= 317 and (best_h is None or r510 > best_h[0]):
        best_h = (r510, hmin, hnom, hmax)
if os.environ.get("C17_R510"):
    r510f = float(os.environ["C17_R510"])
    rp2 = lambda a, b: a * b / (a + b); ronf = TMUX1101["RON_MAX_3V3_85"]
    rmin_f = rp2(r509 * 0.9981, r510f * 0.9981); rmax_f = rp2(r509 * 1.0019, r510f * 1.0019 + ronf)
    best_h = (r510f, (903 / rmax_f + 0.0112) * (1 - 0.104) * 1e3, (903 / rp2(r509, r510f) + 0.0112) * 1e3, (903 / rmin_f + 0.0112) * 1.104 * 1e3)
    P("  R510 FIXED (BOM): High branch recomputed below.")
P(f"  R510 = {best_h[0]/1e3:.2f} k (largest E96 with High IOS min >= 390 mA): High IOS {best_h[1]:.1f}/{best_h[2]:.1f}/{best_h[3]:.1f} mA;"
  f" High total {NONANA + best_h[3] + 0.266 + ILM_I*best_h[3]/best[4]:.1f} mA (S4 limit 1500 mA).")
P(hdr("3. States (maxima, mA) - FINAL round 3 (decisions_r8c DY-1..DY-5: R509 4.81 k, R510 3.74 k, C514 10 nF, C441 DNF)"))
S = R["S"]
st = {}
st["S1"] = S["S1"] * 1e3 + add("S1", "non")
st["S2"] = S["S2"] * 1e3 + add("S2", "non") + add("S2", "ana")
st["S3"] = NONANA + best[4] + 0.266 + ILM_I
st["S3f"] = S["S3f"] * 1e3 + add("S3f", "non") + add("S3f", "ana")
st["S4"] = S["S4"] * 1e3 + add("S4", "non") + (best_h[3] - R["HIGH"][2] * 1e3)
st["S5"] = S["S5"] * 1e3 + add("S5", "non") + add("S5", "ana")
s6_ac = R["S6_AC"] * 1e3 + add("S6", "non"); s6_cc = R["S6_CC"] * 1e3 + add("S6", "non")
d_alt = 0.0
LIM = {"S1": 100, "S2": 500, "S3": 500, "S3f": 500, "S4": 1500, "S5": 500}
for k, v in st.items():
    P(f"  {k:4s} {v:8.2f} mA  limit {LIM[k]:5d}  margin {LIM[k]-v:+8.2f}   (round 2 {S[k]*1e3 if k in S else float('nan'):.2f})")
P(f"  S3 vs the D-5 490 mA reserve rule: {490-st['S3']:+.2f} mA - accepted by the orchestrator (DY-1: Default total <= 490.8 mA, 9.2 mA to 500 mA).")
P(f"  S5 programming mode now only after SET_CONFIGURATION (<= 500 mA granted, decisions r8c) -> limit 500 mA (was 'charger/bench').")
P(f"  S6 suspend (DX-2 wake 4.5 uA, protection final 7.6 uA): legacy A-to-C {s6_ac:.4f} mA, C-to-C {s6_cc:.4f} mA vs 2.5 mA -> margin"
  f" {(2.5-s6_ac)*1e3:+.1f} / {(2.5-s6_cc)*1e3:+.1f} uA  (with the superseded 0.189 mA wake: {s6_ac+0.1845:.3f} / {s6_cc+0.1845:.3f} mA)")

wo = s6_ac - 1.0
P(f"     of which MCU Stop + USB-HS PHY suspended 1.900 mA [PH brief section 6] (typ 0.11 mA), protection 0.0076 mA, IWDG wake 0.0045 mA (DX-2, digital).")
P(f"     The MCU Stop placeholder may rise to {1.9+(2.5-s6_ac):.4f} mA (A-to-C) / {1.9+(2.5-s6_cc):.4f} mA (C-to-C) before the limit is reached.")
P(f"     With the WCH typical Stop 0.11 mA instead of 1.9 mA: {s6_ac-1.79:.3f} mA (information only, typical).")
P("  L-1 (plain): the CH32V307 run/Stop/USB-PHY-suspend and the AGRV2K CPLD currents are NOT published as maxima; the budgets above use")
P("  conservative placeholders (MCU 80 mA vs 22.4 mA typ; Stop 1.9 mA vs 0.11 mA typ; CPLD 40 mA). With those placeholders the")
P("  suspend margin is the figure above (placeholder-based); compliance of 100 mA / 500 mA / 2.5 mA is established only by measuring every")
P("  board in every state (production test).")
c22p = os.path.join(HERE, "c22_results.json")
if os.path.exists(c22p):
    c22 = json.load(open(c22p))
    P(f"  E-16 (suspend power cut, R9): S6 SUPERSEDED by c22 -> {c22['S6']:.4f} mA legacy A-to-C (margin {(2.5-c22['S6'])*1e3:+.0f} uA), {c22['S6']-0.094:.4f} mA C-to-C;"
      " S1-S5 above unchanged (U502 input moved to VBUS, same USB total).")
res = dict(NONANA=NONANA, NEED=NEED, R509=r509, R510=best_h[0], DEF=best[2:5], HIGH=best_h[1:4], S=st, S6_AC=s6_ac, S6_CC=s6_cc,
           S6_WAKE=0.0045)
json.dump(res, open(os.path.join(HERE, "c17_results.json"), "w"), indent=1)
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
