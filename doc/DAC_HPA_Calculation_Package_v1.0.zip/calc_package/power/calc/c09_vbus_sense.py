"""c09 - VBUS sensing on 5V_SYS: divider R105 100 k / R106 47 k (1 %), C103 10 nF at the ADC pin (PA1, D-13).
R8 round 2: digital TS = 55.5 cycles at 12 MHz (source <= 50 k allowed, digital D9); CH32V307 ADC errors EO/ED/EL 4/3/4 LSB max
[DS tables 4-42/4-43 via protection]; minimum operating 5V_SYS 4.311 V (c04); hard-unplug detection latency from c14."""
import json, os
from pw_common import *
out = []
P = out.append
R1, R2, C = 100e3, 47e3, 10e-9
k = R2 / (R1 + R2); Rth = R1 * R2 / (R1 + R2)
P(hdr("Divider and filter"))
P(f"k = {k:.4f}; 5V_SYS 5.55 V -> {5.55*k:.3f} V at the pin (< VDDA 3.25 V); R_th = {Rth/1e3:.2f} k; tau = {Rth*C*1e3:.3f} ms with C103")
P(f"Current from 5V_SYS: {5.5/(147e3*0.99)*1e6:.1f} uA max (in the suspend budget)")
P(hdr("ADC acquisition"))
P("ADC1 continuous single channel (digital D9): TS 55.5 cycles at 12 MHz allows a 50 k source [DS table 4-42 formula, digital], so the"
  " 32 k divider alone is sufficient; C103 additionally makes the sample-capacitor charge sharing negligible (<= 4 mV even multiplexed).")
P(hdr("Brown-out threshold on 5V_SYS and its worst-case band"))
V_TH = 4.00
LEAK = 1e-6                        # [ASSUMP] PA1 leakage max (not confirmed by the digital stream)
ADC_ERR = (4 + 3 + 4) * 3.3 / 4096   # [DS] EO + ED + EL, linear sum
e_rel = 0.014 + TPS7A20["ACC"]
e_abs = LEAK * Rth / k + ADC_ERR / k
lo, hi = V_TH * (1 - e_rel) - e_abs, V_TH * (1 + e_rel) + e_abs
V5MIN = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c04_results.json")))["V5MIN"]
P(f"Nominal 4.00 V: band {lo:.3f} .. {hi:.3f} V (relative {e_rel*100:.1f} %: divider 1.4 %, VDDA 1.5 %; absolute +-{e_abs*1e3:.0f} mV: leakage"
  f" {LEAK*Rth/k*1e3:.0f} mV, ADC 11 LSB {ADC_ERR/k*1e3:.0f} mV) [CALC]")
P(f"No false trip at the minimum operating 5V_SYS {V5MIN:.3f} V (VBUS 4.40 V, High): margin {V5MIN-hi:+.3f} V; the trip precedes the 3V3D"
  f" dropout point 3.536 V (c04) by >= {lo-3.536:.3f} V and 3V3M (3.390 V) by >= {lo-3.390:.3f} V.")
P("Recommended firmware debounce: 2 consecutive watchdog conversions (2 x 5.67 us) - rejects a single-sample spike, costs 6 us.")
P(hdr("Detection latency at a hard unplug (c14 time-domain model, 96 corners per case)"))
P("  C103 10 nF (D-13): action 0.21-0.34 ms after the source disappears; in 30 of 96 corners the MCU resets first (action lost);"
  " with C103 not fitted (or <= 100 pF, tau <= 3.2 us): 0.05-0.12 ms, executed in 96/96 corners.")
P("  Effect on the analog unplug window (c14 section 4): worst 0.27 ms with C103 vs 0.08 ms without; on MCLK: stopped at 3V3D >= 3.17 V"
  " without C103 vs >= 1.65 V with it (both meet the digital 3V3D <= 3V3A + 0.3 V rule).")
P("  -> Recommendation to integration (BOM value only, same 0402 land): C103 10 nF -> 100 pF 50 V C0G (or DNF). Kept at 10 nF in this"
  " BOM because D-13 names it; the digital TS 55.5 setting does not need it.")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
