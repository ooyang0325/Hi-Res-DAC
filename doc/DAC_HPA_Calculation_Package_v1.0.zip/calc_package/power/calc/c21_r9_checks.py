"""c21 - R9 fixes (decisions_r9.md): E-5 suspend inventory and options, E-8 C442/C443 reverse bias with D413/D414,
brown-out margin line, E-6 Default acceptance numbers. Labels as in pw_common."""
import json, math, os
from pw_common import *
HERE = os.path.dirname(os.path.abspath(__file__))
C17 = json.load(open(os.path.join(HERE, "c17_results.json")))
out = []; P = out.append
P(hdr("E-5  Suspend (S6, legacy A-to-C cable) - inventory on the planning values, corrected terms, options"))
inv = [("MCU Stop + USB-HS PHY suspended [PH brief s6, L-1; typ 0.11 mA]", 1.900, "fixed (E-5)"),
       ("D+ 1.5 k pull-up into the host 15 k (USB 2.0, mandatory)", 0.214, "fixed"),
       ("legacy A-to-C cable Rp 56 k -> Rd 5.1 k (Type-C, mandatory)", 0.094, "fixed"),
       ("U102 TPS25200 IIN(on) [DS 190 uA at 150 k / 200 uA at 33 k; 100 k interpolated by ILIM conductance]", 0.1914, "power"),
       ("U102 EN leakage through R109 [DS IEN 2 uA]", 0.002, "power"),
       ("U502 TPS7A20 IGND at the MCU load [DS]", 0.025, "power"),
       ("VBUS_SENSE divider R105/R106 100 k/47 k at 5.5 V", 0.0374, "power"),
       ("D102 SMDJ12A leakage at 5.5 V/50 C [c16 C estimate 3.0 uA; budget 5 uA]", 0.005, "power"),
       ("D103-D105 BAT54 reverse leakage at 50 C (D104/D105 5 V, D103 1.7 V) - corrected bound", None, "power"),
       ("U101 USBLC6, U504 ISHDN, U302, U503 ISD, U505, U103 [DS]", 0.001 + 0.003 + 0.001 + 0.00113 + 0.0007 + 0.00002, "power"),
       ("protection U605 + dividers (3V3A off) [protection R3.7]", 0.0076, "protection"),
       ("MCU suspend IWDG wake (DX-2) [digital]", 0.0045, "digital")]
# BAT54 leakage bound: IR <= 2 uA at 25 V, 25 C [Nexperia DS]; Schottky IR ~ T^2 exp(-q phiB / kT): phiB 0.65 V [ASSUMP] -> x8.3 at 50 C;
# voltage factor vs 25 V: 0.5 at 5 V, 0.3 at 1.7 V [ASSUMP, barrier lowering]
kT = (323.15 / 298.15) ** 2 * math.exp(0.65 / 8.617e-5 * (1 / 298.15 - 1 / 323.15))
bat = 2e-6 * kT * (0.5 + 0.5 + 0.3) * 1e3
inv[8] = (inv[8][0], bat, "power")
tot = sum(x[1] for x in inv)
for nm, i, own in inv:
    P(f"  {nm:112s} {i:7.4f} mA  [{own}]")
P(f"  TOTAL S6 (A-to-C) = {tot:.4f} mA vs 2.500 mA -> margin {(2.5-tot)*1e3:+.1f} uA  (c17: 2.4965 mA with 10 uA for D103-D105 and 190 uA for U102)")
P(f"  BAT54 bound: 2 uA (25 V, 25 C) x {kT:.1f} (50 C, phiB 0.65 V) x (0.5 + 0.5 + 0.3) = {bat*1e3:.1f} uA [CALC/ASSUMP]; typical ~1.5 uA total;"
  " the reviewer's 12 uA lies inside this bound -> the 10 uA allowance of X-4 is NOT guaranteed.")
fixed = 1.900 + 0.214 + 0.094
P(f"  Fixed by the planning value and USB/Type-C: {fixed:.3f} mA -> everything else must be <= {2.5-0.2-fixed:.3f} mA for a 0.2 mA margin;"
  f" it is {tot-fixed:.3f} mA, of which U102 {0.1914+0.002:.3f} mA.")
P("  Options (power side), saving -> verdict:")
P("   a) VBUS divider 10x higher (1 M/470 k): -34 uA; REJECTED - the 1 uA pin-leakage bound [ASSUMP digital] x 320 k = 0.32 V at PA1 = 1.0 V on 5V_SYS"
  " (band 3.756-4.244 V would widen past the 4.311 V operating minimum -> false brown-out trips).")
P("   b) BAT54 -> lower-leakage diode (BAS70 class, IR <= 0.1 uA at 50 V): -20 uA; REJECTED - VF 0.75-1.0 V at the 10-50 mA reverse currents of c14 -> body"
  " diodes conduct again (X-4 / L-8 residual 0.40-0.46 V would be lost).")
P("   c) protection U605 dividers x10 (protection), digital pin states (digital): <= -7 uA / digital's figure.")
P("   => no drop-in or BOM change reaches a 0.2 mA margin: the U102 IQ (0.19 mA) alone is 95 % of the missing 0.2 mA.")
P("   Designed-in fallback (circuit change, owner/orchestrator decision): 'suspend power cut' - U502 becomes a 30 V low-IQ LDO fed from VBUS"
  " (e.g. TI TPS70933, IQ ~1-2 uA, 150 mA [DS to be re-read]) and an NMOS on U102 EN (MCU GPIO, default = U102 on) turns U102 off in Stop:"
  " U102 5 uA (IIN(off) [DS]), divider 0, D104/D105 0 ->")
fb = fixed + 0.005 + 0.002 + 0.005 + 0.005 + 0.0076 + 0.0045 + 0.001
P(f"      S6 ~ {fb:.3f} mA (margin {(2.5-fb)*1e3:+.0f} uA). Costs/impacts: attach region A +20.3 uC (3V3M caps charge at contact) -> C102 4.7 -> 2.2 uF"
  " (c16 C already covers 2.16 uF effective), 3V3M accuracy/transient re-check (protection U605 thresholds use 3V3M +-1.5 %), a free MCU GPIO"
  " (digital), resume sequence (U102 on, 5V_SYS up <= 7.3 ms before any domain), c01/c02/c14/c16/c17 re-runs. Not adopted in R9.")
res = dict(S6=tot, BAT54=bat, S6_fallback=fb)

P(hdr("E-8  C442/C443 (KEMET T495D227K010, MnO2, 10 V) reverse bias during LM27762 start/off, with D413/D414 (BAT54) clamps"))
I_IVP, I_IVN = 0.0174, 0.0148   # [analog X-8] maximum I/V-rail loads (the current that can drive the other reservoir reverse)
def vf_bat54(i, dT=0.0):
    pts = [(1e-4, 0.24), (1e-3, 0.32), (1e-2, 0.40), (3e-2, 0.50), (1e-1, 0.80)]   # [DS Nexperia maxima, 25 C]
    for (i0, v0), (i1, v1) in zip(pts, pts[1:]):
        if i0 <= i <= i1:
            return v0 + (v1 - v0) * math.log(i / i0) / math.log(i1 / i0) - 0.001 * dT   # -1 mV/K [ASSUMP Schottky tempco]
    return pts[-1][1]
for nm, i in (("C442 (N4_VPOS_IV pulled below GND by the V+ supply current while VNEG_IV is up)", I_IVP),
              ("C443 (N4_VNEG_IV pulled above GND by the V- supply current while VPOS_IV is up)", I_IVN)):
    for T in (0.0, 25.0, 50.0, 60.0):
        v = vf_bat54(i, T - 25.0)
        lim = 10.0 * (0.15 - 0.10 * max(0.0, T - 25.0) / 60.0) if T >= 25 else 1.5   # KEMET: 15 % at 25 C, 5 % at 85 C (linear [ASSUMP])
        P(f"  {nm:88s} T {T:4.0f} C: reverse <= {v:.3f} V (BAT54 at {i*1e3:.1f} mA) vs limit {lim:.2f} V -> margin {lim-v:+.2f} V")
P("  Mechanism: D411/D412 block VPOS/VNEG excursions (R3.17); a reservoir can only be reversed through the OPA2210 supply pins when the other I/V rail"
  " is up and its own is empty (start: EN = VIN releases both LM27762 paths together, either may lead; off: the rail that empties first). The"
  " reverse current is bounded by that rail's maximum load (17.4 / 14.8 mA), which D413/D414 carry at <= 0.45 V (25 C), <= 0.43 V (50 C)."
  " Duration: until the other LM27762 path catches up (start, <= the 18.8 ms start) or the reservoirs discharge (off, tens of ms) - inside"
  " the steady-state reverse rating used here (no pulse credit taken).")
P("  -> open item 6 CLOSED: reverse bias <= 0.48 V at 0 C and <= 0.43 V at 50 C vs >= 0.92 V allowed (60 C local) [KEMET reverse-voltage rule,"
  " linear between 25 and 85 C = ASSUMP].")

P(hdr("Brown-out margin line (thin-margins table, R9-A A8)"))
P("  VBUS_SENSE trip band on 5V_SYS 3.756 .. 4.244 V (c09: divider 1.4 %, VDDA 1.5 %, pin leakage 1 uA x 32 k [ASSUMP] 100 mV, ADC 11 LSB).")
for nm, v in (("High, VBUS 4.40 V", 4.311), ("High, with the J101 mated-contact drop", 4.296), ("Default, VBUS 4.40 V", 4.342)):
    P(f"  5V_SYS min {nm:40s} {v:.3f} V -> margin to the band top {(v-4.244)*1e3:+.0f} mV")
P("  -> the effective brown-out margin at the 4.40 V corner is +52 ... +98 mV (not 0.17 V); dominated by the assumed 1 uA PA1 leakage (100 mV).")

P(hdr("E-6  Default mode - explicit margins and acceptance criterion"))
S = C17["S"]; DEF = C17["DEF"]
P(f"  Design values (c17 final, DY-1): Default total {S['S3']:.2f} mA vs 500 mA (+{500-S['S3']:.2f}); IOS min {DEF[0]:.1f} mA vs need 176.96 mA"
  f" (+{DEF[0]-176.957:.2f}; +{DEF[0]-176.957+0.019:.2f} after the VE ANA_SENSE change); IOS max {DEF[2]:.1f} mA.")
P("  Conservatism of the planning values inside the 490.8 mA: MCU 80 mA vs WCH 22.4 mA typ (+57.6 mA), CPLD 40 mA [ASSUMP, unpublished],"
  " DVDD 60 mA [PH] vs ESS 50 mA nominal (+10), U208 70 % burst at 36 MHz (+~0.8), DVCC/AVCC at nominal-as-max (L-1).")
P("  No BOM change widens both margins: R509 trades them 1 : 1.24 (4.84 k: +1.3 mA USB, -1.0 mA need); the +-10.4 % TPS2596 limit tolerance [DS]"
  " (42 mA window) is the cause. Acceptance criterion: (G) Default power targets guaranteed at IOS min 177.9 mA (+0.95 mA over the analog need);"
  " (E) USB 500 mA holds with 9.2 mA on the planning values; (Q) production test on every board: VBUS current in S3 (Default, full-scale"
  " 1 kHz sine into the worst Default load, 25 C) <= 480 mA (10 mA guard for 25->50 C and meter error) and in S1 <= 90 mA; fail -> R509 4.84 k"
  " or firmware limit.")
res.update(dict(S3=S["S3"], IOSmin=DEF[0]))
json.dump(res, open(os.path.join(HERE, "c21_results.json"), "w"), indent=1)
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
