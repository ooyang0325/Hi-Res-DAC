"""c11 - U503 TI TPS259621DDAR (5V_ANA current limiter) and U505 TMUX1101 (Default/High ILM switch), R8 round 2 (D-5).
Sections: OVCSEL vs the TPS25200 clamp; dVdt capacitor (5V_ANA inrush, ramp time vs the 5 ms RAIL_EN rule); FLT semantics;
current-limit behaviour into music peaks and into a short (foldback / thermal auto-retry); LM27762 start into the limit
(time-domain model, LM27762 start-up current unknown -> swept); stability with C506/FB501/C507; thermal; U505 interface.
Uses c03_results.json (limits) - run c03 first."""
import json, os
import numpy as np
from pw_common import *

out = []
P = out.append
R = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c03_results.json")))
DMIN, DNOM, DMAX = R["DEF"]; HMIN, HNOM, HMAX = R["HIGH"]

P(hdr("1. OVCSEL (pin 8) setting and coexistence with the TPS25200 (U102) clamp"))
ovc_u102 = (TPS25200["VOVC_MIN"], TPS25200["VOVC_MAX"])
o4, c4 = TPS2596["VOVC_400K"], TPS2596["VCLAMP_400K"]
oo = TPS2596["VOVC_OPEN"]
P(f"  U102 clamps 5V_SYS at {ovc_u102[0]:.2f}..{ovc_u102[1]:.2f} V for any VBUS below V(OVLO) 6.8 V and disconnects above [DS]; in-spec"
  f" VBUS <= 5.50 V is passed (5V_SYS <= 5.50 V).")
P(f"  Option 'open' (13.8 V): U503 clamp threshold {oo[0]:.2f}..{oo[2]:.2f} V [DS] -> never engaged behind U102 (margin "
  f"{oo[0]-ovc_u102[1]:.2f} V); ROC footnote 'VIN limited to the selected clamp option' met with the same margin.")
P(f"  Option 400 k (5.7 V): threshold {o4[0]:.2f}..{o4[2]:.2f} V, clamped output {c4[0]:.2f}..{c4[2]:.2f} V [DS]: margin to the in-spec"
  f" 5.50 V only {(o4[0]-5.50)*1e3:.0f} mV and a {(ovc_u102[1]-o4[0])*1e3:.0f} mV overlap with the U102 clamp band -> with an out-of-spec"
  " 5.5-6.8 V source two linear clamps could regulate in cascade (U503 toggling between pass and clamp at its threshold); it would"
  " guard only the analog branch (LM27762 5.8 V abs) against a U102 short, i.e. a double fault, while every other 5V_SYS load stays"
  " exposed.")
P("  DECISION: OVCSEL open (pin 8 soldered to an isolated pad, no copper connection) -> the TPS25200 is the single OV element (D1);"
  " no interaction by construction; no part. (The 400 k option needs no layout change if ever wanted: add a 0402 on pin 8 - not"
  " provided as a DNF because no measurement could call for it.)")

P(hdr("2. dVdt capacitor C514 (pin 2): 5V_ANA inrush and ramp time"))
C_DVDT, C_TOL = 10e-9, 0.10          # 10 nF 50 V X7R 0402 (C15195) +-10 %
C_INT = TPS2596["C_DVDT_INT_EST"]    # [CALC] ~1.03 nF internal, from SR(open) = 42.7 V/ms typ
SR_MAX = TPS2596["IDVDT_MAX"] * TPS2596["GDVDT_MAX"] / (C_DVDT * (1 - C_TOL))                 # internal C ignored (upper bound)
SR_MIN = TPS2596["IDVDT_MIN"] * TPS2596["GDVDT_MIN"] / (C_DVDT * (1 + C_TOL) + 1.5 * C_INT)     # internal C x 1.5 (lower bound)
SR_TYP = 2.11e-6 * 20.93 / (C_DVDT + C_INT)
C_OUT_MAX = 1.1e-6 + 11e-6            # C506 + C507 (+10 %, no DC-bias credit)
C_OUT_DNF = C_OUT_MAX + 11e-6         # with the DNF damping C513 fitted
P(f"  SR = IdVdt x GdVdt / C (dVdt pin current 1.89..2.33 uA, gain 20.31..21.5 [DS]): {SR_MIN/1e3:.2f} .. {SR_TYP/1e3:.2f} typ .. "
  f"{SR_MAX/1e3:.2f} V/ms [CALC] (TI Eq.4: 42000/10000 pF = 4.2 V/ms)")
P(f"  Inrush into C506 + C507 <= {C_OUT_MAX*1e6:.1f} uF: <= {C_OUT_MAX*SR_MAX*1e3:.0f} mA ({C_OUT_DNF*SR_MAX*1e3:.0f} mA with C513 fitted)"
  f" < Default IOS min {DMIN*1e3:.0f} mA -> the ramp never enters current limit; LM27762 is disabled during the ramp (RAIL_EN low).")
td_on = 78.9e-6 + (247.3e-6 - 78.9e-6) / 3.3e-9 * C_DVDT          # [ASSUMP] typ delay scaled linearly with C (DS 7.7 points)
t_ramp_max = 5.55 / SR_MIN
P(f"  Turn-on delay ~{td_on*1e6:.0f} us typ [ASSUMP, linear in C from DS 7.7]; ramp to 5.55 V <= {t_ramp_max*1e3:.2f} ms -> 5V_ANA settled"
  f" <= {(2*td_on+t_ramp_max)*1e3:.1f} ms after ANA_EN (delay taken x2) vs RAIL_EN >= 5 ms after ANA_EN (margin"
  f" {(5e-3-2*td_on-t_ramp_max)*1e3:.1f} ms); pin 2 abs max 2.5 V: capacitor rated 50 V (>= 4 V ROC) [DS].")
P(f"  USB view: the step at ANA_EN is <= {C_OUT_MAX*SR_MAX*1e3:.0f} mA for ~{5.5/SR_MAX*1e3:.1f}-{t_ramp_max*1e3:.1f} ms on top of"
  f" ~{(R['S']['S2']-R['I_ANA_Q'])*1e3:.0f} mA -> <= 500 mA.")

P(hdr("3. EN/UVLO, FLT, UVP (pin-level facts used in the netlist)"))
P(f"  EN/UVLO (pin 3) = ANA_EN directly, R513 100 k pull-down: on above {TPS2596['VUVLO_R_MIN']:.2f}-{TPS2596['VUVLO_R_MAX']:.2f} V, off below "
  f"{TPS2596['VUVLO_F_MIN']:.2f}-{TPS2596['VUVLO_F_MAX']:.2f} V, lowest ISD and fault reset below VSD {TPS2596['VSD_MIN']:.2f}-"
  f"{TPS2596['VSD_MAX']:.2f} V [DS]; ANA_EN 0/3.3 V logic (MCU VOL <= 0.05 V at 33 uA) -> clean; EN abs 7 V, ROC 6 V [DS].")
P("  No resistor-programmed input UVLO is used: the IN UVP (2.46..2.58 V rising, 2.36..2.46 V falling [DS]) plus the LM27762 UVLO"
  " are enough; brown-out handling is firmware (VBUS_SENSE).")
P("  FLT (pin 6) -> ANA_FAULT_N, R512 100 k to 3V3M (FLT abs 7 V; leakage <= 1 uA -> VOH >= 3.15 V) [DS].")
P("  FLT is asserted ONLY for thermal shutdown and an ILM short to GND; current limiting, short-circuit limiting, UVP and the OV clamp"
  " do NOT assert it [DS Table 3]:")
for ev, resp, flt in TPS2596_FAULT_TABLE:
    P(f"     {ev:34s} {resp:44s} {flt}")
P("  -> Interface change vs the TPS2553 (which flagged over-current after 5-10 ms): overload is seen through RAILS_OK_N (rails < 95 %)"
  " and, in High mode, through FLT at thermal shutdown; a dead short ON 5V_ANA/5V_ANA_F collapses the PGOOD pull-up, so RAILS_OK_N"
  " reads 'good' while DC_PERMIT_N reads 'not permitted' (rails down -> H = 0) -> firmware supply-fault rule (section 5).")

P(hdr("4. Current-limit behaviour into music peaks (regulates, no trip)"))
for mode, ilim_min, ilim_max in (("Default", DMIN, DMAX), ("High", HMIN, HMAX)):
    for v5 in (4.30, 5.50):
        vds = v5 - 3.9                                   # worst sustained regulation point: 5V_ANA sagged to ~3.9 V (rails at dropout)
        p = vds * ilim_max
        P(f"  {mode:7s} 5V_SYS {v5:.2f} V: while limiting at <= {ilim_max*1e3:.0f} mA with 5V_ANA sagged to 3.9 V the FET dissipates"
          f" <= {p:.2f} W -> TJ <= {60 + p*TPS2596['THETA_JA']:.0f} C (TSD 157 C typ) -> regulates, no FLT, no trip")
P(f"  Response: > ILIM -> regulated within tLIM 87 us typ; > 1.5 x ILIM -> fast clamp within tSC 5 us typ [DS 7.6]. Energy the local"
  f" caps can bridge before 5V_ANA_F sags 1 V: (C506+C507 >= 5 uF) x 1 V = 5 uC -> a 60 mA excess for ~80 us; longer peaks sag"
  " 5V_ANA_F, the LM27762 negative headroom collapses first and the legs clip softly; PGOOD then reports 'not good' ->"
  " firmware overload policy (protection 10.2). The analog stream sizes the Default targets so that the clean envelope stays"
  f" below the IOS min ({DMIN*1e3:.0f} mA vs need {R['NEED']*1e3:.1f} mA).")

P(hdr("5. Short on 5V_ANA / 5V_ANA_F / LM27762 input (fast clamp, foldback, thermal auto-retry)"))
for mode, ilim_max in (("Default", DMAX), ("High", HMAX)):
    p = 5.55 * ilim_max                                  # bound: no foldback credit (Fig 22/23 foldback is typical only)
    tj = 60 + p * TPS2596["THETA_JA"]
    P(f"  {mode:7s}: VIN 5.55 V x IOS max {ilim_max*1e3:.0f} mA = {p:.2f} W (no foldback credit) -> steady TJ {tj:.0f} C at 60 C local,"
      f" theta_JA 52.7 C/W (pad soldered, JEDEC) [CALC]")
P("  Default: TJ ~125 C is below TSD (157 C typ, no min) -> the part can sit in current limit with FLT de-asserted; TJ stays at the"
  " 125 C ROC limit, i.e. no damage, but the firmware must remove ANA_EN. High: TJ would exceed TSD -> thermal shutdown, FLT low,"
  " cool 11.5 C + 95 ms typ, auto-retry (TPS259621) [DS 8.3.5].")
P("  Foldback [DS-typ Fig 22/23]: at VOUT = 0 the limit falls to ~85-135 mA (R_ILM 7.87 k) and ~0.72-0.88 A (453 ohm) -> at our"
  " ~0.2-0.44 A limits the short current is ~0.8-1.0 x ILIM (typical, not used as credit).")
P("  Firmware supply-fault rule (request to digital/protection): with ANA_EN high and >= 20 ms after RAIL_EN, if RAILS_OK_N is high"
  " OR ANA_FAULT_N is low OR DC_PERMIT_N stays high for > 200 ms after the DAC soft start while the leg readings are ~0 (rails dead),"
  " drive RELAY_EN, RAIL_EN, ANA_EN low; retry per the overload policy. Worst case until then: 1.26 W in U503, TJ <= 127 C.")

P(hdr("6. LM27762 start into the U503 limit (RAIL_EN high >= 5 ms after ANA_EN; LM27762 start-up current NOT in SNVSAF7C)"))
# vectorised time-domain model; corners along the batch axis
I_LIMS = (0.25, 0.50, 1.00)          # [ASSUMP] LM27762 positive-LDO and charge-pump start current (500 mA typ 'input current limit')
ILIMS = (("Default min", DMIN), ("Default max", DMAX), ("High min", HMIN))
C_AN = (5.0e-6, 12.1e-6); C_RL = (15.6e-6, 33.8e-6); C_CP = (4.2e-6, 11e-6); V5S = (4.30, 5.50)
grid = [(il, nm, ils, ca, cr, cc, v5) for il in I_LIMS for nm, ils in ILIMS for ca in C_AN for cr in C_RL for cc in C_CP for v5 in V5S]
n = len(grid)
IL = np.array([g[0] for g in grid]); ILS = np.array([g[2] for g in grid]); CA = np.array([g[3] for g in grid])
CR = np.array([g[4] for g in grid]); CC = np.array([g[5] for g in grid]); V5 = np.array([g[6] for g in grid])
VPS, VNS = 3.852, 3.721
IQP, IQN = R["IP"], R["IN"]
dt, T = 0.2e-6, 25e-3
van = V5.copy(); vp = np.zeros(n); vn = np.zeros(n); vcp = np.zeros(n)
on = np.ones(n, bool); trips = np.zeros(n, int); t_good = np.full(n, np.nan); van_min = van.copy()
e2596 = np.zeros(n); ipeak = np.zeros(n)
steps = int(T / dt)
for k in range(steps):
    i2596 = np.clip((V5 - van) / TPS2596["RON_MAX"], 0.0, ILS)
    f = np.clip((vp + vn - 1.0) / 3.5, 0.0, 1.0)      # op-amp quiescent vs total supply (vn stored as magnitude)
    iqp, iqn = IQP * f, IQN * f
    ip = np.where(on, np.minimum(IL, np.maximum(0.0, 20.0 * (VPS - vp))), 0.0)
    ip = np.minimum(ip, np.maximum(0.0, (van - vp) / 0.45))
    icp = np.where(on, np.minimum(IL, np.maximum(0.0, (van - vcp) / 2.5)), 0.0)
    ineg = np.where(on, np.minimum(IL, np.maximum(0.0, 20.0 * (VNS - vn))), 0.0)
    ineg = np.minimum(ineg, np.maximum(0.0, (vcp - vn) / 0.30))
    iin = ip + icp + np.where(on, 1e-3, 0.0)
    pd50 = np.where(on, 0.0, 1.0 / 50e3)
    van += (i2596 - iin) / CA * dt
    vp += (ip - iqp - vp * pd50) / CR * dt
    vn += (ineg - iqn - vn * pd50) / CR * dt
    vcp += (icp - ineg) / CC * dt
    vp = np.maximum(vp, 0.0); vn = np.maximum(vn, 0.0); vcp = np.maximum(vcp, 0.0); van = np.maximum(van, 0.0)
    off_now = on & (van < 2.4); on_now = (~on) & (van > 2.6)
    trips += off_now; on = (on & ~off_now) | on_now
    good = (vp >= 0.95 * VPS) & (vn >= 0.95 * VNS) & np.isnan(t_good)
    t_good[good] = (k + 1) * dt
    van_min = np.minimum(van_min, van)
    e2596 += (V5 - van) * i2596 * dt
    ipeak = np.maximum(ipeak, i2596)
P(f"  Model: U503 = ideal switch (131 mOhm) with a hard limit at ILIM (no overshoot credit); LM27762 positive LDO and charge pump"
  f" start at an unknown current limit I_st (swept {I_LIMS} A), negative LDO likewise; UVLO 2.4 V off / 2.6 V on [DS-typ];"
  f" op-amp/comparator quiescent {IQP*1e3:.1f}/{IQN*1e3:.1f} mA scaled with the total supply; C_5V_ANA {C_AN[0]*1e6:.1f}-{C_AN[1]*1e6:.1f} uF,"
  f" rails {C_RL[0]*1e6:.1f}-{C_RL[1]*1e6:.1f} uF each, CP {C_CP[0]*1e6:.1f}-{C_CP[1]*1e6:.1f} uF; 5V_SYS 4.30/5.50 V; {n} corners, 25 ms.")
P(f"  {'I_st A':>6s} {'U503 limit':>12s} | {'rails good ms (max)':>19s} {'UVLO trips (max)':>16s} {'5V_ANA_F min V':>15s} {'U503 energy mJ':>15s}")
for il in I_LIMS:
    for nm, ils in ILIMS:
        m = (IL == il) & (ILS == ils)
        tg = t_good[m]
        tgs = "never" if np.any(np.isnan(tg)) else f"{np.nanmax(tg)*1e3:6.2f}"
        P(f"  {il:6.2f} {nm:>12s} | {tgs:>19s} {int(trips[m].max()):16d} {van_min[m].min():15.2f} {e2596[m].max()*1e3:15.2f}")
TG_MAX = np.nanmax(t_good)
P(f"  -> every corner reaches 'rails good' (both >= 95 %) within {TG_MAX*1e3:.1f} ms of RAIL_EN; the start current exceeds the Default"
  " limit, so 5V_ANA_F dips and the LM27762 may pass through UVLO cycles (count above) until the rail capacitors are charged -"
  " a current-limited 'self soft start'. U503 energy <= a few mJ (no thermal effect); no FLT (current limit is not a fault).")
P("  Consequences: (a) keep the firmware rule 'RAILS_OK_N valid only >= 20 ms after RAIL_EN' (margin vs the modelled start time);"
  " (b) the protection comparators see a slow, possibly stepped rail ramp - harmless, the switch is open; (c) the LM27762 start-up"
  " current is not specified -> bring-up measurement M9 (scope 5V_ANA_F, VPOS, VNEG, PGOOD at RAIL_EN in Default at VBUS 4.40 V).")

P(hdr("7. Stability with C506 / FB501 / C507"))
P("  Normal operation (switch on, 89-131 mOhm): passive network, c05: worst |Z_in| 1.59 ohm at ~40 kHz (Q ~3.3, set by the USB cable"
  " and the board capacitance), no damping needed; R531/C513 DNF fallback kept.")
P("  dVdt ramp: the TPS2596 regulates the OUT slope at IdVdt x GdVdt / C (a slow loop, ms ramp); TI characterises it with COUT 1 uF /"
  " ROUT 100 ohm and uses 100 uF in the typical application [DS 7.7, 9.2]; C506 1 uF at the pin + C507 10 uF behind FB501 is inside"
  " that range; FB501 x C507 resonates at >= 48 kHz (1 uH / 11 uF), far above a ms-scale ramp loop.")
P("  Current limit: the device becomes a current source (no voltage feedback) - any capacitive load is stable; 5V_ANA_F settles where"
  " the LM27762 (in dropout) draws ILIM. OV-clamp voltage loop: never active (OVCSEL open).")

P(hdr("8. Thermal (TA 50 C + 10 C local, theta_JA 52.7 C/W with the pad soldered [DS])"))
for nm, i in (("Default at IOS max", DMAX), ("High at IOS max", HMAX)):
    p = i * i * TPS2596["RON_MAX"] + 5.5 * TPS2596["IQ_ON_MAX"]
    P(f"  {nm:20s}: {i*1e3:5.0f} mA through 131 mOhm -> {p*1e3:5.1f} mW, TJ {60 + p*TPS2596['THETA_JA']:5.1f} C (limit 125 C)")
P("  Pad: 9 vias to the GND planes under the DDA exposed pad (layout rule); without the pad soldered theta_JA = 119.8 C/W [DS].")

P(hdr("9. U505 TMUX1101DBVR (SOT-23-5): supply, SEL, signal range, leakage"))
P("  Pins [DS SCDS410D]: 1 D -> N5_ILIM_HI (R510), 2 S -> GND, 3 GND, 4 SEL -> ILIM_HI (MCU PA15, R511 100 k pull-down), 5 VDD -> 3V3M"
  " with C515 100 nF (0.1-10 uF required [DS]).")
P(f"  SEL: VIH >= {TMUX1101['VIH_3V3']} V / VIL <= {TMUX1101['VIL_3V3']} V at VDD 3.3 V [DS] vs MCU 2.85 V / 0.05 V; PA15 is plain GPIO at"
  " reset (no JTAG on CH32V307, digital D6) -> R511 holds Default through reset and boot; logic high = switch closed (TMUX1101).")
P(f"  Signal: ILM pin <= ~0.7 V (<= VDD = 3.3 V ROC); switched current = ILM current x R509/(R509+R510) <= "
  f"{TPS2596['GIMON_013_MAX']*HMAX*R['R509']/(R['R509']+R['R510'])*1e3:.2f} mA (<= 120 mA IDC at 85 C [DS]); Ron <= 9.5 ohm (-40..85 C)"
  f" in series with R510 (included in c03); IS/ID(OFF) <= 0.2 nA -> {TMUX1101['IOFF_3V3_85']/(TPS2596['GIMON_013_MIN']*DMIN)*1e6:.1f} ppm"
  " of the Default limit; IDD <= 0.65 uA (-40..125 C) in the suspend budget.")
P("  VDD from 3V3M (always on) so the switch state is defined whenever U503 can be on; at an unplug VDD collapses together with IN.")
P(hdr("R8 round 3 note")); P("  Section 6 (LM27762 started by RAIL_EN after the ramp) is SUPERSEDED: X-1 ties EN+/EN- to VIN; the start during the dVdt ramp, the C514 sweep and the UVLO-cycling result are in c16_r3_review_fixes.out.txt section A. C514 = 10 nF (DY-2; the DX-4 470 nF option reverted): with the X-8 reservoirs rails good <= 18.8 ms incl. 5V_ANA_F >= 4.12 V (c18_x8_rail_start.out.txt); firmware T_START = 40 ms. Section 2 text 'LM27762 is disabled during the ramp (RAIL_EN low)' no longer applies.")
open(__file__.replace(".py", ".out.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
