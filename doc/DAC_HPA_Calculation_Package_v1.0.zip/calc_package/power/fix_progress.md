# Power stream — R8 review fixes (round 3) progress log

Started 2026-09-25 08:30 UTC. Scope: X-1…X-5, X-10 (power items), budget c03, report/BOM/netlist, checker.

| Step | Status | Notes |
|---|---|---|
| 0 read decisions/review | in progress | |
| 0 read decisions/review | done ~08:40 | X-1..X-10 read; review #2,#3,#16,#19,#22,#28,#30, pins-a read; scripts c01/c02/c11/gen read |
| 1 X-3 D102 part search | in progress | no-tIOS-credit bound: cable current can reach V/(Rc+Ron) -> needs low-Rdyn TVS |
| 1 X-3 D102 part | chosen ~08:44 | Littelfuse SMDJ12A (VRWM 12 V, VBR 13.3-14.7 V, VC 19.9 V @ 150.8 A, IR 2 uA @ 12 V/25 C, dVBR 0.1 %/K; DigiKey 5,498). SMAJ/SMF class cannot hold 18 V without tIOS credit (cable current -> V/(Rc+Ron)). Leakage at 5.5 V/50 C not in DS -> estimate |
| 2 X-2 C104 | decided ~08:44 | TPS25200 EN: rise <= 1.9 V, fall >= 0.6 V, IEN +-2 uA -> earliest crossing 0.6 V with +2 uA out of pin; C104 100 nF X7R (C1525) -> t_EN >= 2.2 ms |
| 3 scripts | in progress | writing calc/c16_r3_review_fixes.py (X-1,X-2,X-3,X-5,X-10,budget); c14 edit for EN=VIN + Schottky |
| 3a c16 sections B,D,E | done ~08:47 | C104 100 nF X7R -> U102 on >= 2.24 ms (latest 33.9 ms); region A 28.5 uC ends <= 273 us; region B 40.2 uC (19.5 %) / 37.0 uC with guaranteed IOS credit (26 %); ANA_SENSE R535 68.1k/R536 30.1k (1.725 V max, 20.9 k); AUD_EN high >= 2.18 V (2.245 nom), low <= 112 mV floating |
| 3b c16 A (X-1), C (X-3) | running | |
| 3b c16 A/C + c17 budget | done ~08:50 | see calc/c16_r3_review_fixes.out.txt, c17_budget_r3.out.txt; R509 stays 4.75 k (Default total 489.63 mA, +0.37); S6 3.534 mA with PH (FAIL w/ placeholders, L-1) |
| 4 c14 (EN=VIN, U303 EN=3V3D, Schottky, C103 100 pF) | running | backup c14_unplug_order_r2.py.bak |
| note | | clock check 08:51 UTC (earlier row times corrected to approximate real times) |
| 4 c14 round 3 run 1 (BAT54-class) | done 08:51 | VOUT-VIN max: U502 +404 mV @7.9 mA, U302 +458 mV @52 mA (no fw), U503 +452 mV @42 mA, U504 -3 mV, U303 +5 mV -> BAT54 too weak; need VF<=0.3 V at ~55 mA; fw brown-out @ 100 pF acts 96/96; DVDD-DVCC <= +5 mV with U303 EN=3V3D |
| 5 gen_bom_netlist patched | done 08:53 | R506/R507/RAIL_EN deleted, C104, D102, R535/R536/C516, C103 100 pF, R508 10k, U303 EN=3V3D, U501 EN=5V_ANA_F; Schottky part in gen_sch_part.py (pending) |
| 6 c17 budget (digital values: U208 1.67 mA, R240 33 uA, R233 retired, wake 189 uA) | done 08:58 | NONANA 266.88 mA; R509 4.75 k / R510 3.83 k kept; Default total 489.96 mA (+0.04 to the 490 rule); S1 83.39, S2 338.19, S3f 353.53, S4 751.0, S5 346.30; S6 3.673/3.579 mA with PH (2.683/2.589 with nanopower U605) -> FAIL on placeholders (L-1) |
| 7 BOM/netlist regenerated | done 08:58 | 63 lines, 76 parts (73 fitted, 3 DNF), 221 netlist rows; D103-D105 BAT54 (U502/U302/U503), D102 SMDJ12A, C104, R535/R536/C516 |
| 8 notes in c01/c02/c11 (superseded sections -> c16) + rerun | started 08:59 | PMEG2005AEL-class c14 variant: VOUT-VIN <= +200 mV but IR 600 uA max @10 V -> rejected; BAT54 chosen (VOUT-VIN <= +458 mV residual) |
| 9 report.md R3 section | done ~09:03 | inserted above R2 |
| 10 R2 statements marked superseded; temp logs removed | done ~09:04 | |
| 11 pw_common R3 data block; final checker run | done ~09:05 | 332 parts / 184 nets / 992 pins; issues only iface_absent RAIL_EN (deleted by X-1) and cross_stream_non_iface ANA_SENSE (new X-5 net) -> integration IFACE list |
| DONE | 09:05 | all files saved: report.md (R3 section), bom_rows.csv, netlist.csv, calc/c16*, c17*, c14 (+_pmeg), gen_sch_part.py, gen_bom_netlist.py, pw_common.py; backups *_r2*.bak |

## Follow-up 1 (09:02): analog r3 message - X-8 adopted
| Step | Status | Notes |
|---|---|---|
| F1 read analog request | done 09:03 | D411/D412 PMEG2010AEH + C442/C443 220 uF polymer (176-264 uF) on N4_VPOS_IV/N4_VNEG_IV, OPA2210 17.4/14.8 mA; asks C514 for a rail ramp >= 40 ms and reservoirs in c11/c14; C440 2.2 uF on VCCA -> LP5907 COUT check; C441 DNF needs OK |
| F2 c16 section A2 (start with reservoirs, C514 10 nF vs 470 nF) | in progress | |
| F3 c19 C440/C441 (3V3A) | done 09:10 | effective <= 8.04 uF (DC-bias 0.8 ASSUMP) / analog 8.54 uF <= 10 uF LP5907 limit -> C440 OK; C441 fitted 9.03 uF OK; no-credit count 10.01/11.11 uF; 3V3A < 0.1 V <= 0.472 ms (C440), 0.512 ms (+C441) vs digital wait 0.53 ms |
| F4 c14 with X-8 reservoirs (T 8 ms) | running (started 09:07) | c14 backup c14_unplug_order_r3a.py.bak |
| F2 c18 runs 10 nF / 470 nF | running (started 09:06) | |
| F5 report R3.11 (interim: C440/C441, pending c18/c14) | saved 09:17 | |
| F2 c18 | restarted 09:20 | first runs lost (report bug TD.max on a float); now reduced set (24 corners, dt 0.5 us), 10 nF then 470 nF sequentially |
| F2a c18 10 nF (reduced) | done 09:22 | PGOOD <= 17.9 ms, I/V 95 % <= 17.6 ms, <= 919 UVLO trips until <= 10.0 ms, U503 in ILIM <= 16.8 ms, 5V_ANA_F >= 2.23 V, <= 4.5 mJ |
| F4 c14 X-8 | done 09:28 | I/V rails >= 4.5 V for >= 8 ms (whole run) in all 288 corners; 3V3A < 0.3 V at <= 0.854 ms -> analog requirement met by >= 7.1 ms (was +0.50 ms violation); X-4 BAT54: U502 +410, U302 +456 (no fw), U503 +452 mV; DVDD-DVCC <= +5 mV; brown-out action 0.043-0.090 ms, 96/96 |
| F6 report R3.11 final (C514 stays 10 nF with evidence; window >= 40 ms request; c14 X-8; C440 OK; C441 conditional) | saved 09:32 | |
| F7 checker after analog X-8 | done 09:33 | 371 parts / 203 nets / 1095 pins; only RAIL_EN (iface_absent) and ANA_SENSE (cross-stream) as before; no new issue on power nets. Follow-up complete. |

## Follow-up 2 (09:31): digital r3 message
| Step | Status | Notes |
|---|---|---|
| G1 c18 timing run (10 nF, I_st 0.10-1.0 A, T_START metric: RAILS_OK_N low AND 5V_ANA_F >= 4.00 / 4.12 V) | running 09:35 | |
| G2 c17 S6 both wake figures | done 09:37 | binding 0.189 mA: 3.673/3.579 mA (PH), 2.683/2.589 (nanopower U605); digital alt 0.0034 mA: 3.488/3.393 (PH), 2.498/2.403 mA (nanopower U605) -> A-to-C +2 uA, C-to-C +97 uA |
| G1 c18 timing | done 09:35 | T_START metric <= 18.6 ms (4.00 V) / 18.8 ms (4.12 V ADC worst) -> 1.25x = 23.5 ms; recommend >= 40 ms; 60 ms PH safe |
| G3 report R3.12 | saved 09:36 | T_START, S6 both wake figures, AUD_EN agreed. Follow-up 2 complete. |

## Follow-up 3 (09:35): orchestrator DX-2..DX-4 (binding)
| Step | Status | Notes |
|---|---|---|
| H1 read DX-1..DX-4 | done 09:37 | DX-2 suspend wake 3.4 uA binding; DX-3/DX-4: C514 for a rail ramp >= 40 ms (binding) -> C514 470 nF; protection R3.7 final loads found (3V3M 74.2/7.6 uA, 3V3D 3.36 mA, 3V3A 5.7 uA, block 6 +0.40/+0.38 mA); analog C442/C443 now KEMET T495D227K010ATE100 MnO2 198-242 uF, DCL <= 22 uA |
| H2 c18 470 nF timing run | running 09:37 | |
| H3 c17 with protection finals + DX-2 | in progress | expect R509 re-selection (E96 cannot meet both; E192 4.81 k) |
| H3 c17 with protection finals + DX-2 | done 09:40 | NONANA 269.32 mA, need 176.62 mA; E96 fails both -> R509 4.81 k (E192): IOS 177.9/198.9/220.0, total 489.78 (+0.22), need +1.3 mA; R510 3.74 k: High 393.3/440.4/487.1; S6 2.4954/2.4010 mA (+4.6/+99 uA) |
| H4 BOM: C514 470 nF, R509 4.81 k (E192), R510 3.74 k | done 09:41 | gen_bom_netlist re-run OK (backup gen_bom_netlist_r3a.py.bak) |
| H2 c18 470 nF timing | done 09:41 | PGOOD <= 101.2 ms; T_START metric <= 105.0 ms (4.00 V) / 106.7 ms (4.12 V), ramp-dominated (delay bound 48 ms ASSUMP) -> 1.25x = 133 ms: the 60 ms placeholder is too short |
| H5 report R3.13 | saved 09:43 | C514 470 nF (DX-4) + evidence; T_START 133 ms; budget finals (R509 4.81 k, R510 3.74 k); S6 +4.6/+99 uA; C440/C441 answers; earlier rows marked superseded |
| H6 c11 note (470 nF), checker | done 09:44 | only RAIL_EN / ANA_SENSE as before. Follow-up 3 complete. |

## Follow-up 4 (09:42): digital currents round 3
| Step | Status | Notes |
|---|---|---|
| J1 c17: U208 2.52 mA, R238/R239 0.167 mA, wake 4.5 uA | in progress | |
| J1 c17 | done 09:45 | NONANA 270.34 mA; R509 4.84 k (E192): IOS 176.9/197.8/218.7, total 489.51 (+0.49), need +0.27 mA; R510 3.74 k: High 392.3/439.2/485.8; S6 2.4965/2.4021 mA (+3.5/+97.9 uA) |
| J2 BOM R509 4.84 k | done 09:45 | |
| J3 report R3.14 + checker | done 09:46 | only RAIL_EN / ANA_SENSE. Follow-up 4 complete. |

## Follow-up 5 (09:43): protection round-3 message
| K1 check loads vs c17 | done 09:47 | identical to the R3.7 values already used -> no budget change; R3.15 note (transient X-6 currents, facts for the analog I2C-fallback conflict) saved |

## Follow-up 6 (09:44): protection - R501 fallback coupling
| L1 BOM R501 note + report R3.16 | done 09:48 | fallback 232 k only with protection R672 243 k; VPOS 3.919/3.984/4.049 V; LDO headroom 0.17/0.16 V at VBUS 4.40 V High (dropout typ only); checker unchanged (RAIL_EN, ANA_SENSE) |

## Follow-up 7 (09:45): analog budget update (need 176.9 mA + ANA_SENSE, quiescent 71.56 / 86.29 mA), O15
| M1 c17 with analog final need/quiescent; R509 conflict | in progress | |
| M1 c17 + BOM | done 09:50 | need 176.957 mA; D-5 rule conflict: 4.81 k (need +0.97, total 490.80: 490 rule -0.80, 500 +9.20) chosen per analog; alt 4.84 k (489.51, need -0.07) -> orchestrator decision; S2 342.28, S3 490.80, S5 350.43, S4 758.11; S6 unchanged |
| M2 report R3.17 (conflict, O15 not confirmed + clamp option), checker | done 09:52 | checker: RAIL_EN, ANA_SENSE only |

## Follow-up 8 (09:49): orchestrator DY-1/DY-2/DY-4/DY-5
| N1 C514 revert to 10 nF (BOM/netlist), c11 note, c17 final re-run, report R3.F final values table | done 09:55 | S1 82.40, S2 342.28, S3 490.80, S3f 357.62, S4 758.11, S5 350.43 mA, S6 2.4965/2.4021 mA; checker: RAIL_EN, ANA_SENSE only |

# VE round (value engineering) — started 10:58 UTC (brief ve/brief_ve.md, binding)
| Step | Status | Notes |
|---|---|---|
| V0 read brief, list costly/global power lines | in progress | |
| V1 candidates found | 11:05 | D102 -> MDD SMDJ12A C2994091 (JLCPCB Extended, Economic+Standard, MSL1, VBR 14.7 V max, VC 19.9 V @150.8 A, IR 2 uA; same limits as Littelfuse -> c16 C unchanged) - stock to confirm; J101 -> HRO TYPE-C-31-M-12 C165948 (16P, 20 V, 5 A, LCSC 85,640, $0.10-0.19) - reflow + pad map to confirm |
| V2 evidence | 11:15 | R510 3.74 k = YAGEO RT0603BRD073K74L C861382 (LCSC 4,320, $0.035, 0.1 %/25 ppm); D102: MDD C2994091 out of stock, LGE SMDJ12A C5806873 915 pcs $0.25-0.31, Jingdao C438150 230 pcs; J101 HRO C165948 datasheet NOT retrievable (cookie-gated) -> reflow/pad map unverified; D103-D105 -> Nexperia BAT54,215 C85084 (same type as analog D413/D414) |
| V3 evidence | 11:19 | R509 4.81 k: YAGEO RT0603BRD074K81L C861445 LCSC/JLCPCB 0 stock; KOA RN73R1JTTD4811B25 DigiKey 3,950 -> owner-fit candidate; D102 LGE C5806873 915 pcs but IR/VBRmax not on page (datasheet gated) -> leakage unverified vs S6 margin 3.5 uA |
| V4 BOM/netlist VE changes | done 11:26 | R108 100k Basic, R109 470k (R532 type), R535/R536 100k/47k Basic, R510 C861382, D103-D105 C85084 (analog type), R509 + D102 owner-fitted (DigiKey); checker issues {} |
| V5 report VE section | done 11:29 | adopted 1-5, owner-fitted 6-7, rejected/pending 8-12; totals -5 Extended types = US$15.35/order (3.07/board) Economic |
| VE DONE | 11:30 | files saved: report.md (VE top section), bom_rows.csv, netlist.csv, calc/c20_ve_checks.py/.out.txt; backups *_preVE*.bak |

# R9 round — started 16:59 UTC (r9/reviews_r9.md, r9/decisions_r9.md binding)
| Step | Status | Notes |
|---|---|---|
| R0 read reviews/decisions | in progress | |
| R0 read reviews/decisions | done 17:02 | power items: E-1, E-5, E-6, E-7, E-8, E-9 rows, A4 wording, C2 rebuttal, brown-out margin line |
| R1 E-1 | done 17:06 | source values already correct (R108 100 k, R109 470 k, R535 100 k, R536 47 k, MPN codes decode); stale texts fixed: U102 'IOS 0.87-1.08 A with R108 100 k', C104 'R109 470 k: 3.31-55.3 ms' |
| R2 E-7 | done 17:08 | TPS2596 SLVSET8A: feature list 3.8/5.7/13.8 V pin-selectable clamp; EC 7.5 rows ROVCSEL = OPEN: VOVC 12.97/13.77/14.52 V, VCLAMP 13.13/13.58/13.97 V -> open is a documented setting; keep open (isolated pad) |
| R3 c21 E-5/E-8/brown-out/E-6 | done 17:27 | S6 corrected (BAT54 21.6 uA bound, U102 191.4 uA) = 2.5094 mA (-9.4 uA) on the planning values; no BOM change reaches 0.2 mA; fallback 'suspend power cut' ~2.238 mA (+262 uA) = circuit change; E-8 closed (<= 0.48 V vs >= 0.92 V); brown-out +52..+98 mV |
| R4 report 'R9 fixes' section | saved 17:34 | E-1, E-7, E-5 (fallback = owner decision), E-6 (G/E/Q + production test), E-8 closed, E-9 power rows, A4, C2, brown-out line |
| R4 report 'R9 fixes' section | saved 17:11 (retry after a transient EIO) | E-1, E-7, E-5 (fallback = owner decision), E-6 (G/E/Q + production test), E-8 closed, E-9 power rows, A4, C2, brown-out line |
| R5 checker | done 17:12 | 378 parts / 208 nets / 1,111 pins, issues {}, value-decode 109 lines OK. R9 power items complete; owner decisions: E-5 fallback, E-6 criterion |
| R6 digital E-9/E-5 message | done 17:16 | rows confirmed with corrections (3V3A <= 0.472 ms, 3V3D <= 0.63 ms, DVDD<=DVCC wording, brown-out add AUD_EN); switched divider = option (a) for the owner (-37 uA -> S6 +28 uA), not adopted; x1.5 divider rejected |

## E-16 (17:14): suspend power cut adopted (owner) — power leads
| Step | Status | Notes |
|---|---|---|
| S0 plan | done 17:15 | U502 -> TPS709 (30 V, from VBUS), Q507 NMOS on U102 EN (MCU GPIO, R537 1 M gate pull-down), C102 -> 2.2 uF (attach region A), D103 -> 3V3M->VBUS; re-run c02 regions, c16 C kick, c14 unplug, c17 S1-S6 |
| S1 TPS70933 DS check | done 17:18 | DBV pinout 1 IN/2 GND/3 EN/4 NC/5 OUT (drop-in), VIN abs 32 V, EN max 6.5 V (EN floating = enabled), COUT >= 2.2 uF, IGND 2.05 uA max, ICL 200-500 mA, RthJA 212 C/W; accuracy 1 % + line 10 mV + load 50 mV -> 3.207-3.343 V; VDO 650 mV max @50 mA, 1400 @150 mA -> 3V3M out of regulation below VBUS ~4.25 V -> ratiometric brown-out trip at 4.0 V NOT guaranteed; checking a low-dropout 18-V alternative (TPS7A25) |
| S2 design | 17:23 | U502 -> TI TPS70933DBVR (C89347, LCSC stock, Economic+Standard): IN = VBUS, EN (pin 3) floating = enabled (EN max 6.5 V!), OUT 3V3M, reverse-current protection + VOUT abs 7 V -> D103 deleted; C502 -> 2.2 uF (COUT >= 2.2 uF); Q507 AO3400A on N1_U102_EN (gate N1_U102_OFF, R537 1 M pull-down, default on); C102 4.7 -> 2.2 uF 25 V (attach A); U101 pin 5 5V_SYS -> 3V3M (else D+ back-feeds 5V_SYS through the USBLC6 upper diode in suspend) |
| S3 BOM/netlist E-16 + messages | done 17:24 | U502 TPS70933 (VBUS), C502 2.2 uF, C102 2.2 uF, Q507 + R537 (N1_U102_OFF), U101 pin 5 -> 3V3M, D103 deleted; c14 E-16 run started 17:21; messages to digital (net, resume 60 ms, ratiometric brown-out caveat) and protection (3V3M 3.207-3.343 V) |
| S4 c22 | done 17:27 | S6 2.2521 mA (+248 uA) A-to-C, 2.1581 mA C-to-C; attach A 29.6 uC (41 %), B 20.1 uC (60 %), gap >= 2 ms; kick 17.08 V with C102 2.2 uF; U502 TJ <= 99 C in spec, 9 V -> TSD cycling (survives); 3V3M 3.207-3.343 V |
| S5 report R9.E16 (pending c14 line) | saved 17:25 | |
| S6 c14 E-16 + report + checker | done 17:28 | c14: X-8 compliant (I/V >= 4.5 V 4 ms, 3V3A < 0.3 V <= 0.749 ms), digital/DVDD OK, brown-out 96/96 before MCU reset, X-4 residual unchanged; report R9.E16 complete; checker issues {} |
| S7 digital FYI (PB0 taken, PC14 spare) | done 17:30 | option (a) marked superseded by E-16; N1_U102_OFF -> PC14 suggested to digital |
| S8 digital U102-off question + rename | done 17:33 | net renamed N5_U102_OFF (digital PC14); U102 off at S7 + 0.1 ms is safe (D105 clamps <= 0.24 V), USB suspend level at 8.75 ms after last SOF |
| S9 protection R9 loads | done 17:36 | +1.90 mA at 5V_ANA -> need 178.84 mA; R509 4.81 k fails by 0.94 mA; 4.78 k meets (+0.15/+0.55) at total 492.13 mA; BOM kept 4.81 k (DY-1) pending decision; asked protection for <= +0.9 mA variant |
| S10 analog R9 need | done 17:38 | need 178.81 (G) confirmed; recommend 4.75 k (G +1.23, total 493.45) or 4.78 k (G +0.13, 492.13); BOM keeps 4.81 k pending orchestrator |
| S11 E-18 | done 17:41 | R509 4.75 k owner-fitted (KOA RN73R1JTTD4751B25); Default IOS 180.1/201.3/222.6, High 395.4/442.7/489.7 (R510 3.74 k kept); S1 82.40 S2 344.21 S3 493.45 S3f 359.55 S4 760.76 S5 352.36 S6 2.2521/2.1581 mA |
| S12 protection TLV3404 question | done 17:42 | answered: keep TLV1704 (E-18 R509 4.75 k gives G +1.21-1.29 mA); no variant |
| S13 net-name check | done 17:44 | both netlists on N5_U102_OFF, checker issues {}; TSIGATT <= 23.9 ms noted |
| S14 digital confirmation | 17:45 | N5_U102_OFF matched, checker clean; S9 = S7 + 0.1 ms, suspend current <= 8.75 ms after the last SOF (10 ms limit), Stop at 8.55 ms - consistent with power's U102-off answer |
| S15 protection confirmation | 17:46 | TLV1704 E-3 maxima I+ 0.85 / I- 1.02 mA (+1.90 mA at 5V_ANA) = the c17 input; R509 4.75 k already applied (E-18); no change |
| S16 analog confirmation | 17:48 | G +1.25 mA at IOS min 180.1 mA, 32 ohm Default ~38.9 mW, High +75.3 mA - recorded in report R9.E16 E-18 row. R9 power items complete. |
| E21-1 Q507 -> MMBT3904 | done 17:52 | AO3400A IDSS (5 uA at 30 V/55 C bound) would drop EN to <= 1.08-1.88 V at VBUS 4.40 V; NPN MMBT3904 C20526 (Basic) + R537 100 k series + R538 100 k B-E |
| E21-2 report | done 17:55 | Q507 NPN row, S6 2.2755/2.1815 mA (+224 uA), E-21 volume-ceiling procedure (set + verify), E-6/E-18 fallback text updated; checker issues {} |

## R9 reconciliation (19:58, orchestrator): Default current-limit margin — one figure
| Step | Status | Notes |
|---|---|---|
| c17 re-run with the R9-check block 6 (I+ 2.66 / I- 2.48 mA -> +1.874 mA at 5V_ANA vs R3.7) | done 20:00 | c17 need 178.81 mA (increment basis); analog basis 178.81 - 0.026 + 0.038 (ANA_SENSE) = 178.82 mA [G] = FINAL; IOS min (R509 4.75 k) 180.05 mA -> G margin +1.23 mA (the +1.25/+1.28 quotes used the rounded 180.1 mA); stale 0.057 mA ANA_SENSE term in c17 corrected to 0.038 |
| BOM R509 description | done 20:00 | text only: "IOS 180.05/201.3/222.6 mA; Default need 178.82 mA [G] -> margin +1.23 mA"; price unchanged; checker issues {} |
| S3 / USB total | unchanged | 493.45 mA (analog branch enters S3 at IOS max); S2 344.17, S3f 359.50, S5 352.31 mA (-0.02..-0.04); with the NDK X201: S3 497.95 mA (earlier 497.92 was a rounding slip) |
| 20:07 | orchestrator final consistency pass (integration, text only) | Q507 description: 'EN >= 3.19 V at VBUS 4.40 V / 60 C' -> 'EN >= 3.18 V at VBUS 4.40 V, 50 °C (hot leakage estimated)'; no other field changed | bom_rows.csv | done (integration) |

## R9-RECHECK-02 (20:19, orchestrator): stale "NDK -> R509 4.87 k" text in report.md (text edits only)
| Step | Status | Notes |
|---|---|---|
| mark superseded | done 20:20 | 6 places marked "superseded (R9 E-27): the NDK needs no R509 change; R509 stays 4.75 k; S3 497.95 mA with the NDK": C13 row (R2.0), R2.2 sensitivity sentence (NDK -> 4.87 k and "+2.88 mA moves R509 to 4.87 k"), R2.2 integration-lookup header, R2.11 "Changed" line, R2.13 D-g; backup calc/report_preR9recheck02.md.bak |
| grep for other current-looking 4.87 k | done 20:20 | remaining mentions are informational only: R9 margin table (4.87 k -2.97 mA), R3.6 "4.87 k (175.9 mA) would miss the need", lookup-table row under the superseded header |
