import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""R9 E-13: placement feasibility - courtyard area per placement zone (layout_package.md section 6) vs zone area.
Courtyards: IPC-7351B nominal (level B) approximations per package [ASSUMP, listed in COURT]; owner-fitted parts get
+1.5 mm iron clearance on every side (O-4). DNF footprints are counted (their pads exist). Utilisation limits [ASSUMP]:
<= 55 % comfortable, 55-70 % tight (fine-pitch 4-layer routing still possible), > 70 % not routable at this density.
Writes placement_density_out.txt."""
import csv, os, re, collections
BASE = _PKG_ROOT + ''
COURT = [  # (regex on package text, courtyard L x W mm)
    (r'LQFP-?64', (13.0, 13.0)), (r'QFN-?3[26]|QFN-32', (4.8, 4.8)), (r'QFN-?28', (4.8, 4.8)), (r'VSON-?10|DRC', (3.7, 3.7)),
    (r'WSON-?12|DSS', (3.7, 2.7)), (r'WSON-?6|DRV', (2.7, 2.7)), (r'HSOIC|DDA', (6.6, 5.6)), (r'TSSOP-?14|PW\b', (7.2, 5.8)),
    (r'SOIC-?8|\bD\)', (6.6, 5.6)), (r'VSSOP|SOT765|DCU', (3.4, 3.0)), (r'SOT-?36[13]|TSSOP-?[56]|SC-70|SOT-?353', (2.8, 2.6)),
    (r'SOT-?23-?[56]|DBV', (3.8, 3.4)), (r'SOT-?5X3|DRL', (2.3, 1.9)), (r'SOT-?23|SOT23|TO-236', (3.6, 3.0)),
    (r'2\.5 ?x ?2\.0|2520', (3.1, 2.6)), (r'3225|3\.2 ?x ?2\.5', (3.9, 3.2)), (r'SOD-?123F|SOD123F', (4.3, 2.1)), (r'SOD-?523', (2.1, 1.2)),
    (r'SOD-?323', (3.2, 1.6)), (r'SMC|DO-214AB', (9.0, 6.8)), (r'7343|D-case|\(D\)', (8.6, 5.0)), (r'DIP6|LF1', (10.9, 7.7)),
    (r'USB|Type-C|16P', (9.5, 8.0)), (r'Through-hole|THT|4\.4', (14.5, 12.0)), (r'PJ-332|3\.5 mm|jack', (14.5, 6.5)),
    (r'5\.0 ?x ?3\.2|5032', (6.0, 4.2)), (r'\b1210\b', (4.3, 3.2)),
    (r'1206', (4.5, 2.2)), (r'0805', (3.5, 2.0)), (r'0603', (3.0, 1.5)), (r'0402', (2.0, 1.0)),
]
ZONES = collections.OrderedDict([('Z1 USB input', 15 * 20), ('Z2+Z3 digital + clocks', 28 * 22 + 100), ('Z4 DAC core', 12 * 20),
                                 ('Z4s supervisor/MCLK-alive', 10 * 8), ('Z5 I/V + legs', 14 * 24), ('Z6 switch + jacks', 22 * 48),
                                 ('Z7 protection', 20 * 26), ('Z8 power', 38 * 24)])
Z4S = {'U605', 'U607', 'Q619', 'Q620', 'D609', 'D610'} | {f'R{n}' for n in range(665, 690)} | {f'C{n}' for n in range(623, 630)}
Z6P = {'K601', 'K602', 'K603', 'K604', 'U604', 'Q612', 'Q614', 'Q616', 'Q617', 'R641', 'R642', 'R643', 'R644', 'R645', 'R662', 'R663', 'C622'}
def expand(refs):
    out = []
    for tok in refs.replace(';', ',').split(','):
        tok = tok.strip()
        m = re.match(r'([A-Z]+)(\d+)\s*-\s*([A-Z]*)(\d+)$', tok)
        if m:
            p, a, b = m.group(1), int(m.group(2)), int(m.group(4))
            out += [f'{p}{i}' for i in range(a, b + 1)]
        elif re.match(r'[A-Z]+\d+$', tok):
            out.append(tok)
    return out
def zone(ref):
    n = int(re.sub(r'\D', '', ref) or 0); p = re.sub(r'\d', '', ref)
    if ref in Z4S: return 'Z4s supervisor/MCLK-alive'
    if ref in Z6P: return 'Z6 switch + jacks'
    if ref in ('U502', 'C502', 'Q507', 'R537'): return 'Z1 USB input'      # R9 E-16: 3V3M LDO fed from VBUS, U102 EN switch
    if 100 <= n < 200: return 'Z1 USB input'
    if 200 <= n < 300: return 'Z2+Z3 digital + clocks'
    if 300 <= n < 400: return 'Z4 DAC core'
    if 400 <= n < 500: return 'Z5 I/V + legs'
    if 500 <= n < 600: return 'Z8 power'
    if 600 <= n < 700: return 'Z7 protection'
    if 700 <= n < 800: return 'Z2+Z3 digital + clocks' if ref in ('D705', 'D706', 'R701', 'R702', 'R703', 'J703') else 'Z6 switch + jacks'
    if 900 <= n < 1000: return 'Z7 protection'          # R9 E-3 resistors R900-R925 (protection block 6 overflow numbering)
    return 'Z2+Z3 digital + clocks'
area = collections.Counter(); count = collections.Counter(); unknown = []; parts = 0; owner_extra = 0.0
for s in ['power', 'protection', 'analog', 'digital']:
    for r in csv.DictReader(open(os.path.join(BASE, s, 'bom_rows.csv'), encoding='utf-8-sig')):
        pkg = (r.get('package') or '') + ' ' + (r.get('mpn') or '')
        if re.search(r'PCB pad|no component|8 SMD pads|pads', pkg, re.I) and not re.search(r'jack|USB', pkg, re.I):
            continue
        c = next((d for rx, d in COURT if re.search(rx, pkg, re.I)), None)
        refs = expand(r.get('refs', ''))
        if not refs:
            continue
        if re.search(r'ECHU 0\.22|ECH-U1H224|\b2416\b', pkg):
            c = (7.0, 5.2)                                # 2416 (6041) film chip courtyard [ASSUMP IPC nominal]
        if c is None:
            unknown.append((s, r.get('refs'), r.get('package'))); continue
        own = 'owner' in ((r.get('note') or '') + (r.get('jlcpcb_stock_or_sourcing') or '') + (r.get('jlcpcb_class') or '')).lower()
        ct = refs[0] in ('C631', 'C632', 'C633', 'C634')
        if ct:
            own = False                                   # R9 check: JLCPCB-placed 2416 C_T; owner fit is the fallback
        L, W = c
        a = (L + 3.0) * (W + 3.0) if own else L * W
        if ct:
            a = (L + 3.0) * W                             # orchestrator 19:41: 1.5 mm iron clearance reserved at BOTH PAD ENDS only
            owner_extra += (a - L * W) * len(refs)
        for ref in refs:
            area[zone(ref)] += a; count[zone(ref)] += 1; parts += 1
            if own: owner_extra += a - L * W
tp = 53 * 4.0; mh = 4 * 33.0; fid = 7 * 7.0; dbg = 52 + 33
ZONES_100x80 = collections.OrderedDict([   # E-19 floor plan, board 100 x 80 mm (x right, y up; layout_package.md section 6)
    ('Z1 USB input', 18 * 28),                                  # x 0-18,  y 30-58
    ('Z2+Z3 digital + clocks', 46 * 22),                        # x 0-46,  y 58-80
    ('Z4 DAC core', 18 * 22 + 12 * 22),                         # x 40-58, y 36-58  + x 46-58, y 58-80
    ('Z4s supervisor/MCLK-alive', 22 * 22),                     # x 18-40, y 36-58
    ('Z5 I/V + legs', 20 * 50),                                 # x 58-78, y 30-80
    ('Z6 switch + jacks', 22 * 80 + 20 * 12),                   # x 78-100, y 0-80 + x 58-78, y 0-12
    ('Z7 protection', 28 * 36 + 20 * 18),                       # x 30-58, y 0-36  + x 58-78, y 12-30
    ('Z8 power', 30 * 30 + 12 * 6)])                            # x 0-30,  y 0-30  + x 18-30, y 30-36
out = ['R9 E-13 placement density (current stream BOMs; courtyards [ASSUMP IPC-7351B nominal]; owner-fitted + 1.5 mm iron clearance)',
       f'{parts} footprints (incl. DNF), owner-fitted clearance adds {owner_extra:.0f} mm2', '',
       f"{'zone':<28} {'parts':>5} {'courtyard mm2':>13} {'zone mm2':>9} {'use':>6}  verdict"]
tot = 0.0
for z, za in ZONES.items():
    u = area[z] / za; tot += area[z]
    v = 'comfortable' if u <= 0.55 else ('tight' if u <= 0.70 else 'OVER - move parts to a neighbour zone or grow')
    out.append(f'{z:<28} {count[z]:>5} {area[z]:>13.0f} {za:>9.0f} {100*u:>5.0f} %  {v}')
glob = tot + tp + mh + fid + dbg
board = 80 * 60; usable = board - 280 * 0.5
out += ['', f'parts courtyard total {tot:.0f} mm2 + test points {tp:.0f} + mounting holes {mh:.0f} + fiducials {fid:.0f} + debug pads {dbg:.0f} = {glob:.0f} mm2',
        f'board 80 x 60 = {board} mm2, usable (0.5 mm edge band) {usable:.0f} mm2 -> overall utilisation {100*glob/usable:.0f} %',
        f'grown board 100 x 80 = 8000 mm2 -> {100*glob/(8000-360*0.5):.0f} %; 100 x 70 = 7000 mm2 -> {100*glob/(7000-340*0.5):.0f} %; 90 x 70 = 6300 mm2 -> {100*glob/(6300-320*0.5):.0f} %']
out += ['', 'E-19 floor plan 100 x 80 mm (zone rectangles of layout_package.md section 6):',
        f"{'zone':<28} {'courtyard mm2':>13} {'zone mm2':>9} {'use':>6}   | 100 x 70 alternative (y scaled 70/80)"]
for z, za in ZONES_100x80.items():
    za70 = za * 70 / 80
    out.append(f'{z:<28} {area[z]:>13.0f} {za:>9.0f} {100*area[z]/za:>5.0f} %   | {za70:>6.0f} mm2 {100*area[z]/za70:>4.0f} %')
out.append(f'sum of zone areas {sum(ZONES_100x80.values()):.0f} mm2 (board 8000 mm2)')
if unknown:
    out += ['', 'packages not mapped (not counted):'] + [f'  {u}' for u in unknown]
open('placement_density_out.txt', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print('\n'.join(out))
