import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""VE round (ve/brief_ve.md, owner decisions O-1..O-4): JLCPCB fee model Economic vs Standard, owner-fitted list,
consolidation candidates, attrition/ordering (no spares) and owner-purchase cost, from the CURRENT stream BOMs.

Sources (read 25 Sep 2026):
  JLCPCB fee table  https://jlcpcb.com/help/article/pcb-assembly-price (last updated 8 Sep 2026)
  JLCPCB capability https://jlcpcb.com/capabilities/pcb-assembly-capabilities (Economic vs Standard table)
  Global sourcing   https://jlcpcb.com/help/article/how-to-use-jlcpcb-global-sourcing-parts-service (relay duty 3-30 %,
                    connector commodity inspection US$ 20 per kind)
  Via covering      https://jlcpcb.com/help/article/pcb-via-covering (resin filling free only for >= 6 layers)
  DigiKey Taiwan    https://www.digikey.tw/en/help-support/delivery-information/delivery-time-and-cost (free >= US$ 50, else US$ 20)
  Taiwan Customs    customs value <= NT$ 2,000: duty, commodity tax and business tax exempted (web.customs.gov.tw FAQ)
Labels: [DS] published fee/rule, [CALC], [ASSUMP].
Writes ve_cost_model_out.txt and ve_lines.csv.
"""
import csv, os, re, math, collections

BASE = _PKG_ROOT + ''
STREAMS = ['power', 'protection', 'analog', 'digital']
N = 5                                   # boards (O-1: exact quantity, no spares)

# ---------------- JLCPCB fee table [DS, 8 Sep 2026]
ECON = dict(setup=8.18, stencil=1.53, smt=0.0016, manual=0.0164, hand_labor=3.58, ext_type=3.07, confirm=0.45)
STD = dict(setup=25.56, stencil=8.21, smt=0.0016, manual=0.0164, hand_labor=3.58, any_type=1.53, confirm=0.45,
           fixture=16.42, packing_base=0.50, packing_cm2=0.00003, handling_min_diff=14.93)
XRAY = [(10, 1.64), (50, 0.82), (200, 0.49), (500, 0.33), (1000, 0.25), (3000, 0.16), (99999, 0.082)]
def xray_fee(n):
    for lim, p in XRAY:
        if n <= lim:
            return n * p
    return n * XRAY[-1][1]

# JLCPCB Basic codes known to the parts stream (class text of a stream BOM wins when it says Basic)
KNOWN_BASIC = {'C25744', 'C25741', 'C11702', 'C25900', 'C17168', 'C1525', 'C15849', 'C23630', 'C1546', 'C20917', 'C2297',
               'C2286', 'C25879', 'C26083', 'C25790', 'C8545', 'C1779', 'C15195', 'C12530', 'C1562', 'C25104', 'C25105'}
FIXTURE_NOTE = {'C224063', 'C85084', 'C389351', 'C110921', 'C548774', 'C109295'}   # part pages: "fixture needed" (Standard fee)

def fnum(x, d=0.0):
    try:
        return float(str(x).strip())
    except ValueError:
        return d

rows = []
for s in STREAMS:
    f = os.path.join(BASE, s, 'bom_rows.csv')
    for r in csv.DictReader(open(f, encoding='utf-8-sig')):
        r = dict(r); r['stream'] = s
        rows.append(r)

lines = []
for r in rows:
    fit = (r.get('fit') or '').strip().lower()
    mpn = (r.get('mpn') or '').strip()
    if not fit.startswith('yes'):
        continue
    if any(k in mpn.lower() for k in ('pcb pad', 'pads (no component)', 'no component')):
        continue
    txt = ' '.join([r.get('jlcpcb_class', ''), r.get('jlcpcb_stock_or_sourcing', ''), r.get('note', '')]).lower()
    owner = 'owner-fitted' in txt or 'owner purchase' in txt
    lcsc = (r.get('lcsc') or '').strip()
    m = re.match(r'(C\d{3,9})', lcsc)
    code = m.group(1) if m else ''
    cls = (r.get('jlcpcb_class') or '')
    basic = (cls.strip().lower().startswith('basic') and 'tbc' not in cls.lower()) or code in KNOWN_BASIC
    glob = ('global' in txt and not owner) or (not code and not owner)
    qty = int(fnum(r.get('qty'), 1))
    smt = int(fnum(r.get('smt_pins_per_part'), 0)); tht = int(fnum(r.get('tht_pins_per_part'), 0))
    if 'USB4105' in mpn or 'TYPE-C-31' in mpn:   # shell stakes reflowed pin-in-paste (JLCPCB 'SMT Assembly'), not manual THT
        smt, tht = smt + tht, 0
    lines.append(dict(stream=s if False else r['stream'], refs=r.get('refs', ''), qty=qty, mpn=mpn, code=code, basic=basic,
                      owner=owner, glob=glob, smt=smt, tht=tht, leadless=(r.get('leadless') or '').lower().startswith('y'),
                      price=fnum(r.get('unit_price_usd'), 0.0), cls=cls, src=r.get('jlcpcb_stock_or_sourcing', '')))

def model(ls, klass):
    placed = [l for l in ls if not l['owner']]
    types = collections.OrderedDict()
    for l in placed:
        key = l['code'] or l['mpn']
        t = types.setdefault(key, dict(basic=l['basic'], mpn=l['mpn'], glob=l['glob'], code=l['code']))
        t['basic'] = t['basic'] and l['basic']
    n_types = len(types); n_ext = sum(1 for t in types.values() if not t['basic'])
    smt_j = N * sum(l['qty'] * l['smt'] for l in placed)
    tht_j = N * sum(l['qty'] * l['tht'] for l in placed)
    xr = N * sum(l['qty'] for l in placed if l['leadless'])
    fee = collections.OrderedDict()
    if klass == 'Economic':
        fee['setup'] = ECON['setup']; fee['stencil'] = ECON['stencil']; fee['SMT joints'] = smt_j * ECON['smt']
        fee['manual/THT joints'] = tht_j * ECON['manual']; fee['hand-soldering labor'] = ECON['hand_labor'] if tht_j else 0.0
        fee['Extended types x 3.07'] = n_ext * ECON['ext_type']
        fee['X-ray'] = xray_fee(xr); fee['confirm placement'] = ECON['confirm']
    else:
        fee['setup'] = STD['setup']; fee['stencil'] = STD['stencil']; fee['SMT joints'] = smt_j * STD['smt']
        fee['manual/THT joints'] = tht_j * STD['manual']; fee['hand-soldering labor'] = STD['hand_labor'] if tht_j else 0.0
        fee['all types x 1.53'] = n_types * STD['any_type']
        fee['X-ray'] = xray_fee(xr); fee['confirm placement'] = STD['confirm']
        fee['fixture (2 for 1-29 boards)'] = STD['fixture'] if any(t['code'] in FIXTURE_NOTE for t in types.values()) else 0.0
        fee['packing'] = STD['packing_base'] + STD['packing_cm2'] * 8.0 * 7.0 * N
    parts = sum(l['price'] * l['qty'] * N for l in placed)
    return dict(types=n_types, ext=n_ext, smt_j=smt_j, tht_j=tht_j, xray_n=xr, fee=fee, fee_sum=sum(fee.values()), parts=parts,
                typelist=types)

out = []
def P(s=''):
    out.append(s)

eco = model(lines, 'Economic'); std = model(lines, 'Standard')
diff = std['fee_sum'] - eco['fee_sum']
handling = max(0.0, STD['handling_min_diff'] - diff)
P(f'VE cost model, 25 Sep 2026 - {N} boards, stream BOMs: ' + ', '.join(
    f"{s} {__import__('datetime').datetime.fromtimestamp(os.path.getmtime(os.path.join(BASE, s, 'bom_rows.csv')), __import__('datetime').timezone.utc).strftime('%H:%M')}" for s in STREAMS))
P(f"fitted lines {len(lines)}; owner-fitted lines {sum(l['owner'] for l in lines)}; JLCPCB-placed part types {eco['types']} "
  f"(Basic {eco['types'] - eco['ext']}, Extended/unknown {eco['ext']}); SMT joints {eco['smt_j']}, THT joints {eco['tht_j']}, X-ray parts {eco['xray_n']}")
P('\n1. Assembly fees (JLCPCB table of 8 Sep 2026) [CALC]')
for k in eco['fee']:
    P(f"  Economic  {k:<28} {eco['fee'][k]:8.2f}")
P(f"  Economic  TOTAL assembly fees        {eco['fee_sum']:8.2f}")
for k in std['fee']:
    P(f"  Standard  {k:<28} {std['fee'][k]:8.2f}")
P(f"  Standard  handling-fee top-up (difference must be >= 14.93) {handling:8.2f}")
P(f"  Standard  TOTAL assembly fees        {std['fee_sum'] + handling:8.2f}")
P(f"  -> Economic saves {std['fee_sum'] + handling - eco['fee_sum']:.2f} US$ per 5-board order in assembly fees alone "
  f"(+ no edge rails: panel 80 x 60 instead of 80 x 70 mm; PCB price effect not modelled [ASSUMP small])")
P(f"  JLCPCB-placed parts at stream unit prices x {N} boards: {eco['parts']:.2f} US$ (attrition extra, set by JLCPCB per part)")

# ---------------- Economic process check (O-2): parts placed by JLCPCB that sit at/over an Economic limit
ECON_ISSUES = [
    (r'USB4105', 'peak 255 C (-0/+5) max 5 s < 260 C -> blocks Economic (power V1: replace J101)'),
    (r'TYPE-C-31-M-12', 'HRO drawing not retrievable -> reflow rating and pad map unverified (power V2)'),
    (r'TLP3545A', 'Tsol 260 C 10 s, <= 2 reflows: at the Economic peak -> owner-fitted (protection VE)'),
    (r'PJ-332A', 'SMD jack, plastic body: reflow rating not read (drawing image-only) -> confirm >= 260 C or owner-fit'),
    (r'AGRV2K', 'QFN-32 0.40 mm pitch = the Economic minimum, and Economic has no SPI -> allowed by the rule, highest-risk joint (X-ray applied)'),
    (r'KC2520K|NZ2520SDA', 'LGA 2520: 260 C (Kyocera) / 265 C (NDK) -> OK; X-ray'),
    (r'T495D|TAJD|TPSD', 'D-case tantalum: 260 C J-STD-020 class [ASSUMP, profile not re-read]'),
    (r'ES9018K2M', '<= 260 C, 3 reflows [DS] -> OK'),
    (r'CH32V307', 'WCH reflow not read; JLCPCB page lists Economic and Standard -> accepted on the JLCPCB listing'),
]
P('\n2. Economic process check (O-2: peak >= 260 C with a normal profile, pitch >= 0.4 mm, package >= 0402, no SPI)')
for rx, why in ECON_ISSUES:
    hit = [l for l in lines if re.search(rx, l['mpn'])]
    for l in hit:
        P(f"  {'OWNER' if l['owner'] else 'PLACED':6} {l['stream']:<10} {l['refs'][:22]:<22} {l['mpn'][:34]:<34} {why}")
small = [l for l in lines if re.search(r'\b0201\b', l['mpn'] + ' ' + l['cls'])]
P(f"  packages < 0402: {len(small)}; finest placed pitch 0.40 mm (U202); single-sided, 4 layers, 1.6 mm, 5 pcs: inside Economic")

# ---------------- owner-fitted lines
P('\n3. Owner-fitted lines now in the stream BOMs (O-4)')
own = [l for l in lines if l['owner']]
own_cost = 0.0
for l in own:
    c = l['price'] * l['qty'] * N
    own_cost += c
    P(f"  {l['stream']:<10} {l['refs'][:22]:<22} {l['mpn'][:34]:<34} {l['qty']} x {N} x {l['price']:.3f} = {c:7.2f} US$")
nt_limit = 2000 / 32.5                # [ASSUMP] 32.5 NT$/US$
ship = 0.0 if own_cost >= 50 else 20.0
tax = 0.05 * (own_cost + ship) if own_cost + ship > nt_limit else 0.0
P(f"  owner order {own_cost:.2f} US$ + DigiKey TW shipping {ship:.2f} (free >= 50) + Taiwan business tax 5 % {tax:.2f} "
  f"(exempt <= NT$ 2,000 = {nt_limit:.0f} US$ at 32.5 NT$/US$ [ASSUMP]; ITA electronics tariff 0 % [ASSUMP]) = {own_cost + ship + tax:.2f} US$")

# ---------------- owner-fitted savings per line (JLCPCB route vs owner route) [CALC with ASSUMP noted]
P('\n3a. Owner-fitted savings per 5-board order (JLCPCB route = part x (5 x qty + attrition) + duty/inspection + Extended fee (+ THT labor); owner route = 5 x qty x distributor price, tax share)')
DUTY = {'TLP3545A': 0.30}                      # JLCPCB global sourcing: relays 3-30 % customs duty (protection used 30 %) [DS range, ASSUMP upper]
INSPECT = {}                                   # connectors via global sourcing: US$ 20 per kind (J701 is an LCSC part -> none)
ATTR = {'TLP3545A': 1, 'GT-3321667P': 1, 'SMDJ12A': 1, 'RN73R1JTTD4811': 5}   # [ASSUMP] JLCPCB attrition pieces for these lines
tot_s_e = tot_s_s = 0.0
for l in own:
    key = next((k for k in ATTR if k in l['mpn']), None)
    att = ATTR.get(key, 1)
    duty = next((v for k, v in DUTY.items() if k in l['mpn']), 0.0)
    part_j = l['price'] * (l['qty'] * N + att) * (1 + duty)
    tht_fee = (ECON['hand_labor'] + N * l['qty'] * l['tht'] * ECON['manual']) if l['tht'] else 0.0
    j_e = part_j + ECON['ext_type'] + tht_fee
    j_s = part_j + STD['any_type'] + tht_fee
    o = l['price'] * l['qty'] * N * (1.05 if own_cost + ship > nt_limit else 1.0)
    tot_s_e += j_e - o; tot_s_s += j_s - o
    P(f"  {l['refs'][:22]:<22} {l['mpn'][:30]:<30} JLCPCB route {j_e:7.2f} (Econ) / {j_s:7.2f} (Std) vs owner {o:7.2f} -> saves {j_e - o:6.2f} / {j_s - o:6.2f} US$ per order ({(j_e - o)/N:.2f} / {(j_s - o)/N:.2f} per board)")
P(f"  total owner-fitted saving {tot_s_e:.2f} US$ (Economic) / {tot_s_s:.2f} US$ (Standard) per order; the THT line also removes the per-order hand-soldering labor fee only if no other THT part is placed")

# ---------------- class decision (O-2 literal reading)
P('\n1a. Class decision (O-2): Economic is allowed only if no JLCPCB-placed part sits at an Economic limit.')
P('  U202 AGRV2KQ32 (QFN-32, 0.40 mm pitch) equals the Economic minimum pitch and Economic has no SPI; it cannot be owner-fitted (QFN, O-4).')
P('  J101 USB4105 (255 C/5 s) must be replaced first (power VE); J702 PJ-332A-6A reflow rating unverified.')
P(f"  -> Standard retained unless the owner accepts U202 at the pitch limit; the price of that choice is the handling-fee floor: Standard = Economic + {max(STD['handling_min_diff'], diff):.2f} US$ per order.")

# ---------------- consolidation candidates (same function, one type less)
P('\n4. Part-type consolidation (each Extended type removed saves 3.07 US$ Economic / 1.53 US$ Standard per order)')
CONS = [
    ('BAT54,215', 'BAT54S,215', 'D103-D105 on BAT54S C47546 (already D405-D408): pin 1 A1 -> pin 3 K1 is the same diode, pin 2 (K2) on the NC pad floats; power to confirm the leakage bound (one die, same IR)'),
    ('BAS70,215', 'BAS70-04,215', 'D610 on BAS70-04 C389351 (already D609): pin 1 -> 3 same diode, pin 2 floats; also fixes the BAS70 stock (LCSC 0)'),
]
mpns = ' | '.join(l['mpn'] for l in lines if not l['owner'])
for a, b, why in CONS:
    pa, pb = (a in mpns), (b in mpns)
    P(f"  {a:<14} -> {b:<14} {'APPLICABLE' if pa and pb else ('done/not present' if not pa else 'target absent')}: {why}")
exts = [(k, t['mpn']) for k, t in eco['typelist'].items() if not t['basic']]
P(f"  Extended/unknown types placed by JLCPCB ({len(exts)}):")
for k, m in exts:
    P(f"    {k:<12} {m[:60]}")

# ---------------- attrition / ordering (O-1)
P('\n5. Ordering and attrition (O-1: exact 5-board quantity + JLCPCB attrition, no spares)')
P('  JLCPCB library parts: JLCPCB adds its per-part attrition/minimum quantity automatically in the quote (FAQ: "minimum quantity ... or extra parts to cover attrition";')
P('  unused parts are discarded, not shipped). Global-sourcing buys: need + the attrition JLCPCB shows for that part; consigned/owner parts: owner buys 5 x qty (+ the gate samples, separate).')
P('  -> every "buy N now" of the round-3 plan that included spares (OPA2210 12/16, KC2520K 20, NZ2520SDA 10+10, TLP3545A 25, TLV1704 25, T495D 15, U208 10, D102 10, 0.1 % resistors 50-60)')
P('     drops to 5 x per-board + attrition; gate samples (2 per type named in G-1...G-4) are one small owner order.')
# ---------------- O-1 saving: round-3 buy quantities (with spares) -> 5 x per board + attrition estimate
import io, contextlib, importlib.util
spec = importlib.util.spec_from_file_location('pcs', os.path.join(BASE, 'parts', 'pcba_class_scan.py'))
pcs = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(pcs)
P('\n6. O-1 saving (no spares) against the round-3 buy plan [CALC; attrition estimate 1 pc per IC/oscillator/connector line, 5 % min 2 for passives - ASSUMP; JLCPCB sets the real figure]')
tot_o1 = 0.0
price_of = {}
for l in lines:
    price_of.setdefault(l['refs'].split(',')[0].split('-')[0].strip(), l['price'])
for refs_, part, per, buy, when, source, why in pcs.ORDER_PLAN:
    m = re.search(r'\(was (\d+) with spares\)', why)
    if not m or not per:
        continue
    old_buy = int(m.group(1)); need = 5 * per
    att = 1 if per <= 4 and not re.search(r'R\d|C\d', refs_.split()[0]) else max(2, math.ceil(0.05 * need))
    key = refs_.split(',')[0].split('-')[0].split(' ')[0].strip()
    pr = price_of.get(key, 0.0)
    sv = max(0, old_buy - need - att) * pr
    tot_o1 += sv
    if sv > 0.5:
        P(f"  {refs_[:26]:<26} {old_buy:>4} -> {need}+{att:<3} x {pr:6.3f} = {sv:6.2f} US$")
P(f"  O-1 total about {tot_o1:.0f} US$ per order (parts only; the NDK X201 second source (5 pcs) is also dropped)")
open(os.path.join(BASE, 'parts', 've_cost_model_out.txt'), 'w', encoding='utf-8').write('\n'.join(out) + '\n')
with open(os.path.join(BASE, 'parts', 've_lines.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=['stream', 'refs', 'qty', 'mpn', 'code', 'basic', 'owner', 'glob', 'smt', 'tht', 'leadless', 'price', 'cls', 'src'])
    w.writeheader()
    for l in lines:
        w.writerow(l)
print('\n'.join(out))
