import os as _os_pkg  # calc_package: package root from this file (no absolute paths)
_PKG_ROOT = _os_pkg.path.normpath(_os_pkg.path.join(_os_pkg.path.dirname(_os_pkg.path.abspath(__file__)), '..'))
"""PCBA-class and ordering scan (Follow-up 2 item 5, updated in Follow-up 3 for D-14 = JLCPCB Standard PCBA, top side).

Reads every stream's bom_rows.csv (latest versions), overlays the binding decisions of
integration/decisions_r8b.md / decisions_r8c.md that a stream BOM may not show yet (DECISIONS), and flags each line against
the JLCPCB PCBA limits (read 24 Sep 2026, https://jlcpcb.com/capabilities/pcb-assembly-capabilities):
  Standard (chosen, D-14): reflow 240 +/- 5 C (peak <= 245 C), min IC pin spacing 0.35 mm, min package 0201,
            single PCB >= 70 x 70 mm (else rails/panel), rails + fiducials necessary, SPI + AOI + X-ray.
  Economic (for reference): reflow 255 +/- 5 C fixed, min pitch 0.4 mm, min package 0402, no SPI.
Flags: GLOBAL (no usable LCSC stock -> JLCPCB global sourcing), LOW (LCSC/JLCPCB stock thin or reserve),
       LONG-LEAD (factory lead >= 16 weeks with thin distributor stock, or non-stocked), REFLOW (maker peak
       limit <= 255 C or time-limited), PITCH (<= 0.4 mm), THT, LEADLESS (X-ray), MSL>=2, STALE (the stream BOM
       line still shows a part that a decision replaced), NO-SOURCE (no small-quantity source found).
Outputs: pcba_class_table.csv, pcba_class_scan_out.txt (summary + ordering plan).
Labels in 'src': DS = maker document, JLC = JLCPCB/LCSC part page, DK/MO = DigiKey/Mouser page, ASSUMP = not read.
"""
import csv, re, os, datetime

BASE = _PKG_ROOT + ''
STREAMS = ['power', 'protection', 'analog', 'digital']
TODAY = '25 Sep 2026'

# Decisions / parts-stream results that a stream BOM may not carry yet (added as lines of their own).
DECISIONS = [
    dict(stream='decision', refs='J101', mpn='GCT USB4105-GF-A', lcsc='C3020560', package='USB-C 16P SMT + 4 THT shell stakes',
         jlcpcb_class='Extended (global if LCSC 0)', jlcpcb_stock_or_sourcing='LCSC out of stock (14 Sep 2026); DigiKey 127,933 (24 Sep 2026)',
         leadless='No', tht_pins_per_part='0', note='D-8', qty='1'),
    dict(stream='decision', refs='U103', mpn='TI TPD2E2U06DRLR', lcsc='C1972959', package='SOT-5X3 (DRL)', jlcpcb_class='Extended',
         jlcpcb_stock_or_sourcing='JLCPCB 4,257 (Apr 2025); DigiKey 87,628 (Sep 2026)', leadless='No', tht_pins_per_part='0', note='D-8', qty='1'),
    dict(stream='decision', refs='U503', mpn='TI TPS259621DDAR', lcsc='C2155774', package='HSOIC-8 PowerPAD (DDA)', jlcpcb_class='Extended',
         jlcpcb_stock_or_sourcing='JLCPCB 656 (17 Sep 2026); DigiKey 1,377', leadless='No', tht_pins_per_part='0', note='D-5 (EP needs X-ray)', qty='1'),
    dict(stream='decision', refs='U505', mpn='TI TMUX1101DBVR', lcsc='C1852057', package='SOT-23-5 (DBV)', jlcpcb_class='Extended',
         jlcpcb_stock_or_sourcing='DigiKey 2,865, Mouser 9,098 (Sep 2026); JLCPCB stock not shown', leadless='No', tht_pins_per_part='0', note='D-5', qty='1'),
    dict(stream='decision', refs='U303', mpn='TI TLV75801PDBVR', lcsc='C2877852', package='SOT-23-5 (DBV)', jlcpcb_class='Extended',
         jlcpcb_stock_or_sourcing='LCSC 113,390 (24 Sep 2026)', leadless='No', tht_pins_per_part='0', note='D-7', qty='1'),
    dict(stream='decision', refs='K601-K604', mpn='Toshiba TLP3545A(TP1,F)', lcsc='-', package='DIP6 LF1 SMD gull wing 7.62 mm',
         jlcpcb_class='Global sourcing', jlcpcb_stock_or_sourcing='DigiKey 28,529 (18 Sep 2026); Mouser 15,284 (Aug 2026); factory lead 24 weeks',
         leadless='No', tht_pins_per_part='0', note='D-1', qty='4'),
    dict(stream='decision', refs='X201', mpn='Kyocera KC2520K80.0000C1GE00', lcsc='C1988889 (not available)', package='2.5 x 2.0 mm 4-pad',
         jlcpcb_class='Global sourcing', jlcpcb_stock_or_sourcing='DigiKey 2,964 (5 Aug 2026); Mouser 1,375 + 10,000 on order (18 Sep 2026); factory lead 32 weeks',
         leadless='Yes', tht_pins_per_part='0', note='D-3 revised (Epson SG-210STF 75 MHz EOL)', qty='1'),
    dict(stream='decision', refs='X201 (2nd source)', mpn='NDK NSC5338D-80M (NZ2520SH 80 MHz 3.3 V)', lcsc='-', package='2.5 x 2.0 mm 4-pad',
         jlcpcb_class='Global sourcing', jlcpcb_stock_or_sourcing='DigiKey 974 (Jul 2026); factory lead 24 weeks', leadless='Yes',
         tht_pins_per_part='0', note='D-3 revised: conditional second source, budget 12.7 mA, bring-up checks (disable time, edges)', qty='0'),
]

# Stream BOM lines that a decision has replaced (flag STALE until the stream updates its BOM).
STALE = [
    (r'SHOU HAN', 'J101 -> GCT USB4105-GF-A (D-8)'),
    (r'TPS2553', 'U503 -> TPS259621DDAR + TMUX1101 (D-5)'),
    (r'ME6216', 'U303 -> TLV75801PDBVR (D-7)'),
    (r'AQV251', 'K601-K604 -> TLP3545A(TP1,F) (D-1; AQV251GA only if JLCPCB confirms <= 250 C)'),
    (r'7X-80', 'X201 -> Kyocera KC2520K80.0000C1GE00 (Follow-up 3)'),
    (r'SX3M80', 'X201 -> Kyocera KC2520K80.0000C1GE00 (Follow-up 3)'),
    (r'SG-210STF', 'X201 -> Kyocera KC2520K80.0000C1GE00 (SG-210STF 75 MHz EOL, Follow-up 3)'),
    (r'2N7002.*Q501|Q501.*2N7002', 'Q501 -> TMUX1101 U505 (D-5)'),
]

# facts keyed by a regex on the MPN: (reflow text, peak C or None, time-limited?, pitch mm or None, MSL, src, lead/source note)
FACTS = [
    (r'USB4105', 'peak 255 C (-0/+5), 5 s max; JLCPCB "SMT Assembly", difficulty High', 255, True, 0.5, '1', 'DS GCT; JLC C3020560', ''),
    (r'AQV251', 'IR reflow peak <= 250 C, >= 230 C <= 30 s', 250, True, 2.54, '-', 'DS Panasonic PhotoMOS tech info', ''),
    (r'TLP3545A', 'Tsol 260 C (10 s); reflow once or twice within 2 weeks', 260, False, 2.54, '1', 'DS Toshiba 2023-05; DK MSL 1', 'factory 24 wk; DK 28,529'),
    (r'KC2520K', 'reflow 260 C x 2 [D-3 revised text]', 260, False, None, '1', 'DK MSL 1; D-3 revised', 'factory 32 wk; DK 2,964, MO 1,375'),
    (r'NSC5338D|NZ2520SH', 'IR reflow (lead free) [NDK]', 260, False, None, '1', 'DK MSL 1', 'factory 24 wk; DK 974'),
    (r'7X-80', 'profile peak 260 +/- 10 C, 10 s', 260, False, None, '1', 'DS TXC 7X', 'withdrawn in D-3 revised (MOQ 3,000, not procurable)'),
    (r'SG-210STF', 'J-STD-020D.1 profile', 260, False, None, '1', 'DS Epson', 'EOL'),
    (r'NZ2520SDA|NSC5083D', 'peak 265 C 10 s, >= 230 C 40 s, 3 passes', 265, False, None, '1', 'DS NDK NZ2520SDA', 'factory 24 wk; DK 3,438 / 3,166'),
    (r'SX3M', 'not read (assume 260 C J-STD-020)', None, False, None, '1', 'ASSUMP (SCTF)', 'non-compliant fallback only'),
    (r'ES9018K2M', '<= 260 C, 3 reflows', 260, False, 0.5, '?', 'DS ESS (local copy)', 'LCSC 724: reserve'),
    (r'CH32V307', 'not read (WCH, assume 260 C)', None, False, 0.5, '3', 'JLC MSL 3; ASSUMP reflow', 'JLCPCB 364: reserve'),
    (r'AGRV2K', 'not read', None, False, 0.4, '?', 'pitch from QFN-32 4x4 drawing (0.4 mm)', 'LCSC 980: reserve'),
    (r'TPS2596', 'MSL 2-260C-1 YEAR', 260, False, 1.27, '2', 'TI ordering table', ''),
    (r'TPS25961', 'MSL 1-260C', 260, False, 0.65, '1', 'JLC C5571272', ''),
    (r'OPA1622', 'TI MSL table 260 C', 260, False, 0.5, '?', 'TI (phase 1)', ''),
    (r'OPA2210', 'MSL 2-260C-1 YEAR', 260, False, 1.27, '2', 'TI / DK MSL 2', 'DK 0 (due 14 Dec), MO 0 (due 23 Nov), LCSC 16'),
    (r'LM27762', 'TI MSL table 260 C', 260, False, 0.5, '?', 'TI (phase 1)', ''),
    (r'TPS25200|TLV76733', 'TI MSL table 260 C', 260, False, 0.65, '?', 'TI (phase 1)', ''),
    (r'TLV1704', 'MSL 2-260C-1 YEAR', 260, False, 0.65, '2', 'TI addendum 20 Aug 2026', 'LCSC 61; DK 6,948'),
    (r'TPD2E2U06', 'MSL 1-260C-UNLIM', 260, False, 0.5, '1', 'TI addendum; JLC C1972959', ''),
    (r'TMUX1101', 'MSL 1-260C-UNLIM', 260, False, 0.95, '1', 'TI; JLC C1852057', ''),
    (r'TLV75801|TPS7A2033|LP5907|TPS2553', 'TI MSL table 260 C', 260, False, 0.95, '1', 'TI', ''),
    (r'TPS70933', 'TI 260 C class [MSL not read]', 260, False, 0.95, '?', 'LCSC C89347 5,280 (25 Sep 2026); JLCPCB Economic+Standard', 'R9 E-16 U502'),
    (r'USBLC6', 'TL 260 C', 260, False, 0.95, '1', 'DS ST (phase 1)', ''),
    (r'74LVC1G', 'Nexperia 260 C', 260, False, 0.65, '1', 'ASSUMP (Nexperia J-STD-020)', ''),
    (r'ME6216', 'not read', None, False, 0.95, '?', 'replaced by TLV75801PDBVR', ''),
    (r'PJ-332A', 'not read (SMD 3.5 mm jack, plastic body)', None, False, None, '?', 'confirm with the HRO drawing', ''),
    (r'GT-3321667P', 'THT, wave/hand soldered (not reflowed)', None, False, None, '-', 'JLCPCB THT = wave/hand, both PCBA types', 'JLCPCB 21 / LCSC 724'),
    (r'KT-0', 'not read (LED)', None, False, None, '3', 'JLCPCB Basic LED (MSL 3)', ''),
    (r'LESD5D5', 'not read (LRC original MSL 3)', None, False, None, '3', 'JLC C383211 (LRC) MSL 3', ''),
    (r'BAT54S', 'Nexperia reflow profile (260 C class)', 260, False, 0.95, '1', 'JLC C47546 MSL 1', ''),
    (r'SHOU HAN', 'not read', None, False, 0.5, '?', 'replaced by USB4105-GF-A', ''),
    (r'RT0603WRB07(1K33|665R)', '260 C (YAGEO RT)', 260, False, None, '1', 'DK: not stocked, MOQ 5,000, 20 wk', 'NO SMALL-QTY SOURCE'),
    (r'RT0603WRB072KL', '260 C (YAGEO RT)', 260, False, None, '1', 'LCSC OOS; ERA-3ARW202V DK 1,259; RG1608N-202-W-T1 DK 16,746', ''),
    (r'RG1608P-4751', '260 C class (Susumu RG)', 260, False, None, '1', 'DK 114,162 (25 Sep 2026)', ''),
    (r'RG1608N-132', '260 C class (Susumu RG)', 260, False, None, '1', 'DK 157 (+ ERA-3ARW132V 661)', 'thin DigiKey stock: buy now'),
    (r'RG1608N-681', '260 C class (Susumu RG)', 260, False, None, '1', 'DK 783', 'buy now'),
    (r'RG1608N-202', '260 C class (Susumu RG)', 260, False, None, '1', 'DK 16,746 (+ ERA-3ARW202V 1,259)', ''),
    (r'RT0402BRD07(121K|115K|5K1)', '260 C (YAGEO RT)', 260, False, None, '1', 'DK 25,651 / 19,542 / 25,165', ''),
    (r'PATT0402', 'Vishay thin film (260 C class)', 260, False, None, '1', 'DK MSL 1; DigiKey 3,285 (Feb 2026), 15 wk', ''),
    (r'OPA2333', 'MSL 1 (JLCPCB)', 260, False, 1.27, '1', 'JLC C38732 MSL 1', 'LCSC 5,082 (25 Sep 2026)'),
    (r'UNI-ROYAL', '260 C 10 s', 260, False, None, '1', 'DS UNI-ROYAL (phase 1)', ''),
    # R8 round 3 (decisions_r8c) parts
    (r'PMEG2010AEH', 'Nexperia reflow profile (260 C class)', 260, False, None, '1', 'DS Nexperia v.5; LCSC C110921 11,165 (Jun 2026); JLCPCB library 0', 'pre-order from LCSC'),
    (r'T520D227', 'KEMET T520 reflow 260 C class', 260, False, None, '3', 'DK MSL 3 (168 h); KEMET spec (LCSC)', 'LCSC 53 (Nov 2025); DK 9,494; factory 27 wk'),
    (r'T495D227', 'KEMET T495 (J-STD-020, 260 C class) [ASSUMP, profile not re-read]', 260, False, None, '1', 'DK MSL 1; Buerklin: series MSL 1', 'DK 3,860 (Sep 2026), factory 24 wk; LCSC C212677 out of stock; alt. AVX TPSD227K010R0100 DK 1,534 (13 wk)'),
    (r'TPSD227K010', 'AVX TPS (260 C class) [ASSUMP]', 260, False, None, '1', 'DK MSL 1', 'DK 1,534 (25 Sep 2026), factory 13 wk'),
    (r'BLM15PX330', 'Murata 260 C class', 260, False, None, '1', 'LCSC C160974 22,900 (Mar 2026); DK 0 until 2 Oct 2026', 'alternate only, not ordered'),
    (r'74LVC3G34', 'Nexperia 260 C', 260, False, 0.5, '1', 'JLC C548774 MSL 1', 'DK 0 (due 21 Sep 2026), MO 0 (Feb 2027); LCSC 1,604'),
    (r'SMDJ12A', 'Littelfuse SMD TVS, peak 260 C class', 260, False, None, '1', 'DK MSL 1; JLC C224063 (fixture note)', 'DK 5,498 (Sep 2026); JLCPCB 115 (Sep 2025 page); LCSC 0'),
    (r'BAT54,215', 'Nexperia reflow profile (260 C class)', 260, False, 0.95, '1', 'JLC C85084 MSL 1', ''),
    (r'TLV3402', 'MSL 1-260C-UNLIM', 260, False, 0.65, '1', 'TI part page (Aug 2026)', 'TI: consider an alternate for new designs; LCSC 152'),
    (r'74AUP1G17', 'Nexperia 260 C', 260, False, 0.65, '1', 'JLC C545626 MSL 1; DK MSL 1', 'LCSC 0; DK 66,948'),
    (r'BAS70-04', 'Nexperia 260 C class', 260, False, 0.95, '1', 'DK MSL 1; LCSC C389351', ''),
    (r'AO3400A', 'AOS 260 C class', 260, False, 0.95, '1', 'JLCPCB Basic C20917', ''),
]
# LCSC codes found by the parts stream for stream-BOM lines that carry no code (round 3): regex on MPN -> (code, stock text, keep GLOBAL?)
LCSC_FOUND = [
    (r'0402WGF6812TCE', 'C11537', 'JLCPCB Extended, 9,921 available (23 Sep 2026)', False),
    (r'0402WGF3012TCE', 'C29402', 'JLCPCB Extended, 60,726 available (23 Sep 2026)', False),
    (r'BAT54,215', 'C85084', 'JLCPCB Extended, 202,689 (18 Aug 2026)', False),
    (r'PMEG2010AEH', 'C110921', 'LCSC 11,165 (13 Jun 2026); JLCPCB own stock 0 -> pre-order from LCSC', False),
    (r'T520D227M006ATE015', 'C3018564', 'LCSC 53 (Nov 2025 page) -> global sourcing if gone (DigiKey 9,494)', True),
    (r'T495D227K010ATE100', 'C212677', 'LCSC out of stock (Jun 2026 page) -> global sourcing (DigiKey 3,860; alt. AVX TPSD227K010R0100 DigiKey 1,534)', True),
    (r'SMDJ12A', 'C224063', 'JLCPCB 115 (Sep 2025 page), LCSC 0 -> global sourcing if gone (DigiKey 5,498)', True),
    (r'TLV3402IDR', 'C91242', 'LCSC 745 (25 Sep 2026); TI part page: consider an alternate for new designs', False),
    (r'74AUP1G17GW', 'C545626', 'LCSC out of stock (25 Sep 2026) -> global sourcing (DigiKey 66,948)', True),
    (r'BAS70-04,215', 'C389351', 'LCSC 36,430 (9 Sep 2026)', False),
    (r'BAS70,215', 'C109295', 'LCSC out of stock (Apr 2026), JLCPCB 9 (Feb 2026) -> BAS70-04,215 drop-in or global sourcing', True),
    (r'RT0402BRD07237KL', 'C852654', 'LCSC 7,520 (21 Sep 2026)', False),
    (r'RT0402BRD07(866K|953K|330K|1M|487K|750K|300K|698K)L', '-', 'NOT ORDERABLE: outside the RT0402 +/-0.1 % 25 ppm range (4.7 R-240 k, YAGEO RT datasheet v17 Table 2) - protection re-scaled/moved to 0603 (R9)', True),
    (r'RT0603BRD071ML', 'C326730', 'LCSC 1,200 (25 Sep 2026), JLCPCB Extended; 10/board -> 50 + attrition', False),
    (r'RT0603BRD07487KL', 'C861426', 'LCSC 1,840 (25 Sep 2026), JLCPCB Extended; 12/board -> 60 + attrition', False),
    (r'RT0603BRD07300KL', 'C705762', 'LCSC 65,780 (May) / 84,200 (Sep 2026 alternatives list), JLCPCB Extended', False),
    (r'RT0402BRD0744K2L', 'C705633', 'LCSC ~19,650 (LCSC alternatives list 18 Sep 2026; product page not retrievable 25 Sep), JLCPCB Extended; DigiKey 27,744', False),
    (r'RT0402BRD07200KL', 'C728556', 'LCSC OUT OF STOCK (page 25 Sep 2026, min/multiple 50) -> global sourcing (DigiKey 171,161)', True),
    (r'RT0402BRD0733K2L', 'C852727', 'LCSC OUT OF STOCK (page 25 Sep 2026) -> global sourcing (DigiKey 57,332; Mouser 41,728); LCSC-stocked option UNI-ROYAL TC0225B3322TCC C50670386 (8,750, 0.1 %/25 ppm, 25 V) - protection decision', True),
    (r'RT0402BRD07187KL', 'C852576', 'LCSC OUT OF STOCK (page 25 Sep 2026) -> global sourcing (DigiKey 25,219; Mouser 6,278)', True),
    (r'0402WGF2205TCE', 'C407703', 'LCSC out of stock (Jun 2026) -> global sourcing / YAGEO RC0402FR-0722ML', True),
    (r'0402CG820J500NT', 'C45501', 'LCSC 238,500 / JLCPCB 227,977 (Sep 2026)', False),
    (r'CL21A225KAFNNNE', 'C87994', 'LCSC C87994 page not retrievable (25 Sep 2026); DigiKey 80,862 -> confirm at order (E-16 C102)', True),
    (r'1RC0402F2204', 'C54530777', 'JLCPCB 9,900 (25 Sep 2026)', False),
    (r'1RC0402F4704', 'C54530892', 'LCSC 4,600 (25 Sep 2026)', False),
]
STD_PEAK_MAX = 245    # 240 + 5
ECON_PEAK_MAX = 260   # 255 + 5
STD_PITCH_MIN = 0.35


def stock_is_low(txt):
    t = txt.lower()
    if any(k in t for k in ('out of stock', 'oos', 'n/a', 'not normally', 'non-stocked', 'reserve', 'low', 'buy ')):
        return True
    m = re.search(r'(lcsc|jlcpcb)\s*([\d,.]+)\s*(m|k)?\b', t)
    if m:
        n = float(m.group(2).replace(',', ''))
        n *= {'m': 1e6, 'k': 1e3}.get(m.group(3) or '', 1)
        return n < 500
    return False


rows = []
for s in STREAMS:
    f = os.path.join(BASE, s, 'bom_rows.csv')
    if not os.path.exists(f):
        continue
    mt = datetime.datetime.fromtimestamp(os.path.getmtime(f), datetime.timezone.utc).strftime('%d %b %H:%M UTC')
    for r in csv.DictReader(open(f, encoding='utf-8-sig')):
        r = dict(r)
        r['stream'] = s
        r['bom_date'] = mt
        rows.append(r)
n_bom = len(rows)
bom_mpns = ' | '.join(r.get('mpn', '') for r in rows)
for d in DECISIONS:           # add a decision line only if no stream BOM carries that MPN yet
    key = d['mpn'].split('(')[0].split()[-1] if 'Toshiba' in d['mpn'] else d['mpn'].split()[-1].split('(')[0]
    if key and key in bom_mpns:
        continue
    d = dict(d)
    d['bom_date'] = 'decision'
    rows.append(d)

out = []
for r in rows:
    mpn = r.get('mpn', '') or ''
    refs = r.get('refs', '') or ''
    fact = next((f for f in FACTS if re.search(f[0], mpn)), None)
    flags = []
    lcsc = (r.get('lcsc', '') or '').strip()
    src_txt = r.get('jlcpcb_stock_or_sourcing', '') or ''
    cls = r.get('jlcpcb_class', '') or ''
    pad_like = any(k in mpn.lower() for k in ('pads', 'header', 'pcb pad'))
    if not pad_like and ('global' in (cls + src_txt).lower() or lcsc.lower() in ('', '-', 'none', 'n/a')
                         or 'not available' in lcsc.lower()):
        flags.append('GLOBAL')
    found = next((x for x in LCSC_FOUND if re.search(x[0], mpn)), None)
    if found and (lcsc.lower() in ('', '-', 'none') or lcsc.lower().startswith('n/a') or 'to confirm' in lcsc.lower() or 'not verified' in src_txt.lower()):
        lcsc = found[1] + ' (parts)'
        src_txt = (src_txt + ' | parts: ' + found[2]).strip(' |')
        if not found[3]:
            flags = [f for f in flags if f != 'GLOBAL']
        elif 'GLOBAL' not in flags:
            flags.append('GLOBAL')
    if stock_is_low(src_txt) and 'GLOBAL' not in flags and not pad_like and not found:
        flags.append('LOW')
    if 'standard only' in cls.lower():
        flags.append('STD-ONLY')
    try:
        tht = int(float(r.get('tht_pins_per_part') or '0'))
    except ValueError:
        tht = 0
    if tht > 0:
        flags.append('THT')
    if (r.get('leadless') or '').lower().startswith('y'):
        flags.append('LEADLESS')
    if r['stream'] != 'decision':
        for rx, why in STALE:
            if re.search(rx, mpn + ' ' + refs):
                flags.append('STALE')
                r['note'] = (r.get('note', '') + ' | STALE: ' + why).strip(' |')
                break
    reflow_txt, econ_ok, std_ok, pitch, msl, fsrc, lead = '', 'yes', 'yes', '', '', '', ''
    if fact:
        _, reflow_txt, peak, timed, p, msl, fsrc, lead = fact
        if peak is not None:
            if peak < ECON_PEAK_MAX or (peak <= ECON_PEAK_MAX and timed):
                flags.append('REFLOW')
                econ_ok = 'NO' if peak < 255 else 'AT LIMIT'
            std_ok = 'yes' if peak >= STD_PEAK_MAX else 'NO'
            if timed and peak <= 255 and std_ok == 'yes':
                std_ok = 'yes (confirm dwell)'
        if p is not None:
            pitch = str(p)
            if p <= 0.4:
                flags.append('PITCH')
                econ_ok = 'AT LIMIT (0.4 mm)' if econ_ok == 'yes' else econ_ok
                if p < STD_PITCH_MIN:
                    std_ok = 'NO'
        if msl and msl[0] in '23':
            flags.append('MSL>=2')
        lt = lead.lower()
        if any(k in lt for k in ('wk', 'due', 'moq', 'eol', 'not procurable')) and any(
                k in (lt + src_txt.lower()) for k in ('0 (due', 'lcsc 16', 'lcsc 61', 'not stocked', 'non-stocked', 'moq', 'eol', 'factory')):
            flags.append('LONG-LEAD')
        if 'no small-qty source' in lt or 'not procurable' in lt or lt == 'eol':
            flags.append('NO-SOURCE')
    if pad_like:
        flags = [f for f in flags if f in ('THT',)]
    # R9 E-14: order multiple. JLCPCB-placed lines are bought per piece by JLCPCB (+ its attrition); owner lines bought
    # directly at LCSC must respect the LCSC minimum/multiple shown on the part page.
    mm = re.search(r'min(?:imum)?\s*/\s*multiple\s*(\d+)|minimum:?\s*(\d+)', src_txt, re.I)
    lcsc_mult = int(next(g for g in mm.groups() if g)) if mm else 1
    _otxt = (src_txt + ' ' + (r.get('note', '') or '') + ' ' + cls).lower()
    owner_line = 'owner' in _otxt and not re.search(r'owner[- ]fit\w*[^.;|]{0,20}fallback|fallback[^.;|]{0,40}owner|or owner-fitted|else owner-fitted', _otxt)   # R9 check: an owner-fit FALLBACK is still a JLCPCB-placed line
    try:
        need5 = 5 * int(float(r.get('qty') or 0))
    except ValueError:
        need5 = 0
    if owner_line and 'digikey' in (src_txt + ' ' + cls).lower() and 'owner purchase: lcsc' not in src_txt.lower():
        src_is_lcsc = False
    else:
        src_is_lcsc = 'lcsc' in src_txt.lower()
    if owner_line and src_is_lcsc and lcsc_mult > 1 and need5 % lcsc_mult:
        flags.append('MOQ')
    order_rule = (f'owner buys at LCSC in multiples of {lcsc_mult}' if owner_line and src_is_lcsc
                  else ('owner purchase (DigiKey)' if owner_line else 'JLCPCB buys per piece + attrition' + (f' (LCSC direct would be min/multiple {lcsc_mult})' if lcsc_mult > 1 else '')))
    out.append(dict(stream=r['stream'], bom_date=r.get('bom_date', ''), refs=refs, qty=r.get('qty', ''), mpn=mpn, lcsc=lcsc, order_rule=order_rule,
                    package=r.get('package', ''), jlcpcb_class=cls, stock_or_sourcing=src_txt, flags=' '.join(dict.fromkeys(flags)),
                    reflow_limit=reflow_txt, pitch_mm=pitch, msl=msl, standard_ok=std_ok, economic_ok=econ_ok, lead_or_source=lead,
                    src=fsrc, note=r.get('note', '')))

cols = ['stream', 'bom_date', 'refs', 'qty', 'mpn', 'lcsc', 'order_rule', 'package', 'jlcpcb_class', 'stock_or_sourcing', 'flags', 'reflow_limit',
        'pitch_mm', 'msl', 'standard_ok', 'economic_ok', 'lead_or_source', 'src', 'note']
with open(os.path.join(BASE, 'parts', 'pcba_class_table.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    for o in out:
        w.writerow(o)

lines = [f'PCBA class / ordering scan, {TODAY}. Class decided: JLCPCB Standard PCBA, top side only (D-14).',
         f'{len(out)} lines scanned ({n_bom} from stream BOMs + {len(out) - n_bom} decision lines not yet in a stream BOM).',
         'Stream BOM file dates: ' + ', '.join(sorted({f"{o['stream']} {o['bom_date']}" for o in out if o['stream'] != 'decision'}))]
for flag in ['STD-ONLY', 'NO-SOURCE', 'STALE', 'MOQ', 'REFLOW', 'PITCH', 'THT', 'GLOBAL', 'LONG-LEAD', 'LOW', 'MSL>=2', 'LEADLESS']:
    hit = [o for o in out if flag in o['flags'].split()]
    lines.append(f'\n[{flag}] {len(hit)}')
    for o in hit:
        lines.append(f"  {o['stream']:<10} {o['refs'][:28]:<28} {o['mpn'][:40]:<40} std={o['standard_ok']:<20} {(o['lead_or_source'] or o['reflow_limit'])[:60]}")
bad_std = [o for o in out if o['standard_ok'].startswith('NO')]
lines.append(f'\nStandard PCBA blockers (peak < 245 C or pitch < 0.35 mm): {len(bad_std)}')
for o in bad_std:
    lines.append(f"  {o['stream']} {o['refs']} {o['mpn']} ({o['reflow_limit']})")

# Ordering plan (5 boards; buy = 5 x per-board + spares for bring-up/rework; "now" = order before layout release)
ORDER_PLAN = [
    # (refs, part, per board, buy, when, source, reason)
    ('U403, U404', 'TI OPA2210IDR', 2, 12, 'NOW', 'LCSC C1849415 (16 in stock) into the JLCPCB library (D-8: 12; taking all 16 adds spares); backup TI.com store (OPA2210IDR / OPA2210ID tube)',
     'DigiKey 0 until 14 Dec 2026, Mouser 0 until 23 Nov 2026; no electrical fallback'),
    ('X201', 'Kyocera KC2520K80.0000C1GE00', 1, 20, 'NOW', 'JLCPCB global sourcing (DigiKey 478-KC2520K80.0000C1GE00CT-ND / Mouser 581-KC2520K80.0C1GE)',
     'D-3 revised; LCSC not available; 32-week factory lead if distributor stock goes; replaces EOL Epson SG-210STF 75 MHz'),
    ('X201 2nd source', 'NDK NSC5338D-80M', 0, 5, 'NOW (optional)', 'DigiKey 644-NSC5338D-80MCT-ND (consign or global sourcing)', 'conditional second source per D-3 revised (budget 12.7 mA; bring-up checks of disable time and edges); no R509 change if fitted - R509 stays 4.75 k, S3 497.92 mA with the NDK (decisions_r9 E-27)'),
    ('X202, X203', 'NDK NZ2520SDA 49.152 MHz / 45.1584 MHz NSC5083D', 1, 10, 'NOW', 'JLCPCB global sourcing (DigiKey 3,438 / 3,166)', '24-week factory lead; no LCSC stock'),
    ('K601-K604', 'Toshiba TLP3545A(TP1,F)', 4, 25, 'NOW', 'JLCPCB global sourcing (DigiKey 264-TLP3545A (TP1FCT-ND, 28,529)', 'not in the JLCPCB library; 24-week factory lead'),
    ('U601-U603, U606', 'TI TLV1704AIPWR', 4, 25, 'NOW', 'LCSC C181596 (61 on 24 Sep 2026) into the JLCPCB library, else JLCPCB global sourcing (DigiKey 296-38432-1-ND, 6,948)', 'U606 (X-6) adds a 4th per board; LCSC 61 (re-read 25 Sep 2026 17:1x) also covers 6/board = 30 + attrition if protection R9 E-3 adds 2 x TLV1704 - reserve now'),
    ('J101', 'GCT USB4105-GF-A', 1, 10, 'NOW', 'JLCPCB global sourcing (DigiKey 2073-USB4105-GF-ACT-ND, 127,933)', 'LCSC out of stock (14 Sep 2026)'),
    ('J701', 'G-Switch GT-3321667P-01', 1, 8, 'NOW', 'LCSC C2762984 (724) into the JLCPCB library', 'JLCPCB 21 only; THT (hand/wave by JLCPCB)'),
    ('U301', 'ESS ES9018K2M', 1, 8, 'NOW', 'LCSC C2688377 (724) into the JLCPCB library', 'single source, thin stock'),
    ('U201', 'WCH CH32V307RCT6', 1, 8, 'NOW', 'JLCPCB library (364) / LCSC 193', 'thin stock, MSL 3'),
    ('U202', 'AGM AGRV2KQ32', 1, 8, 'NOW', 'LCSC C18208899 (980)', 'thin stock; marking = AG32VF303K.U6 (P-L1)'),
    ('R401-R416, R438-R445', 'Susumu RG1608N-132-W-T1 / -681-W-T1 / -202-W-T1 (0.05 %, 10 ppm; analog round 2)', 24, 180, 'NOW',
     'JLCPCB global sourcing: DigiKey 1.30 k 157 (+ Panasonic ERA-3ARW132V 661), 680 R 783, 2.00 k 16,746 (+ ERA-3ARW202V 1,259)',
     'buy 60 of each value (analog: >= 48 each); 1.30 k stock is thin; LCSC 0.1 % fallbacks C705738 / C861519 / C728588 on the same footprints'),
    ('R607, R608, R628-R631, R639, R663', 'YAGEO RT0402BRD07121KL C852503 / 115KL C852488 / 5K1L C852856 (0.1 %)', 8, 60, 'at PCBA order', 'JLCPCB global sourcing (DigiKey 25,651 / 19,542 / 25,165)', 'LCSC pages 25 Sep 2026: all three OUT OF STOCK (min/multiple 50); R9 proposal to protection: 5.1 k -> YAGEO AT0402BRD075K1L C851064 (0.1 %, 25 ppm, 50 V, AEC-Q200; LCSC 6,850, min 10) = same-or-better drop-in, removes the 5.1 k global line'),
    ('R672, R675, R682', 'YAGEO RT0402BRD07237KL C852654 (0.1 %)', 3, 20, 'at PCBA order', 'LCSC C852654: 7,520 in stock (25 Sep 2026, min/multiple 20) -> JLCPCB library, NOT global', 'integration costed it as global-sourced'),
    ('R503', 'YAGEO RT0603BRD07205KL', 1, 20, 'NOW', 'LCSC C861217 (900)', 'thin LCSC stock'),
    ('R534', 'YAGEO RT0603BRD0711KL', 1, 20, 'at PCBA order', 'LCSC C728581 (2,260)', 'thin-ish LCSC stock'),
    ('R509', 'Susumu RG1608P-4751-B-T5 (4.75 k 0.1 % 25 ppm)', 1, 20, 'at PCBA order', 'JLCPCB global sourcing (DigiKey RG16P4.75KBCT-ND, 114,162)', 'no LCSC line; power BOM 05:53 (4.64 k only with the withdrawn Epson budget)'),
    ('R423-R426', 'YAGEO RT0603BRD07698RL', 4, 30, 'NOW', 'LCSC C861525 (120) or global sourcing', 'thin LCSC stock; VALUE-LOCKED: Rf, VREF divider R431/R432 and the leg resistors set protection p04 CM band - substitute only same value, <= 0.1 %/25 ppm, and tell protection'),
    ('C417-C420', 'KEMET C0603C821J5GACTU (alt. Murata GRM1885C1H821JA01D)', 4, 30, 'at PCBA order', 'LCSC C2169093 (880)', 'thin LCSC stock'),
    ('C431-C438', 'Murata GRM1885C1H182JA01D', 8, 50, 'at PCBA order', 'LCSC C97878 (750-1,900)', 'thin LCSC stock'),
    ('R641, R642', 'Vishay PATT0402E24R9BGT1 (24.9 R 0.1 % 25 ppm)', 2, 20, 'NOW', 'JLCPCB global sourcing (DigiKey 764-1167-1-ND, 3,285 on a Feb 2026 page)', 'no LCSC source; 15-week factory lead; a 1 % part also meets D-1 (protection)'),
    ('U604', 'TI OPA2333AIDR', 1, 10, 'at PCBA order', 'LCSC/JLCPCB C38732 (5,082)', 'stocked'),
    ('U503, U505, U303, U103', 'TPS259621DDAR / TMUX1101DBVR / TLV75801PDBVR / TPD2E2U06DRLR', 1, 10, 'at PCBA order', 'JLCPCB library (656 / DigiKey / 113,390 / 4,257)', 'stocked'),
    # R8 round 3 (decisions_r8c) additions
    ('U208 (X-7)', 'Nexperia 74LVC3G34DC,125', 1, 10, 'NOW', 'LCSC C548774 (1,604) into the JLCPCB library', 'DigiKey 0 (3,000 due 21 Sep 2026), Mouser 0 (Feb 2027)'),
    ('D102 (X-3)', 'Littelfuse SMDJ12A', 1, 10, 'NOW', 'JLCPCB C224063 if stock remains (115 on the Sep 2025 page), else global sourcing (DigiKey SMDJ12ACT-ND, 5,498)', 'LCSC 0; 34-week factory lead; LGE C5806873 not approved'),
    ('C442, C443 (X-8, R3.12)', 'KEMET T495D227K010ATE100 (220 uF 10 V MnO2 surge robust); alt. AVX TPSD227K010R0100', 2, 15, 'NOW', 'JLCPCB global sourcing: DigiKey 399-10383-1-ND (3,860) or AVX 478-3322-1-ND (1,534); LCSC C212677 out of stock', '24-week (KEMET) / 13-week (AVX) factory lead; MSL 1; polarity gate G-4; replaces the T520D polymer'),
    ('D411, D412 (X-8)', 'Nexperia PMEG2010AEH,115', 2, 15, 'NOW', 'LCSC C110921 (11,165, Jun 2026) pre-ordered into the JLCPCB library (JLCPCB own stock 0)', 'not the JSMSEMI "-JSM" SOD-123 part'),
    ('U605 (X-6)', 'TI TLV3402IDR (SOIC-8)', 1, 10, 'NOW', 'LCSC C91242 (745, 25 Sep 2026) into the JLCPCB library', 'TI part page: "for new designs, we recommend considering an alternate" -> lifetime buy for this build; protection may evaluate TI TLV7042 (dual nanopower open-drain)'),
    ('U607 (X-6)', 'Nexperia 74AUP1G17GW,125', 1, 10, 'NOW', 'JLCPCB global sourcing (DigiKey 1727-3188-1-ND, 66,948)', 'LCSC C545626 out of stock (25 Sep 2026)'),
    ('D609, D610 (X-6)', 'Nexperia BAS70-04,215 (D610 moved to BAS70-04, protection VE)', 2, 20, 'at PCBA order', 'LCSC/JLCPCB C389351 (36,430)', 'stocked'),
    ('R678, R685, R901-R915 odd (0603)', 'YAGEO RT0603BRD071ML 1.00 M 0.1 % 25 ppm 75 V (protection R9 resolution)', 10, 50, 'at PCBA order', 'LCSC C326730 (1,200) into the JLCPCB library', 'was RT0402BRD071ML (not orderable); 50 + attrition of 1,200 - thin-ish, order early'),
    ('R900-R914 even (0603)', 'YAGEO RT0603BRD07487KL 487 k 0.1 % 25 ppm 75 V', 8, 40, 'at PCBA order', 'LCSC C861426 (1,840) into the JLCPCB library', 'R9 check: R920-R923 moved to 110 k 0402 (line below)'),
    ('R920-R923 (0402, R9 check E-24)', 'YAGEO RT0402BRD07110KL 110 k 0.1 % 25 ppm (R_T)', 4, 20, 'at PCBA order', 'LCSC C705063 (8,000; DigiKey 17,115)', 'protection BOM 19:14'),
    ('R677, R684 (0603)', 'YAGEO RT0603BRD07300KL 300 k 0.1 % 25 ppm 75 V', 2, 10, 'at PCBA order', 'LCSC C705762 (65,780+)', 'was RT0402BRD07330KL (not orderable)'),
    ('R675, R682 (0402)', 'YAGEO RT0402BRD0744K2L 44.2 k 0.1 % 25 ppm', 2, 10, 'at PCBA order', 'LCSC C705633 (~19,650, alternatives list 18 Sep 2026)', 're-scaled by protection (R9)'),
    ('R676, R683 (0402)', 'YAGEO RT0402BRD07200KL 200 k 0.1 % 25 ppm', 2, 10, 'at PCBA order', 'JLCPCB global sourcing (DigiKey YAG4202CT-ND 171,161); LCSC C728556 out of stock', 're-scaled by protection (R9; was 953 k)'),
    ('R924 (0402, R9 check E-24)', 'YAGEO RT0402BRD0769K8L 69.8 k 0.1 % 25 ppm (V_T divider top)', 1, 5, 'NOW', 'JLCPCB global sourcing: LCSC C852893 (stock only on a 2024 page), DigiKey US 0 until Feb 2027, DigiKey SG 6,577', 'same-spec alternate Vishay TNPW040269K8BEED (0402, 0.1 %, 25 ppm; DigiKey 72,019) if JLCPCB cannot source the YAGEO part - protection to approve; the 33.2 k/TC0225B3322TCC plan is superseded'),
    ('R925 (0402, R9 check E-24)', 'YAGEO RT0402BRD07100KL 100 k 0.1 % 25 ppm (joins the R653 line)', 1, 5, 'at PCBA order', 'LCSC C852472 (742,100)', 'was 187 k (superseded)'),
    # R9 (E-2/E-3/E-16/E-18/E-21) additions
    ('C631-C634 (E-3, R9 check E-24)', 'Panasonic ECH-U1H224GX9 (220 nF +/-2 % 50 V PPS film, 2416)', 4, 20, 'NOW', 'JLCPCB global sourcing (Mouser 667-ECH-U1H224GX9 19,207; DigiKey PCF1556CT-ND 62); not at LCSC', 'replaces ECH-U1H223GX5 22 nF 1210; ECHU series reflow text 260 C / <= 95 s above 220 C (not confirmed for 2416) -> order remark; owner-fit fallback (2416)'),
    ('U609, U610 (E-3)', 'TI TLV1704AIPWR', 2, 0, 'NOW', 'same LCSC C181596 reserve as U601-U603/U606 (6/board total)', 'counted in the U601 line quantity when protection BOM is final'),
    ('Q623-Q626 (E-3, R9 check E-24)', 'JSCJ MMBT3904 NPN timer reset switches (joins the Q612/Q614/Q507 line)', 4, 20, 'at PCBA order', 'JLCPCB Basic C20526', 'D611/D612 BAS70-05 DELETED (R9-CHK-01) - nothing to buy; R916-R919 now 330 k 1 % C25778 (Extended; LCSC 72,700 per the 25 Sep alternatives list; drop-in RC0402FR-07330KL C138006 355,200); R696 100 k joins C25741'),
    ('U608 (E-2)', 'Nexperia 74LVC1G74DC,125', 1, 10, 'at PCBA order', 'LCSC C503431 (4,620, min 5)', 'stocked'),
    ('U502 (E-16)', 'TI TPS70933DBVR', 1, 10, 'at PCBA order', 'LCSC C89347 (5,280), JLCPCB Extended', 'stocked; same DBV land'),
    ('R679, R686', 'UNI-ROYAL 0402WGF2205TCE (22 M 1 %)', 2, 20, 'NOW', 'global sourcing, or YAGEO RC0402FR-0722ML (confirm with protection)', 'LCSC C407703 out of stock (Jun 2026)'),
    ('D103-D105 (X-4)', 'Nexperia BAT54,215', 3, 20, 'at PCBA order', 'JLCPCB C85084 (202,689)', 'stocked'),
    ('R535, R536 (X-5)', 'UNI-ROYAL 0402WGF1003TCE 100 k / 0402WGF4702TCE 47 k (power VE)', 1, 10, 'at PCBA order', 'JLCPCB Basic C25741 / C25792', 'Basic, same types as R105/R106; was 68.1 k/30.1 k Extended'),
    ('R417-R420 alt.', 'Murata BLM15PX330SN1D', 0, 0, 'not now', 'LCSC C160974 (22,900, Mar 2026) if the bead is chosen; DigiKey 0 until 2 Oct 2026', 'approved alternate only; default fit 0 ohm C17168'),
]
# VE (owner decision O-1, 25 Sep 2026): exact 5-board quantity + JLCPCB attrition, no spares; owner-fitted lines bought by the owner
OWNER_REFS = ('K601', 'J701', 'D102', 'R509')  # owner-fitted per the stream BOMs (VE)
VE_LINE = {   # refs prefix -> (part, when, source) after the streams' VE adoptions (BOMs 25 Sep 11:0x)
    'U403': ('TI OPA2210IDR', 'NOW', 'LCSC C1849415 (16): buy 10 + attrition into the JLCPCB library'),
    'R401': ('YAGEO RT0603BRD071K3L C705738 / RT0603BRD07680RL C861519 (0.1 %) + Susumu RG1608N-202-W-T1 (0.05 %/10 ppm) for R2/R4 (analog R9 E-4 mixed network)', 'NOW', 'LCSC 100 / 8,000; Susumu 2.00 k via JLCPCB global sourcing (DigiKey 16,746, 25 Sep 2026; alt. ERA-3ARW202V 1,259); pre-order the 1.30 k (thin)'),
    'R641': ('YAGEO RT0402BRD0724R9L C852667 (protection VE)', 'at PCBA order', 'LCSC 19,000'),
    'R509': ('KOA RN73R1JTTD4751B25 4.75 k 0.1 % 25 ppm (power E-18, R9; was 4.81 k)', 'NOW (owner)', 'DigiKey/Mouser listings (stock not read 25 Sep 2026); alt. Susumu RG1608P-4751-B-T5 DigiKey 114,162'),
    'C442': ('Kyocera AVX TAJD227K010RNJ C8024 (analog VE)', 'at PCBA order', 'LCSC 44,987'),
    'U208': ('TI SN74LVC3G34DCUR C130024 (digital VE)', 'NOW', 'LCSC 550'),
    'D102': ('Littelfuse SMDJ12A (power VE: owner-bought)', 'NOW (owner)', 'DigiKey 5,498, US$ 1.01 at 10+'),
}
_vp = []
for refs_, part, per, buy, when, source, why in ORDER_PLAN:
    if refs_.startswith('X201 2nd'):
        continue                       # O-1: a conditional second source is a spare -> not bought
    k = next((k for k in VE_LINE if refs_.startswith(k)), None)
    if k:
        part, when, source = VE_LINE[k]
    if per:
        newbuy = 5 * per
        why = f"{why}; VE O-1: {newbuy} + JLCPCB attrition (was {buy} with spares)"
        buy = newbuy
    if refs_.startswith(OWNER_REFS):
        source = 'OWNER purchase (DNP at JLCPCB, layout_package.md 13a): ' + source
    _vp.append((refs_, part, per, buy, when, source, why))
ORDER_PLAN = _vp
ORDER_PLAN.append(('gate samples (O-1)', 'two of each part type named in G-1...G-4, EXCEPT TLP3545A / SMDJ12A / J701 (the owner-fitted parts double as samples)', 0, 0,
                   'NOW (owner)', 'split: DigiKey order US$ 100.60 (owner-fitted TLP3545A 20, SMDJ12A 5, KOA 5 + samples USB4105, KC2520K80, NZ2520SDA x2, 74AUP1G17, TPS2596, TLV1704) / LCSC order US$ 45.97 (J701 5 + 14 sample types)',
                   'layout_package.md 13a table; DigiKey free delivery >= US$ 50 applies; LCSC shipping ~US$ 10 [ASSUMP], LCSC order stays under NT$ 2,000'))
lines.append('\nOrdering plan (5 boards):')
lines.append(f"  {'refs':<28} {'part':<52} {'/board':>6} {'buy':>4}  {'when':<20} source / reason")
for refs_, part, per, buy, when, source, why in ORDER_PLAN:
    lines.append(f"  {refs_:<28} {part[:52]:<52} {per:>6} {buy:>4}  {when:<20} {source}; {why}")
open(os.path.join(BASE, 'parts', 'pcba_class_scan_out.txt'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
