"""Parts stream, R8 / v0.9: bottom-up component stress check at the real operating conditions.

Writes stress_table.csv (refs, mpn, lcsc, package, pinout_source, parameter, rating,
worst_operating_value, margin, verdict, source_url, note) and stress_calc_out.txt.

Labels used in the table: [DS] datasheet min/max, [DS-typ] typical only, [CALC] computed
here, [ASSUMP] assumption, [MEAS] must be measured (fallback named in the note).
Verdicts: OK; THIN (inside the rating but < 20 % / < 0.3 V margin, or rests on an assumption);
FAIL (outside a rating in a permitted operating state); REPLACE (part is replaced/deleted in
v0.9 by the brief - the check shows why); DATA-GAP (the datasheet does not give the limit);
AVAIL (availability risk).
"""
import csv, math

# ------------------------------------------------------------------ operating conditions
TA = 50.0                 # [brief] max ambient, degC
VBUS_MAX, VBUS_MIN = 5.50, 4.40   # [brief] at the receptacle
V33_MAX = 3.3*1.02        # [DS] ME6211 / LP5907 +/-2 % -> 3.366 V
V33_MIN = 3.3*0.98
V13_MAX, V13_MIN = 1.3*1.01, 1.3*0.99   # [DS] ME6216 +/-1 %
VPOS_MAX, VPOS_MIN = 4.014, 3.789       # [brief] (3.90 V option)
VNEG_MAX, VNEG_MIN = 3.828, 3.618       # magnitude
VSUP_AN = VPOS_MAX + VNEG_MAX           # op-amp / comparator total supply
OVP_TRIP_MAX = 5.70       # [ASSUMP] placeholder for the new OVP eFuse maximum trip (power stream owns)

# ------------------------------------------------------------------ MLCC effective capacitance model
# Conservative derating factors [ASSUMP] (Samsung publishes DC-bias curves only as graphs on
# product.samsungsem.com; values below are deliberately below the typical curves of these
# case-size / rated-voltage classes):
TEMP_F = 0.95   # X5R/X7R 0..50 degC (spec +/-15 % over -55..85; typical <= -5 % at 50 degC)
AGE_F = 0.95    # class-II ageing over the product life (~-2.5 %/decade-hour, 2 decades)
BIAS = {
    'CL10A105KB8NNNC': {1.3: 0.97, 3.4: 0.92, 4.0: 0.91, 5.5: 0.88, 5.8: 0.87},   # 1 uF 50 V 0603 X5R
    'CL05A225MQ5NSNC': {1.3: 0.80, 1.6: 0.72, 2.9: 0.50, 3.4: 0.45},             # 2.2 uF 6.3 V 0402 X5R
    'CL21A106KAYNNNE': {3.4: 0.70, 4.0: 0.65, 5.5: 0.55, 5.8: 0.53},             # 10 uF 25 V 0805 X5R
    'CL05B104KO5NNNC': {3.4: 0.90, 4.0: 0.87, 5.5: 0.80},                        # 100 nF 16 V 0402 X7R
    'CL10A225KO8NNNC': {3.4: 0.80, 5.5: 0.70},                                   # 2.2 uF 16 V 0603 X5R (proposed)
}
def ceff(mpn, cnom, tol, v):
    tab = BIAS[mpn]
    k = min((kk for kk in tab if kk >= v - 1e-9), default=max(tab))
    return cnom*(1 - tol)*tab[k]*TEMP_F*AGE_F, tab[k]

def tj(p, rth, ta=TA):
    return ta + p*rth

rows = []
def row(refs, mpn, lcsc, pkg, pin_src, param, rating, worst, margin, verdict, url, note='', status='current'):
    rows.append(dict(refs=refs, mpn=mpn, lcsc=lcsc, package=pkg, pinout_source=pin_src, parameter=param,
                     rating=rating, worst_operating_value=worst, margin=margin, verdict=verdict,
                     source_url=url, note=note, status=status))

def pct(a, b):
    return f'{100*(a-b)/a:.0f} %'

U = dict(
    lp5907='https://www.ti.com/lit/ds/symlink/lp5907.pdf',
    tps2553='https://www.ti.com/lit/ds/symlink/tps2553.pdf',
    lm27762='https://www.ti.com/lit/ds/symlink/lm27762.pdf',
    opa2210='https://www.ti.com/lit/ds/symlink/opa2210.pdf',
    opa1622='https://www.ti.com/lit/ds/symlink/opa1622.pdf',
    lm339='https://www.ti.com/lit/ds/symlink/lm339.pdf',
    es9018='ES9018K2M datasheet v3.7 (ESS, 22 Apr 2021; project copy working/v11/current/ES9018K2M_datasheet_v3.7.txt)',
    ch32='https://github.com/ch32-riscv-ug/ch32-device-data-preview/blob/main/CH32V20x_30xDS0.en/pages/0058.md',
    ch32_jlc='https://jlcpcb.com/partdetail/WCH_Jiangsu_Qin_Heng-CH32V307RCT6/C2988083',
    agrv='https://www.agm-micro.com/upload/userfiles/files/AGRV2K_Rev_3_0.pdf',
    usblc6='https://www.st.com/resource/en/datasheet/usblc6-2.pdf',
    me6211='https://stm32-base.org/assets/pdf/regulators/ME6211.pdf',
    me6216='https://www.lcsc.com/product-detail/C236662.html',
    uniroyal='https://www.uni-royal.cn/en/images/userfile/file/1668661899c56505e6d9ab55c7.pdf',
    rt0603='https://www.lcsc.com/product-detail/C728588.html',
    era3a='https://www.lcsc.com/product-detail/C193242.html',
    cl05a225='https://product.samsungsem.com/mlcc/CL05A225MQ5NSN.do',
    samsung='https://product.samsungsem.com/mlcc/ (MPN code: size/dielectric/value/tolerance/voltage)',
    usbc='https://www.lcsc.com/product-detail/C2765186.html',
    j701='https://www.lcsc.com/product-detail/C2762984.html',
    j702='https://www.lcsc.com/product-detail/C2848643.html',
    bat54s='https://jlcpcb.com/partdetail/BAT54S/C916425 ; pin-out convention https://www.diodes.com/datasheet/download/BAT54S.pdf',
    lesd='https://www.lcsc.com/product-detail/C41399463.html',
    n7002='https://www.lcsc.com/product-detail/C8545.html',
    y201='https://www.lcsc.com/product-detail/C115962.html',
    x201='https://www.lcsc.com/product-detail/C5179978.html',
    x202n='https://www.lcsc.com/product-detail/C2901591.html',
    x203n='https://www.lcsc.com/product-detail/C2901589.html',
    fb501='https://www.lcsc.com/product-detail/C14709.html',
    fb202='https://www.lcsc.com/product-detail/C1002.html (values from working/v05/parts_research.md A15; page not re-fetched)',
    ledg='https://jlcpcb.com/partdetail/C2297', ledr='https://jlcpcb.com/partdetail/C2286',
    tq2sa='https://jlcpcb.com/partdetail/PANASONIC-TQ2SA5V/C2858038',
    g6k='https://jlcpcb.com/partdetail/G6K-2F-Y-DC5/C326376',
    opa2210_stock='https://www.digikey.com/en/products/detail/texas-instruments/OPA2210IDR/10715389 ; https://www.lcsc.com/product-detail/C1849415.html',
)
R0402 = 'UNI-ROYAL 0402WGF'  # family
PR0402 = 0.0625   # [DS] 1/16 W to 70 degC (UNI-ROYAL SMD-SP-001 table 7/8)
VR0402 = 50.0     # [DS] max working voltage

# ================================================================== BLOCK 1: USB-C input
row('J101', 'SHOU HAN TYPE-C 16PIN 2MD(073)', 'C2765186', 'USB-C 16P SMD R/A', 'maker drawing (image) - continuity test required (R8-A10)',
    'VBUS voltage rating', '5 V [DS listing]', f'{VBUS_MAX:.2f} V steady (vSafe5V max), hot-plug ring higher', '-0.50 V', 'FAIL',
    U['usbc'], 'Listed rating 5 V is below vSafe5V max 5.5 V; use a receptacle with a documented >= 20 V rating (USB-C connectors are normally 20 V / 5 A) - see report P-M4')
row('J101', 'SHOU HAN TYPE-C 16PIN 2MD(073)', 'C2765186', 'USB-C 16P SMD R/A', 'maker drawing (image)',
    'VBUS current', '5 A [DS listing] (3 A on JLCPCB page)', '<= 0.80 A [CALC] High mode 0.262 A digital + 0.498 A TPS2553 max + 0.031 A relay coil',
    '>= 2.2 A', 'OK', U['usbc'], 'Operating temperature -25...+85 degC [DS listing] vs 50 degC ambient: OK')
for refs, r, vmax, note in [('R101, R102', 5.1e3, VBUS_MAX, 'CC pull-down Rd; fault case CC shorted to VBUS'),
                            ('R103, R104', 10e3, VBUS_MAX - 3.6, 'CC -> ADC series; fault CC at VBUS, ADC pin clamped at VDD+0.3'),
                            ('R105+R106', 147e3, VBUS_MAX*1.0, 'VBUS divider (power stream may re-value); whole divider'),
                            ('R505', 10e3, VBUS_MAX, 'PGOOD pull-up to 5V_ANA while PGOOD pulls low')]:
    p = vmax**2/r
    row(refs, R0402 + ' (1 %)', {'R101, R102': 'C25905', 'R103, R104': 'C25744', 'R105+R106': 'C25741/C25792', 'R505': 'C25744'}[refs],
        '0402', 'n/a (2-pin)', 'power', '62.5 mW [DS] (to 70 degC)', f'{1e3*p:.2f} mW [CALC]', pct(PR0402, p), 'OK', U['uniroyal'], note)
row('R107', 'UNI-ROYAL 0402WGF0000TCE', 'C17168', '0402 jumper', 'n/a', 'jumper current / resistance',
    '1 A rated, 2 A overload, < 50 mOhm [DS]', 'shell-to-GND ESD return (ns pulses); no DC', 'n/a', 'OK', U['uniroyal'],
    'Optionally replace by a direct copper tie (fewer parts); keep footprint only if a bleed/RC option is wanted')
row('U101', 'ST USBLC6-2SC6', 'C7519', 'SOT23-6L', 'ST datasheet fig. functional diagram: 1 I/O1, 2 GND, 3 I/O2, 4 I/O2, 5 VBUS, 6 I/O1',
    'VBUS pin (5) continuous voltage', 'VRM 5.25 V (IRM <= 150 nA spec point); VBR >= 6.0 V at 1 mA [DS]', f'{VBUS_MAX:.2f} V [brief]',
    '+0.50 V to VBR min, -0.25 V vs VRM', 'THIN', U['usblc6'],
    'Operates 0.25 V above the specified stand-off point: leakage at 5.5 V not specified [MEAS in suspend test]; still below VBR min. Tj -40..150 degC, TL 260 degC/10 s [DS]')
row('U101', 'ST USBLC6-2SC6', 'C7519', 'SOT23-6L', 'ST datasheet', 'D+/D- swing', 'VRM 5.25 V [DS]', '<= 3.6 V (FS signalling), HS 0.4 V',
    '1.65 V', 'OK', U['usblc6'], 'C I/O-GND 3.5 pF max [DS]; IEC 61000-4-2 8 kV contact [DS]')
c, kb = ceff('CL10A105KB8NNNC', 1.0, 0.10, 5.5)
row('C102', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'voltage rating', '50 V [DS: MPN code B=50 V]',
    f'{VBUS_MAX} V steady; hot-plug ring <= 2x VBUS ~11 V [ASSUMP]', '39 V', 'OK', U['samsung'], f'effective C at 5.5 V {c:.2f} uF [CALC, factor {kb}]')

# ================================================================== BLOCK 2: MCU, CPLD, clocks
row('U201', 'WCH CH32V307RCT6', 'C2988083', 'LQFP-64M 10x10, 0.5 mm', 'WCH CH32V20x_30xDS0 pin table (LQFP64M column): PB6 58, PB7 59, PB3 55, PB4 56, PA15 50, PC10-12 51-53, PD2 54',
    'VDD/VIO/VDDA', '-0.3...4.0 V abs max [DS Table 4-1]; 3.3 V rated', f'{V33_MAX:.3f} V [DS ME6211 +/-2 %]', '0.63 V', 'OK', U['ch32'],
    'TA -40..85 degC (suffix 6) [DS]; MSL 3 [JLCPCB page]; JLCPCB stock 364 (21 Sep 2026) - reserve')
row('U201', 'WCH CH32V307RCT6', 'C2988083', 'LQFP-64M', 'WCH pin table: PB4 "I/O FT"', 'PB4 (RAILS_OK_N) input voltage',
    'FT pin VSS-0.3...5.5 V abs max [DS Table 4-1]', f'= 5V_ANA pull-up node: <= {VBUS_MAX:.2f} V steady; up to OVP trip ({OVP_TRIP_MAX} V [ASSUMP]) in the OVP window',
    '0.00 V (steady) / -0.20 V (OVP window)', 'FAIL', U['ch32'],
    'R522 series resistor does not protect an FT pin from over-voltage. Fix: divide the node (e.g. 22 kOhm from the MCU side of R522 to GND -> <= 4.0 V at 5.8 V) - report P-H5')
row('U201', 'WCH CH32V307RCT6', 'C2988083', 'LQFP-64M', 'WCH', 'injected current any pin', '+/-5 mA per pin, +/-25 mA total [DS]',
    '<= 0.19 mA (CC fault through R103/R104 10 kOhm); <= 0.33 mA (enables through 10 kOhm)', '> 4.6 mA', 'OK', U['ch32'], '')
row('U201', 'WCH CH32V307RCT6', 'C2988083', 'LQFP-64M', 'WCH', 'ESD', '4 kV HBM, USB pins 3 kV [DS]', 'protected by U101 at J101', 'n/a', 'OK', U['ch32'], '')
row('Y201', 'YXC X50328MSB2GI', 'C115962', 'SMD5032-2P', 'YXC 2-pad (non-polar)', 'load capacitance / ESR',
    'CL 20 pF, ESR 80 Ohm max, +/-10 ppm, +/-20 ppm stab. [DS listing]', 'C201=C202=33 pF -> 16.5 pF + ~3.5 pF stray = 20 pF [CALC/ASSUMP stray]',
    'n/a', 'OK', U['y201'], 'Drive level and the CH32V307 HSE gm margin not verified (digital stream); -40..85 degC; LCSC stock 37,260')
for refs, mpn, lcsc, v, rat in [('C201, C202', 'FH 0402CG330J500NT', 'C1562', V33_MAX, 50), ('C421', 'FH 0402CG330J500NT', 'C1562', 1.8, 50),
                               ('C203-C210, C212, C213-C216, C217-C219, C305-C309, C616', 'Samsung CL05B104KO5NNNC', 'C1525', V33_MAX, 16),
                               ('C221, C220, C502, C504, C302, C311, C312', 'Samsung CL10A105KB8NNNC', 'C15849', V33_MAX, 50)]:
    row(refs, mpn, lcsc, '0402' if '0402' in mpn or 'CL05' in mpn else '0603', 'n/a', 'voltage rating', f'{rat} V [DS: MPN code]',
        f'{v:.2f} V', f'{rat - v:.1f} V', 'OK', U['samsung'] if 'Samsung' in mpn else 'https://www.lcsc.com/product-detail/C1562.html', 'C0G/X7R/X5R per MPN')
c, kb = ceff('CL05A225MQ5NSNC', 2.2, 0.20, 3.4)
row('C211', 'Samsung CL05A225MQ5NSNC', 'C12530', '0402 (T 0.50 mm)', 'n/a', 'voltage rating / effective C', '6.3 V [DS]',
    f'{V33_MAX:.2f} V; C_eff {c:.2f} uF [CALC]', '2.9 V', 'OK', U['cl05a225'], f'Bias factor {kb} [ASSUMP]; bulk only (attach charge counts nominal C)')
row('U202', 'AGM AGRV2KQ32 (marked AG32VF303K.U6 per AGM ordering note)', 'C18208899', 'QFN-32 4x4 + EP', 'AGM AGRV2K Rev 3.0 Table 5-4: 1 IO_GB, 4 NRST, 6 VDDA33, 16/32 VDD33, 17/30 GND, 24 JTMS, 25 JTCK',
    'junction temperature', '-40...85 degC operating TJ [DS]', f'~{tj(0.083, 45):.0f} degC [CALC: 25 mA x 3.3 V ASSUMP, theta_JA 45 degC/W ASSUMP] + local board heating',
    '~>25 degC', 'THIN', U['agrv'], 'No abs-max/DC tables in the AGM datasheet (VDD33 limit unknown -> DATA-GAP); keep U202 >= 15 mm from LM27762/LDOs; ISP: I/O tri-stated with weak pull-ups [DS]')
row('U202', 'AGM AGRV2KQ32', 'C18208899', 'QFN-32', 'AGM Rev 3.0', 'availability', '-', 'LCSC stock 980 (listing)', 'n/a', 'AVAIL',
    'https://www.lcsc.com/product-detail/C18208899.html', 'Reserve 12 (10 + 2) in the JLCPCB private library before ordering')
row('FB202, FB301', 'Sunlord GZ1608D601TF', 'C1002', '0603', 'n/a', 'current / DCR', '200 mA, 0.45 Ohm [DS listing]',
    '<= 25 mA (CPLD branch), 14.2 mA (DVCC)', '87 %', 'OK', U['fb202'], 'Drop <= 11 mV')
row('X201', 'SCTF SX3M80.000B20F30TNN', 'C5179978', 'SMD3225-4P', 'SCTF 3C drawing: 1 OE/tri-state, 2 GND, 3 OUT, 4 VDD (Notes 3.3, R14)',
    'supply current', '40 mA max [DS listing]', 'counted at 40 mA in the 3V3D budget', 'n/a', 'OK', U['x201'],
    '3.3 V, +/-20/+/-30 ppm, -40..85 degC [DS listing]; OE high/open = enabled -> R218 pull-down keeps it off [DS]; LCSC stock 2,463')
row('X202 (new 49.152 MHz)', 'SCTF SX3M49.152M20F30TNN (proposed)', 'C2901591', 'SMD3225-4P', 'same SCTF 3CM drawing as X201',
    'supply current / availability', '20 mA max [DS listing]; MSL 1 [DigiKey]', 'placeholder in brief 15 mA -> use 20 mA', '-5 mA vs placeholder', 'THIN',
    U['x202n'], 'Replaces YXC OT322524.576MJBA4SL (24.576 MHz) per brief 3.5; LCSC stock 2,741 (Mar 2026 page); one footprint type with X201')
row('X203 (new 45.1584 MHz)', 'SCTF SX3M45.1584M20F30TNN (proposed)', 'C2901589', 'SMD3225-4P', 'same SCTF 3CM drawing as X201',
    'supply current / availability', '20 mA max [DS listing]', 'placeholder 15 mA -> use 20 mA', '-5 mA vs placeholder', 'THIN', U['x203n'],
    'Replaces SX2M22.5792 (22.5792 MHz); LCSC stock 3,736; the 2520 SX2M45.1584 (C21547471) has only 199 in stock - not recommended')
for refs, r, v, lc in [('R212, R213, R218', 2.2e3, V33_MAX, 'C25879'), ('R207, R208', 2.2e3, V33_MAX, 'C25879'), ('R214, R201, R202', 10e3, V33_MAX, 'C25744'),
                       ('R203-R206, R210, R211, R224, R225', 33.0, 1.0, 'C25105')]:
    p = v**2/r if r > 100 else 15e-12*V33_MAX**2*80e6  # 33-Ohm series: C*V^2*f with 15 pF at 80 MHz, all in R (upper bound) [CALC/ASSUMP C]
    row(refs, R0402 + ' (1 %)', lc, '0402', 'n/a', 'power', '62.5 mW [DS]', f'{1e3*p:.2f} mW [CALC]', pct(PR0402, p), 'OK', U['uniroyal'], '')
row('U205 (DNF)', 'Nexperia 74LVC1G157GW,125', 'C135822', 'SOT-363', 'not re-verified (DNF)', 'supply', '1.65-5.5 V [DS listing]', f'{V33_MAX:.2f} V', '>2 V', 'OK',
    'https://www.lcsc.com/product-detail/C135822.html', 'DNF fallback; verify pin-out when fitted')

# ================================================================== BLOCK 3: DAC and supplies
row('U301', 'ESS ES9018K2M', 'C2688377', 'QFN-28 5x5 + EP (EP = DGND)', 'ESS v3.7 pin table: 1 DGND ... 28 RESETB (Notes 3.4 list matches)',
    'AVCC_L/R, VCCA, DVCC', '+4.7 V abs max; 3.3 V +/-5 % (3.135-3.465 V) [DS]', f'{V33_MIN:.3f}-{V33_MAX:.3f} V [DS LDO +/-2 %]', '0.10 V to ROC max', 'OK', U['es9018'], '')
row('U301', 'ESS ES9018K2M', 'C2688377', 'QFN-28', 'ESS v3.7', 'external DVDD', '+1.8 V abs max; 1.3 V +/-5 % (1.235-1.365 V) [DS]',
    f'{V13_MIN:.3f}-{V13_MAX:.3f} V [DS ME6216 +/-1 %]', '0.05 V', 'OK', U['es9018'], 'DVDD <= DVCC in every ramp (power stream)')
row('U301', 'ESS ES9018K2M', 'C2688377', 'QFN-28', 'ESS v3.7', 'operating ambient', '-20...+70 degC TA [DS ROC]', f'{TA:.0f} degC room + local board rise',
    '20 degC minus local rise', 'THIN', U['es9018'], 'Keep >= 15 mm from LM27762/TPS2553/LDO heat; IR check at bring-up [MEAS]')
row('U301', 'ESS ES9018K2M', 'C2688377', 'QFN-28', 'ESS v3.7', 'digital inputs', '-0.3 V ... DVCC+0.3 V [DS]',
    'RESETB/I2S/I2C high while 3V3D off = violation -> firmware keeps them low (R308 1 kOhm limits to <= 3.3 mA)', 'rule', 'OK', U['es9018'],
    'No injection rating given by ESS: keep the existing domain rules (Notes 2.5 step 18); ESD 2 kV HBM, MM 200 V [DS]')
row('U301', 'ESS ES9018K2M', 'C2688377', 'QFN-28', 'ESS v3.7', 'availability', '-', 'LCSC 724 (listing)', 'n/a', 'AVAIL',
    'https://www.lcsc.com/product-detail/C2688377.html', 'Reserve 12 in the JLCPCB library')
p = (VBUS_MAX - V33_MIN)*(17.5e-3 + 0.87e-3)
row('U302', 'TI LP5907MFX-3.3/NOPB', 'C80670', 'SOT-23-5 (DBV)', 'TI SNVS798Q Table 4-2: 1 IN, 2 GND, 3 EN, 4 N/C, 5 OUT',
    'VIN', '6.0 V abs max; 5.5 V ROC [DS]', f'{VBUS_MAX:.2f} V steady; OVP window up to {OVP_TRIP_MAX} V [ASSUMP]', '0.30 V (OVP window) / 0 V to ROC', 'THIN', U['lp5907'],
    'Above ROC only during an OVP event; OVP max trip must stay < 6.0 V')
row('U302', 'TI LP5907MFX-3.3/NOPB', 'C80670', 'SOT-23-5', 'TI', 'Pd / TJ', 'TJ 125 degC ROC, RthJA 193.4 degC/W [DS]',
    f'{1e3*p:.0f} mW -> TJ {tj(p, 193.4):.0f} degC [CALC]', f'{125 - tj(p, 193.4):.0f} degC', 'OK', U['lp5907'], 'Load 17.5 mA + 0.87 mA [brief placeholders]')
row('U302', 'TI LP5907MFX-3.3/NOPB', 'C80670', 'SOT-23-5', 'TI', 'EN', 'VIH >= 1.2 V, VIL <= 0.4 V, EN abs max 6 V [DS]',
    f'{V33_MIN*100/110:.2f} V high (R307/R303 divider), 0 V low', '1.7 V', 'OK', U['lp5907'], 'R307 may be deleted with Q611 (power stream)')
row('U302', 'TI LP5907MFX-3.3/NOPB', 'C80670', 'SOT-23-5', 'TI', 'dropout at VBUS 4.40 V', '250 mV max at 250 mA [DS]',
    '>= 0.9 V headroom (VIN >= 4.2 V after OVP/cable [ASSUMP])', '> 0.6 V', 'OK', U['lp5907'], '')
c1, k1 = ceff('CL10A105KB8NNNC', 1.0, 0.10, 5.5)
c2, k2 = ceff('CL10A105KB8NNNC', 1.0, 0.10, 3.4)
row('C301', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'LP5907 CIN effective', '>= 0.7 uF over all conditions [DS LP5907 5.6]',
    f'{c1:.2f} uF at 5.5 V, 50 degC, -10 %, ageing [CALC]', f'{c1 - 0.7:+.2f} uF', 'THIN', U['lp5907'],
    'Fix: 2.2 uF 16 V X5R 0603 (Samsung CL10A225KO8NNNC, C23630 per Notes 3.4 - verify class/stock) -> ' + f'{ceff("CL10A225KO8NNNC", 2.2, 0.10, 5.5)[0]:.2f} uF')
row('C302', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'LP5907 COUT effective (at the OUT pin)', '>= 0.7 uF, <= 10 uF total, ESR 5-500 mOhm [DS]',
    f'{c2:.2f} uF at 3.37 V [CALC]; total nominal 5.7 uF', f'{c2 - 0.7:+.2f} uF', 'THIN', U['lp5907'],
    'Fix: 2.2 uF 16 V 0603 at C302 -> ' + f'{ceff("CL10A225KO8NNNC", 2.2, 0.10, 3.4)[0]:.2f} uF; total with C303/C304 max-tolerance stays < 10 uF')
c, k = ceff('CL05A225MQ5NSNC', 2.2, 0.20, 3.4)
row('C303, C304', 'Samsung CL05A225MQ5NSNC', 'C12530', '0402', 'n/a', 'voltage / effective C', '6.3 V [DS]', f'3.37 V; C_eff {c:.2f} uF [CALC]', '2.9 V', 'OK',
    U['cl05a225'], 'Large DC-bias loss (factor ' + f'{k}); consider 2.2 uF 16 V 0603 (C23630) for AVCC decoupling (analog stream)')
c, k = ceff('CL05A225MQ5NSNC', 2.2, 0.20, 1.3)
row('C310', 'Samsung CL05A225MQ5NSNC', 'C12530', '0402', 'n/a', 'DVDD decoupling effective C', '>= 1 uF at 1.2 V over temperature [DS ESS p.7]',
    f'{c:.2f} uF at 1.31 V [CALC]', f'{c - 1.0:+.2f} uF', 'OK', U['es9018'], 'Same class as the ESS-recommended TDK C1005X5R0J225M (2.2 uF +/-20 % X5R 6.3 V 0402)')
p = (V33_MAX - V13_MIN)*0.060
row('U303', 'Microne ME6216A13M3G', 'C236662', 'SOT23-3 (M3)', 'Notes 3.4: 1 VSS, 2 VOUT, 3 VIN (Microne A-series M3 convention, cf. ME6211 datasheet pin table); ME6216 PDF not text-readable -> check EasyEDA footprint',
    'VIN / IOUT', 'VIN <= 6 V; 300 mA [DS listing]', f'{V33_MAX:.2f} V; 60 mA [brief DVDD 60 mA]', '>2.6 V; 240 mA', 'OK', U['me6216'],
    'Dropout 110 mV @100 mA [DS-typ] vs >1.9 V headroom; operating -25..125 degC (Ta) [DS listing]')
row('U303', 'Microne ME6216A13M3G', 'C236662', 'SOT23-3', 'see above', 'Pd / TJ', 'Pd and theta_JA not in the listing (Notes quotes 0.54 W) [DATA-GAP]',
    f'{1e3*p:.0f} mW -> TJ ~{tj(p, 250):.0f} degC with theta_JA 250 degC/W [ASSUMP]', 'n/a', 'DATA-GAP', U['me6216'], 'Power stream may replace (brief 3.4: "ME6216 or better")')
row('R301, R302', 'UNI-ROYAL 0805W8F220KT5E', 'C17521', '0805', 'n/a', 'power', '125 mW [DS]', f'{1e3*(0.009**2*2.2):.2f} mW at 9 mA [CALC]', '> 99 %', 'OK', U['uniroyal'],
    'TCR +/-200 ppm/degC for 1-10 Ohm [DS]; failed-output clamp current adds <= 4.4 mA transient')
row('R303, R305, R306, R307, R308', R0402 + ' (1 %)', 'C25741/C25744/C11702', '0402', 'n/a', 'power', '62.5 mW [DS]',
    f'<= {1e3*(V33_MAX**2/1e3):.1f} mW (R308 1 kOhm if RESETB driven into an unpowered DAC)', '82 %', 'OK', U['uniroyal'], '')

# ================================================================== BLOCK 4: I/V and legs
pq = VSUP_AN*(2*3.25e-3) + VPOS_MAX*3.4e-3/2
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8 (D)', 'TI SBOS924H Table 5-2: 1 OUTA, 2 -INA, 3 +INA, 4 V-, 5 +INB, 6 -INB, 7 OUTB, 8 V+',
    'supply', '4.5-36 V ROC, 40 V abs max [DS]', f'{VPOS_MIN + VNEG_MIN:.2f}-{VSUP_AN:.2f} V', '>2.9 V', 'OK', U['opa2210'], 'MSL 2-260C-1 year [DS orderable addendum]')
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI', 'input common mode (+IN = VREF)', '(V-)+1.5 ... (V+)-1.5 V [DS]',
    f'VREF <= 1.754 V vs upper limit {VPOS_MIN - 1.5:.3f} V', f'{VPOS_MIN - 1.5 - 1.754:.3f} V', 'OK', U['opa2210'], '')
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI', 'quiescent current per amplifier', '2.5 mA max at 25 degC; 3.25 mA max at -40..125 degC [DS]',
    '50 degC ambient -> only the 3.25 mA over-temperature limit is guaranteed', '-0.75 mA vs the 2.5 mA used', 'THIN', U['opa2210'],
    'Budget +3.0 mA per rail for 4 channels (analog/power streams; report P-H3)')
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI', 'Pd / TJ', 'TJ 150 degC abs, 125 degC specified; RthJA 126.1 degC/W [DS]',
    f'{1e3*pq:.0f} mW -> TJ {tj(pq, 126.1):.0f} degC [CALC]', f'{125 - tj(pq, 126.1):.0f} degC', 'OK', U['opa2210'], '')
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI', 'input current (DAC-pin fault)', '10 mA [DS abs max]', '<= 4.4 mA [Notes 3.5.1]', '56 %', 'OK', U['opa2210'], '')
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI', 'availability', '-', 'LCSC 16 (Jun 2026); DigiKey 0, 1,626 due 14 Dec 2026, 16-week lead time; JLCPCB page 76 (Sep 2025)',
    'n/a', 'AVAIL', U['opa2210_stock'], 'HIGH risk: buy 12 now (TI.com store / JLCPCB global sourcing) into the JLCPCB library before the order - report P-H1')
row('R401-R416', 'YAGEO RT0603BRD072KL', 'C728588', '0603', 'n/a', 'power / voltage', '100 mW, 75 V [DS listing]',
    f'<= {1e3*(VSUP_AN**2/2e3):.0f} mW (leg rail-stuck, far end at the other rail) [CALC]', '69 %', 'OK', U['rt0603'], 'TCR 25 ppm/degC, 0.1 % [DS]')
row('R401-R416', 'YAGEO RT0603BRD072KL', 'C728588', '0603', 'n/a', 'availability', '-', 'LCSC: out of stock', 'n/a', 'AVAIL', U['rt0603'],
    'Replace by Panasonic ERA-3AEB202V (C193242, 2.00 kOhm 0.1 % 25 ppm 0603, LCSC 12,500, DigiKey 75,066) - report P-M1')
pmax_oc = 0.45
row('U401, U402', 'TI OPA1622IDRCR', 'C2876559', 'VSON-10 3x3 + EP (EP = V-)', 'TI SBOS727B pin table: 1 +INA, 2 V+, 3 GND, 4 V-, 5 +INB, 6 -INB, 7 OUTB, 8 EN, 9 OUTA, 10 -INA; pad V-',
    'supply', '4-36 V ROC, 40 V abs max [DS]', f'{VSUP_AN:.2f} V', '>3.8 V', 'OK', U['opa1622'], 'MSL 1-260C-UNLIM [DS]; LCSC stock 1,400')
row('U401, U402', 'TI OPA1622IDRCR', 'C2876559', 'VSON-10', 'TI', 'quiescent current per channel', '3.3 mA max at 25 degC; 4.2 mA max at -40..125 degC [DS]',
    '50 degC ambient -> 4.2 mA guaranteed limit', '-0.9 mA vs the 3.3 mA used', 'THIN', U['opa1622'], 'Budget +3.6 mA per rail (report P-H3)')
row('U401, U402', 'TI OPA1622IDRCR', 'C2876559', 'VSON-10', 'TI', 'Pd / TJ (one amplifier shorted, 4.4-to-3.5 adapter)', 'TJ 125 degC specified; RthJA 47.6 degC/W [DS]',
    f'{pmax_oc:.2f} W -> TJ {tj(pmax_oc, 47.6):.0f} degC [CALC, Notes 3.7.2 power]', f'{125 - tj(pmax_oc, 47.6):.0f} degC', 'OK', U['opa1622'],
    'Both amplifiers of one package shorted (4.4 mm plug leg+ to leg-) is outside TI\'s one-amplifier short rating -> survival test [MEAS]')
row('U401, U402', 'TI OPA1622IDRCR', 'C2876559', 'VSON-10', 'TI', 'EN pin voltage', '(V-)-0.5 ... (V+)+0.5 V, input current +/-10 mA [DS]',
    'AMP_EN 3.3 V while rails are off = violation; R618 10 kOhm limits to <= 0.33 mA', 'rule', 'OK', U['opa1622'],
    'Firmware: AMP_EN low whenever VPOS/VNEG are not good (Q609 deleted in v0.9)')
row('R417-R420', 'UNI-ROYAL 0402WGF0000TCE', 'C17168', '0402 jumper', 'n/a', 'jumper current / resistance', '1 A rated, < 50 mOhm [DS]',
    '<= ~0.2 A (OPA1622 short-circuit current +145/-130 mA typ [DS-typ])', '80 %', 'OK', U['uniroyal'], 'Adds <= 50 mOhm to Zout (0.5 Ohm target)')
for refs, lc, v in [('C401-C408, C417-C420, C427-C430', 'C1664', 4.1), ('C409-C412, C423-C426, C612-C615', 'C1525', 4.1)]:
    rat = 50 if lc == 'C1664' else 16
    row(refs, 'Samsung CL10C331JB8NNNC' if lc == 'C1664' else 'Samsung CL05B104KO5NNNC', lc, '0603' if lc == 'C1664' else '0402', 'n/a',
        'voltage rating', f'{rat} V [DS: MPN code]', f'<= {v} V (one rail to GND)', f'{rat - v:.0f} V', 'OK', U['samsung'], 'C0G in the signal path' if lc == 'C1664' else '')
c, k = ceff('CL21A106KAYNNNE', 10, 0.10, 4.0)
row('C413-C416, C510, C511', 'Samsung CL21A106KAYNNNE', 'C15850', '0805', 'n/a', 'voltage / effective C', '25 V [DS: MPN code]; LM27762 COUT >= 2.2 uF [DS]',
    f'{VPOS_MAX:.2f} V; C_eff {c:.1f} uF [CALC]', f'{c - 2.2:+.1f} uF', 'OK', U['lm27762'], f'bias factor {k} [ASSUMP]')
row('D405-D408', 'JSMSEMI BAT54S', 'C916425', 'SOT-23', 'standard BAT54S: 1 A1 (lower anode), 2 K2 (upper cathode), 3 common - JSMSEMI drawing image-only -> diode-test samples',
    'reverse voltage / fault current', '30 V; 200 mA [DS listing]', '1.6-1.7 V normal; <= 4.4 mA fault', '> 28 V', 'OK', U['bat54s'], 'MSL 1, Economic+Standard [JLCPCB page]')
row('D405-D408', 'JSMSEMI BAT54S', 'C916425', 'SOT-23', 'see above', 'reverse leakage at 1.7 V, 50 degC', 'only 2 uA max at 25 V, 25 degC given [DS listing] [DATA-GAP]',
    'net leakage per DAC node unbounded by the datasheet (Schottky IR roughly doubles per ~10 degC)', 'n/a', 'DATA-GAP', U['bat54s'],
    'Analog stream decides (brief 3.6): a part with guaranteed IR at 50 degC or no clamp; the offset budget cannot use 0.4 uA')
row('R423-R426, R434-R437, R431-R433 (to become single precision parts)', R0402 + ' (1 %)', 'C11702/C25905/C25756', '0402', 'n/a', 'power',
    '62.5 mW [DS]', f'<= {1e3*(3.8**2/1e3):.1f} mW (1 kOhm at 3.8 V worst I/V swing)', '77 %', 'REPLACE', U['uniroyal'],
    'Brief 3.6 replaces the combinations by single 0.1 % parts (e.g. 825 Ohm): parts stream verifies once the analog stream names them')
row('R427-R430', 'UNI-ROYAL 0603WAF100JT5E', 'C22859', '0603', 'n/a', 'power', '100 mW [DS]', '< 1 mW (series with Cf)', '> 99 %', 'OK', U['uniroyal'], 'TCR +/-200 ppm (1-10 Ohm) [DS]')

# ================================================================== BLOCK 5: power
p502 = (VBUS_MAX - V33_MIN)*0.084
row('U502', 'Microne ME6211C33M5G-N', 'C82942', 'SOT-23-5', 'Microne ME6211 V14 pin table (C-type SOT23-5): 1 VIN, 2 VSS, 3 CE, 4 NC, 5 VOUT',
    'VIN', '6.5 V abs max; 2-6.0 V operating [DS]', f'{VBUS_MAX:.2f} V', '1.0 V', 'OK', U['me6211'], 'Power stream replaces 3V3M by a low-Iq LDO (brief 3.4)')
row('U502', 'Microne ME6211C33M5G-N', 'C82942', 'SOT-23-5', 'Microne', 'Pd', 'Pd 300 mW (SOT23, temperature not stated) [DS]; derated to ~225 mW at 50 degC with TJ 125 degC [ASSUMP linear]',
    f'{1e3*p502:.0f} mW at 5.5 V, 84 mA [CALC]', f'{225 - 1e3*p502:.0f} mW', 'THIN', U['me6211'], 'No theta_JA, dropout max or Iq max in the Microne datasheet [DATA-GAP] -> REPLACE planned')
p504 = (VBUS_MAX - V33_MIN)*0.160
row('U504', 'Microne ME6211C33M5G-N', 'C82942', 'SOT-23-5', 'Microne', 'Pd without the R519/R520 dropper', 'Pd 300 mW [DS]', f'{1e3*p504:.0f} mW at 5.5 V, 160 mA [CALC]',
    f'{300 - 1e3*p504:.0f} mW', 'REPLACE', U['me6211'], 'Confirms brief 3.4: 3V3D needs an LDO rated for >= 0.4 W at 50 degC (SOT-223/DFN with pad)')
row('U503', 'TI TPS2553DBVR', 'C55266', 'SOT-23-6 (DBV)', 'TI SLVS841F: 1 IN, 2 GND, 3 EN, 4 FAULT, 5 ILIM, 6 OUT',
    'VIN', '7 V abs max; 2.5-6.5 V ROC [DS]', f'{VBUS_MAX:.2f} V', '1.0 V', 'OK', U['tps2553'], '')
p553 = 0.5**2*0.135
row('U503', 'TI TPS2553DBVR', 'C55266', 'SOT-23-6', 'TI', 'Pd / TJ normal', 'TJ 125 degC ROC; RthJA 182.6 degC/W; rDS(on) 135 mOhm max [DS]',
    f'{1e3*p553:.0f} mW at 0.5 A -> TJ {tj(p553, 182.6):.0f} degC [CALC]', f'{125 - tj(p553, 182.6):.0f} degC', 'OK', U['tps2553'],
    'Into a short: 5.5 V x 0.498 A = 2.7 W -> thermal cycling (TSD 135 degC in current limit) until firmware drops ANA_EN after the 5-10 ms FAULT deglitch [DS]')
row('U503', 'TI TPS2553DBVR', 'C55266', 'SOT-23-6', 'TI', 'EN / FAULT', 'EN threshold 0.66-1.1 V; FAULT sink 10 mA ROC, VOL <= 180 mV at 1 mA [DS]',
    'EN from 3.3 V GPIO; FAULT pull-up 100 kOhm to 3V3M = 33 uA', 'OK', 'OK', U['tps2553'], 'RILIM 15-232 kOhm range [DS] (single resistors per brief)')
c, k = ceff('CL10A105KB8NNNC', 1.0, 0.10, 5.5)
row('C501, C503, C505, C506', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'voltage / effective C', '50 V [DS]', f'{VBUS_MAX} V; C_eff {c:.2f} uF [CALC]', '44 V', 'OK', U['samsung'],
    'TPS2553 needs >= 0.1 uF at IN [DS] - OK; C503 moves with the new 3V3D LDO')
row('Q501', 'JSCJ 2N7002', 'C8545', 'SOT-23', 'JSCJ: 1 G, 2 S, 3 D (EasyEDA footprint)', 'VGS drive vs threshold', 'VGS(th) <= 2.5 V; RDS(on) 5 Ohm at 10 V only [DS listing]',
    'VGS = 3.3 V (ILIM_HI), ID ~ 8 uA (0.8 V / 100 kOhm [ASSUMP ILIM voltage])', '0.8 V overdrive', 'OK', U['n7002'],
    'Adequate for uA switching; RDS(on) at 3.3 V not specified -> do NOT reuse 2N7002 for the relay driver')
row('FB501', 'Murata BLM18PG121SN1D', 'C14709', '0603', 'n/a', 'current / DCR', '2 A, 50 mOhm [DS listing]', '<= 0.50 A (High limit max) -> 25 mV', '75 %', 'OK', U['fb501'], '-55..125 degC')
p277 = 0.46
row('U501', 'TI LM27762DSSR', 'C473398', 'WSON-12 2x3 + EP (EP = GND)', 'TI SNVSAF7C Table 4-1: 1 PGOOD, 2 FB+, 3 VIN, 4 GND, 5 CP, 6 OUT-, 7 FB-, 8 EN-, 9 C1-, 10 C1+, 11 OUT+, 12 EN+',
    'VIN (5V_ANA_F)', '5.8 V abs max; 2.7-5.5 V operating [DS]', f'{VBUS_MAX:.2f} V steady; OVP window up to {OVP_TRIP_MAX} V [ASSUMP]', '0 V to ROC; 0.10 V to abs max', 'THIN', U['lm27762'],
    'Binding part for the OVP window: OVP trip max must be < 5.8 V incl. overshoot (report P-H6)')
row('U501', 'TI LM27762DSSR', 'C473398', 'WSON-12', 'TI', 'Pd / TJ', 'TJ 125 degC ROC; RthJA 62.2 degC/W [DS]', f'{p277:.2f} W at 5.5 V (Notes 3.6.3) -> TJ {tj(p277, 62.2):.0f} degC [CALC]',
    f'{125 - tj(p277, 62.2):.0f} degC', 'OK', U['lm27762'], 'Exposed pad + >= 5 vias + pour (layout package); MSL 1-260C-UNLIM [DS]')
row('U501', 'TI LM27762DSSR', 'C473398', 'WSON-12', 'TI', 'output current per rail', '250 mA operating, 300 mA abs [DS]', '<= 190 mA peak (2 x 80 mA + quiescent) [CALC from Notes 3.5.2]', '24 %', 'OK', U['lm27762'], '')
row('U501', 'TI LM27762DSSR', 'C473398', 'WSON-12', 'TI', 'EN+/EN-', 'GND-0.3 ... VIN [DS abs max]; VIH 1.2 V [DS]', 'RAIL_EN 3.3 V only after 5V_ANA is up (firmware); R507 limits current', 'rule', 'OK', U['lm27762'],
    'ESD HBM +/-1 kV only [DS] - handle with ESD care; not connector-facing')
c7, k7 = ceff('CL21A106KAYNNNE', 10, 0.10, 5.5)
row('C507, C509', 'Samsung CL21A106KAYNNNE', 'C15850', '0805', 'n/a', 'CIN / CCP effective C', '>= 2 uF after DC bias [DS LM27762 7.2.2.4]; 25 V',
    f'{c7:.1f} uF at 5.5 V [CALC]', f'{c7 - 2.0:+.1f} uF', 'OK', U['lm27762'], '')
c8, k8 = ceff('CL10A105KB8NNNC', 1.0, 0.10, 5.5)
row('C508', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'flying cap effective C', '0.47-1 uF, 10 V recommended [DS]', f'{c8:.2f} uF at ~5.5 V [CALC]', 'in range', 'OK', U['lm27762'], '')
row('C512', 'Samsung CL21A106KAYNNNE', 'C15850', '0805', 'n/a', 'voltage', '25 V [DS]', f'{V33_MAX:.2f} V', '21 V', 'OK', U['samsung'], '')
for refs, r, v, lc in [('R501-R504, R515-R518, R523 (FB dividers, to become single resistors)', 100e3, 4.1, 'C25741...'),
                       ('R506, R508, R511, R512, R513', 100e3, V33_MAX, 'C25741'), ('R507, R521, R522', 10e3, VBUS_MAX, 'C25744')]:
    p = v**2/r
    row(refs, R0402 + ' (1 %)', lc, '0402', 'n/a', 'power', '62.5 mW [DS]', f'{1e3*p:.2f} mW', '> 95 %', 'OK', U['uniroyal'],
        'TCR +/-100 ppm/degC [DS] -> +/-0.25 % per resistor over 0-50 degC: include in the rail/threshold worst case (report P-L3)' if 'FB' in refs else '')

# ================================================================== BLOCK 6: protection
pc = VSUP_AN*2.0e-3
row('U601, U602', 'TI LM339DR (LM339BIDR preferred)', 'C7948 / C22416291', 'SOIC-14 (D)', 'TI SLCS006Z Table 5-1: 1 OUT2, 2 OUT1, 3 VCC, 4 IN1-, 5 IN1+, 6 IN2-, 7 IN2+, 8 IN3-, 9 IN3+, 10 IN4-, 11 IN4+, 12 GND, 13 OUT4, 14 OUT3',
    'junction temperature (LM339 non-B)', 'TJ 0-70 degC recommended [DS 6.5]; LM339B: TA -40..85 degC [DS 6.4]',
    f'TJ ~{tj(pc, 111.2):.0f} degC + local board heating [CALC, RthJA 111.2]', f'{70 - tj(pc, 111.2):.0f} degC (LM339)', 'THIN', U['lm339'], 'Use LM339BIDR (report P-M7)')
row('U601, U602', 'TI LM339DR / LM339BIDR', 'C7948 / C22416291', 'SOIC-14', 'TI', 'supply current', 'LM339 2 mA max (25 degC); LM339B 1.2 mA max (5 V, 25 degC), 1.6 mA max (36 V, -40..85 degC) [DS]',
    'brief placeholder 1.3 mA (LM339B) not guaranteed at 7.8 V / 50 degC -> use 1.6 mA', '-0.3 mA vs placeholder', 'THIN', U['lm339'], 'Flows V+ -> V- (charge-pump factor, R8-D2)')
row('U601, U602', 'TI LM339DR / LM339BIDR', 'C7948 / C22416291', 'SOIC-14', 'TI', 'input voltage', '-0.3 ... 36/38 V vs V- [DS]; input > 0.3 V below V- -> wrong output, excessive current [DS note]',
    f'nodes within the rails ({VSUP_AN:.2f} V span) in operation; at rail collapse a charged filter C can drive an input below V- (R8-B8)', 'rule', 'THIN', U['lm339'],
    'Protection stream adds input series resistors (<= 50 mA input current abs max [DS])')
row('U601, U602', 'TI LM339BIDR', 'C22416291', 'SOIC-14', 'TI', 'availability', '-', 'LCSC 1,080 (Jun 2025 listing)', 'n/a', 'AVAIL', 'https://www.lcsc.com/product-detail/Comparators_Texas-Instruments-LM339BIDR_C22416291.html',
    'Global sourcing acceptable; stocked fallbacks: LM339DR (C7948, LCSC 120,550, TJ 0-70 degC) or LM239DR (TI, TJ -25..85 degC [DS 6.5], LCSC 49,565)')
c, k = ceff('CL10A105KB8NNNC', 1.0, 0.10, 4.0)
row('C601-C604', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'filter capacitance range', 'tolerance +/-10 % [DS: K]; X5R +/-15 % over -55..85 degC [DS class]',
    f'{100*(c/1.0-1):.0f} %/+10 % conservative [CALC: -10 % tol, -5 % temp, -5 % ageing, bias {k} at 4 V]', 'brief used -15/+10 %', 'THIN', U['samsung'],
    'Protection stream: use -26/+10 % (or a stable dielectric) in the trip-time and false-trip corner math')
c_lo = ceff('CL05A225MQ5NSNC', 2.2, 0.20, 2.9)[0]; c_hi = 2.2*1.2
row('C608-C611', 'Samsung CL05A225MQ5NSNC', 'C12530', '0402', 'n/a', 'voltage / capacitance vs node voltage', '6.3 V [DS]',
    f'node 0.29-2.85 V: C {c_lo:.2f}-{c_hi:.2f} uF [CALC]', '3.4 V', 'THIN', U['cl05a225'], 'tau varies > 2:1 with the leg voltage; X7R 0603/0805 >= 16 V reduces it (protection stream)')
for refs, r, v in [('R601-R604', 100e3, VPOS_MAX), ('R624-R627', 15e3, VPOS_MAX + V33_MAX*0.5), ('R628-R635, R639, R640, R618', 10e3, V33_MAX)]:
    p = v**2/r
    row(refs, R0402 + ' (1 %)', 'C25741/C25756/C25744/C25768', '0402', 'n/a', 'power', '62.5 mW [DS]', f'{1e3*p:.2f} mW', '> 90 %', 'OK', U['uniroyal'], '')

# ================================================================== BLOCK 7: outputs, indicators
row('J701', 'G-Switch GT-3321667P-01', 'C2762984', 'THT R/A 20.5 x 8.3 x 6.5 mm', 'maker drawing image-only -> continuity test on samples (R8-A10)',
    'current / voltage / temperature', '500 mA, 30 V, -20..+70 degC [DS listing]', '<= 0.2 A (short), <= 8 V, 50 degC', '60 %; 20 degC', 'OK', U['j701'],
    'LCSC 724, JLCPCB 21 (Notes) -> buy 7 into the JLCPCB library; THT hand/wave soldered (Economic PCBA supports THT)')
row('J702', 'HRO PJ-332A-6A', 'C2848643', 'SMD 14 x 6.3 x 4.5 mm', 'maker drawing image-only -> continuity test (R8-A10)', 'current / voltage / temperature',
    '1 A, 30 V, -25..+80 degC [DS listing]', '<= 0.2 A, <= 8 V, 50 degC', '80 %', 'OK', U['j702'], 'JLCPCB "assembly difficulty high"; reflow peak rating not stated [DATA-GAP] - confirm with JLCPCB (Economic reflow 255 +/- 5 degC)')
row('D701-D704', 'GOODWORK LESD5D5.0CT1G', 'C41399463', 'SOD-523', 'bidirectional (non-polar)', 'stand-off vs leg swing', 'VRWM 5 V, IR 1 uA max, VC 16 V, 7 A [DS listing]',
    f'<= {VPOS_MAX:.2f} V leg (rail-stuck)', f'{5 - VPOS_MAX:.2f} V', 'OK', U['lesd'], 'LCSC stock 13,650')
for refs, mpn, lc, vf, url in [('D705', 'KENTO KT-0805G', 'C2297', '2.6-3.1 V at 5 mA', U['ledg']), ('D706', 'KENTO KT-0603R', 'C2286', '1.8-2.4 V at 20 mA', U['ledr'])]:
    row(refs, mpn, lc, '0805' if '0805' in mpn else '0603', 'maker polarity mark (cathode) - check EasyEDA footprint', 'forward current', f'{vf}; 100/40 mW [DS listing]',
        '<= 1 mA (3.3 V GPIO through R701 1 kOhm / R702 2.2 kOhm)', '> 90 %', 'OK', url, 'MSL 3 [JLCPCB page]; Basic')

row('R701, R702, R421', R0402 + ' (1 %)', 'C11702/C25879/C25741', '0402', 'n/a', 'power', '62.5 mW [DS]',
    f'<= {1e3*((V33_MAX-1.8)**2/1e3):.1f} mW (R701 with a 1.8 V LED drop)', '> 95 %', 'OK', U['uniroyal'], 'LED current <= 1.6 mA')
row('R607-R610, R636, R637 (threshold dividers; to become single E96 parts)', R0402 + ' (1 %)', 'C25792/C25756/C25744', '0402', 'n/a', 'power / TCR',
    '62.5 mW; +/-100 ppm/degC [DS]', f'<= {1e3*(VPOS_MAX**2/57e3):.2f} mW', '> 99 %', 'OK', U['uniroyal'],
    'TCR adds +/-0.25 % per resistor over 0-50 degC: include in the trip-level worst case, or use 0.1 %/25 ppm thin film')
row('C101 (DNF)', 'FH 0402B472K500NT', 'C1538', '0402', 'n/a', 'voltage rating', '50 V [DS: MPN code]', 'shell to GND: ESD only', 'n/a', 'OK',
    'https://www.lcsc.com/product-detail/C1538.html', 'DNF')
row('R215-R217, R703 (DNF)', R0402 + ' (1 %)', 'C25105/C25744/C11702', '0402', 'n/a', 'power', '62.5 mW [DS]', '< 5 mW', '> 90 %', 'OK', U['uniroyal'], 'DNF')
row('PCB', 'JLCPCB 4-layer JLC04161H-7628, 1.6 mm, 1 oz outer / 0.5 oz inner, ENIG', '-', '80 x 60 mm', 'layout_package.md', 'USB pair impedance',
    '90 Ohm +/-15 % (USB 2.0 HS); JLCPCB control +/-10 %', 'W 0.235 mm / S 0.15 mm on L1 over L2: 90.0 Ohm nominal, 80.0-99.3 Ohm fab corners [CALC usb_diffpair_impedance.py]',
    '>= 3.5 Ohm to the USB limits', 'OK', 'https://jlcpcb.com/impedance', 'Confirm in the JLCPCB impedance calculator before ordering (model spread vs closed form 2-3 %)')
row('U202', 'AGM AGRV2KQ32', 'C18208899', 'QFN-32 4x4, 0.4 mm pitch', 'AGM Rev 3.0', 'JLCPCB Economic PCBA minimum IC pin spacing', '0.4 mm [JLCPCB PCBA capabilities]',
    '0.4 mm pitch (32 pins on a 4 mm body)', '0 mm', 'THIN', 'https://jlcpcb.com/capabilities/pcb-assembly-capabilities',
    'At the Economic limit (Standard PCBA 0.35 mm): use the EasyEDA land pattern, solder-mask bridges >= 0.10 mm (green) [JLCPCB], windowpane paste on the EP')

row('R509, R514, R510 (RILIM; to become single resistors)', R0402 + ' (1 %)', 'C25741/C25792', '0402', 'n/a', 'power / tolerance',
    '62.5 mW; 1 %, +/-100 ppm/degC [DS]', '< 0.1 mW (ILIM pin ~1 V [ASSUMP])', '> 99 %', 'OK', U['uniroyal'],
    'Current limit follows RILIM^-0.94...-1.016 [DS TPS2553]: TCR adds +/-0.25 % over 0-50 degC - include in the Default-limit window (power stream)')
row('J703 (DNF)', 'Generic 1x6 2.54 mm header', '-', 'THT 2.54 mm', 'Notes 3.8 pin list', 'fit', 'DNF (no JLCPCB assembly)', '-', 'n/a', 'OK', '-',
    'Only footprint; if fitted by hand it is a second THT part (not assembled by JLCPCB)')

# ================================================================== new parts pre-screen (for the other streams)
row('K601 (proposed)', 'Panasonic TQ2SA-5V', 'C2858038', 'SMD 14 x 9 x 5.6 mm, 2 Form C', 'Panasonic TQ drawing (protection stream to confirm pin map)',
    'coil current / pick-up / timing', '178 Ohm, 140 mW; pick-up <= 75 % (3.75 V), drop-out >= 10 %; operate/release 4 ms max; contact 50 mOhm max, AgNi+Au, min load 10 uA 10 mV [DS]',
    f'coil {1e3*VBUS_MAX/178:.1f} mA at 5.5 V (20 degC coil); >= 4.3 V available [ASSUMP driver drop]', 'pick-up margin 0.55 V at a 20 degC coil only (temperature rows below)', 'THIN', U['tq2sa'],
    'Coil current 30.9 mA exceeds the 30 mA placeholder by 0.9 mA; JLCPCB PCBA type Economic and Standard, MSL 4 [JLCPCB page]')
# relay coil across temperature: pick-up ~ constant ampere-turns -> V_pu scales with coil resistance (Cu 0.393 %/K)
A_CU = 0.00393
R20, V_PU20 = 178.0, 0.75*5.0          # [DS] TQ2SA-5V: 178 Ohm, pick-up <= 75 % at 20 degC (initial)
R_TOL = 0.10                           # [ASSUMP] coil resistance tolerance
V_COIL_MIN = VBUS_MIN - 0.05 - 0.02    # [ASSUMP] OVP drop + trace at the 4.40 V receptacle corner
vpu_cold50 = V_PU20*(1 + A_CU*(TA - 20))
vpu_hot = V_PU20*(1 + A_CU*(TA + 15 - 20))   # [ASSUMP] +15 K coil self-heating after long energisation
i_max = VBUS_MAX/(R20*(1 - R_TOL)*(1 + A_CU*(0 - 20)))
row('K601 (proposed)', 'Panasonic TQ2SA-5V', 'C2858038', 'SMD 14 x 9 x 5.6 mm', 'Panasonic TQ drawing', 'pick-up voltage vs temperature and VBUS corner',
    'pick-up <= 3.75 V at 20 degC [DS]; rises with coil resistance (+0.393 %/K) [CALC]',
    f'needed {vpu_cold50:.2f} V (coil at 50 degC) / {vpu_hot:.2f} V (coil +15 K self-heated) vs {V_COIL_MIN:.2f} V available at VBUS 4.40 V [CALC/ASSUMP]',
    f'{V_COIL_MIN - vpu_cold50:+.2f} V / {V_COIL_MIN - vpu_hot:+.2f} V', 'FAIL', U['tq2sa'],
    'A 5 V coil cannot guarantee re-closing a warm relay at 50 degC and VBUS 4.40 V (report P-H6); 4.5 V coil variant: ' +
    f'{3.375*(1 + A_CU*(TA + 15 - 20)):.2f} V needed -> {V_COIL_MIN - 3.375*(1 + A_CU*(TA + 15 - 20)):+.2f} V margin')
row('K601 (proposed)', 'Panasonic TQ2SA-5V', 'C2858038', 'SMD 14 x 9 x 5.6 mm', 'Panasonic TQ drawing', 'coil current worst case',
    'placeholder <= 30 mA at 5.5 V [brief]', f'{1e3*i_max:.1f} mA at 5.5 V, 0 degC, -10 % coil resistance [CALC]; {1e3*VBUS_MAX/R20:.1f} mA at 20 degC nominal',
    f'{30 - 1e3*i_max:+.1f} mA', 'THIN', U['tq2sa'], '4.5 V coil variant: ' + f'{1e3*VBUS_MAX/(4.5**2/0.14*(1 - R_TOL)*(1 + A_CU*(0 - 20))):.1f} mA worst case (power budget)')
row('K601 (rejected for Economic PCBA)', 'Omron G6K-2F-Y DC5', 'C326376', 'SMD 10 x 6.5 mm', '-', 'JLCPCB PCBA type', 'Standard PCBA only [JLCPCB page]', 'Economic PCBA preferred', 'n/a', 'FAIL', U['g6k'],
    '21.1 mA coil, 3 ms/3 ms, 100 mOhm; usable only with Standard PCBA (rails + fiducials mandatory, >= 70 x 70 mm panel)')
row('R401-R416 (replacement)', 'Panasonic ERA-3AEB202V', 'C193242', '0603', 'n/a', 'availability', '-', 'LCSC 12,500 (Jul 2026); DigiKey 75,066', 'n/a', 'OK', U['era3a'], '2.00 kOhm 0.1 % 25 ppm thin film, 0.1 W, AEC-Q200')

# ================================================================== R8 round 2 (Follow-up 3, 25 Sep 2026)
# Status column: 'current' = part/value in the v0.9 design as of decisions_r8b.md (D-1..D-18) and the stream BOMs;
# 'superseded: ...' = round-1 row kept for traceability, part or value replaced; 'resolved: ...' = finding closed.
SUPERSEDE = [  # (match on refs or mpn, status text)
    (('mpn', 'SHOU HAN'), 'superseded: J101 = GCT USB4105-GF-A (D-8)'),
    (('mpn', 'SX3M80'), 'superseded: X201 = Kyocera KC2520K80.0000C1GE00 (D-3 revised; SX3M80 not approved)'),
    (('mpn', 'SX3M49.152'), 'superseded: X202 = NDK NZ2520SDA NSC5083D (D-4); SX3M is a non-compliant fallback'),
    (('mpn', 'SX3M45.1584'), 'superseded: X203 = NDK NZ2520SDA NSC5083D (D-4); SX3M is a non-compliant fallback'),
    (('mpn', 'ME6216'), 'superseded: U303 = TI TLV75801PDBVR (D-7)'),
    (('mpn', 'ME6211'), 'superseded: U502 = TI TPS7A2033PDBVR, U504 = TI TLV76733DRVR (power BOM)'),
    (('mpn', 'TPS2553'), 'superseded: U503 = TI TPS259621DDAR (D-5)'),
    (('mpn', 'LM339'), 'superseded: U601-U603 = TI TLV1704AIPWR (D-9)'),
    (('mpn', 'TQ2SA'), 'superseded: K601-K604 = Toshiba TLP3545A(TP1,F) (D-1)'),
    (('mpn', 'G6K'), 'superseded: K601-K604 = Toshiba TLP3545A(TP1,F) (D-1)'),
    (('mpn', 'JSMSEMI BAT54S'), 'superseded: D405-D408 = Nexperia BAT54S,215 C47546, moved to the I/V outputs (analog BOM)'),
    (('mpn', 'RT0603BRD072KL'), 'superseded: leg resistors now RT0603WRB (0.05 %/10 ppm) or the approved RT0603BRD alternates (analog BOM)'),
    (('mpn', 'ERA-3AEB202V'), 'superseded: analog BOM uses RT0603WRB072KL / approved RT0603BRD072KL'),
    (('refs', 'R423-R426, R434-R437'), 'superseded: single 0.1 % thin-film parts in the analog BOM (R423-R426 698 R, R431/R432)'),
    (('refs', 'R427-R430'), 'superseded: Cf is a single 820 pF C0G (analog BOM); R427-R430 retired'),
    (('refs', 'R501-R504'), 'superseded: single 0.1 % 25 ppm dividers R501-R504 (D-6)'),
    (('refs', 'R509, R514'), 'superseded: R509 4.75 k (Susumu RG1608P-4751-B-T5, 0.1 %, 25 ppm; DigiKey 114,162) / R510 3.83 k (RT0603BRD073K83L) on TPS2596 ILM (power BOM 25 Sep 05:53)'),
    (('refs', 'R607-R610, R636'), 'superseded: 0.1 % thin-film thresholds (protection BOM)'),
    (('refs', 'R601-R604'), 'superseded: R601-R604 = 105 k (protection BOM); power < 0.2 mW'),
    (('refs', 'R624-R627'), 'superseded: R624-R627 = 6.8 k 0.1 % (protection BOM)'),
    (('refs', 'R628-R635'), 'superseded: 5.1 k / 16.9 k 0.1 % sense networks (protection BOM)'),
    (('refs', 'C601-C604'), 'superseded: C601-C604 = 2.2 uF 16 V X5R 0603 C23630 (protection BOM)'),
    (('refs', 'C608-C611'), 'superseded: C608-C611, C616 = 4.7 uF 25 V X5R 0805 C1779 (protection BOM)'),
    (('refs', 'C301'), 'superseded: C301 = 2.2 uF 16 V X5R 0603 C23630 (D-8)'),
    (('refs', 'C302'), 'superseded: C302 = 2.2 uF 16 V X5R 0603 C23630 (D-8)'),
    (('refs', 'C303, C304'), 'superseded: C303/C304/C310 = 2.2 uF 16 V X5R 0603 C23630 (analog BOM)'),
    (('refs', 'C310'), 'superseded: C310 = 2.2 uF 16 V X5R 0603 C23630 (analog BOM)'),
    (('refs', 'C102'), 'superseded: C102 = 4.7 uF 25 V X5R 0805 C1779 (power BOM)'),
    (('refs', 'C401-C408'), 'superseded: C401-C408 10 pF, C417-C420 820 pF, C431-C438 1.8 nF, all C0G 50 V (analog BOM)'),
    (('refs', 'R212, R213, R218'), 'superseded: R212/R213/R218 = 10 k (digital BOM)'),
    (('refs', 'R207, R208'), 'superseded: R207/R208 = 4.7 k (digital BOM)'),
    (('refs', 'R505'), 'superseded: R505 = 100 k (power BOM); 0.3 mW'),
    (('refs', 'Q501'), 'superseded: Default/High ILM switch = TMUX1101 U505 (D-5)'),
    (('refs', 'U205 (DNF)'), 'superseded: U205 74LVC1G157 now fitted (digital BOM, round-2 row)'),
    (('refs', 'R215-R217'), 'superseded: R215-R217 now fitted (digital BOM)'),
    (('refs', 'K601'), 'superseded: K601-K604 = Toshiba TLP3545A(TP1,F) (D-1)'),
]
RESOLVED = [  # (refs, parameter substring, status text) -> finding closed by a later decision
    ('U201', 'PB4', 'resolved: R532 470 k pin-side pull-down (D-8) -> PB4 <= 4.50 V (round-2 row)'),
    ('U202', 'Economic PCBA minimum', 'resolved: Standard PCBA (D-14), minimum pitch 0.35 mm'),
    ('PCB', 'USB pair impedance', 'superseded: round-2 PCB row (Standard PCBA)'),
    ('U101', 'VBUS pin (5)', 'superseded: U101 pin 5 now on 5V_SYS behind the TPS25200 (round-2 row)'),
    ('U501', 'VIN (5V_ANA_F)', 'superseded: round-2 row with the TPS25200/TPS2596 clamps'),
    ('U302', 'VIN', 'superseded: round-2 row with the TPS25200 clamp'),
    ('U403, U404', 'availability', 'superseded: round-2 availability row (25 Sep 2026)'),
    ('U403, U404', 'quiescent current', 'resolved: load table uses 3.25 mA/ch over temperature (decisions_r8b load table)'),
    ('U401, U402', 'quiescent current', 'resolved: load table uses 4.2 mA/ch over temperature (decisions_r8b load table)'),
    ('U301', 'external DVDD', 'superseded: round-2 row (TLV75801PDBVR 1.283-1.317 V)'),
    ('D701-D704', 'stand-off', 'superseded: round-2 rows (bidirectional confirmed; jack-side nets per D-2)'),
    ('U202', 'junction temperature', 'superseded: round-2 row (CPLD 40 mA [ASSUMP])'),
]
for r in rows:
    for (key, txt), st in SUPERSEDE:
        if (key == 'mpn' and txt in r['mpn']) or (key == 'refs' and r['refs'].startswith(txt)):
            r['status'] = st
            break
    for refs, par, st in RESOLVED:
        if r['refs'].startswith(refs) and par in r['parameter'] and r['status'] == 'current':
            r['status'] = st

# ---- operating conditions of round 2 (decisions_r8b)
VPOS2 = (3.789, 3.852, 3.915)          # [power CALC, D-6]
VNEG2 = (3.661, 3.721, 3.781)          # magnitude [power CALC, D-6]
VSPAN2 = VPOS2[2] + VNEG2[2]           # 7.696 V worst op-amp / comparator supply
V5SYS_CLAMP = 5.55                     # [DS] TPS25200 V(OVC) max (power pw_common)
V5SYS_MIN = 4.30                       # [D-1] 5V_SYS at VBUS 4.40 V
V33H, V33L = 3.3 * 1.02, 3.3 * 0.98    # 3.3 V rails +/-2 % [DS LDOs]
U2 = dict(
    usb4105='https://gct.co/connector/usb4105 ; https://jlcpcb.com/partdetail/3542626-USB4105_GFA/C3020560',
    tpd2e='https://www.ti.com/lit/ds/symlink/tpd2e2u06.pdf (SLLSEG9C; local ../power/ds/tpd2e2u06_fetch.txt)',
    tps2596='https://www.ti.com/lit/ds/symlink/tps2596.pdf (SLVSET8A; local ds/tps2596_SLVSET8A.txt); https://jlcpcb.com/partdetail/TexasInstruments-TPS259621DDAR/C2155774',
    tmux='https://www.ti.com/lit/ds/symlink/tmux1101.pdf (SCDS410D); https://jlcpcb.com/partdetail/TexasInstruments-TMUX1101DBVR/C1852057',
    tlv758='https://www.ti.com/lit/ds/symlink/tlv758p.pdf (SBVS351D; local ds/tlv758p.txt)',
    tlp='https://toshiba.semicon-storage.com/info/TLP3545A_datasheet_en_20230526.pdf?did=60318&prodName=TLP3545A ; https://www.digikey.com/en/products/detail/toshiba-semiconductor-and-storage/TLP3545A-TP1-F/8539920',
    tlv1704='https://www.ti.com/lit/ds/symlink/tlv1704.pdf (SBOS589D; local ../protection/ds/TLV1704_ti_fetch.txt); https://www.digikey.com/en/products/detail/texas-instruments/TLV1704AIPWR/5012683',
    bat54='https://assets.nexperia.com/documents/data-sheet/BAT54S.pdf ; https://jlcpcb.com/partdetail/Nexperia-BAT54S215/C47546',
    lesd='https://www.lcsc.com/product-detail/C41399463.html ; https://jlcpcb.com/partdetail/Lrc-LESD5D50CT1G/C383211',
    kc2520='https://www.mouser.com/datasheet/2/909/clock_k_e-1368023.pdf ; https://www.digikey.com/en/products/detail/kyocera-avx/KC2520K80-0000C1GE00/5322496',
    ndk_sh='https://www.ndk.com/en/products/lineup/crystal-oscillator/NZ2520SH.html ; https://www.digikey.com/en/products/detail/ndk-nihon-dempa-kogyo-co-ltd/NSC5338D-80M/22209279',
    sg210='https://www.digikey.com/en/products/detail/epson/SG-210STF-75-0000ML3/4515145 ; https://download.epsondevice.com/td/pdf/app/SG-210STF_en.pdf',
    ndk_sda='https://www.ndk.com/en/products/upload/lineup/pdf/NDKT02-00008_en.pdf',
    opa_stock='https://www.lcsc.com/product-detail/C1849415.html ; https://www.digikey.com/en/products/detail/texas-instruments/OPA2210IDR/10715389',
    rtw='https://www.digikey.com/en/products/detail/yageo/RT0603WRB071K33L/5929318 ; https://www.digikey.com/en/products/detail/susumu/RG1608N-6650-W-T1/601971 ; https://www.digikey.com/en/products/detail/panasonic-industry/ERA-3ARW202V/3073698',
    rt0402='https://www.digikey.com/en/products/detail/yageo/RT0402BRD07121KL/5926102',
    jlc_cap='https://jlcpcb.com/capabilities/pcb-assembly-capabilities (read 24 Sep 2026)',
)
R2 = 'R8-2'
# --- J101 GCT USB4105-GF-A
row('J101', 'GCT USB4105-GF-A', 'C3020560', 'USB-C 16P SMT + 4 THT shell stakes (0.95 mm)', 'GCT drawing (A/B contact names) - continuity-test 2 samples (R8-A10)',
    'VBUS / contact voltage', '48 V DC [DS GCT]', f'{VBUS_MAX:.2f} V steady; hot-plug ring <= ~11 V [ASSUMP]', '> 37 V', 'OK', U2['usb4105'], R2)
row('J101', 'GCT USB4105-GF-A', 'C3020560', 'USB-C 16P', 'GCT drawing', 'contact current',
    'VBUS pins 5.00 A, GND pins 6.25 A (collectively), B5 1.25 A, others 0.25 A per pin; 40 mOhm max initial [DS GCT]',
    '<= 1.24 A (TPS25200 IOS max with R108 86.6 k [power]); CC <= 1.1 mA (CC shorted to VBUS through Rd)', '>= 3.7 A', 'OK', U2['usb4105'],
    R2 + '; contact drop <= 2 x 40 mOhm x 0.8 A = 64 mV at the High-mode corner [CALC]')
row('J101', 'GCT USB4105-GF-A', 'C3020560', 'USB-C 16P', 'GCT drawing', 'solder process / reflow',
    'peak 255 C (-0/+5) max 5 s [DS GCT]; JLCPCB part page: Assembly Type "SMT Assembly", Economic and Standard, difficulty High, MSL 1',
    'JLCPCB Standard PCBA reflow 240 +/- 5 C (peak <= 245 C) [JLCPCB capabilities]; shell stakes reflowed (pin-in-paste) in the same pass',
    'peak 10 C below the minimum allowed peak; dwell near peak not published', 'THIN', U2['usb4105'],
    R2 + '; ask JLCPCB (order remark) for the Standard profile (time above 240 C) and pin-in-paste on the four stake holes; 0.95 mm stakes do not protrude through 1.6 mm -> no wave soldering possible [CALC]')
row('J101', 'GCT USB4105-GF-A', 'C3020560', 'USB-C 16P', 'GCT drawing', 'temperature / availability', '-40..85 C [DS GCT]',
    '50 C ambient + connector self-heating (<= 64 mV x 0.8 A = 51 mW)', '> 30 C', 'OK', U2['usb4105'],
    R2 + '; LCSC C3020560 out of stock (14 Sep 2026) -> JLCPCB global sourcing (DigiKey 127,933 on 24 Sep 2026)')
# --- U103 TPD2E2U06DRLR
row('U103', 'TI TPD2E2U06DRLR', 'C1972959', 'SOT-5X3 (DRL) 1.6 x 1.2 mm', 'TI SLLSEG9C pin table (DRL): 1 NC, 2 NC, 3 IO1, 4 GND, 5 IO2',
    'CC line voltage', 'VRWM 5.5 V (IIO < 10 uA), VBR >= 6.5 V [DS]', 'normal <= 2.2 V (vRd); fault: CC shorted to VBUS by a cable = 5.50 V',
    'fault case at VRWM, 1.0 V below VBR min', 'THIN', U2['tpd2e'], R2 + '; leakage <= 10 nA at 2.5 V [DS]; no conduction below VBR; fault-only condition')
row('U103', 'TI TPD2E2U06DRLR', 'C1972959', 'DRL', 'TI', 'line capacitance / surge', 'CL 1.5 typ / 1.9 max pF; IPP 5.5 A (8/20 us); PPP 85 W; IEC 61000-4-2 +/-25 kV contact [DS]',
    'cReceiver budget 200-600 pF (USB-C sink)', '> 190 pF', 'OK', U2['tpd2e'], R2 + '; MSL 1-260C-UNLIM [TI addendum]; place at J101 CC pads')
# --- U503 TPS259621DDAR
row('U503', 'TI TPS259621DDAR', 'C2155774', 'HSOIC-8 PowerPAD (DDA) 4.91 x 3.9 mm, EP = GND',
    'TI SLVSET8A §6: 1 GND, 2 dVdt, 3 EN/UVLO, 4 IN, 5 OUT, 6 FLT, 7 ILM, 8 OVLO/OVCSEL, EP GND',
    'IN / OUT voltage', 'IN 21 V abs, 2.7-19 V ROC; OUT <= min(21, VIN + 0.3) V [DS]', f'<= {V5SYS_CLAMP:.2f} V (TPS25200 clamp)', '> 13 V', 'OK', U2['tps2596'], R2)
row('U503', 'TI TPS259621DDAR', 'C2155774', 'DDA', 'TI', 'EN/UVLO, FLT, OVCSEL', 'EN, FLT abs 7 V [DS]; OVCSEL open -> 13.8 V clamp option (inactive at 5.55 V) [DS]',
    f'ANA_EN <= {V33H:.2f} V; FLT pull-up to 3V3M; OVCSEL open (power c11: TPS25200 is the only OV element)', '> 3.6 V', 'OK', U2['tps2596'], R2)
p96 = 0.131 * 0.4834**2
row('U503', 'TI TPS259621DDAR', 'C2155774', 'DDA', 'TI', 'Pd / TJ normal (High limit)', 'TJ 125 C; RthJA 52.7 C/W with EP soldered (119.8 without); RON 131 mOhm max [DS]',
    f'{1e3*p96:.0f} mW at 0.483 A (High IOS max, headline) -> TJ {tj(p96, 52.7):.0f} C [CALC]', f'{125 - tj(p96, 52.7):.0f} C', 'OK', U2['tps2596'],
    R2 + '; into a short: up to 5.55 V x 0.483 A = 2.7 W until OTP (157 C typ) with 95 ms auto-retry -> keep >= 15 mm from U301/U202/U601-U603; X-ray the EP (voids raise RthJA)')
row('U503', 'TI TPS259621DDAR', 'C2155774', 'DDA', 'TI', 'MSL / availability', 'MSL 2-260C-1 YEAR, Sn [TI]', 'JLCPCB 656 available (17 Sep 2026), DigiKey 1,377, LCSC 828 (Apr 2026)',
    'n/a', 'OK', U2['tps2596'], R2 + '; JLCPCB Extended, "Economic and Standard"')
# --- U505 TMUX1101DBVR
row('U505', 'TI TMUX1101DBVR', 'C1852057', 'SOT-23-5 (DBV)', 'TI SCDS410D pin table: 1 D, 2 S, 3 GND, 4 SEL, 5 VDD (DBV and DCK)',
    'VDD / SEL / S-D voltage', 'VDD 1.08-5.5 V ROC, 6 V abs; SEL 6 V abs (fail-safe); VS/VD -0.5..VDD+0.5 V [DS]',
    f'VDD = 3V3M <= {V33H:.2f} V; ILIM_HI <= {V33H:.2f} V; ILM node <= ~0.6 V at the limit [CALC: 903 ohm*A x 0.653 mA/A]; TPS2596 off whenever 3V3M is absent (ANA_EN low)',
    '> 2 V', 'OK', U2['tmux'], R2)
row('U505', 'TI TMUX1101DBVR', 'C1852057', 'DBV', 'TI', 'switch current / Ron / leakage', 'IDC 120 mA (Tj 85 C); RON <= 9.5 ohm (3.3 V, -40..85 C); IS(OFF) <= 0.3 nA (85 C) [DS]',
    '<= 0.4 mA ILM current; Ron in series with R510 3.83 k (power c03 includes 0..9.5 ohm)', '> 99 %', 'OK', U2['tmux'],
    R2 + '; MSL 1-260C-UNLIM; DigiKey 2,865, Mouser 9,098 (Sep 2026); JLCPCB Economic and Standard. DBV confirmed by power c11 (D -> R510, S -> GND, SEL = ILIM_HI, VDD = 3V3M + C515)')
# --- U303 TLV75801PDBVR
p758 = (V33H - 1.283) * 0.060
row('U303', 'TI TLV75801PDBVR', 'C2877852', 'SOT-23-5 (DBV)', 'TI SBVS351D Figure 4-2: 1 IN, 2 GND, 3 EN, 4 FB, 5 OUT',
    'VIN / VOUT window', 'VIN 6.0 V ROC, 6.5 V abs; ESS DVDD 1.235-1.365 V [DS]', f'VIN <= {V33H:.3f} V; VOUT 1.272-1.325 V incl. line/load with R533 15.0 k / R534 11.0 k 0.1 % (RT0603BRD) [power c12]',
    '+37 mV / +40 mV to the ESS window', 'OK', U2['tlv758'], R2 + '; dropout 1.92 V >> 0.40 V max [CALC]')
row('U303', 'TI TLV75801PDBVR', 'C2877852', 'DBV', 'TI', 'Pd / TJ', 'TJ 125 C ROC; RthJA 176.9 C/W [DS]', f'{1e3*p758:.0f} mW at 60 mA -> TJ {tj(p758, 176.9):.0f} C [CALC]',
    f'{125 - tj(p758, 176.9):.0f} C', 'OK', U2['tlv758'], R2 + '; MSL 1-260C-UNLIM; LCSC 113,390 (24 Sep 2026)')
c310, k310 = 2.2 * 0.9 * 0.95 * 0.95 * 0.95, 0.95
row('C310', 'Samsung CL10A225KO8NNNC', 'C23630', '0603', 'n/a', 'TLV758P COUT effective', '>= 0.47 uF derated [DS TLV758P]',
    f'{c310:.2f} uF at 1.32 V [CALC: -10 % tol, bias 0.95 ASSUMP, -5 % temp, -5 % ageing]', f'{c310 - 0.47:+.2f} uF', 'OK', U['samsung'], R2)
# --- photorelays
row('K601-K604', 'Toshiba TLP3545A(TP1,F)', '- (global sourcing)', 'DIP6 LF1 SMD gull wing (11-7A801S), 7.12 x 10.0 x 3.65 mm, TP1 = tape 1,500',
    'Toshiba DS §19 ordering (TP1 = LF1 SMD) + JA pin table: 1 anode, 2 cathode, 3 N.C., 4 drain, 5 source (common), 6 drain',
    'OFF-state voltage', 'VOFF 60 V [DS]', f'<= {VSPAN2:.2f} V across an open switch (leg at +VPOS, jack pulled to -VNEG through a miswired plug)', '> 52 V', 'OK', U2['tlp'],
    R2 + '; pin 3: solder pad, no trace (isolation test groups 1-2-3 vs 4-5-6); pin 5: solder pad, no trace (A connection 4-6)')
row('K601-K604', 'Toshiba TLP3545A(TP1,F)', '-', 'DIP6 LF1', 'see above', 'ON-state current / power', 'ION 4 A (A conn.), -40 mA/C above 25 C -> 3.0 A at 50 C; PO 700 mW, -7 mW/C -> 525 mW at 50 C [DS]',
    '<= 0.3 A (leg short-circuit bound [ASSUMP]) -> 0.3^2 x 0.09 ohm = 8 mW', '> 90 %', 'OK', U2['tlp'], R2 + '; RON 60 mOhm max at 25 C, IF 5 mA; hot RON ~0.09 ohm [ASSUMP x1.5]')
row('K601-K604', 'Toshiba TLP3545A(TP1,F)', '-', 'DIP6 LF1', 'see above', 'LED forward current / power', 'IF 30 mA abs, -0.3 mA/C -> 22.5 mA at 50 C; PD 50 mW, -0.5 mW/C -> 37.5 mW at 50 C; VR 6 V [DS]',
    '<= 7.14 mA (protection p05 limiter max); 1.80 V x 7.14 mA = 12.9 mW; LED reverse 0 V', '> 15 mA', 'OK', U2['tlp'], R2)
if_drop = (V5SYS_MIN - 2 * (1.80 + 0.04) - 0.10 - 0.02) / 100.0
row('K601-K604', 'Toshiba TLP3545A(TP1,F)', '-', 'DIP6 LF1', 'see above', 'LED current >= 5.0 mA at 5V_SYS 4.30 V (D-1), round-1 VBE limiter',
    'IF >= 5 mA for the RON specification and the recommended minimum [DS §9, §13]; VF 1.50/1.64/1.80 V at 10 mA, 25 C [DS §12]',
    f'round-1 MMBT3904 VBE limiter (R_S 100 ohm): with VF = 1.80 V + 0.04 V at 0 C [ASSUMP] it drops out, IF = {1e3*if_drop:.2f} mA [CALC]',
    f'{round(1e3*(if_drop - 0.005), 2) + 0.0:+.2f} mA', 'THIN', U2['tlp'], R2 + '; parts-stream check of 25 Sep; replaced by the protection round-2 sink (next row)',
    status='resolved: protection p05 round 2 (25 Sep 05:17) low-dropout OPA2333 sink, IF 5.315-6.599 mA')
row('K601-K604', 'Toshiba TLP3545A(TP1,F)', '-', 'DIP6 LF1', 'see above', 'LED current >= 5.0 mA at 5V_SYS 4.30 V (D-1), round-2 sink',
    'IF >= 5 mA [DS]; IF abs 30 mA (19.5 mA at 60 C); PD 50 mW (32.5 mW at 60 C) [DS]',
    'U604 OPA2333 + Q612/Q614 sink, V_IREF 137-164 mV / R_S 24.9 ohm 0.1 %: IF 5.315-6.599 mA, independent of 5V_SYS and VF while Q612 is active (regulates down to 5V_SYS 4.17 V at 0 C, VF max) [protection p05 CALC]',
    '+6.3 % over 5.0 mA; Q612 VCE >= 0.426 V at 4.30 V', 'OK', U2['tlp'], R2 + '; supply <= 13.62 mA incl. 3V3M 0.42 mA (D-1 budget 15.32 mA)')
row('U604 (protection round 2)', 'TI OPA2333AIDR', 'C38732', 'SOIC-8 (D)', 'TI standard dual pinout: 1 OUTA, 2 -INA, 3 +INA, 4 V-, 5 +INB, 6 -INB, 7 OUTB, 8 V+ (confirm with the protection netlist)',
    'supply / inputs / output', 'VS 1.8-5.5 V, 7 V abs; RRIO; output current 5 mA [DS/JLC listing]', 'V+ = 3V3D <= 3.366 V (C622 at the pin; R664 retired, protection 05:51); +IN <= 164 mV (from RELAY_EN via R662/R663); -IN 0..V+; output <= 0.54 mA [protection p05]',
    '> 2 V', 'OK', 'https://jlcpcb.com/partdetail/TexasInstruments-OPA2333AIDR/C38732 ; https://www.ti.com/lit/ds/symlink/opa2333.pdf (SBOS351E)',
    R2 + '; JLCPCB Extended, "Economic and Standard", MSL 1; LCSC 5,082 (protection BOM, 25 Sep 2026); OPA2333 datasheet not read by the parts stream (protection figures); netlist pinout = standard dual (checked)')
row('R641, R642 (protection round 2)', 'Vishay PATT0402E24R9BGT1 (alt. Yageo RT0402BRD0724R9L)', '- (global sourcing)', '0402 thin film', 'n/a', 'power / availability', '0.05 W, 0.1 %, 25 ppm, AEC-Q200, anti-sulfur [DS-listing DigiKey]',
    '(6.6 mA)^2 x 24.9 ohm = 1.1 mW; DigiKey 3,285 (Feb 2026 page), 15-week lead', '> 97 %', 'AVAIL', 'https://www.digikey.com/en/products/detail/vishay-dale-thin-film/PATT0402E24R9BGT1/5321403',
    R2 + '; buy 20 now via global sourcing; protection: a 1 % 100 ppm 24.9 ohm part also meets D-1 (5.25-6.68 mA) -> low risk')
row('C617 (protection round 2)', 'Samsung CL10A105KB8NNNC (1.0 uF 50 V X5R)', 'C15849', '0603', 'n/a', 'voltage / polarity', '50 V rating; class II, non-polar',
    '-3.83...+4.01 V (node H) [protection p05]', '> 45 V', 'OK', '-', R2 + '; DC-bias effect small at 4 V on a 50 V part; R647 = 100 k (power 0.16 mW)')
row('K601-K604', 'Toshiba TLP3545A(TP1,F)', '-', 'DIP6 LF1', 'see above', 'reflow / MSL / availability', 'Tsol 260 C (10 s), reflow once or twice, all passes within 2 weeks [DS §8, §17]; MSL 1 [DigiKey]',
    'JLCPCB Standard PCBA 240 +/- 5 C, top side = one pass; DigiKey 28,529 on the TP1 page (18 Sep 2026)', '>= 15 C', 'OK', U2['tlp'],
    R2 + '; land: Toshiba 11-7A801S reference land (JEITA ET-7501 L3, CAD download) - numbers not machine-readable; see layout_package.md footprint check')
# --- comparators
row('U601-U603', 'TI TLV1704AIPWR', 'C181596', 'TSSOP-14 (PW)', 'TI SBOS589D pin table (PW): 1 2OUT, 2 1OUT, 3 V+, 4 1IN-, 5 1IN+, 6 2IN-, 7 2IN+, 8 3IN-, 9 3IN+, 10 4IN-, 11 4IN+, 12 V-, 13 4OUT, 14 3OUT (= LM339 pinout; matches protection netlist)',
    'supply / inputs / outputs', 'VS 2.2-36 V ROC, 40 V abs; inputs (V-)-0.5..(V+)+0.5 V, +/-10 mA; open collector up to 36 V above V- [DS]',
    f'VS <= {VSPAN2:.2f} V; inputs through 100 k (R649-R652) and inside the rails in operation; node H <= VPOS', '> 28 V', 'OK', U2['tlv1704'], R2)
row('U601-U603', 'TI TLV1704AIPWR', 'C181596', 'PW', 'TI', 'supply current', 'IQ 75 uA/ch max (25 C), 100 uA/ch max (-40..125 C) [DS]',
    '3 x 4 x 100 uA = 1.20 mA per rail + dividers/pull-up -> ~1.24 mA vs D-9 budget 1.26 mA', '+0.02 mA', 'OK', U2['tlv1704'], R2 + '; protection owns the budget line')
row('U601-U603', 'TI TLV1704AIPWR', 'C181596', 'PW', 'TI', 'MSL / availability', 'MSL 2-260C-1 YEAR [TI addendum 20 Aug 2026]', 'LCSC 61 (24 Sep 2026); DigiKey 6,948 (23 Sep 2026); TLV1704AQPWRQ1 5,658',
    'n/a', 'AVAIL', U2['tlv1704'], R2 + '; JLCPCB global sourcing (buy 20 = 3 x 5 + 5 spare) - low risk')
# --- clamps and jack ESD
row('D405-D408', 'Nexperia BAT54S,215', 'C47546', 'SOT23 (TO-236AB)', 'Nexperia BAT54S v.6 Table 2: 1 A1, 2 K2, 3 K1;A2 (matches analog netlist)',
    'reverse voltage / fault current / power', 'VR 30 V; IF 200 mA; IFRM 300 mA; IFSM 600 mA (<10 ms); Ptot 250 mW (25 C), Rth(j-a) 500 K/W -> 200 mW at 50 C [DS/CALC]',
    '<= 3.37 V reverse; fault <= 65 mA (OPA2210 short-circuit) x 0.5 V = 33 mW', '> 80 %', 'OK', U2['bat54'], R2 + '; MSL 1; JLCPCB 230,448 available; VF 240/320/400/500/800 mV max at 0.1/1/10/30/100 mA [DS]')
row('D405-D408', 'Nexperia BAT54S,215', 'C47546', 'SOT23', 'see above', 'reverse leakage at ~1.7 V, 50 C', 'only IR <= 2 uA at 25 V, 25 C [DS]; temperature curves typical only',
    'I/V-output node, leakage adds to the DAC-pin budget (analog stream, D-17)', 'n/a', 'DATA-GAP', U2['bat54'], R2 + '; [MEAS] at 50 C on samples (analog)')
row('D701-D704', 'GOODWORK LESD5D5.0CT1G', 'C41399463', 'SOD-523', 'bidirectional, non-polar (LCSC listing); nets JACK_LP/JACK_RP/JACK_LN/JACK_RN (D-2)',
    'polarity / stand-off vs jack swing', 'Bidirectional, VRWM 5 V, IR 1 uA, VBR >= 6 V [DS-listing GOODWORK/DigiKey]; LRC original VBR 7.8 V [JLCPCB listing]',
    f'+/-{VPOS2[2]:.3f} V (legs through the closed switch)', f'+{5 - VPOS2[2]:.2f} V', 'OK', U2['lesd'],
    R2 + '; GOODWORK PDF itself not read (LCSC link wrapper) - parameters from the LCSC/DigiKey/JLCPCB listings; LCSC 13,650 (25 Sep 2026); approved alternate LRC LESD5D5.0CT1G C383211 (analog BOM; order by C number)')
row('D701-D704', 'GOODWORK LESD5D5.0CT1G', 'C41399463', 'SOD-523', 'see above', 'clamp / capacitance', 'VC 16 V at 7 A (10/1000 us), 100 W [DS-listing]; LRC: 18.6 V at 9.4 A (8/20 us); C 12 pF (GOODWORK) / 15 pF (LRC)',
    'ESD at the jack contacts; C on the jack node driven through <= 0.1 ohm', 'n/a', 'OK', U2['lesd'], R2 + '; LRC MSL 3 per JLCPCB (bake if exposed); nonlinear C effect on THD negligible at <= 0.1 ohm source [ASSUMP]')
# --- X201
row('X201 (D-3 choice)', 'Epson SG-210STF 75.0000ML3 (X1G004171008112)', 'C17388398 (75.0000ML)', '2.5 x 2.0 mm 4-pad', 'Epson full DS §9: 1 ST, 2 GND, 3 OUT, 4 VCC',
    'availability', '-', 'DigiKey/Mouser: Obsolete (EOL PCN 25 Jun 2020) for ML3/ML/ML0; LCSC out of stock; Epson 2025 DS: 75 MHz not a standard frequency; one JP broker lot (150 pcs)',
    'n/a', 'FAIL', U2['sg210'], R2 + '; replaced by Kyocera KC2520K80.0000C1GE00 (rows below)', status='superseded: EOL, not procurable; D-3 revised adopts Kyocera KC2520K80 (Follow-up 3)')
ix = 8.0e-3 + V33H / 10e3 * 0.5
row('X201', 'Kyocera KC2520K80.0000C1GE00', 'C1988889 (not available) -> global sourcing', '2.5 x 2.0 x 0.8 mm 4-pad (KC2520K)',
    'Kyocera K-series DS: #1 E/D (INH), #2 GND, #3 OUT, #4 VCC; INH open/H = active, L = High Z, no oscillation',
    'supply / current', 'VCC 2.8-3.63 V (code 3), 4.0 V abs; ICC 8.0 mA max at 62.5-80 MHz, maximum load (15 pF) and full temperature range; I_std 5 uA [DS]',
    f'3V3D {V33L:.3f}-{V33H:.3f} V; 8.0 mA + R227 {V33H/10e3*0.5*1e3:.2f} mA = {ix*1e3:.2f} mA = the D-3-revised 3V3D budget line 8.2 mA', f'{8.2 - ix*1e3:+.2f} mA vs budget; rating limit only at 3.63 V', 'OK', U2['kc2520'],
    R2 + '; X201 adopted in D-3 revised (25 Sep 05:32); C217 = 10 nF at the VCC pad (D-3 revised)')
row('X201', 'Kyocera KC2520K80.0000C1GE00', '-', 'KC2520K', 'see above', 'INH levels and timing', 'VIH >= 70 % VCC, VIL <= 30 % VCC; t_dis <= 200 ns; t_ena <= 3 ms; t_str <= 3 ms [DS]',
    'U206 74LVC1G11 on 3V3D drives INH (VOH >= VCC-0.1 V at <= 100 uA; D-19 adds R235 100 k + R645 1 k to the Q616 gate + PB1 on this node, see U206 row); digital mclk_gate_race margin for t_dis 4.8 us (firmware error case)', '4.6 us', 'OK', U2['kc2520'], R2)
row('X201', 'Kyocera KC2520K80.0000C1GE00', '-', 'KC2520K', 'see above', 'waveform vs ES9018K2M MCLK', 'SYM 45-55 %; tr/tf <= 4.5 ns (10-90 %, 3.3 V); VOH >= 90 %, VOL <= 10 % VCC (8 mA); load <= 15 pF [DS]',
    '80 MHz: 80/0.384 = 208.3 > 192 (+8.5 %); period 12.5 ns, high/low >= 5.63 ns >= 4.5 ns (D-3); load R203 + XI + ~10 mm trace ~5-8 pF [ASSUMP]',
    'rise 4.5 ns < 5.63 ns half period', 'OK', U2['kc2520'], R2 + '; [MEAS] XI waveform at U301 through R203 at bring-up')
jit_snr = -20 * math.log10(2 * math.pi * 20e3 * 1.0e-12)
row('X201', 'Kyocera KC2520K80.0000C1GE00', '-', 'KC2520K', 'see above', 'jitter / phase noise', 'phase jitter 1.0 ps max (12 kHz-20 MHz); phase noise -143 dBc/Hz at 1 kHz, -157 at 10 kHz, -160 at 100 kHz listed at 25 MHz [DS]',
    f'jitter-limited SNR at 20 kHz = {jit_snr:.0f} dB [CALC] vs DNR >= 115 dB', f'{jit_snr - 115:.0f} dB', 'OK', U2['kc2520'],
    R2 + '; at 80 MHz close-in phase noise ~10 dB higher than the 25 MHz listing [ASSUMP 20log(80/25)]; DNR/THD+N [MEAS]')
row('X201', 'Kyocera KC2520K80.0000C1GE00', '-', 'KC2520K', 'see above', 'reflow / MSL / availability', 'MSL 1 [DigiKey]; reflow 260 C x 2 [D-3 revised text; Kyocera soldering sheet not read by parts]',
    'Standard PCBA 240 +/- 5 C; DigiKey 2,964 (5 Aug 2026); Mouser 1,375 + 10,000 on order (18 Sep 2026); 32-week factory lead', 'n/a', 'AVAIL', U2['kc2520'],
    R2 + '; buy 20 now through JLCPCB global sourcing (5 boards + spares + bring-up)')
row('X201 (second source)', 'NDK NSC5338D-80M (NZ2520SH-80.000M-NSC5004D)', '- (global sourcing)', '2.5 x 2.0 x 0.9 mm', 'NDK NZ2520SH: #1 STAND-BY, #2 GND, #3 OUTPUT, #4 VCC',
    'current / data completeness', 'ICC 9.0 mA max (3.3 V, 70-80 MHz, +25 C only, load not stated); I_ST 20 uA (+25 C) [DS]', 'D-3 revised budget 12.7 mA (9.0 mA + C x V x f with 15 pF + R227) [D-3 revised]',
    'n/a', 'DATA-GAP', U2['ndk_sh'], R2 + '; conditional second source (D-3 revised): bring-up checks of disable time and edges; no R509 change (R509 stays 4.75 k, S3 497.92 mA with the NDK, decisions_r9 E-27); +/-50 ppm -40..105 C, SYM 45-55 %, tr/tf 5 ns, start-up 4 ms, AEC-Q100/Q200, MSL 1; DigiKey 974 (Jul 2026)')
i_dc = V33H / 100e3 + 1e-6 + 0.1e-6
row('U206 (D-19)', 'Nexperia 74LVC1G11GW-Q100H', 'C548242', 'SOT-363 (TSSOP6)', 'Nexperia 74LVC1G11 Rev 13.1 pin table: 1 A, 2 GND, 3 B, 4 Y, 5 VCC, 6 C (digital netlist)',
    'output loading on N2_MCLK_OE', 'VOH >= VCC-0.1 V at IO -100 uA; >= 2.3 V at -24 mA (VCC 3.0 V); IO +/-50 mA abs [DS Table 5/7]',
    f'DC {1e6*i_dc:.0f} uA (R235 100 k + PB1 leakage 1 uA + Q616 gate leakage 0.1 uA); edge current into the Q616 gate through R645 1 k <= {V33H/1e3*1e3:.1f} mA for ~1 us (1 k x ~1 nF)',
    f'VOH >= {V33L - 0.1:.2f} V vs X201 VIH {0.7*V33H:.2f} V', 'OK', 'https://assets.nexperia.com/documents/data-sheet/74LVC1G11.pdf (local ../digital/sources/74LVC1G11_Nexperia_Rev13.1.txt)',
    R2 + '; D-19: Q616 gate from N2_MCLK_OE via R645 -> every MCLK stop opens the output switch; R645 placed at U206 so the X201 pin-1 node stays short')
row('C217 (D-3 revised)', '10 nF X7R 50 V 0402 (MPN per digital BOM; e.g. Samsung CL05B103KB5NNNC C15195)', 'C15195 (class)', '0402', 'n/a', 'voltage rating', '50 V [DS: MPN code]',
    f'{V33H:.2f} V (3V3D)', '> 46 V', 'OK', U['samsung'], R2 + '; X201 VCC bypass 0.01 uF at the pad per D-3 revised (Kyocera/Epson/NDK recommend ~0.01 uF)')
# --- X202/X203 NDK NZ2520SDA (D-4)
row('X202, X203', 'NDK NZ2520SDA 49.152/45.1584 MHz NSC5083D', '- (global sourcing)', '2.5 x 2.0 mm', 'NDK: #1 STAND-BY, #2 GND, #3 OUTPUT, #4 VCC',
    'supply current', '15 mA max operating, 35 uA stand-by - both +25 C only [DS]', 'budget one running 15 mA + other 0.035 mA (D-4)', 'n/a', 'DATA-GAP', U2['ndk_sda'],
    R2 + '; symmetry 40-60 % (CPLD divides), tr/tf 6 ns, start-up 4 ms, MSL 1; DigiKey 3,438 / 3,166 (Sep 2026)')
# --- rails and sequencing parts affected by the new clamps
row('U101', 'ST USBLC6-2SC6', 'C7519', 'SOT23-6L', 'ST: 5 VBUS', 'VBUS pin (5) on 5V_SYS', 'VRM 5.25 V (IRM spec point), VBR >= 6.0 V [DS]',
    f'<= {V5SYS_CLAMP:.2f} V (TPS25200 OUT clamp)', f'+{6.0 - V5SYS_CLAMP:.2f} V to VBR, -{V5SYS_CLAMP - 5.25:.2f} V vs VRM', 'THIN', U['usblc6'], R2 + '; leakage above VRM [MEAS] in the suspend test')
row('U501', 'TI LM27762DSSR', 'C473398', 'WSON-12', 'TI SNVSAF7C', 'VIN (5V_ANA_F)', '5.8 V abs; 2.7-5.5 V operating [DS]', f'<= {V5SYS_CLAMP:.2f} V (TPS25200 clamp; TPS2596 OVCSEL open per power c11)',
    f'+{5.8 - V5SYS_CLAMP:.2f} V to abs; {5.5 - V5SYS_CLAMP:+.2f} V to ROC', 'THIN', U['lm27762'], R2 + '; above ROC only while the OVP clamps an over-voltage source')
row('U302', 'TI LP5907MFX-3.3/NOPB', 'C80670', 'SOT-23-5', 'TI', 'VIN (5V_SYS)', '6.0 V abs; 5.5 V ROC [DS]', f'<= {V5SYS_CLAMP:.2f} V', f'+{6.0 - V5SYS_CLAMP:.2f} V to abs; {5.5 - V5SYS_CLAMP:+.2f} V to ROC',
    'THIN', U['lp5907'], R2)
pb4 = V5SYS_CLAMP * 470 / (100 + 10 + 470)
row('U201', 'WCH CH32V307RCT6', 'C2988083', 'LQFP-64M', 'WCH pin table: PB4 FT', 'PB4 (RAILS_OK_N) with R532', 'FT pin VSS-0.3...5.5 V abs [DS Table 4-1]',
    f'5V_ANA_F <= {V5SYS_CLAMP:.2f} V x 470/(100+10+470) = {pb4:.2f} V [CALC]', f'{5.5 - pb4:.2f} V', 'OK', U['ch32'], R2 + '; closes P-H4')
for refs, v, note in [('C301', 5.55, 'LP5907 CIN'), ('C302', V33H, 'LP5907 COUT')]:
    k = 0.70 if v > 5 else 0.80
    c = 2.2 * 0.9 * k * 0.95 * 0.95
    row(refs, 'Samsung CL10A225KO8NNNC', 'C23630', '0603 16 V X5R', 'n/a', note + ' effective', '>= 0.7 uF over all conditions [DS LP5907 5.6]',
        f'{c:.2f} uF at {v:.2f} V [CALC: -10 %, bias {k} ASSUMP, -5 % temp, -5 % ageing]', f'{c - 0.7:+.2f} uF', 'OK', U['lp5907'], R2 + '; closes P-M2')
c6lo, c6hi = 2.2 * 0.9 * 0.95 * 0.95, 2.2 * 1.1
row('C601-C604', 'Samsung CL10A225KO8NNNC', 'C23630', '0603 16 V X5R', 'n/a', 'leg DC-window filter C range', '+/-10 % [DS: K]; X5R class',
    f'{c6lo:.2f}-{c6hi:.2f} uF at <= 0.32 V [CALC: tol, -5 % temp, -5 % ageing, bias ~1.0] = -19/+10 %', 'protection used -15/+10 %', 'THIN', U['samsung'],
    R2 + '; protection stream: add the -5 % ageing term to the trip-time corner (P-M9)')
c8lo, c8hi = 4.7 * 0.9 * 0.95 * 0.95 * 0.85, 4.7 * 1.1
row('C608-C611, C616', 'Samsung CL21A475KAQNNNE', 'C1779', '0805 25 V X5R', 'n/a', 'DC-sense filter C range', '+/-10 % [DS: K]',
    f'{c8lo:.2f}-{c8hi:.2f} uF at <= 2.5 V [CALC: tol, -5 % temp, -5 % ageing, bias 0.85 ASSUMP] = -31/+10 %', 'protection used -28/+10 %', 'THIN', U['samsung'],
    R2 + '; ageing term missing in the protection range (P-M9)')
row('U202', 'AGM AGRV2KQ32', 'C18208899', 'QFN-32 4x4 + EP', 'AGM Rev 3.0 Table 5-4', 'junction temperature', '-40...85 C operating TJ [DS]',
    f'~{tj(0.040*3.366, 45):.0f} C [CALC: 40 mA x 3.37 V ASSUMP, RthJA 45 C/W ASSUMP] + local board heating', f'~{85 - tj(0.040*3.366, 45):.0f} C minus local rise', 'THIN', U['agrv'],
    R2 + '; >= 15 mm from U503/U504/U501/U102 (layout_package.md §7); IR scan at 50 C [MEAS]')
row('U301', 'ESS ES9018K2M', 'C2688377', 'QFN-28', 'ESS v3.7', 'external DVDD (TLV75801)', '+1.8 V abs; 1.3 V +/-5 % (1.235-1.365 V) [DS]', '1.272-1.325 V incl. line/load [power c12]', '+37 mV',
    'OK', U['es9018'], R2 + '; DVDD <= DVCC in every ramp (power stream, TLV758P active discharge)')
row('U403, U404', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI', 'availability (buy 12, D-8)', '-',
    'LCSC 16 in stock (25 Sep 2026); DigiKey 0 (1,626 due 14 Dec 2026); Mouser 0 (9,922 due 23 Nov 2026); TI store behind login', 'n/a', 'AVAIL', U2['opa_stock'],
    R2 + '; buy 12 now (D-8; LCSC has 16) into the JLCPCB library (JLCPCB draws on LCSC stock); backup TI.com (OPA2210IDR or OPA2210ID tube)')
row('U403, U404 (DAC reset state)', 'TI OPA2210IDR', 'C1849415', 'SOIC-8', 'TI SBOS924H Table 5-2', 'output swing / current in the DAC-reset state',
    'VO swing (V+)-0.6 V at RL 600 ohm (25 C only; AOL > 114 dB), (V+)-0.2 V at 10 k (-40..125 C); ISC +/-65 mA [DS]',
    'load ~830 ohm to GND, 3.29-4.07 mA sourced per output; needed Vout = VREF(1 + Rf/Rs) = 2.907-3.369 V vs >= 3.189 V guaranteed at VPOS min (25 C) [analog R2.15]',
    'lower corner 2.907 V is below the swing bound; upper corner may soft-clip', 'OK', U['opa2210'],
    R2 + '; clipping in the worst reset corner is harmless (DAC pin 1.616 V inside 0..AVCC, input differential 0.09 V, output switch open) [analog]; protection uses CM(reset) >= 2.907 V; no over-temperature 600-ohm swing row exists [DATA-GAP, not needed]; dissipation <= (3.915-2.907) V x 4.07 mA = 4 mW')
row('R401-R416, R438-R445', 'YAGEO RT0603WRB071K33L / RT0603WRB07665RL / RT0603WRB072KL (0.05 %, 10 ppm)', 'n/a / n/a / C864006',
    '0603 thin film', 'n/a', 'availability', '-',
    '1.33 k and 665 R: not stocked anywhere found (YAGEO/Susumu/Panasonic 0.05 %/10 ppm: MOQ 1,000-5,000, 20-41 weeks); 2.00 k: ERA-3ARW202V DigiKey 1,259, RG1608N-202-W-T1 16,746',
    'n/a', 'FAIL', U2['rtw'], R2 + '; use the approved RT0603BRD 0.1 %/25 ppm alternates for 1.33 k/665 R (C861196/C861514, in stock) or retune (analog stream notified 25 Sep)',
    status='resolved: analog BOM 25 Sep 05:43 retuned the T network to stocked 0.05 %/10 ppm values (next row)')
row('R401-R416, R438-R445 (analog round 2)', 'Susumu RG1608N-132-W-T1 (1.30 k) / RG1608N-681-W-T1 (680 R) / RG1608N-202-W-T1 (2.00 k); alt. Panasonic ERA-3ARW132V / ERA-3ARW202V',
    '- (global sourcing)', '0603 thin film, 0.05 %, 10 ppm, 0.1 W, 75 V, AEC-Q200', 'n/a', 'availability / rating', '0.1 W, 75 V [DS-listing]',
    'DigiKey: 1.30 k RG1608N 157 + ERA-3ARW132V 661; 680 R RG1608N 783; 2.00 k RG1608N 16,746 + ERA-3ARW202V 1,259 (25 Sep 2026, analog BOM); need 8 + 8 + 8 per board x 5 = 40 each (analog: buy >= 48 each)',
    '1.30 k: ~20 x the need across two makers', 'AVAIL', 'https://www.digikey.com/en/products/detail/susumu/RG1608N-202-W-T1 ; analog/bom_rows.csv',
    R2 + '; buy now (60 of each value) via JLCPCB global sourcing; analog R2.14: offset 6.24/12.48 mV unchanged, phase margin 51.3/59.9 deg re-verified; LCSC fallbacks RT0603BRD071K3L C705738 / RT0603BRD07680RL C861519 / RT0603BRD072KL C728588 (0.1 %/25 ppm)')
row('R607, R608, R628-R631, R639', 'YAGEO RT0402BRD07121KL / 115KL / 5K1L (0.1 %, 25 ppm)', 'C852503 / C852488 / C852856', '0402 thin film', 'n/a', 'availability', '-',
    'LCSC out of stock; DigiKey 25,651 (121 k, re-read 25 Sep 2026), 19,542 (115 k), 25,165 (5.1 k) [protection BOM]', 'n/a', 'AVAIL', U2['rt0402'], R2 + '; JLCPCB global sourcing, low risk')
row('Q616, Q617, Q618', 'AOS AO3400A / JSCJ 2N7002', 'C20917 / C8545', 'SOT-23', 'EasyEDA: 1 G, 2 S, 3 D', 'gate voltage on node H', 'VGS +/-12 V (AO3400A), +/-20 V (2N7002) [DS]',
    '-3.8...+4.0 V (N6_H) [protection p05]', '> 8 V', 'OK', 'https://www.aosmd.com/res/datasheets/AO3400A.pdf', R2)
row('PCB', 'JLCPCB 4-layer JLC04161H-7628, 1.6 mm, ENIG, Standard PCBA top side', '-', '80 x 60 mm + 2 x 5 mm rails = 80 x 70 mm', 'layout_package.md', 'assembly limits',
    'Standard PCBA: reflow 240 +/- 5 C, min pitch 0.35 mm, min package 0201, single PCB >= 70 x 70 mm, rails + fiducials necessary [JLCPCB]',
    'finest pitch 0.4 mm (U202); smallest 0402; lowest part limit 250 C (AQV251GA, excluded) / 255 C (USB4105); board 80 x 70 with rails', '+0.05 mm pitch; >= 10 C reflow', 'OK', U2['jlc_cap'], R2)


# ================================================================== R8 round 3 (review fixes, decisions_r8c.md X-1..X-10, 25 Sep 2026)
R3 = 'R8-3 (decisions_r8c)'
for r in rows:   # rows closed or changed by the round-3 decisions
    if r['status'] != 'current':
        continue
    if r['refs'] == 'U501' and r['parameter'] == 'EN+/EN-':
        r['status'] = 'superseded: X-1 - U501 EN+/EN- tied to 5V_ANA_F (VIN), R506/R507/RAIL_EN deleted (power round 3; round-3 row)'
    elif r['refs'].startswith('R506, R508') or r['refs'].startswith('R507, R521'):
        r['status'] = 'superseded: R506/R507 deleted (X-1), R508 = 10 k (X-10); round-3 passives row'
    elif r['refs'].startswith('R303, R305'):
        r['status'] = 'superseded: R305 = 10 k pull-up to DVCC with Q207 open-drain (X-7); round-3 row'
    elif r['refs'].startswith('U403, U404 (DAC reset state)'):
        r['status'] = 'superseded: OPA2210 now on VPOS_IV/VNEG_IV behind D411/D412 (X-8); round-3 row'
for r in rows:
    if r['refs'] == 'R601-R604':
        r['status'] = 'superseded: R601-R604 = 115 k (protection X-9, round 3); power < 0.2 mW'
U3 = dict(
    pmeg='https://assets.nexperia.com/documents/data-sheet/PMEG2010AEH.pdf (v.5, 8 Oct 2024) ; https://www.lcsc.com/product-detail/C110921.html',
    t520='https://www.digikey.com/en/products/detail/kemet/T520D227M006ATE015/3760616 ; https://www.lcsc.com/product-detail/C3018564.html (KEMET spec sheet)',
    blm='https://www.digikey.com/en/products/detail/murata-electronics/BLM15PX330SN1D (analog BOM)',
    lvc3g34='https://assets.nexperia.com/documents/data-sheet/74LVC3G34.pdf ; https://jlcpcb.com/partdetail/C548774',
    ao3400='https://www.aosmd.com/res/datasheets/AO3400A.pdf',
    smdj='https://www.littelfuse.com/products/overvoltage-protection/tvs-diodes/surface-mount/smdj/smdj12a ; https://www.digikey.com/en/products/detail/littelfuse-inc/SMDJ12A/1835309 ; https://jlcpcb.com/partdetail/Littelfuse-SMDJ12A/C224063',
    tlv3402='https://www.ti.com/product/TLV3402/part-details/TLV3402IDGKR ; https://www.lcsc.com/product-detail/C140314.html ; ../protection/ds/TLV3402_ti_ec.txt',
    aup17='https://jlcpcb.com/partdetail/Nexperia-74AUP1G17GW125/C545626 ; ../protection/ds/74AUP1G17_nexperia_extract.txt',
    bas70='https://www.lcsc.com/product-detail/C389351.html ; https://www.digikey.com/en/products/detail/nexperia-usa-inc/BAS70-04-215/763209',
)
# ---------------- analog X-8: separate I/V supplies (D411/D412 + C442/C443)
vf30 = 220 + 70 * math.log10(3.0)          # [CALC] log interpolation of the 25 C maxima 220 mV/10 mA, 290 mV/100 mA
vf30_0c = vf30 + 25 * 1.5                  # [ASSUMP] -1.5 mV/K typical Schottky tempco (Nexperia gives 25 C maxima only)
row('D411, D412 (analog X-8)', 'Nexperia PMEG2010AEH,115', 'C110921', 'SOD123F 2.6 x 1.6 x 1.1 mm', 'Nexperia DS v.5 Table 2: 1 K (cathode, band), 2 A (analog netlist: D411 A=VPOS K=N4_VPOS_IV; D412 A=N4_VNEG_IV K=VNEG)',
    'VF at the I/V supply current (0 C corner)', 'VF max 220 mV at 10 mA, 290 mV at 100 mA, 430 mV at 1 A, 25 C only [DS Table 7]; analog model uses VF <= 0.30 V at 30 mA over 0-50 C',
    f'30 mA: {vf30:.0f} mV max at 25 C [CALC log interpolation]; 0 C: ~{vf30_0c:.0f} mV [ASSUMP -1.5 mV/K]', f'{300 - vf30_0c:.0f} mV to the 0.30 V model value', 'THIN', U3['pmeg'],
    R3 + '; the OPA2210 CM upper margin is 0.283 V at VF 0.30 V (analog r3_fixes) -> margin is not VF-critical; [MEAS] VPOS - VPOS_IV at 0 C and full signal at bring-up')
row('D411, D412 (analog X-8)', 'Nexperia PMEG2010AEH,115', 'C110921', 'SOD123F', 'see above', 'reverse voltage / leakage / surge',
    'VR 20 V; IR max 50 uA at 5 V, 25 C (typ 15); IFRM 7 A (1 ms); IFSM 9 A (8 us); Ptot 375 mW; Tj 150 C [DS]',
    'reverse only during hold-up: <= 3.9 V; IR at 50 C ~ 50 uA x 2^2.5 = 0.28 mA [ASSUMP doubling per 10 K] vs 1 mA in the analog model; start-up charge current <= 206 mA (264 uF, 10 ms ramp) -> ~0.33 V x 0.21 A = 68 mW for <= 10 ms',
    '> 80 %', 'OK', U3['pmeg'], R3 + '; Cd 70 pF max (5 V) irrelevant on a supply path')
row('D411, D412 (analog X-8)', 'Nexperia PMEG2010AEH,115', 'C110921', 'SOD123F', 'see above', 'reflow / MSL / availability',
    'Nexperia SOD123F: reflow soldering per IPC/JEDEC J-STD-020 (260 C class) [DS section 13, figure only]; MSL 1 [ASSUMP: Nexperia discretes]',
    'JLCPCB Standard 240 +/- 5 C; LCSC C110921 11,165 (13 Jun 2026 page), JLCPCB library 0 (28 Jul 2026 page) -> JLCPCB pre-order from LCSC stock; analog BOM says "global sourcing"',
    'n/a', 'OK', U3['pmeg'], R3 + '; JLCPCB Extended, "fixture needed" note on the part page; buy 15 now (2 per board x 5 + 5); NOT the JSMSEMI "PMEG2010AEH,115-JSM" (C53114153, SOD-123 not SOD123F, wave-solder listing)')
row('C442, C443 (analog X-8)', 'KEMET T520D227M006ATE015 (220 uF 6.3 V polymer tantalum)', 'C3018564', 'D 7343 (7.3 x 4.3 mm, H 2.8 +/- 0.3 mm = 3.1 mm max)', 'polarised: + band; C442 + to N4_VPOS_IV, C443 + to GND (- to N4_VNEG_IV) (analog netlist)',
    'voltage / derating / leakage', '6.3 V (105 C); KEMET T520 derating: apply <= 90 % of rated for <= 10 V parts [ASSUMP from the KEMET derating guideline, not re-read]; DCL <= 138.6 uA (0.1 CV, 25 C, 5 min) [KEMET spec]',
    '<= 3.9 V (VPOS_IV / |VNEG_IV| max) = 62 % of rated; DCL at 3.9 V well below the 6.3 V limit [ASSUMP]', '28 % below the 90 % derating line', 'OK', U3['t520'],
    R3 + '; ESR 15 mOhm, ripple 3.9 A rms (45 C) >> I/V ripple; power budget: add <= 0.14 mA per rail for DCL [ASSUMP 25 C limit at rated V]')
row('C442, C443 (analog X-8)', 'KEMET T520D227M006ATE015', 'C3018564', 'D 7343-31', 'see above', 'reflow / MSL / height / availability',
    'MSL 3 (168 h) [DigiKey/KEMET]; KEMET T520 reflow 260 C peak class; shelf life 52 weeks; height 3.1 mm max',
    'JLCPCB Standard 240 +/- 5 C, parts baked by JLCPCB when MSL >= 3 exposure is exceeded; DigiKey 9,494 (4 Sep 2026, 27-week factory lead); LCSC C3018564 53 (Nov 2025 page)',
    'n/a', 'AVAIL', U3['t520'], R3 + '; buy 15 now (2 per board x 5 + 5) via JLCPCB global sourcing or LCSC; polarity = gate G-4; 3.1 mm body: keep >= 1 mm from the TLP3545A (3.65 mm) and out of the J701/J702 plug path')
c439 = 2.2 * 0.9 * 0.80 * 0.95 * 0.95
row('C439, C440 (analog X-10)', 'Samsung CL10A225KO8NNNC (2.2 uF 16 V X5R 0603)', 'C23630', '0603', 'n/a', 'voltage / effective C after FB301/FB302',
    '16 V; X5R', f'DVCC / VCCA <= 3.37 V -> {c439:.2f} uF effective [CALC: -10 %, bias 0.80 ASSUMP, -5 % temp, -5 % ageing]; analog resonance Q <= 7.3 with this C', '> 12 V', 'OK', U['samsung'], R3)
row('R305 (analog X-7)', 'UNI-ROYAL 0402WGF1002TCE (10 k)', 'C25744', '0402', 'n/a', 'power', '62.5 mW [DS]', f'{1e3*V33H**2/10e3:.1f} mW while Q207 holds reset (DVCC 3.37 V)', '> 95 %', 'OK', U['uniroyal'], R3 + '; pull-up to DVCC (was 100 k pull-down)')
row('R417-R420 alternate (analog X-10)', 'Murata BLM15PX330SN1D (33 ohm at 100 MHz, fitted only if chosen; default 0 ohm C17168)', '- (global sourcing)', '0402', 'n/a', 'current / DCR / availability',
    '3 A rated, DCR <= 22 mOhm [DS-listing]', '<= 0.3 A leg short bound -> 10 % of rating; DCR adds 22 mOhm to Zout (analog: 0.223/0.327 ohm, PM 51.8 deg)', '> 80 %', 'OK', U3['blm'] + ' ; https://www.lcsc.com/product-detail/C160974.html',
    R3 + '; LCSC C160974 22,900 (Mar 2026 page; 196,600 in Jan 2026), DigiKey 0 (10,000 due 2 Oct 2026); -55..125 C, H 0.55 mm; approved alternate, default 0 ohm (JLCPCB Basic) - order only if fitted')
v_iv = 3.915 - 0.15
row('U403, U404 (DAC reset state, round 3)', 'TI OPA2210IDR on VPOS_IV/VNEG_IV', 'C1849415', 'SOIC-8', 'TI SBOS924H; analog netlist: pin 8 N4_VPOS_IV, pin 4 N4_VNEG_IV (X-8)', 'output swing / CM range with the D411/D412 drop',
    'VO (V+)-0.6 V at 600 ohm (25 C); input CM to (V+)-1.5 V [DS as used by analog]',
    'VF 0.30 V: VPOS_IV >= 3.489 V -> swing limit 2.889 V < reset-state target 2.907-3.369 V (saturates, harmless: DAC pin 1.46-1.62 V, switch open); CM limit 1.989 V vs VREF 1.706 V [analog r3_fixes]',
    'CM +0.283 V (was +0.583 V)', 'OK', U['opa2210'], R3 + '; protection: reset-state CM minimum becomes 2.889 V (analog r3_fixes line 4), still > CMTH_HI 2.151 V by 0.74 V')
# ---------------- digital X-6/X-7/X-10
row('U208 (digital X-7)', 'Nexperia 74LVC3G34DC,125', 'C548774', 'VSSOP-8 (SOT765-1), 0.5 mm pitch', 'Nexperia 74LVC3G34 Rev 16 DC pinning: 1 1A, 2 3Y, 3 2A, 4 GND, 5 2Y, 6 3A, 7 1Y, 8 VCC (digital netlist, checked)',
    'supply / inputs with VCC = 0', 'VCC 1.65-5.5 V; VI 0-5.5 V; IOFF +/-2 uA at VCC = 0 (VI/VO 0-5.5 V) [DS]',
    f'VCC = 3V3D <= {V33H:.2f} V; inputs from the 3V3M MCU (<= {V33H:.2f} V) also while 3V3D is off -> IOFF <= 2 uA per pin, no back-power of 3V3D', '> 2 V', 'OK', U3['lvc3g34'],
    R3 + '; tpd 0.5-4.1 ns (3.0-3.6 V, -40..85 C) used in the digital link timing (setup +1.13 ns at 36 MHz writes)')
row('U208 (digital X-7)', 'Nexperia 74LVC3G34DC,125', 'C548774', 'VSSOP-8', 'see above', 'MSL / availability',
    'MSL 1 [JLCPCB]; JLCPCB Extended, "Economic and Standard", fixture note', 'LCSC 1,604 (25 Sep 2026); JLCPCB 188 (May 2026 page); DigiKey 0 (3,000 due 21 Sep), Mouser 0 (Feb 2027)',
    'n/a', 'AVAIL', U3['lvc3g34'], R3 + '; buy 10 now into the JLCPCB library; 0.5 mm pitch >= 0.35 mm Standard minimum')
row('Q207 (digital X-7)', 'AOS AO3400A', 'C20917', 'SOT-23', 'digital netlist: 1 G N2_RESET_DRV, 2 S GND, 3 D DAC_RESETB', 'VDS / VGS / current',
    'VDS 30 V; VGS +/-12 V; VGS(th) 0.65-1.45 V; RDS(on) <= 48 mOhm at 2.5 V [DS]',
    f'VDS <= DVCC {V33H:.2f} V; VGS <= 3V3M {V33H:.2f} V (PA8, R240 100 k pull-up); ID 0.34 mA -> VOL < 1 mV', '> 8 V', 'OK', U3['ao3400'], R3 + '; JLCPCB Basic')
row('R236-R241, C224 (digital round 3)', 'UNI-ROYAL 0402WGF 10 k / 4.7 k / 100 k / 0 R (R241 DNF); Samsung CL05B104KO5NNNC', 'C25744 / C25900 / C25741 / C17168 / C1525', '0402', 'n/a', 'power / voltage',
    '62.5 mW; 16 V (C224)', f'<= {1e3*V33H**2/4.7e3:.1f} mW (R237 with PC10 high into a shorted AUD_EN, fault bound); <= 3.37 V on C224', '> 90 %', 'OK', U['uniroyal'], R3 + '; all JLCPCB Basic')
# ---------------- power X-1..X-5, X-10
row('D102 (power X-3)', 'Littelfuse SMDJ12A', 'C224063 (JLCPCB/LCSC)', 'SMC / DO-214AB (~7.9 x 6.0 x 2.6 mm), unidirectional', 'power netlist: pin 1 = K (band) VBUS, pin 2 = A GND; <= 5 mm from J101',
    'stand-off / clamp', 'VRWM 12 V; VBR 13.3-14.7 V at 1 mA; VC 19.9 V at 150.8 A (10/1000 us); 3000 W; dVBR 0.1 %/K [DS Littelfuse]',
    f'VBUS {VBUS_MAX:.2f} V steady (5 V ringing <= 11 V: no conduction); 9 V mis-set source ringing <= 18.9 V clamped; U102 IN <= 17.0 V at a 5V_SYS hard short, no tIOS credit [power c16 C] vs TPS25200 IN 20 V abs',
    '+6.5 V to VRWM; +3.0 V to U102 abs', 'OK', U3['smdj'], R3 + '; energy a few mJ in < 10 us << 3000 W (power c16)')
row('D102 (power X-3)', 'Littelfuse SMDJ12A', 'C224063', 'SMC', 'see above', 'leakage at 5.5 V / 50 C',
    'IR <= 2 uA at 12 V, 25 C only [DS]', 'at 5.5 V (46 % of VRWM) and 50 C: <= 8 uA [ASSUMP x4 for temperature, no credit for the lower voltage] -> USB suspend budget 2.5 mA unaffected', 'n/a', 'OK', U3['smdj'],
    R3 + '; [MEAS] VBUS current in suspend at 50 C covers it')
row('D102 (power X-3)', 'Littelfuse SMDJ12A', 'C224063', 'SMC', 'see above', 'reflow / MSL / availability',
    'MSL 1 [DigiKey]; Littelfuse SMD TVS lead-free reflow, peak 260 C class [DS; profile figure not re-read]',
    'JLCPCB Standard 240 +/- 5 C; JLCPCB C224063 115 in stock on the Sep 2025 page ("fixture needed"); LCSC C224063 out of stock (Jan 2025 page); power BOM: "LCSC not verified" -> use C224063 in the JLCPCB BOM; DigiKey 5,498 (8 Sep 2026), 34-week factory lead; LGE SMDJ12A C5806873 (915, Apr 2026) is an Asian second source NOT approved (different maker data)',
    'n/a', 'AVAIL', U3['smdj'], R3 + '; buy 10 now (JLCPCB library if the C224063 stock is still there, else global sourcing from DigiKey); cathode band = gate G-4')
row('C104 (power X-2)', 'Samsung CL05B104KO5NNNC (100 nF 16 V X7R 0402)', 'C1525', '0402', 'n/a', 'voltage / delay',
    '16 V', 'EN steady = VBUS <= 5.5 V (EN Zener clamp ~6.4 V on a 20 V fault); earliest U102 turn-on 2.24 ms with -10 %/-15 %/-5 % ageing [power c16 B]', '> 9 V', 'OK', U['samsung'], R3 + '; place at U102 pin 4')
row('C103, C516 (power X-5/X-10)', 'Samsung CL05C101JB5NNNC (100 pF 50 V C0G 0402)', 'C1546', '0402', 'n/a', 'voltage', '50 V C0G', '<= 1.8 V (VBUS_SENSE, ANA_SENSE)', '> 48 V', 'OK', U['samsung'], R3 + '; JLCPCB Basic')
row('R535, R536, R508 (power X-5/X-10)', 'UNI-ROYAL 0402WGF6812TCE 68.1 k / 0402WGF3012TCE 30.1 k / 0402WGF1002TCE 10 k (1 %)', 'C11537 / C29402 / C25744', '0402', 'n/a', 'power',
    '62.5 mW', f'{1e3*5.55**2/98.2e3:.2f} mW (divider at 5.55 V); R508 {1e3*2.3**2/10e3:.2f} mW (AUD_EN 2.3 V)', '> 95 %', 'OK', U['uniroyal'], R3 + '; ANA_SENSE <= 1.725 V at PA0 (power c16 D); C11537 and C29402 are JLCPCB Extended (9,921 / 60,726 available, 23 Sep 2026 pages) - power BOM had no LCSC code')
row('U501 (power X-1)', 'TI LM27762DSSR', 'C473398', 'WSON-12', 'TI SNVSAF7C', 'EN+/EN- tied to VIN (5V_ANA_F)', 'EN+/EN- -0.3 V ... VIN + 0.3 V abs [DS]',
    'EN = VIN at every instant (same net) -> 0 V difference; RAIL_EN, R506, R507 deleted', 'n/a', 'OK', U['lm27762'], R3 + '; the U503 (TPS2596) output enables the rails')


# ---------------- power X-4: Schottky OUT->IN clamps (power BOM 25 Sep 08:57)
U3['bat54'] = 'https://www.nexperia.com/product/BAT54 (Cd 10 pF max at 1 V, IR 2 uA max at 25 V) ; https://jlcpcb.com/partdetail/Nexperia-BAT54215/C85084'
row('D103, D104, D105 (power X-4)', 'Nexperia BAT54,215', 'C85084', 'SOT23 (TO-236AB)', 'Nexperia BAT54 SOT23: 1 anode, 2 n.c., 3 cathode (power BOM: pin 1 A = regulator OUT, 3 K = IN)',
    'reverse voltage / forward current', 'VR 30 V; IF 200 mA; IFSM 600 mA; VF max 0.24/0.32/0.40/0.50/0.80 V at 0.1/1/10/30/100 mA [DS]',
    'reverse <= 5.55 V (regulator off, OUT discharged: D104 3V3A, D105 5V_ANA in suspend); forward only at a collapse, peak current per power c14 section 6', '> 24 V', 'OK', U3['bat54'],
    R3 + '; JLCPCB Extended, Economic + Standard, MSL 1; JLCPCB 202,689 (18 Aug 2026 page), LCSC 133,300 (3 Sep 2026) -> no pre-buy needed; each <= 3 mm from its regulator')
row('D103, D104, D105 (power X-4)', 'Nexperia BAT54,215', 'C85084', 'SOT23', 'see above', 'reverse leakage at 50 C (suspend budget)',
    'IR max 2 uA at 25 V, 25 C only [DS]; no maximum at 5.5 V / 50 C',
    'power c17 counts 0.010 mA for all Schottky diodes at 50 C [X-4 bound]; parts estimate: 2 uA x 5.7 (doubling per 10 K, 25 -> 50 C) x 0.5 (5.5 V vs 25 V) = 5.7 uA per diode at 5.5 V -> ~12 uA for D104 + D105 at 5.5 V and D103 at 2.3 V [ASSUMP]',
    'estimate exceeds the 10 uA bound by ~2 uA', 'DATA-GAP', U3['bat54'],
    R3 + '; suspend S6 already fails on placeholders (power c17, L-1) -> [MEAS] the three diodes at 50 C on the first board (VBUS current in suspend with/without D104/D105 fitted); typical IR is 10-100 x lower than the maximum')


# ---------------- protection X-6/X-9 (protection BOM/netlist 25 Sep 09:02)
U3['tlv3402d'] = 'https://www.lcsc.com/product-detail/C91242.html ; https://www.ti.com/product/TLV3402 ; ../protection/ds/TLV3402_ti_ec.txt'
U3['bas70'] = 'https://www.lcsc.com/product-detail/C389351.html ; https://jlcpcb.com/partdetail/Nexperia-BAS70215/C109295 ; https://www.digikey.com/en/products/detail/nexperia-usa-inc/BAS70-04-215/763209'
U3['aup17dk'] = 'https://www.digikey.com/en/products/detail/nexperia-usa-inc/74AUP1G17GW-125/1022837 ; https://www.lcsc.com/product-detail/C545626.html'
row('U605 (protection X-6)', 'TI TLV3402IDR', 'C91242', 'SOIC-8 (D)', 'TI TLV340x dual: 1 OUT1, 2 IN1-, 3 IN1+, 4 GND, 5 IN2+, 6 IN2-, 7 OUT2, 8 VCC (protection netlist, checked)',
    'supply / inputs / open-drain output', 'VCC 2.5-16 V (2.7 V min over -40..125 C); inputs -0.1 V ... VCC + 5 V (max 20 V); VOL <= 0.3 V at 50 uA; IQ <= 0.95 uA/ch [DS / protection ds extract]',
    f'VCC = 3V3M {V33L:.2f}-{V33H:.2f} V (+0.53 V over 2.7 V); inputs = 3V3A x 0.80 (R675/R676) and 3V3M x 0.75 (R677/R678) <= 2.7 V, also valid with 3V3A > 3V3M; outputs pulled up by R680/R687 100 k into the Q619/Q620 gates', '> 0.5 V (VCC min)', 'OK', U3['tlv3402d'],
    R3 + '; 3V3M load <= 1.9 uA + dividers; R679/R686 22 M hysteresis -> keep the IN+ nodes clean (see layout_package.md high-impedance rule)')
row('U605 (protection X-6)', 'TI TLV3402IDR', 'C91242', 'SOIC-8', 'see above', 'MSL / availability / lifecycle',
    'MSL 1-260C-UNLIM (TI); TI part page: "available for existing designs; for new designs, we recommend considering an alternate"',
    'LCSC C91242 745 in stock (read 25 Sep 2026); DigiKey TLV3402 active (9-week lead)', 'n/a', 'AVAIL', U3['tlv3402d'],
    R3 + '; buy 10 now (lifetime buy for this build); candidate for a later redesign: TI TLV7042 (dual nanopower open-drain) - not evaluated')
row('U606 (protection X-6)', 'TI TLV1704AIPWR', 'C181596', 'TSSOP-14 (PW)', 'TI pin table (as U601-U603); protection netlist: ch1 1V3 good, ch2 MCLK alive, ch3 3V3A repeater, ch4 spare (4IN- = VNEG, 4IN+ = GND, 4OUT pad unconnected)',
    'supply / inputs / outputs', 'VS 2.2-36 V; inputs V- ... V+ (+/-10 mA abs); open collector 36 V above V-; IQ <= 100 uA/ch (-40..125 C) [DS]',
    f'VS <= {VSPAN2:.2f} V; inputs through R670 10 k (1V3), R667 100 k (pump node <= 3.2 V), R681 4.7 M (U605 output); unpowered injection <= 32 uA [protection p10]; outputs on N6_H', '> 28 V', 'OK', U2['tlv1704'],
    R3 + '; VPOS/VNEG +0.40 mA per rail (4 x 100 uA) + 16.1 uA dividers [protection p10] -> power D-9 budget line must grow by this; pin 13 (4OUT) keeps its pad (no trace) - "no copper" in the netlist note means no trace')
row('U607 (protection X-6)', 'Nexperia 74AUP1G17GW,125', 'C545626', 'TSSOP-5 (SOT353-1) 0.65 mm', 'Nexperia 74AUP1G17GW: 1 n.c., 2 A, 3 GND, 4 Y, 5 VCC (protection netlist, checked; pin 1 keeps its pad)',
    'supply / input / output load', 'VCC 0.8-3.6 V; VI -0.5...4.6 V abs, Ioff; IOH/IOL 4 mA at 3.0 V; CI 1.1 pF typ (no maximum); ICC 0.9 uA [DS / protection extract]',
    f'VCC = 3V3D <= {V33H:.2f} V (0.23 V under the 3.6 V recommended maximum); input via R665 1 k from MCLK (<= 3V3D); pump C624 100 pF -> effective load 4.77 pF; supply 3.36 mA at 80 MHz with CPD <= 6 pF [protection p10, ASSUMP]', '+0.23 V to VCC max', 'OK', U3['aup17dk'],
    R3 + '; 3V3D budget +3.36 mA (power c17 still carries the X-6 placeholder 1 mA on 3V3M -> power to move it to 3V3D); input toggling with the Kyocera 4.5 ns maximum edges is NOT provable from datasheet limits (protection p10: a missed toggle reads "dead" = switch open, safe) -> [MEAS] at bring-up; keep the R665-U607 input trace <= 3 mm (C_in)')
row('U607 (protection X-6)', 'Nexperia 74AUP1G17GW,125', 'C545626', 'SOT353-1', 'see above', 'MSL / availability', 'MSL 1 [DigiKey, JLCPCB]; JLCPCB Extended, Economic and Standard',
    'LCSC C545626 out of stock (25 Sep 2026); DigiKey 66,948 (25 Sep 2026), 20-week factory lead', 'n/a', 'AVAIL', U3['aup17dk'], R3 + '; buy 10 now via JLCPCB global sourcing')
row('R665 (protection X-6)', 'UNI-ROYAL 0402WGF1001TCE (1 k)', 'C11702', '0402', 'protection netlist: pin 1 MCLK at the U301 XI pin, pin 2 N6_MCK_IN', 'MCLK load added at XI',
    'X-6: <= 1.5 pF added; Kyocera load <= 15 pF', 'through 1 k the U607 input appears as <= 0.99 pF at 80 MHz + <= 0.3 pF pad/stub = 1.29 pF; MCLK total 13.1 + 1.29 = 14.4 pF [protection p10]', '0.21 pF / 0.6 pF', 'THIN',
    'https://www.lcsc.com/product-detail/C11702.html', R3 + '; the 0.3 pF pad/stub share is a LAYOUT requirement: R665 pad on the XI trace itself (T-stub <= 0.5 mm), <= 1.5 mm from U301 pin 7, no via on the stub (layout_package.md)')
row('D609 (protection X-6)', 'Nexperia BAS70-04,215', 'C389351', 'SOT23', 'Nexperia BAS70-04: 1 a1, 2 k2, 3 k1/a2 (protection netlist: 1 GND, 2 N6_MCK_RC, 3 N6_PMP; checked)',
    'reverse voltage / current / capacitance', 'VR 70 V; IF 70 mA; IFSM 100 mA; VF <= 410 mV at 1 mA, <= 1 V at 15 mA; Cd <= 2 pF [DS-listing]',
    'VR <= 3.4 V; pump current limited by the U607 output (<= 4 mA class, peaks of a few mA into C624 100 pF); steady state ~ node/R666 = 3 uA', '> 60 V', 'OK', U3['bas70'],
    R3 + '; MSL 1; LCSC 36,430 (9 Sep 2026) -> stocked')
row('D610 (protection X-6)', 'Nexperia BAS70,215', 'C109295', 'SOT23', 'Nexperia BAS70: 1 A, 2 n.c., 3 K (protection netlist: 1 N6_V13_TI, 2 NC, 3 N6_V13_TEST)', 'availability',
    'VR 70 V, IF 70 mA [DS-listing]', 'LCSC C109295 out of stock (Apr 2026 page); JLCPCB 9 available (Feb 2026 page)', 'n/a', 'AVAIL', U3['bas70'],
    R3 + '; drop-in proposal to protection: BAS70-04,215 (C389351, same SOT23 footprint): pin 1 a1 -> pin 3 k1 is the same diode, pin 3 -> pin 2 (k2) floats on the NC pad; else global sourcing of BAS70,215')
row('Q619, Q620 (protection X-6)', 'AOS AO3400A', 'C20917', 'SOT-23', 'protection netlist: 1 G N6_V3AG_A/B, 2 S GND, 3 D N2_AVCC_EN_G / AUD_EN', 'VDS / VGS', 'VDS 30 V; VGS +/-12 V [DS]',
    f'VDS <= {V33H:.2f} V; VGS <= 3V3M {V33H:.2f} V (R680/R687 100 k pull-ups)', '> 8 V', 'OK', U3['ao3400'], R3 + '; JLCPCB Basic')
row('C624, C625, C629 (protection X-6)', 'Samsung CL05C101JB5NNNC / CL05C820JB5NNNC / CL05C102JB5NNNC (C0G 50 V 0402)', 'C1546 / TBC / TBC', '0402', 'n/a', 'voltage', '50 V C0G',
    '<= 3.4 V (pump nodes, 1V3 filter)', '> 46 V', 'OK', U['samsung'], R3 + '; 82 pF and 1 nF LCSC codes not verified by parts (protection BOM "TBC"); C0G: no DC-bias or ageing term')
row('R666-R689, R601-R604 (protection round 3)', 'UNI-ROYAL 0402WGF (1 %) / YAGEO RT0402BRD (0.1 %)', 'see protection BOM', '0402', 'n/a', 'power / voltage', '62.5 mW; 50 V',
    '<= 0.12 mW (R674 2.2 k at 0.5 V worst); all nodes <= 4.0 V', '> 99 %', 'OK', U['uniroyal'],
    R3 + '; availability: RT0402BRD07237KL C852654 (LCSC 7,520, 21 Sep 2026); RT0402BRD07866KL / 953KL / 330KL / 071ML: no LCSC listing found -> global sourcing (DigiKey/Mouser YAGEO RT); 0402WGF2205TCE 22 M: LCSC C407703 out of stock (Jun 2026) -> global sourcing or RC0402FR-0722ML; 1 % thick-film values are JLCPCB Basic/Extended')
row('R679, R686, R681, R666, R678, R685 (protection X-6)', '22 M / 4.7 M / 1 M resistors at comparator inputs', 'see protection BOM', '0402', 'n/a', 'board leakage vs node impedance',
    'no datasheet limit (board property)', '22 M hysteresis and 4.7 M/1 M nodes: 1 nA of surface leakage = 22 mV at 22 M [CALC]; flux residue / humidity can reach 1-100 G ohm paths [ASSUMP]', 'n/a', 'THIN', '-',
    R3 + '; layout: >= 0.5 mm clearance to other nets, mask between pads, no vias under the parts, guard ring optional; DFA: ask JLCPCB for board cleaning (no-clean residue) - [MEAS] thresholds at 50 C / high humidity on one board')


# ---------------- analog R3.12 (25 Sep 09:23): C442/C443 -> KEMET T495D227K010ATE100 (MnO2, surge robust); PMEG2010AEH corners
for r in rows:
    if 'T520D227' in r['mpn'] and r['status'] == 'current':
        r['status'] = 'superseded: C442/C443 = KEMET T495D227K010ATE100 MnO2 surge-robust (analog R3.12, 09:23)'
    if r['refs'].startswith('D411, D412') and r['parameter'].startswith('VF at the I/V supply current') and r['status'] == 'current':
        r['status'] = 'superseded: corner table row below (analog R3 open item answered 09:30)'
U3['t495'] = 'https://www.digikey.com/en/products/detail/kemet/T495D227K010ATE100/3880200 ; https://www.lcsc.com/product-detail/C212677.html ; https://content.kemet.com/datasheets/KEM_T2009_T495.pdf (PDF too large for the tool, not read)'
U3['tpsd'] = 'https://www.digikey.com/en/products/detail/kyocera-avx/TPSD227K010R0100/929954'
dcl25 = 0.01 * 220 * 10                      # uA, 0.01 CV at rated voltage, 25 C, 5 min
k50 = 10 ** (25 / 60)                        # [ASSUMP] log interpolation of the x1 (25 C) ... x10 (85 C) limits
row('C442, C443 (analog R3.12)', 'KEMET T495D227K010ATE100 (220 uF +/-10 %, 10 V, MnO2, surge robust); alt. Kyocera AVX TPSD227K010R0100', 'C212677 (LCSC out of stock)',
    'D 7343-31 (7.3 x 4.3 x 2.8 mm, 3.10 mm max)', 'polarised: + band; C442 + to N4_VPOS_IV, C443 + to GND (analog netlist 09:23)',
    'voltage / derating / reverse voltage', '10 V rated (85 C), -55..125 C; MnO2 practice: apply <= 50 % of rated in low-impedance circuits [KEMET/AVX derating guides, not re-read]; small reverse voltage only (series convention ~10 % of rated at 25 C, ~3-5 % at 85 C) [ASSUMP, not re-read]',
    '<= 3.9 V = 39 % of rated; reverse bounded by the D411/D412 forward drop (<= ~0.26 V at 0 C, few mA) during ramps = 2.6 % of rated [CALC]', '11 % below the 50 % line; reverse 2.6 % vs ~5 %', 'OK', U3['t495'],
    R3 + '; charge current <= 206 mA at a 10 ms ramp (analog r3_fixes) - gentle for a 100 % surge-tested T495; ESR 100 mOhm x 30 mA = 3 mV (hold-up unaffected)')
row('C442, C443 (analog R3.12)', 'KEMET T495D227K010ATE100', 'C212677', 'D 7343-31', 'see above', 'DC leakage (budget)',
    f'DCL <= 0.01 CV = {dcl25:.0f} uA at 10 V, 25 C, 5 min [KEMET listing: 22 uA]; x10 at +85 C, x12.5 at +125 C = KEMET/AVX MnO2 convention [not re-read in the T495 PDF]',
    f'50 C: x{k50:.1f} (log interpolation 25 -> 85 C) = {dcl25*k50:.0f} uA per capacitor at RATED voltage [CALC]; at 3.9 V (39 %) the leakage is a fraction of that [no credit taken]', f'<= {dcl25*k50:.0f} uA per rail vs >= 13 mA I/V load (< 0.5 %)', 'OK', U3['t495'],
    R3 + '; analog assumption (0.01 CV, x10 at 85 C) is consistent; budget item for power <= 0.06 mA per rail (upper bound)')
row('C442, C443 (analog R3.12)', 'KEMET T495D227K010ATE100; alt. AVX TPSD227K010R0100', 'C212677', 'D 7343-31', 'see above', 'capacitance / reflow / MSL / availability',
    '+/-10 % (K); MSL 1 (DigiKey KEMET and AVX pages; Buerklin: "series classified MSL 1"); 260 C J-STD-020 class [ASSUMP, profile not re-read]; height 3.10 mm max (both makers)',
    '198-242 uF at 25 C, about -5 % at 0 C [ASSUMP MnO2 typical] -> >= 188 uF >= the 120 uF effective analog needs; KEMET: DigiKey 3,860 (3 Sep 2026), 24-week lead, Buerklin 600, LCSC C212677 out of stock (Jun 2026 page); AVX TPSD227K010R0100: DigiKey 1,534 (25 Sep 2026), 13-week lead, MSL 1',
    '>= 68 uF over the need', 'AVAIL', U3['t495'] + ' ; ' + U3['tpsd'],
    R3 + '; same KEMET/AVX D-case land as the T520D (no footprint change); MSL 1 removes the polymer bake note; buy 15 now via JLCPCB global sourcing (either maker; both on the BOM line as approved)')
# PMEG2010AEH corner table (maker gives 25 C maxima only)
vf10, vf30 = 220.0, 220 + 70 * math.log10(3.0)
tc_lo, tc_hi = 1.5, 1.8                      # mV/K magnitude [CALC diode equation, EG 0.60-0.69 eV, XTI 2, typical]
c0 = f'0 C: 10 mA {vf10 + 25*tc_lo:.0f}-{vf10 + 25*tc_hi:.0f} mV, 30 mA {vf30 + 25*tc_lo:.0f}-{vf30 + 25*tc_hi:.0f} mV'
c50 = f'50 C: 10 mA {vf10 - 25*tc_hi:.0f}-{vf10 - 25*tc_lo:.0f} mV, 30 mA {vf30 - 25*tc_hi:.0f}-{vf30 - 25*tc_lo:.0f} mV'
row('D411, D412 (analog X-8, corners)', 'Nexperia PMEG2010AEH,115', 'C110921', 'SOD123F', 'Nexperia DS v.5: 1 K, 2 A', 'VF at 10-30 mA over 0-50 C / IR at 50 C',
    'VF max 220 mV (10 mA), 290 mV (100 mA), 25 C only; IR max 50 uA at 5 V, 25 C only [DS Table 7]; temperature data typical graphs only',
    f'25 C: 10 mA 220 mV, 30 mA {vf30:.0f} mV [log interpolation, conservative]; tempco -{tc_lo}...-{tc_hi} mV/K [CALC typical]; {c0}; {c50}; IR at 5 V, 50 C: 50 uA x 2^(25/10...25/8) = 0.28-0.44 mA [ASSUMP doubling per 8-10 K]',
    f'30 mA / 0 C: {300 - (vf30 + 25*tc_hi):.0f}...{300 - (vf30 + 25*tc_lo):.0f} mV below 0.30 V; 10 mA: >= {300 - (vf10 + 25*tc_hi):.0f} mV; IR <= 0.44 mA vs 1 mA modelled', 'THIN', U3['pmeg'],
    R3 + '; the 0.30 V model value is a bound only through the tempco assumption -> [MEAS] VPOS - VPOS_IV at 0 C (cold spray) and full signal on one board; IR at 50 C: [MEAS] with 3.9 V reverse')


# ---------------- VE round (ve/brief_ve.md, 25 Sep 2026): substitutes adopted by the streams (stock/class check by parts)
RV = 'VE (25 Sep 2026)'
for r in rows:
    if r['status'] == 'current' and 'T495D227' in r['mpn']:
        r['status'] = 'superseded: VE - analog C442/C443 = Kyocera AVX TAJD227K010RNJ C8024 (LCSC 44,987)'
    if r['status'] == 'current' and r['refs'].startswith('R641, R642 (protection round 2)'):
        r['status'] = 'superseded: VE - R641/R642 = YAGEO RT0402BRD0724R9L C852667 (LCSC 19,000)'
    if r['status'] == 'current' and r['refs'].startswith('R401-R416, R438-R445 (analog round 2)'):
        r['status'] = 'superseded: VE - legs = YAGEO RT0603BRD071K3L C705738 / RT0603BRD07680RL C861519 / Panasonic ERA-3AEB202V C193242 (analog VE)'
    if r['status'] == 'current' and r['refs'].startswith('U208 (digital X-7)') and 'availability' in r['parameter'].lower():
        r['status'] = 'superseded: VE - U208 = TI SN74LVC3G34DCUR C130024 (LCSC 550)'
row('C442, C443 (analog VE)', 'Kyocera AVX TAJD227K010RNJ (220 uF +/-10 %, 10 V, MnO2, ESR 0.5 ohm)', 'C8024', 'D 7343-31', 'polarised; nets as before', 'voltage / DCL / stock',
    '10 V; MnO2 practice <= 50 % of rated [AVX/KEMET guides, not re-read]; DCL 0.01 CV = 22 uA (25 C) [series convention]',
    '3.9 V = 39 %; reverse <= Schottky drop ~0.26 V; charge current <= 206 mA over >= 10 ms (low dV/dt); ESR 0.5 ohm x 30 mA = 15 mV (analog re-verified hold-up)',
    '11 % below the 50 % line', 'OK', 'https://www.lcsc.com/product-detail/C8024.html (analog BOM: LCSC 44,987, 25 Sep 2026)',
    RV + '; JLCPCB Extended; stocked -> no global sourcing; not surge-robust grade: acceptable because the rails ramp (no hot-plug surge on this node)')
row('R401-R416, R438-R445 (analog VE)', 'YAGEO RT0603BRD071K3L / RT0603BRD07680RL (0.1 %, 25 ppm) / Panasonic ERA-3AEB202V (0.1 %, 25 ppm)', 'C705738 / C861519 / C193242', '0603 thin film', 'n/a',
    'availability', '-', 'LCSC 100 (1.30 k, min/multiple 20) / 8,000 / 12,500 (analog BOM 25 Sep 2026); need 40 each + attrition', '1.30 k: 2.5 x the need', 'AVAIL', 'analog/bom_rows.csv',
    RV + '; pre-order the 1.30 k now into the private library (the only thin one); offset/CMRR re-verified by analog')
row('R641, R642 (protection VE)', 'YAGEO RT0402BRD0724R9L (24.9 R 0.1 %)', 'C852667', '0402 thin film', 'n/a', 'availability / power', '62.5 mW', '(6.6 mA)^2 x 24.9 = 1.1 mW; LCSC 19,000 (23 Sep 2026)', '> 95 %', 'OK', 'protection/bom_rows.csv', RV)
row('U208 (digital VE)', 'TI SN74LVC3G34DCUR (VSSOP-8 DCU)', 'C130024', 'VSSOP-8 0.5 mm', 'TI DCU pinning = Nexperia DC (digital checked)', 'Ioff / stock', 'Ioff 10 uA (TI) [digital]', 'LCSC 550 (25 Sep 2026), min/multiple 5', 'n/a', 'OK', 'digital/bom_rows.csv',
    RV + '; skew bound 2.7 ns (digital re-ran the link timing)')


# ---------------- VE final task (orchestrator 11:28): R535/R536 100 k/47 k Basic, D610 BAS70-04, R668/R669 Basic 1 %, 0.1 % LCSC stock re-check
for r in rows:
    if r['status'] != 'current':
        continue
    if r['refs'].startswith('R535, R536, R508 (power X-5/X-10)'):
        r['status'] = 'superseded: VE - R535/R536 = 100 k/47 k UNI-ROYAL Basic C25741/C25792 (power VE)'
    elif r['refs'].startswith('D610 (protection X-6)'):
        r['status'] = 'superseded: VE - D610 = BAS70-04,215 C389351 (protection VE; pin 1 -> 3 same diode, pin 2 floats)'
    elif r['refs'].startswith('R666-R689, R601-R604 (protection round 3)'):
        r['status'] = 'superseded: VE availability row below (R668 1 M 1 % Basic, R669 100 k 1 % Basic; 0.1 % LCSC re-check 25 Sep 2026)'
row('R535, R536, R508 (power VE)', 'UNI-ROYAL 0402WGF1003TCE 100 k / 0402WGF4702TCE 47 k / 0402WGF1002TCE 10 k (1 %)', 'C25741 / C25792 / C25744 (Basic)', '0402', 'n/a', 'power',
    '62.5 mW', f'{1e3*5.55**2/147e3:.2f} mW (divider at 5.55 V); R508 {1e3*2.3**2/10e3:.2f} mW', '> 95 %', 'OK', U['uniroyal'],
    RV + '; ANA_SENSE ratio and source impedance re-verified by power (VE); all JLCPCB Basic')
row('D609, D610 (protection VE)', 'Nexperia BAS70-04,215', 'C389351', 'SOT23', 'D610 on BAS70-04: 1 a1 = N6_V13_TI, 3 k1/a2 = N6_V13_TEST, 2 k2 floats on the NC pad', 'ratings / stock',
    'VR 70 V, IF 70 mA, Cd <= 2 pF', 'VR <= 3.4 V; test-injection current <= 1.5 mA; LCSC 36,430 (9 Sep 2026)', '> 60 V', 'OK', U3['bas70'], RV)
row('R601-R689 0.1 % / 1 % (protection VE)', 'YAGEO RT0402BRD (0.1 %) / UNI-ROYAL 0402WGF (1 %)', 'see protection BOM', '0402', 'n/a', 'availability (LCSC pages 25 Sep 2026)', '-',
    'at LCSC: 237 k C852654 7,520 (min 20); NOT at LCSC: 121 k C852503, 115 k C852488, 5.1 k C852856 (all out of stock, min 50), 953 k / 330 k / 1 M 0.1 % (no LCSC listing found); 22 M 1 % C407703 out of stock; R668 1 M 1 % C26083 and R669 100 k 1 % C25741 are Basic',
    'n/a', 'AVAIL', 'https://www.lcsc.com/product-detail/C852654.html ; C852503 ; C852488 ; C852856',
    RV + '; global sourcing stays for the six 0.1 % values not at LCSC; power in every part < 0.12 mW')

fields = ['refs', 'mpn', 'lcsc', 'package', 'pinout_source', 'parameter', 'rating', 'worst_operating_value', 'margin', 'verdict', 'status', 'source_url', 'note']
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
from collections import Counter
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print(len(rows), len(cur), dict(cnt))

# sourcing clean-up 25 Sep 2026 16:05 (append test)
# ---------------- sourcing clean-up (orchestrator 25 Sep 15:59): drop-ins for lines out of stock at LCSC (appended block; re-writes the outputs)
for r in rows:
    if r['status'] == 'current' and r['refs'].startswith('C624, C625, C629 (protection X-6)'):
        r['status'] = 'superseded: sourcing clean-up - C625 = FH 0402CG820J500NT C45501, C629 C307441 confirmed (row below)'
row('C624, C625, C629 (protection, sourcing)', 'Samsung CL05C101JB5NNNC / FH 0402CG820J500NT / Samsung CL05C102JB5NNNC (C0G 50 V 0402)', 'C1546 / C45501 / C307441', '0402', 'n/a', 'voltage / stock',
    '50 V C0G +/-5 % (all three)', '<= 3.4 V; C45501 LCSC 238,500 / JLCPCB 227,977; C307441 LCSC 29,500 (25 Sep 2026)', '> 46 V', 'OK', 'https://www.lcsc.com/product-detail/C45501.html ; https://www.lcsc.com/product-detail/C307441.html',
    'sourcing clean-up 25 Sep 16:05; C625 drop-in for Samsung C13532 (LCSC out of stock); C0G: no DC-bias/ageing term, MCLK-pump hold time unchanged')
row('R671, R681 (protection, sourcing)', 'SAE 1RC0402F2204 (2.2 M) / SAE 1RC0402F4704 (4.7 M), 1 %, 100 ppm, 50 V', 'C54530777 / C54530892', '0402 thick film', 'n/a', 'power / voltage / stock',
    '62.5 mW; 50 V; 1 %; 100 ppm/K (4.7 M listing; 2.2 M same series [ASSUMP])', '<= 4.0 V across -> < 0.01 mW; JLCPCB 9,900 / LCSC 4,600 (25 Sep 2026)', '> 90 %', 'OK', 'https://jlcpcb.com/partdetail/SAE-1RC0402F2204/C54530777 ; https://www.lcsc.com/product-detail/C54530892.html',
    'sourcing clean-up 25 Sep 16:05; replace UNI-ROYAL C11490 / C474132 (LCSC out of stock); high-impedance-node layout rule unchanged')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after sourcing clean-up:', len(rows), len(cur), dict(cnt))
# ---------------- R9 (decisions_r9.md E-14): thin-margin additions, C617 rating fact, U605 alternate (appended block; re-writes the outputs)
RR9 = 'R9 (decisions_r9 E-14)'
row('U201 / power brown-out (R9-A8)', 'brown-out watchdog threshold vs VBUS 4.40 V corner', '-', '-', 'power c14 / R9-A8', 'brown-out detection margin',
    'USB 2.0 VBUS minimum 4.40 V at the receptacle (brief); watchdog threshold per power c14', 'effective margin ~0.17 V between the threshold and the 4.40 V corner [R9-A8 figure, power owns the calculation]',
    '0.17 V', 'THIN', 'r9/reviews_r9.md (R9-A8)', RR9 + '; thin-margins table addition; [MEAS] VBUS droop at plug-in and the trip point on the first board')
row('U601-U603 leg windows (R9-D)', 'hardware DC-window false-trip margin at 20 Hz', '-', '-', 'protection p03/p11', '20 Hz full-scale square/sine vs the lowest trip level',
    'lowest trip 0.276 V (R9-A); 20 Hz square from rest 0.248 V (R9-A)', 'window margin ~6.2 % at 20 Hz [R9-D figure; protection owns the calculation]', '6.2 %', 'THIN', 'r9/reviews_r9.md (R9-A, R9-D)',
    RR9 + '; thin-margins table addition; aged-C corner of C601-C604 (-18.6 %) already inside (X-9); [MEAS] 20 Hz full-scale burst on the first board')
row('C617 (R9-B5 claim)', 'Samsung CL10A105KB8NNNC', 'C15849', '0603', 'n/a', 'voltage rating (fact check)', '50 V (Samsung code B = 50 V; LCSC page "CAP CER 1uF 50V X5R 0603", read 25 Sep 2026)',
    '-3.83 ... +4.01 V on node H', '> 45 V', 'OK', 'https://www.lcsc.com/product-detail/C15849.html',
    RR9 + '; R9-B "25 V part" claim is wrong; LCSC shows C15849 out of stock today (JLCPCB Basic stock not readable) - in-stock drop-in FH 0603X105K500NT (1 uF 50 V X5R 0603, LCSC 59,000 per the LCSC alternatives list) if JLCPCB is short')
row('U605 alternate (R9-A minor)', 'onsemi NCS3402DR2G (drop-in for TI TLV3402IDR)', 'C904569 (LCSC out of stock)', 'SOIC-8', 'TLV3402 dual pinout (onsemi NCS3402 = second source of the TLV340x family)', 'supply / IQ / availability',
    'VCC 2.7-16 V (-40..125 C), IQ <= 640 nA (DigiKey max), VIO <= 3.6 mV @ 15 V, CM -0.1 V ... VCC + 5 V, open drain, MSL 1, 260 C [onsemi/DigiKey]',
    '3V3M >= 3.23 V; stock: DigiKey 48 (Sep 2026), Mouser 290 (Jul 2026), LCSC 0 (Apr 2026)', '> 0.5 V', 'OK', 'https://www.onsemi.com/products/standard-products/amplifiers-comparators/comparators/ncs3402 ; https://www.digikey.com/en/products/detail/onsemi/NCS3402DR2G/3906396',
    RR9 + '; protection to confirm the timing bound (NCS3402 response ~220-250 us typ vs the TLV3402 value used in p10) before naming it approved')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after R9 E-14 rows:', len(rows), len(cur), dict(cnt))
# ---------------- R9 pre-screen for protection E-2 (latch) - appended; re-writes the outputs
row('E-2 latch candidate (pre-screen)', 'TI SN74LVC1G74DCUR (alt. Nexperia 74LVC1G74DC,125 / onsemi NC7SZ74K8X)', 'C70285', 'VSSOP-8 (DCU) 0.5 mm', 'TI DCU pinning (protection to map CLK/D/CLR/PRE/Q)', 'supply / Ioff / stock',
    'VCC 1.65-5.5 V; inputs 5.5 V tolerant; Ioff; ICC <= 10 uA; tpd <= 5.9 ns at 3.3 V [LCSC listing of the TI data]', 'on 3V3D or 3V3M <= 3.37 V; LCSC 4,740 (25 Sep 2026), min/multiple 5; alternates LCSC 514 / 2,440',
    '> 2 V', 'OK', 'https://www.lcsc.com/product-detail/C70285.html', 'R9 pre-screen; protection owns the choice and the power/clear/preset wiring; 0.5 mm pitch = JLCPCB-placed (not owner-fittable)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after R9 pre-screen:', len(rows), len(cur), dict(cnt))
# ---------------- R9 analog E-4 (mixed leg network) and protection sourcing proposal - appended; re-writes the outputs
for r in rows:
    if r['status'] == 'current' and r['refs'].startswith('R401-R416, R438-R445 (analog VE)'):
        r['status'] = 'superseded: R9 E-4 - R2/R4 2.00 k back to Susumu RG1608N-202-W-T1 0.05 %/10 ppm (analog mixed network, row below)'
row('R401-R416, R438-R445 (analog R9 E-4)', 'YAGEO RT0603BRD071K3L (1.30 k) / RT0603BRD07680RL (680 R), 0.1 %/25 ppm + Susumu RG1608N-202-W-T1 (2.00 k R2/R4), 0.05 %/10 ppm', 'C705738 / C861519 / - (global)', '0603 thin film',
    'n/a', 'availability / rating', '0.1 W, 75 V (Susumu RG1608N, AEC-Q200); YAGEO RT0603 0.1 W', 'LCSC 100 (1.30 k, min 20) / 8,000 (680 R); Susumu 2.00 k DigiKey 16,746 (25 Sep 2026), JLCPCB global sourcing; alt. Panasonic ERA-3ARW202V (DigiKey 1,259)',
    '1.30 k: 2.5 x the need', 'AVAIL', 'analog/bom_rows.csv ; https://www.digikey.com/en/products/detail/susumu/RG1608N-202-W-T1/600604',
    'R9: analog E-4 offset guaranteed (published terms) 5.61 / 11.21 mV; same 0603 land; pre-order the 1.30 k now (thin LCSC stock)')
row('R628-R631, R639, R663 (R9 proposal)', 'YAGEO AT0402BRD075K1L (5.1 k 0.1 %, 25 ppm, 50 V, AEC-Q200, anti-sulfur)', 'C851064', '0402 thin film', 'n/a', 'drop-in for RT0402BRD075K1L C852856 (LCSC out of stock)',
    '0.1 %, 25 ppm/K, 62.5 mW, 50 V [LCSC page 25 Sep 2026]', 'LCSC 6,850 (min/multiple 10); need 30 + attrition', '> 200 x need', 'OK', 'https://www.lcsc.com/product-detail/C851064.html',
    'R9 proposal to protection (sourcing only, same-or-better spec): removes the 5.1 k global-sourcing line; not adopted until protection changes its BOM')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after R9 E-4 / proposal rows:', len(rows), len(cur), dict(cnt))
# ---------------- R9 E-11 support: R665 330 ohm vs 1 k MCLK load (r9_mclk_tap.py) - appended; re-writes the outputs
row('R665 = 330 ohm option (R9 E-11)', 'UNI-ROYAL 0402WGF3300TCE (330 R) instead of 0402WGF1001TCE (1 k)', 'C25104 (Basic) / C11702', '0402', 'protection netlist: pin 1 MCLK at U301 XI, pin 2 N6_MCK_IN',
    'MCLK load at XI with the tap (Kyocera rated load 15 pF)', 'U607 CI 1.1 pF typ, no maximum published; digital MCLK load 13.1 pF (protection p10)',
    '330 R: 14.57-14.97 pF with CI typ and 1-5 mm trace, 15.03-15.37 pF with a 1.5 x CI bound; 1 k: 14.29-14.39 pF in every case [r9_mclk_tap.py]',
    '330 R: +0.22 pF (typ, 3 mm) ... -0.37 pF (bound, 5 mm); 1 k: >= +0.61 pF', 'THIN', 'r9_mclk_tap_out.txt',
    'R9: 330 R raises the Schmitt-input fundamental from 66-85 % to 94-98 % of the XI swing; the <= 15 pF claim with 330 R rests on CI <= ~1.4 pF [ASSUMP] and the <= 3 mm no-via trace rule - E-11 decision with protection/digital')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after R9 E-11 row:', len(rows), len(cur), dict(cnt))
# ---------------- R9 protection E-2/E-3 parts (protection BOM 17:15) - appended; re-writes the outputs
RP = 'R9 (protection E-2/E-3, BOM 25 Sep 17:15 - still iterating)'
row('U608 (protection R9 E-2)', 'Nexperia 74LVC1G74DC,125 (D flip-flop, set/reset, Ioff)', 'C503431', 'VSSOP-8 (SOT765-1) 0.5 mm', 'Nexperia DC pinning (protection netlist)', 'supply / inputs / stock',
    'VCC 1.65-5.5 V; inputs 5.5 V tolerant, Schmitt; Ioff; ICC 100 nA typ [LCSC listing of the Nexperia data]', 'rail <= 3.37 V; LCSC 4,620 (25 Sep 2026), min/multiple 5', '> 2 V', 'OK',
    'https://www.lcsc.com/product-detail/Flip-Flops_Nexperia-74LVC1G74DC-125_C503431.html', RP + '; JLCPCB-placed (0.5 mm, not owner-fittable); alternates TI SN74LVC1G74DCUR C70285 (4,740)')
row('U609, U610 (protection R9 E-3)', 'TI TLV1704AIPWR', 'C181596', 'TSSOP-14', 'as U601-U603', 'supply current / stock',
    'IQ <= 100 uA/ch (-40..125 C) [DS]', '2 x 4 x 100 uA = +0.80 mA per rail on VPOS/VNEG (power budget line must grow); LCSC 61 (re-read 25 Sep 2026) covers 6/board = 30 + attrition', 'n/a', 'AVAIL', U2['tlv1704'],
    RP + '; reserve the LCSC stock now; DigiKey 6,948 as the fallback')
row('D611, D612 (protection R9 E-3)', 'Nexperia BAS70-05,215 (common cathode)', 'C194653 (LCSC marketplace)', 'SOT23', 'Nexperia BAS70-05: 1 a1, 2 a2, 3 common k (protection to confirm in its netlist)', 'ratings / stock',
    'VR 70 V; IF 70 mA; Cd <= 2 pF; IR <= 0.1 uA at 50 V [Nexperia product page]', 'VR <= 8 V; LCSC C194653 marketplace listing (Jul 2026), DigiKey 10,694 (Sep 2026), Mouser 0 (53-week lead)', '> 60 V', 'AVAIL',
    'https://www.digikey.com/en/products/detail/nexperia-usa-inc/BAS70-05-215/763210 ; https://www.nexperia.com/product/BAS70-05', RP + '; buy now (global sourcing if the LCSC marketplace line is not usable)')
row('R900-R925 (protection R9 E-3)', 'YAGEO RT0402BRD 0.1 % (487 k, 750 k, 300 k, 698 k) + UNI-ROYAL 1 % (68 k); 1 M 0.1 % RT0402BRD071ML now x10/board', 'TBC / -', '0402', 'n/a', 'availability / power',
    '62.5 mW; 50 V', 'no LCSC stock found for 487 k / 300 k / 698 k / 750 k / 1 M 0.1 % (165 k C852553 was pre-order only, MOQ 10,000) -> global sourcing; power < 0.1 mW each', 'n/a', 'AVAIL', 'protection/bom_rows.csv',
    RP + '; +5 global-sourced 0.1 % types vs VE (JLCPCB global +10 % price, Extended fee each); protection may prefer LCSC-stocked equivalents (e.g. YAGEO AT0402BRD series) where the thresholds allow')
row('C631-C634 (protection R9 E-3)', 'C0G timer capacitor +/-2 % (MPN TBC at protection)', 'TBC', '0603/0805 (protection)', 'n/a', 'tolerance / availability', 'C0G, +/-2 % needed for the 5.5 % sine margin (protection p18/p19)',
    'MPN not chosen yet; +/-2 % C0G of this size was not found at LCSC in the parts searches (+/-5 % grades are common)', 'n/a', 'DATA-GAP', 'protection/bom_rows.csv',
    RP + '; if only +/-5 % is procurable, protection uses its 3.5 % sine-margin case')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after R9 protection rows:', len(rows), len(cur), dict(cnt))
# ---------------- R9 E-16 suspend power cut (power BOM 25 Sep 17:19) - appended; re-writes the outputs
RE = 'R9 E-16 (power BOM 17:19)'
for r in rows:
    if r['status'] != 'current':
        continue
    if r['refs'].startswith('D103, D104, D105 (power X-4)'):
        r['status'] = 'superseded: E-16 - D103 deleted (TPS70933 has reverse-current protection); D104/D105 unchanged (leakage now 0 in suspend: 5V_SYS off)'
    elif r['refs'] == 'U101' and r['parameter'].startswith('VBUS pin (5) on 5V_SYS'):
        r['status'] = 'resolved: E-16 - U101 pin 5 on 3V3M (<= 3.343 V < VRM 5.25 V)'
row('U502 (power R9 E-16)', 'TI TPS70933DBVR (30 V, 150 mA, ultra-low IQ, reverse-current protection)', 'C89347', 'SOT-23-5 (DBV)', 'TI DBV: 1 IN (VBUS), 2 GND, 3 EN (not connected), 4 NC, 5 OUT (3V3M) - same land as the TPS7A2033PDBVR it replaces',
    'VIN / EN / surge', 'VIN 2.7-30 V, 32 V abs; EN <= 6.5 V abs; ICL 200-500 mA [TI DS via power S1]', 'VBUS <= 5.5 V steady; <= 17.0 V at the 5V_SYS hard-short kick (D102 clamp, power c22) -> +13 V to the 30 V operating limit; EN left open (never tied to VBUS)',
    '+13 V', 'OK', 'https://www.ti.com/lit/ds/symlink/tps709.pdf ; https://www.lcsc.com/product-detail/C89347.html',
    RE + '; LCSC 5,280 (25 Sep 2026, min/multiple 5), JLCPCB 32,252 (power), Extended, Economic + Standard; power to cite the TPS709 EN "floating = enabled" statement (EN pin behaviour when open) in its report')
p709 = (5.5 - 3.207) * 0.083
row('U502 (power R9 E-16)', 'TI TPS70933DBVR', 'C89347', 'DBV', 'see above', 'Pd / TJ and dropout at 83 mA', 'TJ 125 C; RthJA 212 C/W; VDO <= 650 mV at 50 mA, <= 1400 mV at 150 mA [DS via power]',
    f'{1e3*p709:.0f} mW at 5.5 V / 83 mA (power 3V3M maximum) -> TJ {50 + p709*212:.0f} C; VDO at 83 mA ~0.90 V (linear interpolation) -> regulates for VBUS >= 4.24 V (VOUT max) - 0.16 V below the 4.40 V receptacle minimum after cable/connector drop',
    f'{125 - (50 + p709*212):.0f} C; ~0.1-0.16 V dropout margin', 'THIN', 'https://www.ti.com/lit/ds/symlink/tps709.pdf',
    RE + '; below VBUS ~4.25 V 3V3M falls out of regulation (power: ratiometric brown-out trip at 4.0 V not guaranteed -> power/digital own the brown-out statement); keep U502 >= 10 mm from U102 heat')
row('Q507 (power R9 E-16)', 'AOS AO3400A (U102 EN pull-down in Stop)', 'C20917', 'SOT-23', 'power netlist: G = N1_U102_OFF (R537 1 M to GND), S = GND, D = N1_U102_EN', 'VDS / VGS / off-state leakage into the EN node',
    'VDS 30 V; VGS +/-12 V; IDSS <= 1 uA (30 V, 25 C), <= 5 uA (55 C) [AOS DS]', 'VDS <= EN clamp ~6.4 V; VGS <= 3V3M 3.34 V; EN node: R109 470 k from VBUS vs IEN +/-2 uA + IDSS -> V_EN(ss) at VBUS 4.40 V = 4.40 - 0.47 x (2 + IDSS) V = 2.52 V at 2 uA IDSS, 1.11 V at the 5 uA spec value',
    '+0.62 V to the 1.9 V EN threshold with IDSS <= 2 uA [ASSUMP at ~2 V VDS]; fails at the 5 uA 30 V/55 C spec value', 'THIN', 'https://www.aosmd.com/res/datasheets/AO3400A.pdf',
    RE + '; the IDSS maximum is specified only at VDS = 30 V; at the ~2 V EN node it is far lower, but not guaranteed -> power: confirm with R109/IEN (or use a lower R109 / a low-leakage NMOS); [MEAS] U102 turn-on at VBUS 4.40 V and 50 C')
row('C102, C502, R537 (power R9 E-16)', 'Samsung CL21A225KAFNNNE 2.2 uF 25 V X5R 0805 / CL10A225KO8NNNC 2.2 uF 16 V / UNI-ROYAL 1 M', 'C87994 (page not retrievable) / C23630 / C26083', '0805 / 0603 / 0402', 'n/a', 'voltage / stock',
    '25 V / 16 V / 62.5 mW', 'C102 <= 17.0 V kick (68 % of 25 V), bias-derated C set by power (attach region A); C502 on 3V3M <= 3.34 V; R537 3.3 uA while held high', '> 8 V', 'OK', 'https://www.digikey.com/en/products/detail/samsung-electro-mechanics/CL21A225KAFNNNE/3887421',
    RE + '; CL21A225KAFNNNE: LCSC C87994 product page not retrievable today, DigiKey 80,862 (23 Sep 2026) -> confirm the LCSC/JLCPCB stock at order (same part with packaging code G: Mouser 279,983)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after E-16 rows:', len(rows), len(cur), dict(cnt))
# ---------------- R9 protection message 17:27: U605 alternate conditions, C631-C634 sourcing - appended; re-writes the outputs
for r in rows:
    if r['status'] == 'current' and r['refs'].startswith('U605 alternate (R9-A minor)'):
        r['status'] = 'superseded: protection accepted NCS3402DR2G with conditions (row below)'
    if r['status'] == 'current' and r['refs'].startswith('C631-C634 (protection R9 E-3)'):
        r['status'] = 'superseded: protection value 22 nF C0G +/-2 % 50 V 0603 (row below)'
row('U605 alternate (protection accepted 17:27)', 'onsemi NCS3402DR2G (owner/global sourcing; LCSC 0)', 'C904569 (LCSC out of stock)', 'SOIC-8', 'TLV3402 pinout', 'protection acceptance conditions',
    'needs: VOL <= 0.45 V at 35 uA; IQ <= 1 uA/ch at 0-60 C; input range covering 0-2.8 V at VCC 3.25 V',
    'IQ: DigiKey max 640 nA, Mouser 950 nA (listings) -> met; input range: onsemi page "-0.1 V to VCC + 5 V" -> met; VOL at 35 uA: NOT verified (NCS3402 datasheet PDF not readable by the parts tools; the TLV3402 it copies gives <= 0.2 V at 50 uA, 25 C)',
    'VOL open', 'DATA-GAP', 'https://www.onsemi.com/products/standard-products/amplifiers-comparators/comparators/ncs3402 ; https://www.digikey.com/en/products/detail/onsemi/NCS3402DR2G/3906396',
    'R9: approval of the alternate waits for the VOL line of the onsemi datasheet; response 220-250 us typ inside the protection 0.9 ms bound')
row('C631-C634 (protection R9 E-3, 22 nF C0G +/-2 % 50 V 0603)', 'MPN open (candidates KEMET C0603C223G5GACTU / TDK C1608C0G1H223G080AA / Murata GRM1885C1H223GA01D - existence and stock NOT verified)', '-', '0603', 'n/a', 'tolerance / sourcing',
    'C0G, +/-2 % needed (protection: +/-5 % halves the 5.5 % sine margin)', 'no LCSC-stocked +/-2 % 22 nF C0G 0603 found; distributor lookups for the candidates failed (tool limits)', 'n/a', 'DATA-GAP', 'protection/bom_rows.csv',
    'R9: open sourcing item - confirm one +/-2 % MPN at DigiKey/Mouser (JLCPCB global sourcing or owner purchase: 0603 2-terminal is owner-fittable if the group layout keeps 1.5 mm iron clearance)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after protection 17:27 rows:', len(rows), len(cur), dict(cnt))
# ---------------- R9 E-11 adopted (protection + digital 17:29): R665 = 330 ohm with the 10 mm absolute MCLK rule - appended; re-writes the outputs
for r in rows:
    if r['status'] != 'current':
        continue
    if r['refs'].startswith('R665 (protection X-6)') or r['refs'].startswith('R665 = 330 ohm option (R9 E-11)'):
        r['status'] = 'superseded: R9 E-11 adopted - R665 = 330 R C25104 with the 10 mm absolute MCLK trace rule (row below)'
row('R665 (R9 E-11 adopted)', 'UNI-ROYAL 0402WGF3300TCE (330 R, 1 %)', 'C25104 (Basic, same part as digital R228-R230)', '0402', 'protection netlist: pin 1 MCLK at U301 XI, pin 2 N6_MCK_IN',
    'MCLK load at XI with the tap', 'Kyocera KC2520K rated load 15 pF; U607 CI no maximum published',
    'digital: 14.2 pF with 2.4 pF counted behind R665 (0.8 pF margin), XI high/low >= 5.49 ns; parts r9_mclk_tap.py: 14.57-14.97 pF (CI typ) / 15.03-15.37 pF (1.5 x CI) for 1-5 mm - both assume the layout rules',
    '+0.8 pF (digital model)', 'THIN', 'r9_mclk_tap_out.txt ; digital/protection R9 E-11',
    'R9: valid ONLY with X201 pin 3 -> R203 -> XI <= 10 mm absolute, R665 pad on the XI trace <= 1.5 mm from pin 7 (T-stub <= 0.5 mm, no via), R665 -> U607 pin 2 <= 3 mm (no via) - layout_package.md; U607 swing now provable (+141 mV at 4.5 ns edges, protection p19)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after E-11 adopted:', len(rows), len(cur), dict(cnt))
# ---------------- R9 E-19...E-21 parts items (25 Sep 2026 17:4x-18:0x) - appended; re-writes the outputs
for r in rows:
    if r['status'] != 'current':
        continue
    if r['refs'].startswith('C631-C634 (protection R9 E-3, 22 nF C0G'):
        r['status'] = 'superseded: protection adopted Panasonic ECH-U1H223GX5 PPS film 1210 +/-2 % (row below)'
    if r['refs'].startswith('R900-R925') or r['refs'].startswith('R9xx'):
        r['status'] = 'superseded: RT0402 BRD range finding (rows below)'
row('C631-C634 (R9 E-3 timer C_T)', 'Panasonic ECH-U1H223GX5 (22 nF +/-2 % G, stacked metallized PPS film)', '- (not at LCSC; JLCPCB global sourcing)', '1210 / 3225 (3.2 x 2.5 x 1.5 mm, seated max 1.70 mm)', 'n/a (non-polar)',
    'DC voltage / tolerance / reflow', '50 V DC (30 V AC); +/-2 %; -55...125 C; reflow 260 C max and <= 95 s above 220 C at the capacitor surface [Panasonic/RS]; MSL 1 [DigiKey]',
    f'C_T charged from VPOS <= {VPOS2[2]:.3f} V through R_T; +/-2 % as required by protection p18/p19 (T_P 19.7-22.4 ms, sine margin 6.0 %); JLCPCB Standard peak <= 245 C, single top-side pass',
    f'{50 - VPOS2[2]:.1f} V; reflow +15 C', 'OK', 'https://industrial.panasonic.com/ww/products/pt/film-cap-electroequip/models/ECHU1H223GX5 ; https://www.digikey.com/en/products/detail/panasonic-industry/ECH-U1H223GX5/353685',
    'R9 E-21: stock DigiKey 10,488 ($0.565 @10), Mouser 21,571, RS 2,050 (Sep 2026); order remark: confirm Standard-profile time above 220 C <= 95 s; land: Panasonic ECHU 3225 land (datasheet not read here) - check against the IPC 1210 land at footprint review; owner-fit fallback (1210)')
BLOCK = [('R676, R683', '953 k', 'RT0402BRD07953KL', 2), ('R677, R684', '330 k', 'RT0402BRD07330KL', 2), ('R678, R685, R901-R915 odd', '1.00 M', 'RT0402BRD071ML', 10),
         ('R900-R914 even', '487 k', 'RT0402BRD07487KL', 8), ('R920-R923', '750 k', 'RT0402BRD07750KL', 4), ('R924', '300 k', 'RT0402BRD07300KL', 1), ('R925', '698 k', 'RT0402BRD07698KL', 1)]
for refs_, v, mpn, n in BLOCK:
    row(f'{refs_} (protection, {v} 0.1 % 25 ppm 0402)', f'YAGEO {mpn} - NOT ORDERABLE', '- (no listing at LCSC/DigiKey/Mouser)', '0402', 'n/a',
        'orderability (maker range)', 'YAGEO RT datasheet v17 Table 2: RT0402 +/-0.1 % +/-25 ppm = 4.7 R-240 k (BRE +/-50 ppm: <= 500 k; RT0603 BRD: 1 R-1 M)',
        f'{v} > 240 k -> MPN outside the maker range ({n}/board)', 'n/a', 'FAIL', 'https://yageogroup.com/content/datasheet/asset/file/pyu-rt_1-to-0-01_rohs_l',
        'R9 E-21 finding; fix owned by protection: (a) 0603 RT0603BRD same value (0.1 %, 25 ppm, 75 V, 0.1 W) or (b) re-scale to <= 240 k 0402 - asked 18:05')
row('R9xx/R67x 0603 proposal (for protection)', 'YAGEO RT0603BRD07xxxKL (0.1 %, 25 ppm, 75 V, 100 mW)', 'C326730 1 M (LCSC 1,200); C861426 487 k (1,840); C705762 300 k (65,780+); C861327 330 k (0); C861550 750 k (0)', '0603', 'n/a',
    'availability of the drop-in', 'same-or-better: tolerance, TCR, voltage (75 V > 50 V), power (0.1 W > 0.063 W); package 0402 -> 0603',
    '1 M / 487 k / 300 k stocked at LCSC; 330 k LCSC 0; 750 k 0 at LCSC/DigiKey/Mouser (Mouser on order Nov 2026); 953 k non-stocked (Bourns CRT0603-BY-9533ELF 0.1 %/25 ppm listed); 698 k DigiKey listing (stock not read)',
    'n/a', 'AVAIL', 'LCSC product pages C326730 / C861426 / C705762 / C861327; DigiKey 17021325 / 17023151; Octopart',
    'R9 E-21: area +~70 mm2 (28 x 2.5 mm2 courtyard) - fits the 100 x 80 zones; values without stock need protection to pick another maker or an E-96 neighbour')
row('R916-R919 (R9 E-3 R_D)', 'UNI-ROYAL 0402WGF6802TCE (68 k 1 %)', 'C36871 (JLCPCB Extended, 275,185; LCSC 288,700)', '0402', 'n/a', 'availability', 'stocked', 'stocked', 'n/a', 'OK', 'LCSC C36871', 'R9 E-21')
row('R509 (R9 E-18, owner-fitted)', 'KOA RN73R1JTTD4751B25 (4.75 k 0.1 % 25 ppm 0603, AEC-Q200)', '- (owner DigiKey)', '0603', 'n/a', 'availability / dissipation',
    'RN73R 0603: 0.1 W, 75 V [KOA]', 'ILM pin: ~1 V class across R509 -> < 1 mW', '> 99 %', 'AVAIL', 'https://www.koaspeer.com/products/fixed-resistors/thin-film/rn73r',
    'R9 E-21: DigiKey/Mouser listings exist, stock not read today; alternate Susumu RG1608P-4751-B-T5 (DigiKey 114,162) same 0.1 %/25 ppm 0603')
row('U605 alternate NCS3402DR2G (R9 E-21 item 4)', 'onsemi NCS3402DR2G', 'C904569 (LCSC 0)', 'SOIC-8', 'TLV3402 pinout', 'VOL at 35 uA', 'protection condition VOL <= 0.45 V at 35 uA',
    'still NOT verified (onsemi datasheet not readable by the parts tools) -> stays an unverified alternate; do not fit without the datasheet line', 'open', 'DATA-GAP', 'onsemi NCS3402 product page', 'R9 E-21: kept as unverified alternate')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after E-19...E-21 parts items:', len(rows), len(cur), dict(cnt))
# ---------------- R9 E-21 tidy: one NCS3402 DATA-GAP row only - appended; re-writes the outputs
for r in rows:
    if r['status'] == 'current' and r['refs'].startswith('U605 alternate (protection accepted 17:27)'):
        r['status'] = 'superseded: R9 E-21 item 4 row (VOL still unverified; unverified alternate)'
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after E-21 tidy:', len(rows), len(cur), dict(cnt))
# ---------------- R9 protection 17:56 (C631-C634 accepted): reflow limit vs JLCPCB Standard profile - appended; re-writes the outputs
for r in rows:
    if r['status'] == 'current' and r['refs'].startswith('C631-C634 (R9 E-3 timer C_T)'):
        r['status'] = 'superseded: split into electrical (OK) and reflow-profile (THIN) rows after protection acceptance 17:56'
row('C631-C634 (R9 E-3 C_T, electrical)', 'Panasonic ECH-U1H223GX5 (22 nF +/-2 % PPS film, 1210) - accepted by protection 17:56', '- (JLCPCB global sourcing)', '1210', 'n/a (non-polar)',
    'DC voltage / tolerance', '50 V DC; +/-2 %; TC bound +/-0.5 % over 0-60 C (protection p18)', f'<= {VPOS2[2]:.3f} V (VPOS through R_T); protection p18: T_P 19.72-22.37 ms, 20 Hz sine margin 6.0 %',
    f'{50 - VPOS2[2]:.1f} V', 'OK', 'protection p18 re-run 17:56; Panasonic ECHU1H223GX5 page', 'R9 E-21')
row('C631-C634 (R9 E-3 C_T, reflow)', 'Panasonic ECH-U1H223GX5', '-', '1210', 'n/a', 'reflow profile',
    '260 C max and <= 95 s above 220 C at the capacitor surface [Panasonic feature text via RS listings; data sheet PDF not read]',
    'JLCPCB Standard: peak 240 +/- 5 C (<= 245 C, published); time above liquidus not published - JLCPCB reflow guide: 45-90 s above the alloy melting point -> <= 90 s above 217 C, i.e. < 95 s above 220 C; single top-side pass',
    'peak 15 C; time >= 5 s', 'THIN', 'RS ECH-U1H223GX5 / ECH-U1C221JX5 listings; jlcpcb.com/blog/reflow-soldering-profile-explained (search preview); layout_package.md section 1',
    'R9: fits -> JLCPCB global sourcing, placed in reflow; order remark "confirm time above 220 C <= 95 s"; if JLCPCB cannot confirm -> owner-fitted (layout_package.md 13a conditional line; iron clearance reserved in Z7)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after protection 17:56:', len(rows), len(cur), dict(cnt))
# ---------------- R9 protection 18:00: RT0402 range blocker resolved (0603 for 1 M / 487 k / 300 k; re-scaled 0402 values) - appended; re-writes the outputs
for r in rows:
    if r['status'] != 'current':
        continue
    if 'NOT ORDERABLE' in r['mpn'] or r['refs'].startswith('R9xx/R67x 0603 proposal'):
        r['status'] = 'resolved: protection 18:00 - 0603 RT0603BRD for 1 M / 487 k / 300 k, re-scaled 0402 values <= 240 k (rows below)'
RES = [
    ('R678, R685, R901-R915 odd (1.00 M 0603)', 'YAGEO RT0603BRD071ML', 'C326730 (LCSC 1,200; JLCPCB Extended)', '0603', 10, 'OK', 'stocked: 50 + attrition of 1,200'),
    ('R900-R914 even, R920-R923 (487 k 0603)', 'YAGEO RT0603BRD07487KL', 'C861426 (LCSC 1,840; JLCPCB Extended)', '0603', 12, 'OK', 'stocked: 60 + attrition of 1,840; R_T now 487 k'),
    ('R677, R684 (300 k 0603)', 'YAGEO RT0603BRD07300KL', 'C705762 (LCSC 65,780+; JLCPCB Extended)', '0603', 2, 'OK', 'stocked'),
    ('R675, R682 (44.2 k 0402)', 'YAGEO RT0402BRD0744K2L', 'C705633 (LCSC ~19,650 per the LCSC alternatives list 18 Sep 2026; JLCPCB Extended)', '0402', 2, 'OK', 'stocked; product page not retrievable today'),
    ('R676, R683 (200 k 0402)', 'YAGEO RT0402BRD07200KL', 'C728556 (LCSC OUT OF STOCK 25 Sep 2026)', '0402', 2, 'AVAIL', 'JLCPCB global sourcing: DigiKey 171,161'),
    ('R924 (33.2 k 0402)', 'YAGEO RT0402BRD0733K2L', 'C852727 (LCSC OUT OF STOCK 25 Sep 2026)', '0402', 1, 'AVAIL', 'JLCPCB global sourcing: DigiKey 57,332, Mouser 41,728; LCSC option UNI-ROYAL TC0225B3322TCC C50670386 (8,750, 0.1 %/25 ppm, 25 V) if protection accepts it'),
    ('R925 (187 k 0402)', 'YAGEO RT0402BRD07187KL', 'C852576 (LCSC OUT OF STOCK 25 Sep 2026)', '0402', 1, 'AVAIL', 'JLCPCB global sourcing: DigiKey 25,219, Mouser 6,278'),
]
for refs_, mpn, lcsc, pkg, n, verdict, avail in RES:
    vr = '75 V, 0.1 W' if pkg == '0603' else '50 V, 0.063 W'
    row(refs_ + ' (protection R9 resolution)', mpn + ' (0.1 %, 25 ppm thin film; inside the YAGEO range)', lcsc, pkg, 'n/a',
        'voltage / power / availability', f'{vr} [YAGEO RT]', f'<= {VPOS2[2]:.2f} V across (3V3M / 3V3A / VPOS dividers); < 0.1 mW', f'> {70 if pkg == "0603" else 45} V', verdict,
        'protection/bom_rows.csv 18:00; LCSC / DigiKey / Mouser pages 25 Sep 2026', f'R9: {n}/board; {avail}; protection re-verified p10/p18: U605 threshold margin 73 mV, E-3 T_P 20.0-22.2 ms, sine margin 8.1 %, 13.9/27.5 mJ')
row('Re-scaled dividers (R675/R676, R682/R683, R924/R925) supply current', 'protection R9 values', '-', '-', 'n/a', 'divider current (active mode only)',
    '3V3A and VPOS are off in suspend (E-16) -> no suspend-budget impact', '3V3A: 3.3 V / 244.2 k = 13.5 uA per divider x 2 = 27 uA (was 5.5 uA); VPOS: 3.92 V / 220.2 k = 17.8 uA',
    '+~40 uA active (negligible)', 'OK', 'CALC (parts)', 'R9: tell power only if its active budget carries < 0.1 mA reserve')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after protection 18:00:', len(rows), len(cur), dict(cnt))
# ---------------- R9 check fixes (E-22...E-24, protection BOM 19:14): E-3 timer redesign, Q622 gate pull-down - appended; re-writes the outputs
SUP = ('D611, D612 (protection R9 E-3)', 'R916-R919 (R9 E-3 R_D)', 'C631-C634 (R9 E-3 C_T, electrical)', 'C631-C634 (R9 E-3 C_T, reflow)',
       'R900-R914 even, R920-R923 (487 k 0603)', 'R924 (33.2 k 0402)', 'R925 (187 k 0402)', 'Re-scaled dividers (R675/R676, R682/R683, R924/R925)')
for r in rows:
    if r['status'] == 'current' and r['refs'].startswith(SUP):
        r['status'] = 'superseded: R9 check E-22/E-24 timer redesign (protection BOM 19:14; rows below)'
VT = VPOS2[2]
row('Q623-Q626 (R9 check E-24, E-3 timer reset NPN)', 'JSCJ MMBT3904 (RANGE:100-300)', 'C20526 (JLCPCB Basic)', 'SOT-23', 'protection netlist 1 B / 2 E / 3 C (Q612 line)',
    'VCE / IC / leakage', 'VCEO 40 V, IC 200 mA; ICBO <= 50 nA (25 C) [DS per protection BOM]',
    f'VCE <= VPOS {VT:.3f} V; IC = C_T discharge, limited by beta x IB (IB ~ (VPOS - 0.7 V)/330 k ~ 10 uA -> <= 3 mA); off-state collector leakage adds to the timer-node leakage (no hot maximum published)',
    f'{40 - VT:.1f} V; IC >> 1 %', 'OK', 'protection/bom_rows.csv 19:14; JSCJ MMBT3904', 'R9 check: leakage covered by the protection p18 bound of 1 uA per timer node (E class, E-24)')
row('C631-C634 (R9 check E-24 C_T, electrical)', 'Panasonic ECH-U1H224GX9 (0.22 uF +/-2 % G, 50 V DC, stacked PPS film)', '- (not at LCSC; JLCPCB global sourcing)', '2416 (6.0 x 4.1 x 2.8 mm, 3.0 max)', 'n/a (non-polar)',
    'DC voltage / tolerance', '50 V DC (30 V AC); +/-2 %; -55...125 C; MSL 1 [DigiKey/Mouser]', f'C_T charged from VPOS <= {VT:.3f} V via R_T 110 k; protection p18: T_P 19.50-23.23 ms incl. 1 uA leakage, sine margin 5.8 %',
    f'{50 - VT:.1f} V', 'OK', 'https://www.digikey.com/en/products/detail/panasonic-industry/ECH-U1H224GX9/1630901 ; Mouser 667-ECH-U1H224GX9',
    'R9 check: protection BOM example "ECH-U1C224GX5" not found in the Panasonic line -> parts selected ECH-U1H224GX9 (16 V requirement exceeded); stock Mouser 19,207, DigiKey 62 (25 Sep 2026)')
row('C631-C634 (R9 check E-24 C_T, reflow)', 'Panasonic ECH-U1H224GX9', '-', '2416', 'n/a', 'reflow profile',
    'ECHU(X) series feature text: 260 C max and <= 95 s above 220 C at the capacitor surface (size-specific limit for 2416 not read)',
    'JLCPCB Standard peak <= 245 C (published); time above liquidus not published - JLCPCB reflow guide 45-90 s above melting; a 2416 body heats slower than a 1210 (surface below the board peak)',
    'peak 15 C; time >= 5 s', 'THIN', 'RS/Panasonic ECHU feature text; layout_package.md section 13',
    'R9 check: order remark "confirm time above 220 C <= 95 s for ECH-U1H224GX9"; owner-fit fallback (2416) in layout_package.md 13a')
row('R900-R914 even (487 k 0603, R9 check)', 'YAGEO RT0603BRD07487KL', 'C861426 (LCSC 1,840; JLCPCB Extended)', '0603', 'n/a', 'voltage / power / availability', '75 V, 0.1 W [YAGEO RT]',
    f'<= {VT:.2f} V across; < 0.1 mW', '> 70 V', 'OK', 'protection/bom_rows.csv 19:14', 'R9 check: 8/board (R920-R923 moved to 110 k 0402)')
row('R920-R923 (110 k 0402, R9 check E-24 R_T)', 'YAGEO RT0402BRD07110KL', 'C705063 (LCSC 8,000; DigiKey 17,115)', '0402', 'n/a', 'voltage / power / availability', '50 V, 0.063 W [YAGEO RT]',
    f'<= {VT:.2f} V across; <= {1e3 * VT ** 2 / 110e3:.2f} mW', '> 45 V', 'OK', 'LCSC C705063', 'R9 check E-24 (leakage-robust R_T)')
row('R924 (69.8 k 0402, R9 check V_T top)', 'YAGEO RT0402BRD0769K8L', 'C852893 (LCSC stock only on a 2024 page)', '0402', 'n/a', 'availability', '50 V, 0.063 W [YAGEO RT]',
    f'<= {VT:.2f} V across', '> 45 V', 'AVAIL', 'LCSC C852893; DigiKey 1069372 (US 0 until Feb 2027; SG 6,577)',
    'R9 check: JLCPCB global sourcing; same-spec alternate Vishay TNPW040269K8BEED (DigiKey 72,019) for protection approval')
row('R925 (100 k 0402, R9 check V_T bottom)', 'YAGEO RT0402BRD07100KL', 'C852472 (LCSC 742,100)', '0402', 'n/a', 'availability', '50 V, 0.063 W [YAGEO RT]', f'<= {VT:.2f} V across', '> 45 V', 'OK', 'LCSC C852472', 'R9 check')
row('R916-R919 (330 k 0402, R9 check NPN base pull-ups)', 'UNI-ROYAL 0402WGF3303TCE', 'C25778 (JLCPCB Extended; LCSC 72,700 per the 25 Sep alternatives list)', '0402', 'n/a', 'availability / class',
    '50 V, 0.063 W, 1 %', f'<= {VT:.2f} V across', '> 45 V', 'OK', 'jlcpcb.com partdetail C25778; lcsc C138006 alternatives list',
    'R9 check: class is Extended (protection line said Basic); drop-in YAGEO RC0402FR-07330KL C138006 (355,200) if short')
row('R696 (R9 check E-23, Q622 gate pull-down)', 'UNI-ROYAL 0402WGF1003TCE (100 k 1 %)', 'C25741 (Basic)', '0402', 'protection netlist N6_ARMG-GND', 'Q622 gate drive with the pull-down',
    'AO3400A VGS(th) 0.65-1.45 V [DS]', 'U608 Q high 3.3 V through R692 1 k into 100 k -> VG = 3.27 V (divider -1 %); U608 unpowered / R692 open -> VG = 0 V (Q622 off)', '> 1.8 V over VGS(th)max', 'OK', 'CALC (parts)',
    'R9 check E-23: closes the "R692 open / U608 Hi-Z leaves Q622 on" single fault')
row('Re-scaled dividers after the R9 check (R675/R676, R682/R683, R924/R925)', 'protection values', '-', '-', 'n/a', 'divider current (active mode only)',
    '3V3A and VPOS are off in suspend (E-16) -> no suspend-budget impact', f'3V3A: 3.3 V / 244.2 k x 2 = 27 uA; VPOS: {VT:.2f} V / 169.8 k = {1e6 * VT / 169.8e3:.1f} uA',
    '+~50 uA active (negligible)', 'OK', 'CALC (parts)', 'R9 check; protection told power the block-6 change (I+ 2.66 / I- 2.48 mA)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after R9 check fixes:', len(rows), len(cur), dict(cnt))
# ---------------- R9 check: protection message 19:27 (NPN stress figures, C_T voltage) - appended; re-writes the outputs
for r in rows:
    if r['status'] == 'current' and (r['refs'].startswith('Q623-Q626 (R9 check E-24') or r['refs'].startswith('C631-C634 (R9 check E-24 C_T, electrical)')):
        r['status'] = 'superseded: protection 19:27 stress figures (row below)'
row('Q623-Q626 (R9 check E-24, E-3 timer reset NPN; protection 19:27 figures)', 'JSCJ MMBT3904 (RANGE:100-300)', 'C20526 (JLCPCB Basic)', 'SOT-23', 'protection netlist 1 B / 2 E / 3 C',
    'VCB / VEB reverse / IC', 'VCBO 60 V, VCEO 40 V, VEBO 6.0 V, IC 200 mA [MMBT3904 DS]',
    'protection: VCB <= 6.2 V; VEB reverse <= 3.8 V (base node follows the comparator output down to VNEG); IC <= 0.4 mA peak (C_T discharge)',
    'VCB 53.8 V; VEB 2.2 V (37 %); IC >> 99 %', 'OK', 'protection message 19:27; MMBT3904 data sheet ratings',
    'R9 check: VEB reverse 3.8 V is below the 6 V rating (no E-B avalanche); off-state collector leakage inside the protection 1 uA/node bound (E-24)')
row('C631-C634 (R9 check E-24 C_T, electrical; protection 19:27)', 'Panasonic ECH-U1H224GX9 (0.22 uF +/-2 %, 50 V DC, PPS, 2416)', '- (JLCPCB global sourcing)', '2416', 'n/a (non-polar)',
    'DC voltage / tolerance', '50 V DC; +/-2 %; protection requirement >= 16 V', 'protection: C_T sees <= 3.4 V; T_P 19.50-23.23 ms incl. 1 uA leakage, sine margin 5.8 %',
    '46.6 V', 'OK', 'protection message 19:27; DigiKey/Mouser ECH-U1H224GX9', 'R9 check: selected by parts (the example ECH-U1C224GX5 is not in the Panasonic line); Mouser 19,207, DigiKey 62')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('after protection 19:27:', len(rows), len(cur), dict(cnt))
# ---------------- final integration rebuild fix (orchestrator 19:54): Q507 = MMBT3904 + R537/R538 100 k; stale R9-check rows - appended; re-writes the outputs
STALE = ('Q507 (power R9 E-16)', 'C102, C502, R537 (power R9 E-16)', 'E-2 latch candidate (pre-screen)', 'U608 (protection R9 E-2)', 'U609, U610 (protection R9 E-3)')
for r in rows:
    if r['status'] == 'current' and r['refs'] in STALE:
        r['status'] = 'superseded: final R9 circuit (orchestrator 19:54; rows below)'
# Q507 EN-node calculation (values: power/report.md R9 fixes + integration/netlist_merged.csv)
VBUS_LO = 4.40                     # V, power brown-out corner
R109_MAX = 470e3 * 1.01            # UNI-ROYAL 1 % pull-up VBUS -> N1_U102_EN
IEN = 2.0e-6                       # TPS25200 EN pin current |IEN| <= 2 uA [DS 5.5], taken as a sink (worst for turn-on)
V_ON = 1.9                         # TPS25200 EN turn-on threshold, max [DS 5.5]
V_OFF = 0.6                        # TPS25200 EN turn-off threshold, min [DS 5.5]
ICBO_25 = 100e-9                   # JSCJ MMBT3904: ICBO <= 100 nA (VCB 60 V, 25 C); ICEX <= 50 nA (VCE 30 V, VEB(off) 3 V) [DS V2.1]
T_HOT = 50.0
ICBO_HOT = ICBO_25 * 2 ** ((T_HOT - 25) / 10)   # [ASSUMP] x2 per 10 C -> 0.566 uA at 50 C (VCB here only ~3-4 V -> conservative)
V_BE_OFF = ICBO_HOT * 100e3        # base held by R538 100 k (PC14 floating) -> VBE from ICBO, far below conduction
V_EN = VBUS_LO - R109_MAX * (IEN + ICBO_HOT)
I_ALLOW = (VBUS_LO - V_ON) / R109_MAX - IEN
V3M_MIN = 3.3 * 0.98               # 3V3M -2 % (PC14 VOH at uA load ~ VDD)
IB_ON = (V3M_MIN - 0.75) / (100e3 * 1.01) - 0.75 / (100e3 * 0.99)
IC_NEED = 5.55 / (470e3 * 0.99) + IEN
row('Q507 (power R9 E-16, released circuit)', 'JSCJ MMBT3904 (RANGE:100-300) NPN', 'C20526 (JLCPCB Basic; LCSC 25,800)', 'SOT-23',
    'merged netlist: 1 B = N5_Q507_B (R537 100 k from N5_U102_OFF = MCU PC14; R538 100 k to GND), 2 E = GND, 3 C = N1_U102_EN (R109 470 k from VBUS, C104, U102 EN)',
    'VCEO / VEBO / collector cut-off current into the U102 EN node',
    'VCBO 60 V, VCEO 40 V, VEBO 6 V, IC 200 mA; ICEX <= 50 nA (VCE 30 V, VEB(off) 3 V), ICBO <= 100 nA (VCB 60 V), 25 C [JSCJ MMBT3904 DS V2.1]',
    f'off (PC14 low/floating): VCE = V_EN <= VBUS (<= 17 V kick) vs 40 V; VEB never reversed (base at 0 V via R538, VBE {1e3 * V_BE_OFF:.0f} mV from ICBO); ICBO at 50 C {1e6 * ICBO_HOT:.2f} uA [ASSUMP x2/10 C from the 100 nA 25 C max] -> '
    f'V_EN = {VBUS_LO:.2f} - {R109_MAX / 1e3:.1f} k x ({1e6 * IEN:.1f} + {1e6 * ICBO_HOT:.2f}) uA = {V_EN:.2f} V at VBUS {VBUS_LO:.2f} V, 50 C; '
    f'on (PC14 high): IB >= {1e6 * IB_ON:.1f} uA vs IC <= {1e6 * IC_NEED:.1f} uA (forced beta < 1) -> EN << {V_OFF} V',
    f'+{V_EN - V_ON:.2f} V to the 1.9 V EN turn-on threshold; leakage allowance {1e6 * I_ALLOW:.2f} uA = {I_ALLOW / ICBO_HOT:.1f} x the 50 C bound',
    'OK', 'https://www.jscj-elec.com/uploads/pdf/20221020/MMBT3904%20SOT-23%20V2.1.pdf ; power/report.md R9 fixes (Q507 row) ; TPS25200 DS 5.5',
    'final rebuild: replaces the AO3400A row (IDSS 5 uA at 30 V/55 C would have pulled EN to ~1.1 V); power quotes EN >= 3.19 V at 60 C with 0.55 uA - same method')
row('C102, C502, R537, R538 (power R9 E-16, released circuit)', 'Samsung CL21A225KAFNNNE 2.2 uF 25 V X5R 0805 / Samsung CL10A225KO8NNNC 2.2 uF 16 V 0603 / UNI-ROYAL 0402WGF1003TCE 100 k x2',
    'C87994 (Extended) / C23630 (Basic) / C25741 (Basic)', '0805 / 0603 / 0402', 'n/a', 'voltage / dissipation / stock',
    '25 V / 16 V / 62.5 mW, 50 V', f'C102 <= 17.0 V kick (68 % of 25 V); C502 on 3V3M <= 3.37 V; R537 <= {(3.37 - 0.6) ** 2 / 100e3 * 1e6:.0f} uW and R538 <= {0.8 ** 2 / 100e3 * 1e6:.1f} uW with PC14 high, 0 with PC14 low',
    '> 8 V; > 99 %', 'OK', 'power/bom_rows.csv (C102 sourcing filled by parts, E-27); integration/netlist_merged.csv',
    'final rebuild: R537 is 100 k (was 1 M) and R538 100 k is new; C102 LCSC C87994 (szlcsc), DigiKey 80,862 - confirm stock in the JLCPCB BOM tool at order')
row('U608 (protection R9 E-2, released)', 'Nexperia 74LVC1G74DC,125 (D flip-flop, set/reset, Ioff)', 'C503431 (JLCPCB Extended, Economic + Standard, MSL 1)', 'VSSOP-8 (SOT765-1) 0.5 mm',
    'protection netlist: 1 CP, 2 D, 3 /Q, 4 GND, 5 Q, 6 /RD, 7 /SD, 8 VCC (R9 check pin map)', 'supply / inputs / stock',
    'VCC 1.65-5.5 V; inputs 5.5 V tolerant, Schmitt; Ioff [Nexperia]', 'on 3V3D <= 3.37 V; LCSC 4,620, JLCPCB 2,579 (Apr page), DigiKey 4,343', '> 2 V', 'OK',
    'jlcpcb.com partdetail C503431; protection/bom_rows.csv', 'final rebuild: Q output drives Q622 through R692 1 k with the R696 100 k gate pull-down (VG 3.27 V on, 0 V with R692 open / U608 unpowered)')
row('U609, U610 (protection R9 E-3, released)', 'TI TLV1704AIPWR', 'C181596 (LCSC 61 = 6/board reserve)', 'TSSOP-14 (PW)', 'protection netlist: pins 1/2 level outputs -> NPN bases (330 k to VPOS), 8/10 timer inputs, 9/11 V_T, 13/14 -> N6_H',
    'supply current / output sink / stock', 'IQ <= 100 uA/ch (-40..125 C); open-collector output, VS <= 36 V [TI DS]',
    'IQ 2 x 4 x 100 uA = 0.80 mA per rail on VPOS/VNEG; level outputs sink (VPOS - VNEG)/330 k <= 24 uA each; supply span <= 7.7 V; block-6 totals carried by power (protection 19:22: I+ 2.66 / I- 2.48 mA)',
    '> 28 V', 'AVAIL', 'protection/bom_rows.csv + netlist.csv (R9 check)', 'final rebuild: LCSC 61 covers 6/board x 5 = 30 + attrition - reserve now; DigiKey 6,948 fallback')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('final rebuild fix:', len(rows), len(cur), dict(cnt))
print('V_EN', round(V_EN, 3), 'margin', round(V_EN - V_ON, 3), 'ICBO_hot uA', round(ICBO_HOT * 1e6, 3), 'allow uA', round(I_ALLOW * 1e6, 2), 'IB_on uA', round(IB_ON * 1e6, 1), 'IC_need uA', round(IC_NEED * 1e6, 1))
# ---------------- final rebuild: stress rows for the remaining new R9 E-2/E-3 parts (C630, C635-C638, Q621, Q622, R690-R695) - appended; re-writes the outputs
V3D = 3.37
row('C630, C635-C638 (protection R9 E-2/E-3 decoupling)', 'Samsung CL05B104KO5NNNC (100 nF 16 V X7R 0402; C612 line)', 'C1525 (JLCPCB Basic)', '0402', 'protection netlist: C630 3V3D-GND at U608; C635/C637 VPOS-GND, C636/C638 VNEG-GND at U609/U610 pins 3/12',
    'DC voltage', '16 V DC [Samsung]', f'C630 <= {V3D:.2f} V; C635/C637 <= {VPOS2[2]:.3f} V; C636/C638 <= {VNEG2[2]:.3f} V (magnitude)', f'> {16 - max(VPOS2[2], VNEG2[2]):.1f} V', 'OK',
    'protection/bom_rows.csv (C612 line)', 'final rebuild: decoupling only (X7R bias loss irrelevant at <= 4 V of 16 V)')
row('Q621 (protection R9 E-2, latch clear inverter)', 'JSCJ 2N7002 (Q618 line)', 'C8545 (JLCPCB Basic)', 'SOT-23', 'protection netlist: 1 G = N6_TRIP (R690 330 k to 3V3D), 2 S = GND, 3 D = N6_CLR_N (R691 100 k to 3V3D, U608 /RD)',
    'VDS / VGS / drive', 'VDS 60 V, VGS +/-20 V, VGS(th) 1.0-2.5 V [JSCJ 2N7002]',
    f'VDS <= {V3D:.2f} V; ID <= {V3D / 100e3 * 1e6:.0f} uA (R691); VGS +{V3D:.2f} V (R690) down to -{VNEG2[2]:.2f} V if the U606 open-collector output pulls N6_TRIP to VNEG; on-drive 3.23 V (3V3D min) vs VGS(th) max 2.5 V (spec at 250 uA; load only 34 uA)',
    f'VGS {20 - VNEG2[2]:.1f} V; drive +0.73 V over VGS(th)max', 'OK', 'protection netlist; JSCJ 2N7002',
    'final rebuild: an open Q621 is covered by the boot self-test (E-23: PB0 stays high after the self-test trip -> fault, no closure)')
row('Q622 (protection R9 E-2, LED-return arm switch)', 'AOS AO3400A (Q616 line)', 'C20917 (JLCPCB Basic)', 'SOT-23', 'protection netlist: 1 G = N6_ARMG (R692 1 k from U608 Q = N6_ARM; R696 100 k to GND), 2 S = GND, 3 D = N6_M3 (Q617 source)',
    'VDS / ID / VGS', 'VDS 30 V, ID 5.7 A, VGS +/-12 V, VGS(th) 0.65-1.45 V, RDS(on) <= 48 mOhm at 2.5 V [AOS]',
    'VDS <= 5V_SYS 5.55 V (LED-string return); ID <= 7.1 mA (both strings); VGS 3.27 V on (1 k / 100 k), 0 V off -> drop <= 0.4 mV',
    'VDS 24 V; VGS 8.7 V', 'OK', 'protection netlist; AO3400A data sheet',
    'final rebuild: a drain-source short is latent -> production-test step (E-23); R696 keeps it off with R692 open or U608 unpowered')
row('R690-R695 (protection R9 E-2 latch network)', 'UNI-ROYAL 0402WGF3303TCE 330 k (R690, R694) / 0402WGF1003TCE 100 k (R691, R693, R695) / 0402WGF1001TCE 1 k (R692)', 'C25778 (Extended) / C25741 (Basic) / C11702 (Basic)', '0402',
    'protection netlist: R690 3V3D-N6_TRIP, R691 3V3D-N6_CLR_N, R692 N6_ARM-N6_ARMG, R693 VPOS-N6_HREF, R694 N6_HREF-GND, R695 N6_ARM-N6_ARM_MCU (PB0)', 'dissipation / voltage',
    '62.5 mW, 50 V [UNI-ROYAL]', f'R690 <= {(V3D + VNEG2[2]) ** 2 / 330e3 * 1e3:.2f} mW (TRIP at VNEG); R691 {V3D ** 2 / 100e3 * 1e3:.2f} mW; R693/R694 divider {VPOS2[2] / 430e3 * 1e6:.1f} uA; R692/R695 < 0.01 mW',
    '> 99 %', 'OK', 'protection/bom_rows.csv + netlist.csv', 'final rebuild')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('final rebuild, all new parts:', len(rows), len(cur), dict(cnt))
# ---------------- R9-RECHECK-01: U606 channel 4 is the E-2 latch H-OK detector (not spare) - appended; re-writes the outputs
for r in rows:
    if r['status'] == 'current' and r['refs'] == 'U606 (protection X-6)':
        r['status'] = 'superseded: R9-RECHECK-01 - ch4 is used by the E-2 re-arm latch (row below)'
HREF_LO, HREF_HI = 2.8833, 3.1059      # R9 check (independent reproduction): HREF = VPOS x 330/(100 + 330)
row('U606 (protection X-6 + R9 E-2 latch detector)', 'TI TLV1704AIPWR', 'C181596', 'TSSOP-14 (PW)',
    'merged netlist: ch1 1V3 good (4/5, out 2), ch2 MCLK alive (6/7, out 1), ch3 3V3A repeater (8/9, out 14) -> N6_H; ch4 = E-2 H-OK detector: pin 10 (4IN-) = N6_H, pin 11 (4IN+) = N6_HREF (R693 100 k from VPOS / R694 330 k), pin 13 (4OUT) = N6_TRIP (R690 330 k to 3V3D, Q621 gate); V+ 3 = VPOS, V- 12 = VNEG',
    'supply / inputs / outputs', 'VS 2.2-36 V; inputs V- ... V+ (+/-10 mA abs); open collector 36 V above V-; IQ <= 100 uA/ch (-40..125 C) [DS]',
    f'VS <= {VSPAN2:.2f} V; ch1-ch3 inputs through R670 10 k (1V3), R667 100 k (pump node <= 3.2 V), R681 4.7 M; ch4 inputs: N6_H (0 ... VPOS, R647 100 k pull-up) and N6_HREF {HREF_LO:.2f}-{HREF_HI:.2f} V (inside the rails); '
    f'pin 13 open collector pulled to 3V3D by R690: sinks <= {(3.37 + VNEG2[2]) / 330e3 * 1e6:.0f} uA (to VNEG) while H > HREF, released (high) on a trip or with U606 unpowered; unpowered injection <= 32 uA [protection p10]',
    '> 28 V', 'OK', 'https://www.ti.com/lit/ds/symlink/tlv1704.pdf ; integration/netlist_merged.csv (U606 pins 10/11/13)',
    'R9-RECHECK-01: pin 13 is NOT NC (the superseded row wrongly called channel 4 unused; it is the latch detector since R9 E-2); layout: N6_TRIP pin 13 -> R690/Q621 <= 5 mm, N6_HREF R693/R694 at pin 11 <= 5 mm, N6_H to pin 10 under the node-H rules; supply: 4 x 100 uA per rail + dividers (power budget)')
with open('stress_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow(r)
cur = [r for r in rows if r['status'] == 'current']
old = [r for r in rows if r['status'] != 'current']
cnt = Counter(r['verdict'] for r in cur)
with open('stress_calc_out.txt', 'w', encoding='utf-8') as f:
    f.write(f'rows: {len(rows)} ({len(cur)} current, {len(old)} superseded/resolved kept for traceability)\n')
    f.write(f'verdicts of current rows: {dict(cnt)}\n\n')
    for r in cur:
        if r['verdict'] != 'OK':
            f.write(f"{r['verdict']:9s} {r['refs']}: {r['parameter']} | rating {r['rating']} | worst {r['worst_operating_value']} | margin {r['margin']}\n")
    f.write('\nSuperseded / resolved rows:\n')
    for r in old:
        f.write(f"  {r['refs']}: {r['parameter']} ({r['verdict']}) -> {r['status']}\n")
print('R9-RECHECK-01:', len(rows), len(cur), dict(cnt))
